import api from './api';
let setSession = ()=>{
    return new Promise((resolve,reject)=>{
        api.get('common/config').then(res=>{
            window.sessionStorage.setItem('fmadminOptionMap',JSON.stringify(res.data));
            resolve()
        })
    })
}
export default setSession;