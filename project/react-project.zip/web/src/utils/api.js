
import axios from 'axios';
const http = axios.create({
  baseURL: '/api/'
})


// 增加错误处理
// 完善流程
// if( typeof Promise.prototype.done === 'undefined' ){
//   Promise.prototype.done = function( onDone, onFail ){  
//     this.then( onDone, onFail ).catch(err => {
//       setTimeout(()=>{
//         // onDone && onDone( err )
//         throw err
//       }, 0)
//     })
//   }
// }



http.interceptors.response.use(
  response => {
    let data = response.data;
    let status = response.status;

    if( status !== 200 ){
      return Promise.reject(response);
    }

    // 数据请求成功
    if(data.code === 20000) {
      return Promise.resolve(response.data);
    }    

    //cookie失效 未登录
    if(data.code === 40100) {
      return Promise.resolve(response.data);
    }

    return Promise.resolve(response.data)
  },
  err => {

  }
);
 

const get = (url, params) => http.get(url, {params});
const getSingle = (url, id) => http.get(url + '/' + id);
const post = (url, data) => http.post(url, data);
const put = (url, data, id) => {
  if(id){
    return http.put(url + '/' + id, data)
  }else{ 
    return http.put(url,data)
  }
};
const putWithoutId = (url, data) => http.put(url, data);
const del = (url, id) => http.delete(url + '/' + id);
const delByParams = (url, params) => http.delete(url, params);

let api = {
  get,
  getSingle,
  post,
  put,
  putWithoutId,
  del,
  delByParams,
}

export default api;

