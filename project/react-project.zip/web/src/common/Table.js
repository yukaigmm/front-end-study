import React,{Component} from 'react';
import {Table, Pagination} from "antd"

class RTable extends Component{
    constructor(props){
        super(props);
        this.state = {

        }
    }
    getTableData = () => {

    }
    render(){
        let {
            tableData, 
            columns,
            rowKey,
            scroll,
            onRow,
            pageChange,
            pageSizeChange,
            total,
            page,
            pageSize
        } = this.props;
        console.log(tableData)
        return (
            <div className="table-container">
                <Table
                  dataSource={tableData}
                  columns={columns}
                  rowKey={rowKey}
                  pagination={false}
                  scroll={scroll}
                  onRow={onRow}
                  bordered
                />
                <Pagination
                    size="small"
                    showSizeChanger
                    showQuickJumper
                    onChange={pageChange}
                    onShowSizeChange={pageSizeChange}
                    total={total}
                    current={page}
                    pageSize={pageSize}
                />
            </div>
        )
    }
}
export default RTable;