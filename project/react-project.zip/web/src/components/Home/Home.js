
import React, { Component } from 'react';


class Home extends Component {
  render () {
    return (
      <div>home</div>
    )
  }
}

export default Home;