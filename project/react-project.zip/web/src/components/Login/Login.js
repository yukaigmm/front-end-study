import {Form,Input,Button,message} from 'antd';
import React,{Component} from 'react';
import api from '../../utils/api';
import './Login.less'
const FormItem = Form.Item;
class LoginForm extends Component{
    render(){
        const {getFieldDecorator} = this.props.form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 8 },
              },
              wrapperCol: {
                xs: { span: 24 },
                sm: { span: 16 },
              },
        }
        return (
            <div className="login-form-container">
                <div className="login-form-wrapper">
                    <Form className="login-form" onSubmit={this.formSubmit}>
                        <FormItem label="用户名" {...formItemLayout}>
                            {
                                getFieldDecorator('user_name',{
                                    rules:[
                                        {required:true,message:'请输入用户名'}
                                    ]
                                })(<Input onBlur={()=>{this.validateSigleField('user_name')}}/>)
                            }
                        </FormItem>
                        <FormItem label="密码" {...formItemLayout}> 
                    
                            {
                                getFieldDecorator('password',{
                                    rules:[{required:true,message:'请输入密码'}]
                                })(<Input type="password" onBlur={()=>{this.validateSigleField('password')}}/>)
                            }
                        </FormItem>
                        <FormItem className="submit-button">
                            <Button type="primary" htmlType="submit">登录</Button>
                        </FormItem>
                    </Form>
                </div>
            </div>
        )
    }
    constructor(props){
        super(props);
        this.formSubmit = this.formSubmit.bind(this);
        this.validateSigleField = this.validateSigleField.bind(this);
    }
    formSubmit(e){
        e.preventDefault();
        this.props.form.validateFields((err,value)=>{
            let params = {...value,remember:true};
            if(!err){
                api.post('user/checkLogin',params).then(res=>{
                    if(res.code === 20000){
                        message.success('登录成功!')
                        window.localStorage.setItem('userName',res.data.trueName)
                        this.props.history.push('/index/roadshow');
                    }
                })
            }
        })
    }
    validateSigleField(name){
        this.props.form.validateFields(['name'],{force:true})
    }
    componentDidMount(){
        api.get('user/checkInfo').then(res=>{
            if(res.code === 20000){

            }
        })
    }
}
const  Login = Form.create()(LoginForm);
export default Login;