import {Form,Radio,Input,Row,Col} from 'antd';
import React,{Component} from 'react';
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const {TextArea} = Input;
class ModalForm extends Component{
    render(){
        const {getFieldDecorator} = this.props.form;
        const formItemLayout = {
            labelCol: {
                // xs: { span: 24 },
                span: 6 ,
              },
              wrapperCol: {
                // xs: { span: 24 },
                span: 18 ,
              },
        };
        let {needRemark} = this.state;
        return (
            <Form className="roadshow-modal-form">
                <Row>
                    <Col span={12}>
                        <FormItem label="审核结果" {...formItemLayout}>
                            {
                                getFieldDecorator('auditStatus',{
                                    rules:[
                                        {required:true,message:'请选择审核结果'}
                                    ]
                                })(<RadioGroup onChange={this.auditStatusChange.bind(this)}>
                                    <Radio value={1}>通过</Radio>
                                    <Radio value={0}>不通过</Radio>
                                    </RadioGroup>)
                            }
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="路演ID" {...formItemLayout}>
                            {
                                getFieldDecorator('paramQueryId',{
                                    rules:[
                                        {required:!needRemark,message:'请输入路演ID'}
                                    ]
                                })(<Input/>)
                            }
                        </FormItem>
                    </Col>
                </Row>
                <FormItem label="审核备注" {...formItemLayout}>
                    {
                        getFieldDecorator('auditRemark',{
                            rules:[{required:needRemark,message:'请输入审核备注'}]
                        })(<TextArea rows={4}/>)
                    }
                </FormItem>
            </Form>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            needRemark:false
        }
    }
    componentWillReceiveProps(props){
        // console.log(props)
        // if(props.auditStatus === 0){
        //     this.setState({
        //         needRemark:true
        //     });
        // }
        let formValue = this.props.form.getFieldsValue();
        this.setState({
            needRemark:formValue.auditStatus === 0 ? true : false
        })
    }
    auditStatusChange(e){
        this.setState({
            needRemark:e.target.value === 0 ? true : false
        })
    }
}
const RoadshowModalForm = Form.create({})(ModalForm);
export default RoadshowModalForm;