import {Modal,message,Spin} from 'antd';
import React,{Component} from 'react';
import RoadshowModalForm from './RoadshowModalForm';
import ReactHtmlParser from 'react-html-parser';
import api from '../../utils/api';
import videojs from 'video.js';
import 'video.js/dist/video-js.css'

class RoadshowModal extends Component{
    render(){
        let {openStatus} = this.props;
        let {
            loading,
            auditInfo,
            companyTitle
        } = this.state;
        return (
            <Modal
                className="roadshow-modal"
                visible={openStatus} 
                // style={{top:'50%'}}
                wrapClassName="roadshow-modal-container"
                onCancel={this.cancelAudit}
                onOk={this.submitAudit}
                title="审核路演"
                >
                <Spin spinning={loading}>
                    <div className="video-container">
                        {openStatus?
                        <div data-vjs-player>
                        <video ref={ this.getVideoNode} className="video-js"></video>
                        </div>
                        :''}
                    </div>
                    <div className="audit-info-container">
                        <div className="audit-info">
                           
                            {
                                auditInfo.map(item=>{
                                    return item.col === 6? (
                                        <div className="audit-item" key={item.name}>
                                            <span className="audit-label">
                                                {item.label}:
                                            </span>
                                            <div className="content" title={item.name ==="companyShortName"? companyTitle:""}>
                                                {item.value||"--"}
                                            </div>
                                        </div>)
                                        :(
                                        <div className="summary-row audit-item" key={item.name}>
                                                <span className="audit-label">
                                                    {item.label}:
                                                </span>
                                            <div title={item.name ==="companyShortName"? companyTitle:""}>
                                                {ReactHtmlParser(item.value||"--")}
                                            </div>
                                        </div>)
                                })
                            }
                        </div>
                        <RoadshowModalForm
                        wrappedComponentRef={this.getFormRef}
                        />
                    </div>
                </Spin>
            </Modal>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            companyTitle:'',
            auditData:'',
            loading:true,
            auditInfo:[],
            videoOptions:{
                autoplay:false,
                controls:true,
                sources:[],
            },
            preOpenStatus:false,
        }
        this.submitAudit = this.submitAudit.bind(this);
        this.cancelAudit = this.cancelAudit.bind(this);
        this.getFormRef = this.getFormRef.bind(this);
        this.getAuditData = this.getAuditData.bind(this);
        this.getVideoNode = this.getVideoNode.bind(this);
        this.setModalValues = this.setModalValues.bind(this);
    }
    componentWillReceiveProps(props){
        if(props.openStatus === true && props.openStatus !== this.state.preOpenStatus){
            this.setState({
                auditId:props.auditId,
                loading:true,
                preOpenStatus:true
            },()=>{
                this.getAuditData();
            })
        }
    }
    componentDidMount(){
    }
    componentWillUnmount(){
        // 卸载player
        if(this.player){
            this.player.dispose();
        }
    } 

    // 获取审核数据
    getAuditData(){
        
        api.get(`roadshow/${this.state.auditId}`).then(res=>{
            let auditInfoArr = this.getAuditInfo(res.data);
            let url = (process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'test')
            ? 'http://static-test.simuwang.com'
            : 'http://static.simuwang.com';

            console.log(url)
            if(res.code === 20000){
                this.setState({
                    auditData:res.data,
                    companyTitle:res.data["companyName"],
                    auditInfo:auditInfoArr,
                    videoOptions:Object.assign({},this.state.videoOptions,{
                        sources:[{src:`${url}${res.data.tempLinkPath}`}]
                    })
                },this.setModalValues);
            }
            this.setState({loading:false})
        })
    }
    getAuditInfo(resData){
        let auditInfoArr = [
            {
                name:'topic',
                label:'路演名称',
                col:6
            },
            {
                name:'subject',
                label:'路演主题',
                col:6
            },
            {
                name:'roadshowType',
                label:'路演类型',
                col:6,
                render: (value) => {
                    let map = {
                        1: '上市公司',
                        2: '机构观点',
                        3: '私募基金'
                    }
                    return map[value];
                } 
            },
            {
                name:'companyShortName',
                label:'上传机构',
                col:6
            },
            {
                name:'uploadDate',
                label:'上传时间',
                col:6
            },
            {
                name:'uploadUser',
                label:'上传者',
                col:6
            },
            {
                name:'contactNumber',
                label:'联系电话',
                col:6
            },
            {
                name:'speakerName',
                label:'主讲人',
                col:6
            },
            {
                name:'personSummary',
                label:'主讲人介绍',
                col:12
            },
            {
                name:'summary',
                label:'路演介绍',
                col:12
            },
        ];
        auditInfoArr = auditInfoArr.map((item)=>{
            item['value'] = (item.render && item.render instanceof Function) ? item.render(resData[item.name]) : resData[item.name];
            return item;
        })

        return auditInfoArr;
    }
    // 提交审核
    submitAudit(){
        this.form.validateFields((err,value)=>{
            let params = Object.assign({},{
                status:value.auditStatus === 0 ? 3 : 4,
            },value)
            // antd的bug，有必填项未填的时候，err有时候为null，需要手动触发验证错误
            if(value.auditRemark === '' && value.auditStatus === 0){
                this.form.setFields({
                    auditRemark:{
                        errors:[new Error('请输入审核备注')]
                    }
                })
                return;
            }
            if(!err){
                api.put(`/roadshow/auditing/${this.state.auditData.id}`,params).then(res=>{
                    // console.log(res)
                    if(res.code === 20000){
                        message.success('审核成功！');
                        this.props.getRoadshowTableData();

                    }else{
                        message.error(res.msg)
                    }
                })
                this.cancelAudit();
            }
        })
    }
    // 取消审核
    cancelAudit(){
        this.props.closeAuditModal();
        this.form.resetFields();
        this.setState({
            preOpenStatus:false
        })
    }
    // 打开modal时给form赋值，注册video
    setModalValues(){
        // 注册video
        if(this.state.auditData.tempLinkPath){
            this.player = videojs(this.videoNode,this.state.videoOptions,()=>{
                // console.log('onPlayerReady')
                // 回调
            })
        }
        // 给form赋值
        this.form.setFieldsValue({
            auditStatus:this.state.auditData.auditStatus,
            auditRemark:this.state.auditData.auditRemark,
            paramQueryId:this.state.auditData.paramQueryId
        })
    }
    // 获取表单ref
    getFormRef(formRef){
        if(formRef){
            this.form = formRef.props.form;
        }
    }
    // 获取video ref
    getVideoNode(node){
        this.videoNode = node;
    }
}
export default RoadshowModal;