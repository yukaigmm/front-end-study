import {Table,Button,Pagination,message,Select,Modal} from 'antd';
import React,{Component} from 'react';
import RoadshowModal from './RoadshowModal';
import RoadshowSearchForm from './RoadshowSearchForm';
import api from '../../utils/api';
import './Roadshow.less';
// import {observer,inject} from 'mobx-react';
const Option = Select.Option;
const confirm = Modal.confirm;
// @inject('optionStore')
// @observer
class Roadshow extends Component{
    render(){
        let {
            dataSource,
            roadshowColumns,
            roadshowModalOpenStatus,
            tableParams,
            total,
            rowData,
            tableLoading,
            tableHeight,
            tableScroll
        } = this.state;
        return (
            <div className="content-container roadshow-content">
                <div className="roadshow-table-container">
                    <div className="keyword-search-area">
                        <RoadshowSearchForm
                        wrappedComponentRef={this.getFormRef}
                        searchRoadshow={this.searchRoadshow}
                        />
                        <Button onClick={this.searchRoadshow} type="primary" className="keyword-button">搜索</Button>
                    </div>
                    <div className="table-container">
                        <Table
                        bordered
                        size="small"
                        dataSource={dataSource}
                        loading={tableLoading}
                        columns={roadshowColumns}
                        rowKey={(record) => {return record.id}}
                        pagination={false}
                        scroll={{y:tableScroll ? tableHeight :false,x:1200}}
                        ></Table>
                        <Pagination size="small" showSizeChanger showQuickJumper onChange={this.pageChange} onShowSizeChange={this.pageSizeChange} total={total} current={tableParams.pageNo} pageSize={tableParams.pageSize}/>
                        <div className="roadshow-modal-conainer">
                            <RoadshowModal
                            openStatus={roadshowModalOpenStatus}
                            auditId={rowData.id}
                            closeAuditModal={this.closeAuditModal}
                            getRoadshowTableData={this.getRoadshowTableData}
                            />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            // 路演table
            dataSource:[],
            roadshowColumns:[
                {
                    title:'路演名称',
                    dataIndex:'topic',
                    key:'topic',
                },
                {
                    title:'机构',
                    dataIndex:'companyShortName',
                    key:'roadshowCompanyShortName',
                    width: 100
                },
                {
                    title:'路演主题',
                    dataIndex:'subject',
                    key:'subject',
                    width: 200
                },
                {
                    title:'路演类型',
                    dataIndex:'roadshowType',
                    key:'roadshowType',
                    width: 140,
                    render: (text, row, index) => {
                        let map = {
                            1: '上市公司',
                            2: '机构观点',
                            3: '私募基金'
                        }
                        return (
                            <span>{map[row.roadshowType]}</span>
                        )
                    }
                },
                {
                    title:'主讲人',
                    dataIndex:'speakerName',
                    key:'speakerName',
                    width: 100
                },
                {
                    title:'上传者',
                    dataIndex:'uploadUser',
                    key:'uploadUser',
                    width: 100,
                    render:(text,row,index) =>{
                        return (
                            <React.Fragment>
                                {row.uploadUser||'--'}
                            </React.Fragment>
                        )
                    }
                },
                {
                    title:'联系电话',
                    dataIndex:'contactNumber',
                    key:'contactNumber',
                    width: 120,
                    render:(text,row,index) =>{
                        return (
                            <React.Fragment>
                                {row.contactNumber||'--'}
                            </React.Fragment>
                        )
                    }
                },
                {
                    title:'上传日期',
                    dataIndex:'uploadDate',
                    key:'uploadDate',
                    width: 100
                },
                // {
                //     title:'状态设置',
                //     dataIndex:'status',
                //     key:'setStatus',
                //     width: 110,
                //     render:(text,row,index)=>{
                //         let options = [
                //             {
                //                 label:'下架',
                //                 value:5
                //             }
                //             // {
                //             //     label:'发布',
                //             //     value:2
                //             // }
                //         ]
                //         return (
                //             <Select defaultValue={text== 5?text:'请选择'} onChange={this.setRoadshowStatus.bind(this,row)}>
                //                 {options.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                //             </Select>
                //         )
                //     }
                // },
                {
                    title:'当前状态',
                    dataIndex:'status',
                    key:'status',
                    width: 150,
                    render:(text,row,index)=>{
                        let map = {
                            1:'待审核',
                            2:'审核中',
                            3:'审核不通过',
                            4:'已审核',
                            5:'客户要求下架',
                            6:'合规问题下架',
                            7:'已上架',
                        }
                        let iconMap = {

                            1:'icon-clock color-yellow',
                            2:'icon-clock color-yellow',
                            4:'icon-gou color-blue',
                            7:'icon-cloud color-blue',
                            3:'icon-error color-warn',
                            5:'icon-cloud color-default',
                            6:'icon-cloud color-default',
                        }
                        if(iconMap[text]){
                            return (
                                <div>
                                    <span className={'iconfont ' +iconMap[text]}></span>
                                    {map[text]}
                                </div>
                            );
                        }
                        return (
                            <div className='normal-status'>{map[text]}</div>
                        )
                    }
                },
                {
                    title:'操作',
                    dataIndex:'action',
                    // fixed:'right',
                    key:'roadshowAction',
                    width: 200,
                    render:(text,row,index)=>{
                        return (
                            <div>
                                {/* disabled={['7','4'].includes(row.status+'')} */}
                                <Button type="primary"  className="action-button" size="small" onClick={this.auditRoadshow.bind(this,row)}>审核</Button>
                                <Button type="primary" disabled={['5','6','7'].includes(row.status+'')} className="action-button" size="small" onClick={this.downloadRoadshow.bind(this,row)}>下载</Button>
                                <Button type="primary" disabled={['1','2','3'].includes(row.status+'')} size="small" onClick={this.showConfirm.bind(this,row)}>{''+row.status === '7' ? '下架' : '上架'}</Button>
                            </div>

                        )
                    }
                },
            
            
            ],
            tableParams:{
                keyWord:'',
                auditStatus:0,
                subject:0,
                pageNo:1,
                pageSize:10,
            },
            total:1,
            tableLoading:false,
            tableHeight:0,
            tableScroll:false,
            // 审核modal
            roadshowModalOpenStatus:false,
            rowData:{},
        };
        this.auditRoadshow = this.auditRoadshow.bind(this);
        this.closeAuditModal = this.closeAuditModal.bind(this);
        this.pageSizeChange = this.pageSizeChange.bind(this);
        this.pageChange = this.pageChange.bind(this);
        this.getFormRef = this.getFormRef.bind(this);
        this.searchRoadshow = this.searchRoadshow.bind(this);
        this.getRoadshowTableData = this.getRoadshowTableData.bind(this);
        this.setRoadshowStatus = this.setRoadshowStatus.bind(this);
        this.setTableHeight = this.setTableHeight.bind(this);
    }
    componentWillMount(){
        this.getRoadshowTableData();
    };
    componentDidMount(){
        this.setTableHeight();
        window.addEventListener('resize',this.setTableHeight);
    }
    componentWillUnmount(){
        window.removeEventListener('resize',this.setTableHeight)
    }
    // 获取tableData
    getRoadshowTableData(){
        this.setState({tableLoading:true})
        api.get('roadshow',this.state.tableParams).then(res=>{
            if(res.code === 20000){
                this.setState({
                    dataSource:res.data.records,
                    total:res.data.total,
                    tableLoading:false
                },
                ()=>{
                    this.setTableHeight()
                }
            )
            }else{
                this.setState({
                    tableLoading:false
                })
            }
        })
    }
    // 根据搜索条件获取tableData
    searchRoadshow(){
        let formValue = this.form.getFieldsValue();
        this.setState({
            tableParams:Object.assign({},this.state.tableParams,formValue,{
                pageNo:1,
                pageSize:10
            })
        },()=>{
            console.log(this.state.tableParams)
            this.getRoadshowTableData()
        })

    }
    // 切换路演状态
    setRoadshowStatus(row,value){
        if(value === 5){
            this.setRoadshowOff(row.id).then(res=>{
                this.getRoadshowTableData();
            })
        }
    }
    // 设置路演下架
    showConfirm(row) {
        let _this = this;
        if(row.status+'' === '7'){
            confirm({
              title: `确认下架"${row.topic}"吗`,
              content: '下架后将不在路演中心显示',
              onOk() {
                _this.setRoadshowOff(row.id).then(res=>{
                    _this.getRoadshowTableData();
                })
              },
              onCancel() {
                console.log('Cancel');
              },
            });
        }else{
            confirm({
                title: `确认上架"${row.topic}"吗`,
                content: '上架后将在路演中心显示',
                onOk() {
                  _this.setRoadshowOn(row.id).then(res=>{
                      _this.getRoadshowTableData();
                  })
                },
                onCancel() {
                  console.log('Cancel');
                },
              });
        }
      }
    setRoadshowOff(id){
        return new Promise((resolve,reject)=>{
            api.put(`roadshow/auditing/${id}`,{status:5,auditStatus:-1}).then(res=>{
                if(res.code === 20000){
                    message.success('下架路演成功！');
                    resolve();
                }else{
                    message.error(res.msg);
                    reject();
                }
            })
        })
    }
    setRoadshowOn(id){
        return new Promise((resolve,reject)=>{
            api.put(`roadshow/auditing/${id}`,{status:7,auditStatus:-1}).then(res=>{
                if(res.code === 20000){
                    message.success('上架路演成功！');
                    resolve();
                }else{
                    message.error(res.msg);
                    reject();
                }
            })
        })
    }
    // 打开审核modal
    auditRoadshow(row){
        // console.log(this.props.optionStore.fmAdminOptions)
        let params = {
            auditStatus: -1,
            status: ''+row.status === '1' ? 2 : row.status
        }
        api.put(`roadshow/auditing/${row.id}`,params).then(res=>{
            if(res.code === 20000){
                this.setState({
                    roadshowModalOpenStatus:true,
                    rowData:row
                })
            }else{
                message.error(res.msg);
            }
        })
    }
    closeAuditModal(){
        this.setState({
            roadshowModalOpenStatus:false
        })
    }
    // 下载路演视频
    downloadRoadshow(row){
        let params = {
            auditStatus:-1,
            status:2
        }
        if(row.tempLinkPath && row.videoName){
            let url =  (process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'test')
            ? 'http://fmadmin-test.smppw.com'
            : 'http://fmadmin.simuwang.com';
            api.put(`roadshow/auditing/${row.id}`,params).then(res=>{
                if(res.code ===20000){
                    window.location.assign(`${url}/api/common/download?filePath=${row.tempLinkPath}&fileName=${row.videoName}`);
                }
            })
        }else{
            message.error('找不到路演视频资源');
        }
    }
    // 分页变化
    pageChange(page,pageSize){
        this.setState(
            {tableParams:{...this.state.tableParams,pageNo:page}},
            ()=>{
                this.getRoadshowTableData();
            }
        )
    }
    pageSizeChange(page,pageSize){
        this.setState(
            {tableParams:{...this.state.tableParams,pageSize,pageNo:1}},
            ()=>{
                this.getRoadshowTableData();
            }
        )
    }
    // 获取搜索表单的ref
    getFormRef(formRef){
        if(formRef){
            this.form = formRef.props.form;
        }

    }
    // 设置表格自适应高度
    setTableHeight(){
        if(this.roadshowTimer){
            clearTimeout(this.roadshowTimer);
        }
        let tableHeight;
        let _this = this;
        // let tableInnerHeight = document.querySelector('.ant-table-body .ant-table-fixed').offsetHeight;
        this.roadshowTimer = setTimeout(() => {
            // 设置table滚动高度
            if(document.querySelector('.roadshow-table-container')){
                tableHeight = document.querySelector('.roadshow-table-container').offsetHeight - 140;
            }
            if(document.querySelector('.ant-table-body .ant-table-tbody').offsetHeight - tableHeight + 20 < 0){
                _this.setState({
                    tableScroll:false
                })
            }else{
                _this.setState({
                    tableScroll:true
                })
            }
            _this.setState({tableHeight:tableHeight})
        }, 100);
    }
}
export default Roadshow;