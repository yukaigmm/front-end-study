import React,{Component} from 'react';
import {Form,Select,Input} from 'antd';
const FormItem = Form.Item;
const Option = Select.Option;

class FormSearch extends Component{
    render(){
        const {getFieldDecorator} = this.props.form;
        let {
            auditStatusOption,
            // auditSubjectOption
        } = this.state;
        return (
            <Form layout="inline">
                <FormItem>
                    {
                        getFieldDecorator('status',{
                            initialValue:0
                        })(<Select size="small" style={{width: 120}} onChange={this.optionsChange.bind(this)}>
                            {auditStatusOption.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                            </Select>)
                    }
                </FormItem>
                {/* <FormItem>
                    {
                        getFieldDecorator('subject',{
                            initialValue:'春瑜会客厅'
                        })(<Select style={{width: 120}} onChange={this.optionsChange.bind(this)}>
                            {auditSubjectOption.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                            </Select>)
                    }
                </FormItem> */}
                <FormItem>
                    {
                        getFieldDecorator('keyWord',{
                        })(<Input className="search-input" placeholder="请输入关键字"/>)
                    }
                </FormItem>
            </Form>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            auditStatusOption:[
                {
                    label:'全部',
                    value: 0
                  },
                  {
                    label: "待审核",
                    value: 1
                  },
                  {
                    label: "审核中",
                    value: 2
                  },
                  {
                    label: "审核不通过",
                    value: 3
                  },
                  {
                    label: "已审核",
                    value: 4
                  },
                  {
                    label: "客户要求下架",
                    value: 5
                  },
                  {
                    label: "合规问题下架",
                    value: 6
                  },
                  {
                      label:'已上架',
                      value:7
                  }
            ],
            auditSubjectOption:[
                {
                    label: '春瑜会客厅',
                    value: '春瑜会客厅',
                },
                {
                    label: '透过榜单看私募',
                    value: '透过榜单看私募',
                },
                {
                    label: '王牌学院',
                    value: '王牌学院',
                },
                {
                    label: '看财经',
                    value: '看财经',
                },
                {
                    label: '新浪网红财经大赛',
                    value: '新浪网红财经大赛',
                },
                {
                    label: '股灾专题',
                    value: '股灾专题',
                },
                {
                    label: 'CTA',
                    value: 'CTA',
                },
                {
                    label: '大讲堂系列',
                    value: '大讲堂系列',
                },
                {
                    label: '策略报告',
                    value: '策略报告',
                },
                {
                    label: '股票',
                    value: '股票',
                },
                {
                    label: '期货',
                    value: '期货',
                },
                {
                    label: '宏观对冲',
                    value: '宏观对冲',
                },
                {
                    label: '股权',
                    value: '股权',
                },
                {
                    label: '海外',
                    value: '海外',
                },
                {
                    label: '固收',
                    value: '固收',
                },
                {
                    label: '债券',
                    value: '债券',
                },
                {
                    label: '复合策略',
                    value: '复合策略',
                },
                {
                    label: '价值投资',
                    value: '价值投资',
                },
                {
                    label: 'alpha策略',
                    value: 'alpha策略',
                },
                {
                    label: '套利',
                    value: '套利',
                },
                {
                    label: '定增',
                    value: '定增',
                },
                {
                    label: '新三板',
                    value: '新三板',
                },
                {
                    label: 'FOF',
                    value: 'FOF',
                },
                {
                    label: '量化',
                    value: '量化',
                },
                {
                    label: '相对价值',
                    value: '相对价值',
                },
                {
                    label: '网下打新',
                    value: '网下打新',
                },
                {
                    label: '2016私募冠军',
                    value: '2016私募冠军',
                }
            
            ]
        }
    }
    optionsChange(value){
        let _this = this;
        // 需要异步获取，否则获取的是上一步的formValue
        setTimeout(() => {
            _this.props.searchRoadshow();
        }, 100);
    }
}
const RoadshowSearchForm = Form.create({})(FormSearch);
export default RoadshowSearchForm;