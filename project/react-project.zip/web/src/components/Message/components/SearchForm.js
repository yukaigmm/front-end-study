import React,{Component} from 'react';
import {Form,Select,Input} from 'antd';
const FormItem = Form.Item;
const Option = Select.Option;

class InnerForm extends Component{
    constructor(props){
        super(props);
        this.state = {
            noticeTypeOptions: [
                { label:"全部", value: 0 },
                { label:"首页通知", value: 1},
            ],
            noticeStatusOptions: [
                { label:"全部", value: 0 },
                { label:"正常", value: 1 },
                { label:"作废", value: 2 },
            ],
        }
    }
    search = () => {
        console.log("change")
        setTimeout(() => {
            this.props.search();
        }, 100);
    }
    render(){
        const {getFieldDecorator} = this.props.form;
        let {noticeStatusOptions, noticeTypeOptions} = this.state;
        return (
            <div className="search-form-container">
                <Form layout="inline">
                    <FormItem>
                        {
                            getFieldDecorator('noticeType',{
                                initialValue:1
                            })(<Select size="small" style={{width: 120}} onChange={this.search}>
                                {noticeTypeOptions.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                                </Select>)
                        }
                    </FormItem>
                    <FormItem>
                        {
                            getFieldDecorator('noticeStatus',{
                                initialValue:1
                            })(<Select size="small" style={{width: 120}} onChange={this.search}>
                                {noticeStatusOptions.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                                </Select>)
                        }
                    </FormItem>
                    <FormItem>
                        {
                            getFieldDecorator('keyWord',{
                            })(<Input className="search-input" placeholder="请输入关键字"/>)
                        }
                    </FormItem>
                </Form>
            </div>
        )
    }
}
const SearchForm = Form.create({})(InnerForm);
export default SearchForm;