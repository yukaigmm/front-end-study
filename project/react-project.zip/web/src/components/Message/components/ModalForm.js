import React,{Component} from 'react';
import {Form,Select,Input,Row,Col,DatePicker} from 'antd';
import api from "../../../utils/api.js";
import moment from "moment";
const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
class InnerForm extends Component{
    constructor(props){
        super(props);
        this.state = {
            noticeTypeOptions: [
                { label:"全部", value: 0 },
                { label:"首页通知", value: 1},
            ],
            noticeStatusOptions: [
                { label:"全部", value: 0 },
                { label:"正常", value: 1 },
                { label:"作废", value: 2 },
            ],
            triggerTypeOptions: [
                {label: "净值异常", value: 101},
                {label: "净值缺失", value: 102},
                {label: "基金缺失", value: 103},
                {label: "经理缺失", value: 104},
                {label: "公司缺失", value: 105},
                {label: "授权申请", value: 106},
                {label: "新活动", value: 201},
                {label: "活动参加", value: 202},
                {label: "机会回复", value: 301},
                {label: "尽调预约", value: 302},
            ],
            remindCycleOptions: [
                {label: "日", value: 1},
                {label: "周", value: 2},
                {label: "月", value: 3},
                {label: "季度", value: 4},
                {label: "年", value: 5},
            ],
            orgOptions: [],
            searchOrgLoading: false,
            currentOrgIds: [],
            userOptions: [],
            currentUserIds: []
        }
    }
    componentWillReceiveProps(props, oldProps){
        if(props.orgOptions && props.orgOptions.length && !this.state.orgOptions.length){
            this.setState({
                orgOptions: props.orgOptions
            })
        }
        if(props.openStatus === false){
            console.log("close")
            this.setState({
                orgOptions: [],
                currentOrgIds: [],
                userOptions: [],
                currentUserIds: []
            })
        }
    }
    // 模糊搜索机构
    searchOrg = (keyWord) => {
        if(this.searchOrgTimer){
            clearTimeout(this.searchOrgTimer);
        }
        this.searchOrgTimer = setTimeout(() => {
            this.setState({
                searchOrgLoading: true
            })
            api.get("master/org",{keyWord}).then((res) => {
                this.setState({
                    searchOrgLoading: false
                })
                if(res && res.code === 20000){
                    this.setState({
                        orgOptions: res.data.records.map((item) => {
                            return {
                                label: item.orgName,
                                value: item.orgId
                            }
                        }),
                    })
                }
            })
        }, 500);
    }
    // 
    selectOrg = (value) => {
        this.setState({
            currentOrgIds: [...this.state.currentOrgIds,value]
        })
    }
    delOrg = (value) => {
        let currentOrgIds = JSON.parse(JSON.stringify(this.state.currentOrgIds));
        currentOrgIds = currentOrgIds.filter((orgId) => {
            return orgId !== value;
        });
        this.setState({currentOrgIds})
    }
    searchUser = (value) => {
        if(this.searchUserTimer){
            clearTimeout(this.searchUserTimer);
        }
        this.searchUserTimer = setTimeout(() => {
            api.get("master/user", {
                orgIds: this.state.currentOrgIds,
                keyWord: value
            }).then((res) => {
                if(res && res.code === 20000){
                    let userOptions = res.data.records.map((item) => {
                        return {
                            label: item.realName,
                            value: item.userId
                        }
                    })
                    this.setState({
                        userOptions
                    })
                }
            })
        }, 500);
    }
    selectUser = (value) => {
        this.setState({
            currentUserIds: [...this.state.currentUserIds, value]
        })
    }
    delUser = (value) => {
        let currentUserIds = JSON.parse(JSON.stringify(this.state.currentUserIds));
        currentUserIds = currentUserIds.filter((userId) => {
            return userId !== value;
        });
        this.setState({
            currentUserIds
        }, () => {
            console.log(this.state.currentUserIds)
        })
    }
    render(){
        const {getFieldDecorator} = this.props.form;
        let {
            noticeStatusOptions, 
            noticeTypeOptions,
            triggerTypeOptions,
            remindCycleOptions,
            orgOptions,
            searchOrgLoading,
            userOptions
        } = this.state;
        return (
            <div className="modal-form-container">
                <Form layout="inline">
                    <Row>
                        <Col span={24}>
                            <FormItem label="消息标题">
                                {getFieldDecorator('noticeName',{
                                    rules:[
                                        {required:true,message:'请填写消息标题'}
                                    ]
                                })(<Input/>)}
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={24}>
                            <FormItem label="消息内容">
                                {getFieldDecorator('noticeInfo')(<TextArea rows={4}/>)}
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={8}>
                            <FormItem label="消息类型">
                                {
                                    getFieldDecorator('noticeType')(
                                        <Select>
                                            {noticeTypeOptions.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                                        </Select>)
                                }
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem label="消息状态">
                                {
                                    getFieldDecorator('noticeStatus')(
                                        <Select>
                                            {noticeStatusOptions.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                                        </Select>)
                                }
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={24}>
                            <FormItem label="消息链接">
                                {getFieldDecorator('noticeLink')(<Input/>)}
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={24}>
                            <FormItem label="触发逻辑">
                                {getFieldDecorator('triggerLogic')(<TextArea rows={4}/>)}
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={8}>
                            <FormItem label="触发类型">
                                {
                                    getFieldDecorator('triggerType')(
                                        <Select>
                                            {triggerTypeOptions.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                                        </Select>
                                    )
                                }
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem label="通知周期">
                                {
                                    getFieldDecorator('remindCycle')(
                                        <Select>
                                            {remindCycleOptions.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                                        </Select>
                                    )
                                }
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem label="通知节点">
                                {
                                    getFieldDecorator('remindNode')(<Input/>)
                                }
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={24}>
                            <FormItem label="通知机构">
                                {
                                    getFieldDecorator('orgIds')(
                                        <Select
                                            showSearch
                                            placeholder="请输入关键字"
                                            defaultActiveFirstOption={false}
                                            showArrow={false}
                                            filterOption={false}
                                            onSearch={this.searchOrg}
                                            onSelect={this.selectOrg}
                                            onDeselect={this.delOrg}
                                            mode="multiple"
                                        >
                                            {orgOptions.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                                        </Select>
                                    )
                                }
                            </FormItem>
                        </Col>
                    </Row>
                    {/* <Row>
                        <Col span={24}>
                            <FormItem label="通知人员">
                                {
                                    getFieldDecorator('userIds')(
                                        <Select
                                            showSearch
                                            placeholder="请输入关键字"
                                            mode="multiple"
                                            defaultActiveFirstOption={false}
                                            showArrow={false}
                                            filterOption={false}
                                            onSearch={this.searchUser}
                                            onSelect={this.selectUser}
                                            onDeselect={this.delUser}
                                            // onChange={this.orgChange}
                                        >
                                            {userOptions.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                                        </Select>
                                    )
                                }
                            </FormItem>
                        </Col>
                    </Row> */}
                    <Row>
                        <Col span={12}>
                            <FormItem label="开始时间">
                                {
                                    getFieldDecorator('beginDate')(<DatePicker/>)
                                }
                            </FormItem>
                        </Col>
                        <Col span={12}>
                            <FormItem label="结束时间">
                                {
                                    getFieldDecorator('endDate')(<DatePicker/>)
                                }
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={24}>
                            <FormItem label="备注">
                                {getFieldDecorator('remark')(<TextArea rows={4}/>)}
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
            </div>
        )
    }
}
const SearchForm = Form.create({})(InnerForm);
export default SearchForm;