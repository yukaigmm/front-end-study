import {Modal,message,Spin} from 'antd';
import React,{Component} from 'react';
import ModalForm from './ModalForm.js';
import api from '../../../utils/api';
import moment from "moment"

class NoticeModal extends Component{
    
    constructor(props){
        super(props);
        this.state = {
            loading: false,
            orgOptions: [],
        }
    }
    componentWillReceiveProps = (props) =>{
        if(props.openStatus){
            if(props.status === "add"){
            }
            if(props.status === "edit"){
               this.getMessageData(props.id)
            }
        }
    }
    getMessageData = (id) => {
        this.setState({
            loading: true
        })
        api.get("notice/"+id).then((res) => {
            this.setState({
                loading: false
            })
            if(res && res.code === 20000){
                let data = JSON.parse(JSON.stringify(res.data));
                this.setFormData(data);
            }else{
                message.error(res.msg);
            }
        })
    }
    // 处理formData
    setFormData = (data) => {
        if(!data.orgIds){
            delete data.orgIds;
        }
        data.triggerLogic = typeof data.triggerLogic == "object" ? JSON.stringify (data.triggerLogic) : "";
        data.beginDate = data.beginDate ? moment(data.beginDate) : null;
        data.endDate = data.endDate ? moment(data.endDate) : null;
        let {
            noticeName,
            noticeType,
            noticeStatus,
            noticeInfo,
            noticeLink,
            triggerLogic,
            triggerType,
            remindCycle,
            remindNode,
            orgIds,
            userIds,
            priority,
            beginDate,
            endDate,
            remark
        } = data;
        this.form.setFieldsValue({
            noticeName,
            noticeType,
            noticeStatus,
            noticeInfo,
            noticeLink,
            triggerLogic,
            triggerType,
            remindCycle,
            remindNode,
            orgIds,
            userIds,
            priority,
            beginDate,
            endDate,
            remark
        });
        let orgOptions = data.orgInfo.map((item) => {
            return {
                label: item.orgName,
                value: item.orgId
            }
        })
        this.setState({orgOptions})
    }
    submit = () => {
        let submitData = this.getSubmitData();
        console.log(submitData);
        this.form.validateFields((error,value) => {
            if(error === null){
                this.setState({
                    loading: true
                })
                let url, method;
                if(this.props.status === "add"){
                    url = "notice";
                    method = "post";
                }else if(this.props.status === "edit"){
                    url = "notice/"+this.props.id;
                    method = "put";
                }
                api[method](url, submitData).then((res) => {
                    this.setState({
                        loading: false
                    })
                    if(res && res.code === 20000){
                        message.success("提交成功")
                        this.cancel();
                        this.props.getTableData()
                    }else{
                        message.error(res.msg ? res.msg : "提交失败，请重试或联系管理员");
                    }
                }, () => {
                    this.setState({
                        loading: false
                    })
                })
            }else{
                message.error("请按照提示填写必填内容");
            }
        })
    }
    // 接口要求：字段没有值的时候，要么不传该字段，要么传 null
    getSubmitData = () => {
        let data = this.form.getFieldsValue();
        
        let {beginDate, endDate} = data;
        beginDate = beginDate ? beginDate.format("YYYY-MM-DD") : null;
        endDate = endDate ? endDate.format("YYYY-MM-DD") : null;
        if(data.triggerLogic){
            data.triggerLogic = JSON.parse(data.triggerLogic)
        }
        for(let key in data){
            if(data[key] === undefined){
                delete data[key];
            }
        }
        return Object.assign({}, data, {
            beginDate, endDate
        })
    }
    // 取消审核
    cancel = () => {
        this.form.resetFields();
        this.props.closeModal();
        this.setState({orgOptions:[]})
    }
    // 获取表单ref
    getFormRef = (formRef) => {
        if(formRef){
            this.form = formRef.props.form;
        }
    }
    render(){
        let {openStatus, status} = this.props;
        let {
            loading,
            orgOptions
        } = this.state;
        return (
            <Modal
                className="add-edit-modal"
                width={800}
                visible={openStatus} 
                wrapClassName="add-edit-modal-container"
                onCancel={this.cancel}
                onOk={this.submit}
                title={status === "add" ? "新增通知" : "修改通知"}
                >
                <Spin spinning={loading}>
                    <ModalForm 
                    wrappedComponentRef={this.getFormRef}
                    openStatus={openStatus}
                    orgOptions={orgOptions}
                    />
                </Spin>
            </Modal>
        )
    }
}
export default NoticeModal;