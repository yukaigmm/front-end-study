import React,{Component} from 'react';
import {Button, message, Modal} from "antd";
import api from "../../utils/api.js";
import getConfig  from "./config.js";
import SearchForm from "./components/SearchForm.js";
import Table from "../../common/Table.js";
import AddEditModal from "./components/AddEditModal.js";
class Message extends Component{
    constructor(props){
        super(props);
        const config = getConfig.call(this);
        this.state = {
            tableData: [],
            columns: config.columns,
            total: 0,
            pageNo: 1,
            pageSize: 10,
            openStatus: false,
            modalStatus: "add",
            currentNoticeId: ""
        };
    }
    componentWillMount(){
        // this.getTableData();
    }
    componentDidMount(){
        this.getTableData();
    }
    // 获取 tableData
    getTableData = () => {
        let formValue = this.form.getFieldsValue();
        let {pageNo, pageSize} = this.state;
        let params = Object.assign({}, formValue, {
            pageNo,
            pageSize
        })
        api.get("notice", params).then((res) => {
            if(res && res.code === 20000){
                let data = res.data;
                this.setState({
                    tableData: data.records,
                    total: data.total
                })
            }else{
                let msg = res.msg ? res.msg : "数据加载失败，请重试或联系管理员";
                message.error(msg);
            }
        })
    }
    search = () => {
        this.setState({
            pageNo: 1,
            pageSize: 10
        }, () => {
            this.getTableData();
        })
    }
    pageChange = (pageNo, pageSize) => {
        this.setState({pageNo},() => {
            this.getTableData()
        })
    }
    pageSizeChange = (page, pageSize) => {
        this.setState({pageSize},() => {
            this.getTableData()
        })
    }
    // 新增 
    add = () => {
        console.log("add");
        this.setState({
            openStatus: true,
            modalStatus: "add"
        })
    }
    // 编辑 
    edit = (id) => {
        console.log("edit");
        this.setState({
            openStatus: true,
            modalStatus: "edit",
            currentNoticeId: id
        })
    }
    // 删除 
    del = (id) => {
        let that = this;
        Modal.confirm({
            cancelText: '取消',
            okText: '确定',
            title: '删除',
            content: '确定删除此条消息吗？',
            onOk() {
                return new Promise((resolve, reject) => {
                    api.del('notice', `${id}`)
                        .then(res => {
                            if (res.code === 20000) {
                                message.success('删除成功！');
                                that.getTableData();
                                resolve();
                            } else {
                                message.error('删除失败！');
                                resolve();
                            }
                        })

                })
            }
        })
    }
    getFormRef = (formRef) => {
        if(formRef){
            this.form = formRef.props.form;
        }
    }
    closeModal = () => {
        this.setState({
            openStatus: false
        })
    }
    render(){
        let {
            tableData,
            columns,
            total,
            pageNo,
            pageSize,
            openStatus,
            modalStatus,
            currentNoticeId
        } = this.state;
        return (
            <div className="content-container message-manager-container">
                <div className="head-container">
                    <SearchForm
                        wrappedComponentRef={this.getFormRef}
                        search={this.search}
                    />
                    <Button onClick={this.search} type="primary" className="search-button">搜索</Button>
                    <Button onClick={this.add} type="primary" className="add-button">添加</Button>
                </div>
                <div className="cotent-container">
                    <Table
                        tableData={tableData}
                        columns={columns}
                        rowKey={(record) => {return record.id}}
                        // scroll={{y:tableScroll ? tableHeight :false,x:1200}}
                        pageChange={this.pageChange}
                        pageSizeChange={this.pageSizeChange}
                        total={total}
                        page={pageNo}
                        pageSize={pageSize}
                    />
                </div>
                <AddEditModal 
                    openStatus={openStatus}
                    status={modalStatus}
                    id={currentNoticeId}
                    closeModal={this.closeModal}
                    getTableData={this.getTableData}
                />
            </div>
        )
    }
}
export default Message;