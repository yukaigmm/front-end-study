import React from 'react';
import {Button} from "antd";
function getConfig (){
    return {
        columns: [
            {
                title:'消息类别',
                dataIndex:'noticeType',
                key:'noticeType',
                width: 100,
                render: (text, row, index) => {
                    let map = {
                        1: "信披",
                        2: "活动",
                        3: "系统",
                    };
                    return (<div>{map[row.noticeType] || "--"}</div>)
                }
            },
            {
                title:'子类别',
                dataIndex:'triggerType',
                key:'triggerType',
                width: 100,
                render: (text, row, index) => {
                    let map = {
                        "101": "净值异常"
                    };
                    return (
                        <div>{map[row.triggerType] || "--"}</div>
                    )
                }
            },
            {
                title:'消息标题',
                dataIndex:'noticeName',
                key:'noticeName',
                width: 100
            },
            {
                title:'消息内容',
                dataIndex:'noticeInfo',
                key:'noticeInfo',
                width: 240
            },
            {
                title:'消息状态',
                dataIndex:'noticeStatus',
                key:'noticeStatus',
                width: 100,
                render: (text, row, index) => {
                    let map = {
                        1: "正常",
                        2: "废弃",
                    };
                    return (<div>{map[row.noticeStatus]|| "--"}</div>)
                }
            },
            {
                title:'消息来源',
                dataIndex:'triggerLogicType',
                key:'triggerLogicType',
                width: 100,
                render: (text, row, index) => {
                    let map = {
                        1: "系统触发",
                        2: "脚本触发",
                    };
                    return (<div>{map[row.triggerLogicType] || "--"}</div>)
                }
            },
            {
                title:'开始时间',
                dataIndex:'beginDate',
                key:'beginDate',
                width: 240,
            },
            {
                title:'结束时间',
                dataIndex:'endDate',
                key:'endDate',
                width: 240,
            },
            {
                title:'优先级',
                dataIndex:'priority',
                key:'priority',
                width: 80,
            },
            {
                title:'备注',
                dataIndex:'remark',
                key:'remark',
                width: 240,
            },
            {
                title:'操作',
                dataIndex:'action',
                key:'action',
                width: 240,
                render: (text, row, index) => {
                    return (
                        <div>
                            <Button onClick={() =>{this.edit(row.id)}} type="primary" className="edit-button">编辑</Button>
                            <Button onClick={() =>{this.del(row.id)}} type="primary" className="del-button">删除</Button>
                        </div>
                    )
                }
            },
        ]
    }
}
export default getConfig;