import {Form,Input,Radio,Upload,Button,Icon,message, Select} from 'antd';
import React,{Component} from 'react';
import api from '../../utils/api';

const Option = Select.Option;
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
class AddAccountForm extends Component{
   

    render(){
        const {getFieldDecorator} = this.props.form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 8 },
              },
              wrapperCol: {
                xs: { span: 24 },
                sm: { span: 16 },
              },
        }
        
        const uploadProps = {
            action:"api/common/upload",
            data:{fileType:"visitingCard"},
            accept:"image/*",
            onChange:(info)=>{
                   let fileList = info.fileList;
                   fileList = fileList.slice(-1);
                   this.setState({fileList})
                  
                   if(info.file.status==="done"){
                      if(info.file.response.code !==20000){
                          message.error(`上传失败:${info.file.response.msg}`);
                      }
                   }else if(info.file.status ==="error "){
                       message.error("上传失败！")
                   }
            }
        }

        return (
            <Form onSubmit={this.formSubmit} >
                <FormItem label="姓名" {...formItemLayout}>
                    {
                        getFieldDecorator('linkMan',{
                            rules:[
                                {required:true,message:'请输入姓名'}
                            ]
                        })(<Input onBlur={()=>{this.validateSigleField('linkMan')}}/>)
                    }
                </FormItem>
                <FormItem label="手机号码" {...formItemLayout}> 
            
                    {
                        getFieldDecorator('mobile',{
                            rules:[
                                {
                                    required:true,
                                    message:'请输入正确的手机号码',
                                    pattern:/^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/
                                }
                            ]
                        })(<Input onInput={this.checkAccountStatus}/>)
                    }
                </FormItem>

                <FormItem label="名片" {...formItemLayout}>
                    {
                        getFieldDecorator('visitingCardUrl',{
                            rules:[
                                {required:true,message:'请上传名片'},
                                {validator:(rule,value,callback)=>{
                                    let errors = [];
                                    if(value){
                                        let fileList = value.fileList;
                                        if(!fileList.length){
                                            errors.push("请上传名片");
                                        }
                                    }
                                    callback(errors);
                                }}
                               
                            ]
                        })(<Upload {...uploadProps} fileList={this.state.fileList}>
                            <Button>
                               <Icon type="upload" /> 
                                {this.state.fileList.length?"更换名片":"上传名片"}
                             </Button>
                        </Upload>)
                    }
                </FormItem>

                <FormItem label="初始密码" {...formItemLayout}>
                    {
                        getFieldDecorator('initPsw',{
                            rules:[
                                {
                                    required:['3','4'].includes(''+this.state.mobileStatus),
                                    message:'请输入初始密码',
                                },
                                {
                                    validator:(rule,value,callback)=>{
                                        let errors = [];
                                        if(value && value.trim().length < 6){
                                            errors.push(new Error('密码长度最少为6位'));
                                            // callback()
                                        }
                                        callback(errors);
                                    }
                                }
                            ]
                        })(<Input type={this.state.mobileStatus === 0 ? 'password' : 'text'} disabled={['0','1','2'].includes(''+this.state.mobileStatus)} title={this.state.passwordTitleMap[this.state.mobileStatus]}/>)
                    }
                </FormItem>
                <FormItem label="是否管理员" {...formItemLayout}>
                    {
                        getFieldDecorator('isAdmin',{
                            rules:[
                                {required:true,message:'请选择是否管理员'}
                            ]
                        })(<RadioGroup>
                            <Radio value={1}>是</Radio>
                            <Radio value={0}>否</Radio>
                            </RadioGroup>)
                    }
                </FormItem>
                <FormItem label="推荐人" {...formItemLayout}>
                   {
                       getFieldDecorator("recommenderId")(
                           <Select  >
                               {
                                   this.state.recommenderList.map(item=>{
                                       return( 
                                       <Option value={item.id} key={item.id}>
                                         {item.linkman || item.name}
                                      </Option>
                                      )
                                   })
                               }
                           </Select>
                       )
                   }
                </FormItem>
            </Form>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            mobileStatus:0,
            passwordTitleMap:{
                1:"该手机号已绑定官网账号，无需设置密码",
                2:"该手机号已绑定官网账号，无需设置密码",
                3:"",
                4:"",
                0:'请先输入手机号'
            },
            fileList:[],
            recommenderList:[]
        };
        this.checkAccountStatus = this.checkAccountStatus.bind(this)
        this.validateSigleField = this.validateSigleField.bind(this)
        this.resetDefaultFiles = this.resetDefaultFiles.bind(this)
        this.getRecommenderList  = this.getRecommenderList.bind(this)
    }
    // 输入手机号，验证手机号格式，如果格式无误，检查手机是否在官网和申报系统注册过
    // 如果在官网注册过，则使用手机号后六位作为初始密码；如果没有则让用户填初始密码
    checkAccountStatus(e){
        let mobile = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/;
        if(!mobile.test(e.target.value.trim())){
            this.props.form.validateFields(['mobile'],{force:true})
            this.setState({mobileStatus:0});
            return;
        }
        let param = {mobile:e.target.value};
            api.get('user/account/checkAccStatus',param).then(res=>{
                this.setState(
                    {mobileStatus:res.data.accStatus},
                    ()=>{
                        // 在官网有账号的直接用后六位作为初始密码
                        if(['1','2'].includes(''+res.data.accStatus)){
                            this.props.preSetPassword(param.mobile.slice(-6));
                            this.props.form.resetFields(['initPsw']);
                            this.props.form.setFieldsValue({
                                'initPsw':'该手机号已绑定官网账号，无需设置密码'
                            })
                        }else{
                            this.props.preSetPassword('');
                            this.props.form.setFieldsValue({
                                'initPsw':''
                            })
                        }
                    }
                );
            })
    }

    // 获取推荐人列表
    getRecommenderList(){
        let params = {
            deptId:1
        }
        api.get('common/department/user',params).then(res=>{
            if(res.code === 20000){
                this.setState({
                    recommenderList:res.data
                })
            }else{
                message.error("获取推荐人选项失败！")
            }
            
        })
    }

    // 单个表单元素验证
    validateSigleField(name){
        this.props.form.validateFields([name],{force:true})
    }

    resetDefaultFiles(){
        this.setState({
            fileList:[]
        })
    }

    componentWillMount(){
        this.getRecommenderList();
    }
    
}
const ModalForm = Form.create({
})(AddAccountForm);
export default ModalForm;