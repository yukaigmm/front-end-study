
import React,{ Component } from 'react';
import { observer, inject } from 'mobx-react';
import './Account.less';
import api from '../../utils/api';
import moment from 'moment';
import 'moment/locale/zh-cn';
import { Table, Button ,Select, DatePicker, Pagination, Tabs, message, Spin, Checkbox} from 'antd';
import AccountList from './AccountList'
moment.locale('zh-cn')
const Option = Select.Option;
const TabPane = Tabs.TabPane;
const CheckboxGroup = Checkbox.Group;

@inject('optionStore')
@observer
class Account extends Component {
  render () {
    let {
      dataSource,
      columns,
      loading,
      accountItemLoading,
      accountItem,
      rowData,
      currentCompanyId,
      tableDataParams,
      total,
      companyInfo,
      companyOptions,
      currentCompanyInfo,
      applicationOptions
    } = this.state;
    return (
      <div className="content-container account-content-container">
        <div className="table-list account-table-container">
          <div className="keyword-search-area">
            <input className="keyword-input search-input" placeholder="输入关键字搜索" onBlur={this.getKeywords} onKeyUp={this.searchAccountByKeyUp}/>
            <Button className="keyword-button" type="primary" size="small" onClick={this.searchAccount}>搜索</Button>
          </div>
          <Table
            className="company-account-table"
            bordered
            size="small"
            pagination={false}
            dataSource={dataSource}
            columns={columns}
            loading={loading}
            rowClassName={(record)=>{return record.companyId === currentCompanyId ? 'current-row':''}}
            rowKey={(record) => {return record.companyId}}
            onRow={record=>{
              return {
                onClick:()=>{
                  this.getAccountItems({rowData:record,trigger:'rowClick'})
                }
              }
            }}
          />
          <Pagination size="small" /*showSizeChanger showQuickJumper */onChange={this.pageChange} onShowSizeChange={this.pageSizeChange} current={tableDataParams.pageNo} total={total}/>
        </div>
        <div className="table-item-detail">
            <div className="table-item-info">
              <div className="company-name">{currentCompanyInfo.companyName}</div>
              <div className="company-info clearfix">
                {
                  currentCompanyInfo.cityId ? (
                    <div className="company-info-item">
                      <span>所在地区：</span>
                      <AreaComp areaMapping={this.props.optionStore.fmAdminOptions.cRegisterCity} area={currentCompanyInfo.cityId}/>
                  </div> 
                  ):''
                }
                {
                  companyInfo.map(item=>{
                    return currentCompanyInfo[item.key || item.key1] ? (
                      <div className="company-info-item" key={item.key || item.key1}>
                        <span>{item.label}：</span>
                        <span className="company-info-item-content">{currentCompanyInfo[item.key || item.key1]}</span>
                      </div>
                    ):''
                  })
                }
              </div>
            </div>
            <div className="table-item-edit-file">
              <Tabs defaultActiveKey="1" onChange={this.tabChange.bind(this)}>
                <TabPane tab="公司信息" key="1" className="company-options">
                  <Spin spinning={this.state.companyInfoLoading}>
                  {companyOptions.map(item=>{
                    return (
                      <div className="company-option-item" key={item.key}>
                        <span className="item-label">{item.label}：</span>
                        <Select value={currentCompanyInfo[item.key]?currentCompanyInfo[item.key]:'请选择'} onChange={(value)=>{
                          item.handler.call(this,currentCompanyInfo,{[item.key]:value})
                        }}>
                          {item.options.map(opt=><Option value={opt.value} key={opt.value}>{opt.label}</Option>)}
                        </Select>
                      </div>
                    )
                  })}
                  {
                    <div className="company-option-item">
                      <span className="item-label">有效期：</span>
                      <DatePicker
                        format="YYYY-MM-DD"
                        value={!(['0000-00-00',null,undefined].includes(currentCompanyInfo.userCompanyStartDate))?moment(currentCompanyInfo.userCompanyStartDate): null}
                        placeholder="请选择"
                        onChange={(value)=>{this.userCompanyAccountInfoChange.call(this,currentCompanyInfo,{userCompanyStartDate:moment(value).format()})}}
                      />
                      ~
                      <DatePicker
                        format="YYYY-MM-DD"
                        value={!(['0000-00-00',null,undefined].includes(currentCompanyInfo.userCompanyEndDate))?moment(currentCompanyInfo.userCompanyEndDate): null}
                        placeholder="请选择"
                        onChange={(value)=>{this.userCompanyAccountInfoChange.call(this,currentCompanyInfo,{userCompanyEndDate:moment(value).format()})}}
                      />
                    </div>
                  }
                  {
                    <div className="company-option-item">
                      <span className="item-label">开通应用：</span>
                      <CheckboxGroup options={applicationOptions} value={currentCompanyInfo.userCompanyApplicationIds || []} onChange={(value)=>{this.userCompanyAccountInfoChange.call(this,currentCompanyInfo,{userCompanyApplicationIds:value})}} />
                    </div>
                  }
                  {
                    <div className="company-option-item">
                      <span className="item-label">账号数：</span>
                      <span>{currentCompanyInfo.fmAccountCnt || '--'}</span>
                    </div>
                  }
                  </Spin>
                </TabPane>
                <TabPane tab="账号列表" key="2" className="company-account-manage">
                  <AccountList
                    getAccountItems={this.getAccountItems}
                    refreshComanyInfo={this.refreshComanyInfo.bind(this)}
                    rowData={rowData}
                    loading={accountItemLoading}
                    companyId={currentCompanyId}
                    />
                </TabPane>
              </Tabs>
            </div>
        </div>
      </div>
    )
  }
  // 组件挂载时获取账户数据,绑定设置table高度的事件
  componentDidMount () {

    this.getAccountTableData(this.state.tableDataParams);

  }
  // 构造函数
  constructor (props) {
    super(props);
    this.getAccountItems = this.getAccountItems.bind(this);
    this.pageSizeChange = this.pageSizeChange.bind(this);
    this.pageChange = this.pageChange.bind(this);
    this.getKeywords = this.getKeywords.bind(this);
    this.searchAccountByKeyUp = this.searchAccountByKeyUp.bind(this);
    this.searchAccount = this.searchAccount.bind(this);
    this.state = {
      loading: false,
      companyInfoLoading:false,
      tableDataParams:{
        keyWord:'',
        status:'',
        pageNo:1,
        pageSize:10,
      },
      total:20,
      dataSource: [],
      // 右侧公司固定信息
      companyInfo:[
        {
          label:'客户经理',
          key:'userCompanyFollowLinkman',
          key1:'userCompanyFollowUser'
        },
        {
          label:'开通人',
          key:'userCompanyOpenLinkman',
          key1:'userCompanyOpenUser'
        },
        {
          label:'备案编号',
          key:'registerNumber',
        },
        {
          label:'成立日期',
          key:'establishDate',
        },
      ],
      currentCompanyInfo:{},
      // 右侧公司编辑信息
      companyOptions:[
        {
          label:'开通状态',
          key:'userCompanyStatus',
          handler:this.userCompanyAccountInfoChange,
          options:[
            {
              value:1,
              label:'禁用'
            },
            {
              value:2,
              label:'未开通'
            },
            {
              value:3,
              label:'已开通'
            }
          ]
        },
        {
          label:'商务状态',
          key:'userCompanyLevel',
          handler:this.userCompanyAccountInfoChange,
          options:[
            {
              value:1,
              label:'未收费',
            },
            {
              value:2,
              label:'已收费',
            }
          ]
        }
      ],
      applicationOptions:[
        {
          label:'星管家',
          value:1
        }
      ],
      columns: [
        {
          title: '公司ID',
          dataIndex: 'companyId',
          key: 'companyId',
          width: 110,
        },
        {
          title: '公司简称',
          dataIndex: 'companyShortName',
          key: 'companyShortName',
        },
      ],
      // 添加账号modal
      rowData:'',
      // 公司人员账号
      accountItem:[],
      accountItemLoading:false,
      currentCompanyId:'',
    }
  }
  // ---------------------------------根据条件请求table数据
  // 获取账户table数据
  getAccountTableData(params){
    this.setState({loading: true});
    api.get('datadis/company',params).then( (res) => {
      this.setState({loading: false});
      if (res.code === 20000) {
        let tableData = res.data.records;
        this.setState({
          dataSource: JSON.parse(JSON.stringify(tableData)),
          total:res.data.total,
          rowData:this.state.rowData? this.state.rowData : tableData[0]
        },()=>{
          if(!this.state.currentCompanyId){
            this.getCompanyInfo(tableData[0].companyId).then(data=>{
              this.setState({
                currentCompanyInfo:data,
                currentCompanyId:this.state.currentCompanyId || tableData[0].companyId
              })
            });
          }
        })
      }
    })
  }
  // table 分页变化
  pageSizeChange(page, pageSize){
    let params = { ...this.state.tableDataParams, pageSize,pageNo:1};
    this.getAccountTableData(params);
    this.setState({
      tableDataParams:params
    });
  }
  pageChange(pageNo, pageSize){
    let params = { ...this.state.tableDataParams, pageNo};
    this.getAccountTableData(params);
    this.setState({
      tableDataParams:params
    });
  }
  // 点击搜索按钮
  searchAccount(e){
    let pageSize = 10;
    let pageNo = 1;
    let params = {...this.state.tableDataParams,pageSize,pageNo};
    this.getAccountTableData(params);
    this.setState({
      tableDataParams:params
    })
  }
  // 搜素框回车
  searchAccountByKeyUp(e){
    if(e.keyCode === 13){
      this.setState({
        tableDataParams:{
          ...this.state.tableDataParams,
          keyWord:e.target.value
        }
      },()=>{
        this.searchAccount()
      })
    }
  }
  // 获取搜索框的值
  getKeywords(e){
      this.setState({
        tableDataParams:{
          ...this.state.tableDataParams,
          keyWord:e.target.value
        }
      })
  }
  tabChange(key){
    console.log(key)
  }
  
  // 获取公司信息
  getCompanyInfo(companyId){
    return new Promise((resolve,reject)=>{
      api.get('datadis/company/'+companyId).then(res=>{
        if(res.code === 20000){
          resolve(res.data);
        }else{
          message.error(res.msg);
          reject();
        }
      })
    })
  }
  // 获取公司账号信息
  getCompanyAccountList(companyId){
    return new Promise((resolve,reject)=>{
      api.get('user/account',{company_keyword:companyId}).then(res=>{
        this.setState({accountItemLoading:false})
          if(res.code === 20000){
            resolve(res.data.records);
          }else{
            message.err(res.msg);
            reject();
          }
      })
    })
  }
  // 刷新公司信息
  refreshComanyInfo(){
    this.setState({
      companyInfoLoading:true
    })
    this.getCompanyInfo(this.state.currentCompanyId).then(data=>{
      this.setState({
        currentCompanyInfo:data,
        companyInfoLoading:false
      })
    });
  }

  // 单击表格行，公司人员账户信息获取
  getAccountItems(params){
    let companyId = params.rowData.companyId
    if(this.state.currentCompanyId ===  companyId&& params.trigger === 'rowClick'){
      return;
    }
    this.setState({
      currentCompanyId:companyId,
      accountItemLoading:true,
      rowData:params.rowData,
      companyInfoLoading:true
    });
    this.getCompanyInfo(companyId).then(data=>{
      this.setState({
        currentCompanyInfo:data,
        companyInfoLoading:false
      })
    });
  }


  // 改变公司信息状态回调----开通状态，商务状态，有效期
  userCompanyAccountInfoChange(companyInfo,params){
    console.log(params)
    this.setState({
      companyInfoLoading:true
    });
    api.put(`datadis/company/checkCompanyStatus/${companyInfo.companyId}`,params).then(res=>{
      if(res.code === 20000){
        message.success('修改成功！');
      }else{
        message.error(res.msg)
      }
      this.refreshComanyInfo()
    })
  }
}



// 地区组件
const AreaComp = ({area,areaMapping})=>{
  // let areaMapping = this.props.optionStore.fmAdminOptions.cRegisterCity;
  let cityMap = [];
  for(let item of areaMapping){
    if(item.children.length){
      cityMap.push(...item.children);
    }else{
      cityMap.push(item);
    }
  }
  for(let item of cityMap){
    if(item.value === area){
      // console.log(true)
      return (<span className="company-info-item-content">{item.name}</span>)
    }
  } 
  return (<span>--</span>)
}

export default Account;
