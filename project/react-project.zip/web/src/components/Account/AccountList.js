import React , {Component} from 'react';
import {Table,Button,Select,Modal,Pagination,message} from 'antd';
import api from '../../utils/api';
import AddAccountModal from './AddModal'
const Option = Select.Option;
const confirm = Modal.confirm;

class AccountList extends Component{
    render(){
        let {
            columns,
            pageNo,
            total,
            tableData,
            loading,
            showPagination,
            stuffAccountTableHeight,
            addAccountModalOpen,
            tableScroll
        } = this.state;
        return (
            <div className="company-account-detail">
                <div className="add-button-container clearfix">
                    {/* <Button className="add-account-button" size="small" type="primary" onClick={this.addAccount}>添加账号</Button> */}
                </div>
                <div
                 className="account-item"
                >
                    <Table
                     className="stuff-account-table"
                     size="small"
                     bordered
                     pagination={false}
                     columns={columns}
                     dataSource={tableData} 
                     loading={loading}
                     scroll={{y:tableScroll?stuffAccountTableHeight:false}}
                     rowKey={record=>record.id}
                    //  style={{minWidth: '600px'}}
                    />
                    {showPagination?<Pagination size="small" showSizeChanger showQuickJumper onChange={this.pageChange} onShowSizeChange={this.pageSizeChange} defaultCurrent={pageNo} total={total}/>:null}
                    
                </div>
                <AddAccountModal
                    rowData={this.props.rowData}
                    isOpen={addAccountModalOpen}
                    closeModal={this.closeAddAccountModal.bind(this)}
                    getAccountItems={this.getAccountItems.bind(this)}
                />
            </div>
        )
    }
    // 构造函数
    constructor(props){
        super(props);
        this.accountStatusChange = this.accountStatusChange.bind(this);
        this.deleteAccount = this.deleteAccount.bind(this);
        this.adiminStatusChange = this.adiminStatusChange.bind(this);
        this.getTableData = this.getTableData.bind(this);
        this.pageChange = this.pageChange.bind(this);
        this.pageSizeChange = this.pageSizeChange.bind(this);
        this.setTableHeight = this.setTableHeight.bind(this);
        this.addAccount = this.addAccount.bind(this);
        this.closeAddAccountModal = this.closeAddAccountModal.bind(this);
        this.getRecommenderList = this.getRecommenderList.bind(this)
        this.state = {
            recommenderList:[],
            tableData:[],
            loading: false,
            addAccountModalOpen:false,
            accountStatus:'',
            isAdmin:'',
            columns:[
                {
                    title:'姓名',
                    dataIndex:'linkman',
                    key:'linkman',
                    // width: 80
                    render:(text,row)=>{
                        if(row.status == 4){
                            return (
                                <span style={{'textDecoration':'line-through','textDecorationColor':'#f45'}}>{row.linkman}</span>
                            )
                        }
                        return (
                            <span>{row.linkman}</span>
                        )
                    }
                },
                {
                    title:'用户名',
                    dataIndex:'name',
                    key:'name',
                    width: 130,
                    render:(text,row)=>{
                        if(row.status == 4){
                            return (
                                <span style={{'textDecoration':'line-through','textDecorationColor':'#f45'}}>{row.name}</span>
                            )
                        }
                        return (
                            <span>{row.name}</span>
                        )
                    }
                },
                {
                    title:'手机号',
                    dataIndex:'mobile',
                    key:'mobile',
                    width: 110,
                    render:(text,row)=>{
                        if(row.status == 4){
                            return (
                                <span style={{'textDecoration':'line-through','textDecorationColor':'#f45'}}>{row.mobile}</span>
                            )
                        }
                        return (
                            <span>{row.mobile}</span>
                        )
                    }
                },
                {
                    title:"推荐人",
                    dataIndex:"recommenderId",
                    key:"recommenderId",
                    width:90,
                    render:(text,row)=>{
                        if(row.recommenderId){
                         return (
                             this.state.recommenderList.filter(item=>{
                                return item.id == row.recommenderId
                              }).map(recommender=>{
                                return (
                                    <span>{recommender.linkman || recommender.name}</span>
                                )
                            }))
                        }else{
                            return (<span>--</span>);
                        }
                    }
                },
                {
                    title:'账号状态',
                    dataIndex:'status',
                    key:'status',
                    width: 90,
                    render:(text,record,index)=>{
                        return (
                            <Select value={text} onChange={this.accountStatusChange.bind(this,record)} size="small">
                                <Option value={1}>正常</Option>
                                <Option value={2}>禁用</Option>
                                <Option value={3}>离职</Option>
                                <Option value={4}>删除</Option>
                            </Select>
                        )
                    }
                },
                {
                    title:'管理员',
                    dataIndex:'isAdmin',
                    key:'isAdmin',
                    width: 70,
                    render:(text, record, index)=>{
                        return (
                            <Select value={record.isAdmin} onChange={this.adiminStatusChange.bind(this,record)} size="small">
                                <Option value={1}>是</Option>
                                <Option value={0}>否</Option>
                            </Select>
                        )
                    }
                },
                {
                   title:"名片",
                   dataIndex:"visitingCardUrl",
                   width:80,
                   render:(text,record,index)=>{
                       let serve = process.env.NODE_ENV === "production" ? "http://static.simuwang.com":"https://static-test.simuwang.com"
                       return record.visitingCardUrl?(
                           <a href={`${serve}/Uploads/crm/${record.visitingCardUrl}`} target="_blank">查看名片</a>
                       ):(
                           "--"
                       )
                   }
                },
                {
                    title:'操作',
                    dataIndex:'action',
                    key:'action',
                    width: 80,
                    render:(text,record,index)=>{
                        return (
                            <Button type="primary" size="small" onClick={this.deleteAccount.bind(this,record)}>删除</Button>
                        )
                    }
                },
            ],
            companyId:'',
            pageNo:1,
            pageSize:10,
            total:1, 
            showPagination:false,
            stuffAccountTableHeight:0,
            tableScroll:false
        }
    }
    componentWillReceiveProps(nextProps){
        // 父组件传入的company_keyword改变时，组件重新获取table数据
        if(nextProps.companyId !== this.props.companyId){
            this.setState(
                {
                    companyId:nextProps.companyId,
                    pageNo:1,
                    pageSize:10
                },
                ()=>{
                    this.getTableData();
                }
            )
        }
    }
    componentDidMount(){
        if(this.props.companyId){
            this.setState({companyId:this.props.companyId},()=>{
                this.getTableData();
            })
        }
        // 动态设置表格高度
        // setTimeout(() => {
            this.setTableHeight();
            window.addEventListener('resize',this.setTableHeight)
        // }, 100);
    }
    // 组件卸载的时候注销window的事件
    componentWillUnmount(){
        window.removeEventListener('resize',this.setTableHeight)
    }

    componentWillMount(){
        this.getRecommenderList();
    }
    
    // 获取table数据
    getTableData(){
        this.setState({loading:true})
        let {companyId,pageNo,pageSize} = this.state;
        let params = {
            company_keyword:companyId,
            pageNo,
            pageSize,
        }
        api.get('user/account',params).then(res=>{
            this.setState({loading:false})
            if(res.code === 20000){
                if(res.data.records.length){
                    this.setState(
                        {
                            tableData:JSON.parse(JSON.stringify(res.data.records)),
                            showPagination:true,
                            total:res.data.total
                        }
                    );
                }else{
                    // 在删除table数据的时候，如果某一页删完了，需要获得上一页的数据
                    if(pageNo > 1){
                        this.setState({pageNo:pageNo-1});
                        this.getTableData();
                    }else{
                        this.setState({tableData:[],showPagination:false})
                    }
                }
            }else{
                this.setState({tableData:[],showPagination:false})
            }
        })
    }
    // 设置账号状态
    setAccountStatus(params){
        return new Promise((resolve,reject)=>{
            api.put('user/account/accSetStatus',params).then(res=>{
                // if(res.code === 20000){
                //     resolve(res);
                // }else{
                //     reject({msg: res.msg});
                // }
                resolve(res);
            })
        })
    }
    // 删除账号
    deleteAccount(rowData){
        let params = {
            userId:rowData.id,
            companyId:this.props.companyId,
            status:4,
        }
        let _this = this;
        confirm({
            title:`确认删除${rowData.linkman}吗?`,
            content:``,
            okText:'确认',
            cancelText:'取消',
            onOk(){
                _this.setAccountStatus(params).then(res=>{
                    if(res.code === 20000){
                        _this.getTableData();
                        _this.props.refreshComanyInfo();
                        message.success('删除账号成功');
                    }else{
                        message.error(res.msg);
                    }
                })
            }
        })
    }
    // 账号状态改变
    accountStatusChange(rowData,value){
        let params = {
            userId:rowData.id,
            companyId:this.props.companyId,
            status:value,
        }
        rowData.status = value;
        this.setAccountStatus(params).then(res=>{
            this.getTableData();
            this.props.refreshComanyInfo();
        })
    }
    // 管理员状态改变
    adiminStatusChange(rowData,value){
        let params = {
            userId:rowData.id,
            companyId:this.props.companyId,
            isAdmin:value
        }
        this.setAccountStatus(params).then(res=>{
            this.getTableData();
            this.props.refreshComanyInfo();
        })
    }

    // 获取推荐人列表
    getRecommenderList(){
        let params = {
            deptId:1
        }
        api.get('common/department/user',params).then(res=>{
            if(res.code === 20000){
                this.setState({
                    recommenderList:res.data
                })
            }else{
                message.error("获取推荐人选项失败！")
            }
            
        })
    }
    // 分页变化
    pageChange(page,pageSize){
        this.setState(
            {pageNo:page},
            ()=>{
                this.getTableData();
            }
        )
    }
    pageSizeChange(page,pageSize){
        console.log(pageSize)
        this.setState(
            {pageSize:pageSize},
            ()=>{
                this.getTableData();
            }
        )
    }
    // 添加账号modal相关--------------------------
    // 打开添加账号modal
    addAccount(){
        this.setState({addAccountModalOpen:true})
    }
    // 关闭modal的回调
    closeAddAccountModal(){
        this.setState({addAccountModalOpen:false});
    }
    getAccountItems(){
        this.props.refreshComanyInfo();
        this.getTableData();
    }

    // 动态设置页面表格高度,配合css样式设置table容器高度百分比，在窗口高度在560px以上时，table的高度根据窗口高度动态设置。
  setTableHeight(){
        if(this.timer){
            clearTimeout(this.timer);
        }
        let stuffAccountTableHeight;
        let _this = this;
        this.timer = setTimeout(() => {
            if(document.querySelector('.table-item-edit-file')){
                stuffAccountTableHeight = document.querySelector('.table-item-edit-file').offsetHeight - 
                document.querySelector('.table-item-edit-file .ant-tabs-bar').offsetHeight - 110;
                // document.querySelector('.table-item-edit-file .add-account-button').offsetHeight 
            }
            if(document.querySelector('.account-item .ant-table-tbody').offsetHeight - stuffAccountTableHeight < 0){
                _this.setState({
                    tableScroll:false
                })
            }else{
                _this.setState({
                    tableScroll:true
                })
            }
            this.setState({
                stuffAccountTableHeight:stuffAccountTableHeight
            })
           
        }, 100);
  }
}
export default AccountList;