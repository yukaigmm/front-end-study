import {Modal,message} from 'antd';
import React, { Component } from 'react';
import ModalForm from './ModalForm'
import api from '../../utils/api';
import {observer,inject} from 'mobx-react';
@inject('optionStore')
@observer
class AddAccountModal extends Component{
    render(){
        // const {visible,confirmLoading,ModalText} = this.state;
        let {isOpen,rowData} = this.props;
        return (
           <Modal
           title="添加账号"
           visible={isOpen}
           onOk={this.addAccount}
           onCancel={this.cancel}
           >
           <div>
               <div>
                   <p>公司名称:{rowData.companyName}</p>
                   <p>公司简称:{rowData.companyShortName}</p>
                   <p>备案编码:{rowData.registerNumber}</p>
                   <p>成立日期:{rowData.establishDate}</p>
                   <p>所在地区:{this.getCity(rowData.cityId)}</p>
               </div>
               <div>
                   <ModalForm
                   preSetPassword={this.preSetPassword}
                   className="modal-form" 
                   wrappedComponentRef={this.getFormRef}
                   />
               </div>
           </div>
           </Modal> 
        )
    }

    // 构造函数
    constructor(props){
        super(props);
        this.addAccount = this.addAccount.bind(this);
        this.cancel = this.cancel.bind(this);
        this.getCity = this.getCity.bind(this);
        this.preSetPassword = this.preSetPassword.bind(this);
        this.state = {
            formValue:{},
            // 官网绑定手机号时，设置初始密码
            initPassword:''
        }
    }
    // 点击确定按钮
    addAccount(){
        this.form.validateFields((err,values)=>{
            if(!err){
                // 判断是否官网已经绑定该账号
                if(this.state.initPassword){
                    values.initPsw = this.state.initPassword;
                }
                let formData = JSON.parse(JSON.stringify(values));
                if(formData.visitingCardUrl&&formData.visitingCardUrl.fileList.length){
                    formData.visitingCardUrl = formData.visitingCardUrl.fileList
                                                                       .slice(-1)[0]
                                                                       .response.data.filePath
                                                                       .replace(/\/Uploads\/crm\//g,"/");
                }
                let params = Object.assign({companyId:this.props.rowData.companyId},formData)
                api.post('user/account',params).then(res=>{
                    if(res.code === 20000){
                        message.success('新增账号成功！');
                        this.cancel();
                        this.setState({initPassword:''});
                        this.props.getAccountItems({rowData:{companyId:this.props.rowData.companyId}});
                    }else{
                        message.error(res.msg);
                    }
                })
            }else{
                return;
            }
        })
    }
    // 点击取消按钮
    cancel(){
        this.form.resetFields();
        this.props.closeModal();
        this.formRef.resetDefaultFiles();
    }
    // 账号在官网有，申报系统没有的处理
    preSetPassword(pwd){
        this.setState({initPassword:pwd})
    }
    // 获取表单的ref
    getFormRef=(formRef)=>{
        this.formRef = formRef;
        if(formRef){
            this.form = formRef.props.form;
        }
    }

    // 获取城市名称
    getCity(cityId){
        // if(window.sessionStorage.getItem('fmadminOptionMap')){
            let areaMapping = this.props.optionStore.fmAdminOptions.cRegisterCity;
            let cityMap = this.getCityMap(areaMapping);
            for(let item of cityMap){
                if(item.value === cityId){
                    return item.name
                }
            }
        // }
    }

    // 获取城市map
  getCityMap(areaMap){
    let cityMap = [];
    for(let item of areaMap){
      cityMap.push(...item.children)
    }
    return cityMap;
  }

}


export default AddAccountModal