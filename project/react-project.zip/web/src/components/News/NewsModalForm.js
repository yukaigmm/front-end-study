import {Form,Radio,Input,Row,Col} from 'antd';
import React,{Component} from 'react';
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const {TextArea} = Input;
class ModalForm extends Component{
    render(){
        const {getFieldDecorator} = this.props.form;
        const formItemLayout = {
            labelCol: {
                // xs: { span: 24 },
                span: 6 ,
              },
              wrapperCol: {
                // xs: { span: 24 },
                span: 18 ,
              },
        };
        let {needRemark, needUrl} = this.state;
        
        return (
            <Form className="news-modal-form">
                <Row>
                    <Col span={12}>
                        <FormItem label="审核结果" {...formItemLayout}>
                            {
                                getFieldDecorator('auditStatus',{
                                    rules:[
                                        {required:true,message:'请选择审核结果'}
                                    ]
                                })(<RadioGroup onChange={this.auditStatusChange.bind(this)}>
                                    <Radio value={1}>待审核</Radio>
                                    <Radio value={2}>待发布</Radio>
                                    <Radio value={3}>已发布</Radio>
                                    <Radio value={4}>已拒绝</Radio>
                                    <Radio value={5}>已撤回</Radio>
                                </RadioGroup>)
                            }
                        </FormItem>
                    </Col>
                </Row>
                <FormItem label="审核备注" {...formItemLayout}>
                    {
                        getFieldDecorator('auditRemark',{
                            rules:[{required:needRemark,message:'请输入审核备注'}]
                        })(<TextArea rows={4}/>)
                    }
                </FormItem>
                <FormItem label="官网链接" {...formItemLayout}>
                    {
                        getFieldDecorator('articleUrl',{
                            rules:[{required:needUrl,message:'请输入官网链接'}]
                        })(<TextArea rows={4}/>)
                    }
                </FormItem>
            </Form>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            needRemark:false,
            needUrl: false,
        }
    }
    componentWillReceiveProps(props){
        
        // console.log(props)
        // if(props.auditStatus === 0){
        //     this.setState({
        //         needRemark:true
        //     });
        // }
        let formValue = this.props.form.getFieldsValue();
        //当审核状态为已拒绝时，必须填写审核备注
        this.setState({
            needRemark: formValue.auditStatus === 4 ? true : false,
            needUrl: formValue.auditStatus === 3 ? true : false,
        })
    }
    auditStatusChange(e){
        this.setState({
            needRemark:e.target.value === 4 ? true : false,
            needUrl: e.target.value === 3 ? true : false,
        })
    }
}
const NewsModalForm = Form.create({})(ModalForm);
export default NewsModalForm;