import React,{Component} from 'react';
import {Form,Select,Input} from 'antd';
const FormItem = Form.Item;
const Option = Select.Option;

class FormSearch extends Component{
    render(){
        const {getFieldDecorator} = this.props.form;
        let {
            auditStatusOption,
            // auditSubjectOption
        } = this.state;
        return (
            <Form layout="inline">
                <FormItem>
                    {
                        getFieldDecorator('auditStatus',{
                            initialValue:0
                        })(<Select size="small" style={{width: 120}} onChange={this.optionsChange.bind(this)}>
                            {auditStatusOption.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                            </Select>)
                    }
                </FormItem>
                <FormItem>
                    {
                        getFieldDecorator('keywords',{
                        })(<Input className="search-input" placeholder="请输入关键字"/>)
                    }
                </FormItem>
            </Form>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            auditStatusOption:[
                {
                    label: '全部',
                    value: 0
                },
                {
                    label: '待审核',
                    value: 1
                },
                {
                    label: '待发布',
                    value: 2
                },
                {
                    label: '已发布',
                    value: 3
                },
                {
                    label: '审核不通过',
                    value: 4
                },
            ],
        }
    }
    optionsChange(value){
        let _this = this;
        // 需要异步获取，否则获取的是上一步的formValue
        setTimeout(() => {
            _this.props.searchNews();
        }, 100);
    }
}
const NewsSearchForm = Form.create({})(FormSearch);
export default NewsSearchForm;