import {Modal,message,Spin} from 'antd';
import React,{Component} from 'react';
import NewsModalForm from './NewsModalForm';
import ReactHtmlParser from 'react-html-parser';
import api from '../../utils/api';

class NewsModal extends Component{
    render(){
        let {openStatus} = this.props;
        let {
            loading,
            auditInfo,
        } = this.state;
        return (
            <Modal
                className="news-modal"
                visible={openStatus} 
                // style={{top:'50%'}}
                wrapClassName="news-modal-container"
                onCancel={this.cancelAudit}
                onOk={this.submitAudit}
                title="审核资讯"
                >
                <Spin spinning={loading}>
                    <div className="audit-info-container">
                        <div className="audit-info">
                           
                            {
                                auditInfo.map(item=>{
                                    return item.col === 6? (
                                        <div className="audit-item" key={item.name}>
                                            <span className="audit-label">
                                                {item.label}:
                                            </span>
                                            <div className="content">
                                                {item.value||"--"}
                                            </div>
                                        </div>)
                                        :(
                                        <div className="summary-row audit-item" key={item.name}>
                                            <span className="audit-label">
                                                {item.label}:
                                            </span>
                                            <div>
                                                {ReactHtmlParser(item.value||"--")}
                                            </div>
                                        </div>)
                                })
                            }
                        </div>
                        <NewsModalForm
                        wrappedComponentRef={this.getFormRef}
                        />
                    </div>
                </Spin>
            </Modal>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            companyTitle:'',
            articleId:'',
            auditData: {},
            loading:true,
            auditInfo:[],
            preOpenStatus:false,
            imgBaseUrl: ''
        }
        this.submitAudit = this.submitAudit.bind(this);
        this.cancelAudit = this.cancelAudit.bind(this);
        this.getFormRef = this.getFormRef.bind(this);
        this.getAuditData = this.getAuditData.bind(this);
        this.setModalValues = this.setModalValues.bind(this);
    }
    componentWillReceiveProps(props){
        if(props.openStatus === true && props.openStatus !== this.state.preOpenStatus){
            this.setState({
                articleId:props.articleId,
                loading:true,
                preOpenStatus:true
            },()=>{
                this.getAuditData();
            })
        }
    }
    componentDidMount(){
        let url = (process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'test')
            ? 'http://static-test.simuwang.com'
            : 'http://static.simuwang.com';
        this.setState({
            imgBaseUrl: url
        })

    }
    componentWillUnmount(){

    } 

    // 获取审核数据
    getAuditData(){
        
        api.get(`article/${this.state.articleId}`).then(res=>{
            let auditInfoArr = this.getAuditInfo(res.data);
            
            if(res.code === 20000){
                this.setState({
                    auditData:res.data,
                    auditInfo:auditInfoArr,
                },this.setModalValues);
            }
            this.setState({loading:false})
        })
    }
    getAuditInfo(resData){
        let auditInfoArr = [
            {
                name:'articleTitle',
                label:'资讯标题',
                col:12
            },
            {
                name:'author',
                label:'作者',
                col:6
            },
            {
                name:'auditStatus',
                label:'当前状态',
                col:6,
                render: (value) => {
                    let map = {
                        1: '待审核',
                        2: '待发布',
                        3: '已发布',
                        4: '已拒绝',
                        5: '已撤回'
                    }
                    return map[value];
                } 
            },
            {
                name: 'postStatus',
                label: '定时发布',
                col: 6,
                render: (value) => {
                    let map = {
                        0: '否',
                        1: '是'
                    };
                    return map[value] || '未知';
                }
            },
            {
                name: 'postTime',
                label: '发布时间',
                col: 6,
                render: (value) => {
                    return value ? value.split(' ')[0] : '未知';
                }
            },
            {
                name: 'imageUrl',
                label: '资讯图片',
                col: 12,
                render: (value) => {
                    return `<img style="max-width: 100%;max-height: 300px;" src="${this.state.imgBaseUrl}${value}"/>`
                }
            },
            {
                name: 'imageAlt',
                label: '图片描述',
                col: 12,
            },
            {
                name: 'articleFile',
                label: '资讯附件',
                col: 12,
                render: (value, data) => {
                    return `<a download target="_blank" href="${this.state.imgBaseUrl}${value}">${data.articleFilename || '点此下载'}</a>`
                }
            }
        ];
        auditInfoArr = auditInfoArr.map((item)=>{
            item['value'] = (item.render && item.render instanceof Function) ? item.render(resData[item.name], resData) : resData[item.name];
            return item;
        })

        return auditInfoArr;
    }
    // 提交审核
    submitAudit(){
        this.form.validateFields((err,value)=>{
            let params = Object.assign({},{
                id: this.state.articleId,
                auditStatus: value.auditStatus
            },value)
            // antd的bug，有必填项未填的时候，err有时候为null，需要手动触发验证错误
            if(value.auditRemark === '' && value.auditStatus === 0){
                this.form.setFields({
                    auditRemark:{
                        errors:[new Error('请输入审核备注')]
                    }
                })
                return;
            }
            if(!err){
                api.put(`/article/auditing/${this.state.articleId}`,params).then(res=>{
                    // console.log(res)
                    if(res.code === 20000){
                        message.success('审核成功！');
                        this.props.getNewsTableData();

                    }else{
                        message.error(res.msg)
                    }
                })
                this.cancelAudit();
            }
        })
    }
    // 取消审核
    cancelAudit(){
        this.props.closeAuditModal();
        this.form.resetFields();
        this.setState({
            preOpenStatus:false
        })
    }
    // 打开modal时给form赋值，注册video
    setModalValues(){
        // 给form赋值
        this.form.setFieldsValue({
            auditStatus: this.state.auditData.auditStatus,
            auditRemark: this.state.auditData.auditRemark,
            articleUrl: this.state.auditData.articleUrl,
        })
    }
    // 获取表单ref
    getFormRef(formRef){
        if(formRef){
            this.form = formRef.props.form;
        }
    }
}
export default NewsModal;