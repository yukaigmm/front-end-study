import { Table, Button, Pagination } from 'antd';
import React,{ Component } from 'react';
import NewsModal from './NewsModal';
import NewsSearchForm from './NewsSearchForm';
import api from '../../utils/api';
import './News.less';
// import {observer,inject} from 'mobx-react';
// @inject('optionStore')
// @observer
class News extends Component{
    render(){
        let {
            dataSource,
            newsColumns,
            newsModalOpenStatus,
            tableParams,
            total,
            rowData,
            tableLoading,
            tableHeight,
            tableScroll
        } = this.state;
        return (
            <div className="content-container news-content">
                <div className="news-table-container">
                    <div className="keyword-search-area">
                        <NewsSearchForm
                        wrappedComponentRef={this.getFormRef}
                        searchNews={this.searchNews}
                        />
                        <Button onClick={this.searchNews} type="primary" className="keyword-button">搜索</Button>
                    </div>
                    <div className="table-container">
                        <Table
                        bordered
                        size="small"
                        dataSource={dataSource}
                        loading={tableLoading}
                        columns={newsColumns}
                        rowKey={(record) => {return record.articleId}}
                        pagination={false}
                        scroll={{y:tableScroll ? tableHeight :false,x:1200}}
                        ></Table>
                        <Pagination size="small" showSizeChanger showQuickJumper onChange={this.pageChange} onShowSizeChange={this.pageSizeChange} total={total} current={tableParams.pageNo} pageSize={tableParams.pageSize}/>
                        <div className="news-modal-conainer">
                            <NewsModal
                            openStatus={newsModalOpenStatus}
                            articleId={rowData.articleId}
                            closeAuditModal={this.closeAuditModal}
                            getNewsTableData={this.getNewsTableData}
                            />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            // 资讯table
            dataSource:[],
            newsColumns:[
                {
                    title:'公司简称',
                    dataIndex:'companyShortName',
                    key:'companyShortName',
                    width: 150,
                },
                {
                    title:'资讯标题',
                    dataIndex:'articleTitle',
                    key:'articleTitle',
                    width: 150,
                },
                {
                    title:'作者',
                    dataIndex:'author',
                    key:'author',
                    width: 100
                },
                {
                    title:'是否定时发布',
                    dataIndex:'postStatus',
                    key:'postStatus',
                    width: 100,
                    render:(text,row,index)=>{
                        return row.postStatus === 1 ? '是' : '否';
                    }
                },
                {
                    title:'发布时间',
                    dataIndex:'postTime',
                    key:'postTime',
                    width: 100,
                    render:(text,row,index)=>{
                        let time = row.postTime ? row.postTime.split(' ')[0] : '--';
                        return time;
                    }
                },
                {
                    title:'图片描述',
                    dataIndex:'imageAlt',
                    key:'imageAlt',
                    width: 200
                },
                {
                    title:'文章状态',
                    dataIndex:'auditStatus',
                    key:'auditStatus',
                    width: 100,
                    render:(text,row,index)=>{
                        let map = {
                            1: '待审核',
                            2: '待发布',
                            3: '已发布',
                            4: '已拒绝',
                            5: '已撤回'
                        };
                        return map[row.auditStatus] || '--';
                    }
                },
                {
                    title:'操作',
                    dataIndex:'action',
                    // fixed:'right',
                    key:'newsAction',
                    width: 100,
                    render:(text,row,index)=>{
                        return (
                            <div>
                                {/* disabled={['7','4'].includes(row.status+'')} */}
                                <Button type="primary"  className="action-button" size="small" onClick={this.auditNews.bind(this,row)}>审核</Button>
                            </div>

                        )
                    }
                },
            
            
            ],
            tableParams:{
                keywords:'',
                auditStatus:0,
                pageNo:1,
                pageSize:10,
            },
            total:1,
            tableLoading:false,
            tableHeight:0,
            tableScroll:false,
            // 审核modal
            newsModalOpenStatus:false,
            rowData:{},
        };
        this.auditNews = this.auditNews.bind(this);
        this.closeAuditModal = this.closeAuditModal.bind(this);
        this.pageSizeChange = this.pageSizeChange.bind(this);
        this.pageChange = this.pageChange.bind(this);
        this.getFormRef = this.getFormRef.bind(this);
        this.searchNews = this.searchNews.bind(this);
        this.getNewsTableData = this.getNewsTableData.bind(this);
        this.setTableHeight = this.setTableHeight.bind(this);
    }
    componentWillMount(){
        this.getNewsTableData();
    };
    componentDidMount(){
        this.setTableHeight();
        window.addEventListener('resize',this.setTableHeight);
    }
    componentWillUnmount(){
        window.removeEventListener('resize',this.setTableHeight)
    }
    // 获取tableData
    getNewsTableData(){
        this.setState({tableLoading:true})
        api.get('article',this.state.tableParams).then(res=>{
            if(res.code === 20000){
                this.setState({
                    dataSource:res.data.records,
                    total:res.data.total,
                    tableLoading:false
                },
                ()=>{
                    this.setTableHeight()
                }
            )
            }else{
                this.setState({
                    tableLoading:false
                })
            }
        })
    }
    // 根据搜索条件获取tableData
    searchNews(){
        let formValue = this.form.getFieldsValue();
        this.setState({
            tableParams:Object.assign({},this.state.tableParams,formValue,{
                pageNo:1,
                pageSize:10
            })
        },()=>{
            console.log(this.state.tableParams)
            this.getNewsTableData()
        })

    }
    // 打开审核modal
    auditNews(row){
        this.setState({
            newsModalOpenStatus:true,
            rowData:row
        })
    }
    closeAuditModal(){
        this.setState({
            newsModalOpenStatus:false
        })
    }
    
    // 分页变化
    pageChange(page,pageSize){
        this.setState(
            {tableParams:{...this.state.tableParams,pageNo:page}},
            ()=>{
                this.getNewsTableData();
            }
        )
    }
    pageSizeChange(page,pageSize){
        this.setState(
            {tableParams:{...this.state.tableParams,pageSize,pageNo:1}},
            ()=>{
                this.getNewsTableData();
            }
        )
    }
    // 获取搜索表单的ref
    getFormRef(formRef){
        if(formRef){
            this.form = formRef.props.form;
        }

    }
    // 设置表格自适应高度
    setTableHeight(){
        if(this.newsTimer){
            clearTimeout(this.newsTimer);
        }
        let tableHeight;
        let _this = this;
        // let tableInnerHeight = document.querySelector('.ant-table-body .ant-table-fixed').offsetHeight;
        this.newsTimer = setTimeout(() => {
            // 设置table滚动高度
            if(document.querySelector('.news-table-container')){
                tableHeight = document.querySelector('.news-table-container').offsetHeight - 140;
            }
            if(document.querySelector('.ant-table-body .ant-table-tbody').offsetHeight - tableHeight + 20 < 0){
                _this.setState({
                    tableScroll:false
                })
            }else{
                _this.setState({
                    tableScroll:true
                })
            }
            _this.setState({tableHeight:tableHeight})
        }, 100);
    }
}
export default News;