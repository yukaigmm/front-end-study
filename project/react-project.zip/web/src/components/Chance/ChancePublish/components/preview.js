import React, {Component} from 'react'
import {Collapse} from 'antd'

const Panel = Collapse.Panel;

class Preview extends Component {
    constructor(props) {
        super(props);
        this.state = {
            panelTitle: '预览'
        };
    }

    render() {
        let {panelTitle} = this.state;
        return (
            <div className="preview-container">
                <Collapse
                    onChange={this
                    .onCollapseChange
                    .bind(this)}>
                    <Panel header={panelTitle} key='1'>
                        <div className="preview-content-container">
                            预览区域
                        </div>
                    </Panel>
                </Collapse>
            </div>
        )
    }

    // 预览
    onCollapseChange() {
        let panelTitle = this.state.panelTitle === "预览"
            ? '收起预览'
            : '预览';
        this.setState({panelTitle});
      let data = JSON.parse(JSON.stringify(this.props.preview()));

    }

}

export default Preview