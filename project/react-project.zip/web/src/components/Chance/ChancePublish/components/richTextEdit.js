import React, {Component} from "react"
import BraftEditor from 'braft-editor'
import api from '@/utils/api'
import 'braft-editor/dist/braft.css'
import '../css/richTextEditor.less'

class RichTextEditor extends Component {
    constructor(props) {
        super(props);
        this.state = {
            expand: false,
            height: 100
        };
    }

    render() {
        let {expand, height} = this.state;
        const controls = [
            'undo',
            'redo',
            'text-align',
            'media',
            'list_ul',
            'list_ol',
            'link',
            'clear'
        ]
        let editorProps = {
            height: height,
            contentFormat: this.props.contentFormat
                ? this.props.contentFormat
                : 'html',
            initialContent: this.props.value || '',
            controls: this.props.controls
                ? this.props.controls
                : controls,
            onChange: this.props.onChange
                ? this.props.onChange
                : null,
            onRawChange: this.props.onRawChange
                ? this.props.onRawChange
                : null,
            contentId: this.props.contentId || "",
            media: {
                uploadFn: this
                    .uploadFn
                    .bind(this)
            },
            extendControls: this.props.extendControls
                ? [
                    {
                        type: 'button',
                        text: expand
                            ? '收起'
                            : '展开',
                        hoverTitle: expand
                            ? '收起编辑器'
                            : '展开编辑器',
                        onClick: () => {
                            this.onClickExpandButton()
                        }
                    }
                ]
                : []
        }
        return (
            <div className='rich-text-editor-container'>
                <BraftEditor {...this.props} {...editorProps} ref={ref => this.editorInstance = ref}/>
            </div>
        )
    }

    // 展开收起编辑器
    onClickExpandButton() {
        let expand = !this.state.expand;
        let height = expand
            ? this.props.height
            : 100;
        this.setState({expand, height})
    }

    // 上传文件
    uploadFn(param) {
        const data = new FormData();
        const uploadUrl = this.props.uploadUrl;
        data.append('chancePic', param.file)
        api
            .post(`${uploadUrl}`, data)
            .then(res => {
                if (res.code === 20000) {
                    let url = (process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'test')
                        ? 'http://static-test.simuwang.com'
                        : 'http://static.simuwang.com';
                    param.success({url: `${url}${res.data.filePath}`})
                } else {
                    param.error({msg: `${res.msg}`})
                }
            })
    }

}

export default RichTextEditor