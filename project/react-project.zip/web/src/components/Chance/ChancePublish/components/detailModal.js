import React, {Component} from 'react'
import {Modal, Form, message, Spin} from 'antd'

// import $ from 'jquery';

import ModalForm from "./detailsModalForm"
import Preview from "./preview"

import api from '@/utils/api.js'

class DetailModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShow: false,
            record: {},
            detailId: "",
            btnLoading: false,
            loading: false
        };
        this.onCancel = this
            .onCancel
            .bind(this);
        this.onOk = this
            .onOk
            .bind(this);
        // this.formatterText = this.formatterText.bind(this)
    }

    componentWillMount() {}

    render() {
        const FormDetails = Form.create()(ModalForm)
        let {modalTitle} = this.props;
        let {isShow, record, btnLoading} = this.state;
        return (
            <Modal
                destroyOnClose={true}
                bodyStyle={{
                "maxHeight": "500px",
                "overflow": "auto"
            }}
                maskClosable={false}
                confirmLoading={btnLoading}
                okText={'确定'}
                cancelText={'取消'}
                width={800}
                title={modalTitle}
                visible={isShow}
                onOk={this.onOk}
                onCancel={this.onCancel}>
                <Spin spinning={this.state.loading} size="large">
                    <FormDetails
                        value={record}
                        wrappedComponentRef={(inst) => this.formRef = inst}/>
                    {/* <Preview
                        preview={this
                        .preview
                        .bind(this)}/> */}
                </Spin>

            </Modal>

        )
    }

    // 预览
    preview() {
        let form = this.formRef.props.form;
        const formData = form.getFieldsValue();
        return formData;
    }

    // 显示模态框
    show(record) {
        this.setState({isShow: true});
        this.showType = "add";
        if (record) {
            let id = record.id;
            this.setState({detailId: id, loading: true});
            this.showType = "edit";
            api
                .get(`chance/${id}`)
                .then(res => {
                    this.setState({loading: false})
                    if (res.code === 20000) {
                        let details = JSON.parse(JSON.stringify(res.data));
                        if (details.attachPath) {
                            details.attach = [
                                {
                                    uid: -1,
                                    status: 'done',
                                    url: details.attachPath,
                                    name: details.attachName
                                }
                            ]
                        }

                        this.setState({record: details});
                        let roleId = details.department && details.department.length
                            ? details.department[0]
                            : ''
                        this
                            .formRef
                            .onDepartmentChange(roleId);
                    } else {
                        message.error("获取数据失败！");
                    }
                })
                .catch(e => {
                    message.error("获取数据失败！");
                })
        }

    }


    // formatterText (content) {
    //     console.log('content');
        
    //     console.log(content);
        

    //     let finalContent = $('<div></div>');
    //     let div = $('<div></div>').html(content);
    //     let pChildren = div.children('p');
    //     console.log(pChildren);
        
    //     pChildren.each( (index, p) => {
    //         console.log(p);
    //         let text = $(p).text();
    //         console.log(text);
            
    //         finalContent.append($('<span></span>').css({display: 'block', lineHeight: '20px'}).text(text));
    //     })
    //     console.log(finalContent);
        
    //     return finalContent.html();
    // }
    // 提交
    onOk() {

        let form = this.formRef.props.form;
        let formData = form.getFieldsValue();
        let attach = this
            .formRef
            .getFileContent();
        attach = JSON.parse(JSON.stringify(attach));
            console.log(attach)
        if (JSON.stringify(attach) !== '{}') {
            formData.attachName = attach.name;
            formData.attachPath = attach.url;
        } else {
            formData.attachName = '';
            formData.attachPath = '';
        }

        delete formData.attach;
        if (formData.topic.trim().startsWith('<p>') && formData.topic.trim().endsWith('</p>')) {
            formData.topic = formData
                .topic
                .trim()
                .slice(3, -4)
                .trim();
        }
        // formData.topic = this.formatterText(formData.topic);
        formData.businessType = '3';
        
        form.validateFields(valid => {
            if (!valid) {
                if (this.showType === "add") {
                    this.addNewDetails(formData);
                } else {
                    this.editDetails(formData);
                }

            } else {
                message.error('请按红色字段填写内容')
            }
        })

    }

    // 新增机会
    addNewDetails(params) {
        this.setState({btnLoading: true})
        api
            .post(`chance`, params)
            .then(res => {
                this.setState({btnLoading: false})
                if (res.code === 20000) {
                    message.success("新增成功！")
                    this.onCancel();
                    this
                        .props
                        .refreshTable();
                } else {
                    message.error(`新增失败：${res.msg}`);
                }

            })
            .catch(e => {
                console.error(e);
                message.error('新增失败');
            })
    }

    // 编辑机会
    editDetails(params) {
        this.setState({btnLoading: true})
        api
            .put('chance', params, this.state.detailId)
            .then(res => {
                this.setState({btnLoading: false})
                if (res.code === 20000) {
                    message.success("修改成功！");
                    this.onCancel();
                    this
                        .props
                        .refreshTable();
                } else {
                    message.error(`修改失败：${res.msg}`);
                }
            })
            .catch(e => {
                console.error(e);
                message.error('修改失败！');
            })
    }

    // 取消
    onCancel() {
        this
            .formRef
            .props
            .form
            .resetFields();
        this.setState({isShow: false, record: {}})
    }
}

export default DetailModal;