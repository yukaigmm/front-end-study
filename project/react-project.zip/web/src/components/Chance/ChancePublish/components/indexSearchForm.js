import React, {Component} from 'react'
import {Form, Button, Input} from 'antd';

const FormItem = Form.item;


export default class SearchForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            topic: ''
        }
    }

    render() {
        const {getFieldDecorator} = this.props.form;
        let {topic} = this.state;
        return (
            <Form>
                <FormItem label='主题'>
                    {getFieldDecorator('topic',{

                    })(<Input/>)}
                </FormItem>
            </Form>
        )

    }
}