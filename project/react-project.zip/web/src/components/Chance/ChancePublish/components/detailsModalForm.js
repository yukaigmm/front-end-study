import React, {Component} from 'react'



import {
    Form,
    Select,
    Row,
    Col,
    Upload,
    Button,
    Icon,
    message
} from 'antd'
import RichTextEditor from "./richTextEdit.js"
import api from '@/utils/api'

const FormItem = Form.Item;
const Option = Select.Option;

let departmentOptions = [];
api
    .get("common/department")
    .then(res => {
        departmentOptions = JSON.parse(JSON.stringify(res.data));
    });

class ModalForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            departmentOptions,
            personOptions: [],
            attach: {},
            fileList: []
        };
        this.flag = true;
        this.topicEdit = null;
    }

    componentWillMount() {
        this.setState({
            fileList: this.props.value.attach,
            attach: this.props.value.attach && this.props.value.attach.length
                ? this.props.value.attach[0]
                : {}
        })
    }

    render() {
        let {departmentOptions, personOptions} = this.state;
        const {getFieldDecorator} = this.props.form;
        const formItemLayout = {
            labelCol: {
                xs: {
                    span: 24
                },
                sm: {
                    span: 3
                }
            },
            wrapperCol: {
                xs: {
                    span: 24
                },
                sm: {
                    span: 21
                }
            }
        };
        const formItemLayoutInline = {
            labelCol: {
                xs: {
                    span: 24
                },
                sm: {
                    span: 6
                }
            },
            wrapperCol: {
                xs: {
                    span: 24
                },
                sm: {
                    span: 18
                }
            }
        };

        let record = this.props.value;
        const businessTypeMapping = [
            {
                label: "路演",
                value: "1"
            }, {
                label: '货币资金',
                value: '2'
            }, {
                label: '会议',
                value: '3'
            }
        ];
        const chanceTypeMapping = [
            {
                value:'1',
                label:'资金'
            },
            {
                value:'2',
                label:'人才'
            },
            {
                value:'3',
                label:'系统'
            },
            {
                value:'4',
                label:'投研'
            }
        ]
        return (
            <Form>
                <Row gutter={24}>
                    <Col span={24}>
                        <FormItem label='主题' {...formItemLayout}>
                            {getFieldDecorator('topic', {
                                initialValue: `${record.topic || ''}`,
                                rules: [
                                    {
                                        required: true,
                                        message: '主题不能为空'
                                    }, {
                                        validator: (rule, value, callback) => {
                                            let errors = [];
                                            if (value && /^\<p\>[\s]*\<\/p\>$/.test(value.trim())) {
                                                errors.push(new Error("主题不能为空"));
                                            } else {
                                                errors = [];
                                            }
                                            callback(errors)
                                        },
                                        trigger: ['blur', 'change']
                                    }
                                ]
                            })(<RichTextEditor
                                ref={ref => this.topicEdit = ref}
                                height={100}
                                pasteMode={'text'}
                                fontSizes={[]}
                                fontFamilies={[]} 
                                colors ={[]}
                                controls={['undo', 'redo', 'link', 'clear']}
                                uploadUrl={'common/upload'}
                            />)}

                        </FormItem>
                    </Col>
                    {/* <Col span={24}>
                        <FormItem label='详情' {...formItemLayout}>
                            {getFieldDecorator('content', {
                                initialValue: `${record.content || ''}`,
                                // rules: [     {         required: true,         message: '详情不能为空'     },     {
                                //         validator:(rule,value,callback)=>{             let errors = [];
                                //       if(value&&/^\<p\>[\s]*\<\/p\>$/.test(value.trim())){
                                // errors.push(new Error("详情不能为空"));             }else{                errors =
                                // [];             }             callback(errors)         },
                                // trigger:['blur','change']     } ]
                            })(<RichTextEditor
                                extendControls
                                ref={ref => this.detailEditor = ref}
                                uploadUrl={'common/upload'}/>)}
                        </FormItem>
                    </Col> */}
                    <Col span={18}>

                        <Row>
                            <Col span={12}>
                                <FormItem
                                    label='业务负责人'
                                    labelCol={{
                                    xs: {
                                        span: 24
                                    },
                                    sm: {
                                        span: 9
                                    }
                                }}
                                    wrapperCol={{
                                    xs: {
                                        span: 24
                                    },
                                    sm: {
                                        span: 15
                                    }
                                }}>
                                    {getFieldDecorator('department', {
                                        initialValue: `${ (record.department && record.department.length)
                                            ? record.department[0] + ""
                                            : ''}`,
                                        rules: [
                                            {
                                                required: true,
                                                message: '业务负责人不能为空'
                                            }
                                        ]
                                    })(
                                        <Select
                                            onChange={this
                                            .onDepartmentChange
                                            .bind(this)}>
                                            {departmentOptions.map(item => {
                                                return (
                                                    <Option value={item.id + ""} key={item.id}>{item.text}</Option>
                                                )
                                            })}
                                        </Select>
                                    )}
                                </FormItem>
                            </Col>
                            <Col span={10} offset={1}>
                                <FormItem >
                                    {getFieldDecorator('managerId', {
                                        initialValue: record.managerId-0 || "",
                                        rules: [
                                            {
                                                required: true,
                                                message: '业务负责人不能为空'
                                            }
                                        ]
                                    })(
                                        <Select>
                                            {personOptions.map(item => {
                                                return (
                                                    <Option value={item.id -0} key={item.id}>{item.linkman === ""
                                                            ? item.name
                                                            : item.linkman}</Option>
                                                )
                                            })}
                                        </Select>
                                    )}
                                </FormItem>
                            </Col>
                        </Row>
                    </Col>

                    <Col span={12}>
                        <FormItem label='信息类型' {...formItemLayoutInline}>
                            {getFieldDecorator('chanceType', {
                                initialValue: `${record.chanceType || ''}`,
                                rules: [
                                    {
                                        required: true,
                                        message: '信息类型不能为空'
                                    }
                                ]
                            })(
                                <Select placeholder='请选择信息类型'>
                                    {chanceTypeMapping.map(item => {
                                        return (
                                            <Option value={item.value} key={item.value}>{item.label}</Option>
                                        )
                                    })}
                                </Select>
                            )}

                        </FormItem>
                    </Col>

                    {/* <Col span={12}>
                        <FormItem label='业务类型' {...formItemLayoutInline}>
                            {getFieldDecorator('businessType', {
                                initialValue: `${record.businessType || ''}`,
                                rules: [
                                    {
                                        required: true,
                                        message: '业务类型不能为空'
                                    }
                                ]
                            })(
                                <Select placeholder="请选择业务类型">
                                    {businessTypeMapping.map(item => {
                                        return (
                                            <Option value={item.value} key={item.value}>{item.label}</Option>
                                        )
                                    })}
                                </Select>
                            )}
                        </FormItem>
                    </Col> */}

                    <Col span={24}>
                        <FormItem label='附件' {...formItemLayout}>
                            {getFieldDecorator('attach', {
                                initialValue: `${record.attach || ''}`
                            })(
                                <Upload
                                    action='/api/common/upload'
                                    name='chanceAttach'
                                    onChange={this
                                    .onFileChange
                                    .bind(this)}
                                    onPreview={this
                                    .onPreview
                                    .bind(this)}
                                    fileList={this.state.fileList}>
                                    <Button >
                                        <Icon type="upload"/>
                                        上传附件
                                    </Button>
                                </Upload>
                            )}
                        </FormItem>
                    </Col>
                </Row>
            </Form>
        )
    }
    onPreview(file) {
        // let aTag = document.createElement('a') aTag.target = "_blank"; const href =
        // `/api/common/download?fileName=${file.name}&filePath=${file.url}`; aTag.href
        // = href; console.log(aTag) document.body.appendChild(aTag); aTag.click();

        let url = (process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'test')
            ? 'http://fmadmin-test.smppw.com'
            : 'http://fmadmin.simuwang.com';

        window.open(`${url}/api/common/download?fileName=${file.name}&filePath=${file.url}`)
    }

    onFileChange(file) {
        console.log(file)
        let fileList = file.fileList;
        fileList = [fileList.pop()].filter(file => file);
        fileList.map(file => {
            if (file && file.response) {
                if (file.response.code === 20000) {
                    file.url = file.response.data.filePath;
                    message.success('上传成功！');
                    this.setState({
                            attach: Object.assign({
                                name: file.response.data.fileName,
                                url: file.response.data.filePath
                            }, {})
                    })
                } else {
                    message.error('上传失败！');
                }
            }
            return file;
        })
        if (!fileList.length) {
            this.setState(({attach}) => {
                return {attach: {}}
            })
        }
        this.setState({fileList});
    }

    // 获取上传附件内容
    getFileContent() {
        let {attach} = this.state;
        return attach;
    }

    // 部门与人联动
    onDepartmentChange(value) {
        this.setState({personOptions: []});
        let params = {
            'deptId': `${value}`
        }
        //   首次进入不清空后面负责人的值
        if (!this.flag) {
            this
                .props
                .form
                .setFieldsValue({managerId: ''});
        }
        this.flag = false;
        api
            .get("/common/department/user", params)
            .then(res => {
                this.setState({
                    personOptions: JSON.parse(JSON.stringify(res.data))
                })
            })
    }


}

export default ModalForm