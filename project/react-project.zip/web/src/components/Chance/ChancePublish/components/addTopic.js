import React, {Component} from 'react'
import {Input, Icon, message} from 'antd'
import '../css/addTopic.less'

const {TextArea} = Input;

class AddTopic extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectionText: ''
        };
        this.getSelectionText = this
            .getSelectionText
            .bind(this);
    }

    addLink() {
        if (!this.state.selectionText.trim()) {
            message.error("请先选定内容！");
            return;
        }
    }

    getSelectionText() {
        let text;
        if (document.selection) {
            text = document
                .selection
                .createRange()
                .text;
        } else {
            text = window.getSelection() + ''
        }
        this.setState({selectionText: text})
    }

    clearContent() {}

    render() {
        let {value} = this.props;
        return (
            <div>
                <div className="top-bar">
                    <ul>
                        <li
                            title='添加链接'
                            onClick={this
                            .addLink
                            .bind(this)}><Icon type="link"/></li>
                        <li
                            title='清除内容'
                            onClick={this
                            .clearContent
                            .bind(this)}>清除内容</li>
                    </ul>
                </div>
                <TextArea defaultValue={value} onSelect={this.getSelectionText}></TextArea>
            </div>
        )
    }
}

export default AddTopic;