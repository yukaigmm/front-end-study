import React, {Component} from 'react'
import {
    Table,
    Button,
    message,
    Modal,
    Pagination,
    Input
} from 'antd'
import ReactHtmlParser from 'react-html-parser';
// import './css/index.css'
import './css/index.less'
import api from '@/utils/api.js'
import DetailModal from './components/detailModal.js'
// import SearchForm from "./components/indexSearchForm.js"
const Search = Input.Search;
class ChancePublish extends Component {
    constructor(props) {
        super(props);
        this.editChance = this
            .editChance
            .bind(this);
        this.deleteChance = this
            .deleteChance
            .bind(this);
        this.addChance = this
            .addChance
            .bind(this)
        this.getKeywords = this.getKeywords.bind(this);
        this.setTableHeight = this.setTableHeight.bind(this);
        this.state = {
            tableHeight:0,
            total: 0,
            modalTitle: '详情',
            loading: true,
            dataSource: [],
            columns: [
                {
                    title: '主题',
                    dataIndex: 'topic',
                    key: 'topic',
                    width: 200,
                    render(text, record, index) {
                        return (
                            <React.Fragment>
                                {ReactHtmlParser(record.topic)}
                            </React.Fragment>
                        )
                    }
                }, {
                    title: '发布时间',
                    dataIndex: 'createtime',
                    key: 'createtime',
                    width: 60,
                    render(text, record, index) {

                        let time = record.createtime
                            ? record
                                .createtime
                                .slice(0, 10)
                            : '--';
                        let createTime = time === '0000-00-00'
                            ? "--"
                            : time;
                        return (
                            <React.Fragment>
                                {createTime}
                            </React.Fragment>
                        )
                    }
                }, {
                    title: '发布人',
                    dataIndex: 'creator',
                    key: 'creator',
                    width: 60
                }, {
                    title: '负责人',
                    dataIndex: 'manager',
                    key: 'manager',
                    width: 60,
                    render(text, record, index) {
                        return (
                            <React.Fragment>
                                {record.manager || '--'}
                            </React.Fragment>
                        )
                    }
                }, {
                    title: '信息类型',
                    dataIndex: 'chanceType',
                    key: 'chanceType',
                    width: 50,
                    render(text, record, index) {
                        let mapping = {
                            "1": "资金",
                            "2": "人才",
                            "3": "系统",
                            "4": "投研"
                        };
                        return (
                            <React.Fragment>{mapping[record.chanceType] || '--'}</React.Fragment>
                        )
                    }
                }, 
                // {
                //     title: '业务类型',
                //     dataIndex: 'businessType',
                //     key: 'businessType',
                //     width: 60,
                //     render(text, record, index) {
                //         let mapping = {
                //             "1": "路演",
                //             "2": "货币资金",
                //             "3": "会议"
                //         };
                //         return (
                //             <React.Fragment>{mapping[record.businessType] || '--'}</React.Fragment>
                //         )
                //     }
                // }, 
                {
                    title: '操作',
                    dataIndex: 'action',
                    key: 'action',
                    width: 80,
                    render: (text, record, index) => {
                        return (
                            <div>
                                <Button
                                    className='button-edit'
                                    type="primary"
                                    size='small'
                                    onClick={this
                                    .editChance
                                    .bind(this, record)}>
                                    编辑
                                </Button>

                                <Button
                                    className='button-delete'
                                    type="primary"
                                    size='small'
                                    onClick={this
                                    .deleteChance
                                    .bind(this, record)}>
                                    删除
                                </Button>
                            </div>
                        )
                    }
                }
            ],
            topic: '',
            pageSize: 10,
            pageNo: 1
        }
    }

    render() {

        let {
            columns,
            dataSource,
            loading,
            modalTitle,
            pageNo,
            total,
            tableHeight,
            tableScroll
        } = this.state;

        return (
            <div className='content-container chance-content'>
                {/* <div className='search-area'>
                    <Search
                        placeholder='请输入关键字'
                        onSearch={this
                        .search
                        .bind(this)}
                        enterButton="搜索"
                        style={{
                        width: 300
                    }}></Search>

                </div> */}
                <div className="chance-table-container">
                    <div className="keyword-search-area clearfix">
                        <input className="keyword-input search-input" placeholder="输入关键字搜索" onBlur={this.getKeywords.bind(this)} onKeyUp={this.searchAccountByKeyUp.bind(this)}/>
                        <Button className="keyword-button" type="primary" size="small" onClick={this.searchAccount.bind(this)}>搜索</Button>
                        <Button type='primary' size="small" className="add-chance-button" onClick={this.addChance}>添加</Button>
                    </div>
                    <Table
                        bordered
                        size='small'
                        columns={columns}
                        pagination={false}
                        dataSource={dataSource}
                        loading={loading}
                        rowKey={record => record.id}
                        scroll={{
                        y: tableScroll?tableHeight:false
                    }}></Table>
                    <Pagination
                        size="small"
                        showTotal={total => `共 ${total} 条`}
                        showSizeChanger
                        showQuickJumper
                        onChange={this
                        .pageChange
                        .bind(this)}
                        onShowSizeChange={this
                        .pageSizeChange
                        .bind(this)}
                        defaultCurrent={pageNo}
                        total={total}/>
                </div>

                <DetailModal
                    ref={ref => this.detailModal = ref}
                    modalTitle={modalTitle}
                    refreshTable={this
                    .getTableData
                    .bind(this)}></DetailModal>

            </div>
        )
    }

    componentWillMount() {
        this.getTableData();
    }

    componentDidMount() {
        this.setTableHeight();
        window.addEventListener('resize',this.setTableHeight)
    }

    componentWillUnmount() {
        window.removeEventListener('resize',this.setTableHeight)
    }

    // 分页变化
    pageChange(page, pageSize) {
        new Promise((resolve) => {
            this.setState({pageNo: page})
            resolve()
        }).then(() => {
            this.getTableData();
        })

    }

    pageSizeChange(page, pageSize) {
        new Promise(resolve => {
            this.setState({pageSize,pageNo:1});
            resolve()
        }).then(() => {
            this.getTableData();
        })

    }


    // 动态设置表格高度
    setTableHeight(){
        if(this.chanceTimer){
            clearTimeout(this.chanceTimer);
        }
        let stuffAccountTableHeight;
        let _this = this;
        this.chanceTimer = setTimeout(() => {
            if(document.querySelector('.chance-content')){
                stuffAccountTableHeight = document.querySelector('.chance-content').offsetHeight - 
                document.querySelector('.chance-content .keyword-search-area').offsetHeight -130;
            }
            if(document.querySelector('.chance-content .ant-table-tbody').offsetHeight< stuffAccountTableHeight){
                this.setState({
                    tableScroll: false
                })
            }else{
                this.setState({
                    tableScroll: true
                })
            }
            this.setState({
                tableHeight:stuffAccountTableHeight
            })
        }, 100);
  }

    // 获取列表
    getTableData() {
        let params = {
            topic: this.state.topic,
            pageNo: this.state.pageNo,
            pageSize: this.state.pageSize
        }
        this.setState({loading: true})
        api
            .get('chance', params)
            .then(res => {
                this.setState({loading: false});
                if (res.code === 20000) {
                    this.setState({
                        total: res.data.total,
                        loading: false,
                        dataSource: JSON.parse(JSON.stringify(res.data.records))
                    },()=>{
                        this.setTableHeight()
                    });
                } else {
                    message.error('获取列表失败！')
                }
            })
    }

    // 删除机会
    deleteChance(record) {
        const that = this;
        Modal.confirm({
            cancelText: '取消',
            okText: '确定',
            title: '删除',
            content: '确定删除此条机会吗？',
            onOk() {
                let id = record.id;
                return new Promise((resolve, reject) => {
                    api
                        .del('chance', `${id}`)
                        .then(res => {
                            if (res.code === 20000) {
                                message.success('删除成功！');
                                that.getTableData();
                                resolve();
                            } else {
                                message.error('删除失败！');
                                resolve();
                            }
                        })

                })
            }
        })
    }

    // 编辑机会
    editChance(record) {
        this.setState({modalTitle: '编辑'});
        this
            .detailModal
            .show(record);
    }

    // 新增机会
    addChance() {
        this.setState({modalTitle: '添加'});
        this
            .detailModal
            .show();
    }
    // 获取搜索框字段
    getKeywords(e){
        this.setState({
            topic:e.target.value
        })
    }
    // 搜素框回车
    searchAccountByKeyUp(e){
        if(e.keyCode === 13){
            this.setState({
                topic:e.target.value,
                pageNo:1,
                pageSize:10
            },()=>{
                this.getTableData()
            })
        }
    }
    searchAccount(){
        this.setState({
            pageNo:1,
            pageSize:10
        },()=>{
            this.getTableData()
        })
    }

}

export default ChancePublish;