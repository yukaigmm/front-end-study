import React, {Component} from 'react'
import api from '@/utils/api'
import {message, Spin} from 'antd'

class HandleDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            details: {
                companyName: '平安集团',
                accountName: 'moumou',
                account: '15656565656',
                content: '这里是具体的内容。。。。'
            }
        };
    }

    render() {
        let {details, loading} = this.state
        return (
            <div className='details-container'>
                <Spin spinning={loading} delay={100}>
                    <div>
                        <span className="label">所属公司:</span>
                        <span>{details.companyName || '--'}</span>
                    </div>

                    <div className='contact-account-container'>
                        <div className="account-container">
                            <span className="label">账号:</span>
                            <span>{details.account || '--'}</span>
                        </div>
                        <div className="contact-container">
                            <span className="label">联系人:</span>
                            <span>{details.accountName || '--'}</span>
                        </div>

                    </div>

                    <div className='details-content-container'>
                        <span className="label content-label">内容:</span>
                        <div className="content">{details.content || '--'}</div>
                    </div>
                </Spin>
            </div>
        )
    }

    // 获取数据
    getData(id) {
        this.setState({loading: true})
        api
            .get(`/handle/chance/msg/${id}`)
            .then(res => {
                this.setState({loading: false})
                if (res.code === 20000) {
                    let data = JSON.parse(JSON.stringify(res.data));
                    this.setState({details: data})
                } else {
                    message.error(`获取数据失败：${res.msg}`)
                }
            })
            .catch(e => {
                this.setState({loading: false})
                console.error(e);
                message.error(`获取数据失败`);
            })
    }
}

export default HandleDetails