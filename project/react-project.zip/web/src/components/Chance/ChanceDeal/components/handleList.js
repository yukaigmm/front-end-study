import React, {Component} from 'react'
import api from "@/utils/api"
import {message, Spin} from "antd"
import HandleDetails from "./handleDetails"

class HandleList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            handleList: []
        }
    }

    render() {
        let {handleList, loading} = this.state;
        let ToHandleList = handleList.map(item => {
            return (
                <div className='single-record-container' key={item.id}>
                    <p>
                        <span>公司：{item.companyName || '--'}</span>
                        <span>联系人：{item.contact || '--'}</span>
                    </p>
                    < div className='single-content-container'>
                        {item.content || '暂无内容'}
                    </div>
                </div >
            )
        })

        ToHandleList = ToHandleList.length
            ? ToHandleList
            : (
                <span className='no-data-container'>暂无数据</span>
            );
        return (
            <div>
                <div className='handle-list-container'>
                    <Spin spinning={loading} delay={100}>
                        {ToHandleList}
                    </Spin>
                </div>
            </div>

        )
    }

    // 点击具体主题 onClick(id) {     this         .handleDetails         .getData(id); }
    // 获取主题列表
    getData(id) {
        this.setState({loading: true})
        api
            .get(`handle/chance/${id}`)
            .then(res => {
                this.setState({loading: false})
                if (res.code === 20000) {
                    let data = JSON.parse(JSON.stringify(res.data.records));
                    this.setState({handleList: data});
                    // if(data.length){     this.handleDetails.getData(data[0].id) }
                } else {
                    message.error(`获取数据失败：${res.msg}`);
                }
            })
            .catch(e => {
                this.setState({loading: false})
                console.error(e);
                message.error(`获取数据失败`);
            })
    }
}

export default HandleList;