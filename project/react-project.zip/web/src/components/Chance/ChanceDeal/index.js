import React, {Component} from 'react'
import {Row, Col, Table,  message} from 'antd'
import ReactHtmlParser from "react-html-parser"
import HandleList from "./components/handleList"


import api from "@/utils/api"
import './css/index.less'

class ChanceDeal extends Component {
    constructor(props) {
        super(props);
        this.getTableData = this
            .getTableData
            .bind(this)
        this.state = {
            loading: false,
            dataSource: [],
            columns: [
                {
                    title: "主题",
                    dataIndex: 'topic',
                    key: 'topic',
                    width:200,
                    render(text,record,index){
                        return (
                            <React.Fragment>
                              {
                                  ReactHtmlParser(record.topic)
                              }
                            </React.Fragment>
                        )
                    }
                }, {
                    title: '联系次数',
                    dataIndex: 'contactCounts',
                    key: 'contactCounts',
                    width:60
                }, {
                    title: '未读数',
                    dataIndex: 'unreadCounts',
                    key: 'unreadCounts',
                    width:60
                }, {
                    title: '收藏数',
                    dataIndex: 'starCounts',
                    key: 'starCounts',
                    width:60
                }
            ]
        };
    }

    componentWillMount() {
        this.getTableData();
    }

    render() {
        let {loading, columns, dataSource} = this.state;
        return (
            <div className='chance-deal-container'>
                <Row>
                    <Col span={12}>
                        <Table
                            bordered
                            size='small'
                            columns={columns}
                            dataSource={dataSource}
                            loading={loading}
                            onRow={record => {
                            return {
                                onClick: () => {
                                    this.onClickTableRow(record.id)
                                }
                            }
                        }}
                            rowKey={record => record.id}/>
                    </Col>

                    <Col span={11} offset={1}>
                        <HandleList ref={ref => this.handList = ref}/>
                    </Col>
                </Row>
            </div>
        )
    }

    // 点击单行表格
    onClickTableRow(id) {
        this
            .handList
            .getData(id);
    }

    // 获取表格数据
    getTableData() {
        this.setState({loading: true})
        api
            .get('handle/chance')
            .then(res => {
                if (res.code === 20000) {
                    let data = JSON.parse(JSON.stringify(res.data.records));
                    this.setState({dataSource: data})
                    this.setState({loading: false})
                    if (data.length) {
                        this
                            .handList
                            .getData(data[0].id)
                    }
                } else {
                    this.setState({loading: false})
                    message.error(`获取列表失败：${res.msg}`);
                }
            })
            .catch(e => {
                this.setState({loading: false})
                console.error(e);
                message.error(`获取列表失败`);
            })
    }

}

export default ChanceDeal;