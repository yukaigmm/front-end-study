 
import React, { Component } from 'react';


class Chance extends Component {
  render () {
    return (
      <div>Chance</div>
    )
  }
}

export default Chance;