import {Modal,message,Spin} from 'antd';
import React,{Component} from 'react';
import BannerModalForm from './ModalForm.js';
import ReactHtmlParser from 'react-html-parser';
import api from '../../utils/api';
import moment from "moment"

class BannerModal extends Component{
    render(){
        let {openStatus} = this.props;
        let {
            loading,
            clearUpload
        } = this.state;
        return (
            <Modal
                className="add-edit-modal"
                visible={openStatus} 
                wrapClassName="add-edit-modal-container"
                onCancel={this.cancel}
                onOk={this.submit}
                title="新增banner图"
                >
                <Spin spinning={loading}>
                    <BannerModalForm clearUpload={clearUpload} wrappedComponentRef={this.getFormRef}/>
                </Spin>
            </Modal>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            loading: false,
            clearUpload: false,
        }
    }
    componentWillReceiveProps = (props) =>{
        if(props.openStatus){
            this.setState({
                clearUpload: false
            })
            if(props.status === "add"){
                setTimeout(() => {
                    this.form.setFieldsValue({
                        bannerType: 1
                    })
                }, 100);
            }
            if(props.status === "edit"){
                this.setState({
                    loading: true
                })
                api.get(`banner/${props.currentBannerId}`).then((res) => {
                    let {
                        bannerType,
                        bannerLink,
                        imageTitle,
                        imageUrl,
                        bannerStatus,
                        beginDate,
                        endDate
                    } = res.data;
                    this.form.setFieldsValue({
                        bannerType,
                        bannerLink,
                        imageTitle,
                        imageUrl,
                        bannerStatus,
                        beginDate: beginDate ? moment(beginDate) : null,
                        endDate: endDate ? moment(endDate) : null
                    });
                    this.setState({
                        loading: false
                    })
                })
            }
        }
    }
    submit = () => {
        let submitData = this.getSubmitData();
        this.form.validateFields((error,value) => {
            if(error === null){
                this.setState({
                    loading: true
                })
                let url, method;
                if(this.props.status === "add"){
                    url = "banner";
                    method = "post";
                }else if(this.props.status === "edit"){
                    url = "banner/"+this.props.currentBannerId;
                    method = "put";
                }
                api[method](url, submitData).then((res) => {
                    this.setState({
                        loading: false
                    })
                    if(res && res.code === 20000){
                        message.success("提交成功")
                        this.cancel();
                        this.props.getTableData()
                    }else{
                        message.error(res.msg ? res.msg : "提交失败，请重试或联系管理员");
                    }
                }, () => {
                    this.setState({
                        loading: false
                    })
                })
            }else{
                message.error("请按照提示填写必填内容");
            }
        })
    }
    // 接口要求：字段没有值的时候，要么不传该字段，要么传 null
    getSubmitData = () => {
        let data = this.form.getFieldsValue();
        
        let {beginDate, endDate} = data;
        beginDate = beginDate ? beginDate.format("YYYY-MM-DD") : null;
        endDate = endDate ? endDate.format("YYYY-MM-DD") : null;
        for(let key in data){
            if(data[key] === undefined){
                delete data[key];
            }
        }
        return Object.assign({}, data, {
            beginDate, endDate
        })
    }
    // 取消审核
    cancel = () => {
        this.form.resetFields();
        
        this.setState({
            clearUpload: true
        });
        this.props.closeModal();
    }
    // 获取表单ref
    getFormRef = (formRef) => {
        if(formRef){
            this.form = formRef.props.form;
        }
    }
}
export default BannerModal;