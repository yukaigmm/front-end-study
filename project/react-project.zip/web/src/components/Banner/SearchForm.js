import React,{Component} from 'react';
import {Form,Select,Input} from 'antd';
const FormItem = Form.Item;
const Option = Select.Option;

class FormSearch extends Component{
    render(){
        const {getFieldDecorator} = this.props.form;
        let {
            bannerStatusOption,
        } = this.state;
        return (
            <Form layout="inline">
                <FormItem>
                    {
                        getFieldDecorator('bannerStatus',{
                            initialValue:0
                        })(<Select size="small" style={{width: 120}} onChange={this.optionsChange.bind(this)}>
                            {bannerStatusOption.map(item=><Option value={item.value} key={item.value}>{item.label}</Option>)}
                            </Select>)
                    }
                </FormItem>
                <FormItem>
                    {
                        getFieldDecorator('keyWord',{
                        })(<Input className="search-input" placeholder="请输入关键字"/>)
                    }
                </FormItem>
            </Form>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            bannerStatusOption:[
                {label:'全部', value: 0},
                {label: "正常", value: 1},
                {label: "作废", value: 2}
            ],
        }
    }
    optionsChange(value){
        let _this = this;
        // 需要异步获取，否则获取的是上一步的formValue
        setTimeout(() => {
            _this.props.searchRoadshow();
        }, 100);
    }
}
const SearchForm = Form.create({})(FormSearch);
export default SearchForm;