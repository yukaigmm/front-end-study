import {Form,Radio,Input,Row,Col,DatePicker} from 'antd';
import React,{Component} from 'react';
import { callbackify } from 'util';
import UploadImg from "./UploadImg.js"
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const {TextArea} = Input;
class ModalForm extends Component{
    render(){
        const {getFieldDecorator} = this.props.form;
        const formItemLayout = {
            labelCol: {
                span: 6 ,
            },
            wrapperCol: {
                span: 18 ,
            },
        };
        let {fileList} = this.state;
        let {clearUpload} = this.props;
        return (
            <Form className="roadshow-modal-form" onReset={this.onReset()}>
                <Row>
                    <Col span={12}>
                        <FormItem label="图片名称" {...formItemLayout}>
                            {
                                getFieldDecorator('imageTitle')(<Input/>)
                            }
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={24}>
                        <FormItem label="图片上传" {...formItemLayout}>
                            {
                                getFieldDecorator('imageUrl',{
                                    rules:[
                                        {required:true,message:'请上传图片'}
                                    ]
                                })(<UploadImg 
                                    data={{fileType: "bannerImages"}} 
                                    name="chancePic"
                                    limit="1"
                                    fileList={fileList}
                                    clearUpload={clearUpload}
                                    handleChange={this.uploadChange}
                                    />)
                            }
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={24}>
                        <FormItem label="广告链接" {...formItemLayout}>
                            {
                                getFieldDecorator('bannerLink')(<Input/>)
                            }
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={12}>
                        <FormItem label="广告类型" {...formItemLayout}>
                            {
                                getFieldDecorator('bannerType')
                                (<RadioGroup 
                                    options={[{label: "首页广告",value: 1}]}
                                />)
                            }
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="图片状态" {...formItemLayout}>
                            {
                                getFieldDecorator('bannerStatus')
                                (<RadioGroup 
                                    options={[{label: "正常",value: 1},{label: "作废",value: 2}]} 
                                />)
                            }
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={12}>
                        <FormItem label="开始时间" {...formItemLayout}>
                            {
                                getFieldDecorator('beginDate')
                                (<DatePicker/>)
                            }
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="结束时间" {...formItemLayout}>
                            {
                                getFieldDecorator('endDate')
                                (<DatePicker/>)
                            }
                        </FormItem>
                    </Col>
                </Row>
            </Form>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            fileList: [],
        }
    }
    componentWillReceiveProps(props){
        if(props.clearUpload){
            this.setState({
                fileList: []
            })
        }else{
            let formValue = this.props.form.getFieldsValue();
            if(formValue.imageUrl && this.state.fileList.length == 0){
                let serve = process.env.NODE_ENV === "production" ? "http://static.simuwang.com":"https://static-test.simuwang.com"
                this.setState({
                    fileList:[{
                        uid: -11,
                        name:"test.png",
                        url:`${serve}${formValue.imageUrl}`
                    }]
                })
            }
        }
    }
    uploadChange = ({fileList, file}) => {
        this.setState({fileList});
    }
    onReset = () => {
    }
}
const RoadshowModalForm = Form.create({})(ModalForm);
export default RoadshowModalForm;