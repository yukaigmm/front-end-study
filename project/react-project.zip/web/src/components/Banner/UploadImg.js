import { Upload, Icon, Modal } from 'antd';
import React,{Component} from 'react';
class PicturesWall extends React.Component {
    // static getDerivedStateFromProps(nextProps) {
    //     // Should be a controlled component.
    //     if ('value' in nextProps) {
    //         return {
    //         ...(nextProps.value || {}),
    //         };
    //     }
    //     return null;
    // }
  state = {
    previewVisible: false,
    previewImage: '',
  };
  handleCancel = () => this.setState({ previewVisible: false })

  handlePreview = (file) => {
    this.setState({
      previewImage: file.url || file.thumbUrl,
      previewVisible: true,
    });
  }

  handleChange = (params) => {
    if(params.file.response && params.file.response && params.file.response.data.filePath){
        this.triggerChange(params.file.response.data.filePath)
    }
    this.props.handleChange(params);
  }
  triggerChange = (changedValue) => {
    const onChange = this.props.onChange;
    if (onChange) {
      onChange(changedValue);
    }
  }
  componentWillReceiveProps(props){
      if(props.clearUpload){
        //   this.
      }
  }
  render() {
    const { previewVisible, previewImage } = this.state;
    const {data, name, limit, fileList, value} = this.props;
    const uploadButton = (
      <div>
        <Icon type="plus" />
        <div className="ant-upload-text">Upload</div>
      </div>
    );
    return (
      <div className="clearfix">
        <Upload
          action="api/common/upload"
          listType="picture-card"
          name={name}
          data={data}
          fileList={fileList}
          onPreview={this.handlePreview}
          onChange={this.handleChange}
        >
          {fileList.length >= limit ? null : uploadButton}
        </Upload>
        <Modal visible={previewVisible} footer={null} onCancel={this.handleCancel}>
          <img alt="example" style={{ width: '100%' }} src={previewImage} />
        </Modal>
      </div>
    );
  }
}

// ReactDOM.render(<PicturesWall />, mountNode);
export default PicturesWall