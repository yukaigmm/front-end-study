import {Button,Pagination,message,Modal} from 'antd';
import React,{Component} from 'react';
import AddEditModal from './AddEditModal.js'
import SearchForm from './SearchForm';
import api from '../../utils/api';
import './index.less';
import DragableTable from "./DragableTable.js";
import update from 'immutability-helper';
// import {observer,inject} from 'mobx-react';
const confirm = Modal.confirm;
// @inject('optionStore')
// @observer
class Banner extends Component{
    render(){
        let {
            dataSource,
            columns,
            addEditModalStatus,
            tableParams,
            total,
            rowData,
            tableLoading,
            tableHeight,
            tableScroll,
            status,
            currentBannerId
        } = this.state;
        return (
            <div className="content-container roadshow-content">
                <div className="roadshow-table-container">
                    <div className="keyword-search-area">
                        <SearchForm
                            wrappedComponentRef={this.getFormRef}
                            search={this.search}
                        />
                        <Button onClick={this.search} type="primary" className="keyword-button">搜索</Button>
                        <Button onClick={this.addBanner} type="primary" className="add-button">添加</Button>
                    </div>
                    <div className="table-container">
                        <DragableTable
                            columns={columns}
                            data={dataSource}
                            loading={tableLoading}
                            pagination={false}
                            rowKey={(record) => {return record.id}}
                            scroll={{y:tableScroll ? tableHeight :false,x:1200}}
                            updateRow={this.updateRow.bind(this)}
                        />
                        <Pagination 
                            size="small" 
                            showSizeChanger 
                            showQuickJumper 
                            onChange={this.pageChange} 
                            onShowSizeChange={this.pageSizeChange} 
                            total={total} 
                            current={tableParams.pageNo} 
                            pageSize={tableParams.pageSize}
                        />
                        <div className="roadshow-modal-conainer">
                            <AddEditModal
                                openStatus={addEditModalStatus}
                                bannerId={rowData.id}
                                closeModal={this.closeAddEditModal}
                                getTableData={this.getTableData}
                                status={status}
                                currentBannerId={currentBannerId}
                            />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
    constructor(props){
        super(props);
        this.state = {
            // table
            dataSource:[],
            columns:[
                {
                    title:'图片名称',
                    dataIndex:'imageTitle',
                    key:'imageTitle',
                    width: 200
                },
                {
                    title:'图片地址',
                    dataIndex:'imageUrl',
                    key:'imageUrl',
                    width: 200,
                    render: (text, row, index) => {
                        let serve = process.env.NODE_ENV === "production" ? "http://static.simuwang.com":"https://static-test.simuwang.com"
                        return (
                            row.imageUrl ? <img style={{width: "100px"}} src={`${serve}${row.imageUrl}`} /> : ""
                        )
                    }
                },
                {
                    title:'广告链接',
                    dataIndex:'bannerLink',
                    key:'bannerLink',
                    width: 200
                },
                {
                    title:'图片状态',
                    dataIndex:'bannerStatus',
                    key:'bannerStatus',
                    width: 100,
                    render: (text, row, index) => {
                        let map = {
                            1: '正常',
                            2: '作废',
                        }
                        return (
                            <span>{map[row.bannerStatus]}</span>
                        )
                    }
                },
                {
                    title:'开始时间',
                    dataIndex:'beginDate',
                    key:'beginDate',
                    width: 240
                },
                {
                    title:'结束时间',
                    dataIndex:'endDate',
                    key:'endDate',
                    width: 240,
                },
                {
                    title: "操作",
                    dataIndex: "action",
                    key: "action",
                    width: 240,
                    render: (text, row, index) => {
                        return (
                            <div>
                                <Button onClick={() =>{this.editBanner(row.id)}} type="primary" className="edit-button">编辑</Button>
                                <Button onClick={() =>{this.delBanner(row.id)}} type="primary" className="del-button">删除</Button>
                            </div>
                        )
                    }
                }
            
            ],
            tableParams:{
                keyWord:'',
                bannerType:1,
                bannerStatus:0,
                pageNo:1,
                pageSize:10,
            },
            total:1,
            tableLoading:false,
            tableHeight:0,
            tableScroll:false,
            // modal
            addEditModalStatus:false,
            status: "add",
            currentBannerId: "",
            rowData:{},
        };
        this.pageSizeChange = this.pageSizeChange.bind(this);
        this.pageChange = this.pageChange.bind(this);
        this.getFormRef = this.getFormRef.bind(this);
        this.search = this.search.bind(this);
        this.setTableHeight = this.setTableHeight.bind(this);
    }
    componentWillMount(){
        this.getTableData();
    };
    componentDidMount(){
        this.setTableHeight();
        window.addEventListener('resize',this.setTableHeight);
    }
    componentWillUnmount(){
        window.removeEventListener('resize',this.setTableHeight)
    }
    // 获取tableData
    getTableData = () => {
        this.setState({tableLoading:true})
        api.get('banner',this.state.tableParams).then(res=>{
            if(res.code === 20000){
                this.setState({
                    dataSource:res.data.records.concat(),
                    total:res.data.total,
                    tableLoading:false
                },
                ()=>{
                    this.setTableHeight()
                }
            )
            }else{
                this.setState({
                    tableLoading:false
                })
            }
        })
    }
    // 拖拽排序回调
    updateRow(dragIndex,hoverIndex,dragRow){
        this.setState(
            update(this.state, {
                dataSource: {
                    $splice: [
                        [dragIndex, 1],
                        [hoverIndex, 0, dragRow]
                    ],
                },
            })
        ,() => {
            this.setOrder();
        });
    }
    // 设置 banner 排序
    setOrder(){
        let data = this.state.dataSource.map((item) => {
            return item.id;
        });
        api.put("banner/order", {banner: data}).then((res) => {
            if(res.code === 20000){
                message.success("排序成功")
            }
        })
    }
    // 根据搜索条件获取tableData
    search(){
        let formValue = this.form.getFieldsValue();
        this.setState({
            tableParams:Object.assign({},this.state.tableParams,formValue,{
                pageNo:1,
                pageSize:10
            })
        },()=>{
            this.getTableData()
        })

    }
    // 新增 banner 图
    addBanner = () => {
        this.setState({
            addEditModalStatus: true,
            status: "add"
        })
    }
    // 修改 banner 图
    editBanner = (id) => {
        
        this.setState({
            addEditModalStatus: true,
            status: "edit",
            currentBannerId: id
        })
    }
    // 删除 banner 图
    delBanner = (id) => {
        let that = this;
        Modal.confirm({
            cancelText: '取消',
            okText: '确定',
            title: '删除',
            content: '确定删除此条banner吗？',
            onOk() {
                return new Promise((resolve, reject) => {
                    api.del('banner', `${id}`)
                        .then(res => {
                            if (res.code === 20000) {
                                message.success('删除成功！');
                                that.getTableData();
                                resolve();
                            } else {
                                message.error('删除失败！');
                                resolve();
                            }
                        })

                })
            }
        })
    }
   
    closeAddEditModal = () =>{
        this.setState({
            addEditModalStatus:false
        })
    }
    // 分页变化
    pageChange(page,pageSize){
        this.setState(
            {tableParams:{...this.state.tableParams,pageNo:page}},
            ()=>{
                this.getTableData();
            }
        )
    }
    pageSizeChange(page,pageSize){
        this.setState(
            {tableParams:{...this.state.tableParams,pageSize,pageNo:1}},
            ()=>{
                this.getTableData();
            }
        )
    }
    // 获取搜索表单的ref
    getFormRef(formRef){
        if(formRef){
            this.form = formRef.props.form;
        }

    }
    // 设置表格自适应高度
    setTableHeight(){
        if(this.roadshowTimer){
            clearTimeout(this.roadshowTimer);
        }
        let tableHeight;
        let _this = this;
        // let tableInnerHeight = document.querySelector('.ant-table-body .ant-table-fixed').offsetHeight;
        this.roadshowTimer = setTimeout(() => {
            // 设置table滚动高度
            if(document.querySelector('.roadshow-table-container')){
                tableHeight = document.querySelector('.roadshow-table-container').offsetHeight - 140;
            }
            if(document.querySelector('.ant-table-body .ant-table-tbody').offsetHeight - tableHeight + 20 < 0){
                _this.setState({
                    tableScroll:false
                })
            }else{
                _this.setState({
                    tableScroll:true
                })
            }
            _this.setState({tableHeight:tableHeight})
        }, 100);
    }
}
export default Banner;