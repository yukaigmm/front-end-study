
import React, { Component } from 'react';
import { Provider } from 'mobx-react';
import './App.less';


import AppHeader from './layout/AppHeader';
import AppMenu from './layout/AppMenu';
// import AppContent from './layout/AppContent';

import { Layout } from 'antd';

import { HashRouter, Route, Switch, Redirect } from 'react-router-dom';
import routes from './route';
import Login from './components/Login/Login';
import api from './utils/api';

import stores from './stores';

const { Header, Sider, Content } = Layout;


// 路由设置
class App extends Component {
  render() {
    return (
      <HashRouter>
        <Provider {...stores}>
          <div className="App">
            <Switch>
              <Route path="/login" component={Login}/>
              <Route path="/index" component={MainPage}/>
              <Redirect to="/index" />
            </Switch>
          </div>
        </Provider>
      </HashRouter>
    );
  }
}

// 主页页面及二级路由设置
class MainPage extends Component{
  render(){
    return (
      <div className="App">
          <Header className="header">
            <AppHeader userName={this.state.userName} history={this.props.history}></AppHeader>
          </Header>
          <Layout className="body">
            <Sider className="sider" width={160}>
              <AppMenu match={this.props.match}></AppMenu>
            </Sider>
            <Content className="content">
                <Switch>
                  {routes.map((route, idx) => {
                      return route.component ? (<Route key={idx} path={`${this.props.match.url}${route.path}`} exact={route.exact} name={route.name} render={props => (
                          <route.component {...props} />
                        )} />)
                        : (null);
                    },
                  )}
                  <Redirect to="/index/roadshow"/>
                </Switch>
            </Content>
          </Layout>
        </div>
    )
  }
  constructor(props){
    super(props);
    this.state = {
      userName:''
    }
    this.getUserName = this.getUserName.bind(this);
  }
  componentDidMount(){
    this.getUserName()
    // 检查登录状态，如果未登录，就跳转到登录页面
    api.get('user/checkInfo').then(res=>{
      if(res.code !== 20000){
        this.props.history.push('/login')
      }else{
        window.localStorage.setItem('userName',res.data.trueName)
      }
    })
  }
  // 从storage获取用户名
  getUserName(){
    let userName = window.localStorage.getItem('userName');
    this.setState({userName:userName});
  }
}

export default App;
