
// import Home from '@/components/Home/Home';
// import Account from '@/components/Account/Account';
// // import Chance from '@/components/Chance/Chance/index';
// import ChancePublish from '@/components/Chance/ChancePublish/index';
// import ChanceDeal from '@/components/Chance/ChanceDeal/index';
// import Roadshow from '@/components/Roadshow/Roadshow';


// const routes = [
//   // { path: '/home', exact: true, name: 'Home', component: Home },
//   { path: '/account', name: 'Account', component: Account },
//   { path: '/chancePublish', name: 'chancePublish', component: ChancePublish },
//   // { path: '/chanceDeal', name: 'ChanceDeal', component: ChanceDeal },
//   { path: '/roadshow', name: 'Roadshow', component: Roadshow },
// ]

import Loadable from 'react-loadable';
import React from 'react';



class Loading extends React.Component {
  render () {
    return <div></div>
  }
}


const LoadableAccount = Loadable({
  loader: () => import('@/components/Account/Account'),
  loading: Loading
})
const LoadableChancePublish = Loadable({
  loader: () => import('@/components/Chance/ChancePublish/index'),
  loading: Loading
})
const LoadableRoadshow = Loadable({
  loader: () => import('@/components/Roadshow/Roadshow'),
  loading: Loading
})
const LoadableNews = Loadable({
  loader: () => import('@/components/News/News'),
  loading: Loading
})
const LoadableBanner = Loadable({
  loader: () => import('@/components/Banner/index'),
  loading: Loading
})
const LoadableMessage = Loadable({
  loader: () => import('@/components/Message/index'),
  loading: Loading
})

class Account extends React.Component {
  render () {
    return <LoadableAccount />
  }
}

class ChancePublish extends React.Component {
  render () {
    return <LoadableChancePublish />
  }
}

class Roadshow extends React.Component {
  render () {
    return <LoadableRoadshow />
  }
}

class News extends React.Component {
  render () {
    return <LoadableNews />
  }
}

class Banner extends React.Component {
  render () {
    return <LoadableBanner/>
  }
}
class Message extends React.Component {
  render () {
    return <LoadableMessage/>
  }
}


const routes = [
  // { path: '/account', name: 'Account', component: Account },
  // { path: '/chancePublish', name: 'chancePublish', component: ChancePublish },
  { path: '/roadshow', name: 'Roadshow', component: Roadshow },
  { path: '/news', name: 'News', component: News },
  { path: '/banner', name: 'Banner', component: Banner },
  { path: '/message', name: 'Message', component: Message },
]


export default routes;