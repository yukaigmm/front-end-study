import {observable,action,computed} from 'mobx';
import api from '../utils/api'

export class OptionStore{
    @observable options;
    @computed get fmAdminOptions(){
        return this.options || null
    };
    @action getFmAdiminOptions(){
        return new Promise((resolve,reject)=>{
            api.get('common/config').then(action(res=>{
                this.options = res.data;
                resolve();
            }))
        })
    }
}
export default OptionStore;