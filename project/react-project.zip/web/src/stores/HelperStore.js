import { observable, computed, action } from 'mobx';

export class HelperStore {

  constructor(stores = {}) {
    this.accountStore = stores.accountStore;
  }

  @computed get helloworld() {
    return 'Hello World';
  }

}

export default HelperStore;
