import { AccountStore } from './AccountStore';
import { HelperStore } from './HelperStore';
import {OptionStore} from './OptionStore'
const accountStore = new AccountStore();
const optionStore = new OptionStore();
const helperStore = new HelperStore({
  accountStore
});


export default {
  accountStore,
  helperStore,
  optionStore
};
