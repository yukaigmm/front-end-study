import { observable, computed, action } from 'mobx';

export class AccountStore {

  @observable user = null;

  @computed get userId() {
    return this.user ? this.user.id : null;
  }

  @action setUser(user) {
    this.user = user;
  }

}

export default AccountStore;
