import React, { Component } from 'react';
import './AppHeader.less';
import Logo from './Logo';
import {message} from 'antd'
import api from '../utils/api'

class AppHeader extends Component {
  render () {
    return (
      <div className="header-container">
        <div className="logo-wrapper">
          <Logo></Logo>
        </div>
        <div className="header-info">
          <span className="header-title">后台管理系统</span>
          <a className="user-center">
            {this.props.userName}
          </a>
          <div className="logout" onClick={this.logout}>退出</div>
        </div>
      </div>
    )
  }
  constructor(props){
    super(props);
    this.state = {};
    this.logout = this.logout.bind(this);
  }
  logout(){
    api.get('user/checkLogout').then(res=>{
      if(res.code === 20000){
        message.success('登出成功！');
        window.localStorage.clear();
        this.props.history.push('/login')
      }
    })
  }
}


export default AppHeader;