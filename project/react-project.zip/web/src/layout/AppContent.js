import React, { Component } from 'react';

class AppContent extends Component {
  render () {
    return (
      <div>content</div>
    )
  }
}

export default AppContent;