import React, { Component } from 'react';
import './logo.less'
import logo from '../assets/images/logo.png'



class Logo extends Component {
  render () {
    return (
      <div className="logo-container">
        <img className="logo" src={logo} alt="" />
      </div>
    )
  }
}

export default Logo;