import React, { Component } from 'react';
import './AppMenu.less';

import { Menu, Icon } from 'antd';

import { Link } from 'react-router-dom'

const SubMenu = Menu.SubMenu;



class AppMenu extends Component {
  render () {
    return (
      <Menu
        mode={this.state.mode}
        onSelect={this.selectMenu}
        width={160}
      >
        {this.state.menus.map( (menu) => {
          return (menu.childrens && menu.childrens.length) ? 
            <SubMenu key={menu.key} title={
              <span>
                <Icon type={menu.icon} />
                <span>{menu.title}</span>
              </span>
            }>
              {menu.childrens.map( (c) => {
                return (
                  <Menu.Item key={c.key}>
                    <Link to={`${this.props.match.url}/${c.key}`}>
                      <Icon type={c.icon}/>
                      {c.title}
                    </Link>
                  </Menu.Item>
                )
              })}
            </SubMenu> 
          :
            <Menu.Item key={menu.key} className="submenu">
              <Link to={`${this.props.match.url}/${menu.key}`}>
                <Icon type={menu.icon}/>
                {menu.title}
              </Link>
            </Menu.Item>
        })}
      </Menu>
    )
  }
  selectMenu ({item, key}) {
    
  }
  constructor (props) {
    super(props);

    this.selectMenu = this.selectMenu.bind(this);

    this.state = {
      mode: 'inline',
      menus: [
        // {
        //   title: '首页',
        //   key: 'home',
        //   icon: 'mail',
        // },
        // {
        //   title: '账号管理',
        //   key: 'account',
        //   icon: 'mail',
        // },
        // {
        //   title: '机会管理',
        //   key: 'chance',
        //   icon: 'mail',
        //   childrens: [
        //     {
        //       title: '机会发布',
        //       key: 'chancePublish',
        //       icon: 'mail',
        //     },
            // {
            //   title: '机会处理',
            //   key: 'chanceDeal',
            //   icon: 'mail',
            // }
          // ]
        // },
        {
          title: '路演管理',
          key: 'roadshow',
          icon: 'mail',
        },
        {
          title: '资讯管理',
          key: 'news',
          icon: 'mail',
        },
        {
          title: 'banner管理',
          key: 'banner',
          icon: 'mail',
        },
        // {
        //   title: '消息管理',
        //   key: 'message',
        //   icon: 'mail',
        // },
      ]
    }
  }
}

export default AppMenu;