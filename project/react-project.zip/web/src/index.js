import React from 'react';
import ReactDOM from 'react-dom';
import './index.less';
import './assets/fonts/iconfont.css'
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import setSession from './utils/session'
// antd汉化设置
import { LocaleProvider } from 'antd';
import zhCN  from 'antd/lib/locale-provider/zh_CN';
import moment from "moment";
import 'moment/locale/zh-cn';
import stores from './stores/index'
moment.locale('zh-cn');
new Promise((resolve,reject)=>{
    if(!stores.optionStore.fmAdminOptions){
        stores.optionStore.getFmAdiminOptions().then((res=>{
            resolve();
        }))
    }
}).then(()=>{
    ReactDOM.render(<LocaleProvider locale={zhCN}><App /></LocaleProvider>, document.getElementById('root'));
    registerServiceWorker();
})
