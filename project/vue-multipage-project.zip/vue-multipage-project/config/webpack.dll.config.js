


// 公共文件单独编译
//
const {resolve, join} = require('path');
const webpack = require('webpack');
const Uglifyjs = require('uglifyjs-webpack-plugin')


let config = {
    entry: {
        vendor: [
            'vue',
            'jquery',
            'wangeditor',
            './src/common/js/common.js',
            './src/common/js/comp.js',
            'babel-polyfill',
        ]
    },


    output: {
        path: resolve(__dirname, '../../../server/public/pc'),
        filename: 'assets/js/[name].dll.js',
        library: '[name]_library'
    },

    resolve: {
        extensions: ['.js', '.vue'],
    
        alias: {
            '@': join(__dirname, '../src'),
            assets: join(__dirname, '../src/assets'),
            common: join(__dirname, '../src/common'),
            components: join(__dirname, '../src/common/components'),
            root: join(__dirname, 'node_modules')
        }
    },
        

    module: {
        rules: [
            {
                test: /\.vue$/,
                loader: 'vue-loader',
                options: {
                    loaders: {
                        css: ['style-loader', 'css-loader', 'postcss-loader'],
                        less: ['style-loader','css-loader', 'postcss-loader', 'less-loader'],
                        postcss: ['style-loader', 'css-loader', 'postcss-loader']
                    }
                }
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader', 'postcss-loader']
            },
            {
              test: /\.js$/,
              use: 'babel-loader?cacheDirectory',
              include: [resolve('src')]
            },
            {
              test: /\.less$/,
              use: ['style-loader','css-loader', 'postcss-loader', 'less-loader']
            },
            {
              test: /\.(png|jpg|jpeg|gif|eot|ttf|woff|woff2|svg|svgz)(\?.+)?$/,
              use: [{
                loader: 'url-loader',
                options: {
                  limit: 50000,
                  name: 'assets/img/[name].[hash:7].[ext]'
                }
              }]
            }
        ]
    },


    plugins: [
        new webpack.DllPlugin({
            path: join(__dirname, '../../../server/public/pc/assets/js', '[name]-manifest.json'),
            name: '[name]_library',
            context: __dirname
        }),
        new Uglifyjs()
    ]
}



module.exports = config

