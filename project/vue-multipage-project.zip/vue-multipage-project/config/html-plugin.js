
const glob = require('glob')
const HtmlWebpackPlugin = require('html-webpack-plugin')

let config = []
let root = './src'
let pagesPath = `${root}/pages/`


glob.sync(`${root}/pages/**/*.html`).forEach(path => {
    const chunk = path.slice( path.indexOf(pagesPath)+pagesPath.length,  path.lastIndexOf('/'))
    const filename = chunk + '/index.html'

    const htmlConf = {
      filename: filename,
      template: path,
      inject: 'body',
      favicon: `${root}/assets/images/favicon.png`,
      hash: process.env.NODE_ENV === 'production',
      chunks: ['vendors', chunk]  //
    }
    
    config.push(new HtmlWebpackPlugin(htmlConf))
})



module.exports = config