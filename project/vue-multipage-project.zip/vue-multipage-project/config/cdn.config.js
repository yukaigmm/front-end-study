


let config = {

    // type:默认 script,  可配置为 style 
    // src: 资源文件地址
    // order: 资源的引入顺序， 越小越在前面，不设置放后面
    // alternative: 备选方案
    // inject: 'head'   将标签插入到头部
    //, 

    browser: {
        src: '/assets/lib/browser/browsertip.js', 
        order: 1
    },

    editor: {
        src: '/assets/lib/wangEditor/wangEditor.min.js',
        order: 2
    },

    vue: {
        type: 'script',
        src: '/assets/lib/vue/vue.min.js', //'',
        alternative: '//cdn.bootcss.com/vue/2.5.16/vue.min.js',
        order: 3
    }, 

    jquery: {
        src: '/assets/lib/jquery/jquery.min.js', //'',
        alternative: '//cdn.bootcss.com/jquery/2.2.4/jquery.min.js',
        order: 4
    },

    // polyfill
    // 补丁js
    // 先通过浏览器判断是否支持新特性，然后再决定是否引入polyfill.js
    //
    polyfill: {
        src: '/assets/lib/polyfill/import-polyfill.js',
        order: 1,
        inject: 'head'
    },


    // js 公共模块
    // common: {
    //     src: '/assets/js/common.js',
    // },



    // css 相关
    //
    // font: {
    //     type: 'style',
    //     src: '//fonts.googleapis.com/icon?family=Material+Icons'
    // }
}



module.exports = config