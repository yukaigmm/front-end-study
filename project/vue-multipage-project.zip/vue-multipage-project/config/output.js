

// 输出目录
const { join, resolve } = require('path')


module.exports = {
    path: resolve(__dirname, '../../../server/public/pc'),

    filename: 'assets/js/[name].js',

    publicPath: process.env.NODE_ENV === 'development' ? '/' : '/pc/',
}
