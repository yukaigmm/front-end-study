

const glob = require('glob')

let root = './src'
let pagesPath = `${root}/pages/`

let chunks = []
let entries = {
    polyfill: `${root}/common/js/polyfill.js`,
    // common: `${root}/common/js/common.js`,
    // comp: `${root}/common/js/comp.js`
}


// 公共文件
// entries.vendors = [
//     'babel-polyfill',
//     `${root}/common/js/common.js`,
//     `${root}/common/js/comp.js`
// ]

// 多入口文件
glob.sync(`${root}/pages/**/app.js`).forEach(path => {
    let chunk = path.slice( path.indexOf(pagesPath)+pagesPath.length,  path.lastIndexOf('/'))

    entries[chunk] = path // ['babel-polyfill', path]
    chunks.push(chunk)
    
})



module.exports = {
    entry: entries,
    chunks: chunks //: ['vendors']
}