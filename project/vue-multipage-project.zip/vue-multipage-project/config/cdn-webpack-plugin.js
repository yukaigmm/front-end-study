

// cdn webpack 插件
// 替换页面中指定的地址

let HtmlWebpackPlugin = require('html-webpack-plugin')
let fs = require('fs');
let path = require('path');
let output = require('./output')
let debug = false


function CdnPlugin(options) {
    //
    this.options = Object.assign({
        config: './cdn.config.js',
        debug: true
    }, options)


    this.cdnsConfig = require(this.options.config)
    this.htmls = []
}



// cdn 插件编写
// 
CdnPlugin.prototype.apply = function (compiler) {
    let self = this

    compiler.plugin('compilation', compilation => {

        // debug && log( '========= compilation ==========' )
        compilation.plugin('html-webpack-plugin-before-html-generation', (htmlPluginData, callback) => {
            let scripts = htmlPluginData.assets.js
            let styles = htmlPluginData.assets.css
            let cdns = Object.values(self.cdnsConfig)


            // 按 order 排序
            // 降序排列， 因为添加是在前面插入
            // 不设置放后面
            //
            cdns.sort((a, b) => {
                a.order = typeof a.order !== 'undefined' ? a.order : 100
                b.order = typeof b.order !== 'undefined' ? b.order : 100

                return b.order - a.order
            })


            cdns.forEach(item => {
                let isString = typeof item === 'string'
                let isJs = isString ? /\.js$/.test(item) : (!item.type || item.type === 'script')
                let src = item.src || item.href || item
                let isOtherSite = /^(http|\/\/)/.test( src )
                let url = isOtherSite ? src: `${output.publicPath.slice(0, -1)}${src}`

                if( isJs ){
                    let params = {
                        src: url,
                        inject: item.inject,
                        // onerror: item.alternative ? `this.src='${url}'`: null       
                    }
                    scripts.unshift( params )

                }else{
                    styles.unshift({
                        href: url
                    })
                }
            })

            callback(null, htmlPluginData)
        })
    })



    compiler.plugin('emit', (compilation, callback) => {
        debug && log('========= emit ==========')
        callback()
    })
}






// 重写 generateAssetTags
// 增加对象方式
// 
HtmlWebpackPlugin.prototype.generateAssetTags = function (assets) {
    // Turn script files into script tags
    //
    var scripts = assets.js.map(function (scriptPath) {
        let attrs = {
            type: 'text/javascript',
            src: scriptPath,
            inject: '',
            // defer: 'defer'
        }

        if( typeof scriptPath === 'object' ){
            Object.assign( attrs, scriptPath )
        }

        let js = {
            tagName: 'script',
            closeTag: true,
            inject: attrs.inject
        }

        delete attrs.inject
        js.attributes = attrs
        return js;
    });


    // Make tags self-closing in case of xhtml
    var selfClosingTag = !!this.options.xhtml;
    // Turn css files into link tags
    var styles = assets.css.map(function (stylePath) {        
        let attrs = {
            href: stylePath,
            rel: 'stylesheet'
        }

        if( typeof stylePath === 'object' ){
            Object.assign( attrs, stylePath )
        }

        return {
            tagName: 'link',
            selfClosingTag: selfClosingTag,
            attributes: attrs
        };
    });

    // Injection targets
    var head = [];
    var body = [];

    // If there is a favicon present, add it to the head
    if (assets.favicon) {
        head.push({
            tagName: 'link',
            selfClosingTag: selfClosingTag,
            attributes: {
                rel: 'shortcut icon',
                href: assets.favicon
            }
        });
    }

    // Add styles to the head
    head = head.concat(styles);

    // Add scripts to body or head
    let inHead = this.options.inject === 'head'
    scripts.forEach(js=>{
        if( inHead || js.inject === 'head' ){
            head.push( js )
        }else{
            body.push( js )
        }
    })

    return { head: head, body: body };
};




function log() {
    console.log(...arguments)
}



module.exports = CdnPlugin