

const webpack = require('webpack')
const OptimizeCSSPlugin = require('optimize-css-assets-webpack-plugin')
const UglifyJsPlugin = require('uglifyjs-webpack-plugin')
let config = require('./webpack.base.config')


// 
config.plugins = config.plugins.concat([
    new UglifyJsPlugin({
        uglifyOptions: {
            ie8: false,
            // ecma: 8,
            mangle: true,
            output: { comments: false },
            compress: { 
                warnings: false,
                drop_console: (process.env.NODE_ENV === 'test' || process.env.NODE_ENV === 'pre') ? false : true,
                drop_debugger: (process.env.NODE_ENV === 'test' || process.env.NODE_ENV === 'pre') ? false : true
            }
        },
        sourceMap: true,
        cache: true,
    }),

    new OptimizeCSSPlugin()
])




module.exports = config