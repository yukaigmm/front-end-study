const webpack = require('webpack')
let config = require('./webpack.base.config')
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const opn = require("opn")


config.devtool = false
config.devServer = {
    host: 'fm-local.simuwang.com', //dev.fm.com, localhost
    port: 8011,
    historyApiFallback: false,
    noInfo: true,
    // contentBase: '/',
    watchOptions: {
        poll: 1000,
        aggregateTimeout: 500,
        watch: true,
        ignored: /node_modules/
    },
    disableHostCheck: true,
    compress: true,
    overlay: true,
    // quiet: true,
    stats: "errors-only",
    // hot: true,
    // hotOnly: true,
    // inline: true,
    // color: true,

    proxy: {
        '/api': {
            target: 'https://fm-test.simuwang.com', //test分支
            // target: 'http://fm-test.simuwang.com',//develop分支
            changeOrigin: true
        },
        "/ppwApp": {
            target: "https://ppwapp-test.simuwang.com",
            changeOrigin: true,
            pathRewrite: {
                "^/ppwApp": "/"
            }
        }
    },

    open: true,
    openPage: 'index/index.html',
    // after(){
    //     opn('http://localhost:' + this.port+'/index/index.html')
    // }
}


// config.plugins.push(    
//     new BundleAnalyzerPlugin()
// )




module.exports = config