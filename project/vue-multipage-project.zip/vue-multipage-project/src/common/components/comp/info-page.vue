<template>
  <div class="info-page-container">
    <div class="logo-container"></div>
    <div class="inner cl">
      <div class="carousel-total-container fl">
        <div class="carousel-container">
          <ul class="carousel-lists cl" :style="{width:(carouselPics.length+1) * 5.72+'rem'}">
            <li v-for="(item,index) in carouselPics" :key="index" class="carousel-item">
              <img :src="getCarouselPic(item)" alt>
            </li>
          </ul>
        </div>
        <div class="click-tools-container">
          <ul class="click-lists">
            <li
              class="click-item"
              v-for="(item,ind) in carouselPics"
              :key="ind"
              @click="showCorrespondingPic(ind)"
              :class="{current:index==ind || (ind==0&&index==carouselPics.length)}"
            ></li>
          </ul>
        </div>
      </div>
      <div class="info-main-container fl">
        <div class="fund-string"></div>
        <slot name="info"></slot>
      </div>
      <div class="contact-info">
        联系我们：
        <a class="mail-contact" href="mailto:fm@simuwang.com">fm@simuwang.com</a>
        <p class="copyright">版权所有&copy;深圳市排排网投资管理股份有限公司ICP证粤B2-20110208 粤ICP备09068203号</p>
      </div>
    </div>
  </div>
</template>
<script>
import pageView from "../../../common/mixins/pageView";
export default {
  mixins: [pageView],
  data() {
    return {
      carouselPics: [
        "information-disclosure.png",
        "analysis.png",
        "report.png",
        "opportunity.png"
      ],
      index: 0
    };
  },
  mounted() {
    this.setRem();
    window.addEventListener("resize", this.resizeSetRem);
    this.autoRun();
  },
  methods: {
    // 设置页面响应式的rem
    setRem() {
      $("html").css({
        "font-size": ($(document.body).width() * 10) / 192 + "px"
      });
    },
    resizeSetRem() {
      if ($(document.body).width() < 1200) {
        return;
      }
      this.setRem();
    },
    getCarouselPic(item) {
      return `${
        this.$baseUrl[process.env.NODE_ENV]["page"]
      }/assets/images/banner/${item}`;
    },
    // 自动轮播处理index;
    dealIndex() {
      this.index++;
      if (this.index === this.carouselPics.length) {
        // this.goOrigin();
        this.index = 0;
      }
      this.moveToIndex(this.index);
    },
    // 点击工具条显示对应的图片
    showCorrespondingPic(index) {
      this.index = index;
      clearInterval(this.timer);
      this.moveToIndexByClick(index);
      this.autoRun();
    },
    // 根据index调到对应图片
    moveToIndex(index) {
      $(".carousel-lists li")
        .eq(index)
        .fadeIn(1500)
        .siblings()
        .fadeOut(1500);
    },
    moveToIndexByClick(index) {
      $(".carousel-lists li").stop();
      $(".carousel-lists li")
        .eq(index)
        .fadeIn(500)
        .siblings()
        .fadeOut(500);
    },
    // 自动轮播
    autoRun() {
      this.timer = setInterval(() => {
        this.dealIndex();
      }, 2500);
    }
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.resizeSetRem);
  }
};
</script>
<style lang="less" scoped>
html,
body {
  font-family: "微软雅黑", "Microsoft Yahei";
  height: 100%;
  margin: 0;
  padding: 0;
}
.info-page-container {
  width: 100%;
  height: 100%;
  background: url("../../../assets/images/bg.jpg") no-repeat center center;
  background-size: 100% 100%;
  // logo
  .logo-container {
    width: 1.62rem;
    height: 0.61rem;
    margin: 0.05rem 0 0 0.26rem;
    position: absolute;
    background: url("../../../assets/images/logo.png") no-repeat center center;
    background-size: 100%;
  }
  // 版心
  .inner {
    width: 12rem;
    height: 100%;
    padding-top: 1.8rem;
    margin: 0 auto;
    // 轮播图
    .carousel-total-container {
      // width: 5.72rem;
      width: 4.72rem;
      margin-right: 0.96rem;
      margin-left: 0.9rem;
      margin-top: 0.1rem;
    }
    .carousel-container {
      width: 100%;
      // height: 4.49rem;
      height: 3.69rem;
      overflow: hidden;
      position: relative;
      ul.carousel-lists {
        margin: 0;
        height: 100%;
        // position: absolute;
        position: relative;
        .carousel-item {
          // width: 5.72rem;
          // height: 4.49rem;
          display: none;
          position: absolute;
          width: 4.72rem;
          height: 3.69rem;
          float: left;
          background-size: 100% !important;
          img {
            width: 100%;
            height: 100%;
          }
          &:first-child {
            display: block;
          }
        }
      }
    }
    // 轮播图工具条
    .click-tools-container {
      width: 100%;
      height: 0.12rem;
      margin-top: 0.57rem;
      // background-color: red;
      .click-lists {
        width: 100%;
        height: 100%;
        // padding-left: 1.21rem;
        padding-left: 0.7rem;
        margin: 0;
        .click-item {
          width: 0.67rem;
          height: 100%;
          float: left;
          margin-right: 0.16rem;
          cursor: pointer;
          background-color: rgba(255, 255, 255, 0.2);
          &.current {
            background-color: rgba(255, 255, 255, 0.75);
          }
        }
      }
    }
    .info-main-container{
        width: 3.67rem;
        height: 4.5rem;
        .fund-string{
            width: 2.23rem;
            height: .68rem;
            margin: 0 auto;
            background: url('../../../assets/images/master-logo.png') no-repeat center center;
            background-size: 100%;
        }
    }
    // 底部信息
    .contact-info {
      color: rgba(255, 255, 255, 0.4);
      font-size: 0.12rem;
      text-align: center;
      position: absolute;
      bottom: 0.4rem;
      left: 50%;
      transform: translate(-50%);
      width: 100%;
      .mail-contact {
        color: #039be5;
        margin-right: 0.1rem;
      }
      .copyright {
        display: inline-block;
        padding-left: 0.12rem;
        border-left: 1px solid rgba(255, 255, 255, 0.4);
        height: 0.2rem;
        line-height: 0.2rem;
      }
    }
  }
}
</style>
