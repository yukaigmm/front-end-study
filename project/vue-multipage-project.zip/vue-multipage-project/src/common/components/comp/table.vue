<template>
  <div class="table-comp-container">
    <slot></slot>
    <el-table
      v-has-scroll-bar="refresh"
      ref="table"
      :data="data"
      fit
      :show-header="showHeader"
      :height="height"
      :max-height="maxHeight"
      border
      size="mini"
      @row-click="tableRowClick"
      :key="key"
      :class="{'drag-table': draggable}"
      @sort-change="sortChange"
      :default-sort="defaultSort"
      :row-class-name="tableRowClassName"
      @selection-change="selectionChange"
      :row-key="rowKey"
      :expand-row-keys="expandRowKeys"
      @expand-change="expandChange"
    >
      <div slot="empty" class="empty-data-container">
        <span style="display: block;line-height: 30px;">{{emptyData}}</span>
        <img v-if="!fofHide" src="../../../../src/assets/images/empty-data.png" alt />
      </div>
      <el-table-column
        v-if="draggable"
        prop="drag"
        label="拖动"
        width="40"
        :resizable="false"
        align="center"
        :render-header="draggableHeaderRender"
      >
        <template slot-scope="scope">
          <span
            class="drag"
            style="display: block;width: 100%;height: 100%;text-align: center;cursor: move;"
          >
            <i class="iconfont icon-arrows-v"></i>
          </span>
        </template>
      </el-table-column>
      <!-- <el-table-column
      v-if="useSelection"

      ></el-table-column>-->
      <template v-for="(column, index) in columns">
        <el-table-column
          v-if="column.type === 'selection'"
          type="selection"
          :key="index"
          :prop="column.key"
          :label="column.title"
          :width="column.width"
          :min-width="column.minWidth"
          :align="column.align"
          :resizable="false"
          :show-overflow-tooltip="column.showOverflowTooltip === undefined ? true : column.showOverflowTooltip"
          :render-header="column.renderHeader"
          v-bind="column"
        ></el-table-column>
        <template v-else>
          <el-table-column
            v-if="!column.childrens"
            :key="index"
            :type="column.type"
            :prop="column.key"
            :label="column.title"
            :width="column.width"
            :min-width="column.minWidth"
            :align="column.align"
            :resizable="false"
            :show-overflow-tooltip="column.showOverflowTooltip === undefined ? true : column.showOverflowTooltip"
            :sortable="column.sortable?'custom':false"
            v-bind="column"
            :render-header="column.renderHeader"
            :sort-orders="sortOrders"
          >
            <template slot-scope="scope">
              <customColumn
                :ref="`custom-column-${scope.$index}-${column.key}`"
                :renderContent="column.render"
                :scope="scope"
                :prop="column.key"
              ></customColumn>
            </template>
          </el-table-column>
          <el-table-column
            v-else
            :label="column.title"
            :key="index"
            :align="column.align"
            :render-header="column.renderHeader"
          >
            <el-table-column
              v-for="(child, ind) in column.childrens"
              :key="ind"
              :type="child.type"
              :prop="child.key"
              :label="child.title"
              :width="child.width"
              :min-width="child.minWidth"
              :align="child.align"
              :resizable="false"
              :show-overflow-tooltip="child.showOverflowTooltip === undefined ? true : child.showOverflowTooltip"
              :sortable="child.sortable?'custom':false"
              v-bind="child"
              :sort-orders="sortOrders"
              :render-header="child.renderHeader"
            >
              <template slot-scope="scope">
                <customColumn :renderContent="child.render" :scope="scope" :prop="child.key"></customColumn>
              </template>
            </el-table-column>
          </el-table-column>
        </template>
      </template>
      <div slot="append" v-show="tableLoadingMore || reloadMore" class="table-loading-more">
        <vloading v-model="tableLoadingMore" size="small"></vloading>
        <vreload v-model="reloadMore" @reload="reloadMoreData"></vreload>
      </div>
    </el-table>
    <!-- <div> -->
    <slot name="tableTips"></slot>
    <!-- </div> -->
    <div class="table-footer" v-if="usePagination" v-show="data.length">
      <el-pagination
        v-if="(!hidePagination || (totalItem > pageSize))"
        class="right"
        background
        @size-change="sizeChange"
        @current-change="currentChange"
        :current-page="currentPage"
        :page-sizes="pageSizeConf"
        :page-size="pageSize"
        :layout="layout"
        :total="totalItem"
      ></el-pagination>
    </div>
  </div>
</template>

<script>
import _ from "lodash";
import sortable from "sortablejs";
import customColumn from "../../js/customColumn";
import util from "../../directives/has-scroll-bar";

export default {
  directives: {
    hasScrollBar: util.hasScrollBar
  },

  name: "vtable",
  components: {
    customColumn
  },
  props: {
    showHeader: {
      type: Boolean,
      default: true
    },
    showTips: {
      type: Boolean,
      default: false
    },
    columns: {
      type: Array,
      default: () => {
        return [];
      }
    },
    data: {
      type: Array,
      default: () => {
        return [];
      }
    },
    usePagination: {
      type: Boolean,
      default: false
    },
    pageSizeConf: {
      type: Array,
      default: () => {
        return [10, 20, 30, 40];
      }
    },
    pageSize: {
      type: Number,
      default: 10
    },
    layout: {
      type: String,
      default: "total, sizes, prev, pager, next, jumper, ->"
    },
    height: {},
    maxHeight: {
      type: Number
    },
    emptyData: {
      type: String,
      default: "暂无数据"
    },
    currentPage: {},
    totalItem: {},
    draggable: {
      type: Boolean,
      default: false
    },
    dragTitleExplains: {
      type: Array,
      default: () => {
        return ["拖动该列图标可进行排序"];
      }
    },
    rank: {
      type: Boolean,
      default: false
    },
    lazyLoad: {
      type: Boolean,
      default: false
    },
    lazyLoadConfig: {
      type: Object,
      default: {
        noData: "无数据",
        noMoreData: "无更多数据"
      }
    },
    tableLoadingMore: {
      type: Boolean,
      default: false
    },
    reloadMore: {
      type: Boolean,
      default: false
    },
    currentRowIndex: {
      type: [Number, String],
      default: -1
    },
    hidePagination: {
      type: Boolean,
      default: false
    },
    changeRowColor: {
      type: Boolean,
      default: false
    },
    rowKey: {
      type: Function,
      default: () => {}
    },
    expandRowKeys: {
      type: Array,
      default: () => {
        return [];
      }
    },
    fofHide: {
      type: Boolean,
      default: false
    },
    sortOrders: {
      type: Array,
      default: () => {
        return ["descending", "ascending", null];
      }
    }
  },
  data() {
    return {
      // currentPage: 1,
      total: 100,
      key: Date.now(),
      lazyLoadLoading: true,
      defaultSort: {
        prop: "",
        order: ""
      },
      lastSortObj: {
        order: "",
        prop: ""
      },
      // dragable 控制的是是否加载拖拽组件，是父组件中传过来的；selfDraggable 控制的是当前是否能够拖拽，是 table 组件内的状态
      selfDraggable: true,
      currentRow: {},
      currentRowKey: "",
      currentRowId: []
    };
  },
  methods: {
    tableBodyRowClick(index, columnKey) {
      this.$emit("tableBodyRowClick", index, columnKey);
    },
    setCurrentRow(key, id) {
      this.currentRowKey = key;
      this.currentRowId = id;
    },
    // table单行点击回调
    tableRowClick(row, event, column) {
      let index = $(event.currentTarget).index();
      this.$emit("tableRowClick", { row, column, index, event });
    },
    expandChange(row, expandedRows) {
      this.$emit("expandChange", { row, expandedRows });
    },
    sizeChange(size) {
      this.pageSize = size;
      this.$emit("pageSizeChange", size);
    },
    currentChange(page) {
      this.pageNo = page;
      this.$emit("pageChange", page);
    },
    initSortable(disabled = false) {
      let el = $(this.$refs.table.$el).find(
        ".el-table__body-wrapper > table > tbody"
      )[0];
      this.sortableElm = sortable.create(el, {
        animation: 120,
        delay: 0,
        disabled: disabled,
        ghostClass: "ghost",
        chosenClass: "clone",
        dragClass: "draging",
        handle: !disabled ? ".drag" : ".unkown",
        onEnd: ({ oldIndex, newIndex }) => {
          const targetRow = this.data.splice(oldIndex, 1)[0];
          this.data.splice(newIndex, 0, targetRow);
          // this.refresh();
          this.key = Date.now();

          this.$emit("sort", this.data);
        }
      });
    },
    selectionChange(selection) {
      this.$emit("selectionChange", selection);
    },
    sortChange(data) {
      let order;
      if (data.order == "ascending") {
        order = "asc";
      } else if (data.order == "descending") {
        order = "desc";
      } else {
        order = undefined;
      }

      // 只有在table组件支持拖拽的时候才需要改变 selfDraggable 的值；其他的不需要支持拖拽的table，sortChange时不需要修改 selfDraggable 的值
      if (this.draggable && data.prop != "fundType") {
        this.selfDraggable = !data.order;
      }
      this.$emit("sortChange", order, data.prop);
    },
    clearSort() {
      this.$refs.table.clearSort();
    },
    setSortabel() {
      this.selfDraggable = true;
      this.draggable = true;
    },
    setUnSortable() {
      this.selfDraggable = false;
      this.draggable = true;
    },
    refresh() {
      this.key = Date.now();
      if (this.draggable) {
        setTimeout(() => {
          this.initSortable(!this.selfDraggable);
        }, 0);
      }
    },
    draggableHeaderRender(h, { column, $index }) {
      return h("vtooltip", {
        props: {
          explains: this.dragTitleExplains,
          placement: "right"
        }
      });
    },
    getRefs() {
      let finalRefs = [];
      let refs = this.$refs;

      _.forEach(refs, ref => {
        if (ref instanceof Array) {
          _.forEach(ref[0].$refs, i => {
            finalRefs.push(i);
          });
        }
      });
      return finalRefs;
    },
    tableRowClassName({ row, rowIndex }) {
      if (row[this.currentRowKey] === this.currentRowId) {
        return "current-table-row";
      }
    },
    toggleRowSelection(row, selected) {
      this.$refs.table.toggleRowSelection(row, selected);
    },
    reloadMoreData() {
      this.$emit("reloadMoreData");
    },
    doLayout() {
      this.$refs.table.doLayout();
    }
  },
  mounted() {
    if (this.draggable) {
      this.initSortable(!this.selfDraggable);
    }
  },
  watch: {
    selfDraggable: {
      handler(val) {
        if (val) {
          if (this.draggable) {
            setTimeout(() => {
              this.sortableElm && this.sortableElm.option("disabled", false);
              this.refresh();
            }, 0);
          }
        } else {
          this.sortableElm && this.sortableElm.option("disabled", true);
          // this.refresh();
        }
      }
    }
  },
  computed: {}
};
</script>

<style lang="less" rel="styleSheet/less">
.table-comp-container {
  position: relative;
  .el-table {
    // min-height: 300px;
    box-sizing: content-box !important;
    tr {
      height: auto;
    }
    .el-table__header-wrapper {
      th.is-leaf:nth-last-child(2) {
        border-right: none;
      }
      thead.is-group {
        th {
          border-bottom: 1px solid #000;
          height: 25px;
          &.is-leaf {
            border-right: 1px solid #000;
          }
        }
      }
    }
    .el-table__body-wrapper,
    .el-table__fixed-body-wrapper {
      td:last-child {
        border-right: 0;
      }
      tr.current-table-row {
        td {
          background-color: #202d3a;
        }
      }
    }
    .table-cell-link {
      color: #2992ff;
      cursor: pointer;
      display: inline-block;
      &:hover {
        text-decoration: underline;
      }
    }
    .cell {
      padding: 0 5px !important;
    }
    .table-loading-more {
      height: 64px;
      position: relative;
    }
    .el-table__empty-block {
      width: 100% !important;
      min-height: 240px;
      background-color: #111;
      position: relative;
      .el-table__empty-text {
        width: auto;
      }
    }
    .caret-wrapper {
      width: 14px;
      height: 9px;
      margin-left: 5px;
      vertical-align: initial;
      .sort-caret {
        &.ascending {
          left: 0;
          top: 0;
          right: auto;
          bottom: auto;
        }
        &.descending {
          right: 0;
          top: 0;
          left: auto;
          bottom: auto;
        }
      }
    }
    .el-table__expanded-cell {
      padding: 0;
      background-color: #202020;
    }
  }
  .table-action-button-container {
    width: 100%;
    line-height: 34px;
    padding: 0 15px;
    text-align: left;
  }
  .table-footer {
    .el-pager {
      li {
        color: #eee;
      }
    }
  }
  .el-pagination {
    padding: 1px 5px;
  }
}
</style>