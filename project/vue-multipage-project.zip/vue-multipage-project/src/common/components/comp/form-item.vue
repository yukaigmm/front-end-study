<template>
  <div v-if="!hide" class="form-item" :style="formItemStyle" :item-key="dataKey">
    <div class="form-item-label" v-if="label || !!labelWidth" :style="formItemLabelStyle">
      <span class="label-content" :style="labelContentStyle">
        <span class="required-icon" v-if="required">*</span>
        <span class="label-space" v-else></span>
        <span v-if="label" v-html="`${label}：`"></span>
        <el-tooltip v-if="tip" :enterable="false" placement="right">
          <i class="material-icons tip">flag</i>
          <!-- <span>?</span> -->
          <div slot="content" v-html="tip"></div>
        </el-tooltip>
      </span>
    </div>
    <div class="form-item-content" :style="formItemContentStyle">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import Emitter from "../../mixins/emitter";
export default {
  name: "vformItem",
  props: {
    label: {
      type: String,
      default: ""
    },
    labelWidth: {
      type: [String, Number],
      default: 0
    },
    tip: {
      type: String,
      default: ""
    },
    align: {
      type: String,
      default: "left"
    },
    singelAlign: {
      type: String,
      default: ""
    },
    dataKey: {
      type: String
    },
    formItemStyle: {
      type: Object
    },
    hide: {
      type: Boolean,
      default: false
    }
    // compConfig: {
    //   type: [Array, Object],
    //   default: () => {
    //     return {};
    //   }
    // }
  },
  data() {
    return {
      validItems: []
    };
  },
  mixins: [Emitter],
  computed: {
    // formItemStyle () {
    //   return {
    //     parentLabelWidth: 0,
    //   }
    // },
    formItemLabelStyle() {
      return {
        width:
          this.label || this.labelWidth
            ? `${this.labelWidth - 10 || this.parentLabelWidth - 10 || 60}px`
            : 0,
        "margin-right": "10px"
      };
    },
    labelContentStyle() {
      // return
      return this.singelAlign ? { [this.singelAlign]: 0 } : { [this.align]: 0 };
    },
    formItemContentStyle() {
      return {
        paddingLeft:
          this.label || this.labelWidth
            ? `${this.labelWidth || this.parentLabelWidth || 60}px`
            : 0
      };
    },
    required() {
      return this.validItems.some(validItem => {
        return validItem.rules.some(rule => {
          return !!rule.required;
        });
      });
    }
  },
  methods: {
    valid() {
      return new Promise((resolve, reject) => {
        let length = 0;
        let formItemValid = true;
        Promise.all(this.validItems.map( item => item.compBlur())).then( (result) => {
          let finalResult = result.every( item => !!item);
          resolve(finalResult);
          
        })
      }); 
    },
    resetValid() {
      this.validItems.forEach(validItem => {
        validItem.resetValid();
      });
    },
    getParentLabelWidth(width) {
      this.parentLabelWidth = width;
    }
  },
  mounted() {
    if (!this.hide) {
      this.dispatch("vform", "on-form-item-add", this);
    }
  },
  created() {
    this.$on("on-valid-item-add", validItem => {
      if (validItem) {
        this.validItems.push(validItem);
      }
      return false;
    });
    this.$on("on-valid-item-remove", validItem => {
      if (validItem) {
        let index = _.findIndex(this.validItems, validItem);
        this.validItems.splice(index, 1);
      }
    });
  },
  watch: {
    hide: {
      handler(val) {
        if (this.hide) {
          this.dispatch("vform", "on-form-item-remove", this);
        } else {
          this.dispatch("vform", "on-form-item-add", this);
        }
      }
    }
  }
};
</script>

<style lang="less" scoped>
.form-item {
  display: block;
  position: relative;
  &.required {
    .label-content::before {
      content: "*";
      color: #ed3f14;
      position: absolute;
      top: 50%;
      left: 2px;
      line-height: 1;
      transform: translate(0, -50%);
    }
  }
  .required-icon {
    color: #ed3f14;
  }
  .label-space {
    display: inline-block;
    width: 6px;
  }
  .form-item-label {
    display: block;
    position: absolute;
    height: 26px;
    line-height: 26px;
    font-size: 12px;
    font-weight: bold;
    text-align: left;
    word-break: break-all;
    padding: 0;
    color: #eee;
    .label-content {
      vertical-align: middle;
      .tip {
        vertical-align: middle;
        cursor: pointer;
      }
    }
  }
  .form-item-content {
    display: block;
  }
}
</style>
