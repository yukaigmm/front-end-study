<template>
  <el-dialog
    :visible.sync="dialogVisible"
    :append-to-body="true"
    :width="`${this.width}px`"
    top="0"
    :close-on-click-modal="false"
    @close="modalClose"
    @open="modalOpen"
  >
    <div slot="title">{{title}}</div>
    <slot name="loading"></slot>
    <div class="modal-content">
      <slot></slot>
      <vreload v-model="reload" @reload="reloadModal" class="modal-reload"></vreload>
    </div>
    <div slot="footer" class="dialog-footer" v-if="footer">
      <slot name="modal-footer">
        <vbutton @click="close">取消</vbutton>
        <vbutton @click="close" active>确定</vbutton>
      </slot>
    </div>
  </el-dialog>
</template>

<script>
import $ from "jquery";
export default {
  name: "vmodal",
  props: {
    title: {
      type: String,
      default: ""
    },
    width: {
      type: [Number, String]
    },
    footer: {
      type: Boolean,
      default: true
    },
    reload: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      dialogVisible: false,
    };
  },
  methods: {
    open() {
      this.dialogVisible = true;
      // this.$nextTick(() => {
      //   //设置modal内部区域的高度，兼容部分浏览器
      //   this.setModalContentHeight();
      //   window.addEventListener("resize", () => {
      //     this.setModalContentHeight();
      //   });
      // });
    },
    close() {
      this.dialogVisible = false;
      // this.$emit('close');
    },
    modalClose () {
      this.$emit('close');
    },
    modalOpen(){
      this.$emit("open");
    },
    // 动态设置modal-content高度
    setModalContentHeight() {
      let height;
      if (this.footer) {
        height =
          $(this.modalInstance.el).height() -
          $(this.modalInstance.el)
            .find(".modal-content .header")
            .outerHeight() -
          $(this.modalInstance.el)
            .find(".modal-footer")
            .outerHeight();
      } else {
        height =
          $(this.modalInstance.el).height() -
          $(this.modalInstance.el)
            .find(".modal-content .header")
            .outerHeight();
      }
      $(this.modalInstance.el)
        .find(".modal-content .content")
        .outerHeight(height);
    },
    reloadModal(){
      this.$emit("reloadModal");
      this.$emit("input", false)
    }
  },
  mounted() {

  }
};
</script>

<style lang="less" rel="styleSheet/less">
  .el-dialog {
    margin: 0;
    max-height: 600px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    transition: max-height 0.3s linear;
    .el-dialog__header {
      font-size: 14px;
      color: #eee;
    }
    .el-dialog__body {
      max-height: 500px;
      overflow: auto;
      // position: relative;
      z-index: 3;
      padding-bottom: 25px !important;
    }
    .modal-content {
      position: relative;
    }
  }
</style>