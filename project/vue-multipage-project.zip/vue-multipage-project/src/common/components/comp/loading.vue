<template>
  <div class="loading-container" v-show="value">
    <div class="wrapper">
      <div class="preloader-wrapper">
        <div class="loading-img-wrapper"></div>
      </div>
      <div class="title">{{title}}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "vloading",
  props: {
    value: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: "数据加载中，请等待！"
    }
  },
  data() {
    return {};
  },
  methods: {}
};
</script>

<style lang="less" rel="styleSheet/less" scoped>
.spinner-blue,
.spinner-blue-only {
  border-color: #2992ff !important;
}
.loading-container {
  left: 0;
  top: 0;
  position: absolute;
  z-index: 20;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.3);
}
.wrapper {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 0;
  text-align: center;
  .preloader-wrapper {
    display: inline-block;
    width: 34px;
    height: 34px;
    .loading-img-wrapper {
      width: 100%;
      height: 100%;
      background: url("../../../assets/images/loading.gif") no-repeat;
      background-position: center;
    }
  }
  .title {
    display: block;
    text-align: center;
    width: 100%;
    font-size: 12px;
    line-height: 24px;
    color: #2992ff;
  }
}

</style>