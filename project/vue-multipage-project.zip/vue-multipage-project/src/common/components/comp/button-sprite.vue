<template>
  <span
    class="button-sprite"
    :class="{disabled: disabled}"
    :style="buttonSpriteStyle"
    @mouseover="mouseover"
    @mouseout="mouseout"
    @click="click"
    :title="title"
  ></span>
</template>


<script>
export default {
  name: "vbuttonSprite",
  props: {
    pos: {
      type: Object,
      default: () => {
        return {
          normal: { x: 0, y: 0 },
          hover: { x: 0, y: 0 },
          disabled: { x: 0, y: 0 }
        };
      }
    },
    disabled: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      prevState: "normal",
      state: "normal"
    };
  },
  computed: {
    buttonSpriteStyle() {
      return {
        backgroundPosition: `${this.pos[this.state].x}px ${
          this.pos[this.state].y
        }px`,
        cursor: this.state === "disabled" ? "auto" : "pointer"
      };
    }
  },
  mounted() {
    this.state = this.disabled ? "disabled" : "normal";
  },
  watch: {
    disabled: {
      handler() {
        this.state = this.disabled ? "disabled" : "normal";
      }
    }
  },
  methods: {
    mouseover(e) {
      this.prevState = this.state;
      if (this.state === "disabled") {
      } else {
        this.state = "hover";
      }
    },
    mouseout(e) {
      if (this.state === "disabled") {
      } else {
        if (this.prevState !== this.state) {
          this.state = this.prevState;
        }
      }
    },
    click(e) {
      if (this.disabled) {
        return;
      }
      this.$emit("click", e);
    }
  }
};
</script>


<style lang="less" scoped>
.button-sprite {
  display: inline-block;
  width: 18px;
  height: 18px;
  background-image: url("../../../assets/images/sprite.png");
  background-position: 0 0;
  cursor: pointer;
  &.disabled {
    pointer-events: none;
  }
}
</style>

