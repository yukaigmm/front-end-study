<template>
  <div style="height: 100%;">
    <vtab ref="tab" v-if="tabs.length" :tabs="tabs" @clickTab="clickTab">
      <div
        style="height: 100%;"
        v-for="(tab, index) in config.tabs"
        :key="index"
        :slot="tab.tabKey"
      >
        <slot>
          <vformConfig
            v-if="!tab.custom"
            :ref="tab.tabKey"
            :config="tab.formConfig"
            :shadow="shadow"
            v-model="val"
            @change="formConfigChange"
          ></vformConfig>

          <div v-else class="custom-comp-container">
            <component
              :is="tab.customComponent"
              :ref="tab.tabKey"
              :fieldKey="tab.tabKey"
              v-model="val[tab.tabKey]"
              @change="customComponentChange"
            ></component>
            <div class="shadow" v-show="shadow"></div>
          </div>
        </slot>
      </div>
    </vtab>

    <vformConfig
      v-else
      ref="form"
      :config="config.formConfig"
      v-model="val"
      @change="formConfigChange"
    ></vformConfig>
  </div>
</template>

<script>
export default {
  name: "vformTab",
  props: {
    value: {
      type: Object,
      default: () => {
        return {};
      }
    },
    config: {
      type: Object,
      default: () => {
        return {};
      }
    },
    shadow: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      val: {}
    };
  },
  computed: {
    tabs() {
      return this.config.useTab
        ? this.config.tabs.map(tab => {
            return {
              label: tab.tabLabel,
              key: tab.tabKey
            };
          })
        : [];
    },
    formConfigs() {
      return this.config.tabs.map(tab => tab.tabKey);
    }
  },
  methods: {
    clickTab(tabKey) {
      let currentTab = this.config.tabs.filter(tab => {
        return tab.tabKey == tabKey;
      })[0];
      this.$emit("clickTab", currentTab);
    },
    formConfigChange(val) {
      for (let key in val) {
        this.val[key] = val[key];
      }

      this.$emit("input", this.val);
      this.$emit("change", this.val);
    },
    customComponentChange(val, key) {
      if (key) {
        this.val[key] = val;
      }
      this.$emit("input", this.val);
      this.$emit("change", this.val);
    },
    valid() {
      return new Promise(resolve => {
        if (this.tabs.length) {
          let formTabValid = true;
          let invalidTabs = [];

          let invalidTab = "";
          let length = 0;
          Promise.all(
            this.formConfigs.map(form => {
              if (
                this.$refs[form][0] &&
                this.$refs[form][0].valid instanceof Function
              ) {
                return new Promise(resolve => {
                  this.$refs[form][0].valid().then(valid => {
                    if (!valid) {
                      invalidTabs.push(form);
                    }
                    resolve(valid);
                  });
                });
              } else {
                return Promise.resolve(true);
              }
            })
          ).then(result => {
            let finalResult = result.every(item => !!item);
            
            invalidTabs.sort((x, y) => {
              return this.formConfigs.indexOf(x) > this.formConfigs.indexOf(y) ? 1 : -1;
            });
            
            invalidTab = invalidTabs[0];
            resolve({ valid: finalResult, invalidTab });
          });
        } else {
          this.$refs.form.valid().then(valid => {
            resolve({ valid, invalidTab: "" });
          });
        }
      });
    },
    resetValid() {
      if (this.tabs.length) {
        this.formConfigs.forEach(form => {
          if (this.$refs[form][0] && this.$refs[form][0].resetValid) {
            this.$refs[form][0].resetValid();
          }
        });
      } else {
        this.$refs.form.resetValid();
      }
    },
    jumpTab(tab) {
      this.$refs.tab.select(tab);
    }
  },
  created() {
    this.val = JSON.parse(JSON.stringify(this.value));
  },
  watch: {
    value: {
      handler(val) {
        if (JSON.stringify(this.value) !== JSON.stringify(this.val)) {
          this.val = JSON.parse(JSON.stringify(this.value));
        }
      },
      deep: true
    }
  }
};
</script>

<style lang="less" scoped>
.custom-comp-container {
  width: 100%;
  height: 100%;
  position: relative;
  .shadow {
    width: 100%;
    height: 100%;
    background-color: rgba(255, 255, 255, 0);
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1000;
  }
}
</style>

