<template>
  <el-tooltip :placement="placement" :enterable="enterable">
    <div slot="content" class="tooltip-content">
      <span class="remark">{{title}}:</span>
      <div class="tooltip-text">
        <span class="tooltip-text-row" v-for="(explain, index) in finalExplains" :key="index">
          <span class="row-index" v-if="showIndex">{{index + 1}}.</span>
          <span class="row-content">{{explain}}</span>
        </span>
      </div>
    </div>
    <slot>
      <span class="tooltip-icon"></span>
    </slot>
  </el-tooltip>
</template>



<script>
export default {
  props: {
    title: {
      type: String,
      default: "说明"
    },
    placement: {
      type: String,
      default: "bottom"
    },
    enterable: {
      type: Boolean,
      default: false
    },
    explains: {
      type: [Array, String],
      default: () => []
    },
    showIndex: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {};
  },
  computed: {
    finalExplains() {
      // return typeof this.explains === 'string' ? [].concat(this.explains) : this.explains;
      return this.explains instanceof Array
        ? this.explains
        : [].concat(this.explains);
    }
  },
  methods: {}
};
</script>


<style lang="less" scoped>
.remark {
  color: #27d;
  margin-right: 3px;
  float: left;
  line-height: 24px;
}
.tooltip-text {
  float: left;
  margin-left: 3px;
  .tooltip-text-row {
    display: block;
    line-height: 24px;
    .row-index {
      display: inline-block;
      width: 10px;
    }
    .row-text {
      display: inline-block;
    }
  }
}
.tooltip-icon {
  display: inline-block;
  width: 16px;
  height: 16px;
  background: url("../../../assets/images/question.png") no-repeat;
  background-size: 100%;
  vertical-align: middle;
}
</style>

