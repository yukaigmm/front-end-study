<template>
  <el-button
    type="primary"
    class="t2-btn"
    :class="{'n-btn-active': active, 'n-btn': !active}"
    :size="size"
    @click="click"
    :title="title"
    :disabled="disabled"
  >
    <slot></slot>
  </el-button>
</template>

<script>
export default {
  name: "vbutton",
  props: {
    size: {
      type: String,
      default: "normal"
    },
    disabled: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: ""
    },
    active: {
      type: Boolean,
      default: false,
    }
  },
  data() {
    return {};
  },
  methods: {
    click(e) {
      this.$emit("click", e);
    }
  },
  watch: {}
};
</script>

<style lang="less" rel="styleSheet/less">
  .n-btn {
    text-align: center;
    cursor: pointer;
    border-radius: 2px;
    color: #eee;
    height: 26px;
    line-height: 26px;
    background-blend-mode: normal, normal;
    border: 0;
    outline: none;
    font-size: 12px;
    border: 0;
    box-shadow: 0px 1px 2px 0px rgba(0,0,0,0.65), inset 0px 1px 0px 0px rgba(255,255,255,0.25);
    background: linear-gradient(#636363, #333);
    width: 70px;
    &:hover {
      background: linear-gradient(#757575, #444);
    }
    &:focus{
      background: linear-gradient(#636363, #333);
    }
  }
  .t2-btn.is-disabled {
    &:hover {
      background: linear-gradient(#888, #393939);
      color: #999;
    }
  }
</style>