<template>
  <div class="part-container">
    <div class="part-header cl">
      <span class="header-title">{{title}}</span>
      <div class="header-search">
        <slot name="search"></slot>
      </div>
      <div class="header-action">
        <slot name="action"></slot>
      </div>
    </div>
    <div class="part-content">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'vpart',
  props: {
    title: {
      type: String,
      default: '',
    }
  },
  data () {
    return {

    }
  }
}
</script>

<style lang="less">
  .part-container {
    position: relative;
    .part-header {
      height: 40px;
      line-height: 39px;
      background-color: #1a1a1a;
      text-align: left;
      position: relative;
      .header-title {
        display: inline-block;
        font-size: 14px;
        line-height: 14px;
        height: 14px;
        padding-left: 10px;
        color: #eee;
        border-left: 5px solid #17c;
      }
      .header-search {
        display: inline-block;
        height: auto;
        width: auto;
        .el-select, .input-container{
          // float: left;
          margin-left: 20px;
        }
        .el-button {
          // float: left;
          margin-left: 10px;
        }
        .switch {
          margin-left: 20px;
        }
      }
      .header-action {
        // float: right;
        position: absolute;
        right: 10px;
        top: 0;
        // margin-right: 10px;
      }
    }
    .part-content {
      background-color: #111;
      height: calc(~"100% - 40px");
    }
  }
</style>

