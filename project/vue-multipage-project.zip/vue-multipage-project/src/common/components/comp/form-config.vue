<template>
  <aform ref="form" :labelWidth="config.labelWidth">
    <el-row v-for="(row, index) in config.fields" :key="index" :gutter="15">
      <el-col
        v-for="(field, i) in row"
        :key="i"
        :span="field.row ? 24 : (24 / config.cols * (field.colspan || 1))"
        :style="field.style"
      >
        <aformItem
          :ref="field.key"
          :hide="field.hide"
          :align="config.align"
          :singelAlign="field.align"
          :label="field.label"
          :label-width="field.labelWidth || config.labelWidth"
          :formItemStyle="field.formItemStyle"
          :tip="field.tip"
          :data-key="field.comps ? (field.comps.length ? field.comps[0]['key'] : field.comps.key) : ''"
        >
          <el-row v-if="field.comps" style="padding: 0;" :gutter="10">
            <template v-if="field.comps instanceof Array && field.comps.length">
              <el-col
                v-for="(comp, idx) in field.comps"
                :key="idx"
                :span="comp.cols ? comp.cols*2 : 24 / field.comps.length"
              >
                <validBox
                  v-bind="comp"
                  v-model="val[comp.key]"
                  :hide="comp.hide"
                  :ref="comp.key"
                  :validKey="comp.key"
                  :rules="comp.rules"
                  :comp="comp"
                  :showMsgByHover="comp.showMsgByHover"
                  :compStyle="comp.compStyle"
                  @change="validBoxChange"
                  :fullWidth="true"
                ></validBox>
              </el-col>
            </template>
            <template v-else>
              <el-col :span="24">
                <validBox
                  v-bind="field.comps"
                  v-model="val[field.comps.key]"
                  :hide="field.comps.hide"
                  :ref="field.comps.key"
                  :validKey="field.comps.key"
                  :rules="field.comps.rules"
                  :comp="field.comps"
                  :compStyle="field.comps.compStyle"
                  :showMsgByHover="field.comps.showMsgByHover"
                  @change="validBoxChange"
                  :fullWidth="true"
                ></validBox>
              </el-col>
            </template>
          </el-row>
        </aformItem>
      </el-col>
      <div class="cl" v-if="index === config.fields.length-1">
        <slot></slot>
      </div>
    </el-row>

    <div class="shadow" v-show="shadow"></div>
  </aform>

  <!-- <el-form ref="form" model="val" :label-width="config.labelWidth || 160" :label-position="config.align || 'left'">
    <el-row v-for="(row, index) in config.fields" :key="index" :gutter="15">
      <el-col
        v-for="(field, i) in row"
        :key="i"
        :span="field.row ? 24 : (24 / config.cols * (field.colspan || 1))"
        :style="field.style"
      >
        <el-form-item
          :label="field.label"
          :label-width="`${field.labelWidth || config.labelWidth}px`"
        >
          <el-row v-if="field.comps" style="margin: 0;">
            <template v-if="field.comps instanceof Array && field.comps.length">
              <el-col
                v-for="(comp, idx) in field.comps"
                :key="idx"
                :span="comp.cols ? (comp.cols * 2) : (24 / field.comps.length)"
              >
                <el-form-item
                  :prop="comp.key"
                  :rules="comp.rules"
                  label=""
                  :label-width="0"
                >
                  <component
                    :ref="comp.key"
                    :is="comp.compType"
                    v-bind="comp.compConfig"
                    v-model="val[comp.key]"
                    :style="comp.compStyle"
                    @change="compChange"
                    @blur="compBlur"
                  ></component>
                </el-form-item>
              </el-col>
            </template>
            <template v-else>
              <el-col :span="24">
                <el-form-item
                  :prop="field.comps.key"
                  :rules="field.comps.rules"
                  label=""
                  :label-width="0"
                >
                  <component
                    :ref="field.comps.key"
                    :is="field.comps.compType"
                    v-bind="field.comps.compConfig"
                    v-model="val[field.comps.key]"
                    :style="field.comps.compStyle"
                    @change="compChange"
                    @blur="compBlur"
                  ></component>
                </el-form-item>
              </el-col>
            </template>
          </el-row>
             
        </el-form-item>
      </el-col>
    </el-row>
  </el-form> -->
</template>

<script>
import aform from "./form.vue";
import aformItem from "./form-item.vue";
import validBox from "./valid-box.vue";
export default {
  name: "vformConfig",
  components: {
    aform,
    aformItem,
    validBox
  },
  props: {
    value: {
      type: [Object, Array]
    },
    config: {
      type: Object,
      default: () => {
        return {
          cols: 2,
          fields: [],
          labelWidth: 60,
          validate: true
        };
      }
    },
    shadow: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      val: {},
      validBoxes: []
    };
  },
  mounted() {
    // this.val = this.value;
    // if(this.config.fields instanceof Array) {
    //   this.config.fields.forEach( (row) => {
    //     if (!(row instanceof Array)) {
    //       row = [].push(row);
    //     }
    //     row.forEach( (field) => {
    //       if(field.comps instanceof Array) {
    //         field.comps.forEach( (comp) => {
    //           this.validBoxes.push(comp.key);
    //         })
    //       }else {
    //         this.validBoxes.push(field.comps.key);
    //       }
    //     })
    //   })
    // }
  },
  methods: {
    validBoxChange(a, b, c) {
      setTimeout(() => {
        this.$emit("input", this.val);
        this.$emit("change", this.val);
      });
    },
    valid() {
      return new Promise(resolve => {
        this.$refs.form.valid().then(valid => {
          resolve(valid);
        });
      });
    },
    resetValid(resetFields = []) {
      resetFields =
        typeof resetFields === "string" ? [].concat(resetFields) : resetFields;
      this.$refs.form.resetValid(resetFields);
    }
  },
  created() {
    this.val = JSON.parse(JSON.stringify(this.value));
  },
  watch: {
    value: {
      handler(val) {
        if (val) {
          if (JSON.stringify(this.value) !== JSON.stringify(this.val)) {
            this.val = JSON.parse(JSON.stringify(this.value));
          }
        } else {
          this.val = {};
        }
      },
      deep: true
    },
    config: {
      handler(val) {
        // this.key = Date.now();
      },
      deep: true
    }
  }
};
</script>

<style lang="less" scoped>
.shadow {
  width: 100%;
  height: 100%;
  position: absolute;
  background-color: rgba(255, 255, 255, 0);
  display: block;
  top: 0;
  left: 0;
  z-index: 1000;
}
</style>