<template>
  <el-tabs v-model="currentTab" @tab-click="clickTab" class="tab-container" type="card">
    <el-tab-pane 
      v-for="(tab, index) in tabs" 
      :key="index" 
      class="tab" 
      :name="tab.key" 
      :label="tab.label"
    >
      <slot :name="tab.key"></slot>
    </el-tab-pane>
  </el-tabs>
</template>


<script>
export default {
  name: "vtab",
  props: {
    tabs: {
      type: Array,
      default: () => {
        return [];
      }
    },
    titleExplain: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: "button"
    }
  },
  data() {
    return {
      tabsInstance: "",
      tabTitleExplain: "",
      currentTab: ""
    };
  },
  computed: {
    currentTabTitleExplain() {
      let explain = this.currentTab.titleExplain;
      return explain instanceof Array ? explain : [].concat(explain);
    }
  },
  methods: {
    select(id) {
      this.currentTab = id;
    },
    clickTab(tab) {
      let tabKey = tab.name;
      this.currentTab = tabKey;
      this.$emit("clickTab", tabKey);
    },
    clickExplain() {
      this.$emit("clickExplain", this.currentTab.key);
    },
    jumpTab (key) {
      this.select(key);
    }
  },
  mounted() {
    this.currentTab = this.tabs.length ? this.tabs[0]['key'] : '';
  }
};
</script>

<style lang="less" rel="styleSheet/less">
  .tab-container {
    .el-tabs__header {
      margin-bottom: 5px;
      // height: 27px;
      border-bottom: 1px solid #17c;
      .el-tabs__nav-scroll {
        overflow: visible;
        height: 27px;
      }
      .el-tabs__nav-wrap {
        // margin-bottom: 2px;
      }
      .el-tabs__nav {
        border: none;
        .el-tabs__item {
          display: inline-block;
          margin-right: 1px;
          width: 70px;
          height: 24px;
          line-height: 24px;
          text-align: center;
          color: #eee;
          font-size: 12px;
          border-radius: 2px 2px 0 0;
          background: linear-gradient(#636363,#333);
          box-shadow: 0 1px 2px 0 rgba(0,0,0,.65), inset 0 1px 0 0 hsla(0,0%,100%,.25);
          outline: none;
          padding: 0 !important;
          border: none !important;
          position: relative;
          &.is-active {
            background: linear-gradient(#3286c9,#104579);
            &::after {
              content: '';
              display: block;
              width: 100%;
              height: 2px;
              position: absolute;
              bottom: -2px;
              left: 0;
              background-color: #104579;
            }
          }
        }
      }
      
    }
    
  }
</style>