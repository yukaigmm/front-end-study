<template>
  <vmodal
    :title="`视频预览`"
    ref="previewModal"
    class="video-preview-modal t2-el-dialog"
    :footer="false"
    @close="closeVideo"
    
  >
    <div v-if="showVideo" data-vjs-player>
      <video ref="previewVideo" class="video-js"></video>
    </div>
  </vmodal>
</template>

<script>
import videojs from "video.js";
export default {
  props: {},
  data() {
    return {
      showVideo: false
    };
  },
  methods: {
    open(videoUrl) {
      this.$refs.previewModal.open();
      this.showVideo = true;
      this.$nextTick(() => {
        this.player = videojs(this.$refs.previewVideo, {
          autoplay: true,
          controls: true,
          sources: [
            {
              src: videoUrl
            }
          ]
        });
      });
    },
    closeVideo() {
      this.player.dispose();
      this.showVideo = false;
    }
  }
};
</script>

<style lang="less">
.video-preview-modal {
  width: 1040px;
  height: 630px !important;
  min-height: 0 !important;
  max-height: 1000px !important;
  // top: -5px !important;
  // left: -20%;
  .video-js {
    float: left;
    width: 100%;
    height: 100%;
    .video {
      width: 100%;
      height: 100%;
    }
  }
}
</style>


