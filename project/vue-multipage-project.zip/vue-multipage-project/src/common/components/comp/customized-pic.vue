<template>
  <vmodal ref="modal" title="裁切图片" class="t2-el-dialog" width="600">
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="submit">确定</vbutton>
    </div>

    <div class="action-wrapper">
      <label for="uploads" class="upload-btn">{{cropperOptions.img?"更换图片":"上传图片"}}</label>
      <input
        v-if="modal"
        ref="picUpload"
        class="upload-pic-wrap"
        type="file"
        id="uploads"
        accept="image/*"
        @change="uploadImg($event)"
      />

      <vbutton active :disabled="!cropperOptions.img" @click="spinLeft">左转</vbutton>
      <vbutton active :disabled="!cropperOptions.img" @click="spinRight">右转</vbutton>
    </div>

    <div class="pic-wrap">
      <div class="pic-area">
        <vue-cropper
          :key="picKey"
          ref="vueCropper"
          :outputSize="cropperOptions.outputSize"
          autoCrop
          :autoCropWidth="210"
          :autoCropHeight="140"
          :fixedNumber="[210,140]"
          :fixed="fixed"
          original
          @realTime="realTime"
          :img="cropperOptions.img"
        />
      </div>

      <div class="real-time-wrap" :style="previews.div">
        <img :src="previews.url" :style="previews.img" />
      </div>
    </div>
  </vmodal>
</template>

<script>
import { VueCropper } from "vue-cropper";
export default {
  data() {
    return {
      cropperOptions: {
        outputSize: 1,
        img: ""
      },
      modal: false,
      fixed: false,
      previews: {},
      picKey: ""
    };
  },

  methods: {
    submit() {
      if (!this.cropperOptions.img) {
        this.cancel();
        return;
      }
      this.$refs.vueCropper.getCropData(data => {
        this.$emit("getBase64Pic", data);
        this.$refs.vueCropper.getCropBlob(pic => {
          this.$emit("getBlobPic", pic);
          this.onCancel();
        });
      });
    },

    spinLeft() {
      this.$refs.vueCropper.rotateLeft();
    },

    spinRight() {
      this.$refs.vueCropper.rotateRight();
    },

    cancel() {
      this.modal = false;
      this.$refs.picUpload.value = "";
      this.cropperOptions = {
        outputSize: 1,
        img: ""
      };
      this.$refs.vueCropper.clearCrop();
      this.previews = {};
      this.$refs.modal.close();
    },

    show() {
      this.$refs.modal.open();
      this.picKey = Date.now();
      this.modal = true;
    },

    uploadImg(e) {
      let file = e.target.files[0];
      let type = file.type;

      if (!type.includes("image")) {
        this.$Message.error("只能上传图片！");
        return;
      }

      let _this = this;
      let reader = new FileReader();

      reader.onload = event => {
        let data;

        let img = new Image();
        img.src = event.target.result;
        if (img.complete) {
          data = _this.getPicData(img, type);
          _this.$set(this.cropperOptions, "img", data);
        } else {
          img.onload = () => {
            data = _this.getPicData(img, type);
            _this.$set(this.cropperOptions, "img", data);
          };
          img.onerror = () => {
            _this.$Message.error("上传失败！");
          };
        }
      };

      reader.readAsDataURL(file);
    },

    getPicData(img, type) {
      let imgType = type.split("/")[1];
      let canvas = document.createElement("canvas");
      let ctx = canvas.getContext("2d");
      let width = img.width;
      let height = img.height;
      canvas.width = width;
      canvas.height = height;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, width, height);
      let data = canvas.toDataURL(`image/${imgType}`, 1);
      return data;
    },

    realTime(data) {
      this.previews = data;
      if (data.w > 210 || data.h > 140) {
        this.fixed = true;
      } else {
        this.fixed = false;
      }
    }
  }
};
</script>

<style lang="less">
.upload-pic-wrap {
  display: none;
}

.action-wrapper {
  margin-bottom: 10px;
}

.pic-area {
  height: 300px;
}

.real-time-wrap {
  margin-top: 10px;
  overflow: hidden;
}

.upload-btn {
  display: inline-block;
  background: linear-gradient(#3286c9, #104579);
  text-align: center;
  cursor: pointer;
  border-radius: 2px;
  color: #eee;
  height: 26px;
  line-height: 26px;
  outline: none;
  font-size: 12px;
  border: 0;
  box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.65),
    inset 0px 1px 0px 0px rgba(255, 255, 255, 0.25);
  width: 70px;
  margin-right: 10px;

  &:hover {
    background: linear-gradient(#4196e9, #0f5697);
    color: rgb(153, 153, 153);
  }
}
</style>