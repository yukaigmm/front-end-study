<template>
    <div class="reload-container" v-show="value">
        <div class="reload-wrapper">
            <span class="reload-text" @click="reload">重新加载</span>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return {

        }
    },
    props: {
        value: {
            type: Boolean,
            default: false,
        }
    },
    methods: {
        reload(){
            this.$emit("reload");
            this.$emit("input", false)
        }
    },
}
</script>
<style lang="less" scoped>
    .reload-container{
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        z-index: 20;
        background-color: rgba(0, 0, 0, 0.5);
        .reload-wrapper{
            width: 100px;
            height: 30px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            .reload-text{
                cursor: pointer;
                font-size: 14px;
                border: 1px solid #444;
                color: #999;
                padding: 5px 10px;
                &:hover{
                    color: #aaa;
                    border-color: #777;
                }
            }
        }
    }
</style>

