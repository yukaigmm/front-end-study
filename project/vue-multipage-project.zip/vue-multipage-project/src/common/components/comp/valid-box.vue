<template>
  <div
    v-if="!hide"
    class="valid-container"
    :class="{'validate': validate, 'has-margin': hasMargin}"
  >
    <div
      class="comp-container"
      :class="{'comp-invalid': invalidMsg&&!isWarnning,warnning:invalidMsg&&isWarnning}"
    >
      <component
        ref="comp"
        @getAreaValue="getAreaValue"
        :is="comp.compType"
        v-bind="comp.compConfig"
        v-model="val"
        :style="compStyle"
        @change="compChange"
        @blur="compBlur"
        :fullWidth="fullWidth"
      ></component>
      <div v-if="showMsgByHover" class="invalid-msg-hover">
        <span class="triangle"></span>
        <span class="text">{{invalidMsg}}</span>
      </div>
    </div>
    <div v-if="!showMsgByHover" class="invalid-msg-container">
      <span class="invalid-msg" v-if="invalidMsg" :title="invalidMsg">{{invalidMsg}}</span>
      <span v-if="!invalidMsg && comp.notice" class="label-notice">{{comp.notice}}</span>
      <!-- <span>注：视频时长在10分钟以内，大小为50M以内</span> -->
    </div>
  </div>
</template>

<script>
import Emitter from "../../mixins/emitter";
import asyncValidator from "async-validator";
export default {
  name: "vvalidBox",
  props: {
    isWarnning: {
      type: Boolean,
      default: false
    },
    value: {},
    validate: {
      type: Boolean,
      default: true
    },
    validKey: {
      type: String
    },
    hide: {
      type: Boolean,
      default: false
    },
    rules: {
      type: Array,
      default: () => {
        return [];
      }
    },
    comp: {
      type: Object,
      default: () => {
        return {};
      }
    },
    compStyle: {
      type: Object,
      default: () => {
        return {};
      }
    },
    showMsgByHover: {
      type: Boolean,
      default: false
    },
    hasMargin: {
      type: Boolean,
      default: true
    },
    fullWidth: {
      type: Boolean,
      default: false,
    }
  },
  mixins: [Emitter],
  data() {
    return {
      val: "",
      invalidMsg: "",
    };
  },

  methods: {
    onBlur() {
      this.$emit("blur");
    },
    getAreaValue(val) {
      this.$emit("change", val);
    },
    compChange(val) {
      setTimeout(() => {
        this.$emit("input", this.val);
        this.$emit("change", this.val);
      }, 10);

      // 验证触发设置延时，避免通过接口验证的组件一直发请求
      if(this.changeTimer){
        clearTimeout(this.changeTimer);
      }
      this.changeTimer = setTimeout(() => {
        this.valid().then(({ valid, invalidField }) => {
          this.changeValidStatus(valid, invalidField ? invalidField.message : "");
        });
      }, 500);
    },
    compBlur() {
      this.$emit("blur");
      return new Promise(resolve => {
        this.valid().then(({ valid, invalidField }) => {
          this.changeValidStatus(
            valid,
            invalidField ? invalidField.message : ""
          );
          resolve(valid);
        });
      });
    },
    valid() {
      return new Promise(resolve => {
        let rule = {};
        rule[this.validKey] = this.rules;
        let validator = new asyncValidator(rule);
        let validObj = {};
        if (this.rules.length) {
          validObj[this.validKey] = this.val;

          validator.validate(validObj, (errors, fields) => {
            if (errors && errors.length) {
              resolve({ valid: false, invalidField: errors[0] });
            } else {
              resolve({ valid: true });
            }
          });
        } else {
          resolve({ valid: true });
        }
      });
    },
    resetValid() {
      this.changeValidStatus(true);
    },
    changeValidStatus(valid, invalidMsg) {
      if (
        this.$refs.comp &&
        this.$refs.comp.toggleInvalidClass instanceof Function
      ) {
        this.$refs.comp.toggleInvalidClass(!valid);
      }
      if (!valid) {
        this.invalidMsg = invalidMsg || "error";
      } else {
        this.invalidMsg = "";
      }
    }
  },
  mounted() {
    this.val = this.value || this.value === 0 ? this.value : "";

    this.$emit("input", this.val);
    this.$emit("change", this.val);

    if (!this.hide) {
      this.dispatch("vformItem", "on-valid-item-add", this);
      this.dispatch("editTableCell", "on-valid-item-add", this);
    }
  },
  watch: {
    value: {
      handler(val) {
        if (JSON.stringify(this.val) !== JSON.stringify(this.value)) {
          this.val = this.value || this.value === 0 ? this.value : "";
        }
      }
    },
    hide: {
      handler(val) {
        if (this.hide) {
          this.dispatch("vformItem", "on-valid-item-remove", this);
        } else {
          this.dispatch("vformItem", "on-valid-item-add", this);
        }
      }
    },
    rules: {
      // 在表单组件的某一个元素动态切换 key 时，由于现有的逻辑是在validBox mounted 的时候执行 push 操作，
      // 因此如果动态切换组件，会把所有的 key 值不同的 validItem 都 push 进去，这样会导致验证的时候，没有渲染的组件的验证规则依然生效
      // 应用的组件： 净值信息--分配信息 modal， 切换分配类型时，右侧的组件动态切换，我们重置验证规则，而没有改变 key 值
      handler(newVal, oldVal){
        if(JSON.stringify(newVal) !== JSON.stringify(oldVal)){
          this.resetValid()
        }
      },
      // deep: true
    }
  }
};
</script>

<style lang="less" scoped>
.valid-container {
  position: relative;
  &.has-margin {
    margin-bottom: 3px;
  }
  &.validate {
    padding-bottom: 15px;
  }
  .comp-container {
    position: relative;
    text-align: left;
    &.comp-invalid:hover {
      .invalid-msg-hover {
        display: block;
      }
    }
    .invalid-msg-hover {
      display: none;
      position: fixed;
      width: auto;
      min-height: 18px;
      margin-top: 2px;
      padding: 3px 5px;
      border: 1px solid #f45;
      border-radius: 3px;
      background-color: #ffffcc;
      color: #f45;
      line-height: 18px;
      font-size: 12px;
      z-index: 1000;
      .triangle {
        display: block;
        position: absolute;
        left: 0;
        top: 0.5rem;
        width: 0.5rem;
        height: 0.5rem;
      }
    }
  }
  .invalid-msg-container {
    position: absolute;
    text-align: left;
    width: 100%;
    white-space: nowrap;
    font-size: 0;
    .invalid-msg {
      color: #f45;
      font-size: 12px;
    }
    .label-notice {
      display: inline-block;
      color: #666;
      font-size: 12px;
      margin-bottom: 5px;
    }
  }
}
</style>
