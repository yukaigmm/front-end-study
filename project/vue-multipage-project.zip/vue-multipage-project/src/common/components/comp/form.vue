<template>
  <div class="form" :class="{border: border}">
    <slot></slot>
  </div>
</template>

<script>
import _ from "lodash";
export default {
  name: "vform",
  props: {
    labelWidth: {
      type: [Number, String],
      default: 60
    },
    border: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      formItems: []
    };
  },
  methods: {
    valid() {
      // return
      let length = 0;
      let formValid = true;
      return new Promise((resolve, reject) => {
        Promise.all(this.formItems.map(item => item.valid())).then(result => {
          let finalResult = result.every(item => !!item);
          resolve(finalResult);
        });
      });
      
    },
    resetValid(resetFields) {
      if (resetFields.length) {
        this.formItems.forEach(formItem => {
          if (resetFields.indexOf(formItem.dataKey) !== -1) {
            formItem.resetValid();
          }
        });
      } else {
        this.formItems.forEach(formItem => {
          formItem.resetValid();
        });
      }
    }
  },
  created() {
    this.$on("on-form-item-add", formItem => {
      if (formItem) {
        this.formItems.push(formItem);
      }
      return false;
    });

    this.$on("on-form-item-remove", formItem => {
      if (formItem) {
        // this.formItems.push(formItem);
        let index = _.findIndex(this.formItems, formItem);
        this.formItems.splice(index, 1);
      }
    });
  },
  mounted() {
    this.formItems.forEach(item => {
      item.getParentLabelWidth(this.labelWidth);
    });
  }
};
</script>

<style lang="less" scoped>
.form {
  padding: 10px 0;
  background-color: transparent;
  position: relative;
  &.border {
    border: 1px solid #555;
  }
}
</style>
