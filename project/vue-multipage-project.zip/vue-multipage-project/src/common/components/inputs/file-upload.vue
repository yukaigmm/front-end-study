<template>
  <div
    class="file-upload-container"
    :class="{invalid: invalid}"
    @mouseout="leaveUploadContainer"
    @mouseover="hoverUploadContainer"
  >
    <vbutton active v-if="isImport" class="upload-btn" title="选取文件" @click="uploadFile">选取文件</vbutton>
    <div class="file-path-wrapper" v-show="!hideInput">
      <span
        class="file-path validate"
        v-if="val[resName]||docName"
        @click="downloadPath"
      >{{val[resName]||docName}}</span>
    </div>
    <div v-if="val[resName]||docName" v-show="showDelIcon" class="del-btn" @click.stop="delDoc">
      <span class="del">+</span>
    </div>
    <vloading v-model="loading"></vloading>
    <form ref="uploadForm" enctype="multipart/form-data" :action="`/${url}`" method="post">
      <input
        type="file"
        class="input-file"
        :accept="acceptType"
        :name="fileName"
        ref="docFile"
        :title="`${(val[resName]||docName)?'点击更换文件':''}`"
        :multiple="multiple"
        @change="changeValue"
      >
    </form>
  </div>
</template>

<script>
import "formdata-polyfill";
export default {
  props: {
    acceptType: {},
    typeWarn: {},
    acceptDetail: {},
    isImport: {
      default: true
    },
    value: {},
    multiple: {},
    url: {},
    fileName: {
      type: String,
      default: "fileName"
    },
    resName: {},
    hideInput: {
      type: Boolean,
      default: false
    },
    emptyFileObj: {
      type: Object,
      default: () => {
        return {
          filePath: "",
          fileName: ""
        };
      }
    },
    foreignPath: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      val: "",
      invalid: false,
      docName: "",
      showDelIcon: false,
      loading: false
    };
  },
  computed: {
    uploadTitle() {
      return this.val[this.resName] || this.docName ? "点击更换文件" : "";
    }
  },
  methods: {
    changeValue(event) {
      let files = event.target.files || window.event.target;
      let file = files[0] || {};
      let typeStatus = true;
      if (file.name && this.acceptDetail) {
        typeStatus = this.validateFileType(file.name, this.acceptDetail);
      }
      if (file.size > 20 * 1024 * 1024) {
        this.$message.error("请上传大小低于20M的文件！");
        return;
      } else if (typeStatus === false) {
        this.$message.error(this.typeWarn);
        return;
      } else {
        this.loading = true;
        this.docName = file.name;
        // let form = document.querySelector('#uploadForm');
        let form = this.$refs.uploadForm;
        let formData = new FormData(form);
        this.$http
          .post(this.url, formData)
          .then(res => {
            if (!res) return;
            if (res.code === 20000 && res.data) {
              let data = res.data;
              data.name = this.docName;
              this.$emit("input", data);
              this.$emit("change", data);
              this.$emit("getFileData");
              this.$refs.docFile.value = "";
              this.$message.success("上传成功!");
            } else {
              this.docName = "";
              this.resName = "";
              this.$message.error(res.msg);
            }
          })
          .done(() => {
            this.loading = false;
          });
      }
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    },
    uploadFile() {
      this.$refs.docFile.click();
    },
    delDoc() {
      this.docName = "";
      this.val = "";
      this.$emit("input", "");
      this.$emit("change", "");
      this.$emit("getFileData");
    },
    hoverUploadContainer() {
      this.showDelIcon = true;
    },
    leaveUploadContainer() {
      this.showDelIcon = false;
    },
    validateFileType(fileName, typeArray) {
      let fileNameArray = fileName.split(".");
      let fileSuffix = fileNameArray.pop();
      if (typeArray.includes(fileSuffix)) {
        return true;
      }
      return false;
    },
    downloadPath() {
      let path = this.val.filePath;
      if (path) {
        if (this.foreignPath) {
          path = path.replace("Uploads/", "Uploads/foreign/");
        }
        let url = `${
          this.$baseUrl[process.env.NODE_ENV]["staticFile"]
        }/${path}`;
        window.open(url);
      }
    }
  },
  mounted() {
    // this.val = this.value;
  },
  watch: {
    value: {
      handler(val) {
        if (JSON.parse(JSON.stringify(val) == "{}" || !val)) {
          this.val = { [this.resName]: "" };
          this.docName = "";
        } else {
          this.val = val;
        }
      },
      deep: true,

      immediate: true
    }
  }
};
</script>

<style lang="less" rel="styleSheet/less" scoped>
.file-upload-container {
  height: 26px;
  margin-bottom: 0;
  position: relative;
  color: #fff;
  .upload-btn {
    position: absolute;
    left: 0;
    top: 0;
    z-index: 1;
  }
  .file-path-wrapper {
    width: 100%;
    padding-left: 80px;
    position: relative;
    .file-path {
      font-size: 12px;
      display: block;
      width: 100%;
      height: 26px;
      line-height: 26px;
      color: #2992ff;
      cursor: pointer;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      &:hover {
        text-decoration: underline;
      }
    }
  }
  .del-btn {
    width: 20px;
    height: 20px;
    line-height: 16px;
    text-align: center;
    position: absolute;
    right: -10px;
    top: 50%;
    transform: translate(-50%, -50%) rotate(45deg);
    background-color: #aaa;
    border-radius: 50%;
    cursor: pointer;
    font-size: 0;
    .del {
      display: block;
      color: #fff;
      font-size: 26px;
      height: 20px;
      width: 20px;
    }
  }
  .input-file {
    display: none;
  }
}
</style>