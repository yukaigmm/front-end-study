<template>
  <el-checkbox-group v-model="value" @change="changeValue">
    <el-checkbox
      v-for="(option, index) in resultOptions"
      :key="index"
      :label="option.value"
      :class="{'no-label': !option.label.length}"
    >{{option.label}}</el-checkbox>
  </el-checkbox-group>
</template>

<script>
export default {
  props: {
    value: {
      type: [Array, String, Number],
      default: () => {
        return [];
      }
    },
    url: {
      type: String
    },
    valueKey: {
      type: String,
      default: "value"
    },
    labelKey: {
      type: String,
      default: "label"
    },
    options: {
      type: Array,
      default: () => {
        return [];
      }
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      invalid: false,
      urlOptions: []
    };
  },
  methods: {
    changeValue(val) {
      this.$emit("input", this.value);
      this.$emit("change", this.value);
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    }
  },
  computed: {
    resultOptions() {
      return this.options.length ? this.options : this.urlOptions;
    }
  },
  mounted() {
    if (this.url) {
      this.$http.get(url).then(resp => {
        this.urlOptions = resp.data.map(item => {
          return {
            label: item[this.labelKey],
            value: item[this.valueKey]
          };
        });
      });
    }
  }
};
</script>

<style lang="less" rel="styleSheet/less">
.el-checkbox-group {
  text-align: left;
  display: inline-block;
  width: auto;
  .el-checkbox {
    &.no-label {
      .el-checkbox__label {
        padding-left: 0;
      }
    }
  }
}
</style>