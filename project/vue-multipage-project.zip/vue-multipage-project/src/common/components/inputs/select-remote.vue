<template>
  <el-select
    :class="{invalid: invalid,'select-remote':true, 'full-width': fullWidth}"
    :clearable="clearable"
    v-model="selected"
    :multiple="multiple"
    :allow-create="allowCreate"
    :default-first-option="defaultFirstOption"
    filterable
    remote
    @focus="onFocus"
    @change="valueChange"
    :placeholder="placeholder"
    :remote-method="remoteMethod"
    :loading="loading"
    popper-class="remote-arrow"
    :disabled="disabled"
    @click.native="handleClick"
    @blur="handleBlur"
  >
    <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"></el-option>
  </el-select>
</template>

<script>
export default {
  props: {
    allowCreate: {
      type: Boolean,
      default: false
    },

    defaultFirstOption: {
      type: Boolean,
      default: false
    },

    index: {
      type: [String, Number, Object]
    },

    placeholder: {
      type: String,
      default: "请输入关键字"
    },
    // label关联关键字
    labelKey: {
      type: String,
      default: "label"
    },
    alternativeLabelKey: {
      type: String,
      default: "label"
    },
    searchKey: {
      type: String,
      default: ""
    },
    // 设置默认值时的label
    defaultLabel: {
      type: String,
      default: ""
    },
    // 选中的值
    value: {
      default: ""
    },
    // 是否多选
    multiple: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    // url
    remoteUrl: {
      type: String
    },
    // 请求方式
    requestType: {
      type: String,
      default: "get"
    },
    // 和value相关的关键字
    valueKey: {
      type: String
    },
    clearable: {
      type: Boolean,
      default: true
    },
    //是否在空时也进行搜索
    always: {
      type: Boolean,
      default: false
    },
    customerRemoteMethod: {
      type: Function
    },
    fullWidth: {
      type: Boolean,
      default: false
    }
  },
  watch: {
    value: {
      handler(val) {
        if (val && this.defaultLabel) {
          if (!this.options.length) {
            this.options = [{ value: this.value, label: this.defaultLabel }];
          }
        }
      },
      deep: true
    },

    defaultLabel: {
      handler(val) {
        if (val) {
          this.options = this.value
            ? [{ value: this.value, label: this.defaultLabel }]
            : [];
        }
      }
    }
  },

  computed: {
    selected: {
      get() {
        return this.value;
      },

      set() {
        // return this.value;
      }
    }
  },

  data() {
    return {
      loading: false,
      options: [],
      invalid: false
    };
  },
  destoryed() {
    this.options = [];
  },
  mounted() {
    if (this.value) {
      this.options = [{ value: this.value, label: this.defaultLabel }];
    }
  },
  methods: {
    onFocus() {
      this.$emit("focus");
    },
    toggleInvalidClass(invalid = false) {
      this.invalid = invalid;
    },

    valueChange(val) {
      this.$emit("input", val);
      this.$emit("change", val);
      let label = this.getLabel(val);
      this.$emit("onChange", label, this.index);
    },

    getLabel(val) {
      let matchOne = this.options.filter(item => item.value == val);
      let label = matchOne.length ? matchOne[0].label : "";
      return label;
    },
    handleClick(e) {
      e.stopPropagation();
      setTimeout(() => {
        $(e.target).removeAttr("readonly");
        $(e.target)
          .parent()
          .addClass("is-focus");
      }, 100);
      return false;
    },
    handleBlur(e) {
      // $(e.target).attr("readonly","readonly");
      setTimeout(() => {
        $(e.target).removeAttr("readonly");
      }, 100);
      $(e.target)
        .parent()
        .removeClass("is-focus");
    },
    // 模糊匹配
    remoteMethod(query) {
      this.loading = true;
      if (
        this.customerRemoteMethod &&
        this.customerRemoteMethod instanceof Function
      ) {
        this.customerRemoteMethod(query).then(options => {
          this.options = options.map(item => {
            return {
              label: item[this.labelKey] || item[this.alternativeLabelKey],
              value: item[this.valueKey]
            };
          });
          this.loading = false;
        });
      } else {
        if (query || this.always) {
          let params = {
            [this.searchKey || this.labelKey]: query
          };
          this.$http[this.requestType](this.remoteUrl, params).then(res => {
            if (res.data.records) {
              this.options = res.data.records.map(item => {
                return {
                  label: item[this.labelKey] || item[this.alternativeLabelKey],
                  value: item[this.valueKey]
                };
              });
            } else {
              this.options = res.data.map(item => {
                return {
                  label: item[this.labelKey] || item[this.alternativeLabelKey],
                  value: item[this.valueKey]
                };
              });
            }
            this.loading = false;
          });
        } else {
          this.loading = false;
        }
      }
    }
  }
};
</script>

<style lang="less">
.el-select.select-remote {
  &.full-width {
    width: 100%;
  }
  .el-input {
    .el-input__inner {
      color: #999;
    }
  }
  &.invalid {
    .el-input {
      input {
        border-color: #f45;
      }
    }
  }
}
</style>


