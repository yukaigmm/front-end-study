<template>
  <div class="editor">
    <textarea ref="editor" placeholder="请输入内容"></textarea>
  </div>
</template>

<script>
import E from "simditor";
// import "simditor-fullscreen";
// import "simditor-fullscreen/styles/simditor-fullscreen.css";
import "simditor/styles/simditor.css";
import baseUrlConfig from "../../../js/base-url-config.js";

export default {
  model: {
    prop: "value",
    event: "change"
  },

  props: {
    value: {
      default: ""
    },

    toolbarConfig: {
      type: Array,
      default: () => [
        "title",
        "bold",
        "italic",
        "underline",
        "strikethrough",
        "fontScale",
        "color",
        "ol",
        "ul",
        "blockquote",
        // "code",
        // "table",
        "link",
        "image",
        "hr",
        "indent",
        "outdent",
        "alignment",
      ]
    },

    uploadConfig: {
      type: Object,
      default: () => ({
        url: `${window.location.origin}/api/file/visitingCard`,
        fileKey: "directSalePicture"
      })
    }
  },

  data() {
    return {
      defaultImg: require("../../../../assets/images/company-logo-default.png"),
      editor: null
    };
  },

  mounted() {
    this.initEditor();
  },

  methods: {
    initEditor() {
      this.editor = new E({
        textarea: this.$refs.editor,
        toolbar: this.toolbarConfig,
        // pasteImage: true,
        upload: this.uploadConfig,
        toolbarFloat: true
        // defaultImage: this.defaultImg
      });
      let env = process.env.NODE_ENV;
      this.editor.setValue(this.value);
      this.editor.focus();
      this.editor.uploader.on(
        "uploadsuccess",
        (function(_this) {
          return function(e, file, result) {
            var $img, img_path, msg;

            if (!file.inline) {
              return;
            }

            $img = file.img;
            if (typeof result !== "object") {
              try {
                result = $.parseJSON(result);
              } catch (_error) {
                e = _error;
                result = {
                  success: false
                };
              }
            }

            if (result.success === false) {
              msg = result.msg || _this._t("uploadFailed");
              alert(msg);
              img_path = _this.defaultImage;
            } else {
              img_path = `${baseUrlConfig[env]["staticFile"]}${
                result.data.filePath
              }`;
            }

            $img[0]["src"] = img_path;
          };
        })(this.editor)
      );
      // this.editor.on("blur", e => {
      //   this.editor.hidePopover();
      // });

      // this.editor.on("selectionchanged",(e)=>{
      //   console.log("e",e)
      // })
      this.editor.on("valuechanged", (e, src) => {
        let data = this.editor.getValue();

        this.$emit("change", data || "");
      });
    }
  }
};
</script>

<style lang="less">
.simditor {
  width: 100%;
  border: 1px solid #555 !important;
  .simditor-wrapper {
    background: #ffffff !important;
    width: 100%;
    .simditor-body {
      background-color: transparent !important;
      width: 100%;
      max-height: 500px !important;
      min-height: 100px !important;
      overflow: auto !important;
      color: #666666 !important;
      padding: 5px !important;
    }

    .simditor-toolbar {
      width: 100%;
      color: #999;
      background: #181818 !important;
      border-bottom: 1px solid #555 !important;
    }
  }
}
// .simditor .simditor-toolbar > ul > li > .toolbar-item.active {
//   background: #111111 !important;
// }
.editor {
  width: 100%;
  color: #999;
}
.simditor .simditor-wrapper .simditor-placeholder,
.simditor .simditor-body,
.editor-style {
  color: #666666 !important;
  font-size: 12px !important;
}
.simditor .simditor-wrapper .simditor-placeholder {
  padding: 5px !important;
}

.simditor .simditor-body p,
.simditor .simditor-body div,
.editor-style p,
.editor-style div {
  color: #666666 !important;
}
.simditor .simditor-toolbar > ul > li > .toolbar-item {
  color: #999 !important;
  width: 28px !important;
  height: 25px !important;
  line-height: 25px !important;
}

.simditor .simditor-popover.link-popover .btn-unlink span,
.simditor .simditor-popover.image-popover .btn-upload span,
.simditor .simditor-popover.image-popover .btn-restore span {
  color: #999 !important;
}
.simditor .simditor-popover {
  border: 2px solid #555 !important;
  background: #222222 !important;
  border-radius: 8px !important;
}

.simditor .simditor-popover .settings-field {
  height: 40px !important;
  line-height: 40px !important;
}

.simditor .simditor-popover .settings-field input[type="text"] {
  padding: 0 5px !important;
  background-color: #181818 !important;
  height: 26px;
  outline: none !important;
  line-height: 26px;
  border-radius: 5px;
  color: #999999 !important;
  border: 1px solid #555;
  &:hover {
    border-color: #c0c4cc !important;
  }
  &:focus {
    border-color: #409eff !important;
  }
}

.simditor .simditor-popover .settings-field select {
  padding: 0 5px !important;
  background-color: #181818 !important;
  height: 26px;
  outline: none !important;
  line-height: 26px;
  border-radius: 5px;
  width: 200px;
  color: #999999 !important;
  border: 1px solid #555;
  &:hover {
    border-color: #c0c4cc !important;
  }
  &:focus {
    border-color: #409eff !important;
  }
}
</style>

