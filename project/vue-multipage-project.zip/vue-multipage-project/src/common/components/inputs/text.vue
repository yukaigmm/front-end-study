<template>
  <span class="text" :title="title || text || val" v-html="text ? text : val"></span>
</template>


<script>
export default {
  props: {
    value: {
      type: String,
      default: ""
    },
    text: {
      type: String,
      default: ""
    },
    options: {
      type: Array,
      default: () => []
    },
    valueKey: {
      type: String,
      default: "value"
    },
    labelKey: {
      type: String,
      default: "label"
    },
    number: {
      type: Boolean,
      default: false
    },
    floatPoint: {
      type: Number,
      default: 2
    },
    title: {
      type: String,
      default: "" 
    }
  },
  data() {
    return {};
  },
  computed: {
    val() {
      return this.options.length
        ? this.getOptionLabel(this.value)
        : this.number && this.value
        ? parseFloat(this.value).toFixed(this.floatPoint)
        : this.value;
    }
  },
  methods: {
    getOptionLabel(val) {
      let option =
        this.options.filter(option => {
          return `${option[this.valueKey]}` === `${val}`;
        })[0] || {};
      return option[this.labelKey] || "";
    }
  }
};
</script>

<style lang="less" scoped>
.text {
  display: block;
  width: 100%;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  color: #999;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
</style>
