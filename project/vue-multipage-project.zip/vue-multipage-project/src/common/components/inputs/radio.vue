<template>

  <el-radio-group v-model="value" @change="changeValue" class="radio-group">
    <el-radio 
      class="radio-label" 
      v-for="(option, index) in resultOptions" 
      :key="index"
      :label="option.value"
    >
      {{option.label}}
    </el-radio>
  </el-radio-group>
</template>

<script>
export default {
  props: {
    value: {
      type: [Number, String]
    },
    // radioKey: {
    // 	type: String,
    // 	// required: true,
    // 	default: 'radio'
    // },
    url: {
      type: String
    },
    valueKey: {
      type: String,
      default: "value"
    },
    labelKey: {
      type: String,
      default: "label"
    },
    options: {
      type: Array,
      default: () => {
        return [];
      }
    }
  },
  data() {
    return {
      invalid: false
    };
  },
  computed: {
    resultOptions() {
      return this.options.length
        ? this.options.map(item => {
            return {
              label: item[this.labelKey],
              value: item[this.valueKey]
            };
          })
        : this.urlOptions;
    }
  },
  methods: {
    changeValue(val) {
      this.$emit("input", this.value);
      this.$emit("change", this.value);
    },
    // isChecked(optionValue) {
    //   return `${this.val}` == `${optionValue}`;
    // },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    }
  },
  mounted() {
    if (this.url) {
      this.$http.get(url).then(resp => {
        this.urlOptions = resp.data.map(item => {
          return {
            label: item[this.labelKey],
            value: item[this.valueKey]
          };
        });
      });
    }
  },
};
</script>

<style lang="less" rel="styleSheet/less" scoped>
  .radio-group {
    height: 26px;
    .el-radio {
      height: 26px;
      line-height: 26px;
    }
  }
</style>