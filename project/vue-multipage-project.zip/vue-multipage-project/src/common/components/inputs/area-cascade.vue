<template>
  <el-row class="row">
    <el-col :span="8" class="province">
      <vselect
        v-model="province"
        ref="countrySelector"
        :options="provinceOptions"
        valueKey="value"
        labelKey="name"
        @change="changeProvince"
        :fullWidth="fullWidth"
      ></vselect>
    </el-col>
    <el-col :span="16" class="city">
      <vselect
        v-model="city"
        ref="citySelector"
        :options="cityOptions"
        valueKey="value"
        labelKey="name"
        @change="changeCity"
        :fullWidth="fullWidth"
      ></vselect>
    </el-col>
  </el-row>
</template>

<script>
export default {
  name: "varea",
  props: {
    value: {},
    fullWidth: {
      type: Boolean,
      default: false,
    }
  },
  data() {
    return {
      val: {},
      provinceOptions: [],
      province: "",
      lastProvince: "",
      city: "",
      invalid: false
    };
  },
  computed: {
    cityOptions() {
      let currentProvince = this.provinceOptions.filter(province => {
        return province.value == this.province;
      })[0] || { children: [] };

      return currentProvince.children;
    }
  },
  mounted() {
    this.getData();
  },

  methods: {
    toggleInvalidClass(invalid) {
      this.$refs.countrySelector.toggleInvalidClass(invalid);
      this.$refs.citySelector.toggleInvalidClass(invalid);
    },
    changeProvince(val) {
      // 切换省份时，清空城市
      if (this.lastProvince !== val || !val) {
        this.city = "";
        this.$refs.citySelector.val = "";
      }
      this.province = val;
      this.lastProvince = val;

      this.$nextTick(() => {
        if (this.cityOptions.length === 1) {
          this.city = this.cityOptions[0].value;
          this.$refs.citySelector.val = this.cityOptions[0].name;
        }
        this.$emit("input", { provinceId: this.province, cityId: this.city });
        this.$emit("change", { provinceId: this.province, cityId: this.city });
      });
    },

    changeCity(val) {
      this.city = val;
      this.$emit("input", { provinceId: this.province, cityId: this.city });
      this.$emit("change", { provinceId: this.province, cityId: this.city });
    },
    getData() {
      return new Promise(resolve => {
        if (
          this.provinceOptions instanceof Array &&
          this.provinceOptions.length
        ) {
          resolve();
        } else {
          // this.$http.get("/common/config/cRegisterCity").then(res => {
          //   this.provinceOptions = res.data.map( (item) =>{
          //     return {
          //       name: item.name,
          //       value: item.value,
          //       children: item.children.length ? item.children : [{
          //         name: item.name,
          //         value: item.value
          //       }]
          //     }
          //   });
          //   resolve();
          // });
          let fundMasterOptions = JSON.parse(
            sessionStorage.getItem("fund_master_options")
          );
          let registerCityOptons = fundMasterOptions.cRegisterCity;
          this.provinceOptions = registerCityOptons.map(item => {
            return {
              name: item.name,
              value: item.value,
              children: item.children.length
                ? item.children
                : [
                    {
                      name: item.name,
                      value: item.value
                    }
                  ]
            };
          });
        }
      });
    }
  },
  watch: {
    value: {
      handler(val) {
        this.val = this.value || {};
        this.province = this.val.provinceId || "";
        this.lastProvince = this.val.provinceId || "";
        this.city = this.val.cityId || "";
        this.getData().then(() => {
          if (this.city && !this.province) {
            let currentProvince =
              this.provinceOptions.filter(province => {
                return province.children.filter(item => {
                  return item.value == this.city;
                }).length;
              })[0] || {};

            this.province = currentProvince.value || "";
            this.lastProvince = currentProvince.value || "";
          }
        });
      },
      deep: true
    }
  }
};
</script>

<style lang="less" scoped>
.row {
  margin-bottom: 0;
  padding: 0 !important;
  .province {
    padding-right: 5px;
  }
  .city {
    padding-left: 5px;
  }
}
</style>

