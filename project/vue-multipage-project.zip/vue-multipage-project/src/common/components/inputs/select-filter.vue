<template>
  <el-select
    :class="{'invalid': invalid,'select-filter':true, 'full-width': fullWidth}"
    :placeholder="placeholder"
    v-model="val"
    filterable
    @change="valueChange"
    popper-class="filter-arrow"
    :clearable="clearable"
    :disabled="disabled"
  >
    <el-option
      v-for="item in resultOptions"
      :key="item.value"
      :label="item.label"
      :value="item.value"
    ></el-option>
  </el-select>
</template>

<script>
export default {
  props: {
    value: {
      type: [Number, String]
    },
    placeholder: {
      type: String,
      default: "请输入关键字"
    },
    valueKey: {
      type: String,
      default: "label"
    },
    labelKey: {
      type: String,
      default: "label"
    },
    multiple: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: false
    },
    options: {
      type: Array,
      default: () => []
    },
    fullWidth: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      val: ""
    };
  },
  computed: {
    resultOptions() {
      let resultOptions = this.options.length
        ? this.options.map(item => {
            return {
              value: item[this.valueKey],
              label: item[this.labelKey]
            };
          })
        : [];

      return resultOptions;
    }
  },
  methods: {
    valueChange(val) {
      this.$emit("input", this.val);
      this.$emit("change", this.val);
    }
  },
  watch: {
    value: {
      handler() {
        this.val = this.value;
      }
    }
  }
};
</script>

<style lang="less">
.el-select.select-filter {
  &.full-width {
    width: 100%;
  }
  .el-input {
    .el-input__inner {
      color: #999;
    }
  }
  &.invalid {
    .el-input {
      input {
        border-color: #f45;
      }
    }
  }
}
</style>
