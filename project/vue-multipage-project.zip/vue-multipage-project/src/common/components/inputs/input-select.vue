<template>
  <el-row :gutter="10">
    <el-col :span="12">
      <vselect
        ref="select"
        v-bind="computedSelectConfig"
        v-model="selectValue"
        @change="selectChange"
      ></vselect>
    </el-col>
    <el-col :span="12">
      <vinput
        ref="input"
        :disabled="disabled"
        v-bind="inputConfig"
        v-model="inputValue"
        @change="inputChange"
      ></vinput>
    </el-col>
  </el-row>
</template>


<script>
export default {
  props: {
    value: {},
    inputConfig: {
      type: Object,
      default: () => {
        return {};
      }
    },
    selectConfig: {
      type: Object,
      default: () => {
        return {};
      }
    },
    floatLength: {
      type: [Number, String],
      default: 2
    },
    customValue: {
      type: [Number, String],
      default: -10000
    },
    customLabel: {
      type: String,
      default: "自定义"
    }
  },
  data() {
    return {
      selectValue: "",
      inputValue: ""
    };
  },
  computed: {
    computedSelectConfig() {
      let config = JSON.parse(JSON.stringify(this.selectConfig));
      let options = [].concat(this.selectConfig.options);
      options.push({
        value: this.customValue,
        label: this.customLabel
      });
      config.options = options;
      return config;
    },
    disabled() {
      return !(this.selectValue === this.customValue);
    }
  },
  methods: {
    selectChange() {
      if (this.selectValue !== this.customValue) {
        this.$emit("input", this.selectValue, false);
        this.$emit("change", this.selectValue, false);
      } else {
        this.$emit("input", this.inputValue);
        this.$emit("change", this.inputValue);
      }
    },
    inputChange() {
      this.$emit("input", this.inputValue);
      this.$emit("change", this.inputValue);
    },
    toggleInvalidClass(invalid) {
      this.$refs.select.toggleInvalidClass(invalid);
      this.$refs.input.toggleInvalidClass(invalid);
    }
  },
  watch: {
    value: {
      handler(val) {
        if (this.value !== undefined || this.value !== null) {
          let selectItem =
            this.computedSelectConfig.options.filter(option => {
              return option.value == parseInt(this.value);
            })[0] || undefined;
          if (selectItem) {
            this.selectValue = selectItem.value;
            this.inputValue = "";
          } else {
            this.selectValue = this.customValue;
            this.inputValue = this.value;
            // this.inputValue = this.floatLength?parseFloat(this.value).toFixed(this.floatLength):this.value;
          }
        } else {
          this.selectValue = "";
          this.inputValue = "";
        }

        //  没有值的时候，选项也应该是空
        // if(!val){
        //   this.selectValue = "";
        // }
      },
      deep: true
    }
  }
};
</script>

<style lang="less" scoped>
</style>
