<template>
  <div
    class="video-file-upload file-field input-field"
    :class="{invalid: invalid}"
    @mouseout="leaveUploadContainer"
    @mouseover="hoverUploadContainer"
  >
    <div class="btn" @click="uploadFile">
      <vbutton active v-if="isImport" title="导入" :onlyIcon="true" icon="import_export"></vbutton>
      <!-- <span v-else class="highlight file-button">{{!val || !(val[resName])?'上传':'更换'}}</span> -->
      <vbutton active v-else class="upload-btn">{{!val || !(val[resName])?'上传':'更换'}}</vbutton>
      <form ref="uploadForm" enctype="multipart/form-data" :action="`/${url}`" method="post">
        <input
          type="file"
          class="input-file"
          :accept="acceptType"
          :name="fileName"
          ref="docFile"
          :title="`${(val[resName]||docName)?'点击更换文件':''}`"
          :multiple="multiple"
          @change="changeValue"
        >
      </form>
    </div>
    <div class="file-path-wrapper" v-show="!hideInput">
      <span class="file-path-cover"></span>
      <input type="text" class="file-path" style="display:none">
      <span class="file-path validate" @click="showPreview">{{val[resName]||docName}}</span>
      <div v-if="val[resName]||docName" v-show="showDelIcon" class="del-btn" @click.stop="delDoc">
        <span class="del">+</span>
      </div>
    </div>
    <video-preview ref="previewVideo" class="upload-video-preview"></video-preview>
    <vloading v-model="loading"></vloading>
  </div>
</template>

<script>
import "formdata-polyfill";
import videojs from "video.js";
import "video.js/dist/video-js.css";
import videoPreview from "../comp/video-preview.vue";

export default {
  // props: {
  // 	value: {

  // 	},
  // 	multiple: {
  // 		type: Boolean,
  // 		default: false,
  // 	},
  // },
  components: {
    videoPreview
  },
  props: {
    acceptType: {},
    typeWarn: {},
    acceptDetail: {},
    previewUrl: {},
    isImport: {
      default: false
    },
    value: {},
    multiple: {},
    url: {},
    fileName: {
      type: String,
      default: "fileName"
    },
    resName: {},
    hideInput: {
      type: Boolean,
      default: false
    },
    emptyFileObj: {
      type: Object,
      default: () => {
        return {
          filePath: "",
          fileName: ""
        };
      }
    }
  },
  data() {
    return {
      val: "",
      invalid: false,
      docName: "",
      showDelIcon: false,
      loading: false,
      showVideo: false,
      preview: false
    };
  },
  computed: {
    uploadTitle() {
      return this.val[this.resName] || this.docName ? "点击更换文件" : "";
    }
  },
  methods: {
    changeValue(event) {
      let files = event.target.files || window.event.target;
      let file = files[0] || {};
      let typeStatus = true;
      if (file.name && this.acceptDetail) {
        typeStatus = this.validateFileType(file.name, this.acceptDetail);
      }
      if (file.size > 50 * 1024 * 1024) {
        this.$message.error("请上传大小低于50M的文件！");
        return;
      } else if (typeStatus === false) {
        this.$message.error(this.typeWarn);
        return;
      } else {
        this.loading = true;
        this.docName = file.name;
        // let form = document.querySelector('#uploadForm');
        let form = this.$refs.uploadForm;
        let formData = new FormData(form);
        this.$http
          .post(this.url, formData)
          .then(res => {
            if (!res) return;
            if (res.code === 20000 && res.data) {
              let data = res.data;
              this.videoUrl =
                this.$baseUrl[process.env.NODE_ENV]["staticFile"] +
                data.filePath;
              data.name = this.docName;
              this.$emit("input", data);
              this.$emit("change", data);
              this.$refs.docFile.value = "";
              this.$message.success("上传成功!");
            } else {
              this.docName = "";
              this.resName = "";
              this.$message.error(res.msg);
            }
          })
          .done(() => {
            this.loading = false;
          });
      }
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    },
    uploadFile() {
      this.$refs.docFile.click();
    },
    delDoc() {
      this.docName = "";
      this.val = "";
      this.$emit("input", "");
      this.$emit("change", "");
    },
    hoverUploadContainer() {
      this.showDelIcon = true;
    },
    leaveUploadContainer() {
      this.showDelIcon = false;
    },
    validateFileType(fileName, typeArray) {
      let fileNameArray = fileName.split(".");
      let fileSuffix = fileNameArray.pop();
      if (typeArray.includes(fileSuffix)) {
        return true;
      }
      return false;
    },
    setPreviewStatus() {
      this.preview = !this.preview;
    },
    getVideoUrl(file) {
      let reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.videoUrl = reader.result;
      };
    },
    showPreview() {
      this.$refs.previewVideo.open(this.videoUrl);
    }
  },
  mounted() {
    // this.val = this.value;
    // this.videoUrl = this.previewUrl;
  },
  watch: {
    value: {
      handler(val) {
        if (JSON.parse(JSON.stringify(val) == "{}" || !val)) {
          this.val = { [this.resName]: "" };
          this.docName = "";
          this.preview = false;
        } else {
          this.val = val;
        }
      },
      deep: true
    },
    val: {
      handler(val) {},
      deep: true
    },
    previewUrl: {
      handler(val) {
        if (val) {
          this.videoUrl = val;
        }
      },
      deep: true
    }
  }
};
</script>

<style lang="less" rel="styleSheet/less">
.video-file-upload {
  // height: 30px;
  margin-bottom: 0;
  position: relative;
  .btn {
    width: 70px;
    height: 26px;
    line-height: 26px;
    float: left;
    color: #fff;
    // background-color: #2992ff;
  }
  .file-path-wrapper {
    // position: absolute;
    // width: 100%;
    height: 30px;
    position: relative;
    margin-left: 80px;
    & > input {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      // cursor: pointer;
    }
    .file-path-cover {
      // position: absolute;
      width: 100%;
      height: 100%;
      cursor: text;
      // cursor: pointer;
    }
    .file-path {
      font-size: 12px;
      display: inline-block;
      height: 30px;
      line-height: 30px;
      color: #2992ff;
      cursor: pointer;
      &:hover {
        text-decoration: underline;
      }
    }
  }
  .input-file {
    // z-index: 99999;
    display: none;
  }
  .del-btn {
    width: 20px;
    height: 20px;
    line-height: 16px;
    text-align: center;
    position: absolute;
    right: -10px;
    top: 50%;
    transform: translate(-50%, -50%) rotate(45deg);
    background-color: #aaa;
    border-radius: 50%;
    cursor: pointer;
    font-size: 0;
    .del {
      display: block;
      color: #fff;
      font-size: 26px;
      height: 20px;
      width: 20px;
    }
  }
  .upload-video-preview {
    width: 1040px;
    height: 630px !important;
    min-height: 0 !important;
    max-height: 1000px !important;
    top: -2px !important;
    left: -20%;
    .video-js {
      float: left;
      width: 100%;
      height: 100%;
      .video {
        width: 100%;
        height: 100%;
      }
    }
  }
  .modal-overlay {
    display: none !important;
  }
  .modal .modal-content .content {
    padding-bottom: 0px !important;
  }
}
</style>