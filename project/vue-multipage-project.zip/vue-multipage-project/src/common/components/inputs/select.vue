<template>
  <el-select v-model="val" placeholder="请选择" class="select" :class="{'full-width': fullWidth, 'invalid': invalid}" @change="changeValue">
    <el-option
      v-for="(option, index) in resultOptions"
      :key="index"
      :class="{selected: value === option.value}"
      :value="option.value"
      :label="option.label"
    ></el-option>
  </el-select>
</template>
<script>
import $ from "jquery";
export default {
  props: {
    value: {
      type: [Number, String, Array]
    },
    placeholder: {
      type: String,
      default: "请选择"
    },
    multiple: {
      type: Boolean,
      default: false
    },
    url: {
      type: String
    },
    type: {
      type: String,
      default: "get"
    },
    searchParam: {
      type: Object,
      default: () => {
        return {};
      }
    },
    valueKey: {
      type: String,
      default: "value"
    },
    labelKey: {
      type: String,
      default: "label"
    },
    options: {
      type: Array,
      default: () => {
        return [];
      }
    },
    disabled: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: false
    },
    extendKey: {
      type: String
    },
    fullWidth: {
      type: Boolean,
      default: false,
    }
  },

  data() {
    return {
      urlOptions: [],
      invalid: false,
      val: ""
    };
  },

  computed: {
    resultOptions() {
      return this.options.length
        ? this.options.map(item => {
            return {
              label: item[this.labelKey],
              value: `${item[this.valueKey]}`
            };
          })
        : this.urlOptions;
    }
  },

  mounted() {
    this.val = `${this.value}`;
    if (!this.url) {
      return;
    }

    // 动态数据
    //
    let method = this.type;
    let params = this.searchParam;

    this.$http[method](this.url, params).then(resp => {
      let dataArr = this.extendKey ? resp.data[this.extendKey] : resp.data;
      this.urlOptions = dataArr.map(item => {
        return {
          label: item[this.labelKey],
          value: `${item[this.valueKey]}`
        };
      });
    });
  },

  methods: {
    changeValue() {
      this.$emit("input", this.val);
      this.$emit("change", this.val);
    },

    toggleInvalidClass(invalid = false) {
      this.invalid = invalid;
    }
  },

  watch: {
    value: {
      handler(val) {
        this.val = `${this.value}`;
      }
      // immediate: true
    }
  }
};
</script>






<style lang="less" rel="styleSheet/less">
.el-select.select {
  &.full-width {
    width: 100%;
  }
  // .el-input__inner {
  //   color: #999;
  // }
  &.invalid {
    .el-input {
      input {
        border-color: #f45;
      }
    }
  }
}
//select 下拉框箭头
// .el-select-dropdown.el-popper {
//   &[x-placement^="bottom"] {
//     .popper__arrow {
//       &:after {
//         border-bottom-color: #181818 !important;
//       }
//     }
//   }
//   &[x-placement^="top"] {
//     .popper__arrow {
//       &:after {
//         border-top-color: #181818 !important;
//       }
//     }
//   }
// }
</style>