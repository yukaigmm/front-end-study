<template>
  <div class="img-total-container">
    <div
      class="preview-img"
      ref="previewImg"
      :style="imgStyle"
      @click="uploadImage"
      @mouseover="showNotice"
      @mouseout="hideNotice"
    >
      <div class="img-container-parent">
        <div
          ref="imgTotalContainer"
          class="img-container"
          :style="{backgroundImage: src ? '' : showRecommendSize?'':`url('${computedDefaultImage}')`}"
        >
          <img ref="img" :src="src" alt class="img" :style="{transform: `scale(${imgScale})`}" />
          <span v-show="showRecommendSize&&!src" class="recommend-size-wrapper">{{recommendSize}}</span>
        </div>
      </div>
      <form ref="uploadForm" enctype="multipart/form-data">
        <input
          type="file"
          ref="imageFile"
          :name="fieldName"
          accept="image/*"
          class="image-file"
          @change="changeValue"
        />
      </form>
      <div v-if="src" class="del-btn" @click="delImg">
        <span class="del">+</span>
      </div>
      <div class="notice" :class="{'show-notice':notice}">{{`点击${src?'更换':'上传'}${title}`}}</div>
    </div>
    <vloading v-model="loading"></vloading>
  </div>
</template>

<script>
import "formdata-polyfill";

export default {
  model: {
    prop: "value",
    event: "change"
  },
  props: {
    showRecommendSize: {
      type: Boolean,
      default: false
    },

    recommendSize: {
      type: String,
      default: ""
    },

    value: {},
    url: {
      type: String,
      default: "common/upload"
    },
    fieldName: {
      type: String,
      default: "file"
    },
    title: {
      type: String,
      default: "图片"
    },
    defaultImage: {
      type: String,
      default: "/assets/images/company-logo-default.png"
    },
    imgStyle: {
      type: Object,
      default: () => {
        return {
          width: "100px",
          height: "100px"
        };
      }
    },
    foreignPath: {
      type: Boolean,
      default: false
    },

    fullPath: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      src: "",
      invalid: false,
      notice: false,
      imgScale: 1,
      loading: false
    };
  },
  methods: {
    uploadImage() {
      this.$refs.imageFile.click();
    },
    changeValue(event) {
      let files = event.target.files;
      let file = files[0] || {};

      if (file.name && file.size) {
        this.loading = true;
        if (file.size > 5 * 1024 * 1024) {
          this.$message.error("请上传小于5M的图片");
          this.loading = false;
        } else {
          let form = this.$refs.uploadForm;
          let formData = new FormData(form);
          this.$http.post(this.url, formData).then(res => {
            this.loading = false;
            if (!res) return;
            if (res && res.code === 20000) {
              let path = res.data.filePath;
              let staticPath = path;

              //此处专门用于处理公司logo和人物logo。因为都是放在申报系统对应文件夹中。
              if (this.foreignPath) {
                staticPath = staticPath.replace("Uploads/", "Uploads/foreign/");
              }

              this.src = `${
                this.$baseUrl[process.env.NODE_ENV]["staticFile"]
              }/${staticPath}`;
              // this.scaleImg();

              if (this.fullPath) {
                this.$emit("input", this.src);
                this.$emit("change", this.src);
              } else {
                this.$emit("input", path);
                this.$emit("change", path);
              }

              this.$refs.imageFile.value = "";
            } else {
              this.$message({
                type: "error",
                message: "请选择图片文件进行上传",
                showClose: true
              });
            }
          });
        }
      }
    },
    delImg(e) {
      e.stopPropagation();
      this.src = "";
      this.$refs.imageFile.value = "";
      // this.scaleImg();
      this.$emit("input", "");
      this.$emit("change", "");
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    },
    showNotice() {
      // this.$el()
      this.notice = true;
    },
    hideNotice() {
      this.notice = false;
    },
    scaleImg() {
      this.$nextTick(() => {
        let imgTotalContainer = this.$refs.imgTotalContainer;
        if (!imgTotalContainer) {
          return;
        }
        let style = window.getComputedStyle(imgTotalContainer);

        if (this.src) {
          let img = new Image();
          img.src = this.src;
          img.onload = () => {
            let imgWidth = img.width;
            let imgHeight = img.height;

            let xScale = parseInt(style.width) / img.width;
            let yScale = parseInt(style.height) / img.height;

            let finalScale = (xScale > yScale ? yScale : xScale).toFixed(2);

            // if ( finalScale > 1) {
            this.imgScale = finalScale;

            // this.$refs.previewImg.style.width = `${img.width * finalScale}px`;
            // } else {
            //   this.imgScale = 1;
            // }
          };
        } else {
          this.$refs.previewImg.style.width = "auto";
        }
      });
    }
  },
  computed: {
    tip() {
      return this.src ? "点击更改图片" : "点击上传图片";
    },
    computedDefaultImage() {
      return (
        `${this.$baseUrl[process.env.NODE_ENV]["page"]}` + this.defaultImage
      );
    }
  },
  watch: {
    value: {
      handler(val) {
        // if (val) {
        let staticPath = val;
        if (this.foreignPath) {
          staticPath = staticPath.replace("Uploads/", "Uploads/foreign/");
        }
        if (this.fullPath) {
          this.src = val || "";
        } else {
          this.src = val
            ? `${
                this.$baseUrl[process.env.NODE_ENV]["staticFile"]
              }/${staticPath}`
            : "";
        }

        // this.scaleImg();
        // }
      },

      immediate: true
    }
  }
};
</script>

<style lang="less" scoped>
.recommend-size-wrapper {
  display: inline-block;
  height: 12px;
  line-height: 12px;
  width: 100%;
  font-size: 12px;
  color: #666;
}

.img-total-container {
  // position: relative;
  text-align: center;
  font-size: 0;

  // overflow: hidden;
}
.preview-img {
  padding: 2px;
  display: block;
  position: relative;
  cursor: pointer;
  // overflow: hidden;
  // width: 100px;
  // height: 100px;
  border: 1px solid #666;
  &.preview-big {
    width: 150px;
    height: 150px;
  }
  &:hover {
    border-color: #c0c4c4;
  }
  .img-container-parent {
    overflow: hidden;
    height: 100%;
  }
  .img-container {
    height: 100%;
    // overflow: hidden;
    text-align: center;
    // position: relative;
    background-repeat: no-repeat;
    // background-size: 100% auto;
    background-position: center;
    display: flex; /*Flex布局*/
    display: -webkit-flex; /* Safari */
    align-items: center; /*指定垂直居中*/
    justify-content: center;
    .img {
      // width: auto;
      // height: 100%;
      // position: absolute;
      // top: 50%;
      // left: 50%;
      // transform: translate(-50%,-50%);
      display: block;
      transform-origin: center;
      width: auto;
      height: auto;
      max-width: 100%;
      max-height: 100%;
    }
  }
  .image-file {
    display: none;
  }
  .del-btn {
    width: 20px;
    height: 20px;
    line-height: 16px;
    text-align: center;
    position: absolute;
    right: 0;
    top: 0;
    transform: translate(50%, -50%) rotate(45deg);
    background-color: #aaa;
    border-radius: 50%;
    cursor: pointer;
    font-size: 0;
    .del {
      display: block;
      color: #fff;
      font-size: 26px;
      height: 20px;
      width: 20px;
    }
  }
  .notice {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    color: #fff;
    display: none;
    text-align: center;
    font-size: 12px;
  }
  .show-notice {
    display: block;
  }
}
</style>

