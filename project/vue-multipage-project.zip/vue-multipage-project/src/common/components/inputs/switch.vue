<template>
  <div class="switch" :class="{invalid: invalid}">
    <!-- <label v-if="type === 'normal'">
      {{falseLabel}}
      <input type="checkbox" v-model="val" @change="changeValue">
      <span class="lever"></span>
      {{trueLabel}}
    </label>-->
    <el-switch
      v-if="type === 'normal'"
      v-model="value"
      @change="changeValue"
      :active-text="trueLabel"
      :inactive-text="falseLabel"
      :active-value="trueValue"
      :inactive-value="falseValue"
    ></el-switch>
    <vcheckbox
      v-if="type === 'checkbox'"
      :options="checkboxOptions"
      :key="key"
      @change="changeValue"
      v-model="checkboxVal"
      :disabled="disabled"
    ></vcheckbox>
  </div>
</template>

<script>
export default {
  props: {
    value: {
      type: [Boolean, Number],
      default: false
    },
    type: {
      type: String,
      default: "normal"
    },
    falseLabel: {
      type: String,
      default: "否"
    },
    trueLabel: {
      type: String,
      default: "是"
    },
    falseValue: {
      type: [Boolean, Number],
      default: false
    },
    trueValue: {
      type: [Boolean, Number],
      default: true
    },
    disabled: {
      type: Boolean,
      default: false
    },
    key: {
      type: [String, Number]
    },
    clearVal: {
      type: [Boolean, Object],
      default: false
    },
    id: {
      type: [String, Number]
    }
  },
  data() {
    return {
      val: false,
      invalid: false,
      checkboxVal: []
    };
  },
  computed: {
    checkboxOptions() {
      return [
        {
          value: this.trueValue,
          label: this.trueLabel
        }
      ];
    }
  },
  methods: {
    changeValue() {
      if (this.type === "normal") {
        this.$emit("input", this.value);
        this.$emit("change", this.value);
      } else if (this.type === "checkbox") {
        let emitValue =
          this.checkboxVal.length && this.checkboxVal[0] === this.trueValue
            ? this.trueValue
            : this.falseValue;
        this.$emit("input", emitValue);
        this.$emit("change", emitValue);
      }
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    }
  },
  mounted() {
    if (this.type === "normal") {
      this.val = this.value === this.trueValue;
    } else if (this.type === "checkbox") {
      this.checkboxVal = [];
      if (this.value === this.trueValue) {
        this.checkboxVal.push(this.trueValue);
      }
    }
  },
  watch: {
    value: {
      handler(val) {
        if (this.type === "checkbox") {
          if (`${this.value}` === `${this.trueValue}`) {
            this.checkboxVal = [this.trueValue];
          } else {
            this.checkboxVal = [];
          }
        }
      },
      deep: true
    },
    clearVal: {
      handler(val) {
        if (val.overChosen == true && val.id == this.id) {
          this.checkboxVal = [];
          this.$message.error("最多只能收藏十条基金！");
        }
        if (val == true) {
          this.checkboxVal = [];
        }
      },
      deep: true
    }
  }
};
</script>

<style lang="less" rel="styleSheet/less" >
.switch {
  height: 26px;
  .el-checkbox-group {
    height: 26px;
    line-height: 26px;
  }
  .el-switch__label {
    color: #999;
  }
}
</style>