<template>
  <div class="input-container" :style="containerStyle">
    <div
      class="input-box"
      :class="{focus: inputBoxFocus, invalid: invalid&&!isWarnning, disabled: disabled, unit: unit}"
    >
      <el-input 
        v-model="val"
        class="input"
        :class="{number:number,warning:invalid&&isWarnning, 'full-width': fullWidth}"
        :disabled="disabled"
        :placeholder="placeholder"
        :type="inputType"
        @blur="onBlur"
        @focus="onFocus"
        @input="changeValue"
        @change="numChange"
      ></el-input>
    </div>
    <span v-if="unit" ref="unitSpan" class="input-unit">{{unit}}</span>
  </div>
</template>

<script>
export default {
  props: {
    isWarnning: {
      type: [Boolean],
      default: false
    },
    value: {
      type: [Number, String]
    },
    inputType: {
      type: String,
      default: "text"
    },
    placeholder: {
      type: String,
      default: ""
    },
    disabled: {
      type: Boolean,
      default: false
    },
    clickSelect: {
      type: Boolean,
      default: false
    },
    floatPoint: {
      type: [Number, String],
      default: 2
    },
    unit: {
      type: String
    },
    number: {
      type: Boolean,
      default: false
    },
    fullWidth: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      val: "",
      invalid: false,
      containerStyle: {},
      time: null,
      timer: {},
      changeTimer: null,
      numberTimer: null,
      inputBoxFocus: false
    };
  },
  methods: {
    changeValue() {
      // clearTimeout(this.changeTimer);
      // this.changeTimer = setTimeout( () => {
      if (this.number !== true) {
        this.$emit("input", this.val.trim());
        this.$emit("change", this.val.trim());
      } else {
        this.val = this.val.replace(/[a-zA-z]/, "");
      }
      // }, 300)
    },
    numChange() {
      // clearTimeout(this.numberTimer);
      // this.numberTimer = setTimeout( () => {
        // toFixed 返回的是 string 类型，因此再用 parseFloat 处理一遍
      if (this.number == true) {
        this.val =
          parseFloat(this.val) || parseFloat(this.val) === 0
            ? parseFloat(parseFloat(this.val).toFixed(this.floatPoint))
            : null;
        this.$emit("input", this.val);
        this.$emit("change", this.val);
      }
      // }, 300)
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    },
    onFocus(e) {
      this.inputBoxFocus = true;
      if (this.clickSelect) {
        e.target.select();
      }
    },
    onBlur() {
      this.inputBoxFocus = false;
      this.$emit("blur");
    }
  },
  mounted() {
    if (this.number == true) {
      if (parseFloat(this.value) || parseFloat(this.value) === 0) {
        this.val = parseFloat(this.value).toFixed(this.floatPoint);
      } else {
        this.val = null;
      }
    } else {
      this.val = this.value || "";
    }
  },

  watch: {
    value: {
      handler(val) {
        // this.$emit("blur");
        if (this.number == true) {
          if (parseFloat(val) || parseFloat(val) === 0) {
            this.val = parseFloat(val).toFixed(this.floatPoint);
          } else {
            this.val = null;
          }
        } else {
          this.val = this.value;
        }
      },
      deep: true
    }
  }
};
</script>

<style lang="less" rel="styleSheet/less">
.input-container{
  position: relative;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  .input-box {
    width: 100%;
    &.unit{
      width: calc(~"100% - 15px");
    }
    font-size: 0;
    &.invalid {
      .el-input {
        input {
          border-color: #f45;
        }
      }
    }
  }
  .el-input {
    &.is-disabled {
      input {
        background-color: #181818;
        border-color: #555;
      }
    }
    &.number {
      input {
        text-align: right;
      }
    }
    &.full-width {
      width: 100%;
      max-width: 100%;
    }
  }
  .input-unit {
    display: block;
    font-size: 12px;
    margin-left: 3px;
    white-space: nowrap;
  }
}

</style>