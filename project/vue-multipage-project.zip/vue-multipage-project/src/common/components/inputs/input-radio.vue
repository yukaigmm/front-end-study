<template>
  <div class="row input-radio clear">
    <div class="radio-comp-container">
      <vradio ref="radio" v-bind="computedRadioConfig" v-model="radioValue" @change="radioChange"></vradio>
    </div>
    <div class="input-comp-container">
      <vinput
        class="radio-input"
        ref="input"
        v-show="showInput"
        :number="unit?true:false"
        :floatPoint="floatPoint"
        :unit="unit"
        v-bind="inputConfig"
        v-model="inputValue"
        @change="inputChange"
      ></vinput>
    </div>
  </div>
</template>


<script>
export default {
  props: {
    value: {},
    inputConfig: {
      type: Object,
      default: () => {
        return {};
      }
    },
    radioConfig: {
      type: Object,
      default: () => {
        return {};
      }
    },
    floatLength: {
      type: [Number, String],
      default: 2
    },
    unit: {
      type: String
    },
    floatPoint: {
      type: [String, Number]
    }
  },
  data() {
    return {
      radioValue: "",
      inputValue: "",
      customValue: -10000
    };
  },
  computed: {
    computedRadioConfig() {
      let config = JSON.parse(JSON.stringify(this.radioConfig));
      let options = [].concat(this.radioConfig.options);
      options.push({
        value: this.customValue,
        label: "自定义"
      });
      config.options = options;
      return config;
    },
    showInput() {
      return this.radioValue === this.customValue;
    }
  },
  methods: {
    radioChange() {
      if (this.radioValue !== this.customValue) {
        this.$emit("input", this.radioValue);
        this.$emit("change", this.radioValue);
      } else {
        this.$emit("input", this.inputValue);
        this.$emit("change", this.inputValue);
      }
    },
    inputChange() {
      this.$emit("input", this.inputValue);
      this.$emit("change", this.inputValue);
    },
    toggleInvalidClass(invalid) {
      this.$refs.radio.toggleInvalidClass(invalid);
      this.$refs.input.toggleInvalidClass(invalid);
    }
  },
  watch: {
    value: {
      handler(val) {
        if (this.value !== undefined || this.value !== null) {
          let selectItem =
            this.computedRadioConfig.options.filter(option => {
              return `${option.value}` == `${this.value}`;
            })[0] || undefined;
          if (selectItem) {
            this.radioValue = selectItem.value;
            this.inputValue = "";
          } else {
            this.radioValue = this.customValue;
            this.inputValue = this.value;
            // this.inputValue = this.floatLength?parseFloat(this.value).toFixed(this.floatLength):this.value;
          }
        } else {
          this.radioValue = "";
          this.inputValue = "";
        }

        //  没有值的时候，选项也应该是空
        // if(!val){
        //   this.radioValue = "";
        // }
      },
      deep: true
    }
  }
};
</script>

<style lang="less">
.row {
  padding: 0;
}
.input-radio {
  margin-bottom: 0;
}
.radio-comp-container {
  // max-width: 250px;
  float: left;
}
.input-comp-container {
  float: left;
  width: 60px;
  margin-left: 10px;
}
</style>
