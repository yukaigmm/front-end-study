<template>
  <el-row :class="{'editCell':true, 'item':true,'eidit-table-cell-text-right':ifTextAlignRight}">
    <el-col :span="24">
      <vvalidBox
        @blur="onValidBoxBlur"
        :ref="comps.key"
        :validKey="comps.key"
        :rules="comps.rules"
        :comp="comps"
        v-model="tableValue"
        :showMsgByHover="true"
        @change="validBoxChange"
        :validate="validate"
        :hasMargin="false"
        :fullWidth="true"
      ></vvalidBox>
      <slot></slot>
    </el-col>
  </el-row>
</template>

<script>
export default {
  name: "editTableCell",
  props: {
    ifTextAlignRight: {
      type: Boolean,
      default: false
    },
    comps: {
      type: Object
    },
    value: {
      type: [String, Number, Object]
    },
    field: {
      type: String
    },
    rowData: {
      type: Object
    },
    index: {
      type: Number
    },
    validate: {
      type: Boolean,
      default: false
    },
    tableRow: {}
  },

  data() {
    return {
      validItems: [],
      val: ""
    };
  },

  created() {
    this.$on("on-valid-item-add", validItem => {
      if (validItem) {
        this.validItems.push(validItem);
      }
      return false;
    });
  },

  computed: {
    tableValue: {
      get() {
        return this.value;
      },
      set() {}
    }
  },

  mounted() {
    if (this.tableRow || this.tableRow === false) {
      this.valid();
    }
  },
  watch: {
    tableRow: {
      handler(val) {
        this.valid();
      },
      deep: true,
      // immediate:true
    },
    value: {
      handler(val) {}
    }
  },
  methods: {
    onValidBoxBlur() {
      this.$emit("blur");
    },

    validBoxChange(val) {
      this.$emit("input", val);
      this.$emit("change", val);
    },
    valid() {
      return new Promise(resolve => {
        let length = 0;
        let formItemValid = true;
        new Promise(resolve => {
          this.validItems.forEach(validItem => {
            length++;
            validItem.compBlur().then(valid => {
              if (!valid) {
                formItemValid = false;
              }
              if (length === this.validItems.length) {
                resolve(formItemValid);
              }
            });
          });
        }).then(valid => {
          resolve(valid);
        });
      });
    },
    resetValid() {
      this.validItems.forEach(validItem => {
        validItem.resetValid();
      });
    }
  }
};
</script>

<style lang="less" scoped>
.item {
  margin-bottom: 0;
}
</style>

