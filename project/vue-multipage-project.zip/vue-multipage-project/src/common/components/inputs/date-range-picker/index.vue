<template>
    <component 
    :is="compMap[type]"
    v-bind="$attrs"
    @change="change"
    :type="type"
    :value="value"
    ></component>
</template>

<script>
import weekPicker from "./components/week-picker.vue";
import monthPicker from "./components/month-picker.vue";
import moment from "moment"
export default {
    components: {
        weekPicker,
        monthPicker
    },
    data(){
        return {
            compMap: {
                week: "weekPicker",
                month: "monthPicker"
            }
        }
    },
    props: {
        type: {
            type: String,
        },
        value: {}
    },
    methods: {
        change(val){
            this.$emit("change", val);
            this.$emit("input", val)
        }
    },
    mounted() {
        // console.log(this.$attrs)
    },
}
</script>