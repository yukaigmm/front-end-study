<template>
    <el-date-picker
      :key="key"
      :id="key"
      class="v-week-picker"
      :class="{invalid: invalid&&!isWarnning, 'full-width': fullWidth}"
      v-model="date"
      type="week"
      :placeholder="placeholder"
      @change="change"
      :disabled="disabled"
      :clearable="clearable"
      :format="format"
      :popper-class="popperClass"
      :picker-options="pickerOptions"
    ></el-date-picker>
</template>

<script>
function randomString(len) {
  len = len || 32;
  var $chars =
    "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678"; /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
  var maxPos = $chars.length;
  var pwd = "";
  for (let i = 0; i < len; i++) {
    pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
  }
  return pwd;
}

import moment from "moment";
export default {
  props: {
    value: {},
    isWarnning: {
      type: [Boolean],
      default: false
    },
    placeholder: {
      default: "请选择"
    },
    disabled: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: false
    },
    fullWidth: {
      type: Boolean,
      default: false
    },
    format: {
    },
    pickerOptions: {
      type: Object
    }
  },

  model: {
    prop: "value",
    event: "change"
  },

  data() {
    return {
      date: new Date(),
      invalid: false,
      key: "",
      popperClass: "",
      // pickerOptions: {
      //   firstDayOfWeek: 1
      // },
    };
  },

  watch: {
    value: {
      handler(val) {
        if (val == null || val == undefined) {
          val = "";
        }
        if (val === "0000-00-00") {
          val = "";
        }
        this.date = val;
      },
      deep: true
    },
  },
  mounted() {
    if (this.value) {
      this.date = this.value;
    }
    this.setUniqueId();
  },
  methods: {
    setUniqueId(){
        this.key = randomString(10);
        this.popperClass = `month-picker-popper-${this.key}`;
    },
    change(val) {
      this.$emit("change", val);
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    },
  }
};
</script>

<style lang="less">
</style>


