<template>
    <el-date-picker
      :key="key"
      :id="key"
      class="v-month-picker"
      :class="{invalid: invalid&&!isWarnning, 'full-width': fullWidth}"
      v-model="date"
      type="date"
      :placeholder="placeholder"
      @change="change"
      @focus="focus"
      :disabled="disabled"
      :clearable="clearable"
      :format="format"
      :popper-class="popperClass"
      :picker-options="pickerOptions"
    ></el-date-picker>
</template>

<script>
function randomString(len) {
  len = len || 32;
  var $chars =
    "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678"; /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
  var maxPos = $chars.length;
  var pwd = "";
  for (let i = 0; i < len; i++) {
    pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
  }
  return pwd;
}

import moment from "moment";
export default {
  props: {
    value: {},
    isWarnning: {
      type: [Boolean],
      default: false
    },
    placeholder: {
      default: "请选择"
    },
    pickerType: {
      default: "date"
    },
    disabled: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: false
    },
    fullWidth: {
      type: Boolean,
      default: false
    },
    format: {
    },
    pickerOptions: {
      type: Object
    }
  },

  model: {
    prop: "value",
    event: "change"
  },

  data() {
    return {
      date: new Date(),
      invalid: false,
      key: "",
      popperClass: "",
      // pickerOptions: {
      //   firstDayOfWeek: 1
      // },
    };
  },

  watch: {
    value: {
      handler(val) {
        if (val == null || val == undefined) {
          val = "";
        }
        if (val === "0000-00-00") {
          val = "";
        }
        this.date = val;
      },
      deep: true
    },
  },
  mounted() {
    if (this.value) {
      this.date = this.value;
    }
    this.setUniqueId();
  },
  methods: {
    setUniqueId(){
        this.key = randomString(10);
        this.popperClass = `month-picker-popper-${this.key}`;
    },
    formatter(val) {
      return val < 10 ? `0${val}` : `${val}`;
    },

    change(val) {
    //   let dateValue;
    //   if (val) {
    //     dateValue = val instanceof Date ? val : new Date(val);
    //     dateValue = `${dateValue.getFullYear()}-${this.formatter(
    //       dateValue.getMonth() + 1
    //     )}-${this.formatter(dateValue.getDate())}`;
    //   } else {
    //     dateValue = "";
    //   }
      this.$nextTick(() => {
          this.setPanelSelectStyle();
      })
      this.$emit("input", val);
      this.$emit("change", val);
    },
    focus(){
        this.$nextTick(() => {
            this.setPanelHoverStyle();
            this.setPanelSelectStyle();
            $(`.${this.popperClass}`).find(".el-date-picker__header").on("click", this.setPanelSelectStyle)
        })
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    },
    setPanelSelectStyle() {
        this.$nextTick(() => {
            this.removeSelectClass();
            let tableCell = $(`.${this.popperClass}`).find(".el-date-table td.current");
            if(tableCell.hasClass("available")){
                tableCell.parent().addClass("current-select");
                tableCell.parent().siblings().each((index, el) => {
                    $(el).find("td").each((i, td) => {
                        if($(td).hasClass("available")){
                            $(td).parent().addClass("current-select");
                        }
                    })
                })
            }
            $("tr.current-select").first().children().first().addClass("select-start");
            $("tr.current-select").last().children().last().addClass("select-end");
        })
    },
    removeSelectClass(){
        $(`.${this.popperClass}`).find(".el-date-table tr").removeClass("current-select");
        $("tr.current-select").first().children().first().removeClass("select-start");
        $("tr.current-select").last().children().last().removeClass("select-end");
    },
    setPanelHoverStyle(){
        let tableCell = $(`.${this.popperClass}`).find(".el-date-table td");
        tableCell.off("mouseover", this.addTrHoverClass);
        tableCell.off("mouseout", this.removeHoverClass);
        tableCell.on("mouseover", this.addTrHoverClass);
        tableCell.on("mouseout", this.removeHoverClass);
    },
    addTrHoverClass(e){
        let tableCell = null;
        if(e.target.tagName == "SPAN"){
            tableCell = $(e.target).parent().parent();
        }else if (e.target.tagName == "DIV"){
            tableCell = $(e.target).parent();
        }else if (e.target.tagName == "TD"){
            tableCell = $(e.target);
        }
        if(tableCell.hasClass("available")){
            tableCell.parent().addClass("current-hover");
            tableCell.parent().siblings().each((index, el) => {
                $(el).find("td").each((i, td) => {
                    if($(td).hasClass("available")){
                        $(td).parent().addClass("current-hover");
                    }
                })
            })
        }
        $("tr.current-hover").first().children().first().addClass("hover-start");
        $("tr.current-hover").last().children().last().addClass("hover-end");
    },
    removeHoverClass(){
        $(`.${this.popperClass}`).find(".el-date-table tr").removeClass("current-hover");
        $(`.${this.popperClass}`).find(".el-date-table tr td").removeClass("hover-start hover-end");
    }
  }
};
</script>

<style lang="less">
.date-picker {
  &.full-width {
    width: 100%;
    max-width: 100%;
  }
  &.invalid {
    input {
      border-color: #f45;
    }
  }
}
div[class*="month-picker-popper-"]{
    .el-date-table{
        // 鼠标悬浮
        tr.current-hover{
            td{
                div{
                    background-color: #234;
                }
                &.hover-start{
                    div{
                        margin-left: 5px;
                        border-top-left-radius: 15px;
                        border-bottom-left-radius: 15px;
                    }
                }
                &.hover-end{
                    div{
                        margin-right: 5px;
                        border-top-right-radius: 15px;
                        border-bottom-right-radius: 15px;
                    }
                }
            }
        }
        // 选中
        tr.current-select{
            td{
                &.current{
                    span{
                        background-color: transparent !important;
                    }
                }
                div{
                    background-color: #234;
                }
                &.select-start,&.select-end{
                    div{
                        span{
                            border-radius: 50%;
                            background-color: #409EFF;
                            color: #eee;
                        }
                    }
                }
                &.select-start{
                    div{
                        margin-left: 5px;
                        border-top-left-radius: 15px;
                        border-bottom-left-radius: 15px;
                    }
                }
                &.select-end{
                    div{
                        margin-right: 5px;
                        border-top-right-radius: 15px;
                        border-bottom-right-radius: 15px;
                    }
                }
            }
        }
    }
}
</style>


