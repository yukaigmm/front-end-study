<template>
  <el-input
    type="textarea"
    class="textarea"
    :class="{invalid: invalid}"
    :placeholder="placeholder"
    :autosize="{ minRows: 3 }"
    v-model="value"
    @input="changeValue"
    :disabled="disabled"
  ></el-input>
</template>

<script>
export default {
  props: {
    value: {
      type: [Number, String]
    },
    height: {
      type: [String, Number]
    },
    placeholder: {
      type: String,
      default: "请输入..."
    },

    disabled: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      invalid: false
    };
  },
  methods: {
    changeValue() {
      this.$emit("input", this.value);
      this.$emit("change", this.value);
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    },
    onBlur() {
      this.$emit("blur");
    }
  },
  mounted() {
    this.val = this.value;
  }
};
</script>

<style lang="less">
.textarea {
  display: inline-block;
  width: 100%;
  border: none;
  &.invalid {
    textarea {
      border-color: #f45;
    }
  }
  textarea {
    line-height: 26px;
    color: #999;
    font-size: 12px;
    padding: 0 5px;
    background-color: #181818;
    border: 1px solid #555;
    font-family: "微软雅黑", "Microsoft Yahei";
  }
  textarea::-webkit-input-placeholder {
    color: #999;
  }

  textarea::-moz-placeholder {
    color: #999;
  }

  textarea:-moz-placeholder {
    color: #999;
  }

  textarea:-ms-textarea-placeholder {
    color: #999;
  }
}
.el-textarea.is-disabled .el-textarea__inner {
  background: transparent !important;
  border-color: #444 !important;
}
</style>