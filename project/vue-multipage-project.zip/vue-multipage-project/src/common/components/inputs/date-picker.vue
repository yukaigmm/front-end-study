<template>
  <div>
    <el-date-picker
      :key="genId()"
      :id="genId()"
      class="date-picker"
      :class="{invalid: invalid&&!isWarnning, 'full-width': fullWidth}"
      v-model="date"
      :type="pickerType"
      :placeholder="placeholder"
      @change="change"
      :disabled="disabled"
      :clearable="clearable"
      :format="format"
    ></el-date-picker>
  </div>
</template>

<script>
function randomString(len) {
  len = len || 32;
  var $chars =
    "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678"; /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
  var maxPos = $chars.length;
  var pwd = "";
  for (let i = 0; i < len; i++) {
    pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
  }
  return pwd;
}

export default {
  props: {
    value: {},
    isWarnning: {
      type: [Boolean],
      default: false
    },
    placeholder: {
      default: "请选择"
    },
    pickerType: {
      default: "date"
    },
    disabled: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: false
    },
    fullWidth: {
      type: Boolean,
      default: false
    },
    format: {
    }
  },

  model: {
    prop: "value",
    event: "change"
  },

  data() {
    return {
      date: "",
      invalid: false
    };
  },

  watch: {
    value: {
      handler(val) {
        if (val == null || val == undefined) {
          val = "";
        }
        if (val === "0000-00-00") {
          val = "";
        }
        if (/[a-zA-Z]/.test(val)) {
          val = "";
        }

        this.date = val;
      },
      deep: true
    },
    //
    date: {
      handler(val) {
        this.change(val);
      },
      deep: true
    }
  },
  mounted() {
    if (this.value) {
      this.date = this.value;
    }
  },
  methods: {
    formatter(val) {
      return val < 10 ? `0${val}` : `${val}`;
    },

    change(val) {
      let dateValue;
      if (val) {
        dateValue = val instanceof Date ? val : new Date(val);
        dateValue = `${dateValue.getFullYear()}-${this.formatter(
          dateValue.getMonth() + 1
        )}-${this.formatter(dateValue.getDate())}`;
      } else {
        dateValue = "";
      }
      this.$emit("input", dateValue);
      this.$emit("change", dateValue);
    },
    genId() {
      return randomString(10);
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    }
  }
};
</script>

<style lang="less">
.date-picker {
  &.full-width {
    width: 100%;
    max-width: 100%;
  }
  &.invalid {
    input {
      border-color: #f45;
    }
  }
}
</style>


