<template>
  <vmodal
    ref="linkModal"
    title="插入链接"
    @success="linkModalSuccess"
    :width="300"
    class="t2-el-dialog"
  >
    <vformConfig ref="linkForm" :config="linkFormConfig" v-model="linkForm"></vformConfig>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="confirm">插入</vbutton>
    </div>
  </vmodal>
</template>

<script>
export default {
  data() {
    return {
      linkFormConfig: {
        cols: 12,
        fields: [
          [
            {
              label: "标题",
              labelWidth: 70,
              colspan: 12,
              comps: [
                {
                  key: "title",
                  compType: "vinput",
                  rules: [{ required: true, message: "请输入标题" }]
                }
              ]
            }
          ],
          [
            {
              label: "链接",
              labelWidth: 70,
              colspan: 12,
              comps: [
                {
                  key: "link",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "以http://或https://开头的网址"
                  },
                  rules: [
                    { required: true, message: "请输入链接" },
                    {
                      type: "url",
                      message: "请输入正确的网址,以http://或https://开头"
                    }
                  ]
                }
              ]
            }
          ]
        ]
      },
      linkForm: {
        title: "",
        link: ""
      }
    };
  },
  methods: {
    show() {
      this.$refs.linkModal.open();
    },
    hide() {
      this.$refs.linkModal.close();
    },
    confirm() {
      this.$refs.linkForm.valid().then(valid => {
        if (valid) {
          this.$emit("success", this.linkForm);
          this.reset();
          this.hide();
        } else {
          this.$message.error("请按提示修改");
        }
      });
    },
    cancel() {
      this.reset();
      this.hide();
    },
    reset() {
      this.linkForm = {
        title: "",
        link: ""
      };
    }
  }
};
</script>

<style lang="less" scoped>
</style>

