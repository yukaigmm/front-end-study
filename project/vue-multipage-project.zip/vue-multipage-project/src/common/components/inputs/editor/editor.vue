<template>
  <div
    class="editor-container"
    ref="editorContainer"
    :class="{'comp-invalid': invalid, 'has-menu': editorConfig.menus.length, focus: focus}"
  >
    <div v-if="editorConfig.menus.length" class="editor-menu-container">
      <div
        class="editor-menu link"
        v-if="editorConfig.menus.indexOf('link') != -1"
        @click="insertLink"
        title="插入网址"
      >
        <i class="icon iconfont icon-link"></i>
        插入链接
      </div>
    </div>
    <div ref="editor" style="text-align:left" :id="editorId">{{innerContent}}</div>

    <linkModal ref="linkModal" @success="linkModalSuccess"></linkModal>
  </div>
</template>
<script>
import E from "wangeditor";
import $ from "jquery";
import linkModal from "./menus/link-modal.vue";
export default {
  components: {
    linkModal
  },
  data() {
    return {
      editor: {},
      editorCurrentValue: "",
      editorPreValue: "",
      innerContent: "",
      invalid: false,
      focus: false,
      content: "",
      trigger: ""
    };
  },
  props: {
    value: {
      type: String,
      default: ""
    },
    editorConfig: {
      type: Object,
      default: () => {
        return {
          menus: []
        };
      }
    },
    editorId: {
      type: String,
      default: ""
    },
    preValue: {
      type: String
    },
    currentValue: {
      type: String
    }
  },
  methods: {
    editorInit() {
      this.editor = new E(this.$refs.editor);
      for (let key in this.editorConfig) {
        this.editor.customConfig[key] = this.editorConfig[key];
        this.editor.customConfig.menus = [];
      }
      // 设置富文本编辑器快速输入时不回退
      this.editor.customConfig.onchangeTimeout = 1;

      this.editor.customConfig.onchange = content => {
        this.content = content;
        this.$emit("input", content);
        this.$emit("change", content);
      };

      // 目前需求是在用户粘贴输入文本时，只粘贴文本和换行，去除文本格式。
      // 在 wangEditor 内部有一个 getPasteText 方法，通过触发 paste 事件获取剪切板里面的文本信息，刚好可以实现这一需求。
      // getPasteText 方法在 wangEditor 源码中是在 paste 事件发生的时候， catch 中处理的。
      // 所以我们现在处理粘贴文本的时候，第一次先抛出错误，执行 wangEditor 里面的 catch 逻辑，然后获取剪切板的文本和换行，第二次直接返回获取到的 content（ pasteTextHandle 方法执行两次）
      this.editor.customConfig.pasteTextHandle = content => {
        // debugger
        if (!this.trigger) {
          this.trigger = true;
          setTimeout(() => {
            this.trigger = false;
          }, 100);
          throw new Error()
        } else {
          return content;
        }
      };


      this.editor.create();

    },
    // 去除 word 文档的粘贴格式（目前未使用）
    removeWordXml(text){
      var html = text;
      html = html.replace(/<\/?SPANYES[^>]*>/gi, "");//  Remove  all  SPAN  tags
      // html = html.replace(/<(\w[^>]*)  class=([^|>]*)([^>]*)/gi, "<$1$3");  //  Remove  Class  attributes
      // html = html.replace(/<(\w[^>]*)  style="([^"]*)"([^>]*)/gi, "<$1$3");  //  Remove  Style  attributes
      html = html.replace(/<(\w[^>]*)  lang=([^|>]*)([^>]*)/gi, "<$1$3");//  Remove  Lang  attributes
      html = html.replace(/<\\?\?xml[^>]*>/gi, "");//  Remove  XML  elements  and  declarations
      html = html.replace(/<\/?\w+:[^>]*>/gi, "");//  Remove  Tags  with  XML  namespace  declarations:  <o:p></o:p>
      html = html.replace(/ /, "");//  Replace  the   
      html = html.replace(/\n(\n)*( )*(\n)*\n/gi, '\n');
      //  Transform  <P>  to  <DIV>
      // var  re  =  new  RegExp("(<P)([^>]*>.*?)(<//P>)","gi")  ;            //  Different  because  of  a  IE  5.0  error
    //        html = html.replace(re, "<div$2</div>");
      return html;
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    },
    clickEditor(e) {
      setTimeout(() => {
        $(e.target)
          .find(".w-e-text")
          .focus();
      }, 1);
    },
    getOldValue() {
      // $('.editor-container').on('click','.rollback',()=>{
      setTimeout(() => {
        this.editor.txt.html(this.editorPreValue);
        this.editorPreValue = "";
      }, 100);
      return false;
      // })
    },
    compareText(val) {
      let value = $("<div></div>")
        .html(val)
        .text();
      let editorValue = $("<div></div>")
        .html(this.content)
        .text();

      return value == editorValue;
    },
    insertLink() {
      this.$refs.linkModal.show();
    },
    linkModalSuccess({ title, link }) {
      this.editor.cmd.do(
        "insertHTML",
        `<a target="_blank" title=${link} href=${link}>${title}</a>`
      );
    }
  },
  watch: {
    value: {
      handler(val, oldVal) {
        if (!val) {
          this.editor.txt.html(val);
          this.content = "";
        } else {
          if (!this.compareText(val)) {
            this.editor.txt.html(val);
          }
        }
      }
    },
    preValue: {
      handler(val) {
        this.editorPreValue = val;
      }
    },
    currentValue: {
      handler(val) {
        this.editorCurrentValue = val;
        this.editor.txt.html(val);
      },
      deep: true
    },
  },
  mounted() {
    this.editorInit();
    // this.getOldValue();
    // this.getPreValue();
    // setTimeout(() => {
    //     this.editor.$textElem.attr('contenteditable', true)
    // }, 2000);
    $(this.$refs.editorContainer)
      .find(".w-e-text-container .w-e-text")
      .focus(() => {
        this.focus = true;
      })
      .blur(() => {
        this.focus = false;
      });
  }
};
</script>

<style lang="less">
.editor-container {
  .w-e-toolbar {
    display: none !important;
    // background-color: #181818 !important;
    // color: #999;
    // border: none !important;
  }
  .w-e-text-container {
    height: auto !important;
    border: 1px solid #555 !important;
    font-size: 12px;
    z-index: 10 !important;
    cursor: text;
    // &:hover{
    //     border:1px solid #c0c4c4 !important;
    // }
    // &.text-container-focus{
    //     border: 1px solid #20a0ff !important;
    // }
    .w-e-text {
      min-height: 100px !important;
      max-height: 200px !important;
      overflow-y: auto;
      background-color: #181818;
      color: #999;
      // 产品经理 金文政 要求换行\n\r和p标签的表现形式一样，因此将p标签的margin设置为0
      p{
        margin: 0;
      }
    }
    .w-e-panel-container {
      background-color: #333;
      top: 20px;
      box-shadow: none;
      border: 2px solid #555;
      .w-e-panel-tab-title {
        margin: 0;
        border-bottom: none;
        .w-e-item {
          color: #2992ff;
          border-bottom: none;
        }
      }
      .w-e-icon-close {
        color: #fff;
        &:hover {
          color: #fff;
        }
      }
      .w-e-panel-tab-content {
        background-color: #1a1a1a;
        input {
          padding: 0 8px;
        }
        .w-e-button-container {
          margin-top: 10px;
          button {
            background: linear-gradient(#2991fe, #1f6fc2);
            color: #fff;
            width: 60px;
            height: 26px;
            text-align: center;
            line-height: 26px;
            padding: 0;
          }
        }
      }
    }
  }
  .attach-info {
    font-size: 12px;
    .rollback {
      cursor: pointer;
    }
  }
  &.has-menu {
    .w-e-toolbar {
      border: 1px solid #555 !important;
      border-bottom: none !important;
    }
  }
  .editor-menu-container {
    border: 1px solid #555;
    border-bottom: none;
    padding: 3px 0;
    .editor-menu {
      display: inline-block;
      padding: 0 2px;
      font-size: 12px;
      color: #aaa;
      cursor: pointer;
      .iconfont {
        font-size: 16px;
      }
      &:hover {
        color: #20a0ff;
      }
    }
  }

  &:hover {
    .w-e-text-container {
      border: 1px solid #c0c4c4 !important;
    }
    .w-e-toolbar {
      border-color: #c0c4c4 !important;
    }
    .editor-menu-container {
      border-color: #c0c4c4;
    }
  }
  &.focus {
    .w-e-text-container {
      border: 1px solid #20a0ff !important;
    }
    .w-e-toolbar {
      border-color: #20a0ff !important;
    }
    .editor-menu-container {
      border-color: #20a0ff;
    }
  }
  &.comp-invalid {
    .w-e-text-container {
      border-color: #f45 !important;
    }
    .w-e-toolbar {
      border-color: #f45 !important;
    }
    .editor-menu-container {
      border-color: #f45;
    }
  }
}
</style>
