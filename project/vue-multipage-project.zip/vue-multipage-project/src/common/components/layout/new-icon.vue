<template>
  <div class="menu-img-container">
    <img src="../../../assets/images/new.gif" alt>
  </div>
</template>


<script>
export default {
  data() {
    return {};
  }
};
</script>

<style lang="less" scoped>
.menu-img-container {
  display: inline-block;
  width: 21px;
  height: 16px;
  line-height: 0px;
  text-align: center;
  vertical-align: middle;
  img {
    width: 100%;
    height: 100%;
  }
}
</style>


