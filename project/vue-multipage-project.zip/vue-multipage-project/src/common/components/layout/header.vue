<template>
  <nav class="header">
    <div class="nav-wrapper">
      <a href="#" class="brand-logo" @click="toIndexPage">
        <img src="@/assets/images/logo-main.png" alt="logo">
      </a>
      <span class="divide-bar"></span>
      <!-- 切换后的虚拟账号用户名,用于内部使用 -->
      <span v-if="isVirtual" class="virtual-user">{{userName}}</span>

      <el-popover
        class="user-area"
        placement="bottom"
        width="74"
        trigger="hover"
        popper-class="user-area-popper"
      >
        <i class="icon-small-account" slot="reference" style="vertical-align: middle;"></i>
        <ul class="user-action">
          <li class="user-action-item" @click="updatePassword">修改密码</li>
          <!-- 基金大师管理员有切换账号权限，基金大师管理员在申报系统设置 -->
          <li class="user-action-item" v-if="changeAble" @click="switchAccount">切换账号</li>
          <li class="user-action-item" @click="logout">退出</li>
        </ul>
      </el-popover>
      <el-popover
        class="help-area"
        placement="bottom"
        width="74"
        trigger="hover"
        popper-class="help-area-popper"
      >
        <i class="icon-small-help-feedback" slot="reference" style="vertical-align: middle;"></i>
        <ul class="help-action">
          <li class="help-action-item" @click="feedback">反馈意见</li>
          <li class="help-action-item" @click="showHelpDoc">帮助文档</li>
          <li class="help-action-item" @click="showProtocal">服务协议</li>
          <li class="help-action-item" @click="toReleaseNotes">发布日志</li>
        </ul>
      </el-popover>
      <!-- <div @click="feedback" class="feedback-button-container">
        <i class="icon-small-help-feedback" style="vertical-align: middle;"></i>
      </div>-->
      <!-- 反馈意见modal -->
      <vmodal
        ref="feedbackModal"
        class="feedback-modal t2-el-dialog"
        :width="600"
        title="反馈意见"
        @close="closeFeedbackModal"
      >
        <div class="feedback-modal-container">
          <vformConfig ref="feedbackForm" :config="feedbackFormConfig" v-model="feedbackForm"></vformConfig>
        </div>
        <div slot="modal-footer" class="feedback-modal-footer">
          <vbutton @click="closeFeedbackModal">取消</vbutton>
          <vbutton active @click="submitFeedback">提交</vbutton>
        </div>
        <vloading v-model="feedbackLoading"></vloading>
      </vmodal>
      <!-- 修改密码modal -->
      <vmodal
        ref="updatePasswordModal"
        class="password-modal t2-el-dialog"
        :title="`修改密码`"
        :width="300"
        @close="closePasswordModal"
      >
        <div class="password-modal-container">
          <vformConfig ref="passwordForm" :config="passwordFormConfig" v-model="passwordForm"></vformConfig>
        </div>
        <div slot="modal-footer" class="feedback-modal-footer">
          <vbutton @click="closePasswordModal">取消</vbutton>
          <vbutton active @click="submitUpdatePassword">提交</vbutton>
        </div>
        <vloading v-model="passwordLoading"></vloading>
      </vmodal>
      <!-- 切换账号modal -->
      <vmodal
        ref="switchAccountModal"
        class="switch-account-modal t2-el-dialog"
        :title="`切换账号`"
        @close="closeSwitchModal"
        :width="300"
      >
        <div class="account-modal">
          <vformConfig ref="accountForm" :config="accountFormConfig" v-model="accountForm"></vformConfig>
        </div>
        <div slot="modal-footer" class="account-modal-footer">
          <vbutton @click="closeSwitchModal">取消</vbutton>
          <vbutton active @click="switchAccountConfirm">提交</vbutton>
        </div>
        <vloading v-model="accountModalLoading"></vloading>
      </vmodal>
      <!-- 协议条款modal -->
      <protocal-modal ref="protocalModal"></protocal-modal>
    </div>
  </nav>
</template>

<script>
import protocalModal from "../../../pages/login/protocal-modal.vue";
import {refreshMasterToken} from "../../js/utils.js"
export default {
  components: {
    protocalModal
  },
  data() {
    // const validatePassword = (rule, value, callback, source, options) => {
    // 	var errors = [];
    // 	if (value && !/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,21}$/.test(value)) {
    // 		errors.push(new Error('密码为6位以上的数字和英文字母组成'))
    // 	}
    // 	callback(errors);
    // }
    return {
      userName: "",
      showUserInfo: false,
      iconName: "keyboard_arrow_down",
      feedbackTitle: "",
      feedbackContent: "",
      feedbackLoading: false,
      passwordLoading: false,
      // 切换账号配置
      accountModalLoading: false,
      accountForm: {},
      accountFormConfig: {
        cols: 1,
        fields: [
          [
            {
              label: "手机号码",
              labelWidth: 80,
              comps: [
                {
                  key: "mobile",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入账号对应的手机号码"
                  },
                  rules: [
                    {
                      required: true,
                      message: "请输入账号对应的手机号码"
                    }
                  ]
                }
              ]
            }
          ]
        ]
      },
      feedbackForm: {},
      feedbackFormConfig: {
        cols: 1,
        fields: [
          [
            {
              label: "标题",
              labelWidth: 80,
              comps: [
                {
                  key: "topic",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入标题"
                  },
                  rules: [
                    {
                      required: true,
                      message: "请输入标题"
                    }
                  ]
                }
              ]
            }
          ],
          [
            {
              label: "内容",
              labelWidth: 80,
              comps: [
                {
                  key: "content",
                  compType: "vtextArea",
                  compConfig: {
                    placeholder: "请输入内容"
                  },
                  rules: [
                    {
                      required: true,
                      message: "请输入内容"
                    }
                  ]
                }
              ]
            }
          ]
        ]
      },
      passwordFormConfig: {
        cols: 1,
        fields: [
          [
            {
              label: "原密码",
              labelWidth: 100,
              comps: [
                {
                  key: "oldPsw",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入原密码",
                    inputType: "password"
                  },
                  rules: [
                    {
                      required: true,
                      message: "请输入原密码"
                    }
                  ]
                }
              ]
            }
          ],
          [
            {
              label: "新密码",
              labelWidth: 100,
              comps: [
                {
                  key: "newPsw",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入新密码",
                    inputType: "password"
                  },
                  rules: [
                    {
                      required: true,
                      message: "请输入新密码"
                    },
                    {
                      type: "string",
                      min: 6,
                      max: 16,
                      message: "密码需为6-16位"
                    }
                  ]
                }
              ]
            }
          ],
          [
            {
              label: "确认新密码",
              labelWidth: 100,
              comps: [
                {
                  key: "reNewPass",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请再次输入新密码",
                    inputType: "password"
                  },
                  rules: [
                    {
                      required: true,
                      message: "请再次输入新密码"
                    },
                    {
                      type: "string",
                      min: 6,
                      max: 16,
                      message: "密码需为6-16位"
                    },
                    (rule, value, callback, source, options) => {
                      let errors = [];
                      if (value !== this.passwordForm.newPsw) {
                        errors.push(new Error("两次密码不一致"));
                      }
                      callback(errors);
                    }

                    // validatePassword()
                  ]
                }
              ]
            }
          ]
        ]
      },
      passwordForm: {},
      changeAble: false,
      isVirtual: ""
    };
  },
  computed: {
    headerUserName() {
      // return this.userName + '' + ;
      return `${this.userName}${this.userEditable ? "" : "(只读)"}`;
    }
  },
  methods: {
    toIndexPage() {
      window.location.assign(
        this.$baseUrl[process.env.NODE_ENV]["page"] +
          "/index/index.html"
      );
    },
    toReleaseNotes() {
      window.open(
        this.$baseUrl[process.env.NODE_ENV]["page"] +
          "/release-notes/index.html"
      );
    },
    // 退出登录
    logout() {
      this.$http.get("user/checkLogout").then(res => {
        location.assign(
          this.$baseUrl[process.env.NODE_ENV]["page"] + "/login/index.html"
        );
      });
    },
    //  切换账号
    switchAccount() {
      this.$refs.switchAccountModal.open();
    },
    switchAccountConfirm() {
      this.accountModalLoading = true;
      this.$refs.accountForm.valid().then(valid => {
        if (valid) {
          this.$http
            .post("user/changeUser", this.accountForm)
            .then(res => {
              if (!res) return;
              if (res && res.code === 20000) {
                this.closeSwitchModal();
                this.$message.success("切换成功,请稍候");
                let newInfo = res.data.newUserInfo;
                localStorage.setItem(
                  "fund_master_current_user",
                  JSON.stringify({
                    userId: newInfo.userId,
                    userName: newInfo.userName,
                    trueName: newInfo.trueName,
                    isAdmin: newInfo.isAdmin,
                    isVirtual: newInfo.isVirtual,
                    companyId: newInfo.companyId || newInfo.orgId,
                    companyName: newInfo.companyName,
                    userCompanyApplicationIds: newInfo.userCompanyApplicationIds,
                    userPermission: newInfo.userPermission || 1,
                  })
                );

                //canSend 表示用户是否有权限进行部分写接口的调用
                // reloginAble 表示用户是否能调用relogin接口，如果是切换之后的账号，就不让调用
                let canSend = true;
                let reloginAble = true;
                let originUserInfo = JSON.parse(
                  localStorage.getItem("fund_master_origin_user")
                );
                let currentUserInfo = JSON.parse(
                  localStorage.getItem("fund_master_current_user")
                );
                //未登陆情况
                if (!originUserInfo && !currentUserInfo) {
                  canSend = true;
                } else {
                  //模拟用户存在情况时需判断，否则可调用
                  if (currentUserInfo.isVirtual === 1) {
                    reloginAble = false;
                    //模拟用户存在，并且源用户有写权限，可调用
                    if (originUserInfo.changeLevel === 2) {
                      canSend = true;
                    } else {
                      canSend = false;
                    }
                  } else {
                    canSend = true;
                  }
                }

                sessionStorage.setItem("canSend", canSend);
                sessionStorage.setItem("reloginAble", reloginAble);

                setTimeout(() => {
                  location.assign(
                    this.$baseUrl[process.env.NODE_ENV]["page"] +
                      "/index/index.html"
                  );
                }, 1000);
              } else {
                this.$message.error(res.msg);
              }
            })
            .done(() => {
              this.accountModalLoading = false;
            });
        } else {
          this.accountModalLoading = false;
        }
      });
    },
    closeSwitchModal() {
      this.accountForm = {};
      this.$refs.switchAccountModal.close();
      setTimeout(() => {
        this.$refs.accountForm.resetValid();
      }, 100);
    },
    //  反馈操作
    feedback() {
      this.$refs.feedbackModal.open();
    },
    submitFeedback() {
      this.feedbackLoading = true;
      this.$refs.feedbackForm.valid().then(valid => {
        if (valid) {
          this.$http.post("desk/feedback", this.feedbackForm).then(res => {
            this.feedbackLoading = false;
            if (!res) return;
            if (res && res.code === 20000) {
              this.$message.success("反馈成功，谢谢您的宝贵意见");
              this.closeFeedbackModal();
            } else {
              this.$message.error(res.msg);
            }
          });
        } else {
          this.feedbackLoading = false;
        }
      });
    },
    closeFeedbackModal() {
      this.$refs.feedbackModal.close();
      this.$refs.feedbackForm.resetValid();
      this.feedbackForm = {};
    },
    updatePassword() {
      this.$refs.updatePasswordModal.open();
    },
    closePasswordModal() {
      this.$refs.updatePasswordModal.close();
      this.$refs.passwordForm.resetValid();
      this.passwordForm = {};
    },
    submitUpdatePassword() {
      this.passwordLoading = true;
      this.$refs.passwordForm.valid().then(valid => {
        if (valid) {
          let passwordFormData = JSON.parse(JSON.stringify(this.passwordForm));
          delete passwordFormData.reNewPass;
          this.$http
            .put("user/changeSelfPsw", passwordFormData)
            .then(res => {
              if (!res) return;
              if (res && res.code === 20000) {
                this.$message.success("密码修改成功！");
                this.closePasswordModal();
                this.logout();
              } else {
                this.$message.error(res.msg);
              }
            })
            .done(() => {
              this.passwordLoading = false;
            });
        } else {
          this.passwordLoading = false;
        }
      });
    },
    showProtocal() {
      this.$refs.protocalModal.open();
    },

    // 如果页面中没有缓存组合大师 token 有效性的信息，则重新请求刷新token，否则根据 token 的有效性判断功能是否能够使用
    showHelpDoc() {
      // 判断分析功能是否可用， 
      let masterUseable = window.sessionStorage.getItem("masterUseable");
      if(masterUseable === null || masterUseable === "false"){
        refreshMasterToken().then(() => {
          setTimeout(() => {
            this.openHelpDoc();
          }, 100);
        })
      }else{
        this.openHelpDoc();
      } 
    },
    openHelpDoc(){
      let masterUseable = window.sessionStorage.getItem("masterUseable");
      if(masterUseable === "false"){
        this.noticeError()
        return;
      }else{
        window.open(
        this.$baseUrl[process.env.NODE_ENV]["page"] + "/help-doc/index.html"
      );
      }
    },
    noticeError(){
      this.$alert("帮助文档功能授权失败，请重新登录或联系客服", "提示", {
        confirmButtonText: '确定',
        type: "warning",
        callback: action => {}
      });
    },
  },
  mounted() {
    let originUserInfo = localStorage.getItem("fund_master_origin_user")
      ? JSON.parse(localStorage.getItem("fund_master_origin_user"))
      : "";
    let currentUserInfo = window.localStorage.getItem(
      "fund_master_current_user"
    )
      ? JSON.parse(window.localStorage.getItem("fund_master_current_user"))
      : "";
    this.changeAble = originUserInfo.changeAble;

    this.userName = currentUserInfo.trueName || currentUserInfo.userName;
    this.isVirtual = currentUserInfo.isVirtual;
    this.userEditable = currentUserInfo.userPermission === 1;
    if(this.isVirtual == 1){
      sessionStorage.setItem("reloginAble", false);
    }else{
      sessionStorage.setItem("reloginAble", true);
    }
  }
};
</script>

<style lang="less" rel="styleSheet/less">
[v-cloak] {
  display: none !important;
}
.header {
  position: fixed;
  width: 100%;
  top: 0;
  left: 0;
  z-index: 21;
  height: 60px;
  line-height: 60px;
}
.nav-wrapper {
  height: 60px;
  background: linear-gradient(#234, #112132);
  font-size: 0;
  // z-index: 20;
}
.brand-logo {
  display: inline-block;
  height: 100%;
  width: 240px;
  // padding: 5px 0 !important;
  img {
    height: 100%;
    width: 100%;
  }
}
.divide-bar {
  display: inline-block;
  width: 5px;
  height: 100%;
  background-color: #000;
}
.user-area,
.help-area {
  position: relative;
  float: right;
  margin-right: 20px;
  height: 100%;
  text-align: right;
  vertical-align: middle;
}
.help-area {
  margin-right: 10px;
}
.user-action,
.help-action {
  width: 72px;
  text-align: center;
  padding: 1px;
  background-color: #000;
  li.user-action-item,
  li.help-action-item {
    margin-bottom: 1px;
    cursor: pointer;
    width: 70px;
    height: 26px;
    line-height: 26px;
    font-size: 12px;
    color: #eee;
    cursor: pointer;
    border-radius: 2px;
    box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.65),
      inset 0px 1px 0px 0px rgba(255, 255, 255, 0.25);
    background: linear-gradient(#636363, #333);
    &:last-child {
      margin: 0;
    }
    &:hover {
      background: linear-gradient(#4196e9, #0f5697);
    }
  }
}

//设置el-popover的箭头颜色
.user-area-popper,
.help-area-popper {
  // color: #eee;
  div.popper__arrow {
    &:after {
      border-bottom-color: #000 !important;
    }
  }
}

.feedback-button-container {
  margin-right: 10px;
  cursor: pointer;
  float: right;
  color: #eee;
}

// 切换账号modal
.switch-account-modal {
  .account-modal {
    padding-top: 20px;
  }
}

.virtual-user {
  float: right;
  text-decoration: underline;
  margin-right: 20px;
  font-size: 12px;
}
</style>