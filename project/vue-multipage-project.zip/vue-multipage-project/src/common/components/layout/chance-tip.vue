<template>
  <div class="count-container" v-if="unReadChanceCount" :title="title">
    <span class="count">{{showCount}}</span>
  </div>
</template>


<script>
export default {
  data() {
    return {
      countData: [],
      unReadChanceCount: 0
    };
  },
  computed: {
    showCount() {
      return this.unReadChanceCount > 99 ? 99 : this.unReadChanceCount;
    },
    title() {
      return `您有${this.unReadChanceCount}条外部机会未读`;
    }
  },
  methods: {
    getChanceNotReadCount() {
      this.$http.get("chance/usermeta").then(res => {
        if (res.code === 20000) {
          this.unReadChanceCount = res.data.notRead;
        } else {
          this.unReadChanceCount = 0;
        }
        // sessionStorage.setItem(
        //   "fund_master_chance_unread_count",
        //   this.unReadChanceCount
        // );
      });
    },
    refreshChanceCount() {
      this.getChanceNotReadCount();
    }
  },
  mounted() {
    //获取机会未读数，先从sessionStorage中获取，若没有则请求
    // let unReadChanceCount = sessionStorage.getItem(
    //   "fund_master_chance_unread_count"
    // );

    // if (unReadChanceCount) {
    //   this.unReadChanceCount = parseInt(unReadChanceCount);
    // } else {
      this.getChanceNotReadCount();
    // }
  }
};
</script>

<style lang="less" scoped>
.count-container {
  display: inline-block;
  width: 22px;
  height: 22px;
  line-height: 22px;
  background-color: rgb(255, 68, 85);
  border-radius: 50%;
  text-align: center;
  .count {
    font-size: 12px;
    color: #fff;
  }
}
</style>


