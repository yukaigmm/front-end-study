<template>
  <el-menu :default-active="currentMenu" class="menu">
    <template v-for="(menu, index) in menuList">
      <template v-if="!menu.ifHide">
        <el-submenu
          v-if="menu.children && menu.children instanceof Array && menu.children.length"
          :key="index"
          :index="menu.key"
          class="main-menu"
        >
          <div slot="title" class="main-menu-title" :class="{'unlocked': menu.unlocked}">
            <span>{{menu.name}}</span>
            <template v-if="menu.extendComponents && menu.extendComponents.length">
              <component
                v-for="(comp, i) in menu.extendComponents"
                :key="i"
                :is="comp.name"
                :ref="comp.ref"
              ></component>
            </template>
          </div>
          <template v-for="(child, idx) in menu.children">
            <template v-if="!child.ifHide">
              <el-menu-item
                :key="idx"
                :index="child.key"
                @click="toPage(child.to, child.key, child.name)"
                class="sub-menu"
              >
                <div slot="title" class="sub-menu-title">
                  <span>{{child.name}}</span>
                  <template v-if="child.extendComponents && child.extendComponents.length">
                    <component
                      v-for="(comp, i) in child.extendComponents "
                      :key="i"
                      :is="comp.name"
                      :ref="comp.ref"
                    ></component>
                  </template>
                </div>
              </el-menu-item>
            </template>
          </template>
        </el-submenu>
        <el-menu-item
          v-else
          class="main-menu no-children"
          :key="index"
          :index="menu.key"
          @click="toPage(menu.to, menu.key, menu.name)"
        >
          <div slot="title" class="el-submenu__title">
            <div class="main-menu-title" :class="{'unlocked': menu.unlocked}">
              <span>{{menu.name}}</span>
              <template v-if="menu.extendComponents && menu.extendComponents.length">
                <component
                  v-for="(comp, i) in menu.extendComponents"
                  :key="i"
                  :is="comp.name"
                  :ref="comp.ref"
                ></component>
              </template>
            </div>
          </div>
        </el-menu-item>
      </template>
    </template>
  </el-menu>
</template>



<script>
import chanceTip from "./chance-tip.vue";
import wechatLogo from "./wechat-logo.vue";
import newIcon from "./new-icon.vue";
export default {
  props: {
    menuParentKey: {
      type: String,
      default: ""
    },
    menuChildKey: {
      type: String,
      default: ""
    }
  },
  components: {
    chanceTip,
    wechatLogo,
    newIcon
  },
  data() {
    return {
      currentMenu: "",
      currentUserInfo: {}
    };
  },
  computed: {
    menuList() {
      let userCompanyApplicationIds =
        this.currentUserInfo.userCompanyApplicationIds || [];
      // 处理后台返回的使用的应用标识字段，统一设置成数字，因为后端可能返回字符串或是数字，可能导致includes方法失效。
      userCompanyApplicationIds = userCompanyApplicationIds.map(id => {
        return +id;
      });
      return [
        {
          key: "index",
          name: "首页",
          icon: "person",
          to: "/index"
        },
        {
          key: "datadis",
          name: "信披",
          icon: "person",
          ifHide: !this.currentUserInfo.companyId,
          children: [
            {
              key: "companyInfomation",
              name: "公司信息",
              to: "/datadis/company-infomation"
            },
            {
              key: "personInfomation",
              name: "人物信息",
              to: "/datadis/person-infomation"
            },
            {
              key: "fundInfomation",
              name: "基金信息",
              to: "/datadis/fund-infomation"
            },
            {
              key: "navInfomation",
              name: "净值信息",
              to: "/datadis/nav-infomation"
            },
            {
              key: "questionnaire",
              name: "尽调信息",
              to: "/datadis/questionnaire"
            },
            {
              key: "authorization",
              name: "授权信息",
              to: "/datadis/authorization"
            }
          ]
        },
        {
          key: "productAnalysis",
          name: "分析",
          to: "/analysis/product-analysis"
        },
        {
          key: "reportBuilder",
          name: "报告",
          to: "/analysis/report-builder",
          unlocked: true
        },
        {
          key: "directSale",
          name: "直营店",
          icon: "person",
          unlocked: true,
          children: [
            {
              key: "chat",
              name: "聊天",
              to: "/direct-sale/chat"
            },
            {
              key: "pageConfig",
              name: "店铺装修",
              to: "/direct-sale/page-config",
              ifHide: !(userCompanyApplicationIds.indexOf(301) !== -1)
            },
            {
              key: "productList",
              name: "产品货架",
              to: "/direct-sale/product-list",
              ifHide: !(userCompanyApplicationIds.indexOf(301) !== -1)
            },
            {
              key: "directSalenews",
              name: "新闻资讯",
              to: "/direct-sale/news",
              ifHide: !(userCompanyApplicationIds.indexOf(301) !== -1)
            },
            {
              key: "weekly",
              name: "获客报表",
              to: "/direct-sale/weekly"
              // ifHide: !(userCompanyApplicationIds.indexOf(302) !== -1)
            }
          ]
        },
        {
          key: "marketResearch",
          name: "投研",
          icon: "person",
          unlocked: true,
          ifHide:
            !(userCompanyApplicationIds.indexOf(2) !== -1) &&
            !(userCompanyApplicationIds.indexOf(3) !== -1) &&
            !(userCompanyApplicationIds.indexOf(4) !== -1),
          extendComponents: [
            {
              name: "newIcon",
              ref: "newIcon"
            }
          ],
          children: [
            {
              key: "researchReport",
              name: "研报",
              to: "/analysis/research-report",
              ifHide: !(userCompanyApplicationIds.indexOf(2) !== -1)
            },
            {
              key: "peIndex",
              name: "私募指数",
              to: "/analysis/pe-index",
              ifHide: !(userCompanyApplicationIds.indexOf(3) !== -1)
            },
            {
              key: "macroMarket",
              name: "宏观市场",
              to: "/analysis/macro-market",
              ifHide: !(userCompanyApplicationIds.indexOf(4) !== -1)
            }
          ]
        },
        {
          key: "chance",
          name: "机会",
          to: "/chance",
          unlocked: true,
          extendComponents: [
            {
              name: "chanceTip",
              ref: "chanceTip"
            }
          ]
        },
        {
          key: "brand",
          name: "品牌",
          icon: "person",
          children: [
            {
              key: "roadshow",
              name: "路演",
              to: "/brand/roadshow"
            },
            {
              key: "news",
              name: "资讯",
              to: "/brand/news"
            }
          ]
        },
        {
          key: "customerInfoManager",
          name: "星管家",
          icon: "person",
          ifHide: !(userCompanyApplicationIds.indexOf(1) !== -1),
          extendComponents: [
            {
              name: "wechatLogo",
              ref: "wechatLogo"
            }
          ],
          children: [
            {
              key: "customerManager",
              name: "客户管理",
              to: "/crm/customer-manager"
            },
            {
              key: "fundTrade",
              name: "申购赎回管理",
              to: "/crm/fund-trade"
            },
            {
              key: "companyProduct",
              name: "产品货架",
              to: "/crm/company-product"
            },
            {
              key: "latestNotice",
              name: "最新公告",
              to: "/crm/latest-notice"
            },
            {
              key: "aboutUs",
              name: "关于我们",
              to: "/crm/about-us"
            },
            {
              key: "contactMessage",
              name: "咨询留言",
              to: "/crm/contact-message"
            },
            {
              key: "systemProfite",
              name: "参数配置",
              to: "/crm/system-profit"
            }
          ]
        },
        {
          key: "accountManager",
          name: "账号",
          to: "/account",
          ifHide: this.currentUserInfo.isAdmin != 1
        }
      ];
    }
  },
  mounted() {
    this.currentMenu = this.menuChildKey || this.menuParentKey;

    this.currentUserInfo = window.localStorage.getItem(
      "fund_master_current_user"
    )
      ? JSON.parse(window.localStorage.getItem("fund_master_current_user"))
      : {};
  },
  methods: {
    toPage(url, key, name) {
      if (url.indexOf("http") == -1) {
        location.href =
          this.$baseUrl[process.env.NODE_ENV]["page"] + `${url}/index.html`;
      } else {
        let currentUser = JSON.parse(
          localStorage.getItem("fund_master_current_user")
        );
        sa.event(`fundMaster_pageView`, { url: url, page: name });
        window.open(url);
      }
    },

    refreshChanceCount() {
      this.$refs.chanceTip[0].refreshChanceCount();
    }
  }
};
</script>

<style lang="less" rel="styleSheet/less">
.menu.el-menu {
  color: #eee;
  font-size: 14px;
  background-color: #111;
  border-right: none;
  height: 100%;
  overflow: auto;
  .main-menu {
    .el-menu.el-menu--inline {
      border-top: 1px solid #000;
    }
  }
  .el-submenu,
  .main-menu.no-children {
    border-bottom: 1px solid #000;
    height: auto;
    padding: 0 !important;
    &.is-active {
      .el-submenu__title {
        border-top: 1px solid #345;
        border-bottom: 1px solid #345;
        border-left: 4px solid #17c;
        padding-left: 16px !important;
        background: linear-gradient(#234, #112131);
        vertical-align: initial;
        span {
          vertical-align: initial;
        }
      }
      .sub-menu-title {
        background-color: #102030;
        color: #eee;
        &:hover {
          background-color: #051525;
        }
      }
      .sub-menu {
        &.is-active {
          .sub-menu-title {
            background-color: #051525;
            color: #17c;
          }
        }
      }
    }
  }
  .el-submenu__title {
    height: 40px;
    line-height: 40px;
    text-align: left;
    box-sizing: border-box;
    font-weight: 100;
    color: #eee;
    background: linear-gradient(#252525, #222);
    border-top: 1px solid #333;
    border-bottom: 1px solid #333;
    font-size: 14px;
    padding: 0;
    padding-left: 20px !important;
    .el-submenu__icon-arrow {
      color: #eee;
    }
  }
  .el-menu-item.sub-menu {
    height: 34px;
    line-height: 34px;
    background-color: #111;
    border: 0;
    padding: 0;
    font-size: 12px;
    color: #eee;
    padding-left: 0 !important;
  }
  .main-menu-title {
    height: 100%;
    padding-left: 20px;
    &.unlocked {
      background: url("../../../assets/images/lock-off.png") no-repeat;
      background-position: left center;
    }
  }
  .sub-menu-title {
    height: 100%;
    font-size: 12px;
    padding-left: 46px;
    border: 0;
    background-color: #111;
    vertical-align: initial;
    span {
      vertical-align: initial;
    }
    &:hover {
      background-color: #222;
    }
  }
  .el-dropdown-menu__item--divided::before,
  .el-menu,
  .el-menu--horizontal > :not(.is-disabled).el-menu-item:focus,
  .el-menu--horizontal > :not(.is-disabled).el-menu-item:hover,
  .el-menu--horizontal > .el-submenu .el-submenu__title:hover {
    background-color: transparent;
  }
}
</style>