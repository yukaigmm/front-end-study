<template>
  <div class="common">
    <vheader ref="header" v-if="!hideHeader"></vheader>
    <el-row class="content" :class="{'menu-toggle': menuToggle, 'full-height': hideHeader}">
      <el-col class="content-left" v-if="!hideMenu">
        <vmenu ref="menu" :menuParentKey="menuParentKey" :menuChildKey="menuChildKey"></vmenu>
        <span class="gap">
          <span
            class="icon"
            :class="{'icon-show': !menuToggle, 'icon-hide': menuToggle}"
            @click="toggleMenu"
          ></span>
        </span>
      </el-col>

      <el-col class="content-right" :class="{'full-width': hideMenu}">
        <slot></slot>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import vheader from "./header.vue";
import vmenu from "./menu.vue";
export default {
  components: {
    vheader,
    vmenu
  },
  props: {
    menuParentKey: {
      type: String
    },
    menuChildKey: {
      type: String
    },
    hideHeader: {
      type: Boolean,
      default: false
    },
    hideMenu: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      menuToggle: false
    };
  },
  methods: {
    refreshChanceCount() {
      if (!this.hideMenu) {
        this.$refs.menu.refreshChanceCount();
      }
    },
    toggleMenu() {
      this.menuToggle = !this.menuToggle;
      setTimeout(() => {
        this.$emit("toggleMenu", this.menuToggle);
      }, 300);
    }
  },
  mounted() {}
};
</script>

<style lang="less" rel="styleSheet/less"  scoped>
.common {
  position: relative;
  height: 100%;
  .content {
    height: 100%;
    padding-top: 60px;
    margin-bottom: 0;
    padding-bottom: 0;
    position: relative;
    .content-left {
      // height: 100%;
      height: calc(~"100% - 60px");
      width: 240px;
      background-color: #000;
      padding: 5px 0;
      transition: width 0.3s linear, min-width 0.3s linear;
      z-index: 10;
      position: fixed;
      left: 0;
      top: 60px;
      .gap {
        display: block;
        width: 1px;
        height: calc(~"100% - 5px");
        background-color: transparent;
        position: absolute;
        right: -1px;
        top: 5px;
        .icon {
          cursor: pointer;
          &.icon-show {
            display: block;
            width: 11px;
            height: 60px;
            background: url("../../../assets/images/menu/hide.png");
            position: absolute;
            top: 50%;
            left: -10px;
            transform: translate(0, -50%);
            &:hover {
              background: url("../../../assets/images/menu/hide-hover.png");
            }
          }
          &.icon-hide {
            display: block;
            width: 11px;
            height: 60px;
            background: url("../../../assets/images/menu/show.png");
            position: absolute;
            top: 50%;
            left: 1px;
            transform: translate(0, -50%);
            &:hover {
              background: url("../../../assets/images/menu/show-hover.png");
            }
          }
        }
      }
    }
    .content-right {
      height: 100%;
      width: 100%;
      background-color: #000;
      padding: 5px;
      overflow: auto;
      transition: padding-left 0.3s linear;
      padding-left: 245px;
      &.full-width {
        width: 100%;
        max-width: 100%;
        padding: 0;
      }
      // overflow-y: hidden;
      .container {
        max-width: 100%;
      }
      // .content-right-wrap{
      // 	// margin:10px;
      // 	background-color: #1a1a1a;
      // 	height: 100%;
      // }
    }
    &.full-height {
      padding-top: 0;
    }
    &.menu-toggle {
      .content-left {
        width: 0;
      }
      .content-right {
        padding-left: 5px;
      }
    }
  }
}
</style>