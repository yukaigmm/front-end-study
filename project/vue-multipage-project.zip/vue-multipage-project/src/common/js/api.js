import axios from 'axios';
import {
  Message
} from 'element-ui';
import baseUrlConfig from './base-url-config';
import {
  sendErrorInfo
} from "./utils.js"
const http = axios.create({
  baseURL: '/api/',
  withCredentials: true,
});
const appHttp = axios.create({
  baseURL: `${baseUrlConfig[process.env.NODE_ENV]["ppwApp"]}/DirectPP/index`,
  withCredentials: true,

  // headers: {
  //   'Content-type': 'application/x-www-form-urlencoded'
  // },
  transformRequest: [function (data) {
    data = Object.assign({}, {
      app_install_version: "5.2.3",
      app_type: "2",
      device_uuid: "1"
    }, data);
    let ret = ''
    for (let it in data) {
      ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&'
    }
    return ret
  }]
})


// 增加错误处理
// 完善流程
if (typeof Promise.prototype.done === 'undefined') {
  Promise.prototype.done = function (onDone, onFail) {
    this.then(onDone, onFail).catch(err => {
      setTimeout(() => {
        // onDone && onDone( err )
        throw err
      }, 0)
    })
  }
}

// 设置没有编辑权限时，无法发送编辑请求
let editUrls = [
  // 首页添加基金
  {
    url: '^desk/mastFundStatus$',
    method: 'post',
    type: 'edit'
  },
  // 首页删除基金
  {
    url: '^desk/deleteFundCollection/',
    method: 'delete',
    type: 'delete'
  },
  // 首页隐藏基金
  {
    url: '^desk/hideFund$',
    method: 'put',
    type: 'edit'
  },
  // 公司信息提交
  {
    url: '^datadis/company/CO',
    method: 'put',
    type: 'edit'
  },
  {
    url: '^datadis/company/CO',
    method: 'post',
    type: 'edit'
  },
  // 人员新增和修改
  {
    url: '^datadis/personnel/PL',
    method: 'put',
    type: 'edit'
  },
  {
    url: '^datadis/personnel/PL',
    method: 'post',
    type: 'edit'
  },
  // 人员离职
  {
    url: '^datadis/personnel/applyResign',
    method: 'put',
    type: 'edit'
  },
  // 人员删除
  {
    url: '^datadis/personnel/applyDelete',
    method: 'put',
    type: 'delete'
  },
  // 基金新增
  {
    url: '^datadis/FundContract$',
    method: 'post',
    type: 'edit'
  },
  // 基金修改
  {
    url: '^datadis/fund/HF',
    method: 'put',
    type: 'edit'
  },
  // 基金删除
  {
    url: '^datadis/fund/applyDelete$',
    method: 'put',
    type: 'delete'
  },
  // 导入基金
  {
    url: '^datadis/nav/importNav$',
    method: 'post',
    type: 'edit'
  },
  // 填写净值
  {
    url: '^datadis/nav/adjData$',
    method: 'post',
    type: 'edit'
  },
  // 修改净值
  {
    url: '^datadis/nav/adjData$',
    method: 'post',
    type: 'edit'
  },
  // 调整净值更新频率
  {
    url: '^datadis/fundInformation/HF',
    method: 'put',
    type: 'edit'
  },
  // 分配
  {
    url: '^datadis/distribution$',
    method: 'post',
    type: 'edit'
  },
  {
    url: '^datadis/distribution$',
    method: 'put',
    type: 'edit'
  },
  {
    url: '^datadis/distribution/applyDelete$',
    method: 'put',
    type: 'delete'
  },
  // 机会已读和关注,已联系
  {
    url: '^chance/usermeta$',
    method: 'put',
    type: 'edit'
  },
  // 机会联系我们
  {
    url: '^chance/msg$',
    method: 'post',
    type: 'edit'
  },
  // 新增机会
  {
    url: '^chance$',
    method: 'post',
    type: 'edit'
  },
  // 编辑机会
  {
    url: '^chance/(\\d+)$',
    method: 'put',
    type: 'edit'
  },
  // 删除机会
  {
    url: '^chance/(\\d+)$',
    method: 'delete',
    type: 'delete'
  },
  // 新增路演
  {
    url: '^roadshow$',
    method: 'post',
    type: 'edit'
  },
  // 修改路演
  {
    url: '^roadshow/(\\d+)$',
    method: 'put',
    type: 'edit'
  },
  // 删除路演
  {
    url: '^roadshow/(\\d+)$',
    method: 'delete',
    type: 'delete'
  },

  // 设置留言已读
  {
    url: '^handle/chance/msg/(\\d+)$',
    method: 'put',
    type: 'edit'
  },

  // 账户添加
  {
    url: '^user/account$',
    method: 'post',
    type: 'edit'
  },
  // 账户状态设置
  {
    url: 'user/account/accSetStatus',
    method: 'put',
    type: 'edit'
  },
];

// 请求和响应的拦截器
let responseInterceptor = (response) => {
  let data = response.data;
  let status = response.status;

  if (status !== 200) {
    return Promise.reject(response);
  }

  // 数据请求成功
  if (data.code === 20000) {
    return Promise.resolve(response.data);
  }

  //cookie失效 未登录
  if (data.code === 40100) {
    location.assign(baseUrlConfig[process.env.NODE_ENV]['page'] + '/login/index.html')
    return Promise.resolve(response.data);
  }

  let msg = data.msg;
  return Promise.resolve(response.data)
}

let requestInterceptor = (req) => {
  let canSend = window.sessionStorage.getItem('canSend');
  // 判断请求的url和method和禁止编辑的数组元素一致
  let status;
  let type;
  for (let item of editUrls) {
    if (new RegExp(item.url).test(req.url) && req.method == item.method) {
      status = true;
      type = item.type;
      break;
    }
  }
  if ((canSend === 'false') && status) {
    Message.error(`暂无权限进行此操作`);
    throw new Error;
  }
  return req;
}

http.interceptors.response.use(responseInterceptor, err => {});
http.interceptors.request.use(requestInterceptor, err => {})
appHttp.interceptors.response.use(responseInterceptor, err => {});
appHttp.interceptors.request.use(requestInterceptor, err => {})

// 输出的接口
const get = (url, params) => http.get(url, {
  params
});
const getSingle = (url, id) => http.get(url + '/' + id);
const post = (url, data) => http.post(url, data);
const put = (url, data, id) => {
  if (id) {
    return http.put(url + '/' + id, data)
  } else {
    return http.put(url, data)
  }
};
const putWithoutId = (url, data) => http.put(url, data);
const del = (url, id) => http.delete(url + '/' + id);
const delByParams = (url, params) => http.delete(url, {
  params
});
const appPost = (data) => appHttp.post("", data)

let api = {
  get,
  getSingle,
  post,
  put,
  putWithoutId,
  del,
  delByParams,
  appPost
}

export default api;