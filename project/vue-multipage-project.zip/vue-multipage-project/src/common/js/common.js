import Vue from 'vue';

import '../../assets/fonts/iconfont.css'

//fof-style
import 'fof-style/dist/index.css';

//custom files
require('../css/common.less');

// 原先的逻辑是判断浏览器是否支持新特性，如果支持就不引入babel-polyfill，但是有的浏览器支持部分新特性，所以不好判断，只能加一个新的polyfill包
require("./custom-polyfill.js");
// error handler
// require('./error.js')
require("./error-feedback.js")
//sc cdn
require('./sc.js');



//vue http
import api from './api';
Vue.prototype.$http = api;

//vue baseUrl config
import baseUrlConfig from './base-url-config';
Vue.prototype.$baseUrl = baseUrlConfig;


// 去除vue生产环境提示
Vue.config.productionTip = false;


// 引入element-ui 组件
import Element from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

// 

Vue.use(Element);
export default Vue;