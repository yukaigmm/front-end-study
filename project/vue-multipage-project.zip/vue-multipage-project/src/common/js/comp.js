import Vue from './common'


//自定义组件
//layout
import vcommon from '../components/layout/common.vue';


//comp
import vmodal from '../components/comp/modal.vue';
import vtable from '../components/comp/table.vue';
import vtab from '../components/comp/tab.vue';
import vform from '../components/comp/form.vue';
import vformItem from '../components/comp/form-item.vue';
import vformConfig from '../components/comp/form-config.vue';
import vformTab from '../components/comp/form-tab.vue';
import vvalidBox from '../components/comp/valid-box.vue';
import vbutton from '../components/comp/button.vue';
import vbuttonSprite from '../components/comp/button-sprite.vue';
import vloading from '../components/comp/loading.vue';
import vtooltip from '../components/comp/tooltip.vue';
import vpart from '../components/comp/part.vue';
import vreload from "../components/comp/reload.vue"

//inputs
import vtext from '../components/inputs/text.vue';
import vinput from '../components/inputs/input.vue';
import vtextArea from '../components/inputs/text-area.vue';
import veditor from '../components/inputs/editor/editor.vue';
import vradio from '../components/inputs/radio.vue';
import vcheckbox from '../components/inputs/checkbox.vue';
import vselect from '../components/inputs/select.vue';
import vselectRemote from '../components/inputs/select-remote.vue';
import vselectFilter from '../components/inputs/select-filter.vue';
import vswitch from '../components/inputs/switch.vue';
import vdatePicker from '../components/inputs/date-picker.vue';
import vfileUpload from '../components/inputs/file-upload.vue';
import vimageUpload from '../components/inputs/image-upload.vue';
import vvideoUpload from '../components/inputs/video-upload.vue';
import varea from '../components/inputs/area-cascade.vue';
import vinputRadio from '../components/inputs/input-radio.vue';
import vinputSelect from '../components/inputs/input-select.vue';
import vdateRangePicker from '../components/inputs/date-range-picker/index.vue';
import subFundTable from "../../pages/direct-sale/product-list/components/sub-fund-table.vue"

// 表格内自定义控件
import editTableCell from "../components/inputs/tablecolumns.vue";

import EditSelect from "../../pages/direct-sale/product-list/components/edit-select"

import OpenRedemptionSelector from "../../pages/datadis/fund-infomation/components/open-redemption-day-selector"

//layout
Vue.component('vcommon', vcommon);

//comp
Vue.component('vmodal', vmodal);
Vue.component('vtable', vtable);
Vue.component('vtab', vtab);
Vue.component('vform', vform);
Vue.component('vformItem', vformItem);
Vue.component('vformConfig', vformConfig);
Vue.component('vformTab', vformTab);
Vue.component('vvalidBox', vvalidBox);
Vue.component('vbutton', vbutton);
Vue.component('vbuttonSprite', vbuttonSprite);
Vue.component('veditor', veditor);
Vue.component('vloading', vloading);
Vue.component('vtooltip', vtooltip);
Vue.component('vpart', vpart);
Vue.component('vreload', vreload);


//inputs
Vue.component('vtext', vtext);
Vue.component('vinput', vinput);
Vue.component('vtextArea', vtextArea);
Vue.component('vradio', vradio);
Vue.component('vcheckbox', vcheckbox);
Vue.component('vselect', vselect);
Vue.component('vselectRemote', vselectRemote);
Vue.component('vselectFilter', vselectFilter);
Vue.component('vswitch', vswitch);
Vue.component('vdatePicker', vdatePicker);
Vue.component('vfileUpload', vfileUpload);
Vue.component('vimageUpload', vimageUpload);
Vue.component('vvideoUpload', vvideoUpload);
Vue.component('varea', varea);
Vue.component('vinputRadio', vinputRadio);
Vue.component('vinputSelect', vinputSelect);
Vue.component('vdateRangePicker', vdateRangePicker);


Vue.component("editTableCell", editTableCell)
Vue.component("subFundTable", subFundTable)
Vue.component("EditSelect", EditSelect)
Vue.component("OpenRedemptionSelector", OpenRedemptionSelector)