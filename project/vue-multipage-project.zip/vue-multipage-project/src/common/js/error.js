// 错误监控机制
// 整理
// 捕捉
// 上报(后期)


//引入fundebug进行bug收集
var fundebug = require("fundebug-javascript");

//development,test,pre使用一个apikey, production使用单独的apikey
// production => 7e221bdd955f1d1ded2561dccd8f89edb26267559f38f1069b3a1dc1713f3d57
// dev, test, pre => 6c1ead35861f1d720d4a6e9955c4f0bfa32512a73f720e6b302bb5c2d914757e
fundebug.apikey = process.env.NODE_ENV === 'production' ?
    '7e221bdd955f1d1ded2561dccd8f89edb26267559f38f1069b3a1dc1713f3d57' : '6c1ead35861f1d720d4a6e9955c4f0bfa32512a73f720e6b302bb5c2d914757e';
//打开录屏功能
fundebug.silentVideo = false;
//设置环境
fundebug.releasestage = process.env.NODE_ENV;
//收集http body参数
fundebug.setHttpBody = true;


function formatComponentName(vm) {
    if (vm.$root === vm) return 'root';
    var name = vm._isVue ?
        (vm.$options && vm.$options.name) ||
        (vm.$options && vm.$options._componentTag) :
        vm.name;
    return (
        (name ? 'component <' + name + '>' : 'anonymous component') +
        (vm._isVue && vm.$options && vm.$options.__file ?
            ' at ' + (vm.$options && vm.$options.__file) :
            '')
    );
}

Vue.config.errorHandler = function (err, vm, info) {

    let currentUser = JSON.parse(localStorage.getItem('fund_master_current_user'));
    let userId = currentUser.userId;
    let userName = currentUser.trueName;
    let companyName = currentUser.companyName;
    if (vm) {
        var componentName = formatComponentName(vm);
        var propsData = vm.$options && vm.$options.propsData;
        fundebug.notifyError(err, {
            metaData: {
                userId,
                userName,
                companyName,
                componentName: componentName,
                propsData: propsData,
                info: info
            }
        });
    } else {
        fundebug.notifyError(err, {
            userId,
            userName,
            companyName,
        });
    }
};



/*
// 错误捕捉
// errMsg, scriptURI, lineNo, columnNo, error
// 
window.onerror = function( msg, script, line, column, error ){
    
    let message = error && error.stack ? error.stack: msg
    script = script || ''
    line = line || ''
    column = column || '';

    print( message, script, line, column )
}




// Vue中错误捕获
// 
Vue.config.errorHandler = function( err, vm, info ){
    
    let {
        message,
        name,
        column,
        stack
    } = err

    
    let source = stack.match(/at[^)]+\)/im)[0]
    let script = source.match(/\((.+)\)/)[1]
    let line = script.slice( script.lastIndexOf('js:')+3 )
    
    //
    line = line.split(':')[0]
    script = script.slice(0, script.lastIndexOf('js:') + 2)

    print( message + ' at ' + info, script, line, column, name )
}

// 客户端打印
// 
function print( message, script, line, column, type, error ){
    let primaryInfo = 
        '%c引发脚本：' + script + '\n' +
        '错误行：' + line + '\n' +
        '错误列：' + column

    let warnInfo = 
        (type ? ('错误类型：' + type + '\n') : '') +
        '错误说明：' + message

    window.console.log( primaryInfo, 'color:#f00' )
    window.console.warn( warnInfo )
}
*/