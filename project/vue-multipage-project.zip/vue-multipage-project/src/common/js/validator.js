import api from "./api.js"

// 验证必填
// const validateRequired = (rule, value, callback, source, options) => {
//     var errors = [];
//     if (!value) {
//         errors.push(new Error("必填"))
//     }
//     callback(errors)
// }
const validateRequired = (invalidMsg) => {
    return {
        required: true,
        message: invalidMsg || '必填'
    };
}

// 验证满足关联条件时必填
// const validateRelatedRequired = (params = [], currentValue, msg) => {
//     return function (rlue, value, callback, source, options) {
//         var errors = [];
//         if (params.includes(currentValue)) {
//             if (!value) {
//                 errors.push(new Error(msg || "必填"))
//             }
//         }
//         callback(errors)
//     }
// }

// 填写了某个条件时必填
// const validateRequiredWhile = (param, msg) => {
//     return function (rlue, value, callback, source, options) {
//         var errors = [];
//         if (param) {
//             if (!value) {
//                 errors.push(new Error(msg || "必填！"))
//             }
//         }
//         callback(errors)
//     }
// }

// 验证不能含有非法字符
// const validateNotContainInvalidWords = (rule, value, callback, source, options) => {
//     var errors = [];
//     if (value && /^([\.●*\S])$/.test(value)) {
//         errors.push(new Error("名称不得含.,●,*字符及空格"))
//     }
//     callback(errors)
// }
const validateNotContainInvalidWords = (words = [], invalidMsg) => {
    return (rule, value, callback, source, options) => {
        var errors = [];
        if (value) {
            words.forEach(word => {
                if (value.indexOf(word) !== -1) {
                    errors.push(new Error(invalidMsg || `名称不得含${words.join(',')}字符及空格`))
                }

            })
        }
        callback(errors)
    }
}

// 验证是否重复
const validateIsrepeat = (url, type = "get", key, msg = "已存在", param2, param3) => {
    return function (rule, value, callback, source, options) {
        var errors = [];
        let params;
        if (param2 !== undefined) {
            params = Object.assign({}, {
                [key]: value,
                isShort: param2
            }, param3)
        } else {
            params = {
                [key]: value,
            }
        }

        if (value) {
            if (type === "get") {
                api.get(url,
                    params
                ).then(res => {
                    if (res.data.isRepeat) {

                        errors.push(new Error(msg))
                    } else {
                        errors = []
                    }
                }).then(() => {
                    callback(errors)
                })
            } else {
                api.post(url, params).then(res => {
                    if (res.data.isRepeat) {
                        errors.push(new Error(msg))

                    } else {
                        errors = []
                    }
                }).then(() => {
                    callback(errors)
                })
            }
        } else {
            callback(errors)
        }



    }
}

// 验证指定的长度
const validateLength = (len) => {
    return function (rule, value, callback, source, options) {
        var errros = [];
        if (value.trim() && value.length !== len) {
            errors.push(new Error(`必须满足长度为${len}`))
        }
        callback(errors)
    }
}

// 验证大于等于某一日期
const validateGreaterThanSomedate = (date, msg) => {
    return function (rule, value, callback, source, options) {
        var errors = [];
        var ruleDate = new Date(date);
        var valueDate = new Date(value);
        if (valueDate.getTime() < ruleDate.getTime()) {
            errors.push(new Error(msg));
        }
        callback(errors);
    }
}

// 验证小于某一日期
const validateLessThanSomedate = (date, msg) => {
    return function (rule, value, callback, source, options) {
        var errors = [];
        var ruleDate = new Date(date);
        var valueDate = new Date(value);
        if (valueDate.getTime() > ruleDate.getTime()) {
            errors.push(new Error(msg));
        }
        callback(errors);
    }
}

// 验证包含指定字符串
const validateContainSomeString = (str, key) => {
    return function (rule, value, callback, source, options) {
        var errors = [];
        if (key.includes(str)) {
            if (!value) {
                errors.push(new Error("必填"))
            }
        }
        callback(errors)
    }
}

// 为指定类型
const validateSomeType = (type) => {
    return function (rule, value, callback, source, options) {

    }
}

// 验证大于某个数
const validateBiggerThanSomeNumber = (val, msg, equal) => {
    return function (rule, value, callback, source, options) {
        var errors = [];
        if (equal) {
            if (value && !(value >= val)) {
                errors.push(new Error(msg))
            }
        } else {
            if (value && !(value > val)) {
                errors.push(new Error(msg))
            }
        }
        callback(errors)
    }
}

// 验证小于某个数
const validateLessThanSomeNumber = (val, msg) => {
    return function (rule, value, callback, source, options) {
        var errors = [];
        if (value && value > val) {
            errors.push(new Error(msg))
        }
        callback(errors)
    }
}

// 验证在某两个数之间
const validateBetweenTwoNumbers = (lessValue, bigValue, msg, equal, exceptNum) => {
    return function (rule, value, callback, source, options) {

        var errors = [];
        if (exceptNum != undefined) {
            if (parseInt(value) === parseInt(exceptNum)) {

            } else {
                if (equal) {
                    if (value && !(value >= lessValue && value <= bigValue)) {
                        errors.push(new Error(msg))
                    }
                } else {
                    if (value && !(value > lessValue && value < bigValue)) {
                        errors.push(new Error(msg))
                    }
                }
            }
        } else {
            if (equal) {
                if (value && !(value >= lessValue && value <= bigValue)) {
                    errors.push(new Error(msg))
                }
            } else {
                if (value && !(value > lessValue && value < bigValue)) {
                    errors.push(new Error(msg))
                }
            }
        }
        callback(errors)
    }
}

// 验证指定长度的汉字
const validateChineseWithLength = (len, msg) => {
    return function (rule, value, callback, source, options) {
        var errors = [];
        if (value.trim() && !/^[\一-\龥]{1,4}$/.test(value.trim())) {
            errors.push(new Error(msg))
        }
        callback(errors)
    }
}

// 验证大于指定年龄
const validateBiggerThanSomeAge = (age, msg) => {
    return function (rule, value, callback, source, options) {
        var errors = [];
        var nowYear = new Date().getFullYear();
        var valueYear = new Date(value).getFullYear();
        if (value && ((nowYear - valueYear) < age)) {
            errors.push(msg)
        }
        callback(errors)
    }
}

// 验证必须为整数
const validateIntNumber = (rule, value, callback, source, options) => {
    var errors = [];
    if (value && !/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(value)) {
        errors.push(new Error('必须为整数'))
    }
    callback(errors);
}

// 验证手机号
const validatePhoneNumber = (msg = "格式不正确") => {
    return function (rule, value, callback, source, options) {
        var errors = [];
        if (value && !/^(0?(13[0-9]|15[012356789]|17[013678]|18[0-9]|14[579]|19[89])[0-9]{8}$)|((400|800)([0-9\\-]{7,10})|((((((^010)|^02[012345789]{1}))(-| )?)([0-9]){8}$)|((((^0[3456789]{1})[0-9]{2})(-| )?)([0-9]{7,8}$)))((-| |转)*([0-9]{1,4}))?)$/.test(value)) {
            errors.push(new Error(msg))
        }
        callback(errors)
    }
}

// 验证邮箱
const validateEmail = (msg) => {
    return function (rule, value, callback, source, options) {
        var errors = [];
        if (value && !/^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/.test(value)) {
            errors.push(new Error("格式不正确"))
        }
        callback(errors)
    }
}

// 验证不能为周末
const validateWeekend = (rule, value, callback, source, options) => {
    var errors = [];
    var valueDate = new Date(value).getDay();
    if (value && (valueDate == 0 || valueDate == 6)) {
        errors.push(new Error("净值日期不能为周六、日"))
    }
    callback(errors)
}





export {
    // 验证必填
    validateRequired,
    // 验证满足关联条件时必填
    // validateRelatedRequired,
    // 填写了某个条件时必填
    // validateRequiredWhile,
    // 验证包含指定字符时
    validateNotContainInvalidWords,
    // 验证重复
    validateIsrepeat,
    // 验证指定长度
    validateLength,
    // 验证大于某个日期
    validateGreaterThanSomedate,
    // 验证小于某个日期
    validateLessThanSomedate,
    // 验证是否包含某个字符
    validateContainSomeString,
    // 验证指定类型
    validateSomeType,
    // 验证大于某个数
    validateBiggerThanSomeNumber,
    // 验证小于某个数
    validateLessThanSomeNumber,
    // 验证在某两个数之间
    validateBetweenTwoNumbers,
    // 验证指定长度的汉字
    validateChineseWithLength,
    // 验证大于某个年龄
    validateBiggerThanSomeAge,
    // 验证是整数
    validateIntNumber,
    // 验证手机号
    validatePhoneNumber,
    // 验证邮箱
    validateEmail,
    // 验证是否是周末
    validateWeekend
}