

/**
  * 神策分析平台
  * 后台地址：https://scadmin.simuwang.com
  * 项目：
  *   dev, test, pre => 测试项目
  *   production => 智能投资-正式环境
  * 账号密码： 
  *   dev, test, pre => admin kdSvML
  *   production => admin 123456
  

  * 当前需求：( from amy ) 
  *   统计各公司对各菜单的访问次数 
  * 方式： 
  *   左侧菜单 => 自定义查询
  * sql：
  *   select companyid,page,date,count(*) from events where event = 'fundMaster_pageView' and date >= '2018-12-01' group by companyid,page,date

  * excel转换程序：
  *   convertExcel/convertExcel.js

  * 注： 目前星管家各页面未加入fundMaster_pageView事件统计中，需在web/admin-pc/src/common/mixins/pageView.js中添加urlPageMap
*/



import _ from 'lodash';
import {
  getCurrentDateString
} from './utils';

let env = process.env.NODE_ENV;

let scFn = function (para) {
  var p = para.sdk_url,
    n = para.name,
    w = window,
    d = document,
    s = 'script',
    x = null,
    y = null;
  w['sensorsDataAnalytic201505'] = n;
  w[n] = w[n] || function (a) {
    return function () {
      (w[n]._q = w[n]._q || []).push([a, arguments]);
    }
  };
  var ifs = ['track', 'quick', 'register', 'registerPage', 'registerOnce', 'trackSignup', 'trackAbtest', 'setProfile', 'setOnceProfile', 'appendProfile', 'incrementProfile', 'deleteProfile', 'unsetProfile', 'identify', 'login', 'logout', 'trackLink', 'clearAllRegister', 'getAppStatus'];
  for (var i = 0; i < ifs.length; i++) {
    w[n][ifs[i]] = w[n].call(null, ifs[i]);
  }
  if (!w[n]._t) {
    x = d.createElement(s), y = d.getElementsByTagName(s)[0];
    x.async = 1;
    x.src = p;
    x.setAttribute('charset', 'UTF-8');
    y.parentNode.insertBefore(x, y);
    w[n].para = para;
  }
}

if (env === 'test' || env === 'pre') {
  //加载测试环境神策cdn
  scFn({
    sdk_url: 'https://static.sensorsdata.cn/sdk/1.10.9/sensorsdata.min.js',
    heatmap_url: 'https://static.sensorsdata.cn/sdk/1.10.9/heatmap.min.js',
    name: 'sa',
    web_url: 'https://scadmin-test.simuwang.com/',
    // server_url: 'https://scjdk-test.simuwang.com/default/sa',
    server_url: 'https://sensor.simuwang.com/sa?project=default',
    heatmap: {},
    show_log: false,
  });
  sa.quick('autoTrack');
} else if (env === 'production') {
  //加载正式环境神策cdn
  scFn({
    sdk_url: 'https://static.sensorsdata.cn/sdk/1.10.9/sensorsdata.min.js',
    heatmap_url: 'https://static.sensorsdata.cn/sdk/1.10.9/heatmap.min.js',
    name: 'sa',
    web_url: 'https://scadmin.simuwang.com/?project=smart_investment_produciton',
    // server_url: 'https://scjdk.simuwang.com/prod/sa?project=smart_investment_produciton',
    server_url: 'https://sensor.simuwang.com/sa?project=production',
    heatmap: {},
    show_log: false
  });
  sa.quick('autoTrack');

} else if (env === 'development') {
  window.sa = {
    login: () => {},
    track: () => {},
  }
}

//扩展sa对象,添加 事件默认附带的属性
sa.event = (eventName, props = {}, callback) => {
  let currentUser = JSON.parse(localStorage.getItem('fund_master_current_user'));
  let finalProps = {
    userName: currentUser.trueName || currentUser.userName,
    userId: currentUser.userId,
    companyId: currentUser.companyId,
    time: getCurrentDateString(),
    company: currentUser.company,
  };
  _.forEach(props, (value, key) => {
    finalProps[key] = value;
  })
  sa.track(eventName, finalProps, callback);
}
