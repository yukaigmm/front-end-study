import api from './api';
import baseUrlConfig from './base-url-config';


//获取所有下拉选项，存入sessionStorage中
let setOptionsMap = () => {
  return new Promise((resolve) => {
    let optionsData = sessionStorage.getItem('fund_master_options');
    let hasVersionChanged = localStorage.getItem("has_version_changed");

    if (typeof optionsData === 'string' && optionsData.length && JSON.parse(optionsData) instanceof Object && !hasVersionChanged) {
      resolve();
    } else {
      api.get('common/config').then((resp) => {
        if (resp.code === 20000) {
          sessionStorage.setItem('fund_master_options', JSON.stringify(resp.data));
        }
        resolve();
      }, () => {
        resolve();
      })
    }

  })
}



//获取sessionStorage中的选项
let getSessionOption = (key) => {
  let optionsData = JSON.parse(sessionStorage.getItem('fund_master_options'));

  if (key && typeof key === 'string') {
    return optionsData[key] || [];
  } else {
    return optionsData || {};
  }
}

// 验证是否已登录
let checkUserInfo = () => {
  return new Promise((resolve, reject) => {
    api.get('/user/checkInfo').then(res => {
      if (!res) {
        reject();
      }
      if (res && res.code === 20000) {
        resolve(res);
      } else {
        reject();
      }
    }).catch(err => {
      reject();
    })
  })
}

//通过用户验证信息跳转页面
let userInfoValidate = () => {

  return new Promise((resolve, reject) => {
    checkUserInfo().then(res => {
      let data = res.data || {};
      let user = {
        userName: data.username,
        trueName: data.trueName,
        changeAble: data.changeAble,
        changeLevel: data.changeLevel,
        isAdmin: data.isAdmin,
        isVirtual: data.isVirtual,
        companyId: data.companyId,
        companyName: data.companyName,
        userId: data.userId,
        userCompanyApplicationIds: data.userCompanyApplicationIds,
        userPermission: data.userPermission || 1,
        smUserName: data.smUserName,
        smUserId: data.smUserId
      };
      let currentVersion = localStorage.getItem('fund_master_version');


      let version = data.version;
      if (currentVersion != version) {
        localStorage.setItem("has_version_changed", true);
      } else {
        localStorage.setItem("has_version_changed", false);
      }


      localStorage.setItem('fund_master_version', version);
      localStorage.setItem("fund_master_current_user", JSON.stringify(user));
      //用户已登陆， 如果用户处于登录页则跳转是首页，其他页面不用跳转
      if (location.href.indexOf('login') == -1) {
        resolve()
      } else {
        reject();
        location.assign(baseUrlConfig[process.env.NODE_ENV]['page'] + '/index/index.html');
      }

    }, err => {
      //用户未登陆，如果用户在登录页以外的页面，则跳转至登录页
      if (location.href.indexOf('login') == -1) {
        reject();
        location.assign(baseUrlConfig[process.env.NODE_ENV]['page'] + '/login/index.html');
      } else {
        resolve();
      }
    }).catch(err => {
      reject();
      if (location.href.indexOf('login') == -1) {
        location.assign(baseUrlConfig[process.env.NODE_ENV]['page'] + '/login/index.html');
      }
    })
  })
}

let getCurrentDateString = () => {
  let date = new Date();
  return `${date.getFullYear()}-${date.getMonth()+1}-${date.getDate()}`;
}
// module.exports = getUserInfo();

let getUrlParams = () => {
  let urlParams = {};
  let pairs = window.location.search.substring(1).split("&");
  for (let i = 0; i < pairs.length; i++) {
    let pos = pairs[i].indexOf("=");
    if (pos === -1) {
      continue;
    }
    let [key, value] = pairs[i].split("=");
    urlParams[key] = value;
  }
  return urlParams;
};

// 组合大师刷新token
function refreshToken({
  token,
  companyId,
  userName,
  userIdEncrypted
}) {

  return new Promise((resolve, reject) => {
    $.ajax({
      type: "get",
      url: `${
        baseUrlConfig[process.env.NODE_ENV]["master"]
      }/fundMaster/Index/flush`,
      dataType: "jsonp",
      data: {
        token,
        companyId,
        userName,
        userIdEncrypted
      },
      // jsonp: "callback",
      jsonpCallback: "success_jsonpCallback",
      success: json => {
        // console.log(json);
        // debugger
        if (+json.suc === 1) {
          resolve();
        } else {
          reject();
        }
        // resolve();
      },
      fail: () => {
        reject();
      },
      error: () => {
        reject();
      },
      beforeSend: () => {}
    });
  });
};

// 页面中刷新组合大师 token
function refreshMasterToken() {
  return new Promise((resolve, reject) => {
    return checkUserInfo().then((res) => {
      let data = res.data;
      let companyId = data.companyId || data.orgId;
      let {
        token,
        userIdEncrypted
      } = data.userCenter;
      let userName = data.trueName;
      refreshToken({
        token,
        companyId,
        userName,
        userIdEncrypted
      }).then(() => {
        window.sessionStorage.setItem("masterUseable", true);
        resolve()
      }, () => {
        window.sessionStorage.setItem("masterUseable", false);
        resolve()
      })
    })
  })
};

// 获取浏览器信息
function getBrowserInfo() {
  var version = window.navigator.userAgent.toLowerCase()
  var bowsers = {
    chrome: 25,
    firefox: 20,
    msie: 9
  }
  for (var name in bowsers) {
    if (version.indexOf(name) !== -1) {
      var patt = new RegExp('\\s' + name + '[^;]+\\s*', 'i')
      var result = version.match(patt)[0]
      var v = result.match(/\d+/)[0] - 0
      return `浏览器型号：${name}，版本${v}`
    }
  }
};

// 获取公司信息
function getCompanyInfo() {
  let originUser = window.localStorage.getItem("fund_master_origin_user");
  let companyInfo = {};
  if (originUser) {
    let info = JSON.parse(originUser);
    companyInfo.companyId = info.companyId;
    companyInfo.companyName = info.companyName;
    companyInfo.userName = info.trueName;
    return companyInfo;
  }
}
export {
  setOptionsMap,
  getSessionOption,
  checkUserInfo,
  userInfoValidate,
  getCurrentDateString,
  getUrlParams,
  refreshToken,
  refreshMasterToken,
  getBrowserInfo,
  sendErrorInfo,
  getCompanyInfo
}