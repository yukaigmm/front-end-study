import { SourceMapConsumer } from "../../assets/lib/source-map/source-map.js";
import {getBrowserInfo} from "./utils.js";
import api from "./api.js"

SourceMapConsumer.initialize({
    "lib/mappings.wasm": "../../assets/lib/source-map/mappings.wasm"
})

// 获取 vue 报错时的错误信息，包括行数，列数，出错文件
function getErrorInfo(e) {
    let docPath = e.stack.match(/\((.+?)\.js/)[1] + ".js.map";
    let errorPositionInfo = e.stack.match(/\((.+?)\)/)[0].match(/[0-9]+\:[0-9]+/)[0] || "";
    let errorPositionInfoArr = errorPositionInfo.split(":");
    let line, column;
    line = +errorPositionInfoArr[0];
    column = +errorPositionInfoArr[1];
    let errorInfo = {
        message: e.message,
        stack: e.stack,
        column,
        line,
        docPath
    };
    return errorInfo;
}
// 获取 sourceMap
function getSourceMap(path) {
    return new Promise((resolve, reject) => {
        api.get("/readFile", {
            // file: "https://fm-test.simuwang.com/pc/assets/js/datadis/company-infomation.js.map"
            file: path
        }).then((res) => {
            if(res.data){
                resolve(res.data.data);
            }else{
                reject();
            }
        })
    })
}
// 根据 sourceMap 获取错误信息定位
// ie 不支持webassembly，引入的sourceMap需要在浏览器端运行webAssembly，所以需要判断环境是否支持
function getErrorPostion(errorInfo) {
    return new Promise((resolve, reject) => {
        if(window.WebAssembly){
            let {
                line,
                column,
                docPath
            } = errorInfo;
            getSourceMap(docPath).then((source) => {
                if(source.version){
                    new SourceMapConsumer(JSON.parse(JSON.stringify(source))).then((consumer) => {
                        const pos = consumer.originalPositionFor({ line, column});
                        resolve(pos);
                    })
                }
            }, () => {
                reject();
            })
        }else{
            resolve(errorInfo);
        }
    })
}

// 发送错误信息
function sendErrorInfo(errorInfo) {
    let browserInfo = getBrowserInfo();
    let userInfo = window.localStorage.getItem("fund_master_current_user");
    userInfo = userInfo && JSON.parse(userInfo);
    let pageInfo = window.location.href;
    let params = {
        browserInfo,
        userInfo,
        errorInfo,
        pageInfo
    };
    api.post("/clientLog", params);
}

Vue.config.errorHandler = function (e, vm, info) {
    console.error(e)
    let errorInfo = getErrorInfo(e);
    getErrorPostion(errorInfo).then((pos) => {
        errorInfo = Object.assign({}, errorInfo, pos);
        sendErrorInfo(errorInfo);
    },() => {})
}