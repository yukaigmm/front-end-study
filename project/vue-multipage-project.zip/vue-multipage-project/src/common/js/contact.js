//添加基金时显示的联系方式
const contact = {
  landline: '0755-83256796',
  cel: '18122062906',
  qq: '3354170976',
  wechat: '18122062906',
}


export default contact;