// console polyfill
window.console = window.console || (function () {
    var c = {}; c.log = c.warn = c.debug = c.info = c.error = c.time = c.dir = c.profile
    = c.clear = c.exception = c.trace = c.assert = function () { };
    return c;
})();
window.log = console.log;
// array.includes polyfill
Array.prototype.includes = Array.prototype.includes || function(value, start){
    if(start >= this.length - 1)return false;
    if(this.indexOf(value, start) === -1){
        return false;
    }
    return true;
}
// string.includes 
String.prototype.includes = String.prototype.includes || function(value, start){
    if(start >= this.length - 1)return false;
    if(this.indexOf(value, start) === -1){
        return false;
    }
    return true;
}