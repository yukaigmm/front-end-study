/** 
 * 用与table组件中自定义单元格内容的渲染
*/

export default {
  props: {
    renderContent: Function,
    scope: Object,
    prop: String
  },
  render(h) {
    const prop = this.prop;
    const scope = this.scope;

    if (this.renderContent) {
      let content = this.renderContent.call(this._renderProxy, h, {
        row: scope.row,
        column: scope.column,
        index: scope.$index
      });

      return content && content.tag ? content : h('span', content || '');

    } else {
      return h('span', scope.row[prop])
    }

  },

}