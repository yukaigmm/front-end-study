export default {
    hasScrollBar: {
        inserted(el, bindings, vNode) {
            // bindings.value();
        }
    }
}