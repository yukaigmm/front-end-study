export default {
  filters: {
    setFloatLength(val, length) {
      if (length) {
        return parseFloat(val).toFixed(length)
      } else {
        return parseFloat(val).toFixed(2)
      }
    },
    setPercentString(val, length) {
      if (parseFloat(val) || parseFloat(val) === 0) {
        if (length) {
          return (parseFloat(val) * 100).toFixed(length) + '%'
        } else {
          return (parseFloat(val) * 100).toFixed(2) + '%'
        }
      } else {
        return val
      }
    }
  }
}