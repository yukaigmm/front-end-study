/**
  * 神策页面访问事件
  * 当vue实例即将生成时，即表示用户信息为正常情况（若登录则非登录页，若未登陆则必为登录页）。
  * 此时触发页面访问事件。
*/

import {
  getCurrentDateString
} from '../js/utils'

let urlPageMap = {
  // 'login/index': '登录页',
  'index/index': '首页',
  'datadis/compony-infomation': '公司信息',
  'datadis/person-infomation': '人物信息',
  'datadis/fund-infomation': '基金信息',
  'datadis/nav-infomation': '净值信息',
  '/datadis/questionnaire': '尽调信息',
  '/datadis/authorization': '授权信息',
  'analysis/product-analysis': '分析',
  'analysis/report-builder': '报告',
  'chance/index': '机会',
  'account/index': '账号',
}


export default {
  beforeCreate() {
    let href = location.href;
    if (localStorage.getItem('fund_master_current_user')) {
      // sa.track('fundMaster_pageView', {userName: currentUser.trueName || currentUser.userName, currentUser: currentUser.userId, url: location.href, viewTime: getCurrentDateString()})
      _.forEach(urlPageMap, (value, key) => {
        if (href.indexOf(key) !== -1) {
          sa.event(`fundMaster_pageView`, {
            url: location.href,
            page: value
          });
        }
      })
    } else {
      sa.track(`fundMaster_pageView`, {
        url: location.href,
        page: '登录页',
        time: getCurrentDateString()
      });
    }


  }
}