export default {
  data() {
    return {
      maxHeight: 400
    }
  },
  methods: {
    setTabelHeight() {
      let contentHeight = document.querySelector('.content-right').offsetHeight;
      this.maxHeight = contentHeight - (this.hasTabs ? 130 : 100);
      
      window.addEventListener('resize', () => {
        let contentHeight = document.querySelector('.content-right').offsetHeight;
        this.maxHeight = contentHeight - (this.hasTabs ? 130 : 100);
      })
    }
  },
  mounted() {
    setTimeout(() => {
      this.setTabelHeight();
    }, 100)
  }
}