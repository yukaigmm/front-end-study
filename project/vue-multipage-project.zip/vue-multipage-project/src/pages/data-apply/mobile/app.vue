<template>
  <div class="data-apply-container-mobile" ref="applyContainer">
    <vloading v-model="submitLoading"></vloading>
    <div class="page-header">
      <div class="logo-container"></div>
      <div class="logo-text">数据展示与反馈</div>
    </div>
    <div class="page-content">
      
        <div class="notice-text">如果您希望您公司或者基金的数据在排排网网站或APP展示，只需上传名片，排排网工作人员会第一时间联系您。</div>
        <div class="submit-success" v-if="applySuccess">
        <div class="success-icon">
          <div class="icon"></div>
          <div class="text">提交成功</div>
        </div>
      </div>
        <div class="img-container" @click="uploadCard">
          <img :src="cardUrl" alt="" v-show="currentCardUrl">
          <div class="img-placeholder" v-show="!currentCardUrl">
            <div class="img"></div>
            <span>上传名片</span>
          </div>
          <vloading v-model="uploadFileLoading"></vloading>
        </div>
        <form ref="uploadFileForm" style="display: none">
          <input
            type="file"
            accept="image/*"
            name="visitingCard"
            ref="uploadFileInput"
            @change="uploadFileInputChange"
          >
        </form>
        <div class="submit-button" @click="submit">确定</div>
    </div>
    <div class="page-footer">
      <p>
      如果您发现排排网的数据不正确，或对排排网数据有疑问，请联系排排网数据中心反馈。
      </p>
      <p>客服手机/微信：181-2206-2906</p>
    </div>
  </div>
</template>

<script>
  import {getUrlParams} from "../../../common/js/utils.js";
  export default {
    data () {
      return {
        currentCardUrl: null,
        uploadFileLoading: false,
        submitLoading: false,
        applySuccess: false,
      }
    },
    computed: {
      cardUrl(){
        if(this.currentCardUrl){
          return `${this.$baseUrl[process.env.NODE_ENV]["staticFile"]}/${this.currentCardUrl}`
        }
        return null;
      }
    },
    methods: {
     uploadFileInputChange(e) {
        let files = event.target.files || window.event.target;
        let file = files[0] || {};
        if(file.type.indexOf("image/") == -1){
          this.$message.error("图片格式有误，请重新上传!");
          this.currentCardUrl = "";
          return this.imageNotice = "图片格式有误，请重新上传！"
        }
        this.imageNotice = "";
        let form = this.$refs.uploadFileForm;
        let formData = new FormData(form);
        this.uploadFileLoading = true;
        this.$http.post("file/visitingCard", formData).then(res => {
          this.uploadFileLoading = false;
          if (res.code === 20000) {
            this.$message.success("上传成功");
            this.currentCardUrl = res.data.filePath;
            this.$refs.uploadFileInput.value = "";
          } else {
            this.$message.error(`上传失败：${res.data.errorMsg}`);
          }
        });
      },
      submit(){
        if(!this.currentCardUrl){
          this.$message.error("请先上传名片！");
          return;
        }
        if(this.applySuccess) return;
        this.submitLoading = true;
        let urlParams = getUrlParams();
        let params = {
          source: urlParams.source || 1,
          application: 4,
          visitingCard: this.currentCardUrl
        }
        this.$http.post("user/probation", params).then(res => {
          this.submitLoading = false;
          if (res.code === 20000) {
            // this.$message.success('申请成功');
            this.applySuccess = true;
          } else {
            this.$message.error(`申请失败：${res.data.errorMsg}`);
          }
        });
      },
      uploadCard(){
        if (!this.uploadFileLoading) {
          this.$refs.uploadFileInput.click();
        }
      }
    },
    mounted () {
      
    }
  }
</script>

<style lang="less" scoped>
  .data-apply-container-mobile{
    background-color: #fff;
    position: relative;
    padding-bottom: 1rem;
    .page-header{
      width: 100%;
      height: 6.02rem;
      background: url("../../../assets/images/data-apply/mobile/header-bg.png") no-repeat;
      background-size: 100%;
      background-position: center center;
      padding-top: 1.31rem;
      .logo-container{
        width: 1.73rem;
        height: 1.73rem;
        background: url("../../../assets/images/data-apply/mobile/logo.png") no-repeat;
        background-size: 100%;
        background-position: center center;
        margin: 0 auto;
      }
      .logo-text{
        text-align: center;
        color: #FFD296;
        margin-top: .4rem;
        font-size: .35rem;
      }
    }
    .page-content{
      width: 9.06rem;
      margin: 0 auto;
      color: #333333;
      position: relative;
      .notice-text{
        font-size: .4rem;
        line-height: .58rem;
      }
      .img-container{
        margin: .6rem auto;
        width: 8.64rem;
        height: 5.76rem;
        position: relative;
        line-height: 5.76rem;
        text-align: center;
        background-color: #f5f5f5;
        img{
          max-width: 100%;
          max-height: 100%;
        }
      }
      .img-placeholder{
        line-height: .4rem;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        .img{
          background: url("../../../assets/images/data-apply/mobile/img-placeholder.png") no-repeat;
          width: 1.37rem;
          height: 1.37rem;
          background-position: center center;
          background-size: 100%;
          margin-bottom: .2rem;
        }
        span{
          text-align: center;
          font-size: .4rem;
          margin-left: -0.15rem;
        }
      }
      .submit-button{
        margin-top: .6rem;
        width: 8.64rem;
        height: 1.44rem;
        background:linear-gradient(-90deg,rgba(174,143,99,1) 0%,rgba(227,203,169,1) 100%);
        border-radius:.72rem;
        color: #333;
        text-align: center;
        font-size: .52rem;
        line-height: 1.44rem;
      }
    }
    .page-footer{
      width: 9.06rem;
      margin: .68rem auto 0 auto;
      color: #333;
      font-size: .4rem;
      line-height: .58rem;
    }

    .submit-success{
      height: 5.76rem;
      width: 100%;
      position: absolute;
      top: 2.16rem;
      left: 0;
      background-color: rgba(245, 245, 245, 0.85);
      z-index: 3;
      .success-icon{
        height: 1.9rem;
        width: 1.5rem;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        .icon{
          width: 1.5rem;
          height: 1.5rem;
          background: url("../../../assets/images/data-apply/mobile/success.png") no-repeat;
          background-position: center center;
          background-size: 100%;
        }
        .text{
          font-size: .35rem;
          line-height: .35rem;
          text-align: center;
          margin-top: .2rem;
        }
      }
    }
  }
</style>



