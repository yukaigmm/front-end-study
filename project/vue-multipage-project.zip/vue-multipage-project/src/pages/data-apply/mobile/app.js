
import App from './app.vue'

// import { setOptionsMap, userInfoValidate } from '../../common/js/utils'; 

import '../../../common/js/common';
import '../../../common/js/comp';

//引入单独的样式文件
import '../../../common/css/apply.less';

//引入rem适配
import '../../../common/js/font-size'

const createApp = () => {
  new Vue({
    el: '#app',
    render: h => h(App)
  })
}


// setOptionsMap().then( () => {
  createApp()
// })



