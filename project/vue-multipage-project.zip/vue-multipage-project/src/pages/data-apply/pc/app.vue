<template>
  <div class="data-apply-container" ref="applyContainer">
    <div class="page-header">
      <div class="logo-container"></div>
    </div>
    <div class="page-content">
      <vloading v-model="submitLoading"></vloading>
      <vpart title="数据展示与反馈">
        <div class="main-container">
          <div class="notice-text">
            如果您希望您公司或者基金的数据在排排网网站或APP展示，只需上传名片，排排网工作人员会第一时间联系您。
          </div>
          <div class="form-container">
            <div class="upload-notice">
              <vbutton @click="uploadCard">上传名片</vbutton>
              <span class="upload-notice-text">{{imageNotice || "图片格式：jpg、jpeg、gif、png、bmp，文件尺寸小于2M。"}}</span>
            </div>
            <div class="img-upload-wrapper">
              <vloading v-model="uploadFileLoading"></vloading>
              <div class="img-upload" @click="uploadCard" :style="imgStyle">
                <img class="bussiness-card" :src="cardUrl" alt="" v-show="currentCardUrl" :class="{'zero-opacity': applySuccess}">
                <span class="img-placeholder" v-show="!currentCardUrl" :class="{'zero-opacity': applySuccess}"></span>
              </div>
            </div>
            <form ref="uploadFileForm" style="display: none">
              <input
                type="file"
                accept="image/*"
                name="visitingCard"
                ref="uploadFileInput"
                @change="uploadFileInputChange"
              >
            </form>
          </div>
          <div class="success-notice" v-if="applySuccess">
            <span class="success-img"></span>
            <span class="success-text">提交成功</span>
          </div>
          <div class="submit-button">
            <vbutton active @click="submit">确定</vbutton>
          </div>
          <div class="attach-info">
            <p>
              如果您发现排排网的数据不正确，或对排排网数据有疑问，请联系排排网数据中心反馈。
            </p>
            <p>
              客服手机/微信：181-2206-2906
            </p>
          </div>
        </div>
      </vpart>
    </div>
  </div>
</template>

<script>
  import {getUrlParams} from "../../../common/js/utils.js";
  export default {
    data () {
      return {
        currentCardUrl: null,
        uploadFileLoading: false,
        submitLoading: false,
        imageNotice: "",
        applySuccess: false,
        // imgFormat: ["image/jpeg", "image/jpg", "image/gif", "image/png", "image/bmp"]
      }
    },
    computed: {
      cardUrl(){
        if(this.currentCardUrl){
          return `${this.$baseUrl[process.env.NODE_ENV]["staticFile"]}/${this.currentCardUrl}`
        }
        return null;
      }
    },
    methods: {
        uploadFileInputChange(e) {
          let files = event.target.files || window.event.target;
          let file = files[0] || {};
          if(file.type.indexOf("image/") == -1){
            this.$message.error("图片格式有误，请重新上传!");
            this.currentCardUrl = "";
            return this.imageNotice = "图片格式有误，请重新上传！"
          }
          this.imageNotice = "";
          let form = this.$refs.uploadFileForm;
          let formData = new FormData(form);
          this.uploadFileLoading = true;
          this.$http.post("file/visitingCard", formData).then(res => {
            this.uploadFileLoading = false;
            if (res.code === 20000) {
              this.$message.success("上传成功");
              this.currentCardUrl = res.data.filePath;
              this.$refs.uploadFileInput.value = "";
            } else {
              this.$message.error(`上传失败：${res.data.errorMsg}`);
            }
          });
        },
        submit(){
          console.log("submit");
          if(!this.currentCardUrl){
            this.$message.error("请先上传名片！");
            return;
          }
          if(this.applySuccess)return;
          this.submitLoading = true;
          let urlParams = getUrlParams();
          let params = {
            source: urlParams.source || 101,
            application: 4,
            visitingCard: this.currentCardUrl
          }
          this.$http.post("user/probation", params).then(res => {
            this.submitLoading = false;
            if (res.code === 20000) {
              // this.$message.success('申请成功');
              this.applySuccess = true;
            } else {
              this.$message.error(`申请失败：${res.data.errorMsg}`);
            }
          });
        },
        uploadCard(){
          if (!this.uploadFileLoading) {
            this.$refs.uploadFileInput.click();
          }
        }
    },
    mounted () {
    }
  }
</script>

<style lang="less" scoped>
  .data-apply-container{
    height: 100%;
    background-color: #000;
    .page-header{
      height:60px;
      background:linear-gradient(0deg,rgba(17,33,49,1),rgba(34,51,68,1));
      box-shadow:0px 1px 0px 0px rgba(41,146,255,0.25);
      padding-top: 7px;
      padding-left: 42px;
      .logo-container{
        height: 46px;
        width: 165px;
        background: url("../../../assets/images/data-apply/pc/logo.png") no-repeat;
        background-position: center center;
      }
    }
    .page-content{
      padding-left: 5px;
      margin-top: 5px;
      background: #111;
      height: calc(~"100% - 65px");
      position: relative;
      .part-container{
        height: 100%;
        overflow-y: auto;
      }
      .part-content{
        position: relative;
        background-color: #111;
      }
      .main-container{
        // padding-top: 20px;
        position: absolute;
        // bottom: 50%;
        top: 15%;
        left: 50%;
        transform: translate(-50%, 0);
        .notice-text{
          text-align: center;
          font-size: 12px;
          color: #999;
          margin-bottom: 20px;
        }
      }
      .form-container{
        padding: 21px;
        margin: 0 auto;
        width:642px;
        height:448px;
        background:rgba(21,21,21,1);
        border:1px solid #555;
        border-radius:2px;
        .img-upload-wrapper{
          margin-top: 20px;
          position: relative;
          .img-upload{
            width:600px;
            height:360px;
            cursor: pointer;
            border:1px solid rgba(0, 0, 0, 1);
            background-color: #1A1A1A;
            position: relative;
            text-align: center;
            line-height: 360px;
            .bussiness-card{
              max-height: 100%;
              max-width: 100%;
            }
            .img-placeholder{
              width: 32px;
              height: 32px;
              background:url("../../../assets/images/data-apply/pc/img-placeholder.png") no-repeat;
              background-size: 100%;
              background-position: center center;
              position: absolute;
              top: 153px;
              left: 284px;
              &::after{
                content: "上传名片";
                position: absolute;
                bottom: -23px;
                left: -9px;
                width: 48px;
                line-height: 1.5;
                font-size: 12px;
                color: #999;
              }
            }
          }
        }
        .upload-notice-text{
          color: #f45;
          
        }
      }
      .submit-button{
        text-align: center;
        margin: 20px 0 ;
      }
      .attach-info{
        text-align: center;
        color: #999;
      }
      .success-notice{
        position: absolute;
        top: 36px;
        left: 0;
        width: 642px;
        height: 448px;
        background-color: rgba(255, 255, 255, 0.18);
        z-index: 3;
        .success-img{
          display: block;
          background: url("../../../assets/images/data-apply/pc/success.png") no-repeat;
          background-size: 100%;
          width: 26px;
          height: 26px;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
        }
        .success-text{
          position: absolute;
          top: 245px;
          left: 50%;
          transform: translate(-50%, 0);
          font-size: 12px;
        }
      }
    }
    .zero-opacity{
      opacity: 0;
    }
  }
</style>



