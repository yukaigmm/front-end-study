<template>
  <vcommon :menuParentKey="currentMenuParentKey" :hideMenu="true">
    <div slot class="container">
      <iframe class="iframe" :src="iframeSrc"></iframe>
    </div>
  </vcommon>
</template>

<script>
  export default {
    data () {
      return {

      }
    },
    computed: {
      iframeSrc () {
        return `${
          this.$baseUrl[process.env.NODE_ENV]["masterBranches"]
        }/IndicatorDescription/indexExplanation?fm=1`;
      }
    },
    methods: {

    },
    mounted () {

    }
  }
</script>


<style lang="less" scoped>
  .container {
    width: 100%;
    height: 100%;
    background: #222;
    .iframe {
      width: 100%;
      height: 100%;
      border: none;
      outline: none;
      float: left;
    }
  }
</style>
