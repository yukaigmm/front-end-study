<template>
	<vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
		<div slot style="height: 100%;width: 100%;position: relative;">
      <vpart title="研报" style="height: 100%;">
        <div class="iframe-container">
					<iframe v-show="!loading"  class="iframe" ref="iframe" :src="iframeSrc" frameborder="0"></iframe>
					<vloading v-model="loading"></vloading>
				</div>
      </vpart>
    </div>
		
	</vcommon>
</template>

<script>
	import pageView from '../../../common/mixins/pageView';
	export default {
		mixins: [pageView],
		data () {
			return {
				currentMenuParentKey: 'marketResearch',
				currentMenuChildKey: 'researchReport',
				loading: true,
				iframeSrc: '',
				companyId: '',
			}
		},
		methods: {
			getToken () {
				return new Promise( (resolve) =>{
					this.$http.get('token/reports').then ( (res) => {
						resolve(res.data);
					})
				})
			},
			// 提示用户功能不可用并跳转到首页
			noticeError(){
				this.$alert("研报功能授权失败，请重新登录或联系客服", "提示", {
					confirmButtonText: '确定',
					type: "warning",
					callback: action => {
						location.assign(
							this.$baseUrl[process.env.NODE_ENV]["page"] + "/index/index.html"
						);
					}
				});
			},
		},
		mounted () {
			this.getToken().then( (data) =>{
				if(data && data.userId && data.token){
					this.iframeSrc = this.$baseUrl[process.env.NODE_ENV]['researchReport'] + `simuwang/seereport?userId=${data.userId}&token=${data.token}`;
				}else{
					this.noticeError()
				}
			})
			this.$refs.iframe.onload = () => {
				setTimeout( () => {
					this.loading = false;
				}, 300);
			}
		}
	}
</script>

<style lang="less" scoped>
	.iframe-container {
		height: 100%;
		width: 100%;
		background-color: #1a1a1a;
		position: relative;
		overflow: hidden;
		.iframe {
			width: 100%;
			height: 100%;
			html, body {
				margin: 0;
				padding: 0;
			}
		}
	}
	
</style>
