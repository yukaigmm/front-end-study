<template>
	<vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
		<div slot style="height: 100%;width: 100%;position: relative;">
      <vpart title="私募指数" style="height: 100%;">
        <div class="iframe-container">
					<iframe v-show="!loading"  class="iframe" ref="iframe" :src="iframeSrc" frameborder="0"></iframe>
					<vloading v-model="loading"></vloading>
				</div>
      </vpart>
    </div>
		
	</vcommon>
</template>

<script>
	import pageView from '../../../common/mixins/pageView';
	import { refreshMasterToken } from "../../../common/js/utils";
	export default {
		mixins: [pageView],
		data () {
			return {
				currentMenuParentKey: 'marketResearch',
				currentMenuChildKey: 'peIndex',
				loading: true,
				iframeSrc: '',
				companyId: '',
			}
		},
		methods: {
			// 提示用户功能不可用并跳转到首页
			noticeError(){
				this.$alert("私募指数功能授权失败，请重新登录或联系客服", "提示", {
					confirmButtonText: '确定',
					type: "warning",
					callback: action => {
						location.assign(
							this.$baseUrl[process.env.NODE_ENV]["page"] + "/index/index.html"
						);
					}
				});
			},
			initPeIndex(){
				let masterUseable = window.sessionStorage.getItem("masterUseable");
				if(masterUseable === "false"){
					this.noticeError();
					return;
				};
				this.iframeSrc = this.$baseUrl[process.env.NODE_ENV]['master'] + `/private/privateIndex?fm=1`;
				this.$refs.iframe.onload = () => {
					this.loading = false;
				};
			}
		},
		mounted () {
			let masterUseable = window.sessionStorage.getItem("masterUseable");
			if(masterUseable === null || masterUseable === "false"){
				refreshMasterToken().then(() => {
					setTimeout(() => {
						this.initPeIndex();
					}, 100);
				})
			}else{
				this.initPeIndex();
			}
		}
	}
</script>

<style lang="less" scoped>
	.iframe-container {
		height: 100%;
		width: 100%;
		background-color: #1a1a1a;
		position: relative;
		overflow: hidden;
		.iframe {
			width: 100%;
			height: 100%;
			html, body {
				margin: 0;
				padding: 0;
			}
		}
	}
	
</style>
