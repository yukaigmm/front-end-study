<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
    <div slot style="height: 100%;width: 100%;position: relative;">
      <vpart title="基金分析" style="height: 100%;">
        <div slot="search">
            <vselectFilter
              v-if="!noFund"
              v-model="currentFundId"
              :options="collectionFundList"
              labelKey="fundShortName"
              valueKey="fundId"
              @change="selectChange"
            ></vselectFilter>
        </div>
        <div class="iframe-container" v-if="!noFund">
          <iframe v-show="!loading" ref="iframe" slot class="iframe" :src="iframeSrc" frameborder="0"></iframe>
          <vloading v-model="loading"></vloading>
        </div>
        <div v-else class="no-fund-container">
          <div class="no-fund-content">
            <span class="text">您暂无旗下或关注的基金</span>
            <img class="img" src="../../../../src/assets/images/empty-data.png" alt>
          </div>
        </div>
      </vpart>
    </div>
  </vcommon>
</template>

<script>
import pageView from "../../../common/mixins/pageView";
import { getUrlParams,refreshMasterToken } from "../../../common/js/utils";
export default {
  mixins: [pageView],
  data() {
    return {
      currentMenuParentKey: "productAnalysis",
      currentMenuChildKey: "productAnalysis",
      loading: true,
      collectionFundList: [],
      currentFundId: "",
      token: "",
      companyId: "",
      iframeSrc: "",
      noFund: false,
      currentSourceData: 1,
    };
  },
  computed: {
    productAnalysisSrc() {
      let pathParam = this.currentSourceData == 1 ? "Fund" : "index";
        return `${
          this.$baseUrl[process.env.NODE_ENV]["master"]
        }/${pathParam}/${
          this.currentFundId
        }?fm=1&companyId=${this.companyId}`;
    }
  },
  // https://master-test.simuwang.com/Fund/HF00000FJJ?fm=1  基金
  // https://master-test.simuwang.com/index/IN00000011?fm=1 指数
  methods: {
    // 使用组合大师和报告工厂的 iframe 嵌入的页面，由于基金大师用户 companyId 不一定有，因此后台做了一些调整，准备兼容到 orgId ，
    // 因此，这几个页面都做了 orgId 的兼容处理
    getCompanyId() {
      return new Promise(resolve => {
        let currentUserInfo = JSON.parse(
          localStorage.getItem("fund_master_current_user")
        );
        if (currentUserInfo && (currentUserInfo.companyId || currentUserInfo.orgId)) {
          this.companyId = currentUserInfo.companyId || currentUserInfo.orgId;
          resolve();
        } else {
          this.$http.get("user/checkInfo").then(resp => {
            this.companyId = resp.data.companyId || resp.data.orgId;
            resolve();
          });
        }
      });
    },
    getCollectionFundList() {
      return new Promise(resolve => {
        this.$http
          .get("datadis/findCompanyFund")
          .then(resp => {
            this.collectionFundList = resp.data;
            resolve();
          });
      });
    },
    selectChange(val) {
      this.loading = true;
      let currentOption = this.collectionFundList.filter((item) => {
        return item.fundId == val;
      })[0];
      this.currentSourceData = currentOption.sourceData;
      this.iframeSrc = this.productAnalysisSrc;
    },
    // 提示用户分析功能不可用并跳转到首页
    noticeError(){
      this.$alert("分析功能授权失败，请重新登录或联系客服", "提示", {
        confirmButtonText: '确定',
        type: "warning",
        callback: action => {
          location.assign(
            this.$baseUrl[process.env.NODE_ENV]["page"] + "/index/index.html"
          );
        }
      });
    },
    initAnalysis(){
      let masterUseable = window.sessionStorage.getItem("masterUseable");
      if(masterUseable === "false"){
        this.noticeError();
        return;
      }
      this.getCompanyId().then(() => {
        let params = getUrlParams();
        this.currentFundId = params.id;
        this.currentFundShortName = decodeURI(params.name);
        this.currentSourceData = params.sourceData;
        //当有基金id和基金简称传递过来时，默认添加一个选项进行展示，避免select为空的情况。
        if (this.currentFundId && this.currentFundShortName && this.currentSourceData) {
          this.collectionFundList = [
            {
              fundId: this.currentFundId,
              fundShortName: this.currentFundShortName,
              sourceData: this.currentSourceData
            }
          ];
          setTimeout(() => {
            this.iframeSrc = this.productAnalysisSrc;
          }, 0);
        }
        //此处获取全部基金选项
        this.getCollectionFundList().then(() => {
          if (this.collectionFundList.length) {
            //如果没有currentFundId,则需要给一个默认的基金来打开分析页面
            if (!this.currentFundId) {
              this.currentFundId = this.collectionFundList[0]["fundId"];
              this.currentSourceData = this.collectionFundList[0]["sourceData"];
              setTimeout(() => {
                this.iframeSrc = this.productAnalysisSrc;
              }, 0);
            }
          } else {
            this.noFund = true;
          }
        });
      });

      this.$refs.iframe.onload = () => {
        this.loading = false;
      };
    }
  },
  // 
  // 如果 sessionStorage 获取不到 masterUseable， 说明登录的时候缓存的 masterUseable 被清除了，需要重新获取
  mounted() {
    // 判断分析功能是否可用
    let masterUseable = window.sessionStorage.getItem("masterUseable");
    if(masterUseable === null || masterUseable === "false"){
      refreshMasterToken().then(() => {
        setTimeout(() => {
          this.initAnalysis();
        }, 100);
      })
    }else{
      this.initAnalysis();
    }
  }
};
</script>

<style lang="less" scoped>
.iframe-container {
  position: relative;
  width: 100%;
  height: 100%;
  .iframe {
    width: 100%;
    height: 100%;
    // transform-origin: center;
    // transform: scale(0.8);
    html,
    body {
      margin: 0;
      padding: 0;
    }
  }
}
.no-fund-container {
  position: relative;
  width: 100%;
  height: calc(~"100% - 40px");
  .no-fund-content {
    width: auto;
    height: auto;
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    .text {
      display: block;
      line-height: 30px;
      font-size: 12px;
    }
  }
}
.message-bar {
  height: 40px;
  background-color: #333;
  display: flex;
  align-items: center;
  .page-title {
    color: #ffffff;
    height: 14px;
    line-height: 14px;
    border-left: 5px solid #2992ff;
    padding-left: 10px;
    margin-right: 15px;
  }
  .select-wraper {
    display: inline-block;
    width: 220px;
  }
}
</style>
