<template>
  <div class="date-view-container">
    <div class="left-box">
      <span class="version">{{version}}</span>
      <span class="date">{{date}}</span>
    </div>
    <div class="line" :class="{end: end}">
      <span class="date-order">{{order}}</span>
    </div>
    <div class="right-box">
      <div class="content">
        <!-- <span class="title" v-if="!end">更新功能:</span> -->
        <span class="title">更新功能:</span>
        <span class="detail" v-for="(detail, index) in details" :key="index">
          <span class="detail-order">{{index+1 + '. '}}</span>
          <span class="detail-text">{{detail}}</span>
        </span>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      data: {
        type: Object,
        default: () => {
          return {
            time: '',
            version: '',
            details: [],
          }
        }
      },
      order: {
        type: [Number, String],
        default: '',
      },
      end: {
        type: Boolean,
        defalut: false
      }
    },
    data() {
      return {
        
      }
    },
    computed: {
      date () {
        return this.data.date
      },
      version () {
        return this.data.version
      },
      details () {
        return this.data.details;
      }

    },
    methods: {

    }
  }
</script>

<style lang="less" scoped>
  .date-view-container {
    width: 100%;
    position: relative;
    font-size: 15px;
    .left-box {
      float: left;
      width: 85px;
      .version {
        display: block;
        text-align: right;
      }
      .date {
        display: block;
        text-align: right;
      }
    }
    .line {
      display: block;
      width: 2px;
      height: 100%;
      background: #2A95FF;
      position: absolute;
      top: 0;
      left: 100px;
      &.end {
        height: 0;
      }
      .date-order {
        color: #fff;
        border-radius: 50%;
        text-align: center;
        display: block;
        position: absolute;
        top: 0;
        left: 50%;
        transform: translate(-50%, 0);
        width: 22px;
        height: 22px;
        border-radius: 50%;
        background: #2A95FF;
      }

    }
    .right-box {
      padding-left: 140px;
      padding-bottom: 80px;
      width: 100%;
      .content {
        .title {
          font-size: 16px;
          display: block;
          margin-bottom: 10px;
        }
        .detail {
          display: block;
          position: relative;
          .detail-order {
            display: block;
            position: absolute;
            left: 0;
          }
          .detail-text {
            display: inline-block;
            padding-left: 20px;
          }
        }
      }
    }
  }
</style>

