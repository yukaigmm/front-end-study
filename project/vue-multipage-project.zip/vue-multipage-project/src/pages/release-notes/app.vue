<template>
  <vcommon :menuParentKey="currentMenuParentKey" :hideMenu="true">
    <div slot class="container">
      <!-- <span>release notes</span>

      <div v-for="(note, index) in notes" :key="index">
        <div>{{note.time + ' 基金大师' + note.version}}</div>
        <div>
          <div v-for="(content, ind) in note.details" :key="ind">{{(ind+1) + '. ' +content}}</div>
        </div>
      </div>-->
      <template v-for="(yearItem, index) in notes">
        <yearView :data="yearItem" :key="index">
          <div class="tag" v-if="index === 0" slot="tag">
            <span>更新记录</span>
          </div>
          <div slot="body">
            <dateView
              v-for="(dateItem, ind) in yearItem.content"
              :key="ind"
              :data="dateItem"
              :order="ind + 1"
              :end="ind+1==yearItem.content.length"
            ></dateView>
            <!-- <dateView :end="true"></dateView> -->
          </div>
        </yearView>
      </template>
    </div>
  </vcommon>
</template>

<script>
import notes from "./note";
import yearView from "./year-view.vue";
import dateView from "./date-view.vue";

export default {
  components: {
    yearView,
    dateView
  },
  data() {
    return {
      notes: []
    };
  },
  methods: {},
  mounted() {
    this.notes = notes.map(item => {
      return {
        year: item.year,
        content: item.content.reverse()
      };
    });
  }
};
</script>


<style lang="less" scoped>
.container {
  width: 100%;
  min-height: 100%;
  padding: 20px 0 50px 140px;
  background: #222;
}
.tag {
  width: 80px;
  text-align: center;
  background: #223244;
  color: #fff;
  font-size: 15px;
  position: relative;
  &:after {
    content: "";
    display: block;
    border: 8px solid transparent;
    border-right: 10px solid #223244;
    position: absolute;
    left: -18px;
    top: 50%;
    transform: translate(0, -50%);
  }
}
</style>
