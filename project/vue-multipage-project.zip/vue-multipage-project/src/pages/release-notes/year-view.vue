<template>
  <div class="year-view-container">
    <div class="year-view-header">
      <span class="year" @click="toggleBody">{{year}}</span>
      <span class="icon" :class="{open: open, close: !open}" @click="toggleBody"></span>
      <span class="tag">
        <slot name="tag"></slot>
      </span>
    </div>
    <div class="year-view-body" :class="{open: open, close: !open}">
      <slot name="body"></slot>
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      data: {
        type: Object,
        default: () => {
          return {
            year: '',
            content: [],
          }
        }
      }
    },
    data () {
      return {
        open: true,
      }
    },
    computed: {
      year () {
        return this.data.year
      },

    },
    methods: {
      toggleBody () {
        this.open = !this.open;
      }
    },
  }
</script>

<style lang="less" scoped>
  .year-view-container {
    color: #eee;
    font-size: 12px;
    .year-view-header {
      height: 35px;
      position: relative;
      line-height: 35px;
      margin-bottom: 15px;
      font-size: 0;
      .year {
        font-weight: bold;
        font-size: 26px;
        margin: 0 10px 0 0; 
        cursor: pointer;
      }
      .icon {
        border: 8px solid transparent;
        border-left: 12px solid #eee;
        position: absolute;
        top: 50%;
        font-size: 0;
        transform: translate(0, -50%);
        transform-origin: center 25%;
        transition: transform 0.1s linear;
        cursor: pointer;
        &.close {
          transform: rotate(90deg);
        }
      }
      .tag {
        display: inline-block;
        margin-left: 30px;
        height: 100%;
        vertical-align: top;
      }
    }
    .year-view-body {
      transition: height 0.3s linear;
      &.open {
        height: auto;
      }
      &.close {
        height: 0;
        overflow: hidden;
      }
    }
  }
</style>

