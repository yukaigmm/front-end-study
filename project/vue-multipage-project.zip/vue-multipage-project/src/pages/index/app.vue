<template>
  <vcommon :menuParentKey="currentMenuParentKey" @toggleMenu="toggleMenu">
    <div class="index-container-wrapper">
      <div class="layout-loading-container" v-show="layoutLoading">
        <vloading v-model="layoutLoading"></vloading>
      </div>
      <div
        slot
        v-show="!layoutLoading"
        class="container index-total-container"
        :class="{'full-screen': isFullScreen, [fullScreenTarget]: isFullScreen}"
      >
        <banner ref="banner" @setTableHeight="layoutRefresh"></banner>
        <fund-index-table
          ref="fundIndexTable"
          @fullScreen="fullScreen"
        ></fund-index-table>
      </div>
    </div>
    <notice-card style="display: none"></notice-card>
  </vcommon>
</template>
 
<script>
import pageView from "../../common/mixins/pageView";
import fundIndexTable from "./components/fund-index-table/index.vue";
import banner from "./components/banner/index.vue";
import noticeCard from "./components/notice/index.vue";
export default {
  components: {
    fundIndexTable,
    banner,
    noticeCard
  },
  mixins: [pageView],
  data() {
    return {
      currentMenuParentKey: "index",
      fullScreenTarget: "",
      isFullScreen: "",
      layoutLoading: true //第一次获取用户自定义layout时的loading
    };
  },
  methods: {
    fullScreen({ isFullScreen, fullScreenTarget }) {
      this.fullScreenTarget = fullScreenTarget;
      this.isFullScreen = isFullScreen;
      this.$http.put("user/attribute", {
        homeLayout: isFullScreen ? fullScreenTarget : ""
      });
      this.layoutRefresh();
    },
    /*
        如果是开启全屏动作，则只需要把对应的部分refresh，其他部分隐藏
        如果是关闭动作，则需要把所有部分都fefresh.
        需要等待200毫秒 => css transition时间
      */
    layoutRefresh() {
      setTimeout(() => {
          this.$refs.fundIndexTable.refreshLayout();
      }, 250);
    },
    toggleMenu(){
      setTimeout(() => {
        this.$refs.banner.reflow();
      }, 250);
    },
  },
  mounted() {
  },
  created() {
    //获取用户自定义的布局
    this.$http.get("user/attribute").then(res => {
      if (res.code === 20000) {
        this.fullScreenTarget = res.data.homeLayout;
        this.isFullScreen = !!this.fullScreenTarget;
      }
      this.layoutLoading = false;
      //根据用户布局，决定各组件是否请求数据
      this.layoutRefresh();
      if (this.isFullScreen) {
        this.$refs.fundIndexTable.setFullScreen(true);
      }
    });
  }
};
</script>

<style lang="less">
.index-container-wrapper {
  width: 100%;
  height: 100%;
  overflow-y: hidden;
  overflow-x: hidden;
  background-color: #000;
  .layout-loading-container {
    position: relative;
    width: 100%;
    height: 100%;
    background-color: #1a1a1a;
  }
}
.container.index-total-container {
  height: 100%;
  width: 100%;
  .index-banner-container{
    width: 100%;
  }
  .collection-container {
    // height: calc(~"100% - 228px");
    background-color: #1a1a1a;
    position: relative;
    transition: height linear 0.2s, width linear 0.2s;
  }
  .index-banner-container{
    transition: height linear 0.2s, width linear 0.2s;
  }
  .search-container {
    position: relative;
    margin-bottom: 5px;
  }
  
  &.full-screen {
    &.fund-index-table {
      .collection-container {
        height: 100%;
      }
      .index-banner-container{
        height: 0 !important;
        overflow: hidden;
      }
    }
  }
}
</style>
