<template>
    <!-- 风险收益图 -->
    <div class="chart return-risk-chart" ref="returnRiskChart">
      <vpart title="收益风险图" class="chart-container">
        <div slot="search">
        </div>
        <div slot="action">
          
          <vselect :options="returnRiskChartPeriodOptions" v-model="returnRiskChartPeriod" :clearable="false" @change="returnRiskChartPeriodChange"></vselect>
          <i 
            class="iconfont zoom-icon"
            :class="{'icon-quanping1': !fullScreen, 'icon-quxiaoquanping': fullScreen}"
            :title="!fullScreen ? '全屏' : '还原'"
            @click="resize"
          ></i>
        </div>
        <vloading v-model="returnRiskChartLoading" class="loading"></vloading>
        <div class="return-risk-container" style="width: 100%">
            <div ref="returnRiskChartContent" v-show="!returnRiskChartLoading" class="chart-content">
            </div>
        </div>
      </vpart>
    </div>
</template>

<script>
  import HighCharts from "highcharts";
  
  export default {
    data() {
      return {
        firstLoadSuccess: false,
        returnRiskChartDataAll: [],
        returnRiskChartDataCurrent: [],
        returnRiskChartPeriod: "",
        returnRiskChartPeriodOptions: [
          // {
          //   value: 'Last3Months',
          //   label: "近三个月"
          // },
          // {
          //   value: 'LastHalfYear',
          //   label: "最近半年"
          // },
          {
            value: "Last1Year",
            label: "最近一年"
          },
          {
            value: "Last2Years",
            label: "最近两年"
          },
          {
            value: "FromSetup",
            label: "成立以来"
          }
        ],
        returnRiskChartColors: [
          '#88bbee',
          '#88aaff',
          '#ff99ff',
          '#cc33cc',
          '#ffee77',
          '#ffaa00',
          '#aa77ff',
          '#7711ff',
          '#ff8888',
          '#aa4444',
          '#44cccc',
          '#008888',
          '#aaffaa',
          '#11aa11',
          '#bbdd22',
          '#777700',
          '#ee9955',
          '#884400',
          '#ff6644',
          '#aa2200',
          '#ff6699',
          '#bb0044',
          '#bb88bb',
          '#662288',
          '#4466cc',
          '#113399',
          '#aacccc',
          '#557777',
          '#ddcc99',
          '#776644',
        ],
        returnRiskChartLoading: false,
        //存储基金和颜色的对应关系
        fundColorMap: {},
        fullScreen: false,
      };
    },
    methods: {
      // 获取风险收益图数据
      getReturnRiskChartDataAll() {
        let inteval = this.returnRiskChartPeriod;
        // let { start, end } = this.getStartEndDateByInteval(inteval);
        this.returnRiskChartLoading = true;
        return new Promise(resolve => {
          this.$http
            .get("desk/getIncomeRisk", {
              // startDate: start,
              // endDate: end
            })
            .then(resp => {
              this.returnRiskChartDataAll = resp.data instanceof Array ? resp.data : [];
              this.returnRiskChartLoading = false;
              resolve();
            });
        });
      },
      // 单击表格行时，收益风险图显示对应的基金收益风险tooltip
      setCurrentFundOfReturnRiskChart(fundId) {
        let index = _.findIndex(this.returnRiskChartDataCurrent, item => {
          return item.fundId == fundId;
        });
        
        if (this.returnRiskChartInstance && this.returnRiskChartInstance.series.length) {
          this.returnRiskChartInstance.series.forEach((ser, ind) => {
            this.returnRiskChartInstance.series[ind].data[0].setState();
          });
          this.returnRiskChartInstance.tooltip.hide();
          this.returnRiskChartInstance.series[index].data[0].setState("hover");
          //没有点不展示tooltip
          if (
            this.returnRiskChartInstance.series[index].data[0].x ||
            this.returnRiskChartInstance.series[index].data[0].y
          ) {
            this.returnRiskChartInstance.tooltip.refresh([
              this.returnRiskChartInstance.series[index].points[0]
            ]);
          }
        }
      },
      // 绘制风险收益图
      drawReturnRiskChart() {
        return new Promise(resolve => {
          let self = this;
          let currentData = this.returnRiskChartDataAll.filter((item, index) => {
            return item.frequency === this.returnRiskChartPeriod;
          });
          currentData = currentData.length ? currentData[0] : { data: [] };
          this.returnRiskChartDataCurrent = currentData.data;

          let data = this.returnRiskChartDataCurrent.map((item, index) => {
            let id = item.fundId;
            let color = this.returnRiskChartColors[
              index % this.returnRiskChartColors.length
            ];
            this.fundColorMap[id] = color;
            return {
              name: item.fundName ? item.fundName : " ",
              color: color,
              data: [
                {
                  y: item.intervalReturn ? Number(item.intervalReturn) : null,
                  x: item.downsideReturn ? Number(item.downsideReturn) : null,
                  id: id,
                  marker: {
                    symbol: "circle"
                  }
                }
              ]
            };
          });
          let ifShowAxis;
          if (data.length) {
            ifShowAxis = data.some(item => item.data.x);
          } else {
            ifShowAxis = false;
          }

          this.returnRiskChartInstance = HighCharts.chart(
            this.$refs.returnRiskChartContent,
            {
              chart: {
                type: "scatter",
                zoomType: "xy",
                backgroundColor: "#111",
                spacingBottom: 16,
                marginTop: 20,
                marginRight: 50
              },
              title: {
                text: ""
              },
              credits: {
                enabled: false
              },
              xAxis: {
                enabled: ifShowAxis,
                title: {
                  enabled: true,
                  text: "风险",
                  style: {
                    fontFamily: "微软雅黑, Microsoft YaHei",
                    fontSize: "12px",
                    color: "#999"
                  }
                },
                labels: {
                  formatter() {
                    let decimal = (this.value * 100) % 1;
                    return `${
                      decimal === 0
                        ? this.value * 100
                        : parseFloat(HighCharts.numberFormat(this.value * 100))
                    }%`;
                  },
                  style: {
                    fontFamily: "微软雅黑, Microsoft YaHei",
                    fontSize: "12px",
                    color: "#999"
                  }
                },
                tickLength: 3,
                tickWidth: 1,
                startOnTick: true,
                endOnTick: true,
                showLastLabel: true,
                lineColor: "#383838",
                tickColor: "#383838",
                gridLineColor: "rgba(255, 255, 255, 0.1)",
                gridLineDashStyle: "Dash",
                gridLineWidth: 1,
                alternateGridColor: 'rgba(51,51,51,0.1)'
              },
              yAxis: {
                enabled: ifShowAxis,
                title: {
                  text: "收益",
                  style: {
                    fontFamily: "微软雅黑, Microsoft YaHei",
                    fontSize: "12px",
                    color: "#999"
                  }
                },
                labels: {
                  formatter() {
                    let decimal = (this.value * 100) % 1;
                    return `${
                      decimal === 0
                        ? this.value * 100
                        : parseFloat(HighCharts.numberFormat(this.value * 100))
                    }%`;
                  },
                  style: {
                    fontFamily: "微软雅黑, Microsoft YaHei",
                    fontSize: "12px",
                    color: "#999"
                  }
                },
                gridLineColor: "rgba(255, 255, 255, 0.1)",
                gridLineDashStyle: "Dash",
                gridLineWidth: 1,
              },
              legend: {
                enabled: false
              },
              tooltip: {
                valueDecimals: 2,
                hideDelay: 0,
                shared: true,
                followTouchMove: true,
                style: {
                  fontFamily: "微软雅黑, Microsoft YaHei"
                },
                useHTML: true,
                headerFormat: `<b style="display: block;margin-bottom: 5px;">{series.name}</b>`,
                pointFormatter: function() {
                  let formatter = val => {
                    let decimal = (val * 100) % 1;
                    return `${
                      decimal === 0
                        ? val * 100
                        : parseFloat(HighCharts.numberFormat(val * 100))
                    }%`;
                  };

                  let x = this.x;
                  let y = this.y;
                  return `<span style="display: block">
                              <b>风险：</b>
                              ${formatter(x)}
                          </span>
                          <span style="display: block">
                              <b>收益：</b>
                              ${formatter(y)}
                          </span>`;
                }
              },
              plotOptions: {
                scatter: {
                  marker: {
                    radius: 7,
                    states: {
                      hover: {
                        enabled: true,
                        lineColor: "rgb(100,100,100)"
                      }
                    }
                  },
                  states: {
                    hover: {
                      marker: {
                        enabled: false
                      }
                    }
                  }
                }
              },
              series: data
            }
          );
          this.$emit("setFundColorMap", this.fundColorMap);
          resolve();
        });
      },
      returnRiskChartPeriodChange() {
        this.drawReturnRiskChart();
      },
      reflow () {
        this.returnRiskChartInstance.reflow();
      },
      resize () {
        this.fullScreen = this.fullScreen || false;
        this.fullScreen = !this.fullScreen;
        this.$emit('fullScreen', {
          isFullScreen: this.fullScreen,
          fullScreenTarget: 'return-risk-chart'
        })
      },
      refresh () {
        this.reflow();
      },
      refreshLayout () {
        if (this.firstLoadSuccess) {
          this.refresh()
        } else {
          this.firstLoad();
        }
      },
      firstLoad () {
        this.getReturnRiskChartDataAll().then(() => {
          this.drawReturnRiskChart().then(() => {
            //refresh table
            this.$emit("refreshTable");
            this.firstLoadSuccess = true;
          });
        });
        this.returnRiskChartPeriod = this.returnRiskChartPeriodOptions[0].value;
      },
      setFullScreen ( isFullScreen ) {
        this.fullScreen = isFullScreen
      }
    },
    mounted() {
      
    }
  };
</script>

