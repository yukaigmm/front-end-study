import { getSessionOption } from "../../../../common/js/utils.js";
function tableColumns (){
    return [
        // {
        //   key: "color",
        //   title: "",
        //   "render-header": h => {
        //     return h("span", {
        //       class: "color-item",
        //       style: {
        //         display: "inline-block",
        //         width: "10px",
        //         height: "10px",
        //         borderRadius: "50%",
        //         backgroundColor: "#000"
        //       }
        //     });
        //   },
        //   width: 32,
        //   align: "center",
        //   showOverflowTooltip: false,
        //   render: (h, { row, column, index }) => {
        //     return h("span", {
        //       class: "color-item",
        //       style: {
        //         display: "inline-block",
        //         width: "10px",
        //         height: "10px",
        //         borderRadius: "50%",
        //       }
        //     });
        //   }
        // },
        {
          key: "fundShortName",
          title: "基金简称",
          minWidth: 100,
          render: (h, { row, column, index }) => {
            let fundName = null;
            // 10-创业投资基金、11-股权投资基金， 组合大师现在看不到，不支持分析
            if (row.fundType !== 10 && row.fundType !== 11 ) {
              fundName = h(
                "a",
                {
                  class: "table-cell-link",
                  on: {
                    click: e => {
                      e.stopPropagation();
                      e.preventDefault();
                      this.analysisView(row.fundId, row.fundShortName, row.sourceData);
                    }
                  }
                },
                `${row.fundShortName}`
              );
            } else {
              fundName = h(
                "span",
                {
                  class: "table-cell-normal",
                  style: {
                    cursor: "pointer"
                  },
                  on: {
                    click: e => {
                      if (this.currentTablecell === e.target) {
                        this.showPopover = !this.showPopover;
                      } else {
                        this.showPopover = true;
                      }
                      this.currentTablecell = e.target;
                      if (row.fundType === 10 || row.fundType === 11) {
                        this.popoverText = "该类型的基金暂不支持分析";
                      } else {
                        this.popoverText =
                          row.sourceData == 1
                            ? "基金数据未公开"
                            : "暂不支持指数分析";
                      }
                      this.popoverLeft = e.clientX - 290;
                      this.popoverTop = e.clientY - 60 - $(".carousel-container").height();
                    }
                  }
                },
                `${row.fundShortName}`
              );
            }
            return h('div', {}, [
              h("span", {
                class: "color-item",
                style: {
                  display: "inline-block",
                  width: "10px",
                  height: "10px",
                  marginRight: '5px',
                }
              }),
              fundName
            ])
          }
        },
        {
          key: "fundType",
          title: "基金类型",
          width: 95,
          render: (h, { row }) => {
           let map = {
              1: {
                "1": "信托计划",
                "2": "有限合伙",
                "3": "券商资管",
                "4": "公募专户",
                "5": "单账户",
                "6": "证券投资基金",
                "7": "海外基金",
                "8": "期货资管",
                "9": "保险资管",
                "10": "创业投资基金",
                "11": "股权投资基金",
                "12": "银行理财",
                "13": "类固收信托",
                "-1": "其他投资基金"
              },
              2: {
                "1": "股票型",
                "2": "混合型",
                "3": "债券型",
                "4": "货币型",
                "5": "商品型",
                "6": "市场中性型",
                "7": "FOF",
                "8": "海外型",
              }
            }
            // 先判断是公募还是私募，公募的raiseType 为 2，取 map 中的 2；
            // fundType 私募基金类型
            // pubFundType 公募基金类型
            let fundTypeMap = row.raiseType ? map[row.raiseType] : {};
            if (row.sourceData == 2) {
              return "指数";
            } else if (row.raiseType == 1) {
              return fundTypeMap[row.fundType]
            } else if (row.raiseType == 2){
              return fundTypeMap[row.pubFundType]
            }else {
              return "--";
            }
          }
        },
        {
          key: "fundStrategy",
          title: "基金策略",
          width: 80,
          render: (h, { row }) => {
            let map = getSessionOption("cFinancialStrategy");
            for (let item of map) {
              if (item.param == row.strategy) {
                return item.name;
              }
            }
            return "--";
          }
        },
        {
          title: "最新净值",
          align: "center",
          key: "netvalue",
          childrens: [
            {
              key: "priceDate",
              title: "日期",
              width: 90,
              align: "right",
              render: (h, { row }) => {
                return row.priceDate || "--";
              }
            },
            {
              key: "nav",
              title: "净值",
              width: 60,
              align: "right",
              render: (h, { row }) => {
                let nav = row.nav ? Number(row.nav) : "";
                return nav ? nav.toFixed(4) : "--";
              }
            }
          ]
        },
        {
          title: "收益",
          align: "center",
          renderHeader: h => {
            return h("span", [
              h(
                "span",
                {
                  style: {
                    marginRight: "5px"
                  }
                },
                "收益"
              ),
              h("vtooltip", {
                props: {
                  explains: `收益截止日期:${this.endDate}`,
                  showIndex: false
                }
              })
            ]);
          },
          childrens: this.retChildrenConfigArray.map(({title, key}) => {
            return {
              key: key,
              title: title,
              // sortKey: "ret_one_month",
              sortable: true,
              width: 70,
              align: "right",
              render(h, { row }) {
                return h(
                  "div",
                  {
                    style: {
                      color: `${
                        parseFloat(row[key]) > 0
                          ? "#f45"
                          : parseFloat(row[key]) < 0
                          ? "#009819"
                          : ""
                      }`
                    }
                  },
                  row[key] ? (parseFloat(row[key]) * 100).toFixed(2) + "%" : "--"
                );
              },
              renderHeader: h => {
                return h(
                  "span",
                  {
                    class: {
                      "text-span": true
                    }
                  },
                  title
                );
              }
            }
          })
        },
        {
          title: "相对排名",
          align: "center",
          renderHeader: h => {
            return h("span", [
              h(
                "span",
                {
                  style: {
                    marginRight: "5px"
                  }
                },
                "相对排名"
              ),
              h("vtooltip", {
                props: {
                  explains: [
                    `排名截止日期:${this.endDate}`,
                    "相对排名是基金收益在同策略基金中的百分位排名"
                  ]
                }
              })
            ]);
          },
          // childrens: children
         childrens: this.rankChildrenConfigArray.map(({key, title}) => {
            return {
              key: key,
              title: title,
              sortKey: key,
              sortable: true,
              width: 70,
              align: "right",
              renderHeader: h => {
                return h(
                  "span",
                  {
                    class: {
                      "text-span": true
                    }
                  },
                  title
                );
              },
              render: (h, { row }) => {
                return h(
                  "div",
                  {},
                  row[key] ? row[key] : "--"
                );
              }
            }
          })
        },
        {
          key: "fundClickRatio",
          title: "访问热度",
          width: 78,
          sortKey: "fund_click_ratio",
          sortable: true,
          render(h, { row, column, index }) {
            let colorMap = [
              "rgba(250, 200, 41, 1)",
              "rgba(255, 150, 41, 1)",
              "rgba(255, 100 ,41, 1)",
              "rgba(255, 50, 41, 1)"
              // "rgba(255, 0, 41, 1)"
            ];
            return h(
              "div",
              {
                style: {
                  lineHeight: 1,
                  height: "18px",
                  border: "1px solid #aaa",
                  position: "relative",
                  borderRadius: "3px",
                  width: "52px",
                  margin: "0 auto"
                },
                class: {
                  "click-ratio-battery": true
                }
              },
              colorMap.map((value, index) => {
                return h("span", {
                  style: {
                    display: "inline-block",
                    // float: 'left',
                    height: "14px",
                    width: "10px",
                    background:
                      row.fundClickRatio > index ? value : "transparent",
                    border:
                      row.fundClickRatio > index
                        ? `1px solid ${value}`
                        : "1px dashed rgba(255,255,255,.2)",
                    // background: value,
                    // border: `1px solid ${value}`,
                    borderRadius: "2px",
                    margin: "1px 2px 2px 0px",
                    marginLeft: index === 0 ? "2px" : "0"
                  }
                });
              })
            );
          },
          renderHeader: h => {
            return h(
              "span",
              {
                class: {
                  "text-span": true
                }
              },
              "访问热度"
            );
          }
        },
        {
          key: "action",
          title: "操作",
          width: 96,
          // fixed: "right",
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h(
              "div",
              {
                class: 'table-action-button-container'
              },
              [
                //编辑
                h("vbuttonSprite", {
                  props: {
                    disabled: row.collectionType !== 3,
                    pos: {
                      normal: {
                        x: 0,
                        y: -19
                      },
                      hover: {
                        x: -18,
                        y: -19
                      },
                      disabled: {
                        x: -36,
                        y: -19
                      }
                    },
                    title: "编辑"
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      this.modifyFund(index, row);
                    }
                  }
                }),
                //导出pdf
                h("vbuttonSprite", {
                  props: {
                    pos: {
                      normal: {
                        x: 0,
                        y: -187
                      },
                      hover: {
                        x: -18,
                        y: -187
                      },
                      disabled: {
                        x: -36,
                        y: -187
                      }
                    },
                    // disabled: row.isVisible !== 1,
                    title: "导出pdf"
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      this.exportPdf(row.fundId, row.fundShortName);
                    }
                  }
                }),
              ]
            );
          }
        }
      ];
}
export default tableColumns;