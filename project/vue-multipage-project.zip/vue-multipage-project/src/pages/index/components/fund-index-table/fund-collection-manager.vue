<template>
    <vmodal ref="addFundModal" class="add-fund-modal t2-el-dialog" :title="`管理收藏夹`" @close="close" :width="1050">
        <vtab :tabs="tabs" @clickTab="clickTab" :titleExplain="titleExplain" ref="fundConfigTab">
          <div slot="otherFundCollection" style="height: 100%">
            <other-fund ref="otherFund" @getChoseIdArr="getChoseIdArr"></other-fund>
          </div>
          <div slot="selfFundCollection" style="height: 100%">
            <self-fund ref="selfFund" @getHiddenFundIdArr="getHiddenFundIdArr"></self-fund>
          </div>
        </vtab>

        <div slot="modal-footer">
            <!-- <a class="waves-effect waves-light btn" @click="close">取消</a>
            <a class="waves-effect waves-light btn highlight" @click="addFund">确定</a> -->
            <vbutton @click="close">取消</vbutton>
            <vbutton active @click="addFund">确定</vbutton>
        </div>
    </vmodal>
</template>
<script>
import otherFund from './other-fund.vue';
import selfFund from './self-fund.vue';
export default {
  props: {},
  components:{
    otherFund,
    selfFund
  },
  data() {
    return {
      hiddenFundIdArr:[],
      choseIdArr:[],
      loading: false,
      collectionEmptyData:'暂无收藏的基金和指数',
      emptyData: "请输入关键字进行查询",
      selfEmptyData:'暂无基金信息',
      titleExplain:['左侧为排排网收录的基金和指数','根据条件搜索，选择左侧基金，','添加到右侧并点击确定按钮，即可','收藏基金和指数'],
      tabs:[
        {
          label:'第三方基金',
          key:'otherFundCollection',
          titleExplain:['左侧为排排网收录的基金和指数','根据条件搜索，选择左侧基金，','添加到右侧并点击确定按钮，即可','收藏基金和指数'],
          width: 100,
        },
        {
          label:'我的基金',
          key:'selfFundCollection',
          titleExplain:['点击最后一列的图标，即可控制','基金在首页列表中是否显示', '修改后点击确定即可生效'],
          width: 100,
        }
      ],
      
      selfFundFormValue:{
        isHide:0,
        keyWord:'',
        strategy:''
      },
    };
  },
  computed:{
    
  },
  methods: {
    // modal开关,
    // 打开modal时，获取收藏的第三方基金和指数，以及自己基金的基金列表和隐藏基金列表
    init() {
      this.$refs.addFundModal.open();
      this.$nextTick( () => {
        this.$refs.otherFund.searchFund();
        this.$refs.otherFund.getCollectFundList();
        this.$refs.selfFund.getHideFund().then(res=>{
          this.$refs.selfFund.searchSelfFund();
        })
      })
    },
    // 关闭modal时重置搜索表单和表格数据
    close() {
      this.$refs.otherFund.reset();
      this.$refs.selfFund.reset();
      this.$refs.addFundModal.close();
      this.$refs.fundConfigTab.select('otherFundCollection')
    },
    // 获取公司隐藏基金的数组
    getHiddenFundIdArr(val){
      this.hiddenFundIdArr = JSON.parse(JSON.stringify(val));
    },
    // 获取收藏基金和指数的数组
    getChoseIdArr(val){
      this.choseIdArr = JSON.parse(JSON.stringify(val))
    },
    // 获取提交的数据
    getSubmitCollection(){
      let fundToAdd = [];
      for(let item of this.choseIdArr){
        fundToAdd.push({
          fundId:item.fundId,
          sourceData:item.sourceData
        })
      };
      return {
        hide:{
          fundIds:this.hiddenFundIdArr,
          // isHide:1
        },
        collection:{
          fundIds:fundToAdd
        }
      };
    },

    // 点击确定按钮
    addFund() {
      let setParams = this.getSubmitCollection();
      if(!(window.sessionStorage.getItem('canSend') === 'false')){
        this.$refs.otherFund.loadingOn();
        this.$refs.selfFund.loadingOn();
      }
      this.$http.post('desk/mastFundStatus',setParams).then(res=>{
        if(!res)return;
        if(res.code === 20000){
          this.$message({
             showClose: true,
             message: "修改成功",
             type: "success"
           });
           this.$emit("refreshFundList");
           this.$emit("refreshCollectionFund");
           this.$emit("clearSort");
           this.close()
        }else{
          this.$message({
             showClose: true,
             message: res.msg,
             type: "error"
           });
        }
      }).done(()=>{
        this.$refs.otherFund.loadingOff();
        this.$refs.selfFund.loadingOff();
      })
    },
    // tab切换的回调
    clickTab(tabKey){
    },
    // 动态设置表格高度
    setChoseTabelHeight(){
      this.choseMaxHeight = $(".add-fund-modal .content").height() - 100;
      window.addEventListener("resize", () => {
        this.choseMaxHeight = $(".add-fund-modal .content").height() - 100;
      });
    },
  },
  mounted() {
  },
  watch: {
  }
};
</script>

<style lang="less">
  .add-fund-modal{
    .select-container{
      margin-left: 5px;
      display: inline-block;
      width: 70px;
    }
    .add-table-container,.selected-table-container,.add-delete-buttons{
      float: left;
    }
    // 选择基金指数的table
    .add-table-container{
      width: 60%;
      position: relative;
      .fund-table-wrapper{
        .overflow-scroll{
          height:100%;
          .el-table--enable-row-hover{
            height: 100%;
          }
        }
      }
    }
    // 删除和添加按钮
    .add-delete-buttons{
      width: 9%;
      padding: 230px 0 0 7px;
    }
    // 已选基金和指数的table
    .selected-table-container{
      width: 30%;
      position: relative;
      .fund-table-wrapper{
        .overflow-scroll{
          height:100%;
          .el-table--enable-row-hover{
            height: 100%;
          }
        }
      }
    }
    .fund-table-wrapper{
    height: calc(~"100% - 50px");
      border: 1px solid #333;
    }
    
    .self-table-container{
      position: relative;
    }
  }
</style>
