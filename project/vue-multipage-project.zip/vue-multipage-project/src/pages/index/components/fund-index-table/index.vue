<template>
  <div class="collection-container">
		<vpart title="收藏基金和指数" class="table-container fund-index" style="height: 100%;">
			<div slot="search">
				<vselect
					v-model="fundRequestCondition.fundStatus"
					:options="fundStatusOptions"
					@change="searchFund"
				></vselect>
				<vselect
					v-model="fundRequestCondition.strategy"
					:options="strategyOptions"
					@change="searchFund"
				></vselect>
				<vinput
          type="text"
          class="table-search-input"
          style="display: inline-block"
          @keyup.enter.native="searchFund"
          v-model.trim="fundRequestCondition.keyWord"
          placeholder="关键字搜索(基金ID/全称/简称/管理人)"
        ></vinput>
        <vbutton
          active
          title="搜索"
          @click="searchFund"
        >搜索</vbutton>
				<vswitch
					style="display: inline-block;"
          type="checkbox"
					v-model="fundRequestCondition.isVisible"
					:trueValue="-1"
					:falseValue="1"
					trueLabel="显示不对外展示基金"
					falseLabel=""
					@change="searchFund"
				></vswitch>
				<vtooltip :showIndex="false" explains="选中则会同时显示可见与不可见基金" style="vertical-align: -3px;"></vtooltip>
			</div>
			<div slot="action">
				<vbutton
          active
          title="添加收藏"
          @click="configFund"
        >管理</vbutton>
        <i 
					class="iconfont zoom-icon"
					:class="{'icon-quanping1': !fullScreen, 'icon-quxiaoquanping': fullScreen}"
					:title="!fullScreen ? '全屏' : '还原'"
					@click="resize"
				></i>
			</div>
			<vtable
        class="index-table"
        ref="table"
        :columns="columns"
        :data="tableData"
        :useActionColumn="true"
        :height="tableHeight"
        :width="tableWidth"
        :draggable="true"
        :dragTitleExplains="['拖动该列图标可进行排序', '当无搜索排序或者过滤条件时才可拖动']"
        @sortChange="sortChange"
        @sort="dragSort"
        :reloadMore="reloadMore"
        @reloadMoreData="lazyload"
        :tableLoadingMore="tableLoadingMore"
        :currentRowIndex="currentRowIndex"
        :changeRowColor="true"
        @tableRowClick="tableRowClick"
      ></vtable>
			<vloading v-model="tableLoading" :title="loadingTitle" class="loading"></vloading>
      <vreload v-model="reload" @reload="getFundList"></vreload>
      <div
        v-show="showPopover"
        role="tooltip"
        class="self-popover el-popover el-popper el-popover--plain"
        :style="{left:`${popoverLeft}px`,top:`${popoverTop}px`}"
        tabindex="0"
        x-placement="bottom"
      >
        {{popoverText}}
        <div x-arrow class="popper__arrow" style="left: 40.5px;"></div>
      </div>
		</vpart>
    
    <!-- 添加收藏的modal -->
    <config-fund-modal
      ref="configFundModal"
      @clearSort="clearSort"
      @refreshFundList="refreshFundList"
      @refreshCollectionFund="refreshRiskReturnChart"
    ></config-fund-modal>
    <!-- 修改基金modal-->
    <fundModal ref="fundModal" :status="status" @success="getFundList"></fundModal>
    <iframe src="" frameborder="0" style="display: none"></iframe>
  </div>
</template>

<script>
import { getSessionOption , refreshMasterToken} from "../../../../common/js/utils.js";
import configFundModal from "./fund-collection-manager.vue";
import fundModal from "../../../datadis/fund-infomation/fund-modal.vue";
import tableColumns from "./table-column-config.js"
// import TableColumnConfig from './table-column-config.js'
export default {
  components: {
    configFundModal,
    fundModal
  },
  props: {
    // fundColorMap: {
    //   type: Object
    // }
  },
  data() {
    return {
      firstLoadSuccess: false,
      // 基金表格搜索条件
      fundRequestCondition: {
        pageSize: 20,
        pageNo: 1,
        sortKey: "",
        sortOrder: "",
        keyWord: "",
        fundStatus: 1,
        strategy: 0,
        isHide: 2,
        isVisible: 1
      },
      // 搜索下拉选项
      fundStatusOptions: [
        {
          label: "全部",
          value: 0
        },
        {
          label: "运行中",
          value: 1
        },
        {
          label: "已清算",
          value: 2
        }
      ],
      // 表格参数配置
      loadingTitle: "数据加载中...",
      collectionType: 1,
      tableData: [],
      tableHeight: 300,
      tableWidth: 800,
      currentRowIndex: -1,
      endDate: "",
      tableLoading: false,
      // table的重新加载
      reload: false,
      tableLoadingMore: false,
      // 懒加载的重新加载
      reloadMore: false,
      editable: true,
      isDragging: false,
      delayedDragging: false,
      moreData: false,
      tooltipDisabled: true,
      currentFundId: "",
      rankChildrenConfigArray : [
        {title: "近一月",key: "perrankRetOneMonth"},
        {title: "近三月",key: "perrankRetThreeMonth"},
        {title: "近半年",key: "perrankRetSixMonth"},
        {title: "近一年",key: "perrankRetOneYear"},
      ],
      retChildrenConfigArray: [
        {title: "近一月", key: "retOneMonth"},
        {title: "近三月", key: "retThreeMonth"},
        {title: "近半年", key: "retSixMonth"},
        {title: "近一年", key: "retOneYear"},
      ],
      //存储基金和颜色的对应关系
      recordId: "",
      recordKey: "",
      // popover设置
      popoverLeft: -10000,
      popoverTop: -10000,
      popoverText: "",
      currentTablecell: {},
      showPopover: false,
      fullScreen: false,
    };
  },
  methods: {
    // 获取首页基金列表
    getFundList(keepCurrentRow = false) {
      this.reloadMore = false;
      return new Promise(resolve => {
        this.loadingTitle = "数据加载中...";
        this.tableLoading = true;
        if (!keepCurrentRow){this.currentRowId = ""};
        this.fundRequestCondition.pageSize = this.getPageSize();
        this.$http
          .get("desk/findFundCollection", this.fundRequestCondition)
          .then(res => {
            this.tableLoading = false;
            if (res && res.code === 20000 && res.data) {
              this.endDate = this.handleEndDate(res.data.endDate);
              this.tableData = res.data.records;
              // 返回数据有下一页时才能有懒加载
              if (
                res.data.records instanceof Array &&
                res.data.records.length == this.fundRequestCondition.pageSize
              ) {
                this.fundRequestCondition.pageNo++;
                this.moreData = true;
              }
              resolve();
            } else {
              this.reload = true;
            }
            resolve();
          });
        this.$nextTick(() => {
          this.$refs.table.setCurrentRow("fundId", this.currentRowId);
        });
      });
    },
    //监听收藏夹改动事件
    getCollectionChange() {
      this.$http
        .get("desk/findFundCollection", { pageNo: 1, pageSize: -1 })
        .then(res => {
          let totalData = res.data.records || [];

          //收藏的基金或者指数
          let thirdFunds = totalData.filter(item => {
            return item.collectionType === 1;
          });
          //公司自己的基金
          let selfFunds = totalData.filter(item => {
            return item.collectionType !== 1;
          });

          let thirdFundIds = thirdFunds.map(item => {
            return item.fundId;
          });

          //显示的公司基金
          let showSelfFundIds = selfFunds
            .filter(item => {
              return item.isHide == 2;
            })
            .map(item => {
              return item.fundId;
            });

          sa.event("fundMaster_collection", {
            thirdFundCount: thirdFundIds.length,
            thirdFundArr: thirdFundIds.join(","),
            selfFundTotalCount: selfFunds.length,
            selfFundShowCount: showSelfFundIds.length
          });
        });
    },
    // 处理收益和相对排名的截止日期,是请求返回的endDate的下一个月的5号
    handleEndDate(date) {
      let endDate = new Date((date + "-1").replace(/-/g, "/"));
      let endMonth = endDate.getMonth();
      // 将小于10月的月份前面补上0
      return endMonth === 11
        ? `${endDate.getFullYear() + 1}-01-05`
        : `${endDate.getFullYear()}-${
            endDate.getMonth() + 2 < 10
              ? "0" + (endDate.getMonth() + 2)
              : endDate.getMonth() + 2
          }-05`;
    },
    // 设置表格单元格点击popover
    closePopover() {
      document.body.addEventListener("click", e => {
        if (e.target.className != "table-cell-normal") {
          this.showPopover = false;
        }
      });
    },
    // 拖拽排序
    dragSort(fundArr) {
      this.loadingTitle = "保存排序中...";
      this.tableLoading = true;
      let idArr = [];
      this.fundRequestCondition.pageNo = 1;
      for (let item of fundArr) {
        idArr.push(item.fundId);
      }

      //监听表格拖拽事件
      sa.event("fundMaster_tableDrag", { tableRefer: "首页-收藏夹" });
      this.changeRank({ fundIds: idArr }).then(() => {
        this.tableLoading = false;
        this.$refs.table.refresh();
        setTimeout(() => {
          this.tableScroll();
        }, 100);
      });
    },
    // 拖拽排序请求
    changeRank(params) {
      return new Promise((resolve, reject) => {
        this.$http.put("desk/orderFundCollection", params).then(res => {
          if (res && res.code === 20000) {
            resolve();
          }
        });
      });
    },
    // 点击排序
    sortChange(order, prop) {
      let map = {
        fundClickRatio: "fund_click_ratio",
        // absrankRetOneYear: 'absrank_ret_one_year',
        retOneMonth: "ret_one_month",
        retThreeMonth: "ret_three_month",
        retSixMonth: "ret_six_month",
        retOneYear: "ret_one_year",
        perrankRetOneMonth: "perrank_ret_one_month",
        perrankRetThreeMonth: "perrank_ret_three_month",
        perrankRetSixMonth: "perrank_ret_six_month",
        perrankRetOneYear: "perrank_ret_one_year",
      };
      let nameMap = {
        fundClickRatio: "访问热度",
        // absrankRetOneYear: '',
        retOneMonth: "近一月收益",
        retThreeMonth: "近三月收益",
        retSixMonth: "近半年收益",
        retOneYear: "近一年收益",
        perrankRetOneMonth: "近一月相对排名",
        perrankRetThreeMonth: "近三月相对排名",
        perrankRetSixMonth: "近半年收益",
        perrankRetOneYear: "近一年收益",
      };
      document.querySelector(
        ".table-container.fund-index .el-table__body-wrapper"
      ).scrollTop = 0;
      this.fundRequestCondition.pageNo = 1;
      this.fundRequestCondition.sortKey = map[prop];
      this.fundRequestCondition.sortOrder = order;
      this.getFundList();

      //监听表格排序事件
      sa.event("fundMaster_tableSort", {
        tableRefer: "首页-收藏夹",
        sortKey: nameMap[prop],
        sortOrder: order
      });
    },
    // 清除排序
    clearSort() {
      this.$refs.table.clearSort();
    },
    // 条件搜索基金
    searchFund() {
      return new Promise((resolve, reject) => {
        if (this.tableData.length) {
          document.querySelector(
            ".table-container.fund-index .el-table__body-wrapper"
          ).scrollTop = 0;
        }
        $(".table-container.fund-index .el-table__body-wrapper").off("scroll");
        this.fundRequestCondition.pageNo = 1;
        this.fundRequestCondition.sortKey = "";
        this.fundRequestCondition.sortOrder = "";
        this.$refs.table.clearSort();
        if (
          this.fundRequestCondition.keyWord === "" &&
          +this.fundRequestCondition.fundStatus === 0 &&
          +this.fundRequestCondition.strategy === 0
        ) {
          this.$refs.table.setSortabel();
        } else {
          this.$refs.table.setUnSortable();
        }

        //监听搜索事件
        sa.event("fundMaster_tableSearch", {
          keyword: this.fundRequestCondition.keyWord,
          tableRefer: "首页-收藏夹"
        });

        this.getFundList().then(() => {
          setTimeout(() => {
            this.tableScroll();
            // this.$refs.table.setCurrentRow(this.currentRowIndex);
            resolve();
          }, 100);
        });
      });
    },
    // 刷新表格
    refresh() {
      this.setTableHeight();
      this.$refs.table.refresh();
      setTimeout(() => {
        this.tableScroll();
      }, 100);
    },
    // 设置表格高度
    setTableHeight() {
      window.addEventListener("resize", () => {
        setTimeout(() => {
          this.tableHeight = $(".index-container-wrapper").height()-$(".index-banner-container").height() - 41;
        }, 250);
      });
      this.tableHeight = $(".index-container-wrapper").height()-$(".index-banner-container").height() - 41;
    },
    // 表格懒加载
    tableScroll() {
      $(".table-container.fund-index .el-table__body-wrapper").on(
        "scroll",
        () => {
          this.showPopover = false;
          if (this.moreData) {
            let scrollTop = document.querySelector(
              ".table-container.fund-index .el-table__body-wrapper"
            ).scrollTop;
            let scrollHeight = document.querySelector(
              ".table-container.fund-index .el-table__body-wrapper table.el-table__body"
            ).scrollHeight;
            let containerHeight = document.querySelector(
              ".table-container.fund-index .el-table__body-wrapper"
            ).offsetHeight;
            if (
              scrollTop + containerHeight > scrollHeight - 100 &&
              scrollTop > 0
            ) {
              this.lazyload();
            }
          }
        }
      );
    },
    lazyload(){
      this.reloadMore = false;
      this.tableLoadingMore = true;
      this.moreData = false;
      this.$http
        .get("desk/findFundCollection", this.fundRequestCondition)
        .then(res => {
          if (
            res && res.data.records instanceof Array
          ) {
            this.tableData = this.tableData.concat(res.data.records);
            if (
              res.data.records.length ==
              this.fundRequestCondition.pageSize
            ) {
              this.moreData = true;
              this.fundRequestCondition.pageNo++;
            }
          }else{
            this.reloadMore = true;
            this.moreData = true;
          }
          this.tableLoadingMore = false;
        });
    },
    // 打开修改基金modal
    modifyFund(index, rowData) {
      this.status = "modify";
      if (rowData.draft.draftStatus === 1 && rowData.draft.draftTime) {
        let draftTime = rowData.draft.draftTime.split(" ")[0];
        this.$confirm(
          `该基金信息有一份草稿，保存时间为${draftTime},是否继续编辑草稿?`,
          "草稿",
          {
            showCancelButton: true,
            dangerouslyUseHTMLString: true,
            type: "warning",
            closeOnClickModal: false,
            beforeClose: (action, instance, done) => {
              if (action === "confirm") {
                done();
                this.$refs.fundModal.show(rowData.fundId, true);
              } else {
                done();
                this.$refs.fundModal.show(rowData.fundId);
              }
            }
          }
        );
      } else {
        this.$refs.fundModal.show(rowData.fundId);
      }
      this.fundRequestCondition.pageNo = 1;
      this.fundRequestCondition.sortKey = "";
      this.fundRequestCondition.sortOrder = "";
      document.querySelector(
        ".table-container.fund-index .el-table__body-wrapper"
      ).scrollTop = 0;
    },
    // 关闭添加modal之后刷新表格
    refreshFundList(keepCurrentRow) {
      this.fundRequestCondition.pageNo = 1;
      if (this.tableData.length) {
        document.querySelector(
          ".table-container.fund-index .el-table__body-wrapper"
        ).scrollTop = 0;
      }
      this.getFundList();
      this.getCollectionChange();
    },
    configFund() {
      this.$refs.configFundModal.init();
      //监听管理按钮点击事件
      sa.event("fundMaster_collectionBtnClick", {});
    },
    resize() {
      this.fullScreen = this.fullScreen || false;
      this.fullScreen = !this.fullScreen;
      this.$emit("fullScreen", {
        isFullScreen: this.fullScreen,
        fullScreenTarget: "fund-index-table"
      });
    },
    // 基金分析
    analysisView(id, fundShortName, sourceData) {
      sa.event("fundMaster_analysisEnter", { fundId: id });
      let productAnalysisUrl = `${
        this.$baseUrl[process.env.NODE_ENV]["page"]
      }/analysis/product-analysis/index.html?id=${id}&name=${fundShortName}&sourceData=${sourceData}`;
      location.assign(productAnalysisUrl);
    },
    // 导出pdf
    exportPdf(id,fundName) {
      // 判断分析功能是否可用
      let masterUseable = window.sessionStorage.getItem("masterUseable");
      if(masterUseable === null || masterUseable === "false"){
        refreshMasterToken().then(() => {
          setTimeout(() => {
            this.getPdfReport(id, fundName);
          }, 100);
        })
      }else{
        this.getPdfReport(id, fundName);
      }
    },
    getPdfReport(id, fundName){
      //监听导出pdf事件
      this.tableLoading = true;
      this.$message.warning("正在导出pdf，请稍后");
      sa.event("fundMaster_pdfExport", { fundId: id });
      let currentUserInfo = localStorage.getItem("fund_master_current_user");
      let {companyId, userId} = currentUserInfo ? JSON.parse(currentUserInfo) : {};
      let fileKeyUrl = `${this.$baseUrl[process.env.NODE_ENV]["host"]}/expapi/fm/fundDetial/${userId}/1/${companyId}/${id}/pdf`;
      this.$http.get(fileKeyUrl).then((res) => {
        this.tableLoading = false;
        if(res && res.success && res.fileKey){
          let url = `${this.$baseUrl[process.env.NODE_ENV]["host"]}/expapi/getTmpFile/${userId}/${res.fileKey}/${fundName}/pdf`;
          $("iframe").attr("src", url).appendTo($("body")).css({
            display: "none"
          });
        }else{
          this.$message.error("导出失败，请重试");
        }
      })
    },
    tableRowClick({ row, column, index }) {
      this.currentRowId = row.fundId;
      this.$refs.table.setCurrentRow("fundId", this.currentRowId);
      //设置收益风险图选中当前基金
      this.$emit("setCurrentFundOfReturnRiskChart", this.currentRowId);
    },
    // 刷新table和风险收益图
    refreshRiskReturnChart() {
      this.$emit("refreshRiskReturnChart");
    },
    refreshLayout() {
      if (this.firstLoadSuccess) {
        this.refresh();
      } else {
        this.firstLoad();
      }
    },
    firstLoad() {
      this.setTableHeight();
      setTimeout(() => {
        this.searchFund().then(() => {
          this.firstLoadSuccess = true;
        });
      }, 0);
    },
    setFullScreen(isFullScreen) {
      this.fullScreen = isFullScreen;
    },
    // 根据页面的高度，计算出懒加载的 table 需要加载多少行才能使得 table 滚动，否则固定的 pageSize 导致屏幕较大的用户 table 不能滚动，就无法触发懒加载。
    // 页面中 table 可以缩放,因此以放大时的 table 高度为准
    // 50 表头的高度, pageSize 取计算出来的数值和 20 中的大者.
    getPageSize(){
      let tbodyHeight = $(".index-total-container").innerHeight() - $(".index-total-container .part-header").outerHeight() - 50;
      return Math.max(Math.ceil(tbodyHeight / 35) + 1, 20);
    },
  },
  computed: {
    columns(){
      return tableColumns.call(this);
    },
    strategyOptions() {
      let map = getSessionOption("cFinancialStrategy");
      let strategyOptions = [];
      strategyOptions.push({ label: "全部策略", value: 0 });
      for (let item of map) {
        strategyOptions.push({ label: item.name, value: item.param });
      }
      return strategyOptions;
    }
  },
  watch: {
    isDragging(newValue) {
      if (newValue) {
        this.delayedDragging = true;
        return;
      }
      this.$nextTick(() => {
        this.delayedDragging = false;
      });
    },
    endDate: {
      handler(val) {
        if (val) {
          this.$refs.table.refresh();
        }
      },
      deep: true
    }
  },
  mounted() {
    this.closePopover();
  }
};
</script>

<style lang="less" scoped>
  
</style>

