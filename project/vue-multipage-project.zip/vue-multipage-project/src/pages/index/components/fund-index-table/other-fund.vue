<template>
  <div style="height: 100%">
    <div class="add-table-container table-container" style="height:100%">
      <vpart title="选择基金和指数">
        <div slot="search">
          <vselect v-model="addSearchValue.sourceData" @change="searchFund" :options="options"></vselect>
          <vinput
            type="text"
            style="display: inline-block;"
            @keyup.enter.native="searchFund"
            v-model.trim="addSearchValue.fundName"
            placeholder="关键字搜索(基金ID/全称/简称/管理人)"
          ></vinput>
        </div>
        <div slot="action">
          <vbutton active style="vertical-align: baseline;" title="搜索" @click="searchFund">搜索</vbutton>
        </div>
        <vtable
          class="overflow-scroll"
          :columns="columns"
          :data="tableData"
          :maxHeight="maxHeight"
          :usePagination="true"
          :emptyData="emptyData"
          :totalItem="totalItem"
          :currentPage="page"
          @tableRowClick="tableRowClick"
          @addFund="addFund"
          @pageChange="pageChange"
          @pageSizeChange="pageSizeChange"
          :hidePagination="true"
          :pageSizeConf="pageSizeConf"
          :layout="`prev,pager,next`"
        ></vtable>
        <vloading class="loading" v-model="loading"></vloading>
      </vpart>
    </div>
    <!-- 穿梭框中间的按钮 -->
    <div class="add-delete-buttons">
      <vbutton
        active
        @click="addBatch"
        :disabled="!preChoseIdArr.length"
        style="margin-bottom: 10px;"
      >
        添加
        <span style="font-family:'simsun';margin-left:5px;font-weight:bold">&gt;</span>
      </vbutton>
      <vbutton
        active
        @click="deleteBatch"
        :disabled="!preDeleteIdArr.length"
        style="margin-left:0;"
      >
        <span style="font-family:'simsun';margin-right:5px;font-weight:bold">&lt;</span>删除
      </vbutton>
    </div>
    <!-- 已选的基金和指数 -->
    <div class="selected-table-container table-container" style="height:100%">
      <vpart title="已选基金和指数">
        <!-- :key="selectedTableKey" -->
        <vtable
          class="overflow-scroll collection-fund-index"
          :columns="selectedColumns"
          :data="choseIdArr"
          :maxHeight="choseMaxHeight"
          :useActionColumn="true"
          :emptyData="collectionEmptyData"
          @tableRowClick="chosenTableRowClick"
        ></vtable>
        <vloading v-model="collectionLoading"></vloading>
      </vpart>
    </div>
  </div>
</template>
<script>
export default {
  props: {},
  data() {
    return {
      loading: false,
      collectionLoading: false,
      addSearchValue: {},
      options: [
        {
          label: "全部",
          value: -1
        },
        {
          label: "基金",
          value: 1
        },
        {
          label: "指数",
          value: 2
        }
      ],
      pageSizeConf: [10],
      choseMaxHeight: 400,
      choseIdArr: [],
      preChoseIdArr: [],
      preDeleteIdArr: [],
      overChosen: {
        id: "",
        overChosen: false
      },
      tableData: [],
      totalItem: 10,
      page: 1,
      pageSize: 10,
      collectionEmptyData: "暂无收藏的基金和指数",
      emptyData: "请输入关键字进行查询",
      selfEmptyData: "暂无基金信息",
      recordId: "",
      recordKey: "",
      selfFundFormValue: {
        isHide: 0,
        keyWord: "",
        strategy: ""
      },
      selectedTableKey: ""
    };
  },
  computed: {
    columns() {
      return [
        {
          title: "",
          key: "chosen",
          width: 40,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row }) => {
            let _this = this;
            return h("vswitch", {
              props: {
                type: "checkbox",
                trueLabel: "",
                trueValue: true,
                value: JSON.stringify(this.preChoseIdArr).includes(row.fundId),
                id: row.fundId,
                clearVal: this.overChosen,
                disabled: JSON.stringify(this.choseIdArr).includes(row.fundId)
                // key: row.fundId
              },
              on: {
                click: e => {
                  e.preventDefault();
                },
                change: val => {
                  if (row.sourceData == 1) {
                    // 数组长度超出范围时，提醒用户不再添加
                    if (_this.choseCount > 9 && val === true) {
                      this.overChosen = {
                        id: row.fundId,
                        overChosen: true
                      };
                      return;
                    }
                    this.overChosen = {
                      id: row.fundId,
                      overChosen: false
                    };

                    // checkbox变化时改变已选数组的元素
                    if (val === true) {
                      _this.preChoseIdArr.push({
                        fundId: row.fundId,
                        sourceData: 1,
                        fundShortName: row.fundShortName
                      });
                    } else {
                      _this.preChoseIdArr = _this.preChoseIdArr.filter(item => {
                        return item.fundId !== row.fundId;
                      });
                    }
                  } else {
                    // 类型为指数
                    if (val == true) {
                      _this.preChoseIdArr.push({
                        fundId: row.fundId,
                        sourceData: 2,
                        fundShortName: row.fundShortName
                      });
                    } else {
                      _this.preChoseIdArr = _this.preChoseIdArr.filter(item => {
                        return item.fundId !== row.fundId;
                      });
                    }
                  }
                  this.$nextTick(() => {
                    this.preChoseIdArr = JSON.parse(
                      JSON.stringify(this.preChoseIdArr)
                    );
                  });
                }
              }
            });
          }
        },
        {
          title: "类型",
          key: "sourceData",
          width: 100,
          render(h, { row }) {
            let map = {
              1: "基金",
              2: "指数"
            };
            return map[row.sourceData];
          }
        },
        {
          title: "基金简称",
          key: "fundShortName"
        },
        {
          title: "管理人",
          key: "trustName",
          render: (h, { row }) => {
            if (!row.trustName) {
              return h("div", {}, "--");
            } else {
              return h("div", {}, row.trustName);
            }
          }
        },
        {
          title: "投顾",
          key: "advisorName",
          render: (h, { row }) => {
            if (!row.advisorName) {
              return h("div", {}, "--");
            } else {
              return h("div", {}, row.advisorName);
            }
          }
        },
        {
          title: "收藏",
          key: "action",
          width: 58,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                h("vbuttonSprite", {
                  props: {
                    disabled: JSON.stringify(this.choseIdArr).includes(
                      row.fundId
                    ),
                    pos: {
                      normal: { x: 0, y: -73 },
                      hover: { x: -18, y: -73 },
                      disabled: { x: -36, y: -73 }
                    },
                    title: "收藏"
                  },
                  style: {
                    verticalAlign: "middle"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();
                      this.addSingelFund(row);
                    }
                  }
                })
              ]
            );
          }
        }
      ];
    },
    // 已选基金和指数列表配置
    selectedColumns() {
      return [
        {
          title: "",
          width: 40,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row }) => {
            return h("div", [
              h("vswitch", {
                props: {
                  type: "checkbox",
                  trueLabel: "",
                  trueValue: true,
                  value: this.preDeleteIdArr.includes(row.fundId)
                },
                on: {
                  change: val => {
                    if (val) {
                      this.preDeleteIdArr.push(row.fundId);
                    } else {
                      this.preDeleteIdArr = this.preDeleteIdArr.filter(item => {
                        return item !== row.fundId;
                      });
                    }
                  }
                }
              })
            ]);
          }
        },
        {
          title: "基金简称",
          key: "fundShortName"
        },
        {
          title: "移出",
          width: 58,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row }) => {
            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                h("vbuttonSprite", {
                  props: {
                    pos: {
                      normal: { x: 0, y: -241 },
                      hover: { x: -18, y: -241 },
                      disabled: { x: -36, y: -241 }
                    },
                    title: "移出"
                  },
                  style: {
                    verticalAlign: "middle"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();
                      this.deleteFund(row);
                    }
                  }
                })
              ]
            );
          }
        }
      ];
    },
    choseCount() {
      let count = 0;
      this.choseIdArr.concat(this.preChoseIdArr).forEach(item => {
        if (item.sourceData == 1) {
          count++;
        }
      });
      return count;
    }
  },
  methods: {
    // 根据搜索条件查找基金
    getFundList() {
      this.loading = true;
      let param = Object.assign(
        {},
        { pageNo: this.page, pageSize: this.pageSize },
        this.addSearchValue
      );
      this.$http.get("desk/findNotCompanyCollection", param).then(res => {
        this.emptyData = "暂无数据";
        this.setTableHeight();
        this.totalItem = res.data.total;
        this.tableData = JSON.parse(JSON.stringify(res.data.records));
        this.loading = false;
      });
    },
    // 获取已收藏的基金列表
    getCollectFundList() {
      this.collectionLoading = true;
      return new Promise((resolve, reject) => {
        this.$http.get("desk/myCollection").then(res => {
          for (let item of res.data) {
            this.choseIdArr.push({
              fundId: item.fundId,
              fundShortName: item.fundShortName,
              sourceData: item.sourceData
            });
          }
          this.setChoseTabelHeight();
          this.collectionLoading = false;
          resolve();
        });
      });
    },
    // 点击搜索按钮
    searchFund() {
      setTimeout(() => {
        if (this.addSearchValue.fundName) {
          this.page = 1;
          this.pageSize = 10;
          this.getFundList();
          //监听搜索事件
          sa.event("fundMaster_tableSearch", {
            keyword: this.addSearchValue.fundName,
            tableRefer: "首页-收藏夹-第三方基金"
          });
        } else {
          this.tableData = [];
          this.totalItem = 0;
          this.emptyData = "请输入关键字进行查询";
          this.setTableHeight();
        }
      }, 100);
    },
    // 分页器变化根据搜索条件查找基金
    pageChange(page) {
      this.page = page;
      this.overChosen = true;
      this.getFundList();
    },
    pageSizeChange(size) {
      this.pageSize = size;
      this.page = 1;
      this.getFundList();
    },
    // 基金列表行点击切换选中状态
    tableRowClick({ row, column }) {
      if (column.property === "chosen") {
      } else {
        if (JSON.stringify(this.choseIdArr).includes(row.fundId)) {
          return;
        }
        if (row.sourceData == 2) {
          if (JSON.stringify(this.preChoseIdArr).includes(row.fundId)) {
            this.preChoseIdArr = this.preChoseIdArr.filter(item => {
              return item.fundId !== row.fundId;
            });
          } else {
            this.preChoseIdArr.push({
              fundId: row.fundId,
              sourceData: 2,
              fundShortName: row.fundShortName
            });
          }
        } else {
          if (
            this.choseCount > 9 &&
            !JSON.stringify(this.preChoseIdArr).includes(row.fundId)
          ) {
            this.overChosen = {
              id: row.fundId,
              overChosen: true
            };
            return;
          }
          this.overChosen = {
            id: row.fundId,
            overChosen: false
          };
          if (JSON.stringify(this.preChoseIdArr).includes(row.fundId)) {
            this.preChoseIdArr = this.preChoseIdArr.filter(item => {
              return item.fundId !== row.fundId;
            });
          } else {
            this.preChoseIdArr.push({
              fundId: row.fundId,
              sourceData: 1,
              fundShortName: row.fundShortName
            });
          }
        }
      }
    },
    // 已选基金指数的table行点击
    chosenTableRowClick({ row }) {
      if (JSON.stringify(this.preDeleteIdArr).includes(row.fundId)) {
        this.preDeleteIdArr = this.preDeleteIdArr.filter(item => {
          return item !== row.fundId;
        });
      } else {
        this.preDeleteIdArr.push(row.fundId);
      }

      this.selectedTableKey = Date.now();
    },
    // 批量添加和删除
    addBatch() {
      if (this.preChoseIdArr.length) {
        this.choseIdArr = this.choseIdArr.concat(this.preChoseIdArr);
        this.preChoseIdArr = [];
      }
    },
    deleteBatch() {
      this.choseIdArr = this.choseIdArr.filter(item => {
        return !this.preDeleteIdArr.includes(item.fundId);
      });
      this.preDeleteIdArr = [];
    },
    // 删除单条基金
    deleteFund(row) {
      this.choseIdArr = this.choseIdArr.filter(item => {
        return row.fundId !== item.fundId;
      });
      this.preDeleteIdArr = this.preDeleteIdArr.filter(item => {
        return item.fundId !== row.fundId;
      });
    },
    // 添加单条基金
    addSingelFund(row) {
      if (row.sourceData == 1 && this.choseCount > 9) {
        this.$message.error("最多只能收藏十条基金！");
        return;
      }
      this.choseIdArr.push({
        fundId: row.fundId,
        fundShortName: row.fundShortName,
        sourceData: row.sourceData
      });
      this.preChoseIdArr = this.preChoseIdArr.filter(item => {
        return item.fundId !== row.fundId;
      });
    },
    // 动态设置表格高度
    setChoseTabelHeight() {
      this.choseMaxHeight = $(".add-fund-modal .content").height() - 100;
      window.addEventListener("resize", () => {
        this.choseMaxHeight = $(".add-fund-modal .content").height() - 100;
      });
    },
    setTableHeight() {
      this.maxHeight = $(".add-fund-modal .content").height() - 140;
      window.addEventListener("resize", () => {
        this.maxHeight = $(".add-fund-modal .content").height() - 140;
      });
    },
    // modal关闭时清除搜索条件和表格数据
    reset() {
      this.addSearchValue = {
        sourceData: -1,
        fundName: ""
      };
      this.choseIdArr = [];
      this.preChoseIdArr = [];
      this.preDeleteIdArr = [];
      this.searchFund();
    },
    // 加载动画控制
    loadingOn() {
      this.loading = true;
      this.collectionLoading = true;
    },
    loadingOff() {
      this.loading = false;
      this.collectionLoading = false;
    }
  },
  mounted() {
    this.addSearchValue = {
      sourceData: -1
    };
    this.preChoseIdArr = [];
  },
  watch: {
    choseIdArr: {
      handler(val) {
        this.$emit("getChoseIdArr", val);
      },
      deep: true
    }
  }
};
</script>
