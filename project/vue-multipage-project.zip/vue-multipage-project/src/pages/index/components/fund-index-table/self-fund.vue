<template>
  <!-- 本公司的基金显示隐藏管理 -->
  <div style="height: 100%">
    <vpart title="公司基金信息">
      <div slot="search">
        <vselect
          v-model="selfFundFormValue.isHide"
          :options="fundHideOptions"
          @change="searchSelfFund"
        ></vselect>
        <vselect
          v-model="selfFundFormValue.strategy"
          :options="strategyOptions"
          @change="searchSelfFund"
        ></vselect>
        <vinput type="text" class="table-search-input" style="display: inline-block" @keyup.enter.native="searchSelfFund" v-model="selfFundFormValue.keyWord" placeholder="关键字搜索(基金ID/全称/简称/管理人)"></vinput>
        <vbutton active title="搜索" @click="searchSelfFund">搜索</vbutton>
        <vswitch
					style="display: inline-block;"
          type="checkbox"
					v-model="selfFundFormValue.isVisible"
					:trueValue="-1"
					:falseValue="1"
					trueLabel="显示不对外展示基金"
					falseLabel=""
					@change="searchSelfFund"
				></vswitch>
				<vtooltip :showIndex="false" explains="选中则会同时显示可见与不可见基金" style="vertical-align: -3px;"></vtooltip>

      </div>
      <div slot="action"></div>
      <vloading v-model="selfFundLoading"></vloading>
      <vtable
        :key="selfTableKey"
        ref="selfFundTable"
        :columns="selfFundColumns"
        :data="selfFundTableData"
        :pageSize="selfPageSize"
        :maxHeight="maxHeight"
        :usePagination="true"
        :emptyData="emptyData"
        :totalItem="selfTotalItem"
        :currentPage="selfPage"
        :pageSizeConf="selfPageSizeConf"
        @tableRowClick="selfTableRowClick"
        @pageChange="selfPageChange"
        @pageSizeChange="selfPageSizeChange"
      ></vtable>
    </vpart>
  </div>
</template>


<script>
import { getSessionOption } from "../../../../common/js/utils";
export default {
  data() {
    return {
      selfFundTableData: [],
      selfFundFormValue: {
        isHide: 0,
        strategy: "",
        isVisible: 1
      },
      selfPage: 1,
      selfPageSize: 10,
      selfPageSizeConf: [10, 20, 30, 40],
      maxHeight: 300,
      emptyData: "暂无数据",
      selfTotalItem: 10,
      hiddenFundIdArr: [],
      selfFundLoading: false,
      selfTableKey: "",
      fundHideOptions: [
        {
          label: "全部",
          value: "0"
        },
        {
          label: "隐藏",
          value: "1"
        },
        {
          label: "显示",
          value: "2"
        }
      ]
    };
  },
  computed: {
    // 公司自己的基金列表配置
    selfFundColumns() {
      return [
        {
          title: "基金简称",
          key: "fundShortName"
        },
        {
          title: "基金类型",
          key: "fundType",
          render(h, { row }) {
            let map = getSessionOption("cFundType");
            let val;
            map.forEach(obj => {
              if (obj.param == row.fundType) {
                val = obj.name;
              }
            });
            return val || "--";
          }
        },
        {
          title: "基金策略",
          key: "strategy",
          render(h, { row }) {
            let map = getSessionOption("cFinancialStrategy");
            let val;
            map.forEach(obj => {
              if (obj.param == row.strategy) {
                val = obj.name;
              }
            });
            return val || "--";
          }
        },
        {
          title: "管理人",
          key: "trustName"
        },
        {
          title: "显示状态",
          key: "isHide",
          width: 80,
          render: (h, { row }) => {
            let map = {
              1: "隐藏",
              2: "显示"
            };
            return h(
              "div",
              JSON.stringify(this.hiddenFundIdArr).includes(row.fundId)
                ? "隐藏"
                : "显示"
            );
          }
        },
        {
          title: "是否显示",
          width: 58,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row }) => {
            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                h("vbuttonSprite", {
                  props: {
                    pos: JSON.stringify(this.hiddenFundIdArr).includes(
                      row.fundId
                    )
                      ? {
                          normal: { x: 0, y: -259 },
                          hover: { x: -18, y: -259 },
                          disabled: { x: -36, y: -259 }
                        }
                      : {
                          normal: { x: 0, y: -223 },
                          hover: { x: -18, y: -223 },
                          disabled: { x: -36, y: -223 }
                        },
                    title: JSON.stringify(this.hiddenFundIdArr).includes(
                      row.fundId
                    )
                      ? "显示"
                      : "隐藏"
                  },
                  style: {
                    verticalAlign: "middle"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();
                      this.toggleFundVisibility(row);
                    }
                  }
                })
              ]
            );
          }
        }
      ];
    },
    // 基金策略类型
    strategyOptions() {
      let map = getSessionOption("cFinancialStrategy");
      let strategyOptions = [];
      strategyOptions.push({ label: "全部", value: "" });
      for (let item of map) {
        strategyOptions.push({ label: item.name, value: item.param });
      }
      return strategyOptions;
    }
  },
  methods: {
    // 获取公司自己的基金列表
    getSelfFundList(keepCurrentRow = false) {
      let params = {
        keyWord: this.selfFundFormValue.keyWord,
        strategy: this.selfFundFormValue.strategy,
        isHide: this.selfFundFormValue.isHide,
        isVisible: this.selfFundFormValue.isVisible,
        pageNo: this.selfPage,
        pageSize: this.selfPageSize
      };
      this.selfFundLoading = true;
      this.$http.get("desk/findMyFund", params).then(res => {
        this.selfFundLoading = false;
        this.selfTotalItem = res.data.total;
        this.selfFundTableData = JSON.parse(JSON.stringify(res.data.records));
        this.$refs.selfFundTable.refresh();
        this.setTableHeight();
      });
    },
    // 获取隐藏基金数组
    getHideFund() {
      return new Promise((resolve, reject) => {
        this.$http.get("/desk/myHideFund").then(res => {
          this.hiddenFundIdArr = JSON.parse(JSON.stringify(res.data.fundIds));
          resolve();
        });
      });
    },
    // 根据条件获取公司基金列表
    searchSelfFund() {
      this.selfPage = 1;
      this.selfPageSize = 10;
      this.getSelfFundList();
    },
    // 分页器变化
    selfPageChange(page) {
      this.selfPage = page;
      this.getSelfFundList();
    },
    selfPageSizeChange(size) {
      this.selfPageSize = size;
      this.selfPage = 1;
      this.getSelfFundList();
    },
    // 动态设置表格高度
    setTableHeight() {
      this.maxHeight = $(".add-fund-modal .content").height() - 140;
      window.addEventListener("resize", () => {
        this.maxHeight = $(".add-fund-modal .content").height() - 140;
      });
    },
    // 点击自己的基金表格行
    selfTableRowClick() {},
    // 切换自己投顾的基金是否可见
    toggleFundVisibility(row) {
      if (this.hiddenFundIdArr.includes(row.fundId)) {
        this.hiddenFundIdArr = this.hiddenFundIdArr.filter(item => {
          return item !== row.fundId;
        });
      } else {
        this.hiddenFundIdArr.push(row.fundId);
      }
      this.$emit("getHiddenFundIdArr", this.hiddenFundIdArr);
    },
    // 关闭modal时清除搜索条件和表格数据
    reset() {
      this.selfFundFormValue = {
        keyWord: "",
        isHide: 0,
        strategy: ""
      };
      this.hiddenFundIdArr = [];
    },
    // 加载动画控制
    loadingOn() {
      this.selfFundLoading = true;
    },
    loadingOff() {
      this.selfFundLoading = false;
    }
  }
};
</script>
