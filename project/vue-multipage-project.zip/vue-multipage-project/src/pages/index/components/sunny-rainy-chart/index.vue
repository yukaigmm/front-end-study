<template>
    <!-- 晴雨图 -->
    <div class="chart sunny-rainy-chart" ref="sunnyRainyChart">
      <vpart title="私募市场晴雨图" class="chart-container">
        <div slot="search">
        </div>
        <div slot="action">
          
          <vselect :options="sunnyRainyChartPeriodOptions" v-model="sunnyRainyChartPeriod" @change="sunnyRainyChartPeriodChange" :clearable="false"></vselect>
          <i 
            class="iconfont zoom-icon"
            :class="{'icon-quanping1': !fullScreen, 'icon-quxiaoquanping': fullScreen}"
            :title="!fullScreen ? '全屏' : '还原'"
            @click="resize"
          ></i>
        </div>
        <vloading v-model="sunnyRainyChartLoading" class="loading"></vloading>
        <div class="sunny-rainy-container" style="width: 100%">
            <div class="tip" v-if="!sunnyRainyChartLoading">
                <span class="color-item sunny-rain-bar" v-for="(item, index) in sunnyRainyChartColors" :key="index" :style="`background-color: ${item.color}`">
                    <span v-if="item.min || item.min === 0" class="label">{{getPercentFormat(item.min)}}</span>
                </span>
            </div>
            <div ref="sunnyRainyChartContent" v-show="!sunnyRainyChartLoading" class="chart-content sunny-rain-content" style="position: relative">
            </div> 
        </div>
      </vpart>
    </div>
</template>

<script>
import axios from 'axios';
import _ from 'lodash';
import HighCharts from "highcharts";
export default {
  data() {
    return {
      firstLoadSuccess: false,
      sunnyRainyChartData: [],
      sunnyRainyChartPeriod: "",
      sunnyRainyChartPeriodOptions: [],
      sunnyRainyChartLoading: true,
      initOuterData: [
        {
          y: 2,
          name: "股票策略",
          key: 1,
          color: ""
        },
        {
          y: 1,
          name: "宏观策略",
          key: 2,
          color: ""
        },
        {
          y: 1,
          name: "组合策略",
          key: 7,
          color: ""
        },
        {
          y: 1,
          name: "复合策略",
          key: 8,
          color: ""
        },
        {
          y: 1,
          name: "事件驱动",
          key: 4,
          color: ""
        }
      ],
      initInnerData: [
        {
          y: 1,
          name: "相对价值",
          key: 5,
          color: ""
        },
        {
          y: 1,
          name: "管理期货",
          key: 3,
          color: ""
        },
        {
          y: 1,
          name: "固定收益",
          key: 6,
          color: ""
        }
      ],
      sunnyRainyChartColorsMap: {
        ret_1m: [
          { color: "#EF534E", min: 0.04 },
          { color: "#F48383", min: 0.02, max: 0.04 },
          { color: "#F9A0A0", min: 0, max: 0.02 },
          { color: "#C1F5C1", min: -0.002, max: 0 },
          { color: "#89EB89", min: -0.004, max: -0.002 },
          { color: "#13D713", max: -0.004 }
        ],
        ret_3m: [
          { color: "#EF534E", min: 0.1 },
          { color: "#F48383", min: 0.05, max: 0.1 },
          { color: "#F9A0A0", min: 0, max: 0.05 },
          { color: "#C1F5C1", min: -0.005, max: 0 },
          { color: "#89EB89", min: -0.01, max: -0.005 },
          { color: "#13D713", max: -0.01 }
        ],
        ret_6m: [
          { color: "#EF534E", min: 0.2 },
          { color: "#F48383", min: 0.1, max: 0.2 },
          { color: "#F9A0A0", min: 0, max: 0.1 },
          { color: "#C1F5C1", min: -0.01, max: 0 },
          { color: "#89EB89", min: -0.02, max: -0.01 },
          { color: "#13D713", max: -0.02 }
        ],
        ret_1y: [
          { color: "#EF534E", min: 0.4 },
          { color: "#F48383", min: 0.2, max: 0.4 },
          { color: "#F9A0A0", min: 0, max: 0.2 },
          { color: "#C1F5C1", min: -0.02, max: 0 },
          { color: "#89EB89", min: -0.04, max: -0.02 },
          { color: "#13D713", max: -0.04 }
        ],
        ret_2y: [
          { color: "#EF534E", min: 0.8 },
          { color: "#F48383", min: 0.4, max: 0.8 },
          { color: "#F9A0A0", min: 0, max: 0.4 },
          { color: "#C1F5C1", min: -0.04, max: 0 },
          { color: "#89EB89", min: -0.08, max: -0.04 },
          { color: "#13D713", max: -0.08 }
        ],
        ret_2y_a: [
          { color: "#EF534E", min: 0.8 },
          { color: "#F48383", min: 0.4, max: 0.8 },
          { color: "#F9A0A0", min: 0, max: 0.4 },
          { color: "#C1F5C1", min: -0.04, max: 0 },
          { color: "#89EB89", min: -0.08, max: -0.04 },
          { color: "#13D713", max: -0.08 }
        ],
        ret_3y: [
          { color: "#EF534E", min: 1.2 },
          { color: "#F48383", min: 0.6, max: 1.2 },
          { color: "#F9A0A0", min: 0, max: 0.6 },
          { color: "#C1F5C1", min: -0.06, max: 0 },
          { color: "#89EB89", min: -0.12, max: -0.06 },
          { color: "#13D713", max: -0.12 }
        ],
        ret_3y_a: [
          { color: "#EF534E", min: 1.2 },
          { color: "#F48383", min: 0.6, max: 1.2 },
          { color: "#F9A0A0", min: 0, max: 0.6 },
          { color: "#C1F5C1", min: -0.06, max: 0 },
          { color: "#89EB89", min: -0.12, max: -0.06 },
          { color: "#13D713", max: -0.12 }
        ],
        ret_5y: [
          { color: "#EF534E", min: 2 },
          { color: "#F48383", min: 1, max: 2 },
          { color: "#F9A0A0", min: 0, max: 1 },
          { color: "#C1F5C1", min: -0.1, max: 0 },
          { color: "#89EB89", min: -0.2, max: -0.1 },
          { color: "#13D713", max: -0.2 }
        ],
        ret_5y_a: [
          { color: "#EF534E", min: 2 },
          { color: "#F48383", min: 1, max: 2 },
          { color: "#F9A0A0", min: 0, max: 1 },
          { color: "#C1F5C1", min: -0.1, max: 0 },
          { color: "#89EB89", min: -0.2, max: -0.1 },
          { color: "#13D713", max: -0.2 }
        ],
        ret_10y: [
          { color: "#EF534E", min: 2 },
          { color: "#F48383", min: 1, max: 2 },
          { color: "#F9A0A0", min: 0, max: 1 },
          { color: "#C1F5C1", min: -0.1, max: 0 },
          { color: "#89EB89", min: -0.2, max: -0.1 },
          { color: "#13D713", max: -0.2 }
        ],
        ret_10y_a: [
          { color: "#EF534E", min: 2 },
          { color: "#F48383", min: 1, max: 2 },
          { color: "#F9A0A0", min: 0, max: 1 },
          { color: "#C1F5C1", min: -0.1, max: 0 },
          { color: "#89EB89", min: -0.2, max: -0.1 },
          { color: "#13D713", max: -0.2 }
        ],
        ret_ytd: [
          { color: "#EF534E", min: 0.04 },
          { color: "#F48383", min: 0.02, max: 0.04 },
          { color: "#F9A0A0", min: 0, max: 0.02 },
          { color: "#C1F5C1", min: -0.002, max: 0 },
          { color: "#89EB89", min: -0.004, max: -0.002 },
          { color: "#13D713", max: -0.004 }
        ],
        ret_incep: [
          { color: "#EF534E", min: 0.4 },
          { color: "#F48383", min: 0.2, max: 0.4 },
          { color: "#F9A0A0", min: 0, max: 0.2 },
          { color: "#C1F5C1", min: -0.02, max: 0 },
          { color: "#89EB89", min: -0.04, max: -0.02 },
          { color: "#13D713", max: -0.04 }
        ],
        ret_incep_a: [
          { color: "#EF534E", min: 0.4 },
          { color: "#F48383", min: 0.2, max: 0.4 },
          { color: "#F9A0A0", min: 0, max: 0.2 },
          { color: "#C1F5C1", min: -0.02, max: 0 },
          { color: "#89EB89", min: -0.04, max: -0.02 },
          { color: "#13D713", max: -0.04 }
        ],
      },
      fullScreen: false,
    };
  },
  methods: {
    getSunnyRainScale() {
      let holeWidth = $(".table-info-bar").width();
      let riskWidth = $(".return-risk-chart").width();
      let containerWidth = holeWidth - riskWidth;
      let containerHeight = $(".return-risk-chart").height();
      let containerScale = containerWidth / containerHeight;
      let scaleX = (containerWidth * 0.8) / 1200;
      let scaleY = (containerHeight * 0.8) / 800;
      let scale = scaleX > scaleY ? scaleY : scaleX;
      let pic = document.querySelector(".sunny-rainy-container");
      pic.style.transform = `scale(${scale}) translate(-60%, -50%)`;
      pic.style["transform-origin"] = "left 5%";
    },
    // 获取晴雨图数据 -- 通过二部api获取
    getSunnyRainyChartData() {
      this.sunnyRainyChartLoading = true;
      return new Promise(resolve => {
        // this.$http.get("desk/getQuotation").then(resp => {
        //   this.sunnyRainyChartPeriodOptions = resp.data.map(item => {
        //     return {
        //       value: item.key,
        //       label: item.name
        //     };
        //   });

        //   this.sunnyRainyChartPeriod = this.sunnyRainyChartPeriodOptions[0].value;
        //   this.sunnyRainyChartData = resp.data;
        //   this.sunnyRainyChartLoading = false;
        //   resolve();
        // });
        axios.get(`${this.$baseUrl[process.env.NODE_ENV]['master']}/dataservice/v1/barometer`).then( (resp) => {
          resp = resp.data;
          console.log(resp);
          this.sunnyRainyChartPeriodOptions = resp.data.dataset.map(item => {
            return {
              value: item.key,
              label: item.name
            };
          });

          //去掉多余选项，与组合大师保持一致
          //需要去除的选项数组
          let pullOptionArray = ['ret_2y', 'ret_3y', 'ret_5y', 'ret_10y', 'ret_ytd', 'ret_incep']
          _.pullAllBy(this.sunnyRainyChartPeriodOptions, pullOptionArray.map( value => {return { value }}), 'value')

          this.sunnyRainyChartPeriod = this.sunnyRainyChartPeriodOptions[0].value;
          this.sunnyRainyChartData = resp.data.dataset;
          this.sunnyRainyChartLoading = false;
          resolve();
        })
      });
    },
    // 获取晴雨图颜色map
    getColorOfMap(value) {
      let color = "";
      if (value) {
        value = Number(value);
        color = this.sunnyRainyChartColors.filter(item => {
          let min = item.min || item.min === 0 ? item.min : value;
          let max = item.max || item.max === 0 ? item.max : value + 1;
          return value < max && value >= min;
        })[0].color;
      } else {
        // color = this.sunnyRainyChartColors[
        //   this.sunnyRainyChartColors.length - 1
        // ].color;
        color = '#D8D8D8';
      }
      return color;
    },
    // 绘制晴雨图
    drawSunnyRainyChart() {
      let self = this;
      let currentPeriodData = this.sunnyRainyChartData.filter(item => {
        return item.key === this.sunnyRainyChartPeriod;
      })[0];
      
      let outerData = this.initOuterData.map(item => {
        let value = currentPeriodData.data.filter(data => {
          return `${data.key}` === `${item.key}`;
        })[0].value;
        let color = this.getColorOfMap(value);

        return {
          y: item.y,
          name: item.name,
          color: color,
          value: value
        };
      });
      let innerData = this.initInnerData.map(item => {
        let value = currentPeriodData.data.filter(data => {
          return `${data.key}` === `${item.key}`;
        })[0].value;
        let color = this.getColorOfMap(value);
        return {
          y: item.y,
          name: item.name,
          color: color,
          value: value
        };
      });

      this.sunnyRainyChartInstance = HighCharts.chart(
        this.$refs.sunnyRainyChartContent,
        {
          chart: {
            type: "pie",
            backgroundColor: "#111",
          },
          title: {
            text: ""
          },
          credits: {
            enabled: false
          },
          plotOptions: {
            pie: {
              shadow: false,
              center: ["45%", "50%"],
              startAngle: -60
              // states: {
              //   hover: {
              //     enabled: false
              //   }
              // }
              // enableMouseTracking: false,
            }
          },
          tooltip: {
            backgroundColor: "white",
            useHTML: true,
            hideDelay: 0,
            padding: 0,
            formatter: function() {
              let value =
                this.point && this.point.value
                  ? `${Math.round(this.point.value * 10000) / 100}%`
                  : "--";

              return `
              <span style="display: block;;background-color: white;opacity: 1;padding: 7px;">收益：${value}</span>`;
            },
            shared: true,
            style: {
              fontFamily: "微软雅黑, Microsoft YaHei",
              fontSize: "12px",
              backgroundColor: "white",
              opacity: 1,
              position: "relative",
              zIndex: 1000
            },
            followPointer: true
          },
          series: [
            {
              name: "收益",
              size: "100%",
              innerSize: "50%",
              data: outerData,
              dataLabels: {
                formatter: function() {
                  return `
                  <span style="position: absolute;top: -10px; left: -10px;z-index: 0;">
                    <span style="display: block">${this.point.name.substring(
                      0,
                      2
                    )}</span>
                    <span style="display: block">${this.point.name.substring(
                      2,
                      4
                    )}</span>
                  </span>`;
                },
                style: {
                  fontFamily: "微软雅黑, Microsoft YaHei",
                  color: "black",
                  overflow: "hidden",
                  fontSize: "12px"
                },
                distance: -25,
                useHTML: true
              }
            },
            {
              name: "收益",
              size: "50%",
              data: innerData,
              dataLabels: {
                formatter: function() {
                  return `
                  <span style="position: absolute;top: -10px; left: -10px;z-index: 0;">
                    <span style="display: block">${this.point.name.substring(
                      0,
                      2
                    )}</span>
                    <span style="display: block">${this.point.name.substring(
                      2,
                      4
                    )}</span>
                  </span>`;
                },
                style: {
                  fontFamily: "微软雅黑, Microsoft YaHei",
                  color: "black",
                  overflow: "hidden",
                  fontSize: "12px"
                },
                distance: -28,
                useHTML: true
              }
            }
          ]
        }
      );
    },
    getPercentFormat(value) {
      return `${Math.round(value * 10000) / 100}%`;
    },
    sunnyRainyChartPeriodChange() {
      this.drawSunnyRainyChart();
    },
    reflow() {
      this.sunnyRainyChartInstance.reflow();
    },
    resize() {
      this.fullScreen = this.fullScreen || false;
      this.fullScreen = !this.fullScreen;
      this.$emit("fullScreen", {
        isFullScreen: this.fullScreen,
        fullScreenTarget: "sunny-rainy-chart"
      });
    },
    refresh() {
      this.reflow();
    },
    refreshLayout () {
			if (this.firstLoadSuccess) {
				this.refresh()
			} else {
				this.firstLoad();
			}
		},
		firstLoad () {
			this.getSunnyRainyChartData().then(() => {
        this.drawSunnyRainyChart();
        this.firstLoadSuccess = true;
      });
    },
    setFullScreen ( isFullScreen ) {
			this.fullScreen = isFullScreen
		}
  },
  computed: {
    sunnyRainyChartColors() {
      return this.sunnyRainyChartColorsMap[this.sunnyRainyChartPeriod];
    }
  },
  mounted() {
    
  }
};
</script>

