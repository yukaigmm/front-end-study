<template>
    <div class="index-banner-container" :style="{height: showBanner ? '' : '0 !important' }">
        <div class="carousel-container">
            <ul class="carousel-lists cl" :style="carouselListStyle">
                <li v-for="(item,index) in carouselPics" :key="index" :style="{background: `url(${getImgSrc(item.imageUrl)}) center center/100% 100% no-repeat`, width: carouselContainerWidth+'px'}"   class="carousel-item" @click="jumpToLink(item.bannerLink)"></li>
            </ul>
        </div>
        <div class="click-tools-container">
            <ul class="click-lists">
                <li class="click-item" v-for="(item,ind) in new Array(carouselPics.length)" :key="ind" @click="showCorrespondingPic(ind)" :class="{current:index==ind || (ind==0&&index==carouselPics.length)}"></li>
            </ul>
        </div>
    </div>
</template>
<script>
export default {
    data() {
        return {
            carouselPics: [],
            showBanner: true,
            carouselListLeft: 0,
            index: 0,
            carouselContainerWidth: 0,
        }
    },
    methods: {
        // 初始化轮播图
        initCarousel(){
            this.carouselContainerWidth = $(".content-right").width();
            $(".index-banner-container").height($(".content-right").width() * 285 / 1920);
            this.autoRun();
        },
        
        // 自动轮播
        autoRun(){
            if(this.interValTimer){
                clearInterval(this.interValTimer);
            }
            this.interValTimer = setInterval(() => {
                this.toggleCarousel(1);
                this.getCount();
            }, 4000);
        },
        // 根据调整的步长设置轮播动画，如果轮播切换的步长大于当前轮播长度的 1/2，就用反向切换方式（运行路径短一些）
        toggleCarousel(n, speed=500){
            if(n < this.carouselPics.length / 2){
                this.toggleCarouselLeft(n, speed);
            }else{
                this.toggleCarouselRight(n, speed)
            }
        },
        // 获取当前的轮播图序号
        getCount(){
            this.index++;
            if(this.index == this.carouselPics.length){
                this.index = 0;
            }
        },
        showCorrespondingPic(count){
            if(this.index == count) return;
            if(this.interValTimer){
                clearInterval(this.interValTimer);
            }
            let currentIndex;
            this.carouselPics.forEach((item, index) => {
                if(item.index == count){
                    currentIndex = index;
                }
            });
            this.toggleCarousel(currentIndex);
            this.index = count;
            this.autoRun();
        },
        // 顺序切换轮播图
        toggleCarouselLeft(n,speed){
            $(".carousel-lists").animate({
                left: -n * this.carouselContainerWidth
            }, speed, "linear");
            setTimeout(() => {
                this.carouselPics = this.carouselPics.concat(this.carouselPics.splice(0, n));
                $(".carousel-lists").css({
                    left: 0
                })
            }, speed + 50);
        },
        // 反向切换轮播图
        toggleCarouselRight(n,speed){
            this.carouselPics = this.carouselPics.splice(n, this.carouselPics.length).concat(this.carouselPics);
            $(".carousel-lists").css({
                left: (n-this.carouselPics.length) * this.carouselContainerWidth
            })
            setTimeout(() => {
                $(".carousel-lists").animate({
                   left: 0
               }, speed, "linear");
            }, 1);
        },
        getImgSrc(src){
           return `${
                this.$baseUrl[process.env.NODE_ENV]["staticFile"]
            }${src}`;
        },
        reflow(){
            if(this.showBanner){
                this.initCarousel();
                this.$emit("setTableHeight");
            }
        },
        jumpToLink(link){
            if(link){
                if(link.indexOf("http") == -1){
                    link = "http://" + link;
                }
                window.open(link);
            }
        }
    },
    computed: {
        carouselListStyle(){
            return {
                width: this.carouselContainerWidth * this.carouselPics.length + "px",
            }
        },
    },
    mounted() {
        this.$http.get("desk/banner").then((res) => {
            if(res && res.code === 20000 && res.data.length){
                this.carouselPics = res.data.map((item, index) => {
                    return Object.assign({}, item, {index})
                });
                this.initCarousel();
                window.addEventListener("resize", () => {
                     this.carouselContainerWidth = $(".carousel-container").width();
                     $(".index-banner-container").height($(".content-right").width() * 285 / 1920);
                 });
            }else{
                this.carouselPics = [];
                this.showBanner = false;
            }
        })
    },
}
</script>

<style lang="less" scoped>
.index-banner-container{
    position: relative;
    .carousel-container{
        height: 100%;
        width: 100%;
        position: relative;
        .carousel-lists{
            height: 100%;
            list-style: none;
            position: relative;
            top: 0;
            .carousel-item{
                height: 100%;
                float: left;
                overflow: hidden;
                position: relative;
                cursor: pointer;
                // background-size: 83% 83% !important;
                img{
                    // position: absolute;
                    // top: 50%;
                    // left: 50%;
                    // transform: translate(-50%, -50%) scale(0.9,0.8);
                    // min-width: 125%;
                    // height: 125%;
                    width: 100%;
                }
            }
        }
    }
    .click-tools-container{
        position: absolute;
        left: 50%;
        bottom: 22px;
        transform: translate(-50%, 0);
        .click-lists{
            .click-item{
                width: 10px;
                height: 10px;
                background-color: #fff;
                border-radius: 50%;
                float: left;
                cursor: pointer;
                margin: 0 9px;
                &.current{
                    background-color: #00bbff;
                }
            }
        }
    }
}

</style>