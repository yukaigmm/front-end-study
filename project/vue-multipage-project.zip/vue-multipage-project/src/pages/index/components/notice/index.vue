<template>
    <div class="noctice-container">
        <div
            class="notice-item"
            v-for="item in noticeArray" 
            :key="item.messageId" 
         >
            <component 
            :ref="item.messageId" 
            :is="noticeCompMap[item.triggerType]"
            :noticeInfo="item"
            :key="item.messageId"
            @close="close"
            ></component>
        </div>
    </div>
</template>
<script>
    // 引入需要的模板，使用引入组件的 vnode，实例化成 elementUi 的 notify 组件
    // 多次关闭以后 template 里面的组件会被清掉, 因此使用 component 动态组件,根据接口返回的信息动态渲染需要的组件
    import completeInfo from "./components/complete-info";
    import reply from "./components/reply.vue";
    import authorization from "./components/authorization.vue";
    import signUp from "./components/signUp.vue";
    import normalNotice from "./components/normalNotice.vue";
    export default {
        components: {
            completeInfo,
            reply,
            authorization,
            signUp,
            normalNotice
        },
        data(){
            return {
                notice: null,
                noticeCompMap: {
                    101: "reply",
                    102: "completeInfo",
                    103: "completeInfo",
                    104: "completeInfo",
                    105: "completeInfo",
                    106: "authorization",
                    201: "signUp",
                    202: "normalNotice",
                    301: "completeInfo",
                    302: "authorization"
                },
                noticeArray: [],
                currentMessageIdArr: []
            }
        },
        methods: {
            // 点击关闭的回调
            close(id){
                this.setNoticeRead(id).then((res) => {
                    this.getNoticeInfo(1,this.currentMessageIdArr).then(() => {
                        this.noticeArray = this.noticeArray.filter((item) => {
                            return item.messageId !== id;
                        })
                    })
                });
            },
            // 获取需要显示的通知
            getNoticeInfo(num, ids){
                return new Promise((resolve) => {
                    this.$http.get("notice",{limit: num, removeIds: ids}).then((res) => {
                        if(res && res.code === 20000){
                            if(res.data instanceof Array){
                                let data = JSON.parse(JSON.stringify(res.data));
                                this.noticeArray = this.noticeArray.concat(data);
                                this.currentMessageIdArr = this.noticeArray.map((item) => {
                                    return item.messageId;
                                })
                                resolve();
                                this.$nextTick(() => {
                                    data.forEach((noticeInfo, index) => {
                                        noticeInfo.noticeKeyword = noticeInfo.noticeKeyword || noticeInfo.noticeIndex
                                        if(index !== 0){
                                            setTimeout(() => {
                                                this.getNoticeInstance(noticeInfo);
                                            }, 2500);
                                        }else{
                                            setTimeout(() => {
                                                this.getNoticeInstance(noticeInfo);
                                            }, 1000);
                                        }
                                    })
                                })
                            }
                        }
                    })
                })
            },
            // 根据接口信息和引入组件的 vnode 生成通知
            getNoticeInstance(info){
                let compName = this.noticeCompMap[info.triggerType];
                let vnode = this.$refs[info.messageId][0].$vnode;
                this.$notify({
                    position: 'bottom-right',
                    title: info.noticeName,
                    duration: 10000,
                    dangerouslyUseHTMLString: true,
                    message:vnode,
                    onClose: this.close.bind(this, info.messageId)
                })
            },
            // 设置已读
            setNoticeRead(id){
                return new Promise((resolve,reject) => {
                    this.$http.put("notice/"+id).then((res) => {
                        resolve()
                    })
                })
            }
        },
        mounted() {
            this.getNoticeInfo(2);
        },
    }
</script>

<style lang="less">
    .el-notification{
        // bottom: 10px !important;
        padding: 5px;
        border-radius: 4px;
        border: 1px solid #444;
        background-color: #203142;
        box-shadow: 0 1px 2px 0 rgba(0,0,0,.65), inset 0 1px 0 0 hsla(0,0%,100%,.25);
        color: #999;
        .el-notification__group{
            position: relative;
            margin-left: 0;
            width: 100%;
            // header
            .el-notification__title{
                background-color: #203142;
                border: none;
                padding: 0;
                height: 20px;
                line-height: 20px;
                font-size: 14px;
                color: #eee;
            }
            // 关闭按钮
            .el-notification__closeBtn{
                top: -2px;
                right: -3px;
                width: 28px;
                height: 28px;
                background: url("../../../../assets/images/fof_icon.png") no-repeat;
                background-position: -200px -54px;
                &::before{
                    display: none;
                }
                &:hover{
                    background-position: -200px -26px;
                }
                transform: scale(0.8,0.8)
            }
            .el-notification__content{
                min-height: 112px;
            }
            // body
            .notice-wrapper{
                color: #999;
                border-top-right-radius: 4px;
                border-top-left-radius: 4px;
                background-color: #121c26;
                box-shadow: 0 1px 2px 0 rgba(0,0,0,.65), inset 0 1px 0 0 hsla(0,0%,100%,.25);
                font-size: 14px;
                color: #999;
                height: 100%;
                min-height: 112px;
                .info-content{
                    padding: 10px;
                    height: 100%;
                }
                &.authorization-container{
                    .info-content{
                        height: calc(~"100% - 50px");
                        min-height: 72px;
                    }
                }
                .button-container{
                    text-align: right;
                    line-height: 40px;
                    padding-right: 5px;
                    // position: relative;
                    border-top: 1px solid #000;
                }
            }
        }
    }
</style>

