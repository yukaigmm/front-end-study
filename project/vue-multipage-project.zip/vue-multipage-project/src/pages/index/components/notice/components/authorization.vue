<template>
    <div class="authorization-container notice-wrapper">
        <div class="info-content">{{messageContent}}</div>
        <div class="button-container">
            <vbutton @click="refuse">拒绝</vbutton>
            <vbutton active @click="agree">同意</vbutton>
        </div>
    </div>
</template>

<script>
    export default {
        props: ["noticeInfo"],
        data() {
            return {
                
            }
        },
        methods: {
            // setNoticeRead(id){
            //     return new Promise((resolve,reject) => {
            //         this.$http.put("notice/"+id).then((res) => {
            //             resolve()
            //         })
            //     })
            // },
            agree(){
                this.setAuthorizeStatus(this.noticeInfo.noticeIndex, 2).then(() => {
                    this.$parent.close();
                })
            },
            refuse(){
                this.setAuthorizeStatus(this.noticeInfo.noticeIndex, 4).then(() => {
                    this.$parent.close();
                })
            },
            //设置授权状态
            setAuthorizeStatus(id, status) {
                return new Promise((resolve, reject) => {
                    this.$http
                    .post(`masterAuth/change/${id}`, {
                        authId: id,
                        authStatus: status
                    })
                    .then(res => {
                        if (res && res.code === 20000) {
                            this.$message.success("操作成功");
                            resolve();
                        }else{
                            this.$message.error(res.msg || "设置失败，请重试或联系客服");
                        }
                    });
                });
            },
        },
        computed: {
            messageContent(){
                let data = this.noticeInfo.noticeData;
                let content = this.noticeInfo.noticeInfo;
                for(let key in data){
                    if(data[key] == null){
                        data[key] = "";
                    }
                    content = content.replace(key, data[key]);
                };
                return content;
            }
        },
        authClass(){
            return {
                [`authorization-container-${this.noticeInfo.messageId}`]:true ,
                'notice-wrapper':true
            }
        }
    }
</script>

<style lang="less" scoped>
    .complete-info-container{
        cursor: pointer;
    }
</style>

