<template>
    <div class="complete-info-container notice-wrapper">
        <div class="info-content" @click="jumpToInfoPage">
            {{messageContent}}
        </div>
    </div>
</template>

<script>
    export default {
        props: ["noticeInfo"],
        data() {
            return {
                
            }
        },
        methods: {
            jumpToInfoPage(){
                this.setNoticeRead(this.noticeInfo.messageId).then(() => {
                     location.assign(`${this.$baseUrl[process.env.NODE_ENV]["page"]}${this.noticeInfo.noticeLink}?keyWord=${this.noticeInfo.noticeKeyword}&id=${this.noticeInfo.noticeIndex}`);
                })
            },
            setNoticeRead(id){
                return new Promise((resolve,reject) => {
                    this.$http.put("notice/"+id).then((res) => {
                        resolve()
                    })
                })
            }
        },
        computed: {
            messageContent(){
                let data = this.noticeInfo.noticeData;
                let content = this.noticeInfo.noticeInfo;
                for(let key in data){
                    if(data[key] == null){
                        data[key] = "";
                    }
                    content = content.replace(key, data[key]);
                };
                return content;
            }
        },
    }
</script>

<style lang="less" scoped>
    .complete-info-container{
        .info-content{
            cursor: pointer;
        }
    }
</style>

