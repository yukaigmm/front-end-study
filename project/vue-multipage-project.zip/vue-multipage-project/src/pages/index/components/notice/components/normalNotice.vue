<template>
    <div class="complete-info-container" @click="jumpToInfoPage">
        尊敬的私募基金管理人，为了更好体现贵司的企业文化以及投资理念，也为了让投资者综合了解贵司，请及时更新贵司的公司简介、投资理念、投研团队、基金经理等相关资讯。祝顺商祺！
    </div>
</template>

<script>
    export default {
        data() {
            return {
                
            }
        },
        methods: {
            jumpToInfoPage(){
                location.assign(this.$baseUrl[process.env.NODE_ENV]["page"] + "/datadis/company-infomation/index.html");
            }
        },
    }
</script>

<style lang="less" scoped>
    .complete-info-container{
        cursor: pointer;
    }
</style>

