<template>
  <vmodal
    ref="addFundModal"
    class="add-fund-modal t2-el-dialog"
    :title="`管理收藏夹`"
    @close="close"
    :width="950"
  >
    <!-- <vformConfig class="searchForm" ref="addSearch" v-model="addSearchValue" :config="addSearchFields">
            <div class="search-buttons">
              <vbutton class="highlight iconfont icon-search" title="搜索" @click="searchFund">搜索</vbutton>
            </div>
    </vformConfig>-->
    <vtab :tabs="tabs" @clickTab="clickTab" ref="fundConfigTab">
      <!-- 非本公司管理和投顾的基金和指数管理 -->
      <div slot="otherFundCollection" style="height: 100%">
        <div class="add-table-container table-container" style="height:100%">
          <div class="table-info-bar cl">
            <span class="table-info">选择基金和指数</span>
            <div class="select-container">
              <vselect v-model="addSearchValue.sourceData" @change="searchFund" :options="options"></vselect>
            </div>
            <vinput
              type="text"
              class="table-search-input"
              @keyup.enter.native="searchFund"
              v-model.trim="addSearchValue.fundName"
              placeholder="关键字搜索(基金ID/全称/简称/管理人)"
            ></vinput>
            <vbutton active title="搜索" @click="searchFund">搜索</vbutton>
          </div>
          <div class="fund-table-wrapper">
            <vtable
              class="overflow-scroll"
              :columns="columns"
              :data="tableData"
              :maxHeight="maxHeight"
              :usePagination="true"
              :emptyData="emptyData"
              :totalItem="totalItem"
              :currentPage="page"
              @tableRowClick="tableRowClick"
              @addFund="addFund"
              @pageChange="pageChange"
              @pageSizeChange="pageSizeChange"
              :hidePagination="true"
              :pageSizeConf="pageSizeConf"
              :layout="`prev,pager,next`"
            ></vtable>
          </div>
          <vloading class="loading" v-model="loading"></vloading>
        </div>
        <!-- 穿梭框中间的按钮 -->
        <div class="add-delete-buttons">
          <vbutton active @click="addBatch" :disabled="!preChoseIdArr.length">添加
            <span style="font-family:'simsun';margin-left:5px;font-weight:bold">&gt;</span>
          </vbutton>
          <vbutton active @click="deleteBatch" :disabled="!preDeleteIdArr.length">
            <span style="font-family:'simsun';margin-right:5px;font-weight:bold">&lt;</span>删除
          </vbutton>
        </div>
        <!-- 已选的基金和指数 -->
        <div class="selected-table-container table-container" style="height:100%">
          <div class="table-info-bar cl">
            <span class="table-info">已选基金和指数</span>
          </div>
          <div class="fund-table-wrapper">
            <vtable
              class="overflow-scroll collection-fund-index"
              :key="``"
              :columns="selectedColumns"
              :data="choseIdArr"
              :maxHeight="choseMaxHeight"
              :useActionColumn="true"
              :emptyData="collectionEmptyData"
              @tableRowClick="chosenTableRowClick"
            ></vtable>
          </div>
          <vloading v-model="collectionLoading"></vloading>
        </div>
      </div>
      <!-- 本公司的基金显示隐藏管理 -->
      <div slot="selfFundCollection" style="height: 100%">
        <div class="table-container self-table-container" style="height: 100%">
          <div class="table-info-bar cl">
            <span class="table-info">公司基金信息</span>
            <div class="select-container">
              <vselect
                v-model="selfFundFormValue.isHide"
                :options="fundHideOptions"
                @change="searchSelfFund"
              ></vselect>
            </div>
            <div class="select-container">
              <vselect
                v-model="selfFundFormValue.strategy"
                :options="strategyOptions"
                @change="searchSelfFund"
              ></vselect>
            </div>
            <vinput
              type="text"
              class="table-search-input"
              style="display: inline-block"
              @keyup.enter.native="searchSelfFund"
              v-model="selfFundFormValue.keyWord"
              placeholder="关键字搜索(基金ID/全称/简称/管理人)"
            ></vinput>
            <vbutton active title="搜索" @click="searchSelfFund">搜索</vbutton>
          </div>
          <vloading v-model="selfFundLoading"></vloading>
          <vtable
            :key="selfTableKey"
            ref="selfFundTable"
            :columns="selfFundColumns"
            :data="selfFundTableData"
            :pageSize="selfPageSize"
            :maxHeight="maxHeight"
            :usePagination="true"
            :emptyData="emptyData"
            :totalItem="selfTotalItem"
            :currentPage="selfPage"
            :pageSizeConf="selfPageSizeConf"
            @tableRowClick="selfTableRowClick"
            @pageChange="selfPageChange"
            @pageSizeChange="selfPageSizeChange"
          ></vtable>
        </div>
      </div>
    </vtab>

    <div slot="modal-footer">
      <a class="waves-effect waves-light btn" @click="close">取消</a>
      <a class="waves-effect waves-light btn highlight" @click="addFund">确定</a>
    </div>
  </vmodal>
</template>
<script>
import $ from "jquery";
import { getSessionOption } from "../../common/js/utils";
export default {
  props: {},
  data() {
    return {
      loading: false,
      collectionLoading: false,
      selfFundLoading: false,
      addSearchValue: {},
      options: [
        {
          label: "全部",
          value: -1
        },
        {
          label: "基金",
          value: 1
        },
        {
          label: "指数",
          value: 2
        }
      ],
      pageSizeConf: [10],
      maxHeight: 300,
      choseMaxHeight: 400,
      choseIdArr: [],
      preChoseIdArr: [],
      preDeleteIdArr: [],
      overChosen: {
        id: "",
        overChosen: false
      },
      tableData: [],
      totalItem: 10,
      page: 1,
      pageSize: 10,
      collectionEmptyData: "暂无收藏的基金和指数",
      emptyData: "请输入关键字进行查询",
      selfEmptyData: "暂无基金信息",
      recordId: "",
      recordKey: "",
      titleExplain: [
        "左侧为排排网收录的基金和指数",
        "根据条件搜索，选择左侧基金，",
        "添加到右侧并点击确定按钮，即可",
        "收藏基金和指数"
      ],
      tabs: [
        {
          label: "第三方基金",
          key: "otherFundCollection",
          titleExplain: [
            "左侧为排排网收录的基金和指数",
            "根据条件搜索，选择左侧基金，",
            "添加到右侧并点击确定按钮，即可",
            "收藏基金和指数"
          ],
          width: 100
        },
        {
          label: "我的基金",
          key: "selfFundCollection",
          titleExplain: [
            "点击最后一列的图标，即可控制",
            "基金在首页列表中是否显示"
          ],
          width: 100
        }
      ],
      selfFundTableData: [],
      selfFundFormValue: {
        isHide: 0,
        keyWord: "",
        strategy: ""
      },
      fundStatusOptions: [
        {
          label: "全部",
          value: 0
        },
        {
          label: "运行中",
          value: 1
        },
        {
          label: "已清算",
          value: 2
        }
      ],
      fundHideOptions: [
        {
          label: "全部",
          value: "0"
        },
        {
          label: "隐藏",
          value: "1"
        },
        {
          label: "显示",
          value: "2"
        }
      ],
      hiddenFundIdArr: [],
      selfPage: 1,
      selfTotalItem: 10,
      selfPageSize: 10,
      selfPageSizeConf: [10, 20, 30, 40],
      selfTableKey: ""
    };
  },
  computed: {
    columns() {
      return [
        {
          title: "",
          key: "chosen",
          width: 40,
          showOverflowTooltip: false,
          render: (h, { row }) => {
            let _this = this;
            return h("vswitch", {
              props: {
                type: "checkbox",
                trueLabel: "",
                trueValue: true,
                value: JSON.stringify(this.preChoseIdArr).includes(row.fundId),
                id: row.fundId,
                clearVal: this.overChosen,
                disabled: JSON.stringify(this.choseIdArr).includes(row.fundId)
                // key: row.fundId
              },
              on: {
                change: val => {
                  if (row.sourceData == 1) {
                    // 数组长度超出范围时，提醒用户不再添加
                    if (_this.choseCount > 9 && val === true) {
                      this.overChosen = {
                        id: row.fundId,
                        overChosen: true
                      };
                      return;
                    }
                    this.overChosen = {
                      id: row.fundId,
                      overChosen: false
                    };

                    // checkbox变化时改变已选数组的元素
                    if (val === true) {
                      _this.preChoseIdArr.push({
                        fundId: row.fundId,
                        sourceData: 1,
                        fundShortName: row.fundShortName
                      });
                    } else {
                      _this.preChoseIdArr = _this.preChoseIdArr.filter(item => {
                        return item.fundId !== row.fundId;
                      });
                    }
                  } else {
                    // 类型为指数
                    if (val == true) {
                      _this.preChoseIdArr.push({
                        fundId: row.fundId,
                        sourceData: 2,
                        fundShortName: row.fundShortName
                      });
                    } else {
                      _this.preChoseIdArr = _this.preChoseIdArr.filter(item => {
                        return item.fundId !== row.fundId;
                      });
                    }
                  }
                }
              }
            });
          }
        },
        {
          title: "类型",
          key: "sourceData",
          width: 100,
          render(h, { row }) {
            let map = {
              1: "基金",
              2: "指数"
            };
            return map[row.sourceData];
          }
        },
        {
          title: "基金简称",
          key: "fundShortName"
        },
        {
          title: "管理人",
          key: "trustName",
          render: (h, { row }) => {
            if (!row.trustName) {
              return h("div", {}, "--");
            } else {
              return h("div", {}, row.trustName);
            }
          }
        },
        {
          title: "投顾",
          key: "advisorName",
          render: (h, { row }) => {
            if (!row.advisorName) {
              return h("div", {}, "--");
            } else {
              return h("div", {}, row.advisorName);
            }
          }
        },
        {
          title: "收藏",
          key: "action",
          width: 60,
          render: (h, { row, column, index }) => {
            return h("vbuttonSprite", {
              props: {
                disabled: JSON.stringify(this.choseIdArr).includes(row.fundId),
                pos: {
                  normal: { x: 0, y: -73 },
                  hover: { x: -18, y: -73 },
                  disabled: { x: -36, y: -73 }
                },
                title: "收藏"
              },
              style: {
                verticalAlign: "middle"
              },
              on: {
                click: e => {
                  e.stopPropagation();
                  this.addSingelFund(row);
                }
              }
            });
          }
        }
      ];
    },
    // 已选基金列表配置
    selectedColumns() {
      return [
        {
          title: "",
          width: 40,
          showOverflowTooltip: false,
          render: (h, { row }) => {
            return h("div", [
              h("vswitch", {
                props: {
                  type: "checkbox",
                  trueLabel: "",
                  trueValue: true,
                  value: this.preDeleteIdArr.includes(row.fundId)
                },
                on: {
                  change: val => {
                    if (val) {
                      this.preDeleteIdArr.push(row.fundId);
                    } else {
                      this.preDeleteIdArr = this.preDeleteIdArr.filter(item => {
                        return item !== row.fundId;
                      });
                    }
                  }
                }
              })
            ]);
          }
        },
        {
          title: "基金简称",
          key: "fundShortName"
        },
        {
          title: "移出",
          width: 60,
          render: (h, { row }) => {
            return h("vbuttonSprite", {
              props: {
                pos: {
                  normal: { x: 0, y: -241 },
                  hover: { x: -18, y: -241 },
                  disabled: { x: -36, y: -241 }
                },
                title: "移出"
              },
              style: {
                verticalAlign: "middle"
              },
              on: {
                click: e => {
                  e.stopPropagation();
                  this.deleteFund(row);
                }
              }
            });
          }
        }
      ];
    },
    choseCount() {
      let count = 0;
      this.choseIdArr.concat(this.preChoseIdArr).forEach(item => {
        if (item.sourceData == 1) {
          count++;
        }
      });
      return count;
    },
    // 公司自己的基金列表配置
    selfFundColumns() {
      return [
        {
          title: "基金简称",
          key: "fundShortName"
        },
        {
          title: "基金类型",
          key: "fundType",
          render(h, { row }) {
            let map = getSessionOption("cFundType");
            let val;
            map.forEach(obj => {
              if (obj.param == row.fundType) {
                val = obj.name;
              }
            });
            return val || "--";
          }
        },
        {
          title: "基金策略",
          key: "strategy",
          render(h, { row }) {
            let map = getSessionOption("cFinancialStrategy");
            let val;
            map.forEach(obj => {
              if (obj.param == row.strategy) {
                val = obj.name;
              }
            });
            return val || "--";
          }
        },
        {
          title: "管理人",
          key: "trustName"
        },
        {
          title: "显示状态",
          key: "isHide",
          width: 80,
          render: (h, { row }) => {
            let map = {
              1: "隐藏",
              2: "显示"
            };
            return h(
              "div",
              JSON.stringify(this.hiddenFundIdArr).includes(row.fundId)
                ? "隐藏"
                : "显示"
            );
          }
        },
        {
          title: "操作",
          width: 58,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row }) => {
            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                h("vbuttonSprite", {
                  props: {
                    pos: JSON.stringify(this.hiddenFundIdArr).includes(
                      row.fundId
                    )
                      ? {
                          normal: { x: 0, y: -259 },
                          hover: { x: -18, y: -259 },
                          disabled: { x: -36, y: -259 }
                        }
                      : {
                          normal: { x: 0, y: -223 },
                          hover: { x: -18, y: -223 },
                          disabled: { x: -36, y: -223 }
                        },
                    title: JSON.stringify(this.hiddenFundIdArr).includes(
                      row.fundId
                    )
                      ? "显示"
                      : "隐藏"
                  },
                  style: {
                    verticalAlign: "middle"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();
                      this.toggleFundVisibility(row);
                    }
                  }
                })
              ]
            );
          }
        }
      ];
    },
    strategyOptions() {
      let map = getSessionOption("cFinancialStrategy");
      let strategyOptions = [];
      strategyOptions.push({ label: "全部", value: "" });
      for (let item of map) {
        strategyOptions.push({ label: item.name, value: item.param });
      }
      return strategyOptions;
    }
  },
  methods: {
    // 点击搜索按钮
    searchFund() {
      setTimeout(() => {
        if (this.addSearchValue.fundName) {
          this.page = 1;
          this.pageSize = 10;
          // this.getCollectFundList().then(()=>{
          this.getFundList();
          // })
        } else {
          this.tableData = [];
          this.totalItem = 0;
          this.emptyData = "请输入关键字进行查询";
          this.setTableHeight();
        }
      }, 100);
    },
    // 根据搜索条件查找基金
    getFundList() {
      this.loading = true;
      let param = Object.assign(
        {},
        { pageNo: this.page, pageSize: this.pageSize },
        this.addSearchValue
      );
      this.$http.get("desk/findNotCompanyCollection", param).then(res => {
        this.emptyData = "暂无数据";
        this.setTableHeight();
        this.totalItem = res.data.total;
        this.tableData = JSON.parse(JSON.stringify(res.data.records));
        this.loading = false;
      });
    },
    // 获取已收藏的基金列表
    getCollectFundList() {
      this.collectionLoading = true;
      return new Promise((resolve, reject) => {
        this.$http.get("desk/myCollection").then(res => {
          for (let item of res.data) {
            this.choseIdArr.push({
              fundId: item.fundId,
              fundShortName: item.fundShortName,
              sourceData: item.sourceData
            });
          }
          this.setChoseTabelHeight();
          this.collectionLoading = false;
          resolve();
        });
      });
    },
    // 获取公司自己的基金列表
    getSelfFundList(keepCurrentRow = false) {
      let params = {
        keyWord: this.selfFundFormValue.keyWord,
        strategy: this.selfFundFormValue.strategy,
        isHide: this.selfFundFormValue.isHide,
        pageNo: this.selfPage,
        pageSize: this.selfPageSize
      };
      this.selfFundLoading = true;
      this.$http.get("desk/findMyFund", params).then(res => {
        this.selfFundLoading = false;
        this.selfTotalItem = res.data.total;
        this.selfFundTableData = JSON.parse(JSON.stringify(res.data.records));
        // this.selfTableKey = Math.random();
        // if(window.navigator.userAgent.includes('MSIE')){
        //   return;
        // }
        this.$refs.selfFundTable.refresh();
      });
    },
    // 根据条件获取公司基金列表
    searchSelfFund() {
      this.selfPage = 1;
      this.selfPageSize = 10;
      this.getSelfFundList();
    },
    getHideFund() {
      return new Promise((resolve, reject) => {
        this.$http.get("/desk/myHideFund").then(res => {
          this.hiddenFundIdArr = JSON.parse(JSON.stringify(res.data.fundIds));
          resolve();
        });
      });
    },
    // 初始化modal
    init() {
      this.open();
      this.searchFund();
      this.getHideFund().then(res => {
        this.searchSelfFund();
      });
      this.getCollectFundList();
    },
    // modal开关
    open() {
      this.$refs.addFundModal.open();
    },
    close() {
      this.addSearchValue = {
        sourceData: -1,
        fundName: ""
      };
      this.selfFundFormValue = {
        keyWord: "",
        isHide: 0,
        strategy: ""
      };
      this.choseIdArr = [];
      this.preChoseIdArr = [];
      this.preDeleteIdArr = [];
      this.hiddenFundIdArr = [];
      this.searchFund();
      this.$refs.addFundModal.close();
      this.$refs.fundConfigTab.select("otherFundCollection");
    },
    // 分页器变化根据搜索条件查找基金
    pageChange(page) {
      this.page = page;
      this.overChosen = true;
      this.getFundList();
    },
    pageSizeChange(size) {
      this.pageSize = size;
      this.getFundList();
    },
    // 基金列表行点击切换选中状态
    tableRowClick({ row }) {
      if (JSON.stringify(this.choseIdArr).includes(row.fundId)) {
        return;
      }
      if (row.sourceData == 2) {
        if (JSON.stringify(this.preChoseIdArr).includes(row.fundId)) {
          this.preChoseIdArr = this.preChoseIdArr.filter(item => {
            return item.fundId !== row.fundId;
          });
        } else {
          this.preChoseIdArr.push({
            fundId: row.fundId,
            sourceData: 2,
            fundShortName: row.fundShortName
          });
        }
      } else {
        if (
          this.choseCount > 9 &&
          !JSON.stringify(this.preChoseIdArr).includes(row.fundId)
        ) {
          this.overChosen = {
            id: row.fundId,
            overChosen: true
          };
          return;
        }
        this.overChosen = {
          id: row.fundId,
          overChosen: false
        };
        if (JSON.stringify(this.preChoseIdArr).includes(row.fundId)) {
          this.preChoseIdArr = this.preChoseIdArr.filter(item => {
            return item.fundId !== row.fundId;
          });
        } else {
          this.preChoseIdArr.push({
            fundId: row.fundId,
            sourceData: 1,
            fundShortName: row.fundShortName
          });
        }
      }
    },
    // 已选基金指数的table行点击
    chosenTableRowClick({ row }) {
      if (JSON.stringify(this.preDeleteIdArr).includes(row.fundId)) {
        this.preDeleteIdArr = this.preDeleteIdArr.filter(item => {
          return item !== row.fundId;
        });
      } else {
        this.preDeleteIdArr.push(row.fundId);
      }
    },
    // 批量添加和删除
    addBatch() {
      if (this.preChoseIdArr.length) {
        this.choseIdArr = this.choseIdArr.concat(this.preChoseIdArr);
        this.preChoseIdArr = [];
      }
    },
    deleteBatch() {
      this.choseIdArr = this.choseIdArr.filter(item => {
        return !this.preDeleteIdArr.includes(item.fundId);
      });
      this.preDeleteIdArr = [];
    },
    // 点击添加按钮
    addFund() {
      // if(this.choseIdArr.length == 0){
      //   this.close();
      //   return;
      // }
      let fundToAdd = [];
      for (let item of this.choseIdArr) {
        fundToAdd.push({
          fundId: item.fundId,
          sourceData: item.sourceData
        });
      }
      let setParams = {
        hide: {
          fundIds: this.hiddenFundIdArr
          // isHide:1
        },
        collection: {
          fundIds: fundToAdd
        }
      };
      if (!(window.sessionStorage.getItem("canSend") === "false")) {
        this.loading = true;
      }
      this.$http
        .post("desk/mastFundStatus", setParams)
        .then(res => {
          if (!res) return;
          if (res.code === 20000) {
            this.$message({
              showClose: true,
              message: "修改成功",
              type: "success"
            });
            this.$emit("refreshFundList");
            this.$emit("refreshCollectionFund");
            this.$emit("clearSort");
            this.close();
          } else {
            this.$message({
              showClose: true,
              message: res.msg,
              type: "error"
            });
          }
        })
        .done(() => {
          this.loading = false;
        });
    },
    // 删除单条基金
    deleteFund(row) {
      this.choseIdArr = this.choseIdArr.filter(item => {
        return row.fundId !== item.fundId;
      });
      this.preDeleteIdArr = this.preDeleteIdArr.filter(item => {
        return item.fundId !== row.fundId;
      });
    },
    // 添加单条基金
    addSingelFund(row) {
      if (row.sourceData == 1 && this.choseCount > 9) {
        this.$message.error("最多只能收藏十条基金！");
        return;
      }
      this.choseIdArr.push({
        fundId: row.fundId,
        fundShortName: row.fundShortName,
        sourceData: row.sourceData
      });
      this.preChoseIdArr = this.preChoseIdArr.filter(item => {
        return item.fundId !== row.fundId;
      });
    },
    // 切换自己投顾的基金是否可见
    toggleFundVisibility(row) {
      if (this.hiddenFundIdArr.includes(row.fundId)) {
        this.hiddenFundIdArr = this.hiddenFundIdArr.filter(item => {
          return item !== row.fundId;
        });
      } else {
        this.hiddenFundIdArr.push(row.fundId);
      }
    },

    // 点击自己的基金表格行
    selfTableRowClick() {},
    // 自己基金分页器变化
    selfPageChange(page) {
      this.selfPage = page;
      this.getSelfFundList();
    },
    selfPageSizeChange(size) {
      this.selfPageSize = size;
      this.getSelfFundList();
    },
    // tab切换的回调
    clickTab(tabKey) {
      if (tabKey == "selfFundCollection") {
        // this.$refs.selfFundTable.refresh();
        // this.selfTableKey = tabKey;
      }
    },
    // 动态设置表格高度
    setTableHeight() {
      this.maxHeight = $(".add-fund-modal .content").height() - 140;
      window.addEventListener("resize", () => {
        this.maxHeight = $(".add-fund-modal .content").height() - 140;
      });
    },
    setChoseTabelHeight() {
      this.choseMaxHeight = $(".add-fund-modal .content").height() - 100;
      window.addEventListener("resize", () => {
        this.choseMaxHeight = $(".add-fund-modal .content").height() - 100;
      });
    }
  },
  mounted() {
    this.addSearchValue = {
      sourceData: -1
    };
  },
  watch: {}
};
</script>

<style lang="less">
.add-fund-modal {
  .select-container {
    margin-left: 5px;
    display: inline-block;
    width: 70px;
  }
  .add-table-container,
  .selected-table-container,
  .add-delete-buttons {
    float: left;
  }
  // 选择基金指数的table
  .add-table-container {
    width: 60%;
    position: relative;
    .fund-table-wrapper {
      .overflow-scroll {
        height: 100%;
        .el-table--enable-row-hover {
          height: 100%;
        }
      }
    }
  }
  // 删除和添加按钮
  .add-delete-buttons {
    width: 10%;
    padding: 230px 0 0 7px;
    // padding-top:
    span.btn {
      margin-bottom: 10px;
    }
  }
  // 已选基金和指数的table
  .selected-table-container {
    width: 30%;
    position: relative;
    .fund-table-wrapper {
      .overflow-scroll {
        height: 100%;
        .el-table--enable-row-hover {
          height: 100%;
        }
      }
    }
  }
  .fund-table-wrapper {
    height: calc(~"100% - 50px");
    border: 1px solid #333;
  }
  .collection-fund-index .empty-data-container {
    margin-top: -40px;
  }
  .self-table-container {
    position: relative;
  }
}
</style>
