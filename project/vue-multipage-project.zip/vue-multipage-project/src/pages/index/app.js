
import App from './app.vue'

import { setOptionsMap, userInfoValidate } from '../../common/js/utils'; 

import '../../common/js/common';
import '../../common/js/comp';



const createApp = () => {
  new Vue({
    el: '#app',
    render: h => h(App)
  })
}



userInfoValidate().then( () => {
  setOptionsMap().then( () => {
    createApp()
  })
})

