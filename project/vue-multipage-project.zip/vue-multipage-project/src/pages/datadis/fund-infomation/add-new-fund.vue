<template>
  <vmodal
    :title="'新增基金'"
    class="new-fund-modal t2-el-dialog"
    ref="newFundModal"
    @close="cancel"
    :width="630"
  >
    <!-- 有无备案编码 -->
    <div class="chose-area">
      <vformConfig ref="formModal" :config="formConfig" v-model="formReg" @change="onRegChange"></vformConfig>
    </div>

    <!-- 上传区域 -->
    <div class="content-container">
      <vformConfig
        v-show="this.formReg.hasRegsiterNum"
        ref="submitFormWithreg"
        :config="submitConfigWithReg"
        v-model="formContractWithReg"
      ></vformConfig>

      <vformConfig
        v-show="!this.formReg.hasRegsiterNum"
        ref="submitFormWithoutReg"
        :config="submitConfigWithoutReg"
        v-model="formContractWithoutReg"
      ></vformConfig>
      <div v-if="!this.formReg.hasRegsiterNum" class="tips">
        <div class="dashed-line"></div>
        <p>您的基金没有备案编码，请提交基金资料，或联系我们。</p>
        <p>我们将在三个工作日内协助您录入新基金信息。</p>
        <div style="margin-top: 25px;">
          <p>联系电话：{{contacts.landline}}</p>
          <p>手机：{{contacts.cel}}</p>
          <p>微信：{{contacts.wechat}}</p>
          <p>QQ：{{contacts.qq}}</p>
        </div>
      </div>
      <div v-else class="tips">
        <div class="dashed-line"></div>
        <p>您的基金有备案编码，请提交备案编码和基金合同。</p>
        <p>我们将在三个工作日内协助您完成基金新增工作。</p>
      </div>
    </div>

    <!--按钮 -->
    <div slot="modal-footer">
      <!-- <a class="waves-effect waves-light btn" @click="cancel">取消</a>
      <a class="waves-effect waves-light btn highlight" @click="confirm">确定</a>-->
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="confirm">确定</vbutton>
    </div>
  </vmodal>
</template>

<script>
import contacts from "../../../common/js/contact";
import { getSessionOption } from "../../../common/js/utils";
export default {
  data() {
    return {
      contacts: contacts,
      //   有无备案编码配置
      formConfig: {
        cols: 1,
        fields: [
          [
            {
              comps: [
                {
                  key: "hasRegsiterNum",
                  compType: "vradio",
                  compConfig: {
                    options: [
                      {
                        label: "有备案编码",
                        value: 1
                      },
                      {
                        label: "无备案编码",
                        value: 0
                      }
                    ]
                  }
                }
              ]
            }
          ]
        ]
      },
      //   提交内容
      formContractWithoutReg: {},
      formContractWithReg: {},
      //   有无备案编码
      formReg: {
        hasRegsiterNum: 1
      },
      strategyOptions: [],
      substrategyOptions: []
    };
  },

  watch: {
    // formReg: {
    //   handler(val) {
    //     this.formContract = {};
    //     this.$refs.submitForm.resetValid();
    //   },
    //   deep: true
    // }
    "formContractWithoutReg.strategy": {
      handler(val, oldval) {
        if (oldval) {
          this.formContractWithoutReg.substrategy = "";
        }
        if (val) {
          this.strategyOptions.forEach(item => {
            if (item.param == val) {
              this.substrategyOptions = item.children;
            }
          });
        } else {
          this.formContractWithoutReg.substrategy = "";
          this.substrategyOptions = [];
        }
      },
      deep: false
    }
  },
  mounted() {
    this.strategyOptions = getSessionOption("cFinancialStrategy");
  },
  computed: {
    //   提交内容配置
    submitConfigWithReg() {
      // 基金备案编码验证
      const validateFundRegNumber = () => {
        return (rule, value, callback, source, options) => {
          let errors = [];
          if (value) {
            if (!/^S[0-9a-zA-Z]{5}$/.test(value)) {
              errors.push(new Error("备案编码格式有误，请检查！"));
            }
          }

          callback(errors);
        };
      };

      let fields = [
        [
          {
            label: "备案编码",
            labelWidth: 80,
            comps: [
              {
                key: "registerNumber",
                compType: "vinput",
                rules: [
                  { required: true, message: "请填写备案编码" },
                  validateFundRegNumber()
                ]
              }
            ]
          }
        ],
        [
          {
            label: "基金合同",
            labelWidth: 80,
            comps: [
              {
                key: "fundContract",
                compType: "vfileUpload",
                compConfig: {
                  url: "datadis/FundContract/uploadAttach",
                  fileName: "file",
                  resName: "fileName",
                  foreignPath: true
                },
                rules: [{ required: true, message: "请上传基金合同" }]
              }
            ]
          }
        ],
        [
          {
            label: "备注",
            labelWidth: 80,
            comps: [
              {
                key: "remark",
                compType: "vtextArea"
              }
            ]
          }
        ]
      ];
      return {
        cols: 1,
        fields
      };
    },
    submitConfigWithoutReg() {
      let fields = [
        [
          {
            label: "基金全称",
            labelWidth: 105,
            comps: [
              {
                key: "fundName",
                compType: "vinput",
                compConfig: {},
                rules: [{ required: true, message: "请输入基金全称" }]
              }
            ]
          }
        ],
        [
          {
            label: "成立日期",
            labelWidth: 105,
            comps: [
              {
                key: "inceptionDate",
                compType: "vdatePicker",
                compConfig: {},
                rules: [{ required: true, message: "请选择" }]
              }
            ]
          }
        ],
        [
          {
            label: "基金类型",
            labelWidth: 105,
            comps: [
              {
                key: "fundType",
                compType: "vselect",
                compConfig: {
                  options: getSessionOption("cFundType"),
                  valueKey: "param",
                  labelKey: "name"
                },
                rules: [{ required: true, message: "请选择基金类型" }]
              }
            ]
          }
        ],
        [
          {
            label: "基金策略",
            labelWidth: 105,
            colspan: 6,
            comps: [
              {
                key: "strategy",
                compType: "vselect",
                compConfig: {
                  options: (() => {
                    let strategy = getSessionOption("cFinancialStrategy");
                    strategy.pop();
                    return strategy;
                  })(),
                  valueKey: "param",
                  labelKey: "name"
                },
                rules: [
                  { required: true, message: "请选择基金策略" }
                  // validateValue(
                  //   ["-1"],
                  //   "strategy",
                  //   '基金策略不能选择"其他"'
                  // )
                ]
              }
            ]
          },
          {
            label: "子策略",
            labelWidth: 105,
            colspan: 6,
            comps: [
              {
                key: "substrategy",
                compType: "vselect",
                compConfig: {
                  valueKey: "param",
                  labelKey: "name",
                  options: this.substrategyOptions
                },
                rules: [{ required: true, message: "请选择子策略" }]
              }
            ]
          }
        ],
        [
          {
            label: "基金运行状态",
            labelWidth: 105,
            colspan: 2,
            comps: [
              {
                key: "fundStatus",
                compType: "vradio",
                compConfig: {
                  // url: "common/config/cFundOprateState",
                  options: [
                    {
                      name: "开放运行",
                      param: 2
                    },
                    {
                      name: "封闭运行",
                      param: 3
                    },
                    {
                      name: "提前清算",
                      param: 4
                    },
                    {
                      name: "到期清算",
                      param: 5
                    }
                  ],
                  valueKey: "param",
                  labelKey: "name"
                },
                rules: [{ required: true, message: "运行状态不能为空" }]
              }
            ]
          }
        ]
      ];
      return {
        cols: 1,
        fields
      };
    }
  },

  methods: {
    onRegChange(val) {
      if (val.hasRegsiterNum) {
        this.$nextTick(() => {
          this.$refs.submitFormWithreg.resetValid();
        });
      } else {
        this.$nextTick(() => {
          this.$refs.submitFormWithoutReg.resetValid();
        });
      }
    },
    open() {
      this.$refs.newFundModal.open();
    },

    getSubmitData(valueToDeal) {
      let submitData = {};
      for (var key in valueToDeal) {
        if (key == "fundContract") {
          submitData["contractName"] = valueToDeal[key]["fileName"];
          submitData["contractPath"] = valueToDeal[key]["filePath"];
        } else {
          submitData[key] = valueToDeal[key];
        }
      }

      return submitData;
    },

    reset() {
      if (this.formReg.hasRegsiterNum) {
        this.$refs.submitFormWithreg.resetValid();
      } else {
        this.$refs.submitFormWithoutReg.resetValid();
      }
    },

    submitData(ref, value) {
      this.$refs[ref].valid().then(valid => {
        if (valid) {
          let submitData = this.getSubmitData(value);
          this.$http.post("datadis/FundContract", submitData).then(res => {
            if (res.code === 20000) {
              this.$message({
                type: "success",
                message: "提交成功，请等待新增"
              });
              sa.event("fundMaster_addFundWithCode", {
                hasRegisterCode: this.formReg.hasRegsiterNum
              });
              this.$emit("searchFund");
              this.cancel();
            } else {
              this.$message({
                type: "error",
                message: "提交失败"
              });
            }
          });
          this.cancel();
        }
      });
    },

    confirm() {
      if (this.formReg.hasRegsiterNum) {
        this.submitData("submitFormWithreg", this.formContractWithReg);
      } else {
        this.submitData("submitFormWithoutReg", this.formContractWithoutReg);
      }
    },
    cancel() {
      this.$refs.newFundModal.close();
      this.reset();
      this.formContractWithoutReg = {};
      this.formContractWithReg = {};
      this.formReg = {
        hasRegsiterNum: 1
      };
    }
  }
};
</script>

<style lang="less" scoped>
.content-container {
  width: 100%;
  margin: 0 auto;
  padding: 10px;
  border: 1px solid #333;
  // padding: 10px;
  .tips {
    font-size: 12px;
    line-height: 26px;
    .dashed-line {
      border-top: 1px dashed rgba(255, 255, 255, 0.15);
    }
  }
}
</style>
