<template>
  <div class="date-selector">
    每年
    <el-select style="width:100px;" v-model="value[monthKey]" multiple @change="onMonthDataChange">
      <li class="check-all-wrapper" :class="{'is-checked':ifMonthChecked}" title="全部">
        <el-checkbox v-model="ifMonthChecked" @change="onMonthChange">全部</el-checkbox>
      </li>
      <el-option
        v-for="item in monthOptions"
        :key="item.value"
        :value="item.value"
        :label="item.label"
        :title="item.label"
      />
    </el-select>月
    <el-select style="width:70px;" v-model="value[orderKey]" @change="onOrderChange">
      <el-option
        v-for="item in orderOptions"
        :key="item.value"
        :value="item.value"
        :label="item.label"
        :title="item.label"
      />
    </el-select>
    <el-select style="width:100px;" multiple v-model="value[dayKey]" @change="onDayDataChange">
      <li class="check-all-wrapper" :class="{'is-checked':ifDayChecked}" title="全部">
        <el-checkbox v-model="ifDayChecked" @change="onDayChange">全部</el-checkbox>
      </li>
      <el-option
        v-for="item in dayOptions"
        :key="item.value"
        :value="item.value"
        :label="item.label"
        :title="item.label"
      />
    </el-select>
    <el-select style="width:70px;" v-model="value[typeKey]" @change="onTypeChange">
      <el-option
        v-for="item in typeOptions"
        :key="item.value"
        :value="item.value"
        :label="item.label"
        :title="item.label"
      />
    </el-select>
    <el-select
      style="width:100px;"
      multiple
      v-model="value[weekKey]"
      @change="onWeekDataChange"
      :key="weekSelectKey"
      v-if="value[typeKey] == 3"
    >
      <li class="check-all-wrapper" :class="{'is-checked':ifWeekChecked}" title="全部">
        <el-checkbox v-model="ifWeekChecked" @change="onWeekChange">全部</el-checkbox>
      </li>
      <el-option
        v-for="item in weekOptions"
        :key="item.index"
        :value="item.value"
        :label="item.label"
        :title="item.label"
      />
    </el-select>
  </div>
</template>

<script>
import $ from "jquery";
import { cloneDeep } from "lodash";
export default {
  model: {
    prop: "value",
    event: "change"
  },

  props: {
    value: {
      type: Object
    },

    monthKey: {
      type: String,
      default: "openDayMonth"
    },

    weekKey: {
      type: String,
      default: "openDayWeek"
    },
    dayKey: {
      type: String,
      default: "openDayDaysWeeks"
    },
    orderKey: {
      type: String,
      default: "openDayDaySeq"
    },
    typeKey: {
      type: String,
      default: "openDayType"
    }
  },

  data() {
    return {
      allMonthData: [],
      allDayData: [],
      allWeekData: [],
      monthOptions: [],
      orderOptions: [
        {
          value: 1,
          label: "第"
        },
        {
          value: 2,
          label: "后"
        }
      ],

      typeOptions: [
        {
          value: 1,
          label: "工作日"
        },
        {
          value: 2,
          label: "自然日"
        },
        {
          value: 3,
          label: "周"
        }
      ],

      weekOptions: [],
      dayOptions: [],
      ifMonthChecked: false,
      ifDayChecked: false,
      ifWeekChecked: false,
      initDayData: [],
      weekSelectKey: null
    };
  },

  mounted() {
    this.monthOptions = this.generateOptions(12, "month");
    this.weekOptions = this.generateWeekOptions();
    this.weekSelectKey = Date.now();
    let nums = this.value[this.typeKey] == 3 ? 6 : 31;
    this.dayOptions = this.generateOptions(nums) || [];
    this.initDayData = cloneDeep(this.value[this.dayKey]);
  },

  computed: {},

  watch: {
    value: {
      handler(val) {
        let nums = val[this.typeKey] == 3 ? 6 : 31;
        this.dayOptions = this.generateOptions(nums) || [];

        let monthData = val[this.monthKey];
        let dayData = val[this.dayKey];
        let weekData = val[this.weekKey];

        if (monthData && monthData.length == this.monthOptions.length) {
          this.ifMonthChecked = true;
        } else {
          this.ifMonthChecked = false;
        }
        if (dayData && dayData.length == this.dayOptions.length) {
          this.ifDayChecked = true;
        } else {
          this.ifDayChecked = false;
        }
        if (weekData && weekData.length == this.weekOptions.length) {
          this.ifWeekChecked = true;
        } else {
          this.ifWeekChecked = false;
        }
      },

      deep: true,

      immidate: true
    }
  },

  methods: {
    generateOptions(length, type) {
      let options = [];
      let key = type == "month" ? "allMonthData" : "allDayData";
      this[key] = [];
      for (let i = 1; i <= length; i++) {
        options.push({ label: i, value: i });

        this[key].push(i);
      }

      return options;
    },

    generateWeekOptions() {
      let days = [
        "星期一",
        "星期二",
        "星期三",
        "星期四",
        "星期五",
        "星期六",
        "星期天"
      ];

      let options = [];
      this.allWeekData = [];

      days.forEach((day, index) => {
        options.push({
          label: day,
          value: index + 1
        });
        this.$nextTick(() => {
          this.allWeekData.push(index + 1);
        });
      });

      return options;
    },

    onMonthChange(checked) {
      let cloneValue = cloneDeep(this.value || {});
      let data = [];
      if (checked) {
        this.allMonthData.forEach((item, index) => {
          data[index] = item;
        });
      } else {
        data = [];
      }

      cloneValue[this.monthKey] = data;

      this.$emit("input", cloneValue);
    },

    onDayChange(checked) {
      let cloneValue = cloneDeep(this.value || {});
      let data = [];
      if (checked) {
        this.allDayData.forEach((item, index) => {
          data[index] = item;
        });
      } else {
        data = [];
      }

      this.initDayData = cloneDeep(data);
      cloneValue[this.dayKey] = data;

      this.$emit("input", cloneValue);
    },

    onWeekChange(checked) {
      let cloneValue = cloneDeep(this.value || {});
      let data = [];
      if (checked) {
        this.allWeekData.forEach((item, index) => {
          data[index] = item;
        });
      } else {
        data = [];
      }

      cloneValue[this.weekKey] = data;

      this.$emit("input", cloneValue);
    },

    onMonthDataChange(data) {
      if (data.length !== this.allMonthData.length) {
        this.ifMonthChecked = false;
      } else {
        this.ifMonthChecked = true;
      }

      let cloneValue = cloneDeep(this.value || {});
      cloneValue[this.monthKey] = data;

      this.$emit("input", cloneValue);
    },

    onDayDataChange(data) {
      if (data.length !== this.allDayData.length) {
        this.ifMonthChecked = false;
      } else {
        this.ifMonthChecked = true;
      }

      this.initDayData = cloneDeep(data);

      let cloneValue = cloneDeep(this.value || {});
      cloneValue[this.dayKey] = data;

      this.$emit("input", cloneValue);
    },

    onWeekDataChange(data) {
      if (data.length !== this.allWeekData.length) {
        this.ifWeekChecked = false;
      } else {
        this.ifWeekChecked = true;
      }

      let cloneValue = cloneDeep(this.value || {});
      cloneValue[this.weekKey] = data;

      this.$emit("input", cloneValue);
    },

    onTypeChange(data) {
      let cloneValue = cloneDeep(this.value || {});
      cloneValue[this.typeKey] = data;

      if (data == 3) {
        let day = this.initDayData.filter(item => item <= 6);
        let dayData = [...new Set(day)];
        cloneValue[this.dayKey] = dayData;
        this.weekSelectKey = Date.now();
      } else {
        let day = this.initDayData.filter(item => item > 6);
        day = [...new Set(cloneValue[this.dayKey]).concat(day)];
        cloneValue[this.dayKey] = day;
      }

      this.$emit("input", cloneValue);
    },

    onOrderChange(data) {
      let cloneValue = cloneDeep(this.value || {});
      cloneValue[this.orderKey] = data;

      this.$emit("input", cloneValue);
    }
  }
};
</script>

<style lang="less">
.el-select__tags {
  height: 100% !important;
  & > span {
    display: flex;
    height: 100%;
    overflow: hidden;
    align-items: center;
  }

  .el-tag--small {
    height: 22px !important;
    padding: 0 6px 0 2px !important;
  }
}

.el-select .el-tag {
  margin: 2px !important;
}

.check-all-wrapper {
  cursor: pointer;
  width: 100%;
  display: inline-block;
  &:hover {
    background-color: #345;
  }
  padding: 3px 6px;

  .el-checkbox {
    width: 100%;
  }
}

.el-checkbox__label {
  padding-left: 6px !important;
}

.is-checked {
  &.check-all-wrapper {
    background-color: #17c !important;
  }
  .el-checkbox__label {
    color: #eee !important;
  }
}

.date-selector {
  margin: 10px 0;
}
</style>
