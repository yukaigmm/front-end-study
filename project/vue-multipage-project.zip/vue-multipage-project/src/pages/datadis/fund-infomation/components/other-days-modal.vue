<template>
  <vmodal
    class="fund-info-modal t2-el-dialog"
    ref="modal"
    @close="cancel"
    title="添加其他日期"
    :width="320"
  >
    <div class="mutiple-date-wrapper">
      <div class="fund-day-date-picker">
        <el-date-picker
          :clearable="false"
          type="dates"
          v-model="dates"
          value-format="yyyy-MM-dd"
          placeholder="选择一个或多个日期"
        ></el-date-picker>
      </div>

      <div class="chosen-days">
        <vpart title="已选日期列表"></vpart>
        <div class="chosen-days-list">
          <template v-for="item in dates">
            <div :key="item" v-if="getIfShow(item)" class="days-item-wrapper">
              <span>{{item}}</span>
              <span class="delete-btn" title="删除" @click="deleteData(item)"></span>
            </div>
          </template>
        </div>
      </div>
    </div>

    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton @click="ok" active>确定</vbutton>
    </div>
  </vmodal>
</template>

<script>
import { cloneDeep } from "lodash";
import moment from "moment";
export default {
  props: {
    value: {
      type: Object
    },

    dateKey: {
      type: String,
      default: "openDayOther"
    }
  },

  computed: {},
  data() {
    return {
      dates: ""
    };
  },

  methods: {
    getIfShow(date) {
      return typeof date === "string";
    },

    ok() {
      let data = cloneDeep(this.value || {});
      data[this.dateKey] = this.dates;
      this.$emit("input", data);
      this.cancel();
    },

    cancel() {
      this.$set(this, "dates", "");
      this.$refs.modal.close();
    },

    open() {
      this.getDates();
      this.$refs.modal.open();
    },

    getDates() {
      let data = cloneDeep(this.value || {});
      this.dates = data[this.dateKey] || [];
    },

    deleteData(item) {
      let data = cloneDeep(this.dates || []);
      this.dates = data.filter(date => date != item);
    }
  }
};
</script>

<style lang="less">
.el-date-table td.selected div {
  background-color: transparent;
  &:hover {
    background-color: transparent !important;
  }
}

.el-picker-panel__footer {
  background-color: #222 !important;
  border: none !important;
}

.mutiple-date-wrapper {
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-content: center;
}

.chosen-days {
  margin-top: 15px;
  width: 100%;
}

.chosen-days-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: flex-start;
  .days-item-wrapper {
    width: 130px;
    margin: 8px 0;
    display: flex;
    justify-content: space-around;
    align-items: center;
  }

  .delete-btn {
    display: inline-block;
    width: 16px;
    height: 16px;
    cursor: pointer;
    background: url("../../../../assets/images/direct-sale/move.png") no-repeat;
    background-position: 0 -64px;
    &:hover {
      background-position: 0 -80px;
    }
  }
}

.el-button.is-plain:focus,
.el-button.is-plain:hover {
  background: linear-gradient(#757575, #444) !important;
  color: #eeeeee;
}
</style>

