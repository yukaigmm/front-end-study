<template>
  <div class="fund-day-selector">
    <el-radio-group v-model="value[valueKey]" @change="onChange">
      <el-radio
        v-for="item in options"
        :key="item[radioKey]"
        :label="item[radioKey]"
      >{{item[radioLabelKey]}}</el-radio>
    </el-radio-group>

    <div v-if="ifShowSelector">
      <DateSelector :value="value" @input="onInput" v-bind="this.$attrs" />

      <el-button @click="addOtherDate" type="primary" active>添加其他日期</el-button>

      <other-days-modal :value="value" v-bind="this.$attrs" ref="otherDaysModal" @input="onInput" />
    </div>
  </div>
</template>

<script>
import { cloneDeep } from "lodash";
import DateSelector from "./date-selector";
import OtherDaysModal from "./other-days-modal";
export default {
  model: {
    prop: "value",
    event: "change"
  },

  components: {
    DateSelector,
    OtherDaysModal
  },

  props: {
    value: {
      type: [String, Object],
      default: () => {}
    },

    valueKey: {
      type: String,
      required: true,
      default: ""
    },

    options: {
      type: [Object, Array],
      required: true,
      default: () => []
    },

    radioKey: {
      type: String,
      required: true,
      default: "value"
    },

    radioLabelKey: {
      type: String,
      required: true,
      default: "label"
    },

    showValue: {
      type: [String, Number]
    }
  },

  computed: {
    ifShowSelector() {
      return this.value[this.valueKey] == this.showValue;
    }
  },

  data() {
    return {};
  },

  methods: {
    onInput(data) {
      this.$emit("change", data);
    },

    addOtherDate() {
      console.log(123344)
      this.$refs.otherDaysModal.open();
    },

    onChange(val) {
      let data = cloneDeep(this.value);
      data[this.valueKey] = val;
      this.$emit("change", data);
    }
  }
};
</script>


<style lang="less">
.fund-day-selector {
  .el-button--primary {
    width: 80px !important;
  }
}
</style>
