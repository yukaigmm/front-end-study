<template>
  <vmodal
    class="fund-info-modal t2-el-dialog"
    ref="fundModal"
    @close="cancel"
    @open="fundModalOpened"
    @reloadModal="reloadFundInfo"
    :reload="reload"
    :title="'基金信息'"
    :width="760"
  >
    <vloading v-model="modalLoading" slot="loading" :title="loadingTitle" class="loading"></vloading>
    <div class="form-tab-container">
      <vformTab
        ref="formCollection"
        :config="formCollectionConfig"
        v-model="form"
        @clickTab="clickTab"
        :shadow="!userEditable"
      ></vformTab>
    </div>
    <div slot="modal-footer">
      <vbutton @click="close">取消</vbutton>
      <vbutton active v-if="confirmButtonShow" :disabled="reload" @click="confirm">保存</vbutton>
      <vbutton active v-if="confirmButtonShow" :disabled="reload" @click="saveDraft">保存草稿</vbutton>
    </div>
  </vmodal>
</template>
<script>
import fundManager from "./fund-manager.vue";
import attachment from "./attachment.vue";
import strategyIntroduction from "./strategy-introduction.vue";
import formConfig from "./fund-modal-config/form-config.js";
import formWatchHandler from "./fund-modal-config/form-watch.js";
import { getSessionOption } from "../../../common/js/utils";
import $ from "jquery";

export default {
  components: {
    fundManager,
    attachment,
    strategyIntroduction
  },
  props: {
    status: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      initStrategy: "",
      pFundShortName: "",
      fundId: "",
      isDraft: "",
      reload: false,
      trustName: "",
      brokerName: "",
      brokerFutureName: "",
      custodianName: "",
      generalServiceName: "",
      auditorName: "",
      administratorName: "",
      legalCounselName: "",
      trustName: "",
      strategyOptions: [],
      substrategyOptions: [],
      form: {
        managerMapping: [],
        attachInfo: []
      },
      modalLoading: false,
      confirmButtonShow: true,
      userEditable: true,
      firstShow: false,
      loadingTitle: "数据加载中，请等待！",
      setValueCount: 0,
      // 接口给用户返回的数据，用户提交数据的时候，原样返回给后台
      clientLog: ""
    };
  },
  computed: {
    // 表单配置太多，单独拆分到配置文件
    formCollectionConfig() {
      return formConfig.call(this, {
        fundManager,
        attachment,
        strategyIntroduction
      });
    }
  },
  mounted() {
    this.strategyOptions = getSessionOption("cFinancialStrategy");
    this.getStratagyDetail();

    //获取用户权限，判断是否可编辑信息
    let currentUserInfo = localStorage.getItem("fund_master_current_user")
      ? JSON.parse(localStorage.getItem("fund_master_current_user"))
      : {};
    let userPermission = currentUserInfo.userPermission;
    this.userEditable = userPermission === 1;
  },
  methods: {
    transferOprnOrRedemptionDay(type, data) {
      let keysMapping = {
        openDay: {
          month: "openDayMonth",
          order: "openDayDaySeq",
          day: "openDayDaysWeeks",
          type: "openDayType",
          week: "openDayWeek",
          otherDay: "openDayOther"
        },

        redemptionDay: {
          month: "redemptionDayMonth",
          order: "redemptionDayDaySeq",
          day: "redemptionDayDaysWeeks",
          type: "redemptionDayType",
          week: "redemptionDayWeek",
          otherDay: "redemptionDayOther"
        }
      };

      let mapping = keysMapping[type];

      let orderMapping = {
        1: "第",
        2: "后"
      };

      let typeMapping = {
        1: "工作日",
        2: "自然日",
        3: "周"
      };
      let weekMapping = {
        1: "星期一",
        2: "星期二",
        3: "星期三",
        4: "星期四",
        5: "星期五",
        6: "星期六",
        7: "星期天"
      };

      let str;

      let month = data[mapping.month] || [];
      let monthStr = month.join("、");

      let order = orderMapping[data[mapping.order]];

      let day = data[mapping.day] || [];
      let dayStr = day.join("、");

      let dataType = typeMapping[data[mapping.type]];
      let week = data[mapping.week] || [];
      let weekStr = "";
      week.forEach((item, index) => {
        if (index == week.length - 1) {
          weekStr += weekMapping[item];
        } else {
          weekStr += weekMapping[item] + "、";
        }
      });

      let otherDay = data[mapping.otherDay] || [];
      let otherDayStr;
      if (otherDay.length) {
        otherDayStr = otherDay.join("、");
        str = `每年${monthStr || "--"}月${order || "--"}${dayStr ||
          "--"}${dataType || "--"}${weekStr || "--"}以及${otherDayStr}`;
      } else {
        str = `每年${monthStr || "--"}月${order || "--"}${dayStr ||
          "--"}${dataType || "--"}${weekStr}`;
      }

      return str;
    },

    cancel() {
      this.reset();
      this.clearForm();
    },
    /*
      id: fundId,
      isDraft: 是否为草稿
    */
    show(id, isDraft) {
      this.isDraft = isDraft;
      this.fundId = id;
      this.firstShow = true;
      this.open();
      // this.$nextTick(() => {
      //   console.log("opened");
      //   this.getFundInfo(id, isDraft);
      // });
    },
    open() {
      this.$refs.fundModal.open();
    },
    close() {
      this.$refs.fundModal.close();
    },
    reset() {
      this.$refs.formCollection.resetValid();
      this.$refs.formCollection.jumpTab("basicInfomation");
      this.setValueCount = 0;
    },
    fundModalOpened() {
      this.modalLoading = true;
      this.$nextTick(() => {
        this.modalLoading = false;
        this.getFundInfo(this.fundId, this.isDraft);
      });
    },
    getStratagyDetail() {
      $("i.fund-strategy-label").on("click", () => {
        this.$refs.formCollection.jumpTab("strategyIntroduction");
      });
    },
    clearForm() {
      this.form = {
        managerMapping: [],
        attachInfo: []
      };
    },

    getInitStrategy() {
      return new Promise((resolve, reject) => {
        this.$http.get(`datadis/fund/base/${this.fundId}`).then(res => {
          if (res.code === 20000) {
            resolve(res.data.strategy);
          } else {
            resolve();
          }
        });
      });
    },

    getFundInfo(id, isDraft) {
      let url = isDraft ? `datadis/draft/1/${id}` : `datadis/fund/${id}`;
      this.loadingTitle = "数据加载中，请等待！";
      this.modalLoading = true;
      this.reload = false;
      this.$http.get(url).then(
        res => {
          this.modalLoading = false;
          if (res && res.code === 20000) {
            let data = isDraft ? res.data.draftData : res.data;
            this.clientLog = JSON.stringify(data);
            // 给远程搜索的defaultLabel赋值
            this.pFundShortName = data.pFundShortName;
            this.trustName = data.trustName;
            this.brokerName = data.brokerName;
            this.brokerFutureName = data.brokerFutureName;
            this.custodianName = data.custodianName;
            this.liquidationAgencyName = data.liquidationAgencyName;
            this.generalServiceName = data.generalServiceName;
            this.auditorName = data.auditorName;
            this.administratorName = data.administratorName;
            this.legalCounselName = data.legalCounselName;
            data.fundOpenDay = data.fundOpenDay ? data.fundOpenDay : {};
            data.fundRedemptionDay = data.fundRedemptionDay
              ? data.fundRedemptionDay
              : {};
            this.setFormValue(JSON.parse(JSON.stringify(data)));
          } else {
            let msg = res && res.msg ? res.msg : "数据加载失败，请点击重新加载";
            this.$message.error(msg);
            this.reload = true;
          }
        },
        () => {
          this.$message.error("数据加载失败，请重试");
        }
      );
    },
    reloadFundInfo() {
      this.getFundInfo(this.fundId, this.isDraft);
    },
    //  为没有的字段附上空值，配合后台接口
    dealWithViodKeys(objectToDeal, keys = []) {
      keys.forEach(item => {
        if (!objectToDeal[item.parentKey][item.keyTodeal]) {
          objectToDeal[item.parentKey][item.keyTodeal] = "";
        }
      });
      return objectToDeal;
    },
    setFormValue(data) {
      this.form = JSON.parse(JSON.stringify(data));
      this.setValueCount++;
      this.$nextTick(() => {
        if (!this.form.fundName && this.setValueCount <= 5) {
          this.setFormValue(JSON.parse(JSON.stringify(data)));
        } else {
          this.$refs.formCollection.valid();
        }
      });
    },
    confirm() {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }

      this.$refs.formCollection.valid().then(valid => {
        if (valid.valid) {
          // let formData = JSON.parse(JSON.stringify(this.form));
          let formData = Object.assign({}, this.form, {
            clientLog: this.clientLog
          });
          this.modalLoading = true;
          this.getInitStrategy().then(strategy => {
            let initStrategyText;
            let currentStrategyText;

            this.strategyOptions.forEach(item => {
              if (item.param == strategy) {
                initStrategyText = item.name;
              }

              if (item.param == formData.strategy) {
                currentStrategyText = item.name;
              }
            });
            if (strategy && strategy != formData.strategy) {
              this.$prompt(
                `本次修改,您将基金策略由<b style="color:#fff"> ${initStrategyText} </b>修改为<b style="color:#fff"> ${currentStrategyText} </b>,请填写备注信息，以便我们理解该基金策略的变化情况:`,
                "取消",
                {
                  showInput: true,
                  inputPlaceholder: "请输入备注",
                  inputType: "textarea",
                  inputValidator: value => {
                    let regp = /^\s*$/g;
                    if (
                      regp.test(value) ||
                      value == null ||
                      value == "" ||
                      value == undefined
                    ) {
                      return false;
                    }
                    return true;
                  },
                  showCancelButton: true,
                  inputErrorMessage: "备注不能为空",
                  customClass: "customer-dialog",
                  // type: "warning",
                  dangerouslyUseHTMLString: true,
                  closeOnClickModal: false,
                  beforeClose: (action, instance, done) => {
                    let remark = instance.inputValue;
                    if (action === "confirm") {
                      instance.confirmButtonLoading = true;
                      let remarkParams = {
                        logRemark: remark,
                        keyId: this.fundId,
                        logTypeName: "基金策略",
                        keyType: 3,
                        logType: 1
                      };
                      this.$http
                        .post("datadis/remarkLog", [remarkParams])
                        .then(resp => {
                          if (resp.code === 20000) {
                            instance.confirmButtonLoading = false;
                            if (
                              !(
                                window.sessionStorage.getItem("canSend") ===
                                "false"
                              )
                            ) {
                              this.loadingTitle = "修改中...";
                            }
                            done();
                            this.$http
                              .put("datadis/fund", formData, this.fundId)
                              .then(res => {
                                this.modalLoading = false;
                                if (!res) return;
                                if (res.code == 20000) {
                                  this.close();
                                  this.$message.success("修改成功");
                                  this.$emit("success", true);

                                  //监听基金信息编辑的事件
                                  sa.event("fundMaster_infomationSave", {
                                    modalRefer: "基金信息编辑",
                                    id: this.fundId
                                  });
                                } else {
                                  this.$message.error(res.msg);
                                }
                              });
                          } else {
                            this.modalLoading = false;
                            this.$message.error("添加备注失败!");
                          }
                        });
                    } else {
                      instance.confirmButtonLoading = false;
                      this.modalLoading = false;
                      done();
                    }
                  }
                }
              );
            } else {
              if (!(window.sessionStorage.getItem("canSend") === "false")) {
                this.modalLoading = true;
                this.loadingTitle = "修改中...";
              }
              this.$http
                .put("datadis/fund", formData, this.fundId)
                .then(res => {
                  this.modalLoading = false;
                  if (!res) return;
                  if (res.code == 20000) {
                    this.close();
                    this.$message.success("修改成功");
                    this.$emit("success", true);

                    //监听基金信息编辑的事件
                    sa.event("fundMaster_infomationSave", {
                      modalRefer: "基金信息编辑",
                      id: this.fundId
                    });
                  } else {
                    this.$message.error(res.msg);
                  }
                });
            }
          });
        } else {
          this.modalLoading = false;
          this.$message.error("请按红色提示补充信息");
          this.$refs.formCollection.jumpTab(valid.invalidTab);
        }
      });
    },
    saveDraft() {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      if (!(window.sessionStorage.getItem("canSend") === "false")) {
        this.modalLoading = true;
        this.loadingTitle = "修改中...";
      }

      let formData = JSON.parse(JSON.stringify(this.form));

      this.$http
        .post("datadis/draft", {
          draftType: 1,
          draftKeyId: this.fundId,
          draftData: formData,
          clientLog: this.clientLog
        })
        .then(res => {
          this.modalLoading = false;
          if (!res) return;
          if (res.code == 20000) {
            this.close();
            this.$message.success("修改成功");
            this.$emit("success", true);
          } else {
            this.$message.error(res.msg);
          }
        });
    },
    clickTab(val) {
      if (val.tabKey === "strategyIntroduction") {
        this.confirmButtonShow = false;

        //监听基金策略阅读事件
        sa.event("fundMaster_strategyRead", { fundId: this.form.fundId });
      } else {
        this.confirmButtonShow = true;
      }
    }
  },

  watch: {
    "form.strategy": {
      handler(val, oldval) {
        if (oldval) {
          this.form.substrategy = "";
        }
        if (val) {
          this.strategyOptions.forEach(item => {
            if (item.param == val) {
              this.substrategyOptions = item.children;
            }
          });
        } else {
          this.form.substrategy = "";
          this.substrategyOptions = [];
        }
      },
      deep: false
    },
    "form.istiered": {
      handler(val) {
        if (!val) {
          this.form.istieredDesc = "";
        }
      }
    },
    "form.lockupPeriod": {
      handler(val) {}
    },

    "form.fundOpenDay": {
      handler(val) {
        if (val) {
          if (JSON.stringify(val) == "{}") {
            return;
          }
          if (val.isRegularOpen == 1) {
            this.$set(this.form, "openDay", "每个工作日都开放申购");
          } else {
            let str = this.transferOprnOrRedemptionDay("openDay", val);
            this.$set(this.form, "openDay", str);
          }
        }
      },

      deep: true
    },
    "form.fundRedemptionDay": {
      handler(val) {
        if (val) {
          if (JSON.stringify(val) == "{}") {
            return;
          }
          if (val.isRegularRedemption == 1) {
            this.$set(this.form, "redemptionDay", "每个工作日都开放赎回");
          } else {
            let str = this.transferOprnOrRedemptionDay("redemptionDay", val);
            this.$set(this.form, "redemptionDay", str);
          }
        }
      },

      deep: true
    },
    form: {
      handler(val) {
        // console.log(this)
        return formWatchHandler.call(this, val);
      },
      deep: true
    }
  }
};
</script>
<style lang="less">
.form-tab-container {
  position: relative;
  height: 100%;
  #basicInfomation .form > .row {
    padding: 0 10%;
  }
  #fundAuthority .form > .row {
    padding: 0 25%;
  }
  #fundStatus .form > .row {
    padding: 0 20%;
  }
  #fundStratety textarea {
    height: 100px !important;
  }
}

.customer-dialog {
  .el-message-box__status {
    top: 47px !important;
  }
}
</style>