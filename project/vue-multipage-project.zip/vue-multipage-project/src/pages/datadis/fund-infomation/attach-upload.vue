<template>
  <div class="upload-container">
    <a v-show="val.filePath" :href="filePath" target="_blank" class="download">点击下载</a>
    <vfile-upload v-model="val" :url="url" :hideInput="hideInput" :fileName="fileName" class="upload"></vfile-upload>
  </div>
</template>
<script>

export default {
  data(){
      return {
          val:{},
          invalid: false
      }
  },
  computed: {
      filePath () {
        let staticPath = this.val.filePath;
        staticPath.replace('Uploads/', 'Uploads/foreign/');
        return `${this.$baseUrl[process.env.NODE_ENV]['staticFile']}/${staticPath}`;
      }
  },
  props:{
      value:{

      },
      url:{},
      hideInput:{},
      fileName:{}
  },
  methods: {
      toggleInvalidClass (invalid) {
          this.invalid = invalid;
      }
  },
  watch:{
      value:{
          handler(val){
              if(val){
                  this.val = val;
              }
          }
      },
      val:{
          handler(val){
            this.$emit('input',val);
            this.$emit('change',val);
          }
      }
  }
}
</script>
<style lang="less" scoped>
    .upload{
        display: inline-block;
    }
    .download{
        display: inline-block;
    }
    .el-table td div{
        vertical-align: middle;
    }
</style>

