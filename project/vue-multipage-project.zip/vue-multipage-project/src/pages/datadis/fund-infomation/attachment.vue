<template>
  <vpart title="附件信息">
    <div slot="search"></div>
    <div slot="action">
      <vbutton active title="添加收藏" @click="addAttachment">新增</vbutton>
    </div>
    <vtable :key="key" :data="value" :columns="columnsConfig" ref="attachmentTable" width="100%"></vtable>
  </vpart>
</template>

<script>
export default {
  props: {
    value: {
      type: Array,
      default: () => {
        return [];
      }
    }
  },
  data() {
    return {
      key: ""
    };
  },
  computed: {
    columnsConfig() {
      return [
        {
          title: "附件名称",
          key: "docName",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                tableRow: row,
                comps: {
                  key: "docName",
                  compType: "vinput",
                  rules: [
                    { required: true, message: "附件名称不能为空" },
                    (rule, value, callback, source, options) => {
                      let errors = [];

                      if (!row.docPath) {
                        errors.push(new Error("请上传附件"));
                      }
                      callback(errors);
                    }
                  ],
                  validate: false
                },
                value: row.docName
              },
              on: {
                change: val => {
                  this.docNameChange(val, row);
                }
              },
              ref: `docName-${index}`
            });
          }
        },
        {
          title: "附件类型",
          key: "docType",
          width: 120,
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                tableRow: row,
                comps: {
                  compType: "vselect",
                  key: "docType",
                  rules: [{ required: true, message: "附件类型不能为空" }],
                  compConfig: {
                    options: [
                      {
                        value: 1,
                        label: "基金合同"
                      },
                      {
                        value: 2,
                        label: "基金协议"
                      },
                      {
                        value: 3,
                        label: "基金公告"
                      },
                      {
                        value: 4,
                        label: "基金要素"
                      }
                    ]
                  }
                },
                value: row.docType
              },
              on: {
                change: val => {
                  this.docTypeChange(val, row);
                }
              },
              ref: `docType-${index}`
            });
          }
        },
        {
          title: "附件大小",
          key: "docSize",
          width: 100,
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return this.docSizeFormat(row.docSize);
          }
        },
        {
          title: "创建时间",
          key: "createtime",
          width: 100,
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            let time = row.createtime || this.dateFormat();
            return time.split(" ")[0];
          }
        },
        {
          title: "文件",
          key: "file",
          width: 90,
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("vfileUpload", {
              props: {
                url: "datadis/fund/uploadAttach",
                fileName: "fundAttach",
                resName: "fileName",
                hideInput: true
              },
              on: {
                change: val => {
                  this.docFileChange(val, row);
                }
              },
              value: {
                fileName: row.docName || "",
                filePath: row.docPath || ""
              }
            });
          }
        },
        {
          title: "操作",
          align: "center",
          showOverflowTooltip: false,
          key: "action",
          width: 96,
          render: (h, { row, column, index }) => {
            return h("div", {
              class: "table-action-button-container"
            },[
              h("vbuttonSprite", {
                props: {
                  pos: {
                    normal: { x: 0, y: -241 },
                    hover: { x: -18, y: -241 },
                    disabled: { x: -36, y: -241 }
                  },
                  title: "删除"
                },
                style: {
                  verticalAlign: "middle",
                  marginRight: "20px"
                },
                on: {
                  click: e => {
                    this.delete(index, row);
                  }
                }
              }),
              h("vbuttonSprite", {
                props: {
                  pos: {
                    normal: { x: 0, y: -206 },
                    hover: { x: -18, y: -206 },
                    disabled: { x: -36, y: -206 }
                  },
                  title: "下载"
                },
                style: {
                  verticalAlign: "middle"
                },
                on: {
                  click: e => {
                    this.download(index, row);
                  }
                }
              })
            ]);
          }
        }
      ];
    }
  },
  methods: {
    addAttachment() {
      this.$set(this.value, this.value.length, {});
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    },
    delete(index, rowData) {
      this.$confirm("确定删除吗？", "删除", {
        showCancelButton: true,
        type: "warning",
        closeOnClickModal: false,
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            instance.confirmButtonLoading = true;
            instance.confirmButtonText = "删除中...";
            this.$delete(this.value, index);
            this.$emit("change", this.value);
            this.$message({
              showClose: true,
              message: "删除成功,点击确定之后将会生效",
              type: "success"
            });
            instance.confirmButtonLoading = false;
            done();
          } else {
            done();
          }
        }
      });
    },
    download(index, rowData) {
      if (rowData.docPath && rowData.docName) {
        let docPath = rowData.docPath;
        if (/^Uploads/.test(rowData.docPath)) {
          docPath = rowData.docPath.replace(/Uploads\//, "");
        }
        window.open(
          `${
            this.$baseUrl[process.env.NODE_ENV]["host"]
          }/api/common/getFileFromForeign?fileName=${
            rowData.docName
          }&filePath=${docPath}`
        );
      }
    },
    valid() {
      let that = this;
      return new Promise(resolve => {
        let formItemValid = true;
        let length = 0;
        let valids = [];
        if (that.value.length) {
          valids = that.$refs.attachmentTable.getRefs();
        }
        new Promise(resolve => {
          if (valids && valids.length) {
            valids.forEach((item, index) => {
              if (item && item.valid) {
                item.valid().then(valid => {
                  length++;
                  if (!valid) {
                    formItemValid = false;
                  }
                  if (length === valids.length) {
                    resolve(formItemValid);
                  }
                });
              } else {
                length++;
                if (length === valids.length) {
                  resolve(formItemValid);
                }
              }
            });
          } else {
            resolve(true);
          }
        }).then(valid => {
          resolve(valid);
        });
      });
    },
    resetValid() {
      if (!this.value.length) {
        return;
      }
      let valids = this.$refs.attachmentTable.getRefs();
      if (valids.length) {
        valids.forEach(item => {
          if (item) {
            item.resetValid();
          }
        });
      }
    },
    // colChange(val, colIndex, rowIndex) {
    //   let rowData = this.value[rowIndex];
    //   if (colIndex == 4 && rowData.fileName) {
    //     rowData.docName = rowData.fileName.name;
    //     rowData.docSize = this.docSizeFormat(rowData.fileName.fileSize);
    //     rowData.docPath = rowData.fileName.filePath;
    //     rowData.createtime = rowData.fileName.createtime || this.dateFormat()
    //   }
    //   rowData.docScope = 1;
    //   this.$emit('change',this.value);
    // },
    docNameChange(val, row) {
      row.docName = val;
    },
    docTypeChange(val, row) {
      row.docType = val;
    },
    docFileChange(val, row) {
      row.docName = row.docName || val.fileName;
      row.createtime = val.createtime || this.dateFormat();
      row.docSize = val.fileSize;
      row.docPath = val.filePath;
    },
    docSizeFormat(docSize) {
      if (docSize) {
        let size = parseInt(docSize);
        if (size > 1024 && size < 1024 * 1024) {
          return (size / 1024).toFixed(2) + "K";
        } else if (size > 1024 * 1024) {
          return (size / (1024 * 1024)).toFixed(2) + "M";
        } else {
          return size.toFixed(2) + "bit";
        }
      } else {
        return "0bit";
      }
    },
    dateFormat(time = new Date()) {
      let newTime = new Date(time.getTime());
      return `${newTime.getFullYear()}-${newTime.getMonth() +
        1}-${newTime.getDate()}  ${newTime.getHours()}:${newTime.getMinutes()}:${newTime.getSeconds()}`;
    },
    onTableCellChange(val, data, column, index) {
      data[column.property] = val;
    }
  },
  mounted() {},
  watch: {
    value: {
      handler(val) {
        this.key = Date.now();
        this.$emit("input", val);
        this.$emit("change", val);
      },
      deep: true
    }
  }
};
</script>

<style lang="less" scoped>
.addAttach {
  margin-bottom: 10px;
}
</style>

