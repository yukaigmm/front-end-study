<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
    <div slot style="height: 100%;">
      <vpart title="公司基金信息">
        <div slot="search">
          <vselect
            v-model="searchFormValue.fundStatus"
            :options="fundStatusOptions"
            @change="searchFund"
          ></vselect>
          <vselect
            v-model="searchFormValue.strategy"
            :options="strategyOptions"
            @change="searchFund"
          ></vselect>
          <vinput
            type="text"
            class="table-search-input"
            style="display: inline-block"
            @keyup.enter.native="searchFund"
            v-model="searchFormValue.keyWord"
            placeholder="关键字搜索(基金ID/全称/简称/管理人)"
          ></vinput>
          <vbutton active title="搜索" @click="searchFund">搜索</vbutton>
          <vswitch
            style="display: inline-block;"
            type="checkbox"
            v-model="searchFormValue.isVisible"
            :trueValue="-1"
            :falseValue="1"
            trueLabel="显示不对外展示基金"
            falseLabel
            @change="searchFund"
          ></vswitch>
          <vtooltip :showIndex="false" explains="选中则会同时显示可见与不可见基金" style="vertical-align: -3px;"></vtooltip>
        </div>
        <div slot="action">
          <vbutton active title="添加基金" @click="addFund">新增</vbutton>
        </div>
        <vtable
          ref="table"
          :columns="columns"
          :data="tableData"
          :useActionColumn="true"
          :usePagination="true"
          :totalItem="totalItem"
          :currentPage="page"
          :maxHeight="maxHeight"
          :pageSize="pageSize"
          @pageChange="pageChange"
          @pageSizeChange="pageSizeChange"
          :changeRowColor="true"
          @tableRowClick="tableRowClick"
        ></vtable>
        <div
          v-show="showPopover"
          role="tooltip"
          class="self-popover el-popover el-popper el-popover--plain"
          :style="{left:`${popoverLeft}px`,top:`${popoverTop}px`}"
          tabindex="0"
          x-placement="bottom"
        >基金数据未公开
          <div x-arrow class="popper__arrow" style="left: 40.5px;"></div>
        </div>
        <vloading class="loading" v-model="loading"></vloading>
        <vreload class="reload" v-model="reload" @reload="getFundList"></vreload>
      </vpart>

      <!-- 新增modal -->
      <addNewFundModal ref="addNewFundModal" @searchFund="searchFund"></addNewFundModal>

      <!-- 修改modal -->
      <fundModal ref="fundModal" @success="getFundList"></fundModal>
    </div>
  </vcommon>
</template>

<script>
import addNewFundModal from "./add-new-fund.vue";
import fundModal from "./fund-modal.vue";
import { getSessionOption, getUrlParams } from "../../../common/js/utils";
import tableHeight from "../../../common/mixins/table-height";
import pageView from "../../../common/mixins/pageView";
export default {
  mixins: [tableHeight, pageView],
  components: {
    fundModal,
    addNewFundModal
    // toast
  },
  data() {
    return {
      totalItem: 0,
      page: 1,
      pageSize: 10,
      currentMenuParentKey: "datadis",
      currentMenuChildKey: "fundInfomation",
      loading: true,
      userEditable: true,
      reload: false,
      searchFormValue: {
        fundStatus: 1,
        strategy: "",
        keyWord: "",
        isVisible: 1
      },
      fundStatusOptions: [
        {
          label: "全部",
          value: 0
        },
        {
          label: "运行中",
          value: 1
        },
        {
          label: "已清算",
          value: 2
        }
      ],
      status: "add",
      currentFundId: "",
      columns: [
        {
          key: "fundId",
          title: "基金ID",
          width: 100
        },
        {
          key: "fundShortName",
          title: "基金简称",
          render: (h, { row, column, index }) => {
            return h(
              "a",
              {
                class: "table-cell-link",
                on: {
                  click: e => {
                    e.stopPropagation();
                    e.preventDefault();
                    this.modifyFund(index, row);
                  }
                }
              },
              `${row.fundShortName}`
            );
          }
        },
        {
          key: "trustName",
          title: "管理人",
          render(h, { row }) {
            return row.trustName || "--";
          }
        },
        {
          key: "inceptionDate",
          title: "成立日期",
          width: 100,
          align: 'right',
          render(h, { row }) {
            return row.inceptionDate || "--";
          }
        },
        {
          key: "strategy",
          title: "基金策略",
          width: 120,
          render(h, { row }) {
            let map = getSessionOption("cFinancialStrategy");
            let val;
            map.forEach(obj => {
              if (obj.param == row.strategy) {
                val = obj.name;
              }
            });
            return val || "--";
          }
        },
        {
          key: "fundType",
          title: "基金类型",
          width: 120,
          render(h, { row }) {
            // let map = getSessionOption("cFundType");
            // let val;
            // map.forEach(obj => {
            //   if (obj.param == row.fundType) {
            //     val = obj.name;
            //   }
            // });
            // return val || "--";
            let map = {
              1: {
                "1": "信托计划",
                "2": "有限合伙",
                "3": "券商资管",
                "4": "公募专户",
                "5": "单账户",
                "6": "证券投资基金",
                "7": "海外基金",
                "8": "期货资管",
                "9": "保险资管",
                "10": "创业投资基金",
                "11": "股权投资基金",
                "12": "银行理财",
                "13": "类固收信托",
                "-1": "其他投资基金"
              },
              2: {
                "1": "股票型",
                "2": "混合型",
                "3": "债券型",
                "4": "货币型",
                "5": "商品型",
                "6": "市场中性型",
                "7": "FOF",
                "8": "海外型",
              }
            }
            // 先判断是公募还是私募，公募的raiseType 为 2，取 map 中的 2；
            // fundType 私募基金类型
            // pubFundType 公募基金类型
            let fundTypeMap = row.raiseType ? map[row.raiseType] : {};
            if (row.sourceData == 2) {
              return "指数";
            } else if (row.raiseType == 1) {
              return fundTypeMap[row.fundType]
            } else if (row.raiseType == 2){
              return fundTypeMap[row.pubFundType]
            }else {
              return "--";
            }
          }
        },
        {
          key: "fundStatus",
          title: "运行状态",
          width: 100,
          render(h, { row }) {
            let map = getSessionOption("cFundOprateState");
            let val;
            map.forEach(obj => {
              if (obj.param == row.fundStatus) {
                val = obj.name;
              }
            });
            return val || "--";
          }
        },
        {
          key: "action",
          title: "操作",
          width: 50,
          fixed: "right",
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                //编辑
                h("vbuttonSprite", {
                  props: {
                    pos: {
                      normal: { x: 0, y: -19 },
                      hover: { x: -18, y: -19 },
                      disabled: { x: -36, y: -19 }
                    },
                    title: "编辑"
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      this.modifyFund(index, row);
                    }
                  }
                }),
              ]
            );
          }
        }
      ],
      tableData: [],
      popoverLeft: -10000,
      popoverTop: -10000,
      showPopover: false,
      currentTablecell: {}
    };
  },
  mounted() {
    // 初始化时，根据url判断是否是从消息通知页面跳转过来的.
    // 如果是，则改变查询条件，根据基金信息（keyWord）查询到基金，
    // 然后直接打开基金的编辑modal
    let params = getUrlParams();
    if(params.keyWord){
      this.searchFormValue.fundStatus = 0;
      this.searchFormValue.isVisible = -1;
      this.searchFormValue.keyWord = decodeURI(params.keyWord);
      this.currentRowId = params.id;
      this.getFundList(true).then(() => {
        this.closePopover();
        for(let i = 0, len = this.tableData.length; i < len; i++){
          let row = this.tableData[i];
          if(row.fundId == params.id){
            this.modifyFund(i, row);
            break;
          }
        }
      });
    }else{
      this.getFundList().then(() => {
        this.closePopover();
      });
    }

    //获取用户权限，判断是否可编辑信息
    let currentUserInfo = localStorage.getItem("fund_master_current_user") ? JSON.parse(localStorage.getItem("fund_master_current_user")) : {};
    let userPermission = currentUserInfo.userPermission;

    this.userEditable = userPermission === 1;
  },
  methods: {
    // 一页展示数量发生变化
    pageSizeChange(val) {
      this.pageSize = val;
      this.getFundList();
    },
    // 页码发生变化
    pageChange(val) {
      this.page = val;
      this.getFundList();
    },
    // 获取基金列表
    getFundList(keepCurrentRow = false) {
      return new Promise((resolve, reject) => {
        let params = Object.assign(
          {
            pageNo: this.page,
            pageSize: this.pageSize
          },
          this.searchFormValue,
        );
        this.loading = true;
        if (!keepCurrentRow) {
          this.currentRowId = "";
        }
        this.$http.get("datadis/fund", params).then(res => {
          this.loading = false;
          // 在删除table数据的时候，如果某一页删完了，需要获得上一页的数据
          if (res && res.code === 20000) {
            if (res.data.records.length) {
              this.tableData = JSON.parse(JSON.stringify(res.data.records));
              this.totalItem = res.data.total;
            } else {
              if (this.page > 1) {
                this.page -= 1;
                this.getFundList();
              } else {
                this.tableData = [];
              }
            }
          } else {
            let msg = res && res.msg ? res.msg : "数据加载失败，请点击重新加载";
            this.$message.error(msg);
            this.reload = true;
            this.tableData = [];
          }
          resolve();
          // let currentRowIndex = _.findIndex(this.tableData, item => {
          //   return item.fundId === this.currentRowId;
          // });
          this.$nextTick(() => {
            this.$refs.table.setCurrentRow("fundId", this.currentRowId);
          });
        });
      });
    },

    // 删除基金
    deleteFund(index, rowData) {
      this.currentFundId = rowData.fundId;

      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      this.$confirm(
        `确认删除<b style="color:#fff">&nbsp;${
          rowData.fundShortName
        }&nbsp;</b>吗?`,
        "删除",
        {
          showCancelButton: true,
          dangerouslyUseHTMLString: true,
          type: "warning",
          closeOnClickModal: false,
          beforeClose: (action, instance, done) => {
            if (action === "confirm") {
              let params = {
                fundId: rowData.fundId
              };
              instance.confirmButtonLoading = true;
              instance.confirmButtonText = "删除中...";
              this.$http
                .putWithoutId(`datadis/fund/applyDelete`, params)
                .then(res => {
                  done();
                  instance.confirmButtonLoading = false;
                  if (!res) return;
                  if (res.code == 20000) {
                    this.getFundList();
                    this.$message({
                      showClose: true,
                      message: "删除成功",
                      type: "success"
                    });
                  } else {
                    this.$message({
                      showClose: true,
                      message: "删除失败",
                      type: "error"
                    });
                  }
                });
            } else {
              done();
            }
          }
        }
      );
    },
    modifyFund(index, rowData) {
      if (rowData.draft.draftStatus === 1 && rowData.draft.draftTime) {
        let draftTime = rowData.draft.draftTime.split(" ")[0];
        this.$confirm(
          `该基金信息有一份草稿，保存时间为${draftTime},是否继续编辑草稿?`,
          "草稿",
          {
            showCancelButton: true,
            dangerouslyUseHTMLString: true,
            type: "warning",
            closeOnClickModal: false,
            beforeClose: (action, instance, done) => {
              if (action === "confirm") {
                done();
                this.$refs.fundModal.show(rowData.fundId, true);
              } else {
                done();
                this.$refs.fundModal.show(rowData.fundId);
              }
            }
          }
        );
      } else {
        this.$refs.fundModal.show(rowData.fundId);
      }
    },
    addFund() {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      this.$refs.addNewFundModal.open();
    },
    searchFund() {
      this.page = 1;
      this.pageSize = 10;
      this.getFundList();
      this.$refs.table.refresh();
    },
    resetSearchField() {
      this.searchFormValue = {};
      this.getFundList();
    },
    //用于记录上一次操作
    addActionRecord(id, key) {},
    tableRowClick({ row, column, index }) {
      this.currentRowId = row.fundId;
      this.$refs.table.setCurrentRow("fundId", this.currentRowId);
    },
    closePopover() {
      document.body.addEventListener("click", e => {
        if (e.target.className != "table-cell-normal") {
          this.showPopover = false;
        }
      });
      document
        .querySelector(".el-table__body-wrapper")
        .addEventListener("scroll", () => {
          this.showPopover = false;
        });
    }
  },
  computed: {
    strategyOptions() {
      let map = getSessionOption("cFinancialStrategy");
      let strategyOptions = [];
      strategyOptions.push({ label: "全部策略", value: "" });
      for (let item of map) {
        strategyOptions.push({ label: item.name, value: item.param });
      }
      return strategyOptions;
    }
  }
};
</script>

<style lang="less" rel="styleSheet/less" scoped>
.title-bar {
  display: inline-block;
  height: 26px;
  width: 5px;
  background-color: #e60012;
  position: absolute;
  left: 0;
  top: 0;
}
.title-container {
  position: relative;
  padding-left: 5px;
  padding-bottom: 15px;
  margin-bottom: 25px;
  border-bottom: 2px solid #999;
  .main-title {
    display: inline-block;
    padding: 0 15px 0 5px;
    font-weight: bold;
    font-size: 22px;
    height: 26px;
    line-height: 26px;
  }
  .sub-title {
    display: inline-block;
    font-weight: normal;
    font-size: 16px;
    padding-left: 5px;
    height: 26px;
    line-height: 26px;
  }
}
.customer-manager-modal {
  overflow: visible;
  .close-icon {
    display: block;
    position: absolute;
    right: 0;
    top: 0;
    border: 1px solid #999;
    border-radius: 50%;
    transform: translate(50%, -50%);
    background-color: #fff;
    cursor: pointer;
  }
  .item-container {
    padding: 20px 10px;
    .m-title {
      font-weight: bold;
      text-align: left;
      height: 26px;
      line-height: 26px;
      position: relative;
      padding-left: 5px;
      .title-content {
        display: inline-block;
        padding: 0 3px;
      }
    }
  }
  .modal-footer {
    text-align: center;
    .confirm-button {
      display: inline-block;
      border: 1px solid transparent;
      border-radius: 5px;
      &:hover {
        border: 1px solid #999;
      }
    }
  }
}
.self-popover {
  position: fixed;
  transform-origin: center top 0px;
  z-index: 2021;
}
.switch-help-icon {
  vertical-align: super;
  display: inline-block;
  width: 16px;
  height: 16px;
  background: url("../../../assets/images/question.png");
}
</style>