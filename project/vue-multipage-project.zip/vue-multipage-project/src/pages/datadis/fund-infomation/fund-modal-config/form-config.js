import {
  validateIsrepeat,
  validateNotContainInvalidWords,
  validateLessThanSomedate,
  validateBetweenTwoNumbers,
  validateBiggerThanSomeNumber
} from "../../../../common/js/validator.js";
import {
  getSessionOption
} from "../../../../common/js/utils";

function formConfig({
  fundManager,
  attachment,
  strategyIntroduction
}) {
  // 关联验证大于等于某个时间
  const biggerThanRelateTime = (key, msg, equal) => {
    let that = this;
    return function (rule, value, callback, source, options) {
      var errors = [];
      var ruleDate = new Date(that.form[key]);
      var valueDate = new Date(value);
      if (equal) {
        if (valueDate.getTime() < ruleDate.getTime()) {
          errors.push(new Error(msg));
        }
      } else {
        if (valueDate.getTime() <= ruleDate.getTime()) {
          errors.push(new Error(msg));
        }
      }
      callback(errors);
    };
  };
  const validateBiggerThanSomeNumberAndNotMinus1 = (val, msg, equal) => {
    return function (rule, value, callback, source, options) {
      var errors = [];
      if (equal) {
        if (value && !(value >= val)) {
          errors.push(new Error(msg));
          if (value == -1) {
            errors = [];
          }
        }
      } else {
        if (value && !(value > val)) {
          errors.push(new Error(msg));
          if (value == -1) {
            errors = [];
          }
        }
      }
      callback(errors);
    };
  };
  // 关联验证小于等于某个时间
  const lessThanRelateTime = (key, msg, equal) => {
    let that = this;
    return function (rule, value, callback, source, options) {
      var errors = [];
      var ruleDate = new Date(that.form[key]);
      var valueDate = new Date(value);
      if (equal) {
        if (valueDate.getTime() > ruleDate.getTime()) {
          errors.push(new Error(msg));
        }
      } else {
        if (valueDate.getTime() >= ruleDate.getTime()) {
          errors.push(new Error(msg));
        }
      }

      callback(errors);
    };
  };

  // 托管机构验证
  const validateCustodianId = (rule, value, callback, source, options) => {
    let errors = [];
    let fundType = ["1", "2", "3", "4", "6", "8"];
    if (
      fundType.includes(this.form.fundType + "") &&
      !this.form.generalServiceId
    ) {
      if (!value) {
        errors.push(new Error("托管机构不能为空"));
      }
    }
    callback(errors);
  };

  // 验证外包机构
  const validateLiquidationAgencyId = (
    rule,
    value,
    callback,
    source,
    options
  ) => {
    let errors = [];
    let fundType = ["1", "2", "3", "4", "6", "8"];
    if (
      fundType.includes(this.form.fundType + "") &&
      !this.form.generalServiceId &&
      this.form.custodianId
    ) {
      if (!value) {
        errors.push(new Error("外包机构与综合服务商必须填一个才能提交"));
      }
    }
    callback(errors);
  };

  //  验证综合服务商
  const validateGeneralServiceId = (
    rule,
    value,
    callback,
    source,
    options
  ) => {
    let errors = [];
    let fundType = ["1", "2", "3", "4", "6", "8"];
    if (
      fundType.includes(this.form.fundType + "") &&
      !this.form.liquidationAgencyId &&
      this.form.custodianId
    ) {
      if (!value) {
        errors.push(new Error("外包机构与综合服务商必须填一个才能提交"));
      }
    }
    callback(errors);
  };

  // 关联验证必填
  const validateRelatedRequired = (params = [], key, msg = "必填") => {
    let that = this;
    return function (rlue, value, callback, source, options) {
      var errors = [];
      if (params.includes(that.form[key] + "")) {
        if (value !== 0 && !value) {
          errors.push(new Error(msg));
        }
      }
      callback(errors);
    };
  };

  // 关联验证必填
  const validateDayRelatedRequired = (params = [], key, valiateKey, msg = "必填") => {
    let that = this;
    return function (rlue, value, callback, source, options) {
      var errors = [];
      if (params.includes(that.form[key] + "")) {
        if (value !== 0 && !value || !value[valiateKey]) {
          errors.push(new Error(msg));
        }
      }
      callback(errors);
    };
  };
  // 
  const validateBrokerIdRequired = () => {
    let that = this;
    return function (rlue, value, callback, source, options) {
      var errors = [];
      if (!["3", "6", "7", "8"].includes(that.form["strategy"] + "")) {
        if (["1", "3", "4", "6", "8"].includes(that.form["fundType"] + "")) {
          if (value !== 0 && !value) {
            errors.push(new Error("证券经纪不能为空"));
          }
        }
      }
      callback(errors);
    }
  }
  // 不能选择某值
  const validateValue = (params = [], key, msg) => {
    let that = this;
    return function (rlue, value, callback, source, options) {
      var errors = [];
      if (params.includes(that.form[key] + "")) {
        errors.push(new Error(msg));
      }
      callback(errors);
    };
  };

  // 基金备案编码验证
  const validateFundRegNumber = () => {
    return (rule, value, callback, source, options) => {
      let errors = [];
      if (value) {
        if (!/^S[0-9a-zA-Z]{5}$/.test(value)) {
          errors.push(new Error("备案编码格式有误，请检查！"));
        }
      }
      callback(errors);
    };
  };

  //  关联同时满足几个条件必填
  const validateRelatedServralRequired = (params = {}, msg = "必填") => {
    let that = this;
    return function (rule, value, callback, source, options) {
      let errors = [new Error(msg)];
      for (let key in params) {
        if (
          !(params[key].includes(that.form[key] + "") || !that.form[key])
        ) {
          errors = [];
        }
      }
      callback(errors);
    };
  };

  // 关联条件包含某字符，必填
  const validateContainSomeStringRequired = (str, key, msg = "必填") => {
    let that = this;
    return function (rlue, value, callback, source, options) {
      var errors = [];
      if (that.form[key]) {
        if (that.form[key].includes(str + "")) {
          if (!value) {
            errors.push(new Error(msg));
          }
        }
      }

      callback(errors);
    };
  };

  return {
    useTab: true,
    cols: 7,
    tabs: [{
        tabLabel: "基金信息",
        tabKey: "basicInfomation",
        formConfig: {
          cols: 12,
          fields: [
            [{
              label: "基金全称",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                key: "fundName",
                compType: "vtext"
              }]
            }],
            [{
              label: "基金简称",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                key: "fundShortName",
                compType: "vinput",
                rules: [{
                    required: true,
                    type: "string",
                    message: "基金简称不能为空"
                  },
                  validateIsrepeat(
                    "datadis/fund/isFundNameRepeat",
                    "post",
                    "fundName",
                    "此简称已被使用",
                    1,
                    this.fundId ? {
                      fundId: this.fundId
                    } : {}
                  ),
                  validateNotContainInvalidWords([
                    ".",
                    "●",
                    "*",
                    " "
                  ])
                ],
                compConfig: {
                  placeholder: "请输入基金简称"
                },
              }]
            }],
            [{
              label: "备案编码",
              labelWidth: 100,
              colspan: 6,
              comps: [{
                key: "registerNumber",
                compType: "vtext"
              }]
            }],
            [{
              label: "母基金",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                key: "pFundId",
                compType: "vselect",
                compConfig: {
                  labelKey: "fundName",
                  valueKey: "fundId",
                  url: "datadis/company/getSelfFund"
                },
                // compType: "vselectRemote",
                // compConfig: {
                //   searchKey:"fundName",
                //   labelKey: "fundShortName",
                //   valueKey: "fundId",
                //   defaultLabel: this.pFundShortName,
                //   remoteUrl: "datadis/company/getSelfFund"
                // },
                rules: [
                  // validateRelatedRequired(
                  //   [1, true],
                  //   "istiered",
                  //   "母基金不得为空"
                  // ),
                  // validateRelatedRequired(
                  //   [1, true],
                  //   "masterFeederFund",
                  //   "母基金不得为空"
                  // )
                ]
              }]
            }],
            [{
              label: "成立日期",
              labelWidth: 100,
              colspan: 6,
              comps: [{
                key: "inceptionDate",
                compType: "vtext",
                // rules: [{required:true,message:'请选择成立日期'},
                //   validateLessThanSomedate(
                //     `${new Date().getFullYear()}-${1 +
                //       Number(new Date().getMonth())}-${1 +
                //       Number(new Date().getDate())}`,
                //     "成立日期不得大于当前日期"
                //   )
                // biggerThanRelateTime(
                //   "statusStartDate",
                //   "成立日期应大于等于募集开始时间",
                //   true
                // ),
                // biggerThanRelateTime(
                //   "statusEndDate",
                //   "成立日期应大于等于募集结束时间",
                //   true
                // )
                // ],
                compConfig: {
                  placeholder: "请选择成立日期"
                }
              }]
            }],
            [{
                label: "基金类型",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "fundType",
                  compType: "vtext",
                  // rules: [
                  //   { required: true, message: "基金类型不能为空" }
                  // ],
                  compConfig: {
                    options: getSessionOption("cFundType"),
                    valueKey: "param",
                    labelKey: "name"
                  }
                }]
              },
              {
                label: "基金形式",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "fundStructure",
                  compType: "vselect",
                  compConfig: {
                    // url: "common/config/cFundForm",
                    options: getSessionOption("cFundForm"),
                    valueKey: "param",
                    labelKey: "name"
                  },
                  rules: [{
                    required: true,
                    message: "基金形式不能为空"
                  }]
                }]
              }

              // {
              //   label: "注册国家",
              //   labelWidth: 100 ,
              //   hide: this.form["fundType"] != "7" ? true : false,
              //   comps: [
              //     {
              //       key: "domicile",
              //       compType: "vselect",
              //       compConfig: {
              //         // url: "common/config/cRegisterCountry",
              //         options: getSessionOption("cRegisterCountry"),
              //         valueKey: "param",
              //         labelKey: "name"
              //       },
              //       rules: [{ required: true, message: "注册国家不能为空" }]
              //     }
              //   ]
              // },
              // {
              //   label: "基础货币",
              //   labelWidth: 100 ,
              //   hide: this.form["fundType"] != "7" ? true : false,
              //   comps: [
              //     {
              //       key: "baseCurrency",
              //       compType: "vselect",
              //       compConfig: {
              //         // url: "common/config/cBasicCurrency",
              //         options: getSessionOption("cBasicCurrency"),
              //         valueKey: "param",
              //         labelKey: "name"
              //       },
              //       rules: [{ required: true, message: "基础货币不能为空" }]
              //     }
              //   ]
              // }
            ],
            [{
                label: `<span>基金策略</span><i class="fund-strategy-label" title='查看策略介绍'></i>`,
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "strategy",
                  compType: "vselect",
                  compConfig: {
                    options: (() => {
                      let strategy = getSessionOption(
                        "cFinancialStrategy"
                      );
                      strategy.pop();
                      return strategy;
                    })(),
                    valueKey: "param",
                    labelKey: "name"
                  },
                  rules: [{
                      required: true,
                      message: "请选择基金策略"
                    }
                    // validateValue(
                    //   ["-1"],
                    //   "strategy",
                    //   '基金策略不能选择"其他"'
                    // )
                  ]
                }]
              },
              {
                label: "子策略",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "substrategy",
                  compType: "vselect",
                  compConfig: {
                    valueKey: "param",
                    labelKey: "name",
                    options: this.substrategyOptions
                  },
                  rules: [{
                    required: true,
                    message: "请选择子策略"
                  }]
                }]
              }
            ],
            [{
                label: "初始规模",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "initialSize",
                  compType: "vinput",
                  rules: [{
                      required: true,
                      message: "初始规模不能为空"
                    },
                    validateBiggerThanSomeNumber(
                      100,
                      "请输入大于等于100的数字",
                      true
                    )
                  ],
                  compConfig: {
                    placeholder: "请输入",
                    unit: "万元",
                    // align:'right'
                    number: true,
                    floatPoint: 0
                  }
                }]
              },
              {
                label: "前端显示规模",
                labelWidth: 110,
                colspan: 6,
                comps: [{
                  key: "showInitialSize",
                  compType: "vswitch",
                  compConfig: {
                    type: "checkbox",
                    trueValue: 1,
                    falseValue: 0,
                    trueLabel: ""
                  },
                  compStyle: {
                    marginLeft: "-10px"
                  }
                }]
              }
            ],
            [{
                label: "警戒线",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "guardLine",
                  compType: "vinputSelect",
                  compConfig: {
                    selectConfig: {
                      options: [{
                        label: "未设置",
                        value: -1
                      }]
                    },
                    inputConfig: {
                      placeholder: "请输入",
                      unit: "%",
                      number: true
                    },
                    customLabel: "已设置"
                  },
                  // compStyle:{
                  //   width: '200px'
                  // },
                  rules: [{
                      required: true,
                      message: "警戒线不能为空"
                    },
                    validateBetweenTwoNumbers(
                      1,
                      100,
                      "请输入大于1且小于100的数字，可为小数",
                      false,
                      -1
                    )
                  ]
                }]
              },
              {
                label: "止损线",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "stopLossLine",
                  compType: "vinputSelect",
                  compConfig: {
                    selectConfig: {
                      options: [{
                        label: "未设置",
                        value: -1
                      }]
                    },
                    inputConfig: {
                      placeholder: "请输入",
                      unit: "%",
                      number: true
                    },
                    customLabel: "已设置"
                  },
                  // compStyle:{
                  //   width: '121px'
                  // },
                  rules: [{
                      required: true,
                      message: "止损线不能为空"
                    },
                    validateBetweenTwoNumbers(
                      1,
                      100,
                      "请输入大于1小于100的数字，可为小数",
                      false,
                      -1
                    )
                  ]
                }]
              }
            ],
            [{
                label: "最低认购额",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "minInvestmentShare",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入",
                    unit: "万元",
                    number: true,
                    floatPoint: 0
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];

                      if (value) {
                        if (parseFloat(value) < 0) {
                          errors.push(
                            new Error("最低认购额不能小于0")
                          );
                        }
                      }
                      callback(errors);
                    }
                  ]
                }]
              },
              {
                label: "最低追加额",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "subsequentInvestmentShare",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入",
                    unit: "万元",
                    number: true,
                    floatPoint: 0
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];

                      if (value) {
                        if (parseFloat(value) < 0) {
                          errors.push(
                            new Error("最低追加额不能小于0")
                          );
                        }
                      }
                      callback(errors);
                    }
                  ]
                }]
              }
            ],
            [{
                label: "认购费率",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "subscriptionFee",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入",
                    unit: "%",
                    number: true
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];

                      if (value) {
                        if (
                          parseFloat(value) < 0 ||
                          parseFloat(value) > 100
                        ) {
                          errors.push(new Error("请输入0~100的数字"));
                        }
                      }
                      callback(errors);
                    }
                  ]
                }]
              },
              {
                label: "赎回费率",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "redemptionFee",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入",
                    unit: "%",
                    number: true
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];

                      if (value) {
                        if (
                          parseFloat(value) < 0 ||
                          parseFloat(value) > 100
                        ) {
                          errors.push(new Error("请输入0~100的数字"));
                        }
                      }
                      callback(errors);
                    }
                  ]
                }]
              }
            ],
            [{
                label: "管理费率",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "managementfeeTrust",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入",
                    unit: "%",
                    number: true
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];

                      if (value) {
                        if (
                          parseFloat(value) < 0 ||
                          parseFloat(value) > 100
                        ) {
                          errors.push(new Error("请输入0~100的数字"));
                        }
                      }
                      callback(errors);
                    }
                  ]
                }]
              },
              {
                label: "业绩报酬",
                labelWidth: 100,
                colspan: 6,
                comps: [{
                  key: "performanceFee",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入",
                    unit: "%",
                    number: true
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];

                      if (value) {
                        if (
                          parseFloat(value) < 0 ||
                          parseFloat(value) > 100
                        ) {
                          errors.push(new Error("请输入0~100的数字"));
                        }
                      }
                      callback(errors);
                    }
                  ]
                }]
              }
            ],
            [{
                label: "是否分级",
                labelWidth: 100,
                colspan: 3,
                comps: {
                  key: "istiered",
                  compType: "vswitch",
                  compConfig: {
                    type: "checkbox",
                    falseValue: 0,
                    trueValue: 1,
                    trueLabel: ""
                  }
                }
              },
              {
                label: "分级说明",
                labelWidth: 100,
                hide: !this.form.istiered,
                align: "right",
                colspan: 9,
                align: "right",
                comps: [{
                  key: "istieredDesc",
                  compType: "vradio",
                  compConfig: {
                    options: [{
                        label: "优先级",
                        value: 1
                      },
                      {
                        label: "中间级",
                        value: 2
                      },
                      {
                        label: "劣后级",
                        value: 3
                      }
                    ]
                  }
                  // compStyle:{
                  //   align:'right'
                  // }
                }]
              }
            ],
            [{
              label: "优先/劣后比",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                  key: "priority",
                  compType: "vinput",
                  rules: [
                    validateBetweenTwoNumbers(
                      0,
                      100,
                      "请输入大于等于0小于等于100的数字",
                      true
                    )
                  ],
                  compConfig: {
                    number: true,
                    placeholder: "优先级"
                  }
                },
                {
                  key: "intermediate",
                  compType: "vinput",
                  rules: [
                    validateBetweenTwoNumbers(
                      0,
                      100,
                      "请输入大于等于0小于等于100的数字",
                      true
                    )
                  ],
                  compConfig: {
                    number: true,
                    placeholder: "中间级"
                  }
                },
                {
                  key: "posterior",
                  compType: "vinput",
                  rules: [
                    validateBetweenTwoNumbers(
                      0,
                      100,
                      "请输入大于等于0小于等于100的数字",
                      true
                    )
                  ],
                  compConfig: {
                    number: true,
                    placeholder: "次级"
                  }
                }
              ]
            }]
          ]
        }
      },
      {
        tabKey: "fundAuthority",
        tabLabel: "服务机构",
        formConfig: {
          cols: 12,
          fields: [
            [{
              label: "投资顾问",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                // key: "advisorName",
                key: "advisorName",
                compType: "vtext",
                // compConfig: {
                //   labelKey: "companyName",
                //   valueKey: "companyId",
                //   defaultLabel: this.brokerFutureName,
                //   remoteUrl: "datadis/company/getCacheCompany"
                // },
                rules: []
              }]
            }],
            [{
              label: "管理类型",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                key: "managerType",
                compType: "vradio",
                compConfig: {
                  options: [{
                      label: "顾问管理",
                      value: 1
                    },
                    {
                      label: "受托管理",
                      value: 2
                    },
                    {
                      label: "自我管理",
                      value: 3
                    }
                  ]
                }
              }]
            }],
            [{
              label: "管理人",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                key: "trustId",
                compType: "vselectRemote",
                compConfig: {
                  searchKey: "companyName",
                  labelKey: "companyShortName",
                  alternativeLabelKey: "companyName",
                  valueKey: "companyId",
                  defaultLabel: this.trustName,
                  remoteUrl: "datadis/company/getCacheCompany",
                  disabled: this.form.managerType != 1,
                  placeholder: this.form.managerType != 1 ? "" : "请输入关键字"
                }
              }]
            }],
            [{
              label: "托管机构",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                key: "custodianId",
                compType: "vselectRemote",
                compConfig: {
                  searchKey: "companyName",
                  labelKey: "companyShortName",
                  alternativeLabelKey: "companyName",
                  valueKey: "companyId",
                  defaultLabel: this.custodianName,
                  remoteUrl: "datadis/company/getCacheCompany"
                },
                rules: [validateCustodianId]
              }]
            }],
            [{
              label: "外包机构",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                key: "liquidationAgencyId",
                compType: "vselectRemote",
                compConfig: {
                  searchKey: "companyName",
                  labelKey: "companyShortName",
                  alternativeLabelKey: "companyName",
                  valueKey: "companyId",
                  defaultLabel: this.liquidationAgencyName,
                  remoteUrl: "datadis/company/getCacheCompany"
                },
                rules: [validateLiquidationAgencyId]
              }]
            }],
            [{
              label: "综合服务商",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                key: "generalServiceId",
                compType: "vselectRemote",
                compConfig: {
                  searchKey: "companyName",
                  labelKey: "companyShortName",
                  alternativeLabelKey: "companyName",
                  valueKey: "companyId",
                  defaultLabel: this.generalServiceName,
                  remoteUrl: "datadis/company/getCacheCompany"
                },
                rules: [validateGeneralServiceId]
              }]
            }],
            [{
              label: "证券经纪",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                key: "brokerId",
                compType: "vselectRemote",
                compConfig: {
                  searchKey: "companyName",
                  labelKey: "companyShortName",
                  alternativeLabelKey: "companyName",
                  valueKey: "companyId",
                  defaultLabel: this.brokerName,
                  remoteUrl: "datadis/company/getCacheCompany"
                },
                rules: [
                  validateBrokerIdRequired(),
                ]
              }]
            }],
            [{
              label: "期货经纪",
              labelWidth: 100,
              colspan: 12,
              comps: [{
                key: "brokerFutureId",
                compType: "vselectRemote",
                compConfig: {
                  searchKey: "companyName",
                  labelKey: "companyShortName",
                  alternativeLabelKey: "companyName",
                  valueKey: "companyId",
                  defaultLabel: this.brokerFutureName,
                  remoteUrl: "datadis/company/getCacheCompany"
                },
                rules: [
                  validateRelatedRequired(
                    ["2", "3", "5", "8"],
                    "strategy",
                    "期货经纪不能为空"
                  )
                ]
              }]
            }],
            [{
              label: "审计机构",
              labelWidth: 100,
              colspan: 12,
              hide: this.form["fundType"] != "7" ? true : false,
              comps: [{
                key: "auditorId",
                compType: "vselectRemote",
                compConfig: {
                  searchKey: "companyName",
                  labelKey: "companyShortName",
                  alternativeLabelKey: "companyName",
                  valueKey: "companyId",
                  defaultLabel: this.auditorName,
                  remoteUrl: "datadis/company/getCacheCompany"
                },
                rules: [{
                  required: true,
                  message: "审计机构不能为空"
                }]
              }]
            }],
            [{
              label: "法律顾问",
              labelWidth: 100,
              colspan: 12,
              hide: this.form["fundType"] != "7" ? true : false,
              comps: [{
                key: "legalCounselId",
                compType: "vselectRemote",
                compConfig: {
                  searchKey: "companyName",
                  labelKey: "companyShortName",
                  alternativeLabelKey: "companyName",
                  valueKey: "companyId",
                  defaultLabel: this.legalCounselName,
                  remoteUrl: "datadis/company/getCacheCompany"
                },
                rules: [{
                  required: true,
                  message: "法律顾问不能为空"
                }]
              }]
            }],
            [{
              label: "行政管理人",
              labelWidth: 100,
              colspan: 12,
              hide: this.form["fundType"] != "7" ? true : false,
              comps: [{
                key: "administratorId",
                compType: "vselectRemote",
                compConfig: {
                  searchKey: "companyName",
                  labelKey: "companyShortName",
                  alternativeLabelKey: "companyName",
                  valueKey: "companyId",
                  defaultLabel: this.administratorName,
                  remoteUrl: "datadis/company/getCacheCompany"
                },
                rules: [{
                  required: true,
                  message: "行政管理人不能为空"
                }]
              }]
            }]
          ]
        }
      },
      {
        tabLabel: "基金状态",
        tabKey: "fundStatus",
        formConfig: {
          cols: 2,
          fields: [
            // [
            //   {
            //     label: "募集开始日期",
            //     labelWidth: 100 ,
            //     comps: [
            //       {
            //         key: "statusStartDate",
            //         compType: "vdatePicker",
            //         rules: [
            //           validateRelatedRequired(
            //             ["1"],
            //             "fundStatus",
            //             "请选择募集开始日期"
            //           ),
            //           lessThanRelateTime(
            //             "statusEndDate",
            //             "募集开始日期应小于募集结束日期"
            //           )
            //         ],
            //         compConfig:{
            //           placeholder: '请选择募集开始日期'
            //         }
            //       }
            //     ]
            //   },
            //   {
            //     label: "募集结束日期",
            //     labelWidth: 100 ,
            //     comps: [
            //       {
            //         key: "statusEndDate",
            //         compType: "vdatePicker",
            //         rules: [
            //           biggerThanRelateTime(
            //             "statusStartDate",
            //             "募集结束日期应大于募集开始日期"
            //           )
            //         ],
            //         compConfig:{
            //           placeholder: '请选择募集结束时间'
            //         }
            //       }
            //     ]
            //   }
            // ],
            [{
                label: "基金运行状态",
                labelWidth: 110,
                colspan: 2,
                comps: [{
                  key: "fundStatus",
                  compType: "vradio",
                  compConfig: {
                    // url: "common/config/cFundOprateState",
                    options: [{
                        name: "开放运行",
                        param: 2
                      },
                      {
                        name: "封闭运行",
                        param: 3
                      },
                      {
                        name: "提前清算",
                        param: 4
                      },
                      {
                        name: "到期清算",
                        param: 5
                      }
                    ],
                    valueKey: "param",
                    labelKey: "name",
                  },
                  compStyle: {
                    marginLeft: "-10px"
                  },
                  rules: [{
                    required: true,
                    message: "运行状态不能为空"
                  }]
                }]
              },
              {
                label: "清算日期",
                labelWidth: 100,
                colspan: 1,
                hide: this.form["fundStatus"] != 4 &&
                  this.form["fundStatus"] != 5,
                comps: [{
                  key: "liquidateDate",
                  compType: "vdatePicker",
                  rules: [
                    validateRelatedRequired(
                      ["4", "5"],
                      "fundStatus",
                      "清算日期不能为空"
                    ),
                    biggerThanRelateTime(
                      "inceptionDate",
                      "清算日期应大于成立日期"
                    )
                  ],
                  compConfig: {
                    placeholder: "请选择清算日期"
                  },
                  compStyle: {
                    width: "150px"
                  }
                }]
              }
              // this.form["fundStatus"] == 4 ||
              //     this.form["fundStatus"] == 5?
              // {
              //   label: "清算日期",
              //   labelWidth: 100,
              //   comps: [
              //     {
              //       key: "liquidateDate",
              //       compType: "vdatePicker",
              //       rules: [
              //         validateRelatedRequired(
              //           ["4", "5"],
              //           "fundStatus",
              //           "清算日期不能为空"
              //         ),
              //         biggerThanRelateTime(
              //           "inceptionDate",
              //           "清算日期应大于成立日期"
              //         )
              //       ],
              //       compConfig: {
              //         placeholder: "请选择清算日期"
              //       },
              //       compStyle: {
              //         width: '100px',
              //       }
              //     }
              //   ]
              // }
              // :
              // {
              //    label:'',
              //    style: {
              //      height:0
              //    },
              // },
            ],
            [{
              label: "封闭期",
              labelWidth: 100,
              colspan: 2,
              comps: [{
                key: "lockupPeriod",
                compType: "vinputRadio",
                compConfig: {
                  radioConfig: {
                    options: [{
                      label: "未设置",
                      value: -1
                    }]
                  },
                  unit: "月",
                  number: true,
                  floatPoint: 0
                },
                rules: [
                  validateRelatedRequired(
                    ["1", "3", "4", "6", "8"],
                    "fundType",
                    "请填写封闭期"
                  ),
                  validateBiggerThanSomeNumberAndNotMinus1(
                    0,
                    "请输入大于等于0的数字",
                    true
                  )
                ]
              }]
            }],
            [{
              label: "存续期",
              labelWidth: 100,
              colspan: 2,
              comps: [{
                key: "duration",
                compType: "vinputRadio",
                compConfig: {
                  radioConfig: {
                    options: [{
                        label: "无固定期限",
                        value: 0
                      },
                      {
                        label: "永续",
                        value: 999999
                      }
                    ]
                  },
                  number: true,
                  floatPoint: 0,
                  unit: "月"
                },
                rules: [
                  validateRelatedRequired(
                    ["1", "3", "4", "6", "8"],
                    "fundType",
                    "请填写存续期"
                  ),
                  validateBiggerThanSomeNumberAndNotMinus1(
                    0,
                    "请输入大于等于0的数字",
                    true
                  )
                ]
              }]
            }],
            [{
              label: "开放日",
              labelWidth: 100,
              colspan: 2,
              comps: [{
                key: "fundOpenDay",
                row: true,
                compType: "OpenRedemptionSelector",
                rules: [
                  validateDayRelatedRequired(
                    ["1", "3", "4", "6", "8"],
                    "isRegularOpen",
                    "请填写开放日"
                  )
                ],
                compConfig: {
                  options: [{
                      label: "每个工作日都开放申购",
                      value: 1
                    },
                    {
                      label: "定期开放",
                      value: 2
                    }
                  ],

                  valueKey: "isRegularOpen",
                  showValue: 2,


                  monthKey: "openDayMonth",
                  weekKey: "openDayWeek",
                  dayKey: "openDayDaysWeeks",
                  orderKey: "openDayDaySeq",
                  typeKey: "openDayType",
                  dateKey: "openDayOther"

                }
              }]
            }],
            [{
              label: "开放日说明",
              labelWidth: 100,
              colspan: 2,
              comps: [{
                key: "openDay",
                compType: "vtextArea",
                rules: [
                  // validateDayRelatedRequired(
                  //   ["1", "3", "4", "6", "8"],
                  //   "fundType",
                  //   "请填写开放日"
                  // )
                ],
                compConfig: {
                  placeholder: "系统自动生成",
                  disabled: true
                }
              }]
            }],
            [{
              label: "赎回日",
              labelWidth: 100,
              colspan: 2,
              comps: [{
                key: "fundRedemptionDay",
                row: true,
                compType: "OpenRedemptionSelector",
                rules: [
                  validateDayRelatedRequired(
                    ["1", "3", "4", "6", "8"],
                    "fundType",
                    "isRegularRedemption",
                    "请填写赎回日"
                  )
                ],
                compConfig: {
                  options: [{
                      label: "每个工作日都开放赎回",
                      value: 1
                    },
                    {
                      label: "定期开放",
                      value: 2
                    }
                  ],

                  valueKey: "isRegularRedemption",
                  showValue: 2,
                  monthKey: "redemptionDayMonth",
                  weekKey: "redemptionDayWeek",
                  dayKey: "redemptionDayDaysWeeks",
                  orderKey: "redemptionDayDaySeq",
                  typeKey: "redemptionDayType",
                  dateKey: "redemptionDayOther"
                }
              }]
            }],
            [{
              label: "赎回日说明",
              labelWidth: 100,
              colspan: 2,
              comps: [{
                key: "redemptionDay",
                compType: "vtextArea",
                rules: [
                  // validateRelatedRequired(
                  //   ["1", "3", "4", "6", "8"],
                  //   "fundType",
                  //   "请填写赎回日"
                  // )
                ],
                compConfig: {
                  placeholder: "系统自动生成",
                  disabled: true
                }
              }]
            }]
          ]
        }
      },
      {
        tabLabel: "基金经理",
        tabKey: "managerMapping",
        custom: true,
        customComponent: fundManager
      },
      {
        tabLabel: "基金策略",
        tabKey: "fundStratety",
        formConfig: {
          cols: 1,
          fields: [
            [{
              label: "投资限制",
              labelWidth: 100,
              comps: [{
                key: "investmentRestriction",
                compType: "vtextArea",
                rules: [{
                  required: true,
                  message: "请填写投资限制"
                }],
                compConfig: {}
              }]
            }],
            [{
              label: "投资范围",
              labelWidth: 100,
              comps: [{
                key: "investmentScope",
                compType: "vtextArea",
                rules: [{
                  required: true,
                  message: "请填写投资范围"
                }]
              }]
            }],
            [{
              label: "投资策略",
              labelWidth: 100,
              comps: [{
                key: "fundStrategyDescription",
                compType: "vtextArea",
                rules: [{
                  required: true,
                  message: "请填写投资策略"
                }]
              }]
            }],
            [{
              label: "业绩基准指数",
              labelWidth: 100,
              hide: this.form["fundType"] != "3" ? true : false,
              comps: [{
                key: "secondaryBenchmark",
                compType: "vinput"
              }]
            }],
            [{
              label: "投资理念",
              labelWidth: 100,
              hide: this.form["fundType"] != "3" ? true : false,
              comps: [{
                key: "fundInvestmentPhilosophy",
                compType: "vtextArea"
              }]
            }],
            [{
              label: "投资决策流程",
              labelWidth: 100,
              hide: this.form["fundType"] != "3" ? true : false,
              comps: [{
                key: "investmentProcess",
                compType: "vtextArea"
              }]
            }],
            [{
              label: "产品特点",
              labelWidth: 100,
              hide: this.form["fundType"] != "3" ? true : false,
              comps: [{
                key: "fundCharacteristic",
                compType: "vtextArea"
              }]
            }],
            [{
              label: "投资目标",
              labelWidth: 100,
              hide: this.form["fundType"] != "3" ? true : false,
              comps: [{
                key: "investmentObjective",
                compType: "vtextArea"
              }]
            }],
            [{
              label: "资产配置比例",
              labelWidth: 100,
              hide: this.form["fundType"] != "3" ? true : false,
              comps: [{
                key: "fundPortfolio",
                compType: "vtextArea"
              }]
            }]
          ]
        }
      },
      {
        tabLabel: "附件管理",
        tabKey: "attachInfo",
        custom: true,
        customComponent: attachment
      },
      {
        tabLabel: "策略说明",
        tabKey: "strategyIntroduction",
        custom: true,
        customComponent: strategyIntroduction
      }
    ]
  }
}

export default formConfig;