function formWatchHandler(val) {
  //运行状态--成立日期
  if (val.fundStatus === "2" || val.fundStatus === "3") {
    $(".fund-info-modal div[item-key=inceptionDate]").addClass(
      "required"
    );
  } else {
    $(".fund-info-modal div[item-key=inceptionDate]").removeClass(
      "required"
    );
  }
  //基金类型 -- 备案编码
  // if (val.fundType === "6") {
  //   $(".fund-info-modal div[item-key=registerNumber]").addClass(
  //     "required"
  //   );
  // } else {
  //   $(".fund-info-modal div[item-key=registerNumber]").removeClass(
  //     "required"
  //   );
  // }
  //分级，master feeder fund -- 母基金
  // if (val.istiered === 1 || val.masterFeederFund === 1) {
  //   $(".fund-info-modal div[item-key=pFundId]").addClass("required");
  // } else {
  //   $(".fund-info-modal div[item-key=pFundId]").removeClass("required");
  // }
  //基金名称 -- 是否新三板
  // if (val.fundName && val.fundName.includes("新三板")) {
  //   $(".fund-info-modal div[item-key=isThird]").addClass("required");
  // } else {
  //   $(".fund-info-modal div[item-key=isThird]").removeClass("required");
  // }
  //基金类型 -- 管理人
  if (["1", "3", "4", "6", "8"].includes(val.fundType + "")) {
    $(".fund-info-modal div[item-key=trustId]").addClass("required");
  } else {
    $(".fund-info-modal div[item-key=trustId]").removeClass("required");
  }
  //基金类型 综合服务商 -- 托管机构
  if (
    ["1", "2", "3", "4", "6", "8"].includes(val.fundType + "") &&
    !val.generalServiceId
  ) {
    $(".fund-info-modal div[item-key=custodianId]").addClass("required");
  } else {
    $(".fund-info-modal div[item-key=custodianId]").removeClass(
      "required"
    );
  }
  //基金类型 ，综合服务商 托管机构 -- 外包机构
  if (
    ["1", "2", "3", "4", "6", "8"].includes(val.fundType + "") &&
    !val.generalServiceId &&
    val.custodianId
  ) {
    $(".fund-info-modal div[item-key=liquidationAgencyId]").addClass(
      "required"
    );
  } else {
    $(".fund-info-modal div[item-key=liquidationAgencyId]").removeClass(
      "required"
    );
  }
  //基金类型 外包机构 托管机构-- 综合服务商
  if (
    ["1", "2", "3", "4", "6", "8"].includes(val.fundType + "") &&
    !val.liquidationAgencyId &&
    val.custodianId
  ) {
    $(".fund-info-modal div[item-key=generalServiceId]").addClass(
      "required"
    );
  } else {
    $(".fund-info-modal div[item-key=generalServiceId]").removeClass(
      "required"
    );
  }
  //基金类型-- 证券经纪
  if (!["3", "6", "7", "8"].includes(val["strategy"] + "")) {
    if (["1", "3", "4", "6", "8"].includes(val.fundType + "")) {
      $(".fund-info-modal div[item-key=brokerId]").addClass("required");
    } else {
      $(".fund-info-modal div[item-key=brokerId]").removeClass("required");
    }
  } else {
    $(".fund-info-modal div[item-key=brokerId]").removeClass("required");
  }
  //基金策略-- 期货经纪
  if (["2", "3", "5", "8"].includes(val.strategy + "")) {
    $(".fund-info-modal div[item-key=brokerFutureId]").addClass(
      "required"
    );
  } else {
    $(".fund-info-modal div[item-key=brokerFutureId]").removeClass(
      "required"
    );
  }
  //运行状态-- 募集开始时间
  // if (["1"].includes(val.fundStatus)) {
  //   $(".fund-info-modal div[item-key=statusStartDate]").addClass(
  //     "required"
  //   );
  // } else {
  //   $(".fund-info-modal div[item-key=statusStartDate]").removeClass(
  //     "required"
  //   );
  // }
  //基金类型-- 封闭期
  if (["1", "3", "4", "6", "8"].includes(val.fundType + "")) {
    $(".fund-info-modal div[item-key=lockupPeriod]").addClass("required");
  } else {
    $(".fund-info-modal div[item-key=lockupPeriod]").removeClass(
      "required"
    );
  }
  //基金类型-- 存续期
  if (["1", "3", "4", "6", "8"].includes(val.fundType + "")) {
    $(".fund-info-modal div[item-key=duration]").addClass("required");
  } else {
    $(".fund-info-modal div[item-key=duration]").removeClass("required");
  }
  //运行状态-- 清算日期
  if (["4", "5"].includes(val.fundStatus + "")) {
    console.log(this)
    this.$nextTick(() => {
      $(".fund-info-modal div[item-key=liquidateDate]").addClass(
        "required"
      );
    });
  } else {
    $(".fund-info-modal div[item-key=liquidateDate]").removeClass(
      "required"
    );
  }
  //基金类型-- 赎回日
  if (["1", "3", "4", "6", "8"].includes(val.fundType + "")) {
    $(".fund-info-modal div[item-key=redemptionDay]").addClass(
      "required"
    );
  } else {
    $(".fund-info-modal div[item-key=redemptionDay]").removeClass(
      "required"
    );
  }
  //基金类型-- 开放日
  if (["1", "3", "4", "6", "8"].includes(val.fundType + "")) {
    $(".fund-info-modal div[item-key=openDay]").addClass("required");
  } else {
    $(".fund-info-modal div[item-key=openDay]").removeClass("required");
  }

  //基金类型-- 开放日
  if (["1", "3", "4", "6", "8"].includes(val.fundType + "")) {
    $(".fund-info-modal div[item-key=fundOpenDay]").addClass("required");
  } else {
    $(".fund-info-modal div[item-key=fundOpenDay]").removeClass("required");
  }

  //基金类型-- 赎回日
  if (["1", "3", "4", "6", "8"].includes(val.fundType + "")) {
    $(".fund-info-modal div[item-key=fundRedemptionDay]").addClass("required");
  } else {
    $(".fund-info-modal div[item-key=fundRedemptionDay]").removeClass("required");
  }

  if (val["fundStatus"] != 4 && val["fundStatus"] != 5) {
    val.liquidateDate = null;
  }
}
export default formWatchHandler;