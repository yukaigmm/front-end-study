<template>
  <vpart title="基金经理">
    <div slot="search"></div>
    <div slot="action">
      <vbutton active title="添加收藏" @click="addFundManager">新增</vbutton>
    </div>
    <vtable :key="key" :data="value" :columns="columnsConfig" ref="fundManagerTable" width="100%"></vtable>
  </vpart>
</template>

<script>
export default {
  components: {
    // toast
  },
  props: {
    value: {
      type: [Array, Object],
      default: () => []
    }
  },
  data() {
    return {
      key: "",
      validKey: [],
      validItems: [],
      managerOptions: []
    };
  },

  computed: {
    columnsConfig() {
      return [
        {
          title: "基金经理",
          key: "fundManagerId",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                tableRow: row,
                comps: {
                  key: "fundManagerId",
                  compType: "vselect",
                  compConfig: {
                    options: this.managerOptions
                  },
                  rules: [
                    { required: true, message: "请填写基金经理" },
                    (rule, value, callback) => {
                      let errors = [];
                      let tableData = this.value.filter((item, i) => {
                        return i !== index;
                      });
                      let isRepeat = tableData.some((item, i) => {
                        return item.fundManagerId === value;
                      });
                      if (isRepeat) {
                        errors.push("重复的基金经理");
                      }
                      callback(errors);
                    }
                  ],
                  validate: false
                },
                value: row.fundManagerId
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `fundManagerId-${index}`
            });
          }
        },
        {
          title: "管理开始时间",
          key: "managementStartDate",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                tableRow: row,
                comps: {
                  compType: "vdatePicker",
                  key: "managementStartDate",
                  rules: [{ required: true, message: "管理开始时间不能为空" }],
                  compConfig: {
                    placeholder: "请选择管理开始时间"
                  }
                },
                value: row.managementStartDate
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `managementStartDate-${index}`
            });
          }
        },
        {
          title: "管理结束时间",
          key: "managementEndDate",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                tableRow: row,
                comps: {
                  compType: "vdatePicker",
                  key: "managementEndDate",
                  rules: [
                    (rule, value, callback, source, options) => {
                      let errors = [];
                      let ruleDate = new Date(
                        row.managementStartDate
                      ).getTime();
                      let valueDate = new Date(value).getTime();
                      if (value && valueDate <= ruleDate) {
                        errors.push(
                          new Error("管理结束时间必须大于管理开始时间")
                        );
                      }

                      callback(errors);
                    }
                  ],
                  compConfig: {
                    placeholder: "管理结束时间"
                  }
                },
                value: row.managementEndDate
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `startDate-${index}`
            });
          }
        },
        {
          title: "操作",
          key: "action",
          align: "center",
          showOverflowTooltip: false,
          width: 58,
          render: (h, { row, column, index }) => {
            // return h("vbutton", {
            //   class: "highlight",
            //   props: {
            //     onlyIcon: true,
            //     icon: "icon-delete ",
            //     iconSize:"28px",
            //   },
            //   attrs:{
            //     title:"删除"
            //   },
            //   on: {
            //     click: () => {
            //       this.deleteRow(index, row);
            //     }
            //   }
            // });
            return h('div', {
              class: "table-action-button-container"
            }, [
              h("vbuttonSprite", {
                props: {
                  pos: {
                    normal: { x: 0, y: -241 },
                    hover: { x: -18, y: -241 },
                    disabled: { x: -36, y: -241 }
                  },
                  title: "删除"
                },
                style: {
                  verticalAlign: "middle",
                },
                on: {
                  click: e => {
                    this.deleteRow(index, row);
                  }
                }
              })
            ])
          }
        }
      ];
    }
  },

  mounted() {
    this.$http
      .post("datadis/company/getSelfPersonnel", { personnelType: [1] })
      .then(res => {
        this.managerOptions = res.data.map(item => ({
          label: `${item.personnelName}`,
          value: `${item.personnelId}`
        }));
      });
  },

  // mounted() {
  // this.validKey = this.columnsConfig.map(item => {
  //   return item.comps.key;
  // });
  // },
  watch: {
    value: {
      handler(val) {
        this.key = Date.now();
        this.$emit("input", val);
        this.$emit("change", val);
      },
      deep: true
    }
  },
  methods: {
    onTableCellChange(val, data, column, index) {
      console.log("change")
      data[column.property] = val;
    },
    // 获取验证的项目
    // getValidItems() {
    //   this.validItems = [];
    //   this.validKey.forEach(item => {
    //     if (this.value.length) {
    //       this.value.forEach((tableItem, index) => {
    //         this.validItems.push(`${item}-${index}`);
    //       });
    //     } else {
    //       this.validItems = [];
    //     }
    //   });
    // },

    // 提交验证
    valid() {
      let that = this;
      return new Promise(resolve => {
        let formItemValid = true;
        let length = 0;
        let valids = [];
        if (that.value.length) {
          valids = that.$refs.fundManagerTable.getRefs();
        }
        new Promise(resolve => {
          if (valids && valids.length) {
            valids.forEach((item, index) => {
              if (item && item.valid) {
                item.valid().then(valid => {
                  length++;
                  if (!valid) {
                    formItemValid = false;
                  }
                  if (length === valids.length) {
                    resolve(formItemValid);
                  }
                });
              } else {
                length++;
                if (length === valids.length) {
                  resolve(formItemValid);
                }
              }
            });
          } else {
            resolve(true);
          }
        }).then(valid => {
          resolve(valid);
        });
      });
    },
    resetValid() {
      if (!this.value.length) {
        return;
      }
      let valids = this.$refs.fundManagerTable.getRefs();
      if (valids.length) {
        valids.forEach(item => {
          if (item) {
            item.resetValid();
          }
        });
      }
    },

    // 设置表格行样式
    // tableRowClassName({ row, rowIndex }) {
    //   if (rowIndex % 2 === 1) {
    //     return "odd-row";
    //   } else {
    //     return "even-row";
    //   }
    // },
    // 删除内容
    deleteRow(index, row) {
      this.$confirm("确定删除吗？", "删除", {
        showCancelButton: true,
        type: "warning",
        closeOnClickModal: false,
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            instance.confirmButtonLoading = true;
            instance.confirmButtonText = "删除中...";
            this.$delete(this.value, index);
            this.$emit("change", this.value);
            this.$message({
              showClose: true,
              message: "删除成功,点击保存之后将会生效",
              type: "success"
            });
            instance.confirmButtonLoading = false;
            done();
          } else {
            done();
          }
        }
      });
    },

    // 添加内容
    addFundManager() {
      this.$set(this.value, this.value.length, {
        fundManagerId: "",
        managementEndDate: "",
        managementStartDate: ""
      });
    }
  }
};
</script>

<style lang="less" scoped>
.cell-edit-color {
  color: #2db7f5;
  font-weight: bold;
  border: 1px solid #2db7f5;
}
</style>
