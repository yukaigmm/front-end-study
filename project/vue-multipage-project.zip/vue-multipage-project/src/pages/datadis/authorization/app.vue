<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
    <div slot style="height: 100%;" class="authorzation-container">
      <vpart title="授权信息" style="height: 100%;">
        <div slot="search">
          <vselect v-model="searchForm.authStatus" :options="statusOptions" @change="search"></vselect>
          <vinput
            type="text"
            class="table-search-input"
            style="display: inline-block"
            @keyup.enter.native="search"
            v-model="searchForm.keyword"
            placeholder="关键字搜索(基金ID/全称/简称/管理人)"
          ></vinput>
          <vbutton active title="搜索" @click="search">搜索</vbutton>
        </div>
        <div slot="action"></div>
        <vtable
          ref="table"
          :columns="columns"
          :data="tableData"
          :usePagination="true"
          :totalItem="totalItem"
          :currentPage="pageNo"
          :maxHeight="maxHeight"
          :pageSize="pageSize"
          @pageChange="pageChange"
          @pageSizeChange="pageSizeChange"
          :changeRowColor="true"
          @tableRowClick="tableRowClick"
        ></vtable>
        <vloading class="loading" v-model="loading"></vloading>
        <vreload v-model="reload" @reload="getList"></vreload>
      </vpart>
      <actionRecord ref="actionRecord"></actionRecord>
    </div>
  </vcommon>
</template>


<script>
import actionRecord from "./action-record.vue";
import tableHeight from "../../../common/mixins/table-height";
import pageView from "../../../common/mixins/pageView";
import {getUrlParams} from "../../../common/js/utils.js";
export default {
  mixins: [tableHeight, pageView],
  components: {
    actionRecord
  },
  data() {
    return {
      currentMenuParentKey: "datadis",
      currentMenuChildKey: "authorization",
      loading: false,
      reload: false,
      searchForm: {
        authStatus: 0,
        keyword: ""
      },
      statusOptions: [
        {
          value: 0,
          label: "全部"
        },
        {
          value: 1,
          label: "未授权"
        },
        {
          value: 2,
          label: "已授权"
        },
        {
          value: 3,
          label: "已取消授权"
        },
        {
          value: 4,
          label: "已重新授权"
        },
        {
          value: 5,
          label: "已拒绝"
        },
        {
          value: 6,
          label: "已撤销"
        }
      ],
      statusOptionsMap: {
        0: "全部",
        1: "未授权",
        2: "已授权",
        3: "已取消授权",
        4: "已重新授权",
        5: "已拒绝",
        6: "已撤销",
      },
      tableData: [],
      columns: [
        {
          title: "申请人",
          key: "applyUserName",
          width: 90,
          render: (h, {row}) => {
            return h("span", row.applyUserName||"--")
          }
        },
        {
          title: "申请机构",
          key: "applyCompanyName",
          width: 160,
          render: (h, {row}) => {
            return h("span", row.applyCompanyName||"--")
          }
        },
        {
          title: "职位",
          key: "position",
          width: 160,
          render: (h, {row}) => {
            return h("span", row.position||"--")
          }
        },
        {
          title: "部门",
          key: "deptName",
          width: 160,
          render: (h, {row}) => {
            return h("span", row.deptName||"--")
          }
        },
        {
          title: "申请日期",
          key: "applyDate",
          width: 90,
          align: "right",
          render: (h, { row }) => {
            let date = row.applyDate ? row.applyDate.split(" ")[0] : "--";
            return h("span", date);
          }
        },
        {
          title: "申请内容",
          key: "authInfo",
          render: (h, {row}) => {
            return h("span", row.authInfo||"--")
          }
        },
        {
          title: "基金简称",
          key: "authFundName",
          width: 180,
          render: (h, {row}) => {
            return h("span", row.authFundName||"--")
          }
        },
        {
          title: "授权状态",
          key: "authStatus",
          width: 90,
          render: (h, { row }) => {
            return h("span", this.statusOptionsMap[row.authStatus]);
          }
        },
        {
          title: "操作人",
          key: "handleUserName",
          width: 90,
          render: (h, { row }) => {
            return h("span", row.handleUserName || "--");
          }
        },
        {
          title: "操作时间",
          key: "handleDate",
          width: 90,
          align: "right",
          render: (h, { row }) => {
            let date = row.handleDate ? row.handleDate.split(" ")[0] : "--";
            return date;
          }
        },
        {
          title: "操作",
          key: "action",
          fixed: "right",
          align: "center",
          showOverflowTooltip: false,
          width: 180,
          render: (h, { row }) => {
            let arr = [];

            if (row.authStatus === 1) {
              //未授权 显示 同意/拒绝 按钮
              let buttonAgree = h(
                "vbutton",
                {
                  class: ["agree"],
                  on: {
                    click: () => {
                      this.agreeAuthorize(row.id);
                    }
                  },
                  attrs: {
                    active: true
                  }
                },
                "同意"
              );
              let buttonRefuse = h(
                "vbutton",
                {
                  class: ["refuse"],
                  on: {
                    click: () => {
                      this.refuseAuthorize(row.id);
                    }
                  },
                  attrs: {
                    active: true
                  }
                },
                "拒绝"
              );
              arr.push(buttonAgree);
              arr.push(buttonRefuse);
            } else if (row.authStatus === 2) {
              //已授权 显示 取消授权 按钮
              let buttonCancel = h(
                "vbutton",
                {
                  class: ["cancel"],
                  on: {
                    click: () => {
                      this.cancelAuthorize(row.id);
                    }
                  },
                  attrs: {
                    active: true
                  }
                },
                "取消授权"
              );
              arr.push(buttonCancel);
            } else if (row.authStatus === 3) {
              //已取消授权 显示 重新授权 按钮
              let buttonReAgree = h(
                "vbutton",
                {
                  class: ["re-agree"],
                  on: {
                    click: () => {
                      this.reAuthorize(row.id);
                    }
                  },
                  attrs: {
                    active: true
                  }
                },
                "重新授权"
              );
              arr.push(buttonReAgree);
            } else if (row.authStatus === 4) {
              //已重新授权 显示 取消授权 按钮
              let buttonCancel = h(
                "vbutton",
                {
                  class: ["cancel"],
                  on: {
                    click: () => {
                      this.cancelAuthorize(row.id);
                    }
                  },
                  attrs: {
                    active: true
                  }
                },
                "取消授权"
              );
              arr.push(buttonCancel);
            } else if (row.authStatus === 5) {
              //已拒绝 不显示任何按钮 无法进行后续操作
            }else if (row.authStatus === 6){
              //已撤销 不显示任何按钮 无法进行后续操作
            }

            //最后添加 操作记录 按钮
            let buttonRecord = h(
              "vbutton",
              {
                on: {
                  click: () => {
                    this.showActionRecord(row.id);
                  }
                }
              },
              "操作记录"
            );
            arr.push(buttonRecord);
            return h("div", { 
              class: "table-action-button-container",
              style: {
                color: "#eee"
              }
              }, arr);
          }
        }
      ],
      totalItem: "",
      pageNo: 1,
      pageSize: 20
    };
  },
  methods: {
    search() {
      this.getList();
    },
    getList() {
      let params = JSON.parse(JSON.stringify(this.searchForm));
      params.pageNo = this.pageNo;
      params.pageSize = this.pageSize;
      this.loading = true;
      this.$http.get("masterAuth", params).then(res => {
        this.loading = false;
        if (res && res.code === 20000) {
          this.tableData = res.data.records;
          this.totalItem = res.data.total;
        }else{
          let msg = res && res.msg ? res.msg : "数据加载失败，请点击重新加载";
          this.$message.error(msg);
          this.reload = true;
          this.tableData = [];
        }
        // let mockData = [
        //   { id: 1, authStatus: 1},
        //   { id: 2, authStatus: 2},
        //   { id: 3, authStatus: 3},
        //   { id: 4, authStatus: 4},
        // ];
        // this.tableData = mockData;
        // this.totalItem = mockData.length;
      });
    },
    pageChange(val) {
      this.pageNo = val;
      this.getList();
    },
    pageSizeChange(val) {
      this.pageSize = val;
      this.getList();
    },
    tableRowClick({ row, column, index }) {
      this.currentRowId = row.id;
      this.$refs.table.setCurrentRow("id", this.currentRowId);
    },
    //同意授权
    agreeAuthorize(id) {
      this.setAuthorizeStatus(id, 2).then(() => {
        this.getList();
      });
    },
    //拒绝授权
    refuseAuthorize(id) {
      this.setAuthorizeStatus(id, 5).then(() => {
        this.getList();
      });
    },
    //取消授权
    cancelAuthorize(id) {
      this.setAuthorizeStatus(id, 3).then(() => {
        this.getList();
      });
    },
    //重新授权
    reAuthorize(id) {
      this.setAuthorizeStatus(id, 4).then(() => {
        this.getList();
      });
    },
    //设置授权状态
    setAuthorizeStatus(id, status) {
      return new Promise((resolve, reject) => {
        this.$http
          .post(`masterAuth/change/${id}`, {
            authId: id,
            authStatus: status
          })
          .then(res => {
            if (res.code === 20000) {
              this.$message.success("操作成功");
              resolve();
            }
          });
      });
    },
    //展示操作记录
    showActionRecord(id) {
      this.$refs.actionRecord.show(id);
    }
  },
  mounted() {
    // this.getList();

    let params = getUrlParams();
    // 初始化时，根据url判断是否是从消息通知页面跳转过来的.
    // 如果是，则改变查询条件，根据（keyWord）查询到对应的机会信息，
    if(params.keyWord){
      this.searchForm.authStatus = 0;
      this.searchForm.keyword = decodeURI(params.keyWord);
      this.currentRowId = +params.id;
      this.$refs.table.setCurrentRow("id", this.currentRowId);
      this.getList();
    }else{
      this.getList()
    }
    
  }
};
</script>


<style lang="less">
.authorzation-container {
  .table-action-button-container {
    .action-button {
      margin-right: 5px;
      cursor: pointer;
      &.cancel,
      &.re-agree {
        margin-right: 10px;
      }
      &:hover {
        color: #2992ff;
      }
    }
  }
}
</style>


