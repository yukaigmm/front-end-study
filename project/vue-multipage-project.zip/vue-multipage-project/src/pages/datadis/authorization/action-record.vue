<template>
  <vmodal
    class="ahthorization-record-modal t2-el-dialog"
    ref="modal"
    @close="cancel"
    title="操作记录"
    :width="560"
  >
    <vloading v-model="loading" class="loading"></vloading>
    <div slot="modal-footer">
      <vbutton active @click="close">关闭</vbutton>
    </div>

    <div class="table-container">
      <vtable ref="table" :columns="columns" :data="tableData" :changeRowColor="true"></vtable>
    </div>
  </vmodal>
</template>

<script>
export default {
  data() {
    return {
      loading: false,
      tableData: [],
      columns: [
        {
          title: "操作人",
          key: "handleUserName"
        },
        {
          title: "操作时间",
          key: "handleDate"
        },
        {
          title: "操作内容",
          key: "handleContent",
          render: (h, { row }) => {
            let map = {
              1: "",
              2: "同意授权",
              3: "取消授权",
              4: "重新授权",
              5: "拒绝",
              6: "撤销"
            };
            return map[row.authStatus] || "--";
          }
        }
      ]
    };
  },
  methods: {
    open() {
      this.$refs.modal.open();
    },
    close() {
      this.$refs.modal.close();
    },
    show(id) {
      this.open();
      this.getHandleList(id);
    },
    cancel () {
      this.close();
    },
    getHandleList(id) {
      this.loading = true;
      this.$http.get(`masterAuth/handle/${id}`).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          this.tableData = res.data.records;
        }
      });
    }
  }
};
</script>


<style lang="less" scoped>
</style>

