<template>
  <vpart title="教育背景">
    <div slot="search"></div>
    <div slot="action">
      <vbutton active title="添加教育背景" @click="addEducationBg">新增</vbutton>
    </div>
    <vtable :key="key" ref="educatonTable" :columns="columnsConfig" :data="value" width="100%"></vtable>
  </vpart>
</template>

<script>
export default {
  components: {},

  props: {
    value: {
      type: [Array, Object],
      default: () => []
    },
    fieldKey: {
      type: String
    }
  },

  data() {
    return {
      options: [],
      key: "",
      validKey: [],
      validItems: [],
      columnsConfig: [
        {
          title: "起始日期",
          key: "startDate",
          width: 110,
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                tableRow: row,
                comps: {
                  compType: "vselect",
                  key: "startDate",
                  compConfig: {
                    options: this.options
                  },
                  rules: [
                    { required: true, message: "起始日期不能为空" },
                    (rule, value, callback) => {
                      let errors = [];
                      let startDate = row.startDate;
                      let endDate = row.endDate;
                      if (startDate > endDate && endDate != "") {
                        errors.push(new Error("起始日期不能大于毕业日期"));
                      } else {
                        errors = [];
                      }
                      callback(errors);
                    }
                  ]
                },
                value: row.startDate
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `startDate-${index}`
            });
          }
        },
        {
          title: "毕业日期",
          width: 110,
          showOverflowTooltip: false,
          key: "endDate",
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                tableRow: row,
                comps: {
                  compType: "vselect",
                  key: "endDate",
                  compConfig: {
                    options: this.options
                  },
                  rules: [
                    { required: true, message: "毕业日期不能为空" },
                    (rule, value, callback) => {
                      let errors = [];
                      let startDate = row.startDate;
                      let endDate = row.endDate;
                      if (startDate > endDate && endDate != "") {
                        errors.push(new Error("毕业日期不能小于起始日期"));
                      } else {
                        errors = [];
                      }
                      callback(errors);
                    }
                  ]
                },
                value: row.endDate
              },

              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `endDate-${index}`
            });
          }
        },
        {
          title: "学校",
          key: "schoolName",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                comps: {
                  compType: "vinput",
                  key: "schoolName",
                  rules: [{ required: true, message: "学校不能为空" }],
                  compConfig: {
                    placeholder: "请输入学校"
                  }
                },
                value: row.schoolName
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `schoolName-${index}`
            });
          }
        },
        {
          title: "专业",
          key: "professionName",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                comps: {
                  compType: "vinput",
                  key: "professionName",
                  compConfig: {
                    placeholder: "请输入专业"
                  }
                },
                value: row.professionName
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `professionName-${index}`
            });
          }
        },
        {
          title: "学历",
          width: 110,
          key: "educationType",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                comps: {
                  compType: "vselect",
                  key: "educationType",
                  rules: [{ required: true, message: "学历不能为空" }],
                  compConfig: {
                    options: [
                      {
                        label: "专科",
                        value: 1
                      },
                      {
                        label: "本科",
                        value: 2
                      },
                      {
                        label: "硕士",
                        value: 3
                      },
                      {
                        label: "博士",
                        value: 4
                      }
                    ]
                  }
                },
                value: row.educationType
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `educationType-${index}`
            });
          }
        },
        {
          title: "操作",
          key: "action",
          width: 58,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h('div', {
              class: "table-action-button-container"
            }, [
              h("vbuttonSprite", {
                props: {
                  pos: {
                    normal: { x: 0, y: -241 },
                    hover: { x: -18, y: -241 },
                    disabled: { x: -36, y: -241 }
                  },
                  title: "删除"
                },
                style: {
                  verticalAlign: "middle",
                },
                on: {
                  click: e => {
                    this.deletRow(index, row);
                  }
                }
              })
            ]) 
          }
        }
      ]
    };
  },
  mounted() {
    this.validKey = this.columnsConfig.map(item => {
      return item.key;
    });
    this.options = this.getDateOptions();
  },
  watch: {
    value: {
      handler(val) {
        this.key = Date.now();
        this.$emit("input", val);
        this.$emit("change", val, this.fieldKey);
      },
      deep: false
    }
  },

  methods: {
    onTableCellChange(val, data, column, index) {
      data[column.property] = val;
    },
    // 设置表格行样式
    tableRowClassName({ row, rowIndex }) {
      if (rowIndex % 2 === 1) {
        return "odd-row";
      } else {
        return "even-row";
      }
    },
    // 删除内容
    deletRow(index, row) {
      this.$confirm("确定删除吗？", "删除", {
        showCancelButton: true,
        type: "warning",
        closeOnClickModal: false,
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            instance.confirmButtonLoading = true;
            instance.confirmButtonText = "删除中...";
            this.$delete(this.value, index);
            this.$emit("change", this.value, this.fieldKey);
            this.$message({
              showClose: true,
              message: "删除成功,点击保存之后将会生效",
              type: "success"
            });
            instance.confirmButtonLoading = false;
            done();
          } else {
            done();
          }
        }
      });
    },

    // 添加内容
    addEducationBg() {
      this.$set(this.value, this.value.length, {
        startDate: "",
        endDate: "",
        schoolId: "",
        professionId: "",
        educationType: ""
      });
    },
    getValidItems() {
      this.validItems = [];
      this.validKey.forEach(item => {
        if (this.value.length) {
          this.value.forEach((subitem, index) => {
            this.validItems.push(`${item}-${index}`);
          });
        } else {
          this.validItems = [];
        }
      });
    },
    // 提交验证
    valid() {
      let that = this;
      return new Promise(resolve => {
        let formItemValid = true;
        let valids = [];
        if (that.value.length) {
          valids = that.$refs.educatonTable.getRefs();
        }

        new Promise(resolve => {
          if (valids && valids.length) {
            valids.forEach((item, index) => {
              item.valid().then(valid => {
                length++;
                if (!valid) {
                  formItemValid = false;
                }
                if (index === valids.length-1) {
                  if (formItemValid) {
                    resolve(true);
                  } else {
                    resolve(false);
                  }
                }
              });
            });
          } else {
            resolve(true);
          }
        }).then(valid => {
          resolve(valid);
        });
      });
    },
    resetValid() {
      if (!this.value.length) {
        return;
      }
      let valids = this.$refs.educatonTable.getRefs();
      if (valids.length) {
        valids.forEach(item => {
          if (item) {
            item.resetValid();
          }
        });
      }
    },
    getDateOptions() {
      let endYear = new Date().getFullYear();
      let options = [];
      for (let i = endYear; i >= 1970; i--) {
        options.push({ label: i, value: i });
      }
      return options;
    }
  }
};
</script>

<style lang="less" scoped>
.cell-edit-color {
  color: #2db7f5;
  font-weight: bold;
  border: 1px solid #2db7f5;
}
</style>
