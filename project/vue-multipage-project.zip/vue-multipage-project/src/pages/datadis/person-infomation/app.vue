<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
    <div slot style="height: 100%;">
      <vpart title="公司人员信息">
        <div slot="search">
          <vselect
            v-model="searchFormValue.isLeave"
            @change="personStatusChange"
            :options="personStatusOption"
          ></vselect>
          <vinput
            type="text"
            class="table-search-input"
            style="display: inline-block;"
            @keyup.enter.native="searchPerson"
            v-model="searchFormValue.keyWord"
            placeholder="关键字搜索(姓名/手机号)"
          ></vinput>
          <vbutton active title="搜索" @click="searchPerson">搜索</vbutton>
        </div>
        <div slot="action">
          <vbutton active title="添加人员" @click="addPerson">新增</vbutton>
        </div>
        <vtable
          ref="table"
          :columns="columns"
          :data="tableData"
          :maxHeight="maxHeight"
          :usePagination="true"
          layout="total"
          :totalItem="totalItem"
          :draggable="true"
          :dragTitleExplains="['拖动该列图标可进行排序', '当无搜索排序或者过滤条件时才可拖动', '官网显示顺序与页面显示顺序一致']"
          :currentRowIndex="currentRowIndex"
          :changeRowColor="true"
          @sort="dragSort"
          @tableRowClick="tableRowClick"
        ></vtable>
        <vloading class="loading" v-model="loading" :title="loadingTitle"></vloading>
        <vreload class="reload" v-model="reload" @reload="getPersonList"></vreload>
      </vpart>

      <!-- 新增和修改人物modal -->
      <personModal ref="personModal" @getPersonList="getPersonList"></personModal>

      <!-- 删除人物modal -->
      <vmodal
        ref="delModal"
        class="t2-el-dialog"
        :currentPersonId="currentPersonId"
        @close="cancel"
      >
        <div slot="modal-footer">
          <a class="waves-effect waves-light btn" @click="cancel">取消</a>
          <a class="waves-effect waves-light btn highlight" @click="confirm">确定</a>
        </div>
      </vmodal>

      <!-- 离职 modal-->
      <vmodal
        ref="dimissionModal"
        :title="`离职`"
        :width="300"
        class="dimission-modal t2-el-dialog"
        @close="closeDimission"
      >
        <div class="date-picker-container">
          <vformConfig :config="dimissionConfig" ref="dimissionForm" v-model="dimissionValue"></vformConfig>
        </div>
        <div slot="modal-footer">
          <vbutton @click="closeDimission">取消</vbutton>
          <vbutton active @click="confirmDimission">确认</vbutton>
        </div>
      </vmodal>
    </div>
  </vcommon>
</template>

<script>
import $ from "jquery";
import _ from "lodash";
import tableHeight from "../../../common/mixins/table-height.js";
import personModal from "./person-modal.vue";
import { getSessionOption, getUrlParams } from "../../../common/js/utils";
import pageView from "../../../common/mixins/pageView";
export default {
  components: {
    personModal
    // toast
  },
  mixins: [tableHeight, pageView],
  data() {
    return {
      currentCompany: "",
      totalItem: 0,
      page: 1,
      pageSize: -1,
      currentMenuParentKey: "datadis",
      currentMenuChildKey: "personInfomation",
      loading: true,
      userEditable: true,
      reload: false,
      dimissionConfig: {
        cols: 1,
        fields: [
          [
            {
              label: "离职时间",
              labelWidth: 90,
              colspan: 1,
              comps: {
                key: "endDate",
                compType: "vdatePicker",
                rules: [{ required: true, message: "请选择离职时间" }]
              }
            }
          ]
        ]
      },
      dimissionValue: {},
      personStatusOption: [
        {
          label: "全部",
          value: -1
        },
        {
          label: "在职",
          value: 0
        },
        {
          label: "离职",
          value: 1
        }
      ],
      currentPersonId: "",
      status: "add",
      searchFormValue: {
        isLeave: 0,
        keyWord: ""
      },
      columns: [
        {
          key: "personnelName",
          title: "姓名",
          render: (h, { row, column, index }) => {
            return h("span", row.personnelName || "--");
          }
        },
        {
          key: "position",
          title: "当前职位",
          render(h, { row }) {
            return row.position || "--";
          }
        },
        // {
        //   key: "position",
        //   title: "职业背景"
        // },
        {
          key: "mobile",
          title: "手机",
          align: "right",
          render(h, { row }) {
            return row.mobile || "--";
          }
        },
        // {
        //   key: "auditstate",
        //   title: "审核状态",
        //   render(h, { row }) {
        //     let map = {
        //       "0": "未审核",
        //       "1": "已审核",
        //       "2": "新增申请中",
        //       "3": "更新申请中",
        //       "4": "删除申请中",
        //       "5": "未通过",
        //       "-1": "草稿"
        //     };

        //     return map[row.auditstate];
        //   }
        // },
        {
          key: "isLeave",
          title: "人员状态",
          render(h, { row }) {
            let map = {
              "0": "在职",
              "1": "离职"
            };

            return map[row.isLeave] || "--";
          }
        },
        {
          key: "action",
          title: "操作",
          width: 134,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            let self = this;
            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                //编辑
                h("vbuttonSprite", {
                  props: {
                    pos: {
                      normal: { x: 0, y: -19 },
                      hover: { x: -18, y: -19 },
                      disabled: { x: -36, y: -19 }
                    },
                    title: "编辑"
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      self.openModifyPersonModal(index, row);
                    }
                  }
                }),
                //删除
                h("vbuttonSprite", {
                  props: {
                    pos: {
                      normal: { x: 0, y: -241 },
                      hover: { x: -18, y: -241 },
                      disabled: { x: -36, y: -241 }
                    },
                    title: "删除"
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      self.deletePerson(index, row);
                    }
                  }
                }),
                //离职
                h("vbuttonSprite", {
                  props: {
                    disabled: row.isLeave === 1,
                    pos: {
                      normal: { x: 0, y: -277 },
                      hover: { x: -18, y: -277 },
                      disabled: { x: -36, y: -277 }
                    },
                    title: "离职"
                  },
                  style: {
                    verticalAlign: "middle"
                  },
                  on: {
                    click: e => {
                      this.dismissPerson(index, row);
                    }
                  }
                })
              ]
            );
          }
        }
      ],
      tableData: [],
      currentRowIndex: -1,
      recordId: "",
      recordKey: "",
      loadingTitle: "加载中..."
    };
  },
  mounted() {
    // 初始化时，根据url判断是否是从消息通知页面跳转过来的.
    // 如果是，则改变查询条件，根据人物的信息（关键字keyWord）--手机号或者人名，查询到人物，
    // 然后直接打开人物的编辑modal
    let params = getUrlParams();
    if (params.keyWord || params.id) {
      this.searchFormValue.keyWord = decodeURI(params.keyWord);
      this.searchFormValue.isLeave = -1;
      this.currentRowId = params.id;
      this.getPersonList(true).then(() => {
        for (let i = 0, len = this.tableData.length; i < len; i++) {
          let row = this.tableData[i];
          if (row.personnelId == params.id) {
            this.openModifyPersonModal(i, row);
            break;
          }
        }
      });
    } else {
      this.getPersonList();
    }
    this.getCurrentCompany();

    //获取用户权限，判断是否可编辑信息
    let currentUserInfo = localStorage.getItem("fund_master_current_user")
      ? JSON.parse(localStorage.getItem("fund_master_current_user"))
      : {};
    let userPermission = currentUserInfo.userPermission;
    this.userEditable = userPermission === 1;
  },
  methods: {
    personStatusChange(val) {
      this.searchPerson();
    },

    getPersonList(keepCurrentRow = false) {
      return new Promise((resolve, reject) => {
        this.loading = true;

        if (!keepCurrentRow) {
          this.currentRowId = "";
        }

        let params = Object.assign(
          {
            pageNo: this.page,
            pageSize: this.pageSize
          },
          this.searchFormValue
        );
        this.$http.get("datadis/personnel", params).then(res => {
          this.loading = false;
          if (res && res.code === 20000) {
            resolve();
            if (res.data.records.length) {
              this.tableData = JSON.parse(JSON.stringify(res.data.records));
              this.totalItem = res.data.total;

              //判断当前是否为全部范围，确定是否可拖拽

              if (
                +this.searchFormValue.isLeave === -1 &&
                this.searchFormValue.keyWord === ""
              ) {
                this.$refs.table.setSortabel();
              } else {
                this.$refs.table.setUnSortable();
              }
            } else {
              // 在删除table数据的时候，如果某一页删完了，需要获得上一页的数据
              if (this.page > 1) {
                this.page -= 1;
                this.getPersonList();
              } else {
                this.tableData = [];
              }
            }
          } else {
            let msg = res && res.msg ? res.msg : "数据加载失败，请点击重新加载";
            this.$message.error(msg);
            this.tableData = [];
            this.reload = true;
          }
          // let currentRowIndex = _.findIndex(this.tableData, (item) => {
          //   return item.personnelId === this.currentRowId;
          // })
          // if(keepCurrentRow){
          this.$nextTick(() => {
            this.$refs.table.setCurrentRow("personnelId", this.currentRowId);
          });
          // }
        });
      });
    },
    searchPerson() {
      this.getPersonList();
      this.$refs.table.refresh();
    },
    reset() {
      ths.searchFormValue = {};
      thsi.getPersonList();
    },
    getCurrentCompany() {
      let currentUser = JSON.parse(
        localStorage.getItem("fund_master_current_user")
      );
      if (currentUser && currentUser.companyName) {
        this.currentCompany = currentUser.companyName;
      } else {
        this.$http.get("user/checkInfo").then(res => {
          this.currentCompany = res.data.companyName;
        });
      }
    },
    addPerson() {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      this.$refs.personModal.show("add", this.currentCompany);
    },
    deletePerson(index, rowData) {
      this.currentPersonId = rowData.personnelId;
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      this.$prompt(
        // `确认删除<b style="color:#fff">&nbsp;${rowData.personnelName}&nbsp;</b>吗？`,
        `信息删除后不可恢复<br/>
         如您确认删除<b style="color:#fff">&nbsp;${rowData.personnelName}&nbsp;</b>,请填写备注:
        `,
        "删除",
        {
          showInput: true,
          inputPlaceholder: "请输入备注",
          inputType: "textarea",
          inputValidator: value => {
            let regp = /^\s*$/g;
            if (
              regp.test(value) ||
              value == null ||
              value == "" ||
              value == undefined
            ) {
              return false;
            }
            return true;
          },
          showCancelButton: true,
          inputErrorMessage: "备注不能为空",
          customClass: "customer-dialog",
          // type: "warning",
          dangerouslyUseHTMLString: true,
          closeOnClickModal: false,
          beforeClose: (action, instance, done) => {
            let remark = instance.inputValue;
            let params = {
              personnelId: rowData.personnelId
            };
            if (action === "confirm") {
              instance.confirmButtonLoading = true;
              instance.confirmButtonText = "删除中...";

              let remarkParams = {
                logRemark: remark,
                keyId: rowData.personnelId,
                logTypeName: "删除人物",
                keyType: 2,
                logType: 4
              };

              this.$http
                .post("datadis/remarkLog", [remarkParams])
                .then(resp => {
                  if (resp.code === 20000) {
                    this.$http
                      .putWithoutId("datadis/personnel/applyDelete", params)
                      .then(res => {
                        done();
                        instance.confirmButtonLoading = false;
                        if (!res) return;
                        if (res.code == 20000) {
                          this.getPersonList();
                          this.$message({
                            showClose: true,
                            message: "删除成功",
                            type: "success"
                          });
                        } else {
                          this.$message({
                            showClose: true,
                            message: "删除失败",
                            type: "error"
                          });
                        }
                      });
                  } else {
                    done();
                    instance.confirmButtonLoading = false;
                    this.$message.error("添加备注失败!");
                  }
                });
            } else {
              done();
              instance.confirmButtonLoading = false;
            }
          }
        }
      );
    },
    dismissPerson(index, rowData) {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      this.$refs.dimissionModal.open();
      this.currentPersonId = rowData.personnelId;
    },
    cancel() {
      this.$refs.delModal.close();
    },
    closeDimission() {
      this.$refs.dimissionModal.close();
      this.dimissionValue = {};
      setTimeout(() => {
        this.$refs.dimissionForm.resetValid();
      }, 100);
    },
    confirmDimission() {
      let param = Object.assign({}, this.dimissionValue, {
        personnelId: this.currentPersonId
      });
      this.$refs.dimissionForm.valid().then(valid => {
        if (valid) {
          this.$http.put("datadis/personnel/applyResign", param).then(res => {
            if (!res) return;
            if (res.code === 20000) {
              this.$message.success("申请离职成功!");
              this.getPersonList(true);
              this.closeDimission();
            } else {
              this.$message.error(res.msg);
            }
          });
        }
      });
    },
    confirm() {
      this.$http
        .put("datadis/personnel/applyDelete", {
          personnelId: this.currentPersonId
        })
        .then(res => {
          if (res.code == 20000) {
            this.$refs.delModal.close();
          }
        });
    },
    openModifyPersonModal(index, rowData) {
      if (rowData.draft.draftStatus === 1 && rowData.draft.draftTime) {
        let draftTime = rowData.draft.draftTime.split(" ")[0];
        this.$confirm(
          `该人物信息有一份草稿，保存时间为${draftTime},是否继续编辑草稿?`,
          "草稿",
          {
            cancelButtonText: "重新编辑",
            confirmButtonText: "继续编辑",
            showCancelButton: true,
            dangerouslyUseHTMLString: true,
            type: "warning",
            closeOnClickModal: false,
            beforeClose: (action, instance, done) => {
              if (action === "confirm") {
                done();
                this.$refs.personModal.show(
                  "modify",
                  rowData.personnelId,
                  true
                );
              } else {
                done();
                // this.$refs.personModal.getPersonInfo(rowData.personnelId);
                // this.$refs.personModal.open("modify");
                this.$refs.personModal.show("modify", rowData.personnelId);
              }
            }
          }
        );
      } else {
        this.$refs.personModal.show("modify", rowData.personnelId);
      }
    },
    //用于记录上一次操作
    addActionRecord(id, key, index) {},
    tableRowClick({ row, column, index }) {
      this.currentRowId = row.personnelId;
      this.$refs.table.setCurrentRow("personnelId", this.currentRowId);
    },
    dragSort(data) {
      this.loadingTitle = "保存排序中...";
      this.loading = true;
      //修改任务次序
      this.$http
        .put("datadis/personnel/order", {
          personnelIds: data.map(item => {
            return item.personnelId;
          })
        })
        .then(res => {
          this.loading = false;
          this.$message.success("排序成功");
          this.$refs.table.refresh();
        });
    }
  }
};
</script>

<style lang="less">
.dimission-modal {
  .el-dialog {
    height: 180px;
  }
  .date-picker-container {
    width: 260px;
  }
}

.customer-dialog {
  .el-message-box__status {
    top: 47px !important;
  }
}
</style>

