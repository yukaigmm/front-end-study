<template>
  <div class="service-history-form">
    <vformConfig ref="formConfig" v-model="val[0]" :config="serviceHistoryFields" @change="changeValue">
    </vformConfig>
  </div>
</template>

<script>
import {
  validateEmail,
  validatePhoneNumber
} from "../../../common/js/validator.js";
import { getSessionOption } from "../../../common/js/utils";
export default {
  props: {
    value: {
      type: [Array, Object],
      default: () => {
        return [{ isDefault: 1 }];
      }
    },
    fieldKey: {
      type: String
    }
  },
  data() {
    return {
      val: [],
      validItems: [],
      key: "serviceHistory"
    };
  },
  created() {
    this.val = JSON.parse(JSON.stringify(this.value));
  },
  watch: {
    value: {
      handler(val) {

        if (this.value instanceof Array && this.value.length) {
          this.val = JSON.parse(JSON.stringify(this.value));
        } else {
          this.val = [{}];
        }
        for (let item of this.val) {
          item.isDefault = 1;
          if (!item.isLeave) {
            item.endDate = "";
          }
        }
      },
      deep: true
    }
  },

  computed: {
    serviceHistoryFields() {
      // 验证是否重复
      const validateIsrepeat = (url, key, msg = "已存在") => {
        let that = this;
        return function(rule, value, callback, source, options) {
          var errors = [];
          let params;
          let id = that.$parent.$children[0].value.personnelId;
          if (!id) {
            params = {
              [key]: value
            };
          } else {
            params = {
              [key]: value,
              personnelId: id
            };
          }
          if (value) {
            that.$http
              .post(url, params)
              .then(res => {
                if (res.data.isRepeat) {
                  errors.push(new Error(msg));
                } else {
                  errors = [];
                }
              })
              .then(() => {
                callback(errors);
              });
          } else {
            callback(errors);
          }
        };
      };

      const validateEndDate = (rule, value, callback) => {
        let errors = [];
        if (this.val[0]) {
          if (this.val[0].isLeave) {
            if(/[a-zA-Z]/.test(value)){
              value = ""
            }
            if (!value) {
              errors.push(new Error("离职日期不能为空"));
            }
          }
        }

        callback(errors);
      };
      return {
        cols: 12,
        fields: [
          [
            {
              label: "人员类型",
              labelWidth: 120,
              colspan:12,
              comps: [
                {
                  key: "personnelType",
                  compType: "vselect",
                  cols: 6,
                  compConfig: {
                    options: getSessionOption("cPersonnelType"),
                    valueKey: "param",
                    labelKey: "name"
                  },
                  rules: [{ required: true, message: "人员类型不能为空" }]
                },
                {
                  key: 'tip',
                  compType: 'vtext',
                  cols: 6,
                  compConfig: {
                    text: '注：类型为基金经理时才能关联基金信息'
                  },
                  compStyle:{
                    cssFloat: 'right',
                    color:'#666',
                    // width: '120px',
                    // wordWrap:'break-word'
                  }
                }
              ]
            }
          ],
          [
            {
              label: "当前职位",
              labelWidth: 120,
              colspan:12,
              comps: [
                {
                  key: "position",
                  compType: "vinput",
                  cols: 6,
                  rules: [{ required: true, message: "当前职位不能为空" }],
                  compConfig: {
                    placeholder: "请输入职位"
                  }
                }
              ]
            },
          ],
          [
            {
              label: "任期开始时间",
              labelWidth: 120,
              colspan:12,
              comps: [
                {
                  key: "startDate",
                  compType: "vdatePicker",
                  cols: 6,
                  rules: [{ required: true, message: "任期开始时间不能为空" }],
                  compConfig: {
                    placeholder: "请选择时间"
                  },
                  compStyle: {
                    width: '100%',
                  }
                }
              ]
            }
          ],
          [
            {
              label: "核心人物",
              labelWidth: 120,
              colspan: 12,
              comps: {
                key: "keyFigure",
                cols: 6,
                compType: "vradio",
                compConfig: {
                  radioKey: "keyFigure",
                  options: [
                    {
                      value: 1,
                      label: "是"
                    },
                    {
                      value: 0,
                      label: "否"
                    },
                    {
                      value: -1,
                      label: "保密"
                    }
                  ]
                }
              }
            },
          ],
          [
            {
              label: "投研团队成员",
              labelWidth: 120,
              comps: [
                {
                  key: "ifinclude",
                  cols: 6,
                  compType: "vswitch",
                  compConfig: {
                    type: "checkbox",
                    falseValue: 0,
                    trueValue: 1,
                    trueLabel: '',
                  }
                }
              ]
            }
          ],
          [
            {
              label: "官网是否展示",
              labelWidth: 120,
              colspan: 12,
              comps: {
                key: "isVisible",
                cols: 6,
                compType: "vradio",
                compConfig: {
                  radioKey: "isVisible",
                  options: [
                    {
                      value: 1,
                      label: "是"
                    },
                    {
                      value: 0,
                      label: "否"
                    },
                  ]
                }
              }
            },
          ],
          [
            {
              label: "是否离职",
              labelWidth: 120,
              colspan: 6,
              comps: [
                {
                  key: "isLeave",
                  compType: "vswitch",
                  cols: 2,
                  compConfig: {
                    type: "checkbox",
                    falseValue: 0,
                    trueValue: 1,
                    trueLabel: '',
                  }
                },
                {
                  key: "endDate",
                  compType: "vdatePicker",
                  cols: 10,
                  hide: this.val[0].isLeave ? false : true,
                  rules: [validateEndDate],
                  compConfig: {
                    placeholder: '离职日期'
                  },
                  compStyle:{
                    width: '189px'
                  }
                }
              ]
            },
            // {
            //   label: "离职日期",
            //   labelWidth: 120,
            //   colspan: 2 / 3,
            //   hide: this.val[0].isLeave ? false : true,
            //   comps: [
            //     {
            //       rules: [validateEndDate],
            //       key: "endDate",
            //       compType: "vdatePicker"
            //     }
            //   ]
            // }
          ]
        ]
      };
    }
  },

  methods: {
    changeValue() {
      this.$emit("input", this.val, this.fieldKey);
      this.$emit("change", this.val, this.fieldKey);
    },
    // 提交验证
    valid() {
      return new Promise(resolve => {
        this.$refs.formConfig.valid().then(valid => {
          resolve(valid);
        });
      });
    },
    resetValid() {
      this.$refs.formConfig.resetValid();
    }
  }
};
</script>

<style lang="less" scoped>
  .service-history-form{
    padding: 0% 10%;
    &>.form{
      width: 600px;
    }
  }
</style>

