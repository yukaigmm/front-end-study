<template>
  <vpart title="荣誉贡献">
    <div slot="search"></div>
    <div slot="action">
      <vbutton active title="添加人物工作背景" @click="addWorkBg">新增</vbutton>
    </div>
    <vtable :key="key" ref="workTable" :columns="columnsConfig" :data="value" width="100%"></vtable>
  </vpart>
</template>

<script>
export default {
  components: {
    // toast
  },
  props: {
    value: {
      type: [Array, Object],
      default: () => []
    },
    fieldKey: {
      type: String
    }
  },
  data() {
    return {
      key: "",
      validKey: [],
      validItems: [],
      defaultLabel: 0
    };
  },
  computed: {
    columnsConfig() {
      return [
        {
          title: "获奖时间",
          width: 150,
          key: "earnDate",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                tableRow: row,
                comps: {
                  compType: "vdatePicker",
                  key: "earnDate",
                  rules: [
                    { required: true, message: "获奖时间不能为空" }
                    // (rule, value, callback) => {
                    //   let errors = [];
                    //   let endDate = row.endDate;
                    //   let startDate = row.startDate;
                    //   if (endDate == -1) {
                    //     endDate = Number.POSITIVE_INFINITY;
                    //   }
                    //   if (startDate > endDate && endDate != "") {
                    //     errors.push(new Error("开始时间不能大于结束时间"));
                    //   } else {
                    //     errors = [];
                    //   }
                    //   callback(errors);
                    // }
                  ]
                },
                value: row.earnDate
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `startDate-${index}`
            });
          }
        },

        {
          title: "荣誉名称",
          key: "topic",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                tableRow: row,
                comps: {
                  compType: "vinput",
                  key: "topic",
                  rules: [{ required: true, message: "荣誉名称不能为空" }],
                  compConfig: {
                    placeholder: "请输入荣誉名称"
                  }
                },
                value: row.topic
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `companyName-${index}`
            });
          }
        },
        {
          title: "颁奖机构",
          width: 200,

          showOverflowTooltip: false,
          key: "organizer",
          render: (h, { row, column, index }) => {
            return h("editTableCell", {
              props: {
                tableRow: row,
                comps: {
                  compType: "vinput",
                  key: "organizer",
                  compConfig: {
                    placeholder: "请输入颁奖机构"
                  }
                },
                value: row.organizer
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              },
              ref: `positionName-${index}`
            });
          }
        },
        {
          title: "操作",
          key: "action",
          width: 58,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                h("vbuttonSprite", {
                  props: {
                    pos: {
                      normal: { x: 0, y: -241 },
                      hover: { x: -18, y: -241 },
                      disabled: { x: -36, y: -241 }
                    },
                    title: "删除"
                  },
                  style: {
                    verticalAlign: "middle"
                  },
                  on: {
                    click: e => {
                      this.deletRow(index, row);
                    }
                  }
                })
              ]
            );
          }
        }
      ];
    }
  },

  mounted() {
    // let options = this.getDateOptions();
    // this.startDate = options;
    // this.endDate = JSON.parse(JSON.stringify(options));
    // this.endDate.unshift({ label: "至今", value: -1 });
  },
  watch: {
    value: {
      handler(val) {
        this.key = Date.now();
        this.$emit("input", val);
        this.$emit("change", val, this.fieldKey);
        this.defaultLabel = new Date().getTime();
      },
      deep: false
    }
  },

  methods: {
    onTableCellChange(val, data, column, index) {
      data[column.property] = val;
    },
    // getValidItems() {
    //   this.validItems = [];
    //   this.validKey.forEach(item => {
    //     this.value.forEach((subitem, index) => {
    //       this.validItems.push(`${item}-${index}`);
    //     });
    //   });
    // },
    // 提交验证
    valid() {
      // this.getValidItems();

      let that = this;
      return new Promise(resolve => {
        let formItemValid = true;
        let valids = [];
        if (that.value.length) {
          valids = that.$refs.workTable.getRefs();
        }

        

        new Promise(resolve => {
          if (valids && valids.length) {
            
            valids.forEach((item, index) => {
              item.valid().then(valid => {
                if (!valid) {
                  formItemValid = false;
                }
                if (index === valids.length-1) {
                  resolve(formItemValid);
                }
              });
            });
          } else {
            resolve(true);
          }
        }).then(
          valid => {
            resolve(valid);
          },
          () => {}
        );
      });
    },
    resetValid() {
      if (!this.value.length) {
        return;
      }
      let valids = this.$refs.workTable.getRefs();
      if (valids.length) {
        valids.forEach(item => {
          if (item) {
            item.resetValid();
          }
        });
      }
    },
    // // 设置表格行样式
    // tableRowClassName({ row, rowIndex }) {
    //   if (rowIndex % 2 === 1) {
    //     return "odd-row";
    //   } else {
    //     return "even-row";
    //   }
    // },
    // 删除内容
    deletRow(index, row) {
      this.$confirm("确定删除吗？", "删除", {
        showCancelButton: true,
        type: "warning",
        closeOnClickModal: false,
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            instance.confirmButtonLoading = true;
            instance.confirmButtonText = "删除中...";
            this.$delete(this.value, index);
            this.$emit("change", this.value, this.fieldKey);
            this.$message({
              showClose: true,
              message: "删除成功,点击保存之后将会生效",
              type: "success"
            });
            instance.confirmButtonLoading = false;
            done();
          } else {
            done();
          }
        }
      });
    },

    // 添加内容
    addWorkBg() {
      this.$set(this.value, this.value.length, {
        organizer: "",
        earnDate: "",
        topic: "",
        // positionId: ""
      });
    },
    // getDateOptions() {
    //   let endYear = new Date().getFullYear();
    //   let options = [];
    //   for (let i = endYear; i >= 1970; i--) {
    //     options.push({ label: i, value: i });
    //   }
    //   return options;
    // }
  }
};
</script>

<style lang="less" scoped>
.cell-edit-color {
  color: #2db7f5;
  font-weight: bold;
  border: 1px solid #2db7f5;
}
</style>
