<template>
  <vmodal
    class="person-modal t2-el-dialog"
    ref="modal"
    :title="'人物基本信息'"
    :width="760"
    :reload="reload"
    @close="cancel"
    @reloadModal="reloadPersonInfo"
  >
    <vloading slot="loading" v-model="modalLoading" :title="loadingTitle" class="loading"></vloading>
    <div class="form-tab-container">
      <vformTab
        ref="formTab"
        :config="formTabConfig"
        v-model="form"
        :shadow="!userEditable"
        @clickTab="clickTab"
      ></vformTab>
      <!-- <vloading v-model="loading" class="loading"></vloading> -->
    </div>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton :disabled="reload" active @click="confirm">保存</vbutton>
      <vbutton :disabled="reload" active @click="saveDraft">保存草稿</vbutton>
    </div>
  </vmodal>
</template>

<script>
import education from "./education.vue";
import work from "./work.vue";
import serviceHistory from "./service-history.vue";
import honor from "./honor.vue";
import { getSessionOption } from "../../../common/js/utils";
import {
  validateChineseWithLength,
  validateBiggerThanSomeAge,
  validateGreaterThanSomedate,
  validatePhoneNumber,
  validateEmail
} from "../../../common/js/validator.js";
export default {
  data() {
    return {
      companyName: "",
      status: "",
      positionFirstChange: true,
      startDatefirstChange: true,
      personnelId: "",
      isDraft: "",
      openStatus: false,
      // loading: false,
      reload: false,
      modalLoading: false,
      form: {
        educationInfo: [],
        workBg: [],
        serviceHistory: [
          { keyFigure: 1, ifinclude: 1, isDefault: 1, isVisible: 1 }
        ]
      },
      userEditable: true
    };
  },
  methods: {
    // 设置缺省工作经历
    clickTab(val) {
      if (val.tabKey === "workBg") {
        if (this.status === "add") {
          if (
            this.form.serviceHistory.length &&
            this.form.serviceHistory[0].startDate
          ) {
            if (this.startDatefirstChange) {
              let startDate = new Date(
                this.form.serviceHistory[0].startDate
              ).getFullYear();
              let positionName = this.form.serviceHistory[0].position;
              this.$set(this.form.workBg, 0, {
                startDate,
                endDate: -1,
                companyName: this.companyName,
                positionName
              });

              this.startDatefirstChange = false;
            }
          }

          if (
            this.form.serviceHistory.length &&
            this.form.serviceHistory[0].position
          ) {
            if (this.positionFirstChange) {
              let startDate = new Date(
                this.form.serviceHistory[0].startDate
              ).getFullYear();
              let positionName = this.form.serviceHistory[0].position;
              this.$set(this.form.workBg, 0, {
                startDate,
                endDate: -1,
                companyName: this.companyName,
                positionName
              });
              this.positionFirstChange = false;
            }
          }
        }
      }
    },
    // 获取人物的当前就职公司
    setKeysNotShow(ObjectTodeal, keys = []) {},

    //  设置没有填写时的默认字段
    setVoidKeys(ObjectToDeal, keys = []) {
      keys.forEach(item => {
        if (!ObjectToDeal[item]) {
          ObjectToDeal[item] = [];
        }
      });
      return ObjectToDeal;
    },
    /*
      status: 打开状态 string [add modify]
      key: 关键字 string [add => companyName , modify => id]
      isDraft: 是否打开草稿  boolean
    */
    show(status, key, isDraft) {
      this.status = status;
      this.isDraft = isDraft;
      this.open(status);
      this.openStatus = true;
      if (this.status === "add") {
        this.companyName = key;
      } else {
        this.$nextTick(() => {
          this.getPersonInfo(key, isDraft);
        });
      }
      if (this.status === "add") {
        this.$set(this.form, "educationInfo", []);
        this.$set(this.form.workBg, 0, {
          endDate: -1,
          companyName: this.companyName
        });
        this.$set(this.form.serviceHistory, 0, {
          keyFigure: 1,
          ifinclude: 1,
          isDefault: 1,
          isVisible: 1
        });
        //  添加的时候，由于给工作背景的table添加了一行，会触发 任职开始时间（startDate）的验证，因此需要重置验证
        this.reset();
      }
    },
    //  确认提交
    confirm() {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      if (!(window.sessionStorage.getItem("canSend") === "false")) {
        this.modalLoading = true;
      }

      this.clickTab({ tabKey: "workBg" });
      setTimeout(() => {
        this.$refs.formTab.valid().then(valid => {
          if (valid.valid) {
            let formData = this.getSubmitData();
            formData = this.setVoidKeys(formData, [
              "educationInfo",
              "workBg",
              "honor"
            ]);

            if (this.status == "add") {
              this.$http.post("datadis/personnel", formData).then(res => {
                this.modalLoading = false;
                if (!res) {
                  this.$message.error("新增失败");
                  return;
                }
                if (res.code == 20000) {
                  this.cancel();
                  this.$message.success("新增成功");
                  this.$emit("getPersonList", true);

                  //监听人物信息新增的事件
                  sa.event("fundMaster_infomationSave", {
                    modalRefer: "人物信息新增"
                  });
                } else {
                  this.$message.error(res.msg);
                }
              });
            } else if (this.status == "modify") {
              this.getModifyFormData(formData);
              this.$http
                .putWithoutId(`datadis/personnel/${this.personnelId}`, formData)
                .then(res => {
                  this.modalLoading = false;
                  if (!res) return;
                  if (res.code == 20000) {
                    this.cancel();
                    this.$message.success("修改成功");
                    this.$emit("getPersonList", true);

                    //监听人物信息新增的事件
                    sa.event("fundMaster_infomationSave", {
                      modalRefer: "人物信息新增",
                      id: formData.personnelId
                    });
                  } else {
                    this.$message.error(res.msg);
                  }
                });
            }
          } else {
            this.modalLoading = false;
            this.$refs.formTab.jumpTab(valid.invalidTab);
            this.$message.error("请按红色提示补充信息");
          }
        });
      }, 100);
    },
    saveDraft() {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      if (!(window.sessionStorage.getItem("canSend") === "false")) {
        this.modalLoading = true;
      }

      this.clickTab({ tabKey: "workBg" });
      let formData = this.getSubmitData();
      formData = this.setVoidKeys(formData, [
        "educationInfo",
        "workBg",
        "honor"
      ]);

      this.$http
        .post("datadis/draft", {
          draftType: 2,
          draftKeyId: this.personnelId,
          draftData: formData
        })
        .then(res => {
          this.modalLoading = false;
          if (!res) {
            this.$message.error("新增草稿失败");
            return;
          }
          if (res.code == 20000) {
            this.cancel();
            this.$message.success("新增草稿成功");
            this.$emit("getPersonList", true);
          } else {
            this.$message.error(res.msg);
          }
        });
    },
    cancel() {
      this.clearForm();
      this.close();
      // 这个地方使用 600ms 的延时，是因为 valid-box.vue 的 compChange 方法是 500ms 触发验证，
      // clearForm 方法会触发 datePicker 组件的 change 事件，
      // 从而触发 valid-box 中的 compChange 事件，最后会调用 changeValidStatus 方法触发验证
      // 因此如果要重置验证，需要先让 compChange 事件执行 changeValidStatus 方法，然后再执行 resetValid 方法，这样才不会resetValid 之后依然触发验证
      setTimeout(() => {
        this.reset();
      }, 600);
    },
    //显示模态框
    open(status) {
      this.$refs.modal.open();
    },
    // 隐藏模态框
    close() {
      this.$refs.modal.close();
    },
    // 重置formtab的验证
    reset() {
      setTimeout(() => {
        this.$refs.formTab.resetValid();
        this.$refs.formTab.jumpTab("basicInformation");
      }, 0);
    },
    // 清除form表单的内容
    clearForm() {
      this.form = {
        educationInfo: [],
        workBg: [],
        serviceHistory: []
      };
      this.startDatefirstChange = true;
      this.positionFirstChange = true;
    },
    // 提交信息的格式化
    getSubmitData() {
      let cityId = this.form.provinceId
        ? this.form.provinceId.cityId || ""
        : "";
      let provinceId = this.form.provinceId
        ? this.form.provinceId.provinceId || ""
        : "";
      let formData = JSON.parse(JSON.stringify(this.form));
      if (formData.workBg && formData.workBg.length) {
        formData.workBg.forEach(item => {
          item.companyName = item.companyName;
          if (item.endDate == -1) {
            item.endDate = "";
          }
        });
      }

      if (
        !formData.investmentExperience &&
        formData.investmentExperience != 0
      ) {
        formData.investmentExperience = -1;
      }

      formData.serviceHistory[0].email = formData.email;
      // if (formData.personProfile) {
      let personProfile =
        formData.personProfile instanceof Object
          ? JSON.parse(JSON.stringify(formData.personProfile))
          : {};
      formData.profileName = personProfile.fileName || "";
      formData.profilePath = personProfile.filePath || "";
      // }
      // delete formData.email;
      // delete formData.personProfile;
      let submitFormData = Object.assign({}, formData, { provinceId, cityId });
      return submitFormData;
    },
    // 修改信息的格式化
    getModifyFormData(formData) {
      for (let key in formData) {
        if (formData[key] instanceof Array && formData[key].length) {
          for (let item of formData[key]) {
            item.personnelId = this.personnelId;
          }
        } else {
          formData.personnelId = this.personnelId;
        }
      }
    },
    // 修改人物时获取人物信息
    // isDraft 是否是草稿，1表示获取草稿
    getPersonInfo(id, isDraft) {
      let url = isDraft ? `datadis/draft/2/${id}` : `datadis/personnel/${id}`;
      this.personnelId = id;
      this.reload = false;
      this.modalLoading = true;
      this.$http.get(url).then(res => {
        this.openStatus = false;
        this.modalLoading = false;
        if (res && res.code === 20000) {
          this.form = isDraft ? res.data.draftData : res.data;
          this.form.personProfile = {
            fileName: this.form.profileName,
            filePath: this.form.profilePath
          };
          if (this.form.investmentExperience == -1) {
            this.form.investmentExperience = "";
          }
          if (this.form.workBg && this.form.workBg.length) {
            this.form.workBg.forEach(item => {
              if (!item.endDate) {
                item.endDate = -1;
              }
            });
          }

          this.form.email = this.form.serviceHistory[0].email;

          // for(let item of )
          this.form.provinceId = {
            provinceId: this.form.provinceId,
            cityId: this.form.cityId
          };
          // setTimeout(() => {
          //   this.$refs.formTab.valid();
          // }, 500);
        } else {
          let msg = res && res.msg ? res.msg : "数据加载失败，请点击重新加载";
          this.$message.error(msg);
          this.reload = true;
        }
      });
    },
    reloadPersonInfo() {
      this.getPersonInfo(this.personnelId, this.isDraft);
    }
  },
  mounted() {
    //获取用户权限，判断是否可编辑信息
    let currentUserInfo = localStorage.getItem("fund_master_current_user")
      ? JSON.parse(localStorage.getItem("fund_master_current_user"))
      : {};
    let userPermission = currentUserInfo.userPermission;
    this.userEditable = userPermission === 1;
  },
  computed: {
    loadingTitle() {
      if (this.openStatus) {
        return "数据加载中，请等待！";
      }
      return this.status == "add" ? "添加中..." : "修改中...";
    },
    formTabConfig() {
      //  验证大于1900
      const valiateGreaterThanSomeNumber = (
        rule,
        value,
        callback,
        source,
        options
      ) => {
        let errors = [];
        if (value && parseFloat(value) <= 1900) {
          errors.push(new Error("年份应该大于1900"));
        }
        callback(errors);
      };
      // 验证是否重复
      const validateIsrepeat = (url, key, msg = "已存在") => {
        let that = this;
        return function(rule, value, callback, source, options) {
          var errors = [];
          let params;
          if (that.status == "add") {
            params = {
              [key]: value
            };
          } else {
            params = {
              [key]: value,
              personnelId: that.personnelId
            };
          }

          if (value) {
            that.$http
              .post(url, params)
              .then(res => {
                if (res.data.isRepeat) {
                  errors.push(new Error(msg));
                } else {
                  errors = [];
                }
              })
              .then(() => {
                callback(errors);
              });
          } else {
            callback(errors);
          }
        };
      };

      return {
        useTab: true,
        cols: 2,
        tabs: [
          {
            tabLabel: "基本信息",
            tabKey: "basicInformation",
            formConfig: {
              cols: 12,
              fields: [
                [
                  {
                    label: "姓名",
                    labelWidth: 105,
                    colspan: 7,
                    comps: [
                      {
                        key: "personnelName",
                        compType: "vinput",
                        rules: [
                          { required: true, message: "姓名不能为空" }
                          // validateChineseWithLength(
                          //   "4",
                          //   "人物名称请输入四个字以内的汉字"
                          // )
                        ],
                        compConfig: {
                          placeholder: "请输入姓名"
                        }
                      }
                    ]
                  },
                  {
                    label: "",
                    colspan: 5,
                    comps: {
                      key: "avatar2",
                      compType: "vimageUpload",
                      compConfig: {
                        url: "/datadis/personnel/uploadAvatar",
                        fieldName: "avatarFile",
                        defaultImage:
                          "/assets/images/person-atavar-default.png",
                        imgStyle: {
                          width: "200px",
                          height: "200px",
                          minWidth: "200px",
                          maxWidth: "100%",
                          marginLeft: "10px"
                        },
                        foreignPath: true
                      }
                    },
                    style: {
                      cssFloat: "right"
                    }
                  },
                  {
                    label: "性别",
                    labelWidth: 105,
                    colspan: 7,
                    comps: [
                      {
                        key: "sex",
                        compType: "vradio",
                        compConfig: {
                          radioKey: "sex",
                          options: [
                            {
                              value: 1,
                              label: "男"
                            },
                            {
                              value: 2,
                              label: "女"
                            }
                          ]
                        }
                      }
                    ]
                  },
                  {
                    label: "出生年份",
                    labelWidth: 105,
                    colspan: 7,
                    comps: [
                      {
                        key: "birthday",
                        compType: "vdatePicker",
                        rules: [
                          { required: true, message: "出生年份不能为空" },
                          validateBiggerThanSomeAge(
                            "18",
                            "年龄必须大于18周岁，请检查出生日期"
                          )
                        ],
                        compConfig: {
                          placeholder: "请选择",
                          format: "yyyy",
                          pickerType: "year"
                        }
                      }
                    ]
                  },
                  {
                    label: "籍贯",
                    labelWidth: 105,
                    colspan: 7,
                    comps: [
                      {
                        key: "provinceId",
                        compType: "varea",
                        rules: [
                          { required: true, message: "请填写籍贯" },
                          (rlue, value, callback, source, options) => {
                            var errors = [];
                            if (!value || !value.cityId) {
                              errors.push(new Error("籍贯未选择完整"));
                            }
                            callback(errors);
                          }
                        ]
                      }
                    ]
                  },
                  {
                    label: "最高学历",
                    labelWidth: 105,
                    colspan: 7,
                    comps: [
                      {
                        key: "education",
                        compType: "vradio",
                        rules: [
                          { required: true, message: "最高学历不能为空" }
                        ],

                        compConfig: {
                          radioKey: "education",
                          options: [
                            {
                              value: 3,
                              label: "专科"
                            },
                            {
                              value: 4,
                              label: "本科"
                            },
                            {
                              value: 5,
                              label: "硕士"
                            },
                            {
                              value: 6,
                              label: "博士"
                            }
                          ]
                        }
                      }
                    ]
                  }
                ],
                [
                  {
                    label: "手机号码",
                    labelWidth: 105,
                    colspan: 7,
                    comps: [
                      {
                        key: "mobile",
                        compType: "vinput",
                        rules: [
                          { required: true, message: "手机号码不能为空" },
                          validatePhoneNumber(),
                          validateIsrepeat(
                            "datadis/personnel/isMobileRepeat",
                            "mobile",
                            "该手机号已被使用"
                          )
                        ],
                        compConfig: {
                          placeholder: "请输入手机号码"
                        }
                      }
                    ]
                  },
                  {
                    label: "人物资料",
                    labelWidth: 105,
                    colspan: 5,
                    style: {},
                    comps: [
                      {
                        key: "personProfile",
                        compType: "vfileUpload",
                        compConfig: {
                          url: "datadis/personnel/uploadProfile",
                          fileName: "profileFile",
                          resName: "fileName",
                          emptyFileObj: {
                            fileName: "",
                            filePath: ""
                          },
                          foreignPath: true
                        }
                      }
                    ]
                  }
                ],
                [
                  {
                    label: "邮箱地址",
                    labelWidth: 105,
                    colspan: 7,
                    comps: [
                      {
                        key: "email",
                        compType: "vinput",
                        rules: [
                          { required: true, message: "邮箱地址不能为空" },
                          validateEmail(),
                          validateIsrepeat(
                            "/datadis/personnel/isEmailRepeat",
                            "email",
                            "该邮箱已被使用"
                          )
                        ],
                        compConfig: {
                          placeholder: "请输入邮箱地址"
                        }
                      }
                    ]
                  },
                  {
                    label: "金融从业年份",
                    labelWidth: 105,
                    colspan: 5,
                    style: {},
                    comps: [
                      {
                        key: "careerStartYear",
                        compType: "vdatePicker",
                        rules: [
                          { required: true, message: "从业年份不能为空" },
                          (rule, value, callback, source, options) => {
                            let errors = [];

                            if (value) {
                              let currentYear = new Date(value).getFullYear();
                              let birthYear = this.form.birthday
                                ? new Date(this.form.birthday).getFullYear()
                                : 0;

                              if (birthYear) {
                                if (birthYear > currentYear) {
                                  errors.push(
                                    new Error("从业年份应该大于出生年份")
                                  );
                                }
                              }
                            }
                            callback(errors);
                          },
                          (rule, value, callback) => {
                            let errors = [];
                            if (value) {
                              let currentYear = new Date().getFullYear();
                              let valueYear = new Date(value).getFullYear();
                              if (valueYear > currentYear) {
                                errors.push(
                                  new Error("从业年份不能大于当前年份")
                                );
                              }
                            }
                            callback(errors);
                          }
                        ],
                        compConfig: {
                          placeholder: "请选择",
                          format: "yyyy",
                          pickerType: "year"
                        }
                      }
                    ]
                  }
                ],
                [
                  {
                    label: "人物简介",
                    labelWidth: 105,
                    colspan: 12,
                    comps: [
                      {
                        key: "profile",
                        compType: "veditor",
                        rules: [
                          { required: true, message: "人物简介不能为空" },
                          (rule, value, callback) => {
                            let errors = [];
                            if (value) {
                              let text = $("<div></div>")
                                .html(value)
                                .text();
                              if (!text) {
                                errors.push(new Error("人物简介不能为空"));
                              }
                            } else {
                              errors.push(new Error("人物简介不能为空"));
                            }
                            callback(errors);
                          }
                        ],
                        compConfig: {
                          editorId: "profile",
                          placeholder: "请输入人物简介",
                          editorConfig: {
                            menus: []
                          }
                        }
                      }
                    ]
                  }
                ]
              ]
            }
          },
          {
            tabLabel: "任职信息",
            tabKey: "serviceHistory",
            custom: true,
            customComponent: serviceHistory
          },
          {
            tabLabel: "教育背景",
            tabKey: "educationInfo",
            custom: true,
            customComponent: education
          },
          {
            tabLabel: "工作背景",
            tabKey: "workBg",
            custom: true,
            customComponent: work
          },
          {
            tabLabel: "荣誉贡献",
            tabKey: "honor",
            custom: true,
            customComponent: honor
          }
        ]
      };
    }
  },
  watch: {
    "form.serviceHistory": {
      handler(val) {
        if (val && val[0]) {
          if (val[0].isLeave) {
            $(".person-modal div[item-key=endDate]").addClass("required");
          } else {
            $(".person-modal div[item-key=endDate]").removeClass("required");
          }
        }
      },
      deep: true
    }
  }
};
</script>

<style lang="less">
.person-modal {
  text-align: center;
  .form-tab-container {
    position: relative;
    height: 100%;
    #basicInformation .form > .row {
      padding: 0 3%;
    }
  }
}
</style>
