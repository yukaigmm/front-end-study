<template>
	<vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
    <div slot style="height: 100%;width: 100%;position: relative;">
      <vpart title="尽调信息" style="height: 100%;">
        <div class="iframe-container">
          <iframe v-show="!loading" ref="iframe" slot class="iframe" :src="iframeSrc" frameborder="0"></iframe>
          <vloading v-model="loading"></vloading>
        </div>
      </vpart>
		</div>
	</vcommon>
</template>

<script>
import pageView from '../../../common/mixins/pageView';
import { getUrlParams } from '../../../common/js/utils';
export default {
  mixins: [pageView],
  data() {
    return {
      currentMenuParentKey: "datadis",
      currentMenuChildKey: "questionnaire",
      loading: true,
      userEditable: true
    };
  },
  computed: {
    iframeSrc () {
      return `${this.$baseUrl[process.env.NODE_ENV]['qr']}/index.php?c=Index&a=index&fm=1`;
    }
  },
  methods: {
    
  },
  mounted () {
    this.$refs.iframe.onload = () => {
      this.loading = false;
    };

    //获取用户权限，判断是否可编辑信息
    let currentUserInfo = localStorage.getItem('fund_master_current_user') ? JSON.parse(localStorage.getItem('fund_master_current_user')) : {};
    let userPermission = currentUserInfo.userPermission;
    this.userEditable = userPermission === 1;
  }
};
</script>

<style lang="less" scoped>
.iframe-container {
  position: relative;
  width: 100%;
  height: 100%;
  .iframe {
    width: 100%;
    height: 100%;
  }
}
</style>
