<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
    <div style="height: 100%;">
      <vpart title="公司基本信息" style="height: 100%;">
        <div slot="search"></div>
        <div slot="action"></div>
        <div class="company-container-wrapper">
          <!-- <div slot> -->
          <div class="company-form">
            <vformConfig
              :config="formTabConfig"
              v-model="formTabValue"
              ref="companyInfoForm"
              :shadow="!userEditable"
            ></vformConfig>
            <div class="submit-container">
              <vbutton active @click="submit" :disabled="submitBtnDisabled">{{buttonText}}</vbutton>
            </div>
          </div>
          
          <vloading v-model="loading" :title="loadingTitle" class="loading"></vloading>
          <!-- </div> -->
        </div>
      </vpart>
    </div>
  </vcommon>
</template>

<script>
import {
  validateIsrepeat,
  validateNotContainInvalidWords,
  validatePhoneNumber,
  validateEmail
} from "../../../common/js/validator.js";
import { getSessionOption } from "../../../common/js/utils";
import pageView from "../../../common/mixins/pageView";
export default {
  mixins: [pageView],
  data() {
    return {
      currentMenuParentKey: "datadis",
      currentMenuChildKey: "companyInfomation",
      loading: true,
      loadingTitle: "加载中...",
      currentCompanyId: "",
      formTabValue: { hasConsultingQualification: 0 },
      pCompanyName: "",
      submitBtnDisabled: true,
      userEditable: true
    };
  },
  watch: {
    formTabValue: {
      handler(val) {
        this.submitBtnDisabled = false;
      },
      deep: true
    }
  },
  computed: {
    buttonText() {
      return this.currentCompanyId ? "保存" : "提交";
    },
    formTabConfig() {
      // 满足关联条件必填
      const validateRelatedRequired = (params = [], key, msg = "必填") => {
        let that = this;
        return function(rlue, value, callback, source, options) {
          var errors = [];
          if (params.includes(that.formTabValue[key] + "")) {
            if (!value) {
              errors.push(new Error(msg));
            }
          }
          callback(errors);
        };
      };

      // const validateRegNum = (rule, value, callback, source, options) => {
      //   let errors = [];
      //   if (value && !/^P[\d]{7}$/.test(value)) {
      //     errors.push(new Error("请按P+七位数字格式填写备案编码"));
      //   }
      //   callback(errors);
      // };

      const companyAssetSizeMap = () => {
        let value = this.formTabValue.companyType;
        if (value == 17 || value == 18) {
          return [
            { value: 10, label: "0-2亿" },
            { value: 11, label: "2-5亿" },
            { value: 12, label: "5-10亿" },
            { value: 13, label: "10亿以上" }
          ];
        } else if (value == 14) {
          return [
            { value: 6, label: "0-20亿" },
            { value: 4, label: "20-50亿" },
            { value: 8, label: "50-100亿" },
            { value: 9, label: "100亿以上" }
          ];
        }
        return [
          { value: 1, label: "0-1亿" },
          { value: 2, label: "1-10亿" },
          { value: 3, label: "10-20亿" },
          { value: 4, label: "20-50亿" },
          { value: 5, label: "50亿以上" }
        ];
      };

      return {
        cols: 12,
        fields: [
          [
            {
              label: "公司全称",
              labelWidth: 105,
              colspan: 6,
              comps: {
                key: "companyName",
                compType: "vtext"
              },
              style: {
                // paddingLeft: '50px',
              }
            }
          ],
          [
            {
              label: "公司Logo",
              labelWidth: 105,
              colspan: 6,
              comps: {
                key: "logo",
                compType: "vimageUpload",
                compConfig: { 
                  url: "datadis/company/uploadLogo",
                  fieldName: "companyLogo",
                  imgStyle: {
                    minWidth: "180px",
                    maxWidth: "100%",
                    height: "158px"
                  },
                  foreignPath: true
                }
              },
              style: {
                cssFloat: "right"
              }
            },
            {
              label: "公司简称",
              labelWidth: 105,
              colspan: 6,
              comps: {
                key: "companyShortName",
                compType: "vinput",
                rules: [
                  { required: true, message: "公司简称不能为空" },
                  validateIsrepeat(
                    "/datadis/company/isRepeat",
                    "get",
                    "companyShortName",
                    "此简称已被使用"
                  ),
                  validateNotContainInvalidWords([".", "●", "*", " "])
                ]
              }
            },
            {
              label: "投顾资质",
              labelWidth: 105,
              colspan: 3,
              comps: {
                key: "hasConsultingQualification",
                compType: "vswitch",
                compConfig: {
                  type: "checkbox",
                  trueValue: 1,
                  falseValue: 0,
                  trueLabel: ""
                }
              }
            },
            {
              label: "管理规模",
              labelWidth: 80,
              colspan: 3,
              align: "right",
              comps: {
                key: "companyAssetSize",
                compType: "vselect",
                compConfig: {
                  options: companyAssetSizeMap()
                },
                compStyle: {
                  // width:'75px'
                }
              }
            },
            {
              label: "母公司",
              labelWidth: 105,
              colspan: 6,
              comps: {
                key: "pCompanyId",
                compType: "vselectRemote",
                compConfig: {
                  labelKey: "companyName",
                  valueKey: "companyId",
                  defaultLabel: this.pCompanyName,
                  remoteUrl: "datadis/company/getCacheCompany"
                }
              }
            },
            {
              label: "注册地",
              labelWidth: 105,
              colspan: 6,
              comps: {
                key: "domicileId",
                compType: "vselect",
                compConfig: {
                  options: getSessionOption("cRegisterCountry"),
                  valueKey: "param",
                  labelKey: "name"
                }
              }
            }
          ],
          [
            {
              label: "办公城市",
              labelWidth: 105,
              colspan: 6,
              comps: [
                {
                  key: "cityId",
                  compType: "varea",
                  rules: [
                    { required: true, message: "办公城市不能为空" },
                    (rlue, value, callback, source, options) => {
                      var errors = [];

                      if (!this.formTabValue.cityId.cityId) {
                        errors.push(new Error("办公城市未选择完整"));
                      }
                      callback(errors);
                    }
                  ]
                }
              ]
            },
            {
              label: "联系电话",
              labelWidth: 105,
              colspan: 6,
              comps: {
                key: "contactPhone",
                compType: "vinput",
                rules: [validatePhoneNumber()],
                compConfig: {
                  placeholder: "请输入公司联系电话"
                }
              }
            }
          ],
          [
            {
              label: "公司网址",
              labelWidth: 105,
              colspan: 6,
              comps: {
                key: "website",
                compType: "vinput",
                compConfig: {
                  placeholder: "请输入公司网址"
                }
              }
            },
            {
              label: "公司宣传材料",
              labelWidth: 105,
              colspan: 6,
              comps: [
                {
                  key: "adv",
                  compType: "vfileUpload",
                  compConfig: {
                    url: "datadis/company/uploadAdvFile",
                    fileName: "advFile",
                    resName: "fileName",
                    // 删除上传文件返回的文件对象
                    emptyFileObj: {
                      filePath: "",
                      fileName: ""
                    },
                    foreignPath: true
                  }
                }
              ]
            }
          ],
          [
            {
              label: "办公地址",
              labelWidth: 105,
              colspan: 12,
              comps: {
                key: "companyAddress2",
                compType: "vinput",
                compConfig: {
                  placeholder: "请输入办公地址"
                }
              }
            }
          ],
          [
            {
              label: "公司简介",
              labelWidth: 105,
              colspan: 12,
              comps: {
                key: "companyProfile",
                compType: "veditor",
                compConfig: {
                  editorId: "companyProfile",
                  // showMenu:false,
                  editorConfig: {
                    menus: []
                  }
                }
              }
            }
          ],
          [
            {
              label: "投资理念",
              labelWidth: 105,
              colspan: 12,
              comps: {
                key: "philosopy",
                compType: "veditor",
                compConfig: {
                  editorId: "philosopy",
                  // showMenu:false,
                  editorConfig: {
                    menus: []
                  }
                }
              }
            }
          ]
        ]
      };
    }
  },
  methods: {
    getCompanyId() {
      return new Promise((resolve, reject) => {
        let currentUser = JSON.parse(
          localStorage.getItem("fund_master_current_user")
        );
        if (currentUser && currentUser.companyId) {
          this.currentCompanyId = currentUser.companyId;
          resolve(this.currentCompanyId);
        } else {
          this.$http.get("user/checkInfo").then(res => {
            this.currentCompanyId = res.data.companyId;
            resolve(this.currentCompanyId);
          });
        }
      });
    },
    submit() {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      if (!(window.sessionStorage.getItem("canSend") === "false")) {
        this.loading = true;
      }
      this.$refs.companyInfoForm.valid().then(valid => {
        if (valid) {
          this.getsubmitData();
          // 判断当前是否有公司id，有的话修改，没有就新增
          if (this.currentCompanyId) {
            let cityId = this.formTabValue.cityId.cityId;
            let provinceId = this.formTabValue.cityId.provinceId;
            let formData = Object.assign({}, this.formTabValue, {
              provinceId,
              cityId
            });
            this.$http
              .put("datadis/company", formData, this.currentCompanyId)
              .then(res => {
                if (!res) return;
                this.loading = false;
                if (res.code === 20000) {
                  this.$message({
                    type: "success",
                    message: "修改成功",
                    showClose: true
                  });
                  this.submitBtnDisabled = true;
                } else {
                  this.$message({
                    type: "error",
                    message: res.msg,
                    showClose: true
                  });
                }
              });
          } else {
            let cityId =
              this.formTabValue.cityId instanceof Object
                ? this.formTabValue.cityId.cityId
                : this.formTabValue.cityId;
            let provinceId =
              this.formTabValue.cityId instanceof Object
                ? this.formTabValue.cityId.provinceId
                : "";
            let formData = Object.assign({}, this.formTabValue, {
              provinceId,
              cityId
            });
            this.$http.post("datadis/company", formData).then(res => {
              this.loading = false;
              if (!res) return;
              if (res.code === 20000) {
                this.$message({
                  showClose: true,
                  message: "修改成功",
                  type: "success"
                });

                //监听公司信息修改的事件
                sa.event("fundMaster_infomationSave", {
                  modalRefer: "公司信息编辑",
                  id: formData.companyId
                });
              } else {
                this.$message({
                  showClose: true,
                  message: "修改失败",
                  type: "error"
                });
              }
            });
          }
        } else {
          this.loading = false;
          this.$message.error("请按红色提示补充信息");
        }
      });
    },
    getsubmitData() {
      this.formTabValue.advFilePath = this.formTabValue.adv.filePath || "";
      this.formTabValue.advFileName = this.formTabValue.adv.fileName || "";
    },
    // 获取公司信息
    getCompanyInfo(id) {
      this.loading = true;
      this.$http.get(`datadis/company/${id}`).then(res => {
        this.formTabValue = res.data instanceof Array ? {} : res.data;
        this.pCompanyName = res.data.pCompanyName;
        this.formTabValue.cityId = {
          provinceId: "",
          cityId: this.formTabValue.cityId
        };
        this.formTabValue.adv = {
          fileName: this.formTabValue.advFileName,
          filePath: this.formTabValue.advFilePath
        };
        this.loading = false;
        this.loadingTitle = "修改中...";
        this.$nextTick(() => {
          this.submitBtnDisabled = true;
        });
      });
    }
  },
  mounted() {
    this.getCompanyId().then(companyId => {
      if (companyId) {
        this.getCompanyInfo(companyId);
      } else {
        this.loading = false;
        this.loadingTitle = "添加中...";
      }
    });
    //获取用户权限，判断是否可编辑信息
    let currentUserInfo = localStorage.getItem("fund_master_current_user") ? JSON.parse(localStorage.getItem("fund_master_current_user")) : {};
    let userPermission = currentUserInfo.userPermission;
    this.userEditable = userPermission === 1;
  }
};
</script>
<style lang="less" scoped>
.company-container-wrapper {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
  background-color: #111;
  .submit-container {
    text-align: right;
    // margin-bottom: 20px;
    padding-bottom: 10px;
  }
}

.company-form {
  // padding: 0 100px;
  width: 780px;
  margin: 0 auto;
}
</style>
