<template>
  <vmodal ref="modal" class="t2-el-dialog" title="导出净值" @close="cancel">
    <vformConfig ref="form" :config="formConfig" v-model="form"></vformConfig>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="confirm">导出</vbutton>
    </div>
  </vmodal>
</template>

<script>
import moment from "moment";
export default {
  data() {
    return {
      initForm: {
        fundId: "",
        fundName: "",
        timePeriod: "formThisYear",
        beginTime: "",
        endTime: ""
      },
      form: {
        fundId: "",
        fundName: "",
        timePeriod: "formThisYear",
        beginTime: "",
        endTime: ""
      },
      inceptionDate: ""
    };
  },
  computed: {
    formConfig() {
      return {
        cols: 12,
        fields: [
          [
            {
              label: "基金简称",
              labelWidth: 100,
              colspan: 12,
              comps: [
                {
                  key: "fundName",
                  compType: "vtext"
                }
              ]
            }
          ],
          [
            {
              label: "时间段",
              labelWidth: 100,
              colspan: 12,
              comps: [
                {
                  key: "timePeriod",
                  compType: "vradio",
                  cols: 12,
                  compConfig: {
                    options: [
                      {
                        value: "formThisYear",
                        label: "今年以来"
                      },
                      {
                        value: "recentOneYear",
                        label: "最近一年"
                      },
                      {
                        value: "recentThreeYear",
                        label: "最近三年"
                      },
                      {
                        value: "formSetup",
                        label: "成立以来"
                      },
                      {
                        value: "custom",
                        label: "自定义"
                      }
                    ]
                  },
                  rules: [{ required: true, message: "请选择时间段" }]
                }
              ]
            }
          ],
          [
            {
              label: "",
              labelWidth: 100,
              colspan: 12,
              comps: [
                {
                  key: "beginTime",
                  compType: "vdatePicker",
                  cols: 3,
                  compConfig: {
                    placeholder: "开始时间"
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];
                      if (!value) {
                        errors.push(new Error("请选择开始时间"));
                      }
                      callback(errors);
                    }
                  ]
                },
                {
                  key: "endTime",
                  compType: "vdatePicker",
                  cols: 3,
                  compConfig: {
                    placeholder: "结束时间"
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];
                      if (!value) {
                        errors.push(new Error("请选择结束时间"));
                      }
                      callback(errors);
                    }
                  ]
                }
              ]
            }
          ],
          [
            {
              label: "包含分配信息",
              labelWidth: 110,
              comps: [
                {
                  key: "allot",
                  compType: "vswitch",
                  compConfig: {
                    type: "checkbox",
                    trueValue: 1,
                    falseValue: 0,
                    trueLabel: ""
                  },
                  compStyle: {
                    marginLeft: "-10px",
                  }
                }
              ]
            }
          ]
        ]
      };
    }
  },
  methods: {
    show(fundId, fundName, inceptionDate) {
      this.open();
      this.form.fundId = fundId;
      this.form.fundName = fundName;
      this.inceptionDate = inceptionDate;
    },
    hide() {
      this.reset();
      this.close();
    },
    open() {
      this.$refs.modal.open();
    },
    close() {
      this.$refs.modal.close();
    },
    reset() {
      this.form = JSON.parse(JSON.stringify(this.initForm));
    },
    confirm() {
      this.$refs.form.valid().then(valid => {
        if (valid) {
          //进行导出操作
          this.$http
            .get("datadis/nav/exportNavListWithMissing", {
              fundId: this.form.fundId,
              allot: this.form.allot,
              beginTime: this.form.beginTime,
              endTime: this.form.endTime
            })
            .then(res => {
              if (res.code === 20000) {
                let url = res.data.url;
                // window.open(`${this.$baseUrl[process.env.NODE_ENV]['host']}/${url}`);
                this.downloadFile(
                  `${this.$baseUrl[process.env.NODE_ENV]["host"]}/${url}`
                );
                this.cancel();
              }
            });
        } else {
          this.$message.error("请按红色提示补充信息");
        }
      });
    },
    cancel() {
      this.reset();
      this.hide();
    },
    downloadFile(url) {
      let a = document.createElement("a");
      document.body.appendChild(a);
      a.href = url;
      a.target = "_self";
      a.click();
    }
  },
  watch: {
    "form.timePeriod": {
      handler(val) {
        if (val === "formThisYear") {
          this.form.beginTime = moment()
            .startOf("year")
            .format("YYYY-MM-DD");
          this.form.endTime = moment().format("YYYY-MM-DD");
        } else if (val === "recentOneYear") {
          this.form.beginTime = moment()
            .subtract(1, "years")
            .format("YYYY-MM-DD");
          this.form.endTime = moment().format("YYYY-MM-DD");
        } else if (val === "recentThreeYear") {
          this.form.beginTime = moment()
            .subtract(3, "years")
            .format("YYYY-MM-DD");
          this.form.endTime = moment().format("YYYY-MM-DD");
        } else if (val === "formSetup") {
          this.form.beginTime = moment(new Date(this.inceptionDate)).format(
            "YYYY-MM-DD"
          );
          this.form.endTime = moment().format("YYYY-MM-DD");
        }
      },
      deep: true
    }
  }
};
</script>

