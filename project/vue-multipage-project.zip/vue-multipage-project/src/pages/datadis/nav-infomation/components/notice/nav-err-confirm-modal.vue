<template>
  <vmodal ref="modal" class="nav-err-confirm-modal t2-el-dialog" title="净值确认" @close="cancel">
    <span style="display: block;padding-left:20px;margin: 10px 0;">您填写的以下净值<span style="color: #2992ff">{{errMsg}}</span>，请上传估值表或填写备注确认</span>
    <div style="display: block;padding-left:20px;margin: 10px 0;color: red;font-size: 12px;max-height: 300px;overflow-y: auto;">
      <div v-for="(data, index) in params.submitData.addData" :key="index">
        <span style="margin-right: 10px;">{{data.priceDate}}</span>
        <span style="margin-right: 10px;">{{data.nav}}</span>
        <span>新增</span>
      </div>
      <div v-for="(data, index) in params.submitData.updateData" :key="index">
        <span style="margin-right: 10px;">{{data.priceDate}}</span>
        <span style="margin-right: 10px;">{{data.nav}}</span>
        <span>修改</span>
      </div>
    </div>
    <vformConfig ref="form" :config="formConfig" v-model="form"></vformConfig>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="confirm">确定</vbutton>
    </div>
    <vloading slot="loading" v-model="loading"></vloading>
  </vmodal>
</template>

<script>
  export default {
    data () {
      return {
        form: {
          attach: '',
          remark: '',
        },
        loading: false,
        formConfig: {
          cols: 1,
          fields: [
            [
              {
                label: "净值文件",
                labelWidth: 80,
                comps: [
                  {
                    key: "attach",
                    compType: "vfileUpload",
                    compConfig: {
                      url: "datadis/remarkLog/uploadAttach",
                      fileName: "attach",
                      resName: "fileName",
                    },
                    rules: [
                      (rule, value, callback, sources, options) => {
                        let errors = [];
                        if (!this.form.remark.trim() && !value) {
                          errors.push(new Error('请上传估值表或者填写非空备注'))
                        }
                        callback(errors);
                      }
                    ]
                  }
                ]
              }
            ],
            [
              {
                label: '备注',
                labelWidth: 80,
                comps: [
                  {
                    key: 'remark',
                    compType: 'vinput',
                    rules: [
                      (rule, value, callback, sources, options) => {
                        let errors = [];
                        if (!value.trim() && !this.form.attach.filePath) {
                          errors.push(new Error('请上传估值表或者填写非空备注'))
                        }
                        callback(errors);
                      }
                    ]
                  }
                ]
              }
            ]
          ]
        },
        params: {
          submitData: [],
        },
      }
    },
    methods: {
      show (params, errMsg) {
        this.$refs.modal.open();
        this.params = params;
        this.errMsg = errMsg || '数据有误';
        this.$refs.form.resetValid();
      },
      hide () {
        this.$refs.modal.close();
      },
      cancel () {
        this.hide();
        this.reset();
      },
      reset () {
        this.loading = false;
        this.$refs.form.resetValid();
        this.params = {
          submitData: [],
        };
        this.form = {
          remark: '',
          attach: {},
        }
      },
      confirm () {
        this.$refs.form.valid().then( (valid) => {
          if (valid) {
            this.loading = true;
            let fundRemark = {
              logRemark: this.form.remark,
              attachPath: this.form.attach.filePath,
              attachName: this.form.attach.fileName
            }
            let submitData = JSON.parse(JSON.stringify(this.params.submitData));
            submitData.addData = submitData.addData.map( (data) => {
              data.fundRemark = JSON.parse(JSON.stringify(fundRemark));
              return data;
            })
            submitData.updateData = submitData.updateData.map( (data) => {
              data.fundRemark = JSON.parse(JSON.stringify(fundRemark));
              return data;
            })
            //已上传估值表或填写备注，进行日志填写，以及提交净值数据
            this.$http.post("datadis/nav/adjData", submitData).then( (res) => {
              this.loading = false;
              if (res.code === 20000) {
                // this.$message({
                //   type: "success",
                //   message: "净值添加成功",
                //   showClose: true
                // });
                this.$emit('success', this.params);
                this.cancel();
              }
              
            })
            
          }
        })
      },
    },
    watch: {
      form: {
        handler (val) {
          this.$refs.form.valid();
        },
        deep: true,
      }
    }
  }
</script>


<style lang="less" scoped>
  .nav-err-confirm-modal {
    width: 600px;
    height: 400px;
    min-width: 600px;
    min-height: 400px;
  }
</style>

