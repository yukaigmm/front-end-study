<template>
  <vmodal
    ref="modal"
    :title="`历史净值--${fundName}`"
    class="add-nav-modal t2-el-dialog"
    :width="900"
    @close="closeModal"
  >
    <div style="position:relative;height:100%;padding:10px;">
      <vpart title="历史净值">
        <div slot="search">
          <vselect
            :placeholder="'请选择净值状态'"
            :options="options"
            @change="onSearchSelectChange"
            v-model="dataType"
          ></vselect>
          <div class="freq-selector">
            <span class="label">净值更新频率:</span>
            <span>
              <vselect
                :placeholder="'修改净值更新频率'"
                :options="freqOptions"
                @change="onFreqSelectChange"
                v-model="navFrequency"
                :disabled="!userEditable"
              ></vselect>
            </span>
          </div>
        </div>
        <div slot="action">
          <div class="score-infomation">
            完成度得分:&nbsp;&nbsp;
            <span :style="scoreStyle">{{percent}}</span>
          </div>
          <vbutton active title="导出净值" style="margin-right: 3px;" @click="exportNav">导出</vbutton>
        </div>
        <vtable
          ref="table"
          :key="key"
          :max-height="tableMaxHeight"
          :columns="columnsConfig"
          :data="tableData"
          :useActionColumn="true"
          :usePagination="true"
          :totalItem="totalItem"
          :currentPage="currentPage"
          :changeRowColor="true"
          @pageChange="pageChange"
          @pageSizeChange="sizeChange"
          @tableRowClick="tableRowClick"
        ></vtable>
        <vloading class="loading" v-model="loading"></vloading>
      </vpart>
      <distributionModal ref="distributionModal" :status="status" @success="addDistibutionSuccess"></distributionModal>
    </div>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="submitHistoryNav">保存</vbutton>
    </div>

    <exportNavModal ref="exportNavModal"></exportNavModal>
    <warn-modal @submitNav="submitWarnRow" ref="warnModal"></warn-modal>
    <batch-warn-modal ref="batchWarnModal" @submitWarnNav="submitTableNav"></batch-warn-modal>
    <batch-error-modal ref="batchErrorModal" @submitWarnNav="submitTableNav"></batch-error-modal>
  </vmodal>
</template>

<script>
import $ from "jquery";
import distributionModal from "./distribution-modal.vue";
import customColumn from "../../../../common/js/customColumn.js";
import exportNavModal from "./export-nav-modal.vue";
import _ from "lodash";
import errorMap from "../error-map.js";
import warnModal from "./notice/warn-modal.vue";
import batchWarnModal from "./notice/history-batch-warn-modal.vue";
import batchErrorModal from "./notice/history-batch-error-modal.vue";
import columnsConfig from "./history-table-config.js";
export default {
  components: {
    customColumn,
    distributionModal,
    exportNavModal,
    warnModal,
    batchWarnModal,
    batchErrorModal
  },
  data() {
    return {
      initNavValue: "",
      initCamNavValue: "",
      freqOptions: [
        {
          label: "季",
          value: "季"
        },
        {
          label: "月",
          value: "月"
        },
        {
          label: "周",
          value: "周"
        },
        {
          label: "天",
          value: "天"
        }
      ],
      status: "",
      options: [
        {
          label: "只看缺失",
          value: 1
        },
        {
          label: "已有净值",
          value: 2
        },
        {
          label: "已有分配",
          value: 3
        },
        {
          label: "全部",
          value: 0
        }
      ],
      scoreStyle: { color: "red" },
      fundId: "",
      navFrequency: "",
      inceptionDate: "",
      dataType: 0,
      currentRowId: "",
      key: "",
      pageSize: 10,
      totalItem: 0,
      currentPage: 1,
      loading: false,
      fundName: "",
      percent: "",
      deleteNavId: [],
      historyNavData: [],
      tableData: [],
      validItems: [],
      tableMaxHeight: null,
      editNavs: [],
      remarks: [],
      // 净值modal当前编辑行，保存编辑之前的值
      currentEditorRowDataArr: [],
      // 点击分红时保存所有的编辑行

      //区分估值表确认框返回值，当前为新增状态还是修改状态
      navErrConfirmModalType: "add",
      userEditable: true,
      validatingFlag: false,
      validatedData: [],
      saveTimer: ""
    };
  },

  computed: {
    columnsConfig() {
      return columnsConfig.call(this);
    }
  },
  created() {
    for (let i = 0; i < 10; i++) {
      this.validItems.push(`nav-${i}`);
    }
  },
  mounted() {
    //获取用户权限，判断是否可编辑信息
    let currentUserInfo = localStorage.getItem("fund_master_current_user")
      ? JSON.parse(localStorage.getItem("fund_master_current_user"))
      : {};
    let userPermission = currentUserInfo.userPermission;
    this.userEditable = userPermission === 1;
  },
  watch: {
    remarks: {
      handler(val) {},
      deep: true
    }
  },
  methods: {
    // 获取基金净值得分
    getNavScore() {
      this.$http.get(`datadis/nav/${this.fundId}/getNavScore`).then(res => {
        if (res.code === 20000) {
          this.percent = Math.ceil(parseFloat(res.data.score));
        }
      });
    },
    // 显示模态框
    show(fundId, fundName, score, navFrequency, inceptionDate) {
      this.fundId = fundId;
      this.fundName = fundName;
      this.navFrequency = navFrequency;
      this.inceptionDate = inceptionDate;
      this.currentPage = 1;
      this.pageSize = 10;
      this.tableData = [];
      this.setScoreStyle(score);
      this.$refs.modal.open();
      this.getHistoryNav();
    },
    // 设置得分样式
    setScoreStyle(score) {
      this.percent = parseFloat(score);
      if (this.percent > 80) {
        this.scoreStyle = { color: "green" };
      } else if (this.percent <= 80 && this.percent > 60) {
        this.scoreStyle = { color: "#ccccc6" };
      } else {
        this.scoreStyle = { color: "red" };
      }
    },
    cancel() {
      this.$refs.modal.close();
    },
    //  关闭模态框
    closeModal() {
      this.navFrequency = "";
      this.dataType = 0;
      this.deleteNavId = [];
      this.currentEditorRowDataArr = [];
      this.currentPage = 1;
      this.pageSize = 10;
      this.tableData = [];
      this.editNavs = [];
      this.remarks = [];
      this.key = Date.now();
      this.$emit("refreshTableData");
    },

    // 获取历史净值
    getHistoryNav(keepCurrentRow = false) {
      let params = {
        fundId: this.fundId,
        dataType: this.dataType,
        navFrequency: this.navFrequency
      };
      this.loading = true;
      if (!keepCurrentRow) {
        this.currentRowId = "";
      }
      return new Promise(resolve => {
        this.$http
          .get("datadis/nav/findNavListWithMissing", params)
          .then(resp => {
            this.tableMaxHeight = $(".add-nav-modal").height() - 200;
            this.setTableHeight();
            this.historyNavData = resp.data;
            this.totalItem = resp.data.length;
            this.loading = false;
            if (this.currentPage) {
              this.tableData = this.historyNavData.slice(
                this.pageSize * (this.currentPage - 1),
                this.pageSize * this.currentPage
              );
            } else {
              this.tableData = this.historyNavData.slice(0, 10);
            }
            this.$nextTick(() => {
              this.$refs.table.setCurrentRow("priceDate", this.currentRowId);
            });
            resolve();
          });
      });
    },
    // 渲染表格
    renderTable() {
      let endIndex = this.pageSize * this.currentPage;
      let startIndex = endIndex - this.pageSize;
      if (endIndex > this.totalItem - 1) {
        this.tableData = this.historyNavData.slice(startIndex);
      } else {
        this.tableData = this.historyNavData.slice(startIndex, endIndex);
      }
      this.refreshTable();
    },
    // 一页数量切换
    sizeChange(val) {
      this.pageSize = val;
      this.renderTable();
    },
    // 页码切换
    pageChange(val) {
      this.currentPage = val;
      this.renderTable();
      this.$nextTick(() => {
        this.$refs.table.setCurrentRow("priceDate", this.currentRowId);
      });
    },
    // 添加备注
    addRemarks(row, value, ifEdit) {
      // 编辑净值
      if (ifEdit) {
        for (let i = 0, len = this.remarks.length; i < len; i++) {
          // 已有备注，覆盖
          if (row.id == this.remarks[i].keyId) {
            this.remarks[i] = {
              keyId: row.id,
              logRemark: value || "",
              keyType: 4,
              logType: 4,
              logTypeName: "修改净值"
            };
            break;
          } else {
            // 没有备注，新增一条备注
            this.remarks.push({
              keyId: row.id,
              logRemark: value || "",
              keyType: 4,
              logType: 4,
              logTypeName: "修改净值"
            });
            break;
          }
        }
        if (this.remarks.length === 0) {
          this.remarks.push({
            keyId: row.id,
            logRemark: value || "",
            keyType: 4,
            logType: 4,
            logTypeName: "修改净值"
          });
        }
      } else {
        // 删除净值
        this.remarks.push({
          keyId: row.id,
          logRemark: value || "",
          keyType: 4,
          logType: 4,
          logTypeName: "删除净值"
        });
      }
    },
    // 修改净值
    editNav(row, index) {
      if (row.nav <= 0) {
        this.$message.error("净值应该大于0！");
        return;
      }
      if (isNaN(Number(row.nav))) {
        this.$message.error("净值应该是数字！");
        return;
      }
      if (isNaN(Number(row.cumulativeNavCrawl))) {
        this.$message.error("累计净值应该是数字！");
        return;
      }
      this.validateAndSubmitRow(row, index);
    },
    // 验证并提交一行净值
    validateAndSubmitRow(row, index) {
      this.loading = true;
      this.validateRow(row).then(res => {
        this.loading = false;
        if (res.code === 20000 && res.data.qcLevel == 3) {
          this.submitRow(row, index);
        } else if (res.data.qcLevel == 2) {
          this.$refs.warnModal.open(res.data.qcData, row, index);
        } else if (res.data.qcLevel == 1) {
          let noticeContentArray = res.data.qcData.map(item => {
            let content = "";
            content = errorMap[item.code].notice.replace(
              "$date",
              row.priceDate
            );
            return content || "";
          });
          this.$alert(noticeContentArray.join("。\n\r"), "净值保存", {
            confirmButtonText: "确定",
            callback: action => {}
          });
        }
      });
    },
    updatePriceDate(row, index, status) {
      //手动更新相关的历史净值
      let priceDate = row.priceDate;
      let preDate;
      let preNav;
      let navIndex = index + this.pageSize * (this.currentPage - 1);
      if (status === "add") {
        preDate = priceDate;
        preNav = row.nav;
      } else if (status === "del") {
        preDate = row.preDate;
        preNav = row.preNav;
      }
      for (let i = navIndex - 1; i >= 0; i--) {
        if (this.historyNavData[i].preDate === priceDate) {
          this.historyNavData[i].preNav = preNav;
          this.historyNavData[i].preDate = preDate;
        }
      }
      for (let i = index - 1; i >= 0; i--) {
        if (this.tableData[i].preDate === priceDate) {
          this.tableData[i].preNav = preNav;
          this.tableData[i].preDate = preDate;
        }
      }
    },
    submitRow(row, index) {
      this.loading = true;
      let navInfo = this.getNavInfo(row);
      this.$prompt("请输入备注(选填)", "确定修改本期净值？", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        inputPlaceholder: "请输入备注"
      })
        .then(({ value }) => {
          navInfo.fundRemark = {
            logRemark: value
          };
          this.$http.post("datadis/fundNav", { navs: [navInfo] }).then(res => {
            this.loading = false;
            if (!res) return;
            if (res.code === 20000) {
              //监听净值填充事件
              sa.event("fundMaster_navFill", {
                fundId: this.fundId,
                fillType: "edit"
              });
              row.canEdit = !row.canEdit;
              row.auditstate = 1;
              this.refreshTable();
              this.$message({
                message: "修改成功",
                type: "success"
              });
              this.getNavScore();
              //从未执行修改请求的行数组中去除当前行
              _.remove(this.currentEditorRowDataArr, data => {
                return data.editId === row.editId;
              });
              // 更新一行之后，更新的净值日期之后的净值的上期净值日期和上期日期需要更新
              this.updatePriceDate(row, index, "add");
              this.refreshTable();
            }
          });
        })
        .catch(() => {
          this.cancelEditRow(row);
        });
    },
    // 取消编辑行。取消时，还原之前的值，输入框变成需要点击编辑按钮才能编辑的状态,去除数组中这一行的值
    cancelEditRow(row) {
      this.loading = false;
      this.currentEditorRowDataArr = this.currentEditorRowDataArr.filter(
        (item, index) => {
          if (item.editId === row.editId) {
            row.nav = item.nav;
            row.priceDate = item.priceDate;
            row.cumulativeNavCrawl = item.cumulativeNavCrawl;
            return false;
          } else {
            return true;
          }
        }
      );
      delete row.editId;
      delete row.currentPage;
      row.canEdit = false;
      this.refreshTable();
      this.$message({
        type: "info",
        message: "本次修改将不会生效"
      });
    },
    submitWarnRow({ row, index }) {
      this.submitRow(row, index);
    },
    // 删除净值
    deleteNav(row, index) {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      let navIndex = (this.currentPage - 1) * this.pageSize + index;
      this.$prompt("请输入备注", "确定删除本期净值？", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        inputPattern: /[\s\S]/,
        inputPlaceholder: "请输入备注",
        inputErrorMessage: "备注不能为空"
      })
        .then(({ value }) => {
          this.$http
            .post("datadis/fundNav/del", {
              navList: [
                {
                  id: row.id,
                  fundRemark: {
                    logRemark: value
                  }
                }
              ]
            })
            .then(res => {
              if (!res) return;
              if (res.code === 20000) {
                this.getNavScore();

                // 净值不存在时直接删除
                this.$delete(this.historyNavData, navIndex);
                this.totalItem = this.historyNavData.length;
                this.pageChange(this.currentPage);
                this.$message({
                  message: "删除成功",
                  type: "success"
                });
                this.updatePriceDate(row, index, "del");
                // 在删除一行时，如果如果该行已经编辑，那么在当前编辑行的数组中去除这一行，
                // 这样关闭modal的时候就不会提示有编辑行尚未保存
                this.currentEditorRowDataArr = this.currentEditorRowDataArr.filter(
                  item => {
                    if (item.priceDate !== row.priceDate) {
                      return item;
                    }
                  }
                );
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "取消删除"
          });
        });
    },

    // 修改净值更新频率
    onFreqSelectChange(val) {
      this.navFrequency = val;
      let params = {
        navFrequency: `${val}`
      };
      this.$http
        .putWithoutId(`datadis/fundInformation/${this.fundId}`, params)
        .then(res => {
          if (!res) return;
          this.$message({
            type: "success",
            message: "修改成功"
          });
        })
        .then(() => {
          this.refreshHistoryNav();
          this.$emit("refreshTableData");
          this.$http
            .get(`/datadis/nav/${this.fundId}/getNavScore`)
            .then(res => {
              this.percent = Math.round(res.data.score);
            });
        });
    },
    // 处理提交的数据
    getValidatedData() {
      let validatedData = [];
      let tableData = JSON.parse(JSON.stringify(this.historyNavData));
      this.validatingFlag = tableData.some(row => {
        return row.validating;
      });
      tableData = tableData.filter(item => item.id == null && !item.validating);
      validatedData = tableData
        .filter(item => item.nav && item.priceDate)
        .map(item => {
          return {
            nav: item.nav,
            priceDate: item.priceDate,
            cumulativeNavCrawl: item.cumulativeNavCrawl,
            validateResult: item.validateResult
          };
        });
      return validatedData;
    },

    // 提交历史净值数据，相关逻辑与 app.vue 页面保存当页的逻辑一致
    submitHistoryNav() {
      // 如果还有处于编辑状态的行，阻止关闭并跳转到相应页面
      if (this.currentEditorRowDataArr.length) {
        this.noticeUnSavedRow();
        return;
      }
      // 验证是否有填写过的新增净值行
      let canSubmit = this.historyNavData.some(row => {
        return row.id == null && row.priceDate && row.nav;
      });
      if (!canSubmit) {
        this.cancel();
        return;
      }
      this.validatedData = this.getValidatedData();
      if (this.validatingFlag && this.submitTimeCount < 5) {
        this.loading = true;
        this.saveTimer = setTimeout(() => {
          this.submitTimeCount++;
          this.submitHistoryNav();
        }, 500);
      } else if (this.validatedData.length > 0) {
        this.loading = false;
        this.submitTimeCount = 0;
        let unnormalData = this.validatedData.filter(row => {
          return row.validateResult.qcLevel == 2;
        });
        let errorData = this.validatedData.filter(row => {
          return row.validateResult.qcLevel == 1;
        });
        if (errorData.length) {
          this.$refs.batchErrorModal.open(errorData);
          return;
        }
        if (unnormalData.length > 0) {
          this.$refs.batchWarnModal.open(unnormalData);
        } else {
          this.submitTableNav(true);
        }
      } else {
        this.loading = false;
        this.submitTimeCount = 0;
        this.$message.error("请等待净值检验完成");
      }
    },
    // 提示未保存的编辑行
    noticeUnSavedRow() {
      this.pageChange(this.currentEditorRowDataArr[0].currentPage);
      this.$refs.table.setCurrentRow(
        "priceDate",
        this.currentEditorRowDataArr[0].priceDate
      );
      this.$message.error("您有编辑行尚未保存！");
    },
    submitTableNav(ifSubmitWarnData) {
      let submitData;
      if (ifSubmitWarnData) {
        submitData = this.validatedData.map(item => {
          item.fundId = this.fundId;
          return this.getNavInfo(item);
        });
      } else {
        submitData = this.validatedData
          .filter(item => {
            return item.validateResult.qcLevel != 2;
          })
          .map(row => {
            row.fundId = this.fundId;
            return this.getNavInfo(row);
          });
      }
      // 提交保存
      if (submitData.length == 0) {
        return;
      }
      this.loading = true;
      this.$http.post("datadis/fundNav", { navs: submitData }).then(res => {
        this.loading = false;
        if (!res) return;
        if (res.code == 20000) {
          this.$message({
            type: "success",
            message: "净值添加成功",
            showClose: true
          });
          // this.$emit("refreshTableData")
          this.cancel();
        } else {
          this.$message.error(res.msg);
        }
      });
      console.log(submitData);
    },
    /**
     * val 当前单元格数据
     * data 整行表格数据
     * column 当前行字段信息等
     * index 当前行索引
     */
    onTableCellChange(val, data, column, index) {
      this.$set(data, column.property, val);
      this.$set(
        this.historyNavData,
        index + this.pageSize * (this.currentPage - 1),
        data
      );
      this.validateNav(data);
    },
    validateNav(row) {
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        row.validateResult = null;
        this.validateRow(row).then(res => {
          row.navError = "";
          row.priceDateError = "";
          row.cumulativeNavCrawlError = "";
          if (
            res.code === 20000 &&
            res.data &&
            res.data.qcData instanceof Array
          ) {
            row.validateResult = res.data;
            for (let item of res.data.qcData) {
              this.$set(
                row,
                `${errorMap[item.code].errorField}Error`,
                errorMap[item.code].notice.replace("$date", row.priceDate)
              );
            }
            this.$set(row, "validFlag", !row.validFlag);
          }
        });
      }, 100);
    },
    validateRow(row) {
      return new Promise(resolve => {
        let params = this.getNavInfo(row);
        if (params.nav && params.priceDate) {
          row.validating = true;
          this.$http.get("datadis/fundNav/validate", params).then(res => {
            row.validating = false;
            resolve(res);
          });
        }
      });
    },
    getNavInfo(row) {
      let navInfo = {};
      let needKeys = ["fundId", "priceDate", "nav", "cumulativeNavCrawl", "id"];
      needKeys.forEach(item => {
        if (row[item] === "" || row[item] === undefined || row[item] === null) {
          navInfo[item] = null;
        } else {
          navInfo[item] = row[item];
        }
      });
      if (navInfo.id == null) {
        delete navInfo.id;
      }
      return navInfo;
    },
    // 清空表格中可编辑单元格的验证与数据
    resetValid() {
      this.validItems.forEach(item => {
        if (this.$refs[item][0]) {
          this.$refs[item][0].resetValid();
        }
      });
    },
    // 新增之后，刷新列表
    refreshHistoryNav(keepCurrentRow) {
      this.getHistoryNav(keepCurrentRow);
    },

    // 设置表格高度
    setTableHeight() {
      window.addEventListener("resize", () => {
        let maxHeight = $(".add-nav-modal").height() - 200;
        this.tableMaxHeight = maxHeight;
      });
    },

    // 点击表格某行，添加单独样式
    tableRowClick({ row, column, index }) {
      this.currentRowId = row.priceDate;
      this.$refs.table.setCurrentRow("priceDate", this.currentRowId);
    },

    // 设置表格行样式
    tableRowClassName({ row, rowIndex }) {
      if (rowIndex % 2 === 1) {
        return "odd-row";
      } else {
        return "even-row";
      }
    },

    onEditCellBlur() {},

    // 净值状态发生改变
    onSearchSelectChange(value) {
      this.dataType = value;
      if (!this.fundId) {
        return;
      }
      this.currentPage = 1;
      this.pageSize = 10;
      this.getHistoryNav();
    },
    // 新增分配信息
    addDistibute(row, index) {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      if (row.canEdit) {
        this.$message.warning("请先确认当前行的修改");
      } else {
        this.$refs.distributionModal.open(row.fundId, row.priceDate, row.nav);
        this.status = "add";
      }
    },

    // 删除分配信息
    deleteFundDistribute(rowData, rowIndex, disIndex) {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      this.$confirm("确认删除吗？", "删除", {
        showCancelButton: true,
        type: "warning",
        closeOnClickModal: false,
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            let params = {
              id: rowData.id
            };
            instance.confirmButtonLoading = true;
            instance.confirmButtonText = "删除中...";
            this.$http
              .putWithoutId(`datadis/distribution/applyDelete`, params)
              .then(res => {
                done();
                instance.confirmButtonLoading = false;
                if (!res) return;
                if (res.code == 20000) {
                  this.$message({
                    showClose: true,
                    message: "删除成功",
                    type: "success"
                  });
                  // rowData.auditstate = 4;
                  // this.tableData[rowIndex].distribution[
                  //   disIndex
                  // ].auditstate = 4;
                  let arr = JSON.parse(
                    JSON.stringify(this.tableData[rowIndex].distribution)
                  );
                  _.pullAt(arr, disIndex);
                  this.tableData[rowIndex].distribution = JSON.parse(
                    JSON.stringify(arr)
                  );
                  // this.refreshHistoryNav();
                } else {
                  this.$message({
                    showClose: true,
                    message: "删除失败",
                    type: "error"
                  });
                }
              });
          } else {
            done();
          }
        }
      });
    },
    //前端手动添加分配信息，避免刷新表格丢失修改的数据
    addDistibutionSuccess(data) {
      let currentRowIndex = _.findIndex(this.tableData, item => {
        return item.priceDate === this.currentRowId;
      });

      this.tableData[currentRowIndex].distribution =
        this.tableData[currentRowIndex].distribution instanceof Array
          ? this.tableData[currentRowIndex].distribution
          : [];
      this.tableData[currentRowIndex].distribution.push({
        id: data.disInfo.data.id,
        auditstate: 1,
        distributeDate: data.disInfo.data.distributeDate,
        distributeType: data.disInfo.data.distributeType,
        distribution: data.disInfo.data.distribution
      });
    },
    //导出历史净值
    exportNav() {
      this.$refs.exportNavModal.show(
        this.fundId,
        this.fundName,
        this.inceptionDate
      );
    },
    refreshTable() {
      this.$refs.table.refresh();
      this.tableData.forEach(row => {
        if (typeof row.validFlag === "boolean") {
          this.$set(row, "validFlag", !row.validFlag);
          console.log(row);
          console.log(row.validFlag);
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.search-area {
  width: 100%;
  padding: 10px;
  border: 1px solid rgb(85, 85, 85);
  margin: 0 auto;
  margin-top: 5px;
}
.score-message {
  text-align: right;
}
.table-area {
  margin-top: 10px;
}
.delete-nav {
  cursor: pointer;
  padding: 8px;
}
.operate {
  font-size: 14px;
}
.message-bar {
  width: calc(~"100% - 1px");
  display: flex;
  justify-content: space-between;
  height: 40px;
  align-items: center;
  padding-right: 10px;
  background: #333;
  color: #ffffff;
  font-size: 14px;
  margin-bottom: 1px;
  .fund-name {
    display: inline-block;
    padding-left: 10px;
    border-left: 5px solid #2992ff;
  }
  .search-selector {
    display: inline-block;
    width: 220px;
  }
}
.history {
  margin-top: 48px;
  .el-table__header-wrapper {
    position: fixed !important;
    z-index: 9 !important;
    top: 163px !important;
    width: 96% !important;
  }
}
.add-nav-modal {
  overflow: hidden;
}

.freq-selector {
  display: inline-block;
  margin-left: 20px;
  .label {
    margin-right: 5px;
    font-size: 14px;
  }
}
.score-infomation {
  display: inline-block;
}
</style>

