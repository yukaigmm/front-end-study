<template>
  <vmodal
    ref="modal"
    title="批量导入净值"
    @close="cancel"
    :class="{'import-nav-modal':true,'with-error-table':errorTableData.length, 't2-el-dialog': true}"
    :width="600"
  >
    <div class="import-content-wraper">
      <div class="form-content">
        <p class="tips">
          点击下载
          <a href="/download/excel/nav_import.xlsx" target="_blank" class="templet">历史净值模板</a>,填写后可批量导入历史净值信息
        </p>
        <div class="form-import">
          <vformConfig ref="formModal" :config="formConfig" v-model="form"></vformConfig>
        </div>
      </div>

      <div class="message-bar" v-show="errorTableData.length">
        <div class="message-info">导入成功{{successCount}}条，导入失败{{failCount}}条</div>
      </div>

      <!-- 错误表格区域 -->
      <div class="table-container" v-show="errorTableData.length">
        <div class="table-info-bar cl">
          <span class="table-info">错误详情</span>
        </div>
        <vtable
          :max-height="tableMaxHeight"
          :key="key"
          ref="table"
          :showTips="true"
          :columns="columnsConfig"
          :data="errorTableData"
        ></vtable>
      </div>
      <errorHandleModal ref="errorHandleModal"></errorHandleModal>
    </div>

    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="importNav">保存</vbutton>
    </div>
  </vmodal>
</template>

<script>
import errorHandleModal from "./notice/import-error-handle.vue";
export default {
  components: {
    errorHandleModal
  },
  data() {
    return {
      successCount: "",
      failCount: "",
      form: {},
      formConfig: {
        cols: 1,
        fields: [
          [
            {
              label: "净值文件",
              labelWidth: 80,
              comps: [
                {
                  key: "navFile",
                  compType: "vfileUpload",
                  compConfig: {
                    url: "datadis/nav/uploadImportFile",
                    fileName: "importFile",
                    resName: "fileName",
                    acceptType: `.xlsx,.xlsm,.xlsb,.xltx,.xltm,.xlam,.xls,.xlt`,
                    foreignPath: true
                  },
                  compStyle: {
                    width: "280px"
                  },
                  rules: [
                    { required: true, message: "请上传净值文件" },
                    (rule, value, callback) => {
                      let errors = [];
                      if (
                        value.name &&
                        !/\.xl(s[xmb]{0,1}|t[xm]|am)$/.test(value.name)
                      ) {
                        errors.push(new Error("请上传excel文件"));
                      }
                      callback(errors);
                    }
                  ]
                }
              ]
            }
          ]
        ]
      },
      columnsConfig: [
        {
          title: "错误行号",
          key: "line",
          width: 70
        },
        {
          title: "基金ID",
          key: "fundId",
          width: 100
        },
        {
          title: "基金简称",
          key: "fundShortName",
          render: (h, { row }) => {
            return row.fundShortName ? `${row.fundShortName}` : "--";
          }
        },
        {
          title: "净值日期",
          key: "priceDate",
          width: 90
        },
        {
          title: "错误类型",
          key: "errorMsg",
          renderHeader: h => {
            return h("span", [
              h("span", "操作"),
              h(
                "el-tooltip",
                {
                  props: {
                    enterable: false
                  }
                },
                [
                  h("span", {
                    style: {
                      display: "inline-block",
                      width: "16px",
                      height: "16px",
                      background: `url("${
                        this.$baseUrl[process.env.NODE_ENV]["page"]
                      }/assets/images/question.png") no-repeat`,
                      backgroundSize: "100%",
                      verticalAlign: "-3px",
                      marginLeft: "5px"
                    },
                    on: {
                      click: () => {
                        this.showHandleMethods();
                      }
                    }
                  }),
                  h(
                    "div",
                    {
                      slot: "content"
                    },
                    [
                      h(
                        "span",
                        {
                          style: {
                            color: "#27d"
                          }
                        },
                        "说明："
                      ),
                      h("span", "点击查看处理方法")
                    ]
                  )
                ]
              )
            ]);
          }
        }
      ],
      errorTableData: [],
      key: "",
      // totalItem: "",
      // currentPage: 1,
      tableMaxHeight: null
      // allErrorTableData:[],
      // pageSize:10
    };
  },
  //  watch:{
  //    errorTableData:{
  //        handler(val){

  //        }
  //     }
  //  },
  methods: {
    // 设置表格高度
    setTableHeight() {
      let maxHeight = 600 - 345;
      this.tableMaxHeight = maxHeight;
      window.addEventListener("resize", () => {
        let maxHeight = $(".import-nav-modal").height() - 345;
        this.tableMaxHeight = maxHeight;
      });
    },
    // currentChange(val) {
    //   this.currentPage = val;

    //   let endIndex = val * this.pageSize;
    //   let startIndex = endIndex - this.pageSize;
    //   if (endIndex > this.totalItem - 1) {
    //     this.errorTableData = this.allErrorTableData.slice(startIndex);
    //   } else {
    //     this.errorTableData = this.allErrorTableData.slice(
    //       startIndex,
    //       endIndex
    //     );
    //   }
    // },
    // sizeChange(val) {
    //   this.pageSize = val;
    //   let endIndex = val * this.currentPage;
    //   let startIndex = endIndex - val;
    //   if (endIndex > this.totalItem - 1) {
    //     this.errorTableData = this.allErrorTableData.slice(startIndex);
    //   } else {
    //     this.errorTableData = this.allErrorTableData.slice(
    //       startIndex,
    //       endIndex
    //     );
    //   }

    // },
    showHandleMethods() {
      this.$refs.errorHandleModal.show();
    },

    show() {
      this.$refs.modal.open();
    },
    cancel() {
      // this.totalItem = 0;
      this.key = Date.now();
      // this.currentPage = 1;
      // this.pageSize = 10;
      // this.allErrorTableData = [];
      this.errorTableData = [];
      this.$delete(this.form, "navFile");
      this.$refs.modal.close();
      this.$refs.formModal.resetValid();
    },

    importNav() {
      this.$refs.formModal.valid().then(valid => {
        if (valid) {
          let params = {
            filePath: this.form.navFile.filePath
          };

          this.$http.post("datadis/nav/importNav", params).then(res => {
            if (!res) return;
            if (res.code === 20000) {
              if (res.data.failCnt == 0 && res.data.successCnt == 0) {
                this.$message({
                  type: "error",
                  message: "模板错误，请重新选择"
                });
                this.cancel();
              } else {
                if (res.data.failCnt == 0) {
                  this.$message({
                    type: "success",
                    message: "导入成功"
                  });
                  sa.event("fundMaster_navImport", {});
                  this.cancel();
                } else {
                  // this.$message({
                  //   type: "info",
                  //   message: `导入成功${res.data.successCnt}条，失败${
                  //     res.data.failCnt
                  //   }条`

                  // });
                  this.successCount = res.data.successCnt;
                  this.failCount = res.data.failCnt;
                  this.setTableHeight();
                  this.errorTableData = res.data.error.reverse();
                  // this.totalItem = res.data.error.length;
                  // this.errorTableData = this.allErrorTableData.slice(0, 10);
                }
              }
            } else {
              this.$message({
                type: "error",
                message: "导入失败"
              });
            }
          });
        } else {
          this.$message.error("请按红色提示补充信息");
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.import-content-wraper {
  padding: 10px;
}
.form-content {
  height: 130px;
  // padding: 15px;
  border: 1px solid #999;
  margin-bottom: 5px;
}
.tips {
  padding-left: 90px;
}
.templet {
  color: #27d;
  text-decoration: underline;
  cursor: pointer;
}
.modal.modal-fixed-footer {
  height: 400px;
}
.modal.modal-fixed-footer.with-error-table {
  height: 600px;
}
.form-import {
  padding-left: 80px;
}

.table-container {
  border: 1px solid #999;
}
.message-bar {
  color: #ffffff;
  height: 40px;
  display: flex;
  align-items: center;
  background-color: #333;
  margin: 5px 0;
  border: 1px solid #999;
  .message-info {
    height: 14px;
    padding-left: 10px;
    border-left: 5px solid #2992ff;
    line-height: 14px;
  }
}
</style>

