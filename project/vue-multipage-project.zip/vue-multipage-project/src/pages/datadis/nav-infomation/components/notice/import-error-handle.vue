<template>
    <vmodal ref="modal" title="错误处理" class="error-handle t2-el-dialog" :width="300">
    <div class="handle-methods">
            <p>1.查询基金信息失败：查询不到基金信息，请检查导入文件中“融智产品ID”字段是否填写正确</p>
            <p>2. 基金缺失：查询不到基金信息，请检查导入文件中“融智产品ID”字段是否填写正确</p>
            <p>3. 非本公司基金：导入功能只能修改本公司基金的净值，请确保导入文件中的基金是您公司的产品</p>
            <p>4. 基金募集中：导入的基金处于募集中状态，不能修改净值信息，请检查导入文件中“融智产品ID”是否填写正确</p>
            <p>5. 净值日期输出错误：净值日期填写不正确，请按模板中的格式修改导入文件中的“日期”字段</p>
            <p>6. 日期转换失败：净值日期填写不正确，请按模板中的格式修改导入文件中的“日期”字段</p>
            <p>7. 净值日期缺失：净值日期未填写，请按模板中格式填写净值日期</p>
            <p>8. 净值日期大于当前日期：净值日期大于当前日期，请修改净值日期</p>
            <p>9. 净值日期大于清算日期：净值日期大于清算日期，请修改净值日期</p>
            <p>10. 净值缺失：净值未填写，请按模板中的要求填写净值</p>
            <p>11. 净值涨幅过大：净值超过前次净值幅度过大，请检查净值是否填写正确</p>
            <p>12. 超出阈值：净值超出前次净值幅度过大，请检查净值是否填写正确</p>
            <p>13. 净值已存在：数据库中已存在相同日期的净值数据，导入的数据不会生效。</p>
    </div>
     <div slot="modal-footer">
          <vbutton active @click="close">关闭</vbutton>
      </div>
    </vmodal>
</template>

<script>
export default {
  data() {},
  methods: {
    show() {
      this.$refs.modal.open();
    },
    close() {
      this.$refs.modal.close();
    }
  }
};
</script>

<style lang="less" scoped>
.modal.modal-fixed-footer {
  font-size: 14px;
  width: 450px !important;
  height: 400px;
}
.handle-methods{
    height: 100%;
    padding: 15px;
    overflow-y: auto;
}
</style>


