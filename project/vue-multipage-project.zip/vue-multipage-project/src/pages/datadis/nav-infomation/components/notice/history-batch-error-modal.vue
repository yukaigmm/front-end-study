<template>
    <vmodal ref="modal" class="t2-el-dialog" :width="900" title="净值保存" @close="close">
    <div>您本次保存的数据存在错误数据，请修正后再保存</div>
     <vtable
        ref="table"
        :max-height="200"
        :columns="columns"
        :data="tableData"
      ></vtable>
    <div slot="modal-footer">
        <!-- <vbutton @click="cancel">取消</vbutton> -->
        <vbutton active @click="confirm">确定</vbutton>
    </div>
  </vmodal>
</template>

<script>
    import errorMap from '../../error-map';
    export default {
        data(){
            return {
                columns: [
                    {
                        title: "净值日期",
                        key: "priceDate",
                        width: 140
                    },
                    {
                        title: "单位净值",
                        key: "nav",
                        width: 100
                    },
                    {
                        title: "累计净值",
                        key: "cumulativeNavCrawl",
                        width: 100
                    },
                    {
                        title: "错误信息",
                        key: "errorInfo",
                    },
                ],
                tableData: []
            }
        },
        methods: {
            open(errorData){
                this.$refs.modal.open();
                this.tableData = errorData.map((item) => {
                    let errorInfo = item.validateResult.qcData.map((data) => {
                        // return data.msg;
                        return errorMap[data.code].notice.replace("$date", item.priceDate);
                    }).join("\n\r");
                    return {
                        fundShortName: item.fundShortName,
                        fundId: item.fundId,
                        priceDate: item.priceDate,
                        nav: item.nav,
                        cumulativeNavCrawl: item.cumulativeNavCrawl,
                        errorInfo: errorInfo
                    }
                })
            },
            close(){

            },
            // cancel(){
            //     this.$refs.modal.close();
            //     this.$emit("submitWarnNav", false)
            // },
            confirm(){
                // this.$emit("submitWarnNav", true);
                this.$refs.modal.close();
            }
        },
    }
</script>
<style lang="less" scoped>
    .warn-item{
        line-height: 20px;
    }
    .notice{
        color: #f45;
        font-size: 14px;
    }
</style>