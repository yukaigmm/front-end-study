<template>
  <div class="file-upload add file-field input-field" :class="{invalid: invalid}" title="导入">
    <div class="button">
      <vbutton active icon="icon-excelwenjian">导入</vbutton>
      <form ref="uploadForm" enctype="multipart/form-data">
        <input
          type="file"
          :name="fileName"
          ref="docFile"
          :multiple="multiple"
          @change="changeValue"
        >
      </form>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    value: {},
    multiple: {},
    url: {},
    fileName: {
      type: String,
      default: "importFile"
    },
    resName: {}
  },
  data() {
    return {
      val: "",
      invalid: false,
      docName: ""
    };
  },
  methods: {
    changeValue(event) {
      let files = event.target.files;
      let file = files[0] || {};
      this.docName = file.name;
      let form = this.$refs.uploadForm;
      let formData = new FormData(form);
      let id = this.$message({
        message: "正在导入中...",
        type: "info",
        duration: 0
      });
      this.$http
        .post(this.url, formData)
        .then(res => {
          if (!res) return;
          if (res) {
            if (res.code === 20000) {
              let data = res.data;
              data.name = this.docName;
              this.$emit("input", data);
              this.$emit("change", data);
              this.$refs.docFile.value = "";
              return data;
            } else {
              this.$message.closeAll();
              this.$message({
                type: "error",
                message: "文件上传失败"
              });
            }
          } else {
            this.$message.closeAll();
            this.$message({
              type: "error",
              message: "文件上传失败"
            });
          }
        })
        .then(data => {
          let params = {
            filePath: data.filePath
          };

          this.$http.post("datadis/nav/importNav", params).then(res => {
            if (!res) return;
            if (res.code === 20000) {
              this.$message.closeAll();
              this.$message({
                type: "success",
                message: "导入成功"
              });
            } else {
              this.$message.closeAll();
              this.$message({
                type: "error",
                message: "导入失败"
              });
            }
          });
        });
    },
    toggleInvalidClass(invalid) {
      this.invalid = invalid;
    }
  },
  mounted() {
    // this.val = this.value;
  },
  watch: {
    value: {
      handler(val) {
        if (JSON.parse(JSON.stringify(val) == "{}" || !val)) {
          this.val = { [this.resName]: "" };
          this.docName = "";
        } else {
          this.val = val;
        }
      },
      deep: true
    }
  }
};
</script>

<style lang="less" rel="styleSheet/less" scoped>
.add {
  margin-top: 5px;
  margin-right: 36px;
  float: left;
}
.file-upload {
  height: 30px;
  margin-bottom: 0;

  .btn {
    height: 30px;
    line-height: 30px;
    background-color: #2992ff;
  }
  .file-path-wrapper {
    & > input {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  &.file-field {
    width: 40px;
    input[type="file"] {
      width: 40px;
    }
  }
}
</style>