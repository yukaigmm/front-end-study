<template>
    <vmodal ref="modal" class="t2-el-dialog" :width="900" title="净值保存" @close="close">
    <div>您本次保存的数据存在异常数据，数据提交后需要排排网工作人员审核确认</div>
    <div class="notice">点击确认继续提交数据，点击取消放弃提交数据</div>
     <vtable
        ref="table"
        :max-height="200"
        :columns="columns"
        :data="tableData"
      ></vtable>
    <div slot="modal-footer">
        <vbutton @click="cancel">取消</vbutton>
        <vbutton active @click="confirm">确定</vbutton>
    </div>
  </vmodal>
</template>

<script>
    import errorMap from '../../error-map';
    export default {
        data(){
            return {
                columns: [
                    {
                        title: "净值日期",
                        key: "priceDate",
                        width: 140
                    },
                    {
                        title: "单位净值",
                        key: "nav",
                        width: 100
                    },
                    {
                        title: "累计净值",
                        key: "cumulativeNavCrawl",
                        width: 100,
                        render: (h, {row}) => {
                            return h("div", row.cumulativeNavCrawl || "--");
                        }
                    },
                    {
                        title: "异常信息",
                        key: "errorInfo",
                    },
                ],
                tableData: []
            }
        },
        methods: {
            open(unnormalData){
                this.$refs.modal.open();
                this.tableData = unnormalData.map((item) => {
                    let errorInfo = item.validateResult.qcData.map((data) => {
                        // return item.msg;
                        return errorMap[data.code].notice.replace("$date", item.priceDate)
                    }).join("，");
                    return {
                        fundShortName: item.fundShortName,
                        fundId: item.fundId,
                        priceDate: item.priceDate,
                        nav: item.nav,
                        cumulativeNavCrawl: item.cumulativeNavCrawl,
                        errorInfo: errorInfo
                    }
                })
            },
            close(){

            },
            cancel(){
                this.$refs.modal.close();
                this.$emit("submitWarnNav", false)
            },
            confirm(){
                this.$emit("submitWarnNav", true);
                this.$refs.modal.close();
            }
        },
    }
</script>
<style lang="less" scoped>
    .warn-item{
        line-height: 20px;
    }
    .notice{
        color: #f45;
        font-size: 14px;
    }
</style>