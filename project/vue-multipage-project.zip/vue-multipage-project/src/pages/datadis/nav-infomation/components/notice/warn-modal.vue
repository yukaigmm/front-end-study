<template>
    <vmodal ref="modal" class="t2-el-dialog" :width="warnInfo.length == 1 ? 550 : 400" title="净值保存" @close="close">
        <div class="warn-item-container" v-if="warnInfo.length > 1">
            <div v-for="(item, key) in warnInfo" :key="key" class="warn-item">{{item}}，</div>
            <div class="warn-item">数据提交后需要排排网工作人员审核确认</div>
        </div>
        <div class="warn-item-container" v-else>
            <div v-for="(item, key) in warnInfo" :key="key" class="warn-item">{{item}}，数据提交后需要排排网工作人员审核确认</div>
        </div>
    <div class="notice">点击确认继续提交数据，点击取消放弃提交数据</div>
    <div slot="modal-footer">
        <vbutton @click="cancel">取消</vbutton>
        <vbutton active @click="confirm">确定</vbutton>
    </div>
  </vmodal>
</template>

<script>
    import errorMap from '../../error-map';
    export default {
        data(){
            return {
                warnInfo: [],
                currentRow: {},
                currentIndex: "",
            }
        },
        methods: {
            open(qcData, row, index){
                this.currentRow = row;
                this.currentIndex = index;
                this.$refs.modal.open();
                this.warnInfo = qcData.map((item) => {
                    return errorMap[item.code].notice.replace("$date", row.priceDate);
                })
            },
            close(){
                this.currentRow = {};
                this.currentIndex = "";
            },
            cancel(){
                this.$refs.modal.close();
            },
            confirm(){
                this.$emit("submitNav",{row: this.currentRow, index: this.currentIndex});
                this.cancel();
            }
        },
    }
</script>
<style lang="less" scoped>
    .warn-item{
        line-height: 20px;
    }
    .notice{
        color: #f45;
        font-size: 14px;
    }
</style>