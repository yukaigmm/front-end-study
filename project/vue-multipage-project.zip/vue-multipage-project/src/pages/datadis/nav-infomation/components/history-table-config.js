function columnsConfig() {
    return [
      {
        title: "净值日期",
        canEdit: true,
        key: "priceDate",
        width: 140,
        showOverflowTooltip: false,
        render: (h, { row, column, index }) => {
          if (row.id !== null) {
            let priceDate = row.priceDate;
            return priceDate ? priceDate : "--";
          } else {
            return h("editTableCell", {
              props: {
                tableRow: row.validFlag,
                comps: {
                  compType: "vdatePicker",
                  key: "priceDate",
                  compConfig: {
                    disabled: !this.userEditable
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];
                      if (row.priceDateError) {
                        errors.push(new Error(row.priceDateError));
                      }
                      callback(errors);
                    }
                  ]
                },
                value: row.priceDate
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              }
            });
          }
        }
      },
      {
        title: "单位净值",
        canEdit: true,
        key: "nav",
        align: "right",
        showOverflowTooltip: false,
        render: (h, { row, column, index }) => {
          if (row.id !== null && !row.canEdit) {
            let nav = row.nav;
            return nav ? Number(nav).toFixed(4) : "--";
          } else {
            return h("editTableCell", {
              props: {
                ifTextAlignRight: true,
                tableRow: row.validFlag,
                comps: {
                  compType: "vinput",
                  key: "nav",
                  compConfig: {
                    disabled: !this.userEditable
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];
                      if (value) {
                        if (value <= 0) {
                          errors.push(new Error("净值应该大于0"));
                        }
                      }
                      callback(errors);
                    },
                    (rule, value, callback) => {
                      let errors = [];
                      if (value) {
                        if (isNaN(Number(value))) {
                          errors.push(new Error("请输入数字"));
                        }
                      }
                      callback(errors);
                    },
                    (rule, value, callback) => {
                      let errors = [];
                      if (row.navError && row.nav) {
                        errors.push(new Error(row.navError));
                      }
                      callback(errors);
                    },
                  ]
                },
                value: row.nav
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              }
            });
          }
        }
      },
      {
        title: "累计净值",
        canEdit: true,
        key: "cumulativeNavCrawl",
        align: "right",
        showOverflowTooltip: false,
        render: (h, { row, column, index }) => {
          let ifDisabled = !row.nav;
          if (row.id !== null && !row.canEdit) {
            let cumulativeNavCrawl = row.cumulativeNavCrawl;
            return cumulativeNavCrawl
              ? Number(cumulativeNavCrawl).toFixed(4)
              : "--";
          } else {
            let cumulativeNavCrawlInput = h("editTableCell", {
              props: {
                ifTextAlignRight: true,
                tableRow: row.validFlag,
                comps: {
                  compType: "vinput",
                  key: "cumulativeNavCrawl",
                  compConfig: {
                    disabled: ifDisabled
                  },
                  rules: [
                    (rule, value, callback) => {
                      let errors = [];
                      if (value) {
                        if (isNaN(Number(value))) {
                          errors.push(new Error("请输入数字"));
                        }
                      }
                      callback(errors);
                    },
                    (rule, value, callback) => {
                      let errors = [];
                      if (row.cumulativeNavCrawlError) {
                        errors.push(new Error(row.cumulativeNavCrawlError));
                      }
                      callback(errors);
                    },
                  ]
                },
                value: row.cumulativeNavCrawl
              },
              on: {
                change: val => {
                  this.onTableCellChange(val, row, column, index);
                }
              }
            });
            if (ifDisabled) {
              return h(
                "el-tooltip",
                {
                  props: {
                    enterable: false
                  }
                },
                [
                  cumulativeNavCrawlInput,
                  h(
                    "div",
                    {
                      slot: "content"
                    },
                    "请先填写单位净值"
                  )
                ]
              );
            } else {
              return cumulativeNavCrawlInput;
            }
          }
        }
      },
      {
        title: "上期净值日期",
        key: "preDate",
        render(h, { row, column, index }) {
          let prePriceDate = row.preDate;
          return prePriceDate ? prePriceDate : "--";
        }
      },
      {
        title: "上期单位净值",
        key: "preNav",
        align: "right",
        render(h, { row, column, index }) {
          let preNav = row.preNav;
          return preNav ? Number(preNav).toFixed(4) : "--";
        }
      },
      {
        title: "分配信息",
        key: "distribution",
        width: 80,
        render: (h, { row, column, index }) => {
          // let classNameMapping = {
          //   "1": "icon-fenhongjilu",
          //   "2": "icon-divide",
          //   "3": "icon-payment",
          //   "-1": "icon-qita"
          // };
          // let styleMapping = {
          //   "1": { color: "red", "margin-right": "5px" },
          //   "2": { color: "yellow", "margin-right": "5px" },
          //   "3": { color: "blue", "margin-right": "5px" },
          //   "-1": { color: "white", "margin-right": "5px" }
          // };
          let typeMapping = {
            "1": "分红",
            "2": "拆分",
            "3": "业绩报酬",
            "-1": "其他"
          };
          let auditstateMap = {
            "0": "未审核",
            "1": "已审核",
            "2": "新增申请中",
            "3": "更新申请中",
            "4": "删除申请中",
            "5": "未通过",
            "6": "删除失败",
            "-1": "草稿"
          };
          if (row.distribution && row.distribution.length) {
            let initDistribution = JSON.parse(
              JSON.stringify(row.distribution)
            );
            let distribution = [];
            distribution = _.sortBy(initDistribution, [
              function(o) {
                return o.distributeType;
              }
            ]);
            if (distribution[0].distributeType == -1) {
              distribution = distribution.concat(distribution.splice(0, 1));
            }

            let divStyle = {
              display: "flex",
              "justify-content": "space-between",
              "align-items": "center",
              width: "320px",
              paddingBottom: "3px"
            };
            let text =
              distribution.length > 1
                ? `${typeMapping[distribution[0].distributeType]}...`
                : `${typeMapping[distribution[0].distributeType]}`;
            return h(
              "el-tooltip",
              {
                props: {
                  offset: -3
                }
              },
              [
                h("div", `${text}`),
                h(
                  "div",
                  {
                    slot: "content"
                  },
                  [
                    h(
                      "div",
                      {
                        style: Object.assign(
                          {
                            borderBottom: "1px dashed #555",
                            color: "#27d",
                            paddingBottom: "5px"
                          },
                          divStyle
                        )
                      },
                      [
                        h(
                          "span",
                          {
                            style: {
                              flex: 3,
                              textAlign: "center"
                            }
                          },
                          "分配类型"
                        ),
                        h(
                          "span",
                          {
                            style: {
                              flex: 3,
                              textAlign: "center"
                            }
                          },
                          "分配比例"
                        ),
                        h(
                          "span",
                          {
                            style: {
                              flex: 3,
                              textAlign: "center"
                            }
                          },
                          "审核状态"
                        ),
                        h(
                          "span",
                          {
                            style: {
                              flex: 2,
                              textAlign: "center"
                            }
                          },
                          "操作"
                        )
                      ]
                    )
                  ].concat(
                    distribution.map((item, ind) => {
                      let style = Object.assign(
                        {
                          color: "#aaa",
                          marginBottom: 0
                        },
                        divStyle
                      );
                      return h(
                        "div",
                        {
                          style: style
                        },
                        [
                          h(
                            "span",
                            {
                              style: { flex: 3, textAlign: "center" }
                            },
                            `${typeMapping[item.distributeType]}`
                          ),
                          h(
                            "span",
                            {
                              style: { flex: 3, textAlign: "center" }
                            },
                            `${Number(item.distribution).toFixed(4)}`
                          ),
                          h(
                            "span",
                            {
                              style: { flex: 3, textAlign: "center" }
                            },
                            `${auditstateMap[item.auditstate] || "--"}`
                          ),

                          h(
                            "div",
                            {
                              style: {
                                marginLeft: "5px",
                                flex: 2,
                                textAlign: "center"
                              }
                            },
                            [
                              h("vbuttonSprite", {
                                props: {
                                  disabled: row.auditstate == 4,
                                  pos: {
                                    normal: { x: 0, y: -241 },
                                    hover: { x: -18, y: -241 },
                                    disabled: { x: -36, y: -241 }
                                  },
                                  title: "删除"
                                },
                                style: {
                                  verticalAlign: "middle",
                                  display: "inline-block"
                                },
                                on: {
                                  click: e => {
                                    this.deleteFundDistribute(
                                      item,
                                      index,
                                      ind
                                    );
                                  }
                                }
                              })
                            ]
                          )
                        ]
                      );
                    })
                  )
                )
              ]
            );
          } else {
            return "--";
          }
        }
      },
      {
        title: "审核状态",
        key: "auditstate",
        render(h, { row, column, index }) {
          let map = {
            "1": "通过",
            "2": "新增申请中",
            "3": "更新申请中",
            "4": "删除申请中",
            "5": "未通过",
            "6": "删除失败",
            "-1": "草稿"
          };
          if (row.isAutoCheck == "0") {
            map["5"] = "人工审核失败";
          } else {
            map["5"] = "人工审核中";
          }
          return map[row.auditstate] ? map[row.auditstate] : "--";
        }
      },
      {
        title: "操作",
        key: "action",
        width: 134,
        align: "center",
        showOverflowTooltip: false,
        renderHeader(h) {
          return h("span", [
            h("span", "操作"),
            h(
              "el-tooltip",
              {
                props: {
                  enterable: false
                }
              },
              [
                h("span", {
                  style: {
                    display: "inline-block",
                    width: "16px",
                    height: "16px",
                    background: `url("${
                      this.$baseUrl[process.env.NODE_ENV]["page"]
                    }/assets/images/question.png") no-repeat`,
                    backgroundSize: "100%",
                    verticalAlign: "-3px",
                    marginLeft: "5px"
                  }
                }),
                h(
                  "div",
                  {
                    slot: "content"
                  },
                  [
                    h(
                      "span",
                      {
                        style: {
                          color: "#27d"
                        }
                      },
                      "说明："
                    ),
                    h("span", "只有有净值记录的基金，才能添加分红信息")
                  ]
                )
              ]
            )
          ]);
        },
        render: (h, { row, column, index }) => {
          return h(
            "div",
            {
              class: "table-action-button-container"
            },
            [
              //编辑
              h("vbuttonSprite", {
                props: {
                  disabled:
                    !(
                      row.auditstate == 1 ||
                      row.auditstate == 5 ||
                      row.auditstate == 6 ||
                      (row.auditstate == null && row.id !== null)
                    ) || row.auditstate == 4,
                  pos: row.canEdit
                    ? {
                        normal: { x: 0, y: -0 },
                        hover: { x: -18, y: -0 },
                        disabled: { x: -36, y: -0 }
                      }
                    : {
                        normal: { x: 0, y: -19 },
                        hover: { x: -18, y: -19 },
                        disabled: { x: -36, y: -19 }
                      },
                  title: row.canEdit ? "保存" : "编辑"
                },
                style: {
                  verticalAlign: "middle",
                  marginRight: "20px"
                },
                on: {
                  click: e => {
                    if (!this.userEditable) {
                      this.$message.error("只读账号无法进行此操作");
                      return;
                    }
                    if (!row.canEdit) {
                      row.editId = new Date().getTime();
                      row.currentPage = this.currentPage;
                      row.index = index;
                      this.currentEditorRowDataArr.push(
                        JSON.parse(JSON.stringify(row))
                        // row
                      );
                      this.currentEditorRowDataArr = _.uniqBy(
                        this.currentEditorRowDataArr,
                        "id"
                      );
                      row.canEdit = true;
                      // this.$refs.table.refresh();
                      this.refreshTable();
                    } else {
                      this.editNav(row, index);
                    }
                  }
                }
              }),
              //删除
              h("vbuttonSprite", {
                props: {
                  disabled: row.auditstate == 4 || row.id === null,
                  pos: {
                    normal: { x: 0, y: -241 },
                    hover: { x: -18, y: -241 },
                    disabled: { x: -36, y: -241 }
                  },
                  title: "删除"
                },
                style: {
                  verticalAlign: "middle",
                  marginRight: "20px"
                },
                on: {
                  click: e => {
                    this.deleteNav(row, index);
                  }
                }
              }),
              //分红
              h("vbuttonSprite", {
                props: {
                  disabled: row.id === null || row.auditstate == 4,
                  pos: {
                    normal: { x: 0, y: -38 },
                    hover: { x: -18, y: -38 },
                    disabled: { x: -36, y: -38 }
                  },
                  title: "添加分红"
                },
                style: {
                  verticalAlign: "middle",
                  marginRight: "20px"
                },
                on: {
                  click: e => {
                    this.addDistibute(row, index);
                  }
                }
              })
            ]
          );
        }
      }
    ];
  }

  export default columnsConfig;