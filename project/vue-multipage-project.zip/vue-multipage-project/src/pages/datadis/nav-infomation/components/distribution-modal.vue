<template>
  <vmodal ref="modal" :width="900" class="t2-el-dialog" @close="cancel" :title="distributionTitle">
    <vloading slot="loading" v-model="modalLoading" :title="loadingTitle" class="loading"></vloading>
    <div class="distribution-form-container">
      <vformConfig ref="formCollection" :config="formCollectionConfig" v-model="form"></vformConfig>
      <vloading v-model="loading" class="loading"></vloading>
    </div>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="confirm">保存</vbutton>
    </div>
  </vmodal>
</template>

<script>
export default {
  props: ["status"],
  data() {
    // const validateNum = (rule, value, callback, source, options) => {
    //     let errors = [];
    //     if (value && !/^[0-9]+([.]{1}[0-9]+){0,1}$/.test(value)) {
    //       errors.push(new Error("分配比例必须为整数或小数"));
    //     }
    //     callback(errors);
    //   };

    return {
      nav: "",
      loading: false,
      modalLoading: false,
      distributeId: "",
      distributionTitle: "分配信息",
      ifDisabled: false,
      form: {},
      options: [],
      fundId: "",
      distributeMap: {
        "1": {
          label: "分红金额",
          key: "distributeNum"
        },
        "2": {
          label: "拆分比例",
          key: "splitPercent"
        },
        "3": {
          label: "业绩报酬",
          key: "yieldDistribute"
        },
        "-1": {
          label: "分红金额",
          key: "distributeOthers"
        }
      }
    };
  },

  watch: {
    // "form.distributeType": {
    //   handler(val) {
    //     this.$refs.formCollection
    //   },
    //   deep: true,
    //   immediate: true
    // }
  },

  created() {
    this.$http.get("datadis/company/getSelfFund").then(res => {
      this.options = res.data.map(item => ({
        label: item.fundShortName,
        value: item.fundId
      }));
    });
  },

  methods: {
    //   显示模态框
    open(fundId, distributeDate, nav) {
      this.nav = nav;
      this.fundId = fundId;
      if (fundId && distributeDate) {
        this.$set(this.form, "fundId", fundId);
        this.$set(this.form, "distributeDate", distributeDate);
        this.ifDisabled = true;
      }
      this.$refs.modal.open();
    },
    // 隐藏模态框
    close() {
      this.ifDisabled = false;
      this.nav = "";
      this.$refs.modal.close();
    },
    clearForm() {
      this.form = {};
    },
    reset() {
      setTimeout(() => {
        this.$refs.formCollection.resetValid();
      }, 100);
    },
    cancel() {
      this.close();
      this.clearForm();
      this.reset();
    },
    //  确认提交
    confirm() {
      if (!(window.sessionStorage.getItem("canSend") === "false")) {
        this.modalLoading = true;
      }
      // console.log(this.getSubmitData())
      // let form = JSON.parse(JSON.stringify(this.form));
      this.$refs.formCollection.valid().then(valid => {
        // console.log(valid);
        if (valid) {
          let formData = this.getSubmitData();
          if (this.status == "add") {
            this.$http.post("datadis/distribution", formData).then(res => {
              this.modalLoading = false;
              if (!res) return;
              if (res && res.code === 20000) {
                //监听添加分红事件
                sa.event("fundMaster_addDistribution", { fundId: this.fundId });

                this.cancel();
                this.$message.success("新增成功");
                this.$emit("success", res.data);
              } else {
                this.$message.error(res.msg);
              }
            });
          } else if (this.status == "modify") {
            this.$http
              .put("datadis/distribution", formData, this.distributeId)
              .then(res => {
                this.modalLoading = false;
                if (!res) return;
                if (res && res.code === 20000) {
                  this.cancel();
                  this.$message.success("修改成功");
                  this.$emit("getDistributionList", true);
                } else {
                  this.$message.error(res.msg);
                }
              });
          }
        } else {
          this.modalLoading = false;
          this.$message.error("请按红色提示补充信息");
        }
      });
    },
    getDistributeInfo(id) {
      this.distributeId = id;
      this.loading = true;
      this.$http.get(`datadis/distribution/${id}`).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          this.form = res.data;
          this.form.attach = {
            fileName: this.form.attachName,
            filePath: this.form.attachPath
          };
        }
      });
    },
    getSubmitData() {
      let form = JSON.parse(JSON.stringify(this.form));
      let attachName, attachPath;
      if (this.form.attach) {
        attachName = this.form.attach.fileName;
        attachPath = this.form.attach.filePath;
        // this.form.attach = null;
      }
      // 清除掉无效的参数键值对
      // form = this.removeInvalidKeys(form);
      let formData = Object.assign({}, form, { attachName, attachPath });
      formData.attach = null;
      return formData;
    },
    removeInvalidKeys(formData) {
      let form = JSON.parse(JSON.stringify(formData));
      delete form.distributeNum;
      delete form.splitPercent;
      delete form.yieldDistribute;
      delete form.distributeOthers;
      return form;
    }
  },
  computed: {
    loadingTitle() {
      return this.status == "add" ? "添加中..." : "修改中...";
    },
    formCollectionConfig() {
      const validateBetweenTwoNumbers = (lessValue, bigValue, msg, equal) => {
        return function(rule, value, callback, source, options) {
          var errors = [];
          if (equal) {
            if (value && !(value >= lessValue && value <= bigValue)) {
              errors.push(new Error(msg));
            }
          } else {
            if (value && !(value > lessValue && value < bigValue)) {
              errors.push(new Error(msg));
            }
          }
          callback(errors);
        };
      };

      const validateIfBiggerThanNav = (rules, val, cb) => {
        let mapping = {
          "1": "分红",
          "2": "拆分",
          "3": "业绩报酬",
          "-1": "其他"
        };

        let text = mapping[this.form.distributeType];
        let needArr = [1, -1, 3];
        let errors = [];
        if (val && needArr.includes(this.form.distributeType)) {
          if (val > this.nav) {
            let nav = new Number(this.nav);
            errors.push(`不能大于最新净值${nav.toFixed(4)}`);
          }
        }

        cb(errors);
      };

      return {
        cols: 2,
        fields: [
          [
            {
              label: "基金名称",
              labelWidth: 80,
              comps: [
                {
                  key: "fundId",
                  compType: "vtext",
                  compConfig: {
                    options: this.options
                  }
                }
              ]
            },
            {
              label: "分配日期",
              labelWidth: 80,
              comps: [
                {
                  key: "distributeDate",
                  compType: "vdatePicker",
                  rules: [
                    {
                      required: true,
                      message: "分配日期不能为空"
                    }
                  ],
                  compConfig: {
                    placeholder: "请选择分配日期",
                    disabled: this.ifDisabled
                  },
                  compStyle: {
                    width: "180px"
                  }
                }
              ]
            }
          ],
          [
            {
              label: "分配类型",
              labelWidth: 80,
              comps: [
                {
                  key: "distributeType",
                  compType: "vradio",
                  compConfig: {
                    radioKey: "distributeType",
                    options: [
                      {
                        value: 1,
                        label: "分红"
                      },
                      {
                        value: 2,
                        label: "拆分"
                      },
                      {
                        value: 3,
                        label: "业绩报酬"
                      },
                      {
                        value: -1,
                        label: "其他"
                      }
                    ]
                  },
                  rules: [
                    {
                      required: true,
                      message: "分配类型不能为空"
                    }
                  ]
                }
              ]
            },
            {
              // 不改变 key 值，只根据 rules 是否变化来直接 resetValid
              label: `${
                this.distributeMap[this.form.distributeType]
                  ? this.distributeMap[this.form.distributeType]["label"]
                  : "分红金额"
              }`,
              labelWidth: 80,
              comps: [
                {
                  // key: `${this.distributeMap[this.form.distributeType] ?
                  // this.distributeMap[this.form.distributeType]['key']:
                  // "distribution"}`,
                  key: "distribution",
                  compType: "vinput",
                  rules: [
                    {
                      required: true,
                      message: `${
                        this.distributeMap[this.form.distributeType]
                          ? this.distributeMap[this.form.distributeType][
                              "label"
                            ]
                          : "分红金额"
                      }不能为空`
                    },
                    // validateNum,
                    this.form.distributeType == 2
                      ? validateBetweenTwoNumbers(
                          0,
                          100,
                          "请输入大于等于0小于等于100的数字",
                          true
                        )
                      : "",
                    { validator: validateIfBiggerThanNav }
                  ],
                  compConfig: {
                    placeholder:
                      this.form.distributeType == 2
                        ? "请输入拆分比例"
                        : "请输入单位基金份额分红金额",
                    // number:true,
                    floatPoint: 2
                  },
                  compStyle: {
                    width: "180px"
                  }
                },
                function() {
                  if (
                    this.form.distributeType &&
                    this.form.distributeType != 2
                  ) {
                    return {
                      key: "attachText",
                      compType: "vtext",
                      compConfig: {
                        text: "元/单位基金份额"
                      },
                      compStyle: {
                        marginLeft: "10px"
                      }
                    };
                  }
                  return {
                    compType: "vtext"
                  };
                }.call(this)
              ]
            }
          ],
          [
            {
              label: "公告标题",
              labelWidth: 80,
              comps: [
                {
                  key: "docTitle",
                  compType: "vinput",
                  rules: [
                    {
                      required: true,
                      message: "公告标题不能为空"
                    }
                  ],
                  compConfig: {
                    placeholder: "请输入公告标题"
                  }
                }
              ]
            },
            {
              label: "公告日期",
              labelWidth: 80,
              comps: [
                {
                  key: "docDate",
                  compType: "vdatePicker",
                  rules: [
                    {
                      required: true,
                      message: "公告日期不能为空"
                    }
                  ],
                  compConfig: {
                    placeholder: "请选择公告日期"
                  },
                  compStyle: {
                    width: "180px"
                  }
                }
              ]
            }
          ],
          [
            {
              label: "公告附件",
              labelWidth: 80,
              comps: [
                {
                  key: "attach",
                  compType: "vfileUpload",
                  compConfig: {
                    url: "datadis/distribution/uploadAttach",
                    fileName: "attach",
                    resName: "fileName",
                    foreignPath: true
                  },
                  rules: [
                    {
                      required: true,
                      message: "请上传公告附件"
                    }
                  ]
                }
              ]
            }
          ]
        ]
      };
    }
  }
};
</script>

<style lang="less" scoped>
.distribution-form-container {
  position: relative;
  height: 100%;
}
</style>
