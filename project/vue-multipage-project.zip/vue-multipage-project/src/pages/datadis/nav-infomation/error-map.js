const errorMap = {
    "101": {
      level: "1",
      notice: "基金ID缺失，无法保存净值",
      plan: "请联系排排网数据对接人协助解决",
      errorField: "nav"
    },
    "102": {
      level: "1",
      notice: "基金ID缺失，无法保存净值",
      plan: "请联系排排网数据对接人协助解决",
      errorField: "priceDate"
    },
    "104": {
      level: "1",
      notice: "基金ID缺失，无法保存净值",
      plan: "请联系排排网数据对接人协助解决",
      errorField: "nav"
    },
    "105": {
      level: "1",
      notice: "基金ID缺失，无法保存净值",
      plan: "请联系排排网数据对接人协助解决",
      errorField: "priceDate"
    },
    "106": {
      level: "1",
      notice: "净值格式错误，净值应为正数",
      plan: "请修改净值以后再保存",
      errorField: "nav"
    },
    "200": {
      level: "1",
      notice: "基金ID缺失，无法保存净值",
      plan: "请联系排排网数据对接人协助解决",
      errorField: "nav"
    },
    "201": {
      level: "2",
      notice: "基金运行状态异常",
      errorField: "nav"
    },
    "301": {
      level: "1",
      notice: "净值日期$date大于当前日期",
      plan: "请修改净值日期后再保存",
      errorField: "priceDate"
    },
    "302": {
      level: "2",
      notice: "基金未成立",
      errorField: "nav"
    },
    "303": {
      level: "2",
      notice: "基金净值日期大于清算日期",
      errorField: "priceDate"
    },
    "304": {
      level: "1",
      notice: "净值日期$date为周末",
      plan: "请修改净值日期后再保存",
      errorField: "priceDate"
    },
    "401": {
      level: "2",
      notice: "净值与前次净值相差太大",
      errorField: "nav"
    },
    "501": {
      level: "1",
      notice: "$date日累计净值格式错误，累计净值应为正数",
      plan: "请修改累计净值后再保存",
      errorField: "cumulativeNavCrawl"
    },
    "502": {
      level: "2",
      notice: "累计净值与前次累计净值相差太大",
      errorField: "cumulativeNavCrawl"
    },
    "503": {
      level: "2",
      notice: "累计净值小于单位净值和累计分红之和",
      errorField: "cumulativeNavCrawl"
    },
    "504": {
      level: "2",
      notice: "单位净值和累计净值相差过大",
      errorField: "cumulativeNavCrawl"
    },
    "1001": {
      level: "1",
      notice: "$date日净值已存在",
      plan: "请修改净值日期后再保存",
      errorField: "priceDate"
    },
  };
  export default errorMap;