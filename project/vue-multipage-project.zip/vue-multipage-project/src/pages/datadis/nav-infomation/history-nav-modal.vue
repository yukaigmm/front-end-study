<template>
  <vmodal
    ref="modal"
    :title="modalTitle"
    class="add-nav-modal t2-el-dialog"
    :width="900"
    :reload="reload"
    @close="closeModal"
    @reloadModal="getHistoryNav"
  >
    <div style="position:relative;height:100%;padding:10px;">
      <vpart title="历史净值">
        <div slot="search">
          <vselect
            :placeholder="'请选择净值状态'"
            :options="options"
            @change="onSearchSelectChange"
            v-model="dataType"
          ></vselect>
          <div class="freq-selector">
            <span class="label">净值更新频率:</span>
            <span>
              <vselect
                :placeholder="'修改净值更新频率'"
                :options="freqOptions"
                @change="onFreqSelectChange"
                v-model="navFrequency"
                :disabled="!userEditable"
              ></vselect>
            </span>
          </div>
        </div>
        <div slot="action">
          <div class="score-infomation">
            完成度得分:&nbsp;&nbsp;
            <span :style="scoreStyle">{{percent}}</span>
          </div>
          <vbutton active title="导出净值" style="margin-right: 3px;" @click="exportNav">导出</vbutton>
        </div>
        <vtable
          ref="table"
          :key="key"
          :max-height="tableMaxHeight"
          :columns="columnsConfig"
          :data="tableData"
          :useActionColumn="true"
          :usePagination="true"
          :totalItem="totalItem"
          :currentPage="currentPage"
          :changeRowColor="true"
          @pageChange="currentChange"
          @pageSizeChange="sizeChange"
          @tableRowClick="tableRowClick"
        ></vtable>
      </vpart>
      <distributionModal ref="distributionModal" :status="status" @success="addDistibutionSuccess"></distributionModal>
      <navErrConfirmModal ref="navErrConfirmModal" @success="navErrConfirmModalSuccess"></navErrConfirmModal>
    </div>
    <vloading slot="loading" class="loading" v-model="loading"></vloading>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="submitHistoryNav">保存</vbutton>
    </div>

    <exportNavModal ref="exportNavModal"></exportNavModal>
  </vmodal>
</template>

<script>
import $ from "jquery";
import distributionModal from "./distribution-modal.vue";
import navErrConfirmModal from "./nav-err-confirm-modal.vue";
import customColumn from "../../../common/js/customColumn.js";
import exportNavModal from "./export-nav-modal.vue";
import _ from "lodash";
export default {
  components: {
    customColumn,
    distributionModal,
    navErrConfirmModal,
    exportNavModal
  },
  data() {
    return {
      initNavValue: "",
      initCamNavValue: "",
      navId: "",
      freqOptions: [
        {
          label: "季",
          value: "季"
        },
        {
          label: "月",
          value: "月"
        },
        {
          label: "周",
          value: "周"
        },
        {
          label: "天",
          value: "天"
        }
      ],
      status: "",
      options: [
        {
          label: "只看缺失",
          value: 1
        },
        {
          label: "已有净值",
          value: 2
        },
        {
          label: "已有分配",
          value: 3
        },
        {
          label: "全部",
          value: 0
        }
      ],
      scoreStyle: { color: "red" },
      score: "",
      validatePriceDate: "",
      fundId: "",
      navFrequency: "",
      inceptionDate: "",
      dataType: 0,
      currentRowId: "",
      key: "",
      pageSize: 10,
      totalItem: 0,
      currentPage: 1,
      loading: false,
      reload: false,
      fundName: "",
      percent: "",
      deleteNavId: [],
      historyNavData: [],
      tableData: [],
      modalTitle: "",
      validItems: [],
      tableMaxHeight: null,
      editNavs: [],
      remarks: [],
      // 净值modal当前编辑行，保存编辑之前的值
      currentEditorRowDataArr: [],
      // 点击分红时保存所有的编辑行

      //区分估值表确认框返回值，当前为新增状态还是修改状态
      navErrConfirmModalType: "add",
      userEditable: true
    };
  },

  computed: {
    columnsConfig() {
      const validateIsOverThreshold = () => {
        let that = this;
        return function(rule, value, callback, sources, options) {
          let errors = [];
          let params;
          if (that.navId) {
            params = {
              id: that.navId,
              nav: value,
              fundId: that.fundId,
              priceDate: that.validatePriceDate
            };
          } else {
            params = {
              nav: value,
              fundId: that.fundId,
              priceDate: that.validatePriceDate
            };
          }
          if (value) {
            that.$http
              .post("datadis/nav/validate", params)
              .then(res => {
                if (res.code === 20000) {
                  if (!res.data.isvalid) {
                    if (res.data.errorType === 303) {
                      errors.push(
                        new Error("净值日期不能为周末，请删除该行重新添加")
                      );
                    } else if (res.data.errorType === 600) {
                      errors.push(new Error("该净值日期已存在，请修改后重试"));
                    } else {
                      errors.push(new Error(res.data.errorMsg));
                    }
                  }
                }
              })
              .then(() => {
                callback(errors);
              });
          } else {
            callback();
          }
        };
      };

      return [
        {
          title: "净值日期",
          canEdit: true,
          key: "priceDate",
          width: 140,
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            if (row.id) {
              let priceDate = row.priceDate;
              return priceDate ? priceDate : "--";
            } else {
              return h("editTableCell", {
                props: {
                  comps: {
                    compType: "vdatePicker",
                    key: "priceDate",
                    compConfig: {
                      disabled: !this.userEditable
                    }
                  },
                  value: row.priceDate
                },
                on: {
                  change: val => {
                    this.onTableCellChange(val, row, column, index);
                  }
                }
              });
            }
          }
        },
        {
          title: "单位净值",
          canEdit: true,
          key: "nav",
          align: "right",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            if (row.id && !row.canEdit) {
              let nav = row.nav;
              return nav ? Number(nav).toFixed(4) : "--";
            } else {
              return h("editTableCell", {
                props: {
                  ifTextAlignRight: true,
                  comps: {
                    compType: "vinput",
                    key: "nav",
                    compConfig: {
                      disabled: !this.userEditable
                    },
                    rules: [
                      validateIsOverThreshold(),
                      (rule, value, callback) => {
                        let errors = [];
                        if (value) {
                          if (value <= 0) {
                            errors.push(new Error("净值应该大于0"));
                          }
                        }
                        callback(errors);
                      },
                      (rule, value, callback) => {
                        let errors = [];
                        if (value) {
                          if (isNaN(Number(value))) {
                            errors.push(new Error("请输入数字"));
                          }
                        }
                        callback(errors);
                      }
                    ]
                  },
                  value: row.nav
                },
                on: {
                  change: val => {
                    this.onTableCellChange(val, row, column, index);
                  }
                }
              });
            }
          }
        },
        {
          title: "累计净值",
          canEdit: true,
          key: "cumulativeNavCrawl",
          align: "right",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            let ifDisabled = !row.nav;
            if (row.id && !row.canEdit) {
              let cumulativeNavCrawl = row.cumulativeNavCrawl;
              return cumulativeNavCrawl
                ? Number(cumulativeNavCrawl).toFixed(4)
                : "--";
            } else {
              let cumulativeNavCrawlInput = h("editTableCell", {
                props: {
                  ifTextAlignRight: true,
                  comps: {
                    compType: "vinput",
                    key: "cumulativeNavCrawl",
                    compConfig: {
                      disabled: ifDisabled
                    },
                    rules: [
                      (rule, value, callback) => {
                        let errors = [];
                        if (value) {
                          if (isNaN(Number(value))) {
                            errors.push(new Error("请输入数字"));
                          }
                        }
                        callback(errors);
                      }
                    ]
                  },
                  value: row.cumulativeNavCrawl
                },
                on: {
                  change: val => {
                    this.onTableCellChange(val, row, column, index);
                  }
                }
              });
              if (ifDisabled) {
                return h(
                  "el-tooltip",
                  {
                    props: {
                      enterable: false
                    }
                  },
                  [
                    cumulativeNavCrawlInput,
                    h(
                      "div",
                      {
                        slot: "content"
                      },
                      "请先填写单位净值"
                    )
                  ]
                );
              } else {
                return cumulativeNavCrawlInput;
              }
            }
          }
        },
        {
          title: "上期净值日期",
          key: "preDate",
          render(h, { row, column, index }) {
            let prePriceDate = row.preDate;
            return prePriceDate ? prePriceDate : "--";
          }
        },
        {
          title: "上期单位净值",
          key: "preNav",
          align: "right",
          render(h, { row, column, index }) {
            let preNav = row.preNav;
            return preNav ? Number(preNav).toFixed(4) : "--";
          }
        },
        {
          title: "分配信息",
          key: "distribution",
          width: 80,
          render: (h, { row, column, index }) => {
            // let classNameMapping = {
            //   "1": "icon-fenhongjilu",
            //   "2": "icon-divide",
            //   "3": "icon-payment",
            //   "-1": "icon-qita"
            // };
            // let styleMapping = {
            //   "1": { color: "red", "margin-right": "5px" },
            //   "2": { color: "yellow", "margin-right": "5px" },
            //   "3": { color: "blue", "margin-right": "5px" },
            //   "-1": { color: "white", "margin-right": "5px" }
            // };
            let typeMapping = {
              "1": "分红",
              "2": "拆分",
              "3": "业绩报酬",
              "-1": "其他"
            };
            let auditstateMap = {
              "0": "未审核",
              "1": "已审核",
              "2": "新增申请中",
              "3": "更新申请中",
              "4": "删除申请中",
              "5": "未通过",
              "6": "删除失败",
              "-1": "草稿"
            };
            if (row.distribution && row.distribution.length) {
              let initDistribution = JSON.parse(
                JSON.stringify(row.distribution)
              );
              let distribution = [];
              distribution = _.sortBy(initDistribution, [
                function(o) {
                  return o.distributeType;
                }
              ]);
              if (distribution[0].distributeType == -1) {
                distribution = distribution.concat(distribution.splice(0, 1));
              }

              let divStyle = {
                display: "flex",
                "justify-content": "space-between",
                "align-items": "center",
                width: "320px",
                paddingBottom: "3px"
              };
              let text =
                distribution.length > 1
                  ? `${typeMapping[distribution[0].distributeType]}...`
                  : `${typeMapping[distribution[0].distributeType]}`;
              return h(
                "el-tooltip",
                {
                  props: {
                    offset: -3
                  }
                },
                [
                  h("div", `${text}`),
                  h(
                    "div",
                    {
                      slot: "content"
                    },
                    [
                      h(
                        "div",
                        {
                          style: Object.assign(
                            {
                              borderBottom: "1px dashed #555",
                              color: "#27d",
                              paddingBottom: "5px"
                            },
                            divStyle
                          )
                        },
                        [
                          h(
                            "span",
                            {
                              style: {
                                flex: 3,
                                textAlign: "center"
                              }
                            },
                            "分配类型"
                          ),
                          h(
                            "span",
                            {
                              style: {
                                flex: 3,
                                textAlign: "center"
                              }
                            },
                            "分配比例"
                          ),
                          h(
                            "span",
                            {
                              style: {
                                flex: 3,
                                textAlign: "center"
                              }
                            },
                            "审核状态"
                          ),
                          h(
                            "span",
                            {
                              style: {
                                flex: 2,
                                textAlign: "center"
                              }
                            },
                            "操作"
                          )
                        ]
                      )
                    ].concat(
                      distribution.map((item, ind) => {
                        let style = Object.assign(
                          {
                            color: "#aaa",
                            marginBottom: 0
                          },
                          divStyle
                        );
                        return h(
                          "div",
                          {
                            style: style
                          },
                          [
                            h(
                              "span",
                              {
                                style: { flex: 3, textAlign: "center" }
                              },
                              `${typeMapping[item.distributeType]}`
                            ),
                            h(
                              "span",
                              {
                                style: { flex: 3, textAlign: "center" }
                              },
                              `${Number(item.distribution).toFixed(4)}`
                            ),
                            h(
                              "span",
                              {
                                style: { flex: 3, textAlign: "center" }
                              },
                              `${auditstateMap[item.auditstate] || "--"}`
                            ),

                            h(
                              "div",
                              {
                                style: {
                                  marginLeft: "5px",
                                  flex: 2,
                                  textAlign: "center"
                                }
                              },
                              [
                                h("vbuttonSprite", {
                                  props: {
                                    disabled: row.auditstate == 4,
                                    pos: {
                                      normal: { x: 0, y: -241 },
                                      hover: { x: -18, y: -241 },
                                      disabled: { x: -36, y: -241 }
                                    },
                                    title: "删除"
                                  },
                                  style: {
                                    verticalAlign: "middle",
                                    display: "inline-block"
                                  },
                                  on: {
                                    click: e => {
                                      this.deleteFundDistribute(
                                        item,
                                        index,
                                        ind
                                      );
                                    }
                                  }
                                })
                              ]
                            )
                          ]
                        );
                      })
                    )
                  )
                ]
              );
            } else {
              return "--";
            }
          }
        },
        {
          title: "审核状态",
          key: "auditstate",
          render(h, { row, column, index }) {
            let map = {
              "1": "通过",
              "2": "新增申请中",
              "3": "更新申请中",
              "4": "删除申请中",
              "5": "未通过",
              "6": "删除失败",
              "-1": "草稿"
            };
            if (row.isAutoCheck == "0") {
              map["5"] = "人工审核失败";
            } else {
              map["5"] = "人工审核中";
            }
            return map[row.auditstate] ? map[row.auditstate] : "--";
          }
        },
        {
          title: "操作",
          key: "action",
          width: 134,
          align: "center",
          showOverflowTooltip: false,
          renderHeader(h) {
            return h("span", [
              h("span", "操作"),
              h(
                "el-tooltip",
                {
                  props: {
                    enterable: false
                  }
                },
                [
                  h("span", {
                    style: {
                      display: "inline-block",
                      width: "16px",
                      height: "16px",
                      background: `url("${
                        this.$baseUrl[process.env.NODE_ENV]["page"]
                      }/assets/images/question.png") no-repeat`,
                      backgroundSize: "100%",
                      verticalAlign: "-3px",
                      marginLeft: "5px"
                    }
                  }),
                  h(
                    "div",
                    {
                      slot: "content"
                    },
                    [
                      h(
                        "span",
                        {
                          style: {
                            color: "#27d"
                          }
                        },
                        "说明："
                      ),
                      h("span", "只有有净值记录的基金，才能添加分红信息")
                    ]
                  )
                ]
              )
            ]);
          },
          render: (h, { row, column, index }) => {
            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                //编辑
                h("vbuttonSprite", {
                  props: {
                    disabled:
                      !(
                        row.auditstate == 1 ||
                        row.auditstate == 5 ||
                        row.auditstate == 6 ||
                        (row.auditstate == null && row.id !== null)
                      ) || row.auditstate == 4,
                    pos: row.canEdit
                      ? {
                          normal: { x: 0, y: -0 },
                          hover: { x: -18, y: -0 },
                          disabled: { x: -36, y: -0 }
                        }
                      : {
                          normal: { x: 0, y: -19 },
                          hover: { x: -18, y: -19 },
                          disabled: { x: -36, y: -19 }
                        },
                    title: row.canEdit ? "保存" : "编辑"
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      if (!this.userEditable) {
                        this.$message.error("只读账号无法进行此操作");
                        return;
                      }
                      if (!row.canEdit) {
                        row.editId = new Date().getTime();
                        row.currentPage = this.currentPage;
                        row.index = index;
                        this.currentEditorRowDataArr.push(
                          JSON.parse(JSON.stringify(row))
                          // row
                        );
                        this.currentEditorRowDataArr = _.uniqBy(
                          this.currentEditorRowDataArr,
                          "id"
                        );
                        row.canEdit = true;
                        this.$refs.table.refresh();
                      } else {
                        this.editNav(row, index);
                      }
                    }
                  }
                }),
                //删除
                h("vbuttonSprite", {
                  props: {
                    disabled: row.auditstate == 4 || !row.id,
                    pos: {
                      normal: { x: 0, y: -241 },
                      hover: { x: -18, y: -241 },
                      disabled: { x: -36, y: -241 }
                    },
                    title: "删除"
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      this.deleteNav(row, index);
                    }
                  }
                }),
                //分红
                h("vbuttonSprite", {
                  props: {
                    disabled: !row.id || row.auditstate == 4,
                    pos: {
                      normal: { x: 0, y: -38 },
                      hover: { x: -18, y: -38 },
                      disabled: { x: -36, y: -38 }
                    },
                    title: "添加分红"
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      this.addDistibute(row, index);
                    }
                  }
                })
              ]
            );
          }
        }
      ];
    }
  },

  created() {
    for (let i = 0; i < 10; i++) {
      this.validItems.push(`nav-${i}`);
    }
  },
  mounted() {
    //获取用户权限，判断是否可编辑信息
    let currentUserInfo = localStorage.getItem("fund_master_current_user")
      ? JSON.parse(localStorage.getItem("fund_master_current_user"))
      : {};
    let userPermission = currentUserInfo.userPermission;
    this.userEditable = userPermission === 1;
  },
  watch: {
    remarks: {
      handler(val) {},
      deep: true
    }
  },
  methods: {
    // 获取基金净值得分
    getNavScore() {
      this.$http.get(`datadis/nav/${this.fundId}/getNavScore`).then(res => {
        if (res.code === 20000) {
          this.percent = Math.ceil(parseFloat(res.data.score));
        }
      });
    },

    // 显示模态框
    show(fundId, fundName, score, navFrequency, inceptionDate) {
      this.fundId = fundId;
      this.fundName = fundName;
      this.navFrequency = navFrequency;
      this.inceptionDate = inceptionDate;
      this.score = score;
      this.currentPage = 1;
      this.pageSize = 10;
      this.tableData = [];
      this.percent = parseFloat(score);
      if (this.percent > 80) {
        this.scoreStyle = { color: "green" };
      } else if (this.percent <= 80 && this.percent > 60) {
        this.scoreStyle = { color: "#ccccc6" };
      } else {
        this.scoreStyle = { color: "red" };
      }
      this.modalTitle = `历史净值--${fundName}`;
      this.$refs.modal.open();
      this.getHistoryNav();
    },
    cancel() {
      this.$refs.modal.close();
    },
    //  关闭模态框
    closeModal() {
      // 清空当前净值id
      this.navId = "";
      // 清空当前净值更新频率
      this.navFrequency = "";
      // 历史净值类型
      this.dataType = 0;
      // 删除的净值
      this.deleteNavId = [];
      // 清空当前编辑行
      this.currentEditorRowDataArr = [];
      this.currentPage = 1;
      this.pageSize = 10;
      this.tableData = [];
      this.editNavs = [];
      this.remarks = [];
      // this.$refs.modal.close();
      this.key = Date.now();
      this.resetRecord();
      this.$emit("refreshTableData");
      console.log("cancel");
    },

    // 获取历史净值
    getHistoryNav(keepCurrentRow = false) {
      let params = {
        fundId: this.fundId,
        dataType: this.dataType,
        navFrequency: this.navFrequency
      };
      this.reload = false;
      this.loading = true;
      if (!keepCurrentRow) {
        this.currentRowId = "";
      }
      return new Promise(resolve => {
        this.$http
          .get("datadis/nav/findNavListWithMissing", params)
          .then(resp => {
            this.loading = false;
            if (resp && resp.code === 20000) {
              this.tableMaxHeight = $(".add-nav-modal").height() - 200;
              this.setTableHeight();
              this.historyNavData = resp.data;
              this.totalItem = resp.data.length;
              if (this.currentPage) {
                this.tableData = this.historyNavData.slice(
                  this.currentPage * this.pageSize - this.pageSize,
                  this.currentPage * this.pageSize
                );
              } else {
                this.tableData = this.historyNavData.slice(0, 10);
              }
              this.$nextTick(() => {
                this.$refs.table.setCurrentRow("priceDate", this.currentRowId);
              });
            } else {
              let msg =
                resp && resp.msg ? resp.msg : "数据加载失败，请点击重新加载";
              this.$message.error(msg);
              this.reload = true;
            }
            resolve();
          });
      });
    },

    // 添加修改了的净值
    addEditNavsToEditNavs(row) {
      if (this.editNavs.length) {
        for (let i = 0, len = this.editNavs.length; i < len; i++) {
          if (row.id == this.editNavs[i].id) {
            this.editNavs[i] = row;
            break;
          } else {
            this.editNavs.push(row);
            break;
          }
        }
      } else {
        this.editNavs.push(row);
      }
      row.canEdit = false;
      this.$refs.table.refresh();
    },

    // 添加备注
    addRemarks(row, value, ifEdit) {
      // 编辑净值
      if (ifEdit) {
        for (let i = 0, len = this.remarks.length; i < len; i++) {
          // 已有备注，覆盖
          if (row.id == this.remarks[i].keyId) {
            this.remarks[i] = {
              keyId: row.id,
              logRemark: value || "",
              keyType: 4,
              logType: 4,
              logTypeName: "修改净值"
            };
            break;
          } else {
            // 没有备注，新增一条备注
            this.remarks.push({
              keyId: row.id,
              logRemark: value || "",
              keyType: 4,
              logType: 4,
              logTypeName: "修改净值"
            });
            break;
          }
        }
        if (this.remarks.length === 0) {
          this.remarks.push({
            keyId: row.id,
            logRemark: value || "",
            keyType: 4,
            logType: 4,
            logTypeName: "修改净值"
          });
        }
      } else {
        // 删除净值
        this.remarks.push({
          keyId: row.id,
          logRemark: value || "",
          keyType: 4,
          logType: 4,
          logTypeName: "删除净值"
        });
      }
    },

    // 刷新表格后维持列表原先的状态
    setTableOriginStatus() {
      this.tableData.forEach(item => {
        for (
          let i = 0, len = this.currentEditorRowDataArr.length;
          i < len;
          i++
        ) {
          if (item.id == this.currentEditorRowDataArr[i]["id"]) {
            item.canEdit = true;
            this.$set(
              item,
              "priceDate",
              this.currentEditorRowDataArr[i]["priceDate"]
            );
            this.$set(item, "nav", this.currentEditorRowDataArr[i]["nav"]);
            this.$set(
              item,
              "cumulativeNavCrawl",
              this.currentEditorRowDataArr[i]["cumulativeNavCrawl"]
            );
            this.$set(
              item,
              "currentPage",
              this.currentEditorRowDataArr[i]["currentPage"]
            );
            this.$set(
              item,
              "editId",
              this.currentEditorRowDataArr[i]["editId"]
            );
            this.$set(item, "index", this.currentEditorRowDataArr[i]["index"]);
          }
        }
      });
      this.$refs.table.refresh();
    },

    // 修改净值
    editNav(row, index) {
      if (row.nav <= 0) {
        this.$message.error("净值应该大于0！");
        return;
      }
      if (isNaN(Number(row.nav))) {
        this.$message.error("净值应该是数字！");
        return;
      }

      if (isNaN(Number(row.cumulativeNavCrawl))) {
        this.$message.error("累计净值应该是数字！");
        return;
      }
      this.$prompt("请输入备注(选填)", "确定修改本期净值？", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        inputPlaceholder: "请输入备注"
      })
        .then(({ value }) => {
          // 删除当前编辑行数组中的当前行数据
          // this.currentEditorRowDataArr= this.currentEditorRowDataArr.filter((item,index)=>{
          //   return item.editId !== row.editId;
          // })
          // delete row.editId;
          // delete row.currentPage;

          // this.$message({
          //   type: "success",
          //   message: "修改成功，点击保存之后将会生效"
          // });
          // this.addEditNavsToEditNavs(row);
          // this.addRemarks(row, value, true);
          let submitData = {
            addData: [],
            delData: [],
            updateData: [
              {
                id: row.id,
                fundId: row.fundId,
                priceDate: row.priceDate,
                nav: row.nav,
                cumulativeNavCrawl: row.cumulativeNavCrawl
              }
            ]
          };
          this.$http.post("datadis/nav/adjData", submitData).then(res => {
            if (!res) return;
            if (res.code === 20000) {
              //监听净值填充事件
              sa.event("fundMaster_navFill", {
                fundId: this.fundId,
                fillType: "edit"
              });

              row.canEdit = !row.canEdit;
              row.auditstate = 1;
              this.$refs.table.refresh();
              this.$message({
                message: "修改成功",
                type: "success"
              });
              this.getNavScore();
              // 修改之后恢复列表原先的状态
              // this.getHistoryNav(true).then(() => {
              //   this.setTableOriginStatus();
              // });
              //从未执行修改请求的行数组中去除当前行
              _.remove(this.currentEditorRowDataArr, data => {
                return data.editId === row.editId;
              });

              //手动更新相关的历史净值
              let priceDate = row.priceDate;
              let nav = row.nav;
              let editNavIndex = index + this.pageSize * (this.currentPage - 1);

              for (let i = editNavIndex - 1; i >= 0; i--) {
                if (this.historyNavData[i].preDate === priceDate) {
                  this.historyNavData[i].preNav = nav;
                } else {
                  break;
                }
              }
              for (let i = index - 1; i >= 0; i--) {
                if (this.tableData[i].preDate === priceDate) {
                  this.tableData[i].preNav = nav;
                } else {
                  break;
                }
              }
              this.$refs.table.refresh();

              //添加修改时的备注
              if (value) {
                this.$http.post("datadis/remarkLog", [
                  {
                    keyId: row.id,
                    keyType: 4,
                    logRemark: value,
                    logType: 4,
                    logTypeName: "修改净值"
                  }
                ]);
              }
            }
            // else if (res.code === 40010) {
            //   if (res.data.errorType === 401) {
            //     this.navErrConfirmModalType = 'edit';
            //     this.$refs.navErrConfirmModal.show({
            //       submitData,
            //       row,
            //       index,
            //       value
            //     }, '涨幅过大');
            //   } else if (res.data.errorType === 402) {
            //     this.navErrConfirmModalType = 'edit';
            //     this.$refs.navErrConfirmModal.show({
            //       submitData,
            //       row,
            //       index,
            //       value
            //     }, '超出阈值');
            //   } else {
            //     this.$message({
            //       type: "error",
            //       message: `${res.msg}: ${res.data.errorMsg}`
            //     });
            //   }
            // }
            else {
              this.$message({
                type: "error",
                message: `${res.msg}: ${res.data.errorMsg}`
              });
            }
          });
        })
        .catch(() => {
          // 取消时，还原之前的值，输入框变成需要点击编辑按钮才能编辑的状态,去除数组中这一行的值
          this.currentEditorRowDataArr = this.currentEditorRowDataArr.filter(
            (item, index) => {
              if (item.editId === row.editId) {
                row.nav = item.nav;
                row.priceDate = item.priceDate;
                row.cumulativeNavCrawl = item.cumulativeNavCrawl;
                return false;
              } else {
                return true;
              }
            }
          );
          delete row.editId;
          delete row.currentPage;
          row.canEdit = false;
          this.$refs.table.refresh();
          this.$message({
            type: "info",
            message: "本次修改将不会生效"
          });
        });
    },

    // 删除净值
    deleteNav(row, index) {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      let navIndex = (this.currentPage - 1) * this.pageSize + index;
      // 已有净值需要输入备注
      if (row.id) {
        this.$prompt("请输入备注", "确定删除本期净值？", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          inputPattern: /[\s\S]/,
          inputPlaceholder: "请输入备注",
          inputErrorMessage: "备注不能为空"
        })
          .then(({ value }) => {
            this.$http
              .post("datadis/nav/adjData", {
                addData: [],
                updateData: [],
                delData: [].concat(row.id)
              })
              .then(res => {
                if (!res) return;
                if (res.code === 20000) {
                  this.getNavScore();

                  // 净值不存在时直接删除
                  this.$delete(this.historyNavData, navIndex);
                  // this.$delete(this.tableData, index);
                  this.totalItem = this.historyNavData.length;
                  this.currentChange(this.currentPage);
                  this.$message({
                    message: "删除成功",
                    type: "success"
                  });

                  let priceDate = row.priceDate;
                  let delNavIndex =
                    index + this.pageSize * (this.currentPage - 1);
                  let nextPreNav = row.preNav;
                  let nextPreDate = row.preDate;

                  for (let i = delNavIndex - 1; i >= 0; i--) {
                    if (this.historyNavData[i].preDate === priceDate) {
                      this.historyNavData[i].preNav = nextPreNav;
                      this.historyNavData[i].preDate = nextPreDate;
                    } else {
                      break;
                    }
                  }
                  for (let i = index - 1; i >= 0; i--) {
                    if (this.tableData[i].preDate === priceDate) {
                      this.tableData[i].preNav = nextPreNav;
                      this.tableData[i].preDate = nextPreDate;
                    } else {
                      break;
                    }
                  }

                  this.$refs.table.refresh();

                  // 在删除一行时，如果如果该行已经编辑，那么在当前编辑行的数组中去除这一行，
                  // 这样关闭modal的时候就不会提示有编辑行尚未保存
                  this.currentEditorRowDataArr = this.currentEditorRowDataArr.filter(
                    item => {
                      if (item.priceDate !== row.priceDate) {
                        return item;
                      }
                    }
                  );

                  //提交日志
                  this.$http.post("datadis/remarkLog", [
                    {
                      keyId: row.id,
                      keyType: 4,
                      logRemark: value,
                      logType: 4,
                      logTypeName: "删除净值"
                    }
                  ]);
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "取消删除"
            });
          });
      } else {
        // 净值不存在时直接删除
        this.$delete(this.historyNavData, navIndex);
        this.$delete(this.tableData, index);
        this.totalItem = this.historyNavData.length;
        this.currentChange(this.currentPage);
        this.$message({
          message: "删除成功,点击保存之后将会生效",
          type: "success"
        });
      }
      // this.$confirm("确定删除吗？", "删除", {
      //   showCancelButton: true,
      //   type: "warning",
      //   closeOnClickModal: false,
      //   callback: (action, instance) => {
      //     if (action === "confirm") {

      //     } else {
      //       this.$message({
      //         type: "info",
      //         message: "取消删除"
      //       });
      //     }

      // if (action === "confirm") {
      //   this.$delete(this.historyNavData, navIndex);
      //   this.$delete(this.tableData, index);
      //   this.totalItem = this.historyNavData.length;
      //   this.currentChange(this.currentPage);
      //   if (row.id) {
      //     this.deleteNavId.push(row.id);
      //   }
      //   this.$message({
      //     showClose: true,
      //     message: "删除成功,点击保存之后将会生效",
      //     type: "success"
      //   });
      //   done();
      // } else {
      //   done();
      // }
      //   }
      // });
    },

    // 修改净值更新频率
    onFreqSelectChange(val) {
      this.navFrequency = val;
      let params = {
        navFrequency: `${val}`
      };
      this.$http
        .putWithoutId(`datadis/fundInformation/${this.fundId}`, params)
        .then(res => {
          if (!res) return;
          this.$message({
            type: "success",
            message: "修改成功"
          });
        })
        .then(() => {
          this.refreshHistoryNav();
          this.$emit("refreshTableData");
          this.$http
            .get(`/datadis/nav/${this.fundId}/getNavScore`)
            .then(res => {
              this.percent = Math.round(res.data.score);
            });
        });
    },
    // 处理提交的数据
    dealWithSubmitData() {
      let submitData = {
        addData: [],
        delData: [],
        updateData: []
      };
      // 添加的净值只需要传递这四个字段
      let needKeys = ["fundId", "priceDate", "nav", "cumulativeNavCrawl"];
      // let updateNeedKeys = [
      //   "fundId",
      //   "priceDate",
      //   "nav",
      //   "cumulativeNavCrawl",
      //   "id"
      // ];
      let dealedTableData = [];
      // let finalUpdatedData = [];
      let tableData = JSON.parse(JSON.stringify(this.historyNavData));
      // 处理修改的数据
      // let updateData = tableData.filter(item => item.canEdit);
      // 净值不能重复添加，去除已存在的净值
      tableData = tableData.filter(item => !item.id);
      // 获取修改了的净值
      // updateData.forEach(item => {
      //   let sigleItem = {};
      //   updateNeedKeys.forEach(key => {
      //     sigleItem[key] = item[key];
      //   });
      //   finalUpdatedData.push(sigleItem);
      // });
      // 处理新增的净值数据
      tableData.forEach(item => {
        let sigleItem = {};
        needKeys.forEach(key => {
          sigleItem[key] = item[key];
        });
        dealedTableData.push(sigleItem);
      });
      dealedTableData = dealedTableData.filter(item => item.nav);

      submitData.addData = JSON.parse(JSON.stringify(dealedTableData));

      submitData.delData = JSON.parse(JSON.stringify(this.deleteNavId));
      submitData.updateData = JSON.parse(JSON.stringify(this.editNavs));
      return submitData;
    },

    // 提交历史净值数据
    submitHistoryNav() {
      // 如果还有处于编辑状态的行，阻止关闭并跳转到相应页面
      if (this.currentEditorRowDataArr.length) {
        this.currentChange(this.currentEditorRowDataArr[0].currentPage);
        setTimeout(() => {
          this.$refs.table.setCurrentRow(
            "priceDate",
            this.currentEditorRowDataArr[0].priceDate
          );
          this.$refs.table.refresh();
        }, 100);
        this.$message.error("您有编辑行尚未保存！");
        return;
      }
      let submitData = this.dealWithSubmitData();
      if (
        !submitData.addData.length &&
        !submitData.delData.length &&
        !submitData.updateData.length
      ) {
        this.cancel();
        return;
      }
      this.$http.post("datadis/nav/adjData", submitData).then(res => {
        if (!res) return;
        if (res.code == 20000) {
          //监听净值填充事件
          sa.event("fundMaster_navFill", {
            fundId: this.fundId,
            fillType: "add"
          });

          // 提交备注
          // 删除没有备注的数据，如果没有备注，就直接关闭;否则请求接口
          this.remarks = this.remarks.filter(item => {
            return item.logRemark !== "";
          });
          if (this.remarks.length) {
            this.$http.post("datadis/remarkLog", this.remarks).then(res => {
              if (res.code === 20000) {
                this.cancel();
              }
            });
          } else {
            this.cancel();
          }
          this.$message({
            type: "success",
            message: "净值新增成功",
            showClose: true
          });
          this.$emit("refreshTableData");
        }
        // else if (res.code == 40010) {
        //   if (res.data.errorType === 401) {
        //     this.navErrConfirmModalType = 'add';
        //     this.$refs.navErrConfirmModal.show({
        //       submitData,
        //     }, '涨幅过大');
        //   } else if (res.data.errorType === 402) {
        //     this.navErrConfirmModalType = 'add';
        //     this.$refs.navErrConfirmModal.show({
        //       submitData,
        //     }, '超出阈值');
        //   } else {
        //     this.$message({
        //     type: "error",
        //     message: `${res.msg}: ${res.data.errorMsg}`,
        //     showClose: true
        //   });
        //   }
        // }
        else {
          this.$message({
            type: "error",
            message: `${res.msg}: ${res.data.errorMsg || ""}`,
            showClose: true
          });
        }
      });
      this.resetRecord();
    },

    // 新增分配信息
    addDistibute(row, index) {
      console.log(row);
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      if (row.canEdit) {
        this.$message.warning("请先确认当前行的修改");
      } else {
        this.$refs.distributionModal.open(row.fundId, row.priceDate, row.nav);
        this.status = "add";
      }
    },

    // 删除分配信息
    deleteFundDistribute(rowData, rowIndex, disIndex) {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      this.$confirm("确认删除吗？", "删除", {
        showCancelButton: true,
        type: "warning",
        closeOnClickModal: false,
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            let params = {
              id: rowData.id
            };
            instance.confirmButtonLoading = true;
            instance.confirmButtonText = "删除中...";
            this.$http
              .putWithoutId(`datadis/distribution/applyDelete`, params)
              .then(res => {
                done();
                instance.confirmButtonLoading = false;
                if (!res) return;
                if (res.code == 20000) {
                  this.$message({
                    showClose: true,
                    message: "删除成功",
                    type: "success"
                  });
                  // rowData.auditstate = 4;
                  // this.tableData[rowIndex].distribution[
                  //   disIndex
                  // ].auditstate = 4;
                  let arr = JSON.parse(
                    JSON.stringify(this.tableData[rowIndex].distribution)
                  );
                  _.pullAt(arr, disIndex);
                  this.tableData[rowIndex].distribution = JSON.parse(
                    JSON.stringify(arr)
                  );
                  // this.refreshHistoryNav();
                } else {
                  this.$message({
                    showClose: true,
                    message: "删除失败",
                    type: "error"
                  });
                }
              });
          } else {
            done();
          }
        }
      });
    },

    /**
     * val 当前单元格数据
     * data 整行表格数据
     * column 当前行字段信息等
     * index 当前行索引
     */
    onTableCellChange(val, data, column, index) {
      // if (val) {
      // data[column.property] = val;
      this.$set(data, column.property, val);
      // }
      if (data.id) {
        this.navId = data.id;
      } else {
        this.navId = "";
      }

      this.validatePriceDate = data.priceDate;
      this.$set(
        this.historyNavData,
        index + this.pageSize * (this.currentPage - 1),
        data
      );
    },

    // 清空表格中可编辑单元格的验证与数据
    resetValid() {
      this.validItems.forEach(item => {
        if (this.$refs[item][0]) {
          this.$refs[item][0].resetValid();
        }
      });
    },

    // 重置标签记录
    resetRecord() {
      this.recordId = "";
      this.recordKey = "";
    },

    // 一页数量切换
    sizeChange(val) {
      let historyNavData = JSON.parse(JSON.stringify(this.historyNavData));
      this.pageSize = val;
      let endIndex = val * this.currentPage;
      let startIndex = endIndex - val;
      if (endIndex > this.totalItem - 1) {
        this.tableData = historyNavData.slice(startIndex);
      } else {
        this.tableData = historyNavData.slice(startIndex, endIndex);
      }
    },

    // 页码切换
    currentChange(val) {
      let historyNavData = JSON.parse(JSON.stringify(this.historyNavData));
      this.currentPage = val;
      let endIndex = val * this.pageSize;
      let startIndex = endIndex - this.pageSize;
      this.currentRowId = "";
      this.$nextTick(() => {
        this.$refs.table.setCurrentRow("priceDate", this.currentRowId);
      });
      if (endIndex > this.totalItem - 1) {
        this.tableData = historyNavData.slice(startIndex);
      } else {
        this.tableData = historyNavData.slice(startIndex, endIndex);
      }
      // this.setTableOriginStatus();
    },
    // 删除一行之后，改变后面的修改过的行的index和currentpage
    setEditRowCurrentPage(currentPage) {
      for (let item of this.currentEditorRowDataArr) {
        if (currentPage < item.currentPage) {
          if (item.index > 0) {
            item.index--;
          } else {
            item.index = 9;
            item.currentPage--;
          }
        }
      }
    },
    // 新增之后，刷新列表
    refreshHistoryNav(keepCurrentRow) {
      this.getHistoryNav(keepCurrentRow);
    },

    // 设置表格高度
    setTableHeight() {
      window.addEventListener("resize", () => {
        let maxHeight = $(".add-nav-modal").height() - 200;
        this.tableMaxHeight = maxHeight;
      });
    },

    // 点击表格某行，添加单独样式
    tableRowClick({ row, column, index }) {
      this.currentRowId = row.priceDate;
      this.$refs.table.setCurrentRow("priceDate", this.currentRowId);
    },

    // 设置表格行样式
    tableRowClassName({ row, rowIndex }) {
      if (rowIndex % 2 === 1) {
        return "odd-row";
      } else {
        return "even-row";
      }
    },

    onEditCellBlur() {},

    // 净值状态发生改变
    onSearchSelectChange(value) {
      this.dataType = value;
      if (!this.fundId) {
        return;
      }
      this.currentPage = 1;
      this.pageSize = 10;
      // this.getHistoryNav(params);
      this.getHistoryNav();
    },
    //用于记录上一次操作
    // addActionRecord(id, key) {
    //   this.recordId = id;
    //   this.recordKey = key;
    // }

    //前端手动添加分配信息，避免刷新表格丢失修改的数据
    addDistibutionSuccess(data) {
      // let currentRow = this.tableData.filter( (item) => {
      //   return item.priceDate === this.currentRowId
      // })
      let currentRowIndex = _.findIndex(this.tableData, item => {
        return item.priceDate === this.currentRowId;
      });

      this.tableData[currentRowIndex].distribution =
        this.tableData[currentRowIndex].distribution instanceof Array
          ? this.tableData[currentRowIndex].distribution
          : [];
      this.tableData[currentRowIndex].distribution.push({
        id: data.disInfo.data.id,
        auditstate: 1,
        distributeDate: data.disInfo.data.distributeDate,
        distributeType: data.disInfo.data.distributeType,
        distribution: data.disInfo.data.distribution
      });
    },
    navErrConfirmModalSuccess(params) {
      if (this.navErrConfirmModalType === "edit") {
        params.row.canEdit = !params.row.canEdit;
        params.row.auditstate = 1;
        this.$refs.table.refresh();
        this.$message({
          message: "修改成功",
          type: "success"
        });
        this.getNavScore();
        // 修改之后恢复列表原先的状态
        // this.getHistoryNav(true).then(() => {
        //   this.setTableOriginStatus();
        // });
        //从未执行修改请求的行数组中去除当前行
        _.remove(this.currentEditorRowDataArr, data => {
          return data.editId === params.row.editId;
        });

        //手动更新相关的历史净值
        let priceDate = params.row.priceDate;
        let nav = params.row.nav;
        let editNavIndex =
          params.index + this.pageSize * (this.currentPage - 1);

        for (let i = editNavIndex - 1; i >= 0; i--) {
          if (this.historyNavData[i].preDate === priceDate) {
            this.historyNavData[i].preNav = nav;
          } else {
            break;
          }
        }
        for (let i = params.index - 1; i >= 0; i--) {
          if (this.tableData[i].preDate === priceDate) {
            this.tableData[i].preNav = nav;
          } else {
            break;
          }
        }
        this.$refs.table.refresh();

        //添加修改时的备注
        if (params.value) {
          this.$http.post("datadis/remarkLog", [
            {
              keyId: params.row.id,
              keyType: 4,
              logRemark: params.value,
              logType: 4,
              logTypeName: "修改净值"
            }
          ]);
        }
      } else if (this.navErrConfirmModalType === "add") {
        // 提交备注
        // 删除没有备注的数据，如果没有备注，就直接关闭;否则请求接口
        this.remarks = this.remarks.filter(item => {
          return item.logRemark !== "";
        });
        if (this.remarks.length) {
          this.$http.post("datadis/remarkLog", this.remarks).then(res => {
            if (res.code === 20000) {
              this.cancel();
            }
          });
        } else {
          this.cancel();
        }
        this.$message({
          type: "success",
          message: "净值新增成功",
          showClose: true
        });
        this.$emit("refreshTableData");
      }
    },

    //导出历史净值
    exportNav() {
      this.$refs.exportNavModal.show(
        this.fundId,
        this.fundName,
        this.inceptionDate
      );
    }
  }
};
</script>

<style lang="less" scoped>
.search-area {
  width: 100%;
  padding: 10px;
  border: 1px solid rgb(85, 85, 85);
  margin: 0 auto;
  margin-top: 5px;
}
.score-message {
  text-align: right;
}
.table-area {
  margin-top: 10px;
}
.delete-nav {
  cursor: pointer;
  padding: 8px;
}
.operate {
  font-size: 14px;
}
.message-bar {
  width: calc(~"100% - 1px");
  display: flex;
  justify-content: space-between;
  height: 40px;
  align-items: center;
  padding-right: 10px;
  background: #333;
  color: #ffffff;
  font-size: 14px;
  margin-bottom: 1px;
  .fund-name {
    display: inline-block;
    padding-left: 10px;
    border-left: 5px solid #2992ff;
  }
  .search-selector {
    display: inline-block;
    width: 220px;
  }
}
.history {
  margin-top: 48px;
  .el-table__header-wrapper {
    position: fixed !important;
    z-index: 9 !important;
    top: 163px !important;
    width: 96% !important;
  }
}
.add-nav-modal {
  overflow: hidden;
}

.freq-selector {
  display: inline-block;
  margin-left: 20px;
  .label {
    margin-right: 5px;
    font-size: 14px;
  }
}
.score-infomation {
  display: inline-block;
}
</style>

