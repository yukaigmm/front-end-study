<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
    <vpart title="净值信息">
      <div slot="search">
        <vselect v-model="searchForm.fundStatus" :options="fundStatusOptions" @change="search"></vselect>
        <vinput
          style="display: inline-block"
          @keyup.enter.native="searchFund"
          v-model="searchForm.keyWord"
          placeholder="关键字搜索(基金ID/全称/简称)"
        ></vinput>
        <vbutton active title="搜索" @click="search">搜索</vbutton>
        <vswitch
          style="display: inline-block;"
          type="checkbox"
          v-model="searchForm.isVisible"
          :trueValue="-1"
          :falseValue="1"
          trueLabel="显示不对外展示基金"
          falseLabel
          @change="search"
        ></vswitch>
        <vtooltip :showIndex="false" explains="选中则会同时显示可见与不可见基金" style="vertical-align: -3px;"></vtooltip>
      </div>
      <div slot="action">
        <div class="remind">
          <span>
            完成度得分：
            <span :style="scoreStyle">{{score}}</span>
          </span>
          <vtooltip explains="所有净值信息的完整度得分" :showIndex="false" style="vertical-align: -3px;"></vtooltip>
        </div>
        <vbutton active @click="saveCurrentPageNav" style>保存当页</vbutton>
        <vbutton active @click="importNav">导入</vbutton>
      </div>
      <vtable
        ref="table"
        :showTips="true"
        :max-height="maxHeight"
        :columns="columnsConfig"
        :data="navTableData"
        :useActionColumn="true"
        :usePagination="true"
        :totalItem="totalItem"
        :currentPage="currentPage"
        @pageChange="currentChange"
        @pageSizeChange="sizeChange"
        :changeRowColor="true"
        @tableRowClick="tableRowClick"
      ></vtable>
      <vreload v-model="reload" @reload="getNavList"></vreload>
      <vloading class="loading" v-model="loading"></vloading>

      <div class="tip-wrapper">
        尊敬的私募管理人，您好。为了减少您净值填写的工作，您可以通过授权托管机构给排排网发送净值的方式使净值报送自动化。
        <br />
        具体操作步骤，请联系您的专属数据对接人：{{this.dockerName||"--"}}，联系电话：{{this.dockerPhoneNo||"--"}}
      </div>
    </vpart>

    <importNavModal ref="importNavModal"></importNavModal>
    <navModal ref="navModal" @refreshTableData="refreshTableData"></navModal>
    <navErrConfirmModal ref="navErrConfirmModal" @success="navErrConfirmModalSuccess"></navErrConfirmModal>
    <warn-modal @submitNav="submitRowWarnNav" ref="warnModal"></warn-modal>
    <batch-warn-modal ref="batchWarnModal" @submitWarnNav="submitTableNav"></batch-warn-modal>
  </vcommon>
</template> 

<script>
import navModal from "./components/history-nav-modal.vue";
import importNavModal from "./components/import-nav-modal.vue";
import navErrConfirmModal from "./components/notice/nav-err-confirm-modal.vue";
import pageView from "../../../common/mixins/pageView";
import warnModal from "./components/notice/warn-modal.vue";
import errorMap from "./error-map.js";
import batchWarnModal from "./components/notice/batch-warn-modal.vue";
export default {
  components: {
    navModal,
    importNavModal,
    navErrConfirmModal,
    warnModal,
    batchWarnModal
  },
  mixins: [pageView],
  data() {
    return {
      dockerName: "",
      dockerPhoneNo: "",
      scoreStyle: { color: "red", marginLeft: "0px" },
      firstRequest: true,
      fundId: "",
      score: 0,
      pageSize: 10,
      totalItem: 0,
      currentPage: 1,
      loading: false,
      reload: false,
      navTableData: [],
      currentMenuParentKey: "datadis",
      currentMenuChildKey: "navInfomation",
      searchForm: {
        keyWord: "",
        fundStatus: 1,
        isVisible: 1
      },
      maxHeight: null,
      recordId: "",
      recordKey: "",
      fundStatusOptions: [
        {
          label: "全部",
          value: 0
        },
        {
          label: "运行中",
          value: 1
        },
        {
          label: "已清算",
          value: 2
        }
      ],
      userEditable: true,
      submitTimeCount: 0,
      validatedData: []
    };
  },

  computed: {
    columnsConfig() {
      return [
        {
          title: "基金ID",
          key: "fundId",
          width: 110
        },
        {
          title: "基金简称",
          key: "fundShortName"
          // render(h, { row, column, index }) {
          //   return h(
          //     "p",
          //     {
          //       // class: "ellipsis",
          //       attrs: {
          //         title: row.fundShortName
          //       }
          //     },
          //     row.fundShortName
          //   );
          // }
        },
        {
          title: "净值日期",
          key: "priceDate",
          canEdit: true,
          width: 140,
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            if (!row.isMissing) {
              let priceDate = row.priceDate;
              return priceDate ? priceDate : "--";
            } else {
              return h("editTableCell", {
                props: {
                  tableRow: row.validFlag,
                  comps: {
                    compType: "vdatePicker",
                    key: "priceDate",
                    compConfig: {
                      disabled: !this.userEditable
                    },
                    rules: [
                      (rule, value, callback) => {
                        let errors = [];
                        if (row.priceDateError) {
                          errors.push(new Error(row.priceDateError));
                        }
                        callback(errors);
                      }
                    ]
                  },
                  value: row.priceDate
                },
                on: {
                  change: val => {
                    this.onTableCellChange(val, row, column, index);
                  }
                }
              });
            }
          }
        },
        {
          title: "单位净值",
          key: "nav",
          width: 100,
          canEdit: true,
          align: "right",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            if (!row.isMissing) {
              let nav = row.nav;
              nav = nav ? Number(nav).toFixed(4) : "--";
              return nav;
            } else {
              return h("editTableCell", {
                props: {
                  ifTextAlignRight: true,
                  tableRow: row.validFlag,
                  comps: {
                    compType: "vinput",
                    key: "nav",
                    isWarnning: true,
                    compConfig: {
                      floatPoint: 4,
                      disabled: !this.userEditable
                      // number: true
                      // isWarnnig: true,
                    },
                    rules: [
                      (rule, value, callback) => {
                        let errors = [];
                        if (value <= 0 && value !== "") {
                          errors.push(new Error("净值应该大于0"));
                        }
                        callback(errors);
                      },
                      (rule, value, callback) => {
                        let errors = [];
                        if (value) {
                          if (isNaN(Number(value))) {
                            errors.push(new Error("请输入数字"));
                          }
                        }
                        callback(errors);
                      },
                      (rule, value, callback) => {
                        let errors = [];
                        if (row.navError && row.nav) {
                          errors.push(new Error(row.navError));
                        }
                        callback(errors);
                      }
                    ]
                  },
                  value: row.nav
                },

                on: {
                  change: val => {
                    this.onTableCellChange(val, row, column, index);
                  }
                }
              });
            }
          }
        },
        {
          title: "累计净值",
          key: "cumulativeNavCrawl",
          canEdit: true,
          align: "right",
          width: 100,
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            let ifDisabled = !row.nav;
            if (!row.isMissing) {
              let cumulativeNavCrawl = row.cumulativeNavCrawl;
              cumulativeNavCrawl = cumulativeNavCrawl
                ? Number(cumulativeNavCrawl).toFixed(4)
                : "--";
              return cumulativeNavCrawl;
            } else {
              let cumulativeNavCrawlInput = h("editTableCell", {
                props: {
                  tableRow: row.validFlag,
                  ifTextAlignRight: true,
                  comps: {
                    compType: "vinput",
                    key: "cumulativeNavCrawl",
                    compConfig: {
                      floatPoint: 4,
                      disabled: ifDisabled
                      // number: true
                    },
                    rules: [
                      (rule, value, callback) => {
                        let errors = [];
                        if (value) {
                          if (isNaN(Number(value))) {
                            errors.push(new Error("请输入数字"));
                          }
                        }
                        callback(errors);
                      },
                      (rule, value, callback) => {
                        let errors = [];
                        if (row.cumulativeNavCrawlError) {
                          errors.push(new Error(row.cumulativeNavCrawlError));
                        }
                        callback(errors);
                      }
                    ]
                  },
                  value: row.cumulativeNavCrawl
                },
                on: {
                  change: val => {
                    this.onTableCellChange(val, row, column, index);
                  },
                  blur: () => {}
                }
              });

              if (ifDisabled) {
                return h(
                  "el-tooltip",
                  {
                    props: {
                      enterable: false
                    }
                  },
                  [
                    cumulativeNavCrawlInput,
                    h(
                      "div",
                      {
                        slot: "content"
                      },
                      "请先填写单位净值"
                    )
                  ]
                );
              } else {
                return cumulativeNavCrawlInput;
              }
            }
          }
        },
        {
          title: "上期净值日期",
          width: 100,
          key: "prePriceDate",
          align: "right",
          render(h, { row, column, index }) {
            let prePriceDate = row.prePriceDate;
            return prePriceDate ? prePriceDate : "--";
          }
        },
        {
          title: "上期单位净值",
          width: 100,
          key: "preNav",
          align: "right",
          render(h, { row, column, index }) {
            let preNav = row.preNav;
            preNav = preNav ? Number(preNav).toFixed(4) : "--";
            return preNav;
          }
        },
        {
          title: "更新频率",
          width: 70,
          key: "navFrequency",
          align: "center",
          render(h, { row, column, index }) {
            let navFrequency = row.navFrequency;
            return navFrequency ? navFrequency : "--";
          }
        },
        {
          title: "得分",
          width: 50,
          align: "right",
          key: "score",
          render(h, { row, column, index }) {
            let color = "#fff";
            let score = Math.round(row.score);
            if (score) {
              if (score > 80) {
                color = "green";
              } else if (score <= 80 && score > 60) {
                color = "#ccccc6";
              } else {
                color = "red";
              }
            }
            score = score ? `${score}` : "--";
            return h(
              "span",
              {
                style: {
                  color
                }
              },
              score
            );
          }
        },
        {
          title: "操作",
          key: "action",
          width: 96,
          fixed: "right",
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            let disabled = false;
            if (row.nav) {
              let nav = parseFloat(row.nav);
              disabled = nav > 0 && row.priceDate;
            }

            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                //保存
                h("vbuttonSprite", {
                  props: {
                    disabled: !row.isMissing || !disabled,
                    pos: {
                      normal: { x: 0, y: 0 },
                      hover: { x: -18, y: 0 },
                      disabled: { x: -36, y: 0 }
                    },
                    title: "保存"
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      this.validateAndSubmitRow(row, index);
                    }
                  }
                }),
                //更多
                h("vbuttonSprite", {
                  props: {
                    pos: {
                      normal: { x: 0, y: -56 },
                      hover: { x: -18, y: -56 },
                      disabled: { x: -36, y: -56 }
                    },
                    title: "更多"
                  },
                  style: {
                    verticalAlign: "middle"
                  },
                  on: {
                    click: e => {
                      this.showMore(
                        row.fundId,
                        row.fundShortName,
                        row.score,
                        row.navFrequency,
                        row.inceptionDate
                      );
                    }
                  }
                })
              ]
            );
          }
        }
      ];
    }
  },

  created() {
    this.getNavList();
    this.getDocker();
  },

  mounted() {
    this.setTabelHeight();

    //获取用户权限，判断是否可编辑信息
    let currentUserInfo = localStorage.getItem("fund_master_current_user")
      ? JSON.parse(localStorage.getItem("fund_master_current_user"))
      : {};
    let userPermission = currentUserInfo.userPermission;
    this.userEditable = userPermission === 1;
  },

  methods: {
    getDocker() {
      this.$http.get("/datadis/company/getCompanyBackStage").then(res => {
        if (res.code === 20000) {
          this.dockerName = res.data.realName || res.data.receiverName;
          this.dockerPhoneNo = res.data.mobile;
        }
      });
    },

    importNav() {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      this.$refs.importNavModal.show();
    },
    setTabelHeight() {
      this.maxHeight =
        document.querySelector(".content-right").offsetHeight - 150;
      window.addEventListener("resize", () => {
        this.maxHeight =
          document.querySelector(".content-right").offsetHeight - 150;
      });
    },
    // 获取净值整体得分
    getNavScore() {
      this.$http.get("datadis/nav/getCompanyNavScore").then(res => {
        if (res.code === 20000) {
          this.score = Math.round(res.data.score);
          if (this.score > 80) {
            this.scoreStyle.color = "green";
          } else if (this.score <= 80 && this.score > 60) {
            this.scoreStyle.color = "#ccccc6";
          } else {
            this.scoreStyle.color = "red";
          }
        }
      });
    },

    // 一页展示数据发生改变
    sizeChange(val) {
      this.pageSize = val;
      this.getNavList();
    },

    // 页码发生改变
    currentChange(val) {
      this.navTableData = [];
      this.currentPage = val;
      this.getNavList();
    },

    //  搜索条件发生变化，匹配搜索
    search() {
      this.getNavList();
    },
    // 刷新表格
    refreshTableData() {
      this.getNavList(true);
    },
    // 获取净值列表
    getNavList(keepCurrentRow = false) {
      let params = Object.assign(
        {
          pageNo: this.currentPage,
          pageSize: this.pageSize
        },
        this.searchForm
      );
      if (!keepCurrentRow) {
        this.currentRowId = "";
      }
      this.loading = true;
      this.$http
        .get("datadis/nav/findFundNav", params)
        .then(res => {
          this.loading = false;
          if (res && res.code === 20000) {
            this.navTableData = res.data.records;
            this.totalItem = res.data.total;

            let currentRowIndex = _.findIndex(this.tableData, item => {
              return item.fundId === this.currentRowId;
            });
            this.$nextTick(() => {
              // this.$refs.table.setCurrentRow(currentRowIndex);
              this.$refs.table.refresh();
              this.$refs.table.setCurrentRow("fundId", this.currentRowId);
            });
          } else {
            let msg = res && res.msg ? res.msg : "数据加载失败，请点击重新加载";
            this.$message.error(msg);
            this.reload = true;
            this.navTableData = [];
          }
        })
        .then(() => {
          this.getNavScore();
        });
    },

    // 设置表格行样式
    tableRowClassName({ row, rowIndex }) {
      if (rowIndex % 2 === 1) {
        return "odd-row";
      } else {
        return "even-row";
      }
    },

    // 显示更多
    showMore(fundId, fundName, score, navFrequency, inceptionDate) {
      this.$refs.navModal.show(
        fundId,
        fundName,
        Math.round(score),
        navFrequency,
        inceptionDate
      );
    },

    // 表格可编辑数据发生变化
    onTableCellChange(val, row, column, index) {
      this.$set(row, column.property, val);
      this.validateNav(row);
    },
    // 根据一行获取需要验证和提交的净值数据
    getNavInfo(row) {
      let navInfo = {};
      let needKeys = ["fundId", "priceDate", "nav", "cumulativeNavCrawl"];
      needKeys.forEach(item => {
        if (row[item] === "" || row[item] === undefined) {
          navInfo[item] = null;
        } else {
          navInfo[item] = row[item];
        }
      });
      return navInfo;
    },
    tableRowClick({ row, column, index }) {
      this.currentRowId = row.fundId;
      this.$refs.table.setCurrentRow("fundId", this.currentRowId);
    },
    navErrConfirmModalSuccess(params) {
      this.$message({
        type: "success",
        message: "净值添加成功",
        showClose: true
      });
      //获取单条净值的新信息用于更新，避免刷新掉其他已填写的净值数据
      this.$http
        .get("datadis/nav/findFundNav", { fundId: params.data.fundId })
        .then(res => {
          if (res.code === 20000) {
            let newInfo = res.data.records[0] || null;
            if (newInfo) {
              this.navTableData[params.index] = JSON.parse(
                JSON.stringify(newInfo)
              );
              this.$refs.table.refresh();
            }
          }
        });
    },
    // 验证一行净值并设置对应单元格的错误信息，将返回的错误信息存到行数据中
    // 由于是 change 事件触发的，目前组件触发 change 比较频繁，因此做节流处理（settimeout）
    validateNav(row) {
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        row.validateResult = null;
        this.validateRow(row).then(res => {
          row.navError = "";
          row.priceDateError = "";
          row.cumulativeNavCrawlError = "";
          if (
            res.code === 20000 &&
            res.data &&
            res.data.qcData instanceof Array
          ) {
            row.validateResult = res.data;
            for (let item of res.data.qcData) {
              this.$set(
                row,
                `${errorMap[item.code].errorField}Error`,
                errorMap[item.code].notice.replace("$date", row.priceDate)
              );
            }
            // validFlag 是触发单元格验证的标识符，tableColumns 组件里面有 watch 这个值的逻辑
            this.$set(row, "validFlag", !row.validFlag);
          }
        });
      }, 100);
    },
    // 验证单行数据，并设置和关闭正在验证的状态（validating 表示是否正在验证）
    validateRow(row) {
      return new Promise(resolve => {
        let params = this.getNavInfo(row);
        if (params.nav && params.priceDate) {
          row.validating = true;
          this.$http.get("datadis/fundNav/validate", params).then(res => {
            row.validating = false;
            resolve(res);
          });
        }
      });
    },
    //  验证并提交一行净值，qcLevel 表示净值的检验结果，1 -- 错误，2 -- 异常， 3 -- 健康
    //  健康净值可以直接入库；
    //  异常的净值需要提示用户详细的异常信息，用户确认后可以入库，用户取消则取消入库；
    //  错误净值提示用户错误信息，不能入库
    validateAndSubmitRow(row, index) {
      this.loading = true;
      this.validateRow(row).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          if (res.data.qcLevel == 3) {
            this.submitRow(row, index);
          } else if (res.data.qcLevel == 2) {
            this.$refs.warnModal.open(res.data.qcData, row, index);
          } else if (res.data.qcLevel == 1) {
            let noticeContentArray = res.data.qcData.map(item => {
              let content = "";
              content = errorMap[item.code].notice.replace(
                "$date",
                row.priceDate
              );
              return content || "";
            });
            this.$alert(noticeContentArray.join("。\n\r"), "净值保存", {
              confirmButtonText: "确定",
              callback: action => {}
            });
          }
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 提交一行净值数据
    submitRow(row, index) {
      this.loading = true;
      let navInfo = this.getNavInfo(row);
      this.$http.post("datadis/fundNav", { navs: [navInfo] }).then(res => {
        this.loading = false;
        if (!res) return;
        if (res.code == 20000) {
          this.$message({
            type: "success",
            message: "净值添加成功",
            showClose: true
          });
          this.$http
            .get("datadis/nav/findFundNav", { fundId: row.fundId })
            .then(res => {
              if (res.code === 20000) {
                //监听净值填充事件
                sa.event("fundMaster_navFill", {
                  fundId: row.fundId,
                  fillType: "add"
                });
                //获取单条净值的新信息用于更新，避免刷新掉其他已填写的净值数据
                let newInfo = res.data.records[0] || null;
                if (newInfo) {
                  this.navTableData[index] = JSON.parse(
                    JSON.stringify(newInfo)
                  );
                  this.$refs.table.refresh();
                }
              }
            });
        } else if (res.code == 40010) {
          this.$message({
            type: "error",
            message: `${res.data.errorMsg}`,
            showClose: true
          });
        } else {
          this.$message({
            type: "error",
            message: `净值添加失败`,
            showClose: true
          });
        }
      });
    },
    submitRowWarnNav({ row, index }) {
      this.submitRow(row, index);
    },
    //保存当前页净值数据
    // 点击保存当页按钮时，先查看是否页面表格的验证都已经完成，如果完成了，则判断是否有异常净值，有异常净值的提示用户，根据用户的操作决定是否保存
    // 如果没完成验证，则等待净值检验完成， 每隔 500ms 检查一次是否完成，检查五次以后放弃还在验证的净值行。
    saveCurrentPageNav() {
      if (!this.userEditable) {
        this.$message.error("只读账号无法进行此操作");
        return;
      }
      let canSubmit = this.navTableData.some(row => {
        return row.isMissing && row.priceDate && row.nav;
      });
      if (!canSubmit) {
        this.$message.error("请先填写净值和净值日期后再保存");
        return;
      }
      let validatingFlag = this.navTableData.some(row => {
        return row.validating;
      });
      if (this.saveTimer) {
        clearTimeout(this.saveTimer);
      }
      this.validatedData = this.getValidatedData();
      if (validatingFlag && this.submitTimeCount < 5) {
        this.loading = true;
        this.saveTimer = setTimeout(() => {
          this.submitTimeCount++;
          this.saveCurrentPageNav();
        }, 500);
      } else if (this.validatedData.length > 0) {
        this.loading = false;
        this.submitTimeCount = 0;
        let unnormalData = this.validatedData.filter(row => {
          return row.validateResult.qcLevel == 2;
        });
        if (unnormalData.length > 0) {
          this.$refs.batchWarnModal.open(unnormalData);
        } else {
          this.submitTableNav();
        }
      } else {
        this.loading = false;
        this.submitTimeCount = 0;
        this.$message.error("请等待净值检验完成");
      }
    },
    // 提交页面填写净值
    // ifSubmitWarnData 为 true 表示是提交健康数据和异常数据，为 false 表示提交数据需要过滤掉异常数据
    submitTableNav(ifSubmitWarnData) {
      let submitData;
      if (ifSubmitWarnData) {
        submitData = this.validatedData
          .filter(item => {
            return item.validateResult.qcLevel != 1;
          })
          .map(row => {
            return this.getNavInfo(row);
          });
      } else {
        submitData = this.validatedData
          .filter(item => {
            return (
              item.validateResult.qcLevel != 2 &&
              item.validateResult.qcLevel != 1
            );
          })
          .map(row => {
            return this.getNavInfo(row);
          });
      }
      // 提交保存
      this.loading = true;
      this.$http.post("datadis/fundNav", { navs: submitData }).then(res => {
        this.loading = false;
        if (!res) return;
        if (res.code == 20000) {
          this.$message({
            type: "success",
            message: "净值添加成功",
            showClose: true
          });
          this.getNavList();
          this.validatedData = [];
        }
      });
      console.log(submitData);
    },
    // 保存页面的数据处理
    getValidatedData() {
      let validatedData = [];
      let tableData = JSON.parse(JSON.stringify(this.navTableData));
      validatedData = tableData
        .filter(
          row => row.isMissing && !row.validating && row.nav && row.priceDate
        )
        .map(item => {
          return {
            fundShortName: item.fundShortName,
            fundId: item.fundId,
            nav: item.nav,
            priceDate: item.priceDate,
            cumulativeNavCrawl: item.cumulativeNavCrawl,
            validateResult: item.validateResult
          };
        });
      return validatedData;
    }
  }
};
</script>

<style lang="less" scoped>
.remind {
  float: left;
  color: #ffffff;
  font-size: 14px;
  margin-right: 10px;
}

.tip-wrapper {
  // position: fixed;
  // bottom: 15px;
  color: #999;
}
</style>