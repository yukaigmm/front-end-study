<template>
    <vcommon ref="common" :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey" :hideHeader="fofHide" :hideMenu="fofHide">
      <div class="chance-page-content">
        <vtab ref="tab" :tabs="tabs" @clickTab="clickTab" @clickExplain="clickExplain">
          <div v-for="(item,index) in tabConfig" :key="index" :slot="item.slot" style="height: 100%;">
            <component @refreshChanceCount="refreshChanceCount" :is="item.component" :ref="item.slot"></component>
          </div>
        </vtab>
      </div>

      <tipModal ref="tipModal"></tipModal>

    </vcommon>
</template>
<script>
  import chanceSquare from "./components/chance/chance-square.vue";
  // import roadshow from "./components/roadshow/app.vue";
  import chanceManager from "./components/chance-manager//chance-manager.vue";
  import messageNotice from "./components/message-notice/message-notice.vue";
  import tipModal from './components/tip-modal.vue';
  import pageView from '../../common/mixins/pageView';
  import { getUrlParams } from '../../common/js/utils';
  import "./app.scss";
  export default {
    components: {
      chanceSquare,
      chanceManager,
      messageNotice,
      tipModal
    },
    mixins: [pageView],
    data() {
      return {
        hasTabs: true,
        currentMenuParentKey: "chance",
        currentMenuChildKey: "chance",
        tabConfig: [
          {
            slot: "chanceSquare",
            compId: 1,
            component: "chanceSquare"
          },
          {
            slot: "chanceManager",
            compId: 3,
            component: "chanceManager"
          },
          {
            slot: "messageNotice",
            compId: 4,
            component: "messageNotice"
          },
        ],
        fofHide: false, //组合大师来源标识符
      };
    },
    computed: {
      tabs () {
        let tabs = [
          {
            label: "机会",
            key: "chanceSquare",
            titleExplain: '点击查看操作指引',
          },
          {
            label: "机会管理",
            key: "chanceManager",
            titleExplain: '点击查看操作指引',
          }
        ]
        if(this.fofHide){
          return tabs
        }
        return [...tabs,{
            label: "消息提醒",
            key: "messageNotice",
            titleExplain: '点击查看操作指引',
          }]
      }
    },
    methods: {
      refreshChanceCount() {
        this.$refs.common.refreshChanceCount();
      },
      clickTab (tab) {
        this.$refs[tab][0].refresh();
      },
      clickExplain (tab) {
        this.$refs.tipModal.show();
      },
      setTheme (){
          let params = getUrlParams();
          let theme = decodeURI(params.theme);
          if(theme && theme.indexOf("skin-") > -1) {
            document.querySelector('html').className = theme
          } else {
            document.querySelector('html').className = ''
          }
      }
    },
    mounted () {
      let chanceTipHasShow = 0;
      this.$http.get('user/attribute').then( (res) => {
        if (res.code === 20000) {
          chanceTipHasShow = res.data.chanceTip || 0;
        }
        if (!chanceTipHasShow) {
          this.$refs.tipModal.show();
        }
      })
      let params = getUrlParams();
      if(params.keyWord){
        this.$refs.tab.jumpTab("chanceManager");
      }
      // this.setTheme();
      // document.querySelector('html').className = "skin-purple-white";
      // document.querySelector('html').className = "skin-blue-white";
    },
    created () {
      let params = getUrlParams();
      if (params.fof === '1') {
        this.fofHide = true;
      }
    }
  };
</script>


<style lang="scss">
.chance-page-content {
  height: 100%;
  .tab-content {
    padding: 2px 0 0 0;
  }
}
</style>


