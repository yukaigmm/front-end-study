<template>
  <div style="height:100%">
    <vpart title="机会列表" class="table-container chance-square-table-container">
      <div slot="search">
        <vselect v-model="searchForm.chanceType" :options="typeOptions" @change="search"></vselect>
        <vselect v-model="searchForm.setType" :options="statusOptions" @change="search"></vselect>
        <vinput
          type="text"
          style="display: inline-block"
          @keyup.enter.native="search"
          v-model="searchForm.keyWord"
          placeholder="关键字搜索(主题或发布机构)"
        ></vinput>
        <vbutton active title="搜索" @click="search">搜索</vbutton>
      </div>
      <div slot="action">
        <vbutton active title="发布机会" @click="addChance">发布机会</vbutton>
      </div>
      <vtable
        ref="table"
        :columns="columns"
        :data="tableData"
        :usePagination="true"
        :totalItem="totalItem"
        layout="total"
        :currentPage="pageNo"
        :rowKey="row => row.id"
        :expandRowKeys="expandRowKeys"
        :maxHeight="maxHeight"
        @pageChange="pageChange"
        @pageSizeChange="pageSizeChange"
        @tableRowClick="tableRowClick"
        @expandChange="tableRowClick"
        @sortChange="sortChange"
        :reloadMore="reloadMore"
        @reloadMoreData="lazyload(true)"
        style="position: relative"
        :fofHide="fofHide"
        :tableLoadingMore="tableLoadingMore"
      ></vtable>
      <vloading class="loading" v-model="loading"></vloading>
      <vreload v-model="reload" @reload="search"></vreload>
    </vpart>

    <!-- 机会批量操作菜单 -->
    <div class="chance-menus" v-show="menuShow" :style="chanceMenuStyle">
      <span class="menu-item" @click="setAllChanceRead">将所有机会设为已读</span>
      <span class="menu-item" @click="cancelAllChanceStar">取消所有关注</span>
    </div>

    <!-- 发布/编辑机会modal -->
    <chanceModal ref="chanceModal" @chanceModalSuccess="chanceModalSuccess"></chanceModal>
  </div>
</template>

<script>
// import contactModal from './add-contact.vue';
import chanceModal from "./chance-modal.vue";
import tableHeight from "../../../../common/mixins/table-height.js";
import {getUrlParams} from "../../../../common/js/utils.js";
import chanceDetail from "./chance-detail.vue";

export default {
  components: {
    // contactModal,
    chanceModal,
    chanceDetail
  },
  props: {
    fofHide: {
      type: Boolean,
      default: false
    }
  },
  mixins: [tableHeight],
  data() {
    return {
      hasTabs: true,
      currentMenuParentKey: "chance",
      currentMenuChildKey: "chance",
      searchForm: {
        chanceType: 0,
        setType: 0,
        keyWord: "",
        sortKey: "",
        sortOrder: ""
      },
      typeOptions: [
        {
          value: 0,
          label: "全部类型"
        },
        {
          value: 1,
          label: "资金"
        },
        {
          value: 2,
          label: "人才"
        },
        {
          value: 4,
          label: "投研"
        },
        {
          value: 3,
          label: "系统"
        },
        {
          value: 5,
          label: "活动"
        },
        {
          value: 6,
          label: "招商"
        }
      ],
      statusOptions: [
        { value: 0, label: "全部状态" },
        { value: 1, label: "已读" },
        { value: 2, label: "未读" },
        { value: 3, label: "已关注" },
        { value: 4, label: "未关注" },
        { value: 5, label: "已联系" },
        // { value: 6, label: '未联系' }
        // { value: 7, label: "已发布" },
        { value: 8, label: "有效" },
        { value: 9, label: "已过期" }
      ],
      tableData: [],
      columns: [
        {
          key: "expand",
          type: "expand",
          width: 30,
          render: (h, { row }) => {
            return h(
              "div",
              {
                class: "expand-container"
              },
              [
                h("chance-detail", {
                  props: {
                    chanceId: row.id,
                    type: "outer"
                  }
                })
              ]
            );
          }
        },
        {
          key: "chanceType",
          title: "类型",
          width: 52,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row }) => {
            let titleMap = {
              1: "资金",
              2: "人才",
              3: "系统",
              4: "投研",
              5: "活动",
              6: "招商"
            };
            let bgPositionMap = {
              1: "-32px 0",
              2: "-0 0",
              3: "-64px 0",
              4: "-96px 0",
              5: "-128px 0",
              6: "-160px 0"
            };
            return h("span", {
              style: {
                display: "block",
                width: "32px",
                height: "22px",
                lineHeight: "34px",
                display: "block",
                textAlign: "center",
                backgroundImage: `url(${
                  this.$baseUrl[process.env.NODE_ENV]["page"]
                }/assets/images/sprite-chance.png)`,
                backgroundPosition: bgPositionMap[row.chanceType]
              },
              attrs: {
                title: titleMap[row.chanceType]
              }
            });
          }
        },
        {
          key: "topic",
          title: "主题",
          showOverflowTooltip: false,
          render: (h, { row }) => {
            let outOfDate = false;
            if (row.chanceStatus === 2) {
              outOfDate = true;
            }
            let outOfDateDomString =
              '<span style="float: left">[已过期]</span>';

            return h(
              "div",
              {
                style: {
                  width: "100%",
                  height: "100%",
                  position: "relative"
                }
              },
              [
                h("span", {
                  style: {
                    display: "block",
                    width: "100%",
                    color: !row.isRead ? "rgb(206, 206, 206)" : "#999",
                    fontWeight: !row.isRead ? "bold" : "normal",
                    lineHeight: "2",
                    maxHeight: "120px",
                    overflow: "hidden"
                  },
                  domProps: {
                    innerHTML: outOfDate
                      ? `${outOfDateDomString}${row.topic}`
                      : row.topic
                  },
                  class: {
                    "is-read": row.isRead,
                  }
                }),
                !row.isRead
                  ? h("span", {
                      style: {
                        display: "block",
                        width: "5px",
                        height: "5px",
                        borderRadius: "50%",
                        position: "absolute",
                        top: "5px",
                        left: "-5px",
                        backgroundColor: "#FF4455"
                      }
                    })
                  : ""
              ]
            );
          }
        },
        {
          key: "endTime",
          title: "有效时间",
          width: 130,
          align: "right",
          sortKey: "end_time",
          // sortable: true,
          render: (h, { row }) => {
            let outOfDate = false;
            let endTime = row.endTime;
            if (endTime) {
              endTime = endTime.split(" ")[0];
              outOfDate = new Date(endTime) < new Date();
            } else {
              endTime = "";
            }
            if (endTime === "0000-00-00") {
              endTime = "";
            }
            return h(
              "span",
              {
                style: {
                  color: !row.isRead ? "rgb(206, 206, 206)" : "#999",
                  marginRight: "2px"
                },
                class: {
                  "is-read": row.isRead,
                }
              },
              endTime || "--"
            );
          }
        },
        {
          key: "companyName",
          title: "发布机构",
          width: 220,
          sortKey: "company_name",
          sortable: true,
          align: "left",
          render: (h, { row }) => {
            let companyName = row.companyName || "";
            return h(
              "span",
              {
                style: {
                  color: !row.isRead ? "rgb(206, 206, 206)" : "#999"
                },
                class: {
                  "is-read": row.isRead,
                }
              },
              companyName
            );
          }
        },
        {
          key: "createtime",
          title: "发布时间",
          width: 100,
          align: "right",
          sortKey: "create_time",
          sortable: true,
          render: (h, { row }) => {
            let date = row.createtime.split(" ")[0];
            if (date === "0000-00-00") {
              date = "--";
            }
            return h(
              "span",
              {
                style: {
                  color: !row.isRead ? "rgb(206, 206, 206)" : "#999"
                },
                class: {
                  "is-read": row.isRead,
                }
              },
              date
            );
          }
        },
        {
          key: "action",
          title: "操作",
          align: "center",
          showOverflowTooltip: false,
          width: 96,
          renderHeader: h => {
            return h(
              "span",
              {
                style: {
                  display: 'inlne-block'
                }
              },
              [
                h("span", "操作"),
                h("i", {
                  class: "iconfont icon-icon_more chance-menu-button",
                  style: {
                    cursor: "pointer",
                    marginLeft: "5px",
                    verticalAlign: "-2px"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();
                      this.showMenus();
                    }
                  }
                })
              ]
            );
          },
          render: (h, { row }) => {
            return h(
              "div",
              {
                class: 'table-action-button-container'
              },
              [
                //联系
                h(
                  "div",
                  {
                    style: {
                      display: "inline-block",
                      marginRight: "20px",
                      position: "relative"
                    }
                  },
                  [
                    h("vbuttonSprite", {
                      props: {
                        pos: row.isContact
                          ? {
                              normal: { x: 0, y: -150 },
                              hover: { x: -18, y: -150 },
                              disabled: { x: -36, y: -150 }
                            }
                          : {
                              normal: { x: 0, y: -168 },
                              hover: { x: -18, y: -168 },
                              disabled: { x: -36, y: -168 }
                            },
                        title: "联系"
                      },
                      style: {
                        verticalAlign: "middle"
                      },
                      on: {
                        click: e => {
                          // this.showContactModal(row);
                          e.stopPropagation();
                          this.showDetail(row);
                        }
                      }
                    }),
                    row.msgCount > 0
                      ? h(
                          "span",
                          {
                            style: {
                              position: "absolute",
                              top: "0",
                              right: "-8px",
                              display: "block",
                              width: "18px",
                              height: "18px",
                              lineHeight: "18px",
                              textAlign: "center",
                              backgroundColor: "#FF4455",
                              color: "#fff !important",
                              borderRadius: "50%",
                              transformOrigin: "center",
                              transform: "scale(0.75)"
                            }
                          },
                          row.msgCount > 99 ? 99 : row.msgCount
                        )
                      : ""
                  ]
                ),

                //关注
                h("vbuttonSprite", {
                  props: {
                    pos: row.isKeep
                      ? {
                          normal: { x: 0, y: -91 },
                          hover: { x: -18, y: -91 },
                          disabled: { x: -36, y: -91 }
                        }
                      : {
                          normal: { x: 0, y: -73 },
                          hover: { x: -18, y: -73 },
                          disabled: { x: -36, y: -73 }
                        },
                    title: row.isKeep ? "取消关注" : "关注"
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();
                      this.setFavoriteStatus(row);
                    }
                  }
                })
                //附件下载
                // row.attachPath ? h('vbuttonSprite', {
                //   props: {
                //     pos: {
                //       normal: { x: 0, y: -206 },
                //       hover: { x: -18, y: -206 },
                //       disabled: { x: -36, y: -206 },
                //     },
                //     title: '下载附件'
                //   },
                //   style: {
                //     verticalAlign: 'middle',
                //   },
                //   on: {
                //     click: (e) => {
                //       e.stopPropagation();
                //       this.downloadAttach(row);
                //     }
                //   }
                // }) : ''
              ]
            );
          }
        }
      ],
      totalItem: 0,
      pageNo: 1,
      pageSize: 20,
      loading: false,
      reload: false,
      reloadMore: false,
      // selectionActionShow: false,
      expandRowKeys: [],
      activeRowIds: [],
      key: null,
      menuShow: false,
      chanceMenuStyle: {},
      tableLoadingMore: false,
      moreData: true
    };
  },
  mounted() {
    
    document.body.addEventListener("click", () => {
      this.menuShow = false;
    });
    let params = getUrlParams();
    // 初始化时，根据url判断是否是从消息通知页面跳转过来的.
    // 如果是，则改变查询条件，根据（keyWord）查询到对应的机会信息，
    // if(params.keyWord){
    //   this.searchForm.chanceType = 0;
    //   this.searchForm.setType = 0;
    //   this.searchForm.keyWord = decodeURI(params.keyWord);
    //   this.currentRowId = +params.id;
    //   this.$refs.table.setCurrentRow("id", this.currentRowId);
    //   this.search().then(() => {
    //     let row = this.tableData.filter((row) => {
    //       return row.id == this.currentRowId;
    //     })[0];
    //     this.tableRowClick({row});
    //   })
    // }else{
      this.search();
    // }
  },
  methods: {
    search() {
      this.reloadMore = false;
      return new Promise(resolve => {
        this.pageNo = 1;
        this.$emit("refreshChanceCount");
        this.getChanceData().then(() => {
          setTimeout(() => {
            this.tableScroll();
          }, 100);
          resolve();
        });
      });
    },
    // 页面加载第一版
    getChanceData() {
      this.reload = false;
      this.loading = true;
      return new Promise((resolve, reject) => {
        this.expandRowKeys = [];
        let params = this.getParams();
        this.$http.get("chance", params).then(res => {
          this.loading = false;
          if (res && res.code === 20000) {
            this.totalItem = res.data.total;
            let records = this.getRecords(res.data.records);
            this.tableData = records;
            // this.key = Date.now();
            // 监听机会改动事件
            this.sendSaEvent(records,this.totalItem);
            if(records.length == this.pageSize){
              this.moreData = true;
            }
          }else{
              this.reload = true;
              this.tableData = [];
              let msg = res && res.msg ? res.msg : "数据获取失败，请点击重试";
              this.$message.error(msg);
          }
          resolve(res);
        });
      });
    },
    // 获取参数
    getParams(){
      this.pageSize = this.getPageSize();
      let params = {
          pageNo: this.pageNo,
          pageSize: this.pageSize
        };
        for (let key in this.searchForm) {
          params[key] = this.searchForm[key];
        }
        if (params.setType === 7) {
          params.isCompany = 1;
          params.setType = 0; //设为全部
        }

        //有效期采用chanceStatus字段查询
        if (params.setType === 8 || params.setType === 9) {
          let map = {
            8: 1,
            9: 2
          };
          params.chanceStatus = map[params.setType];
          params.setType = 0; //设为全部
        }
        return params;
    },
    // 监听机会改动事件
    sendSaEvent(records, totalCount){
      let readCount = records.filter(item => {
        return item.isRead === 1;
      }).length;
      let recordCount = records.filter(item => {
        return item.isContact === 1;
      }).length;
      let starCount = records.filter(item => {
        return item.isKeep === 1;
      }).length;
      sa.event("fundMaster_chanceAction", {
        totalCount,
        readCount,
        recordCount,
        starCount
      });
    },
    // 处理tableData
    getRecords(resRecords=[]){
      let records = resRecords.map((item) => {
          if(item.isAnonymous != 1){
            item.companyName = item.bread.map((orgInfo) => {
              return orgInfo.title;
            }).join(">");
          };
          return item;
      })
      return records;
    },
    // 根据页面的高度，计算出懒加载的 table 需要加载多少行才能使得 table 滚动，否则固定的 pageSize 导致屏幕较大的用户 table 不能滚动，就无法触发懒加载
    // 50 是页脚的高度， 34 是表头的高度， 35 是表格一行的高度, pageSize 取计算出来的数值和 20 两者的较大值。
    getPageSize(){
      let tbodyHeight = $(".chance-page-content").innerHeight() - $(".chance-page-content .el-tabs__header.is-top").outerHeight() - $(".chance-page-content .part-header").outerHeight() - 50 - 34;
      return Math.max(Math.ceil(tbodyHeight / 35) + 1, 20);
    },
    refresh() {
      // this.key = Date.now();
      this.search();
    },
    // 点击排序
    sortChange(order, prop) {
      let map = {
        companyName: "company_name",
        createtime: "createtime"
      };
      this.searchForm.sortKey = map[prop];
      this.searchForm.sortOrder = order;
      this.search();
    },
    pageChange() {},
    pageSizeChange() {},
    showContactModal(data) {
      this.$refs.contactModal.show(data);
    },
    showDetail(data) {
      //设置table的expandRowKeys，若当前行在其中，则会自动加载详情组件
      let index = this.expandRowKeys.indexOf(data.id);
      if (index === -1) {
        this.expandRowKeys.push(data.id);
      } else {
        this.expandRowKeys.splice(index, 1);
      }

      //判断当前行机会是不是处于打开详情状态，如果是则进行用户行为记录
      let isRowExpand = this.expandRowKeys.indexOf(data.id) !== -1;
      if (isRowExpand) {
        this.$http.put("chance/chanceLog", {
          chanceId: [].concat(data.id),
          viewType: 1
        });
      }
    },
    //设置关注状态
    setFavoriteStatus(data) {
      let metaValue = data.isKeep === 0 ? 1 : 0; //1设为关注 0取消关注
      let viewType = data.isKeep === 0 ? 5 : 6; // 5设为关注 6取消关注
      let param = {
        chanceId: [].concat(data.id),
        setType: 2,
        metaValue: metaValue
      };
      this.$http.put("chance/usermeta", param).then(res => {
        if (!res) return;
        if (res.code === 20000) {
          this.$message({
            type: "success",
            message: metaValue === 1 ? "关注成功" : "取消关注成功",
            showClose: true
          });
          data.isKeep = metaValue === 1 ? 1 : 0;
          // this.getChanceData(true);
          this.$http.put("chance/chanceLog", {
            chanceId: [].concat(data.id),
            viewType: viewType
          });
        } else {
          this.$message({
            type: "error",
            message: res.msg,
            showClose: true
          });
        }
      });
    },
    tableRowClick({ row }) {
      // 显示/关闭机会详情，即将当前机会id添加/删除到table的expandRowKey中
      this.showDetail(row);

      //如果当前行未读，则设成已读
      if (!row.isRead) {
        let param = {
          chanceId: [].concat(row.id),
          setType: 1,
          metaValue: 1
        };
        this.$http.put("chance/usermeta", param).then(res => {
          if (!res) return;
          if (res.code === 20000) {
            //手动设置为已读状态, 但不刷新表格数据，保留选中项
            row.isRead = 1;

            //刷新菜单中的数字提示
            // this.$refs.common.refreshChanceCount();
            this.$emit("refreshChanceCount");
            //日志
            this.$http.put("chance/chanceLog", {
              chanceId: [].concat(row.id),
              viewType: 1
            });
          }
        });
      }
      this.currentRowId = row.id;
      this.$refs.table.setCurrentRow("id", this.currentRowId);
      this.$refs.table.toggleRowSelection(row);
    },
    addChance() {
      this.$refs.chanceModal.show();
    },
    chanceModalSuccess() {
      this.search();
    },
    showMenus() {
      this.menuShow = !this.menuShow;
      let button = $(this.$el).find(".chance-menu-button");
      this.chanceMenuStyle = {
        left: `${(button.offset().left - $(window).scrollTop()) - 80}px`,
        top: `${(button.offset().top - $(window).scrollLeft()) + 20}px`
      };
    },
    setAllChanceRead() {
      this.menuShow = !this.menuShow;
      this.$http
        .put("chance/usermeta", {
          setType: 1,
          metaValue: 1
        })
        .then(res => {
          if (res.code === 20000) {
            this.$message.success("批量设置成功");
            this.search();
            this.$emit("refreshChanceCount");

            //监听批量设置机会为已读事件
            sa.event("fundMaster_setAllChanceRead");
          }
        });
    },
    cancelAllChanceStar() {
      this.menuShow = !this.menuShow;
      this.$http
        .put("chance/usermeta", {
          setType: 2,
          metaValue: 0
        })
        .then(res => {
          if (res.code === 20000) {
            this.$message.success("批量设置成功");
            this.search();

            sa.event("fundMaster_cancelAllChanceStar");
          }
        });
    },
    // 表格懒加载
    tableScroll() {
      $(
        ".table-container.chance-square-table-container .el-table__body-wrapper"
      ).on("scroll", () => {
        if (this.moreData) {
          let scrollTop = document.querySelector(
            ".table-container.chance-square-table-container .el-table__body-wrapper"
          ).scrollTop;
          let scrollHeight = document.querySelector(
            ".table-container.chance-square-table-container .el-table__body-wrapper table.el-table__body"
          ).scrollHeight;
          let containerHeight = document.querySelector(
            ".table-container.chance-square-table-container .el-table__body-wrapper"
          ).offsetHeight;
          if (
            scrollTop + containerHeight > scrollHeight - 100 &&
            scrollTop > 0
          ) {
            this.moreData = false;
            this.pageNo++;
            this.lazyload(true)
          }
        }
      });
    },
    lazyload(keepCurrentRow = false) {
      this.reloadMore = false;
      this.tableLoadingMore = true;
      return new Promise((resolve, reject) => {
        // this.expandRowKeys = [];
        let params = this.getParams();
        this.$http.get("chance", params).then(res => {
          this.tableLoadingMore = false;
          if (res && res.code === 20000) {
            let records = this.getRecords(res.data.records);
            this.tableData = this.tableData.concat(records);
            if (
                res.data.records instanceof Array &&
                res.data.records.length === this.pageSize
              ) {
                this.moreData = true;
              } else {
                this.moreData = false;
              }
            this.$nextTick(() => {
              this.$refs.table.setCurrentRow("id", this.currentRowId);
            });
          }else{
              this.reloadMore = true;
              let msg = res && res.msg ? res.msg : "数据获取失败，请点击重试";
              this.$message.error(msg);
              this.moreData = true;
          }
          resolve(res);
        });
      });
    },
  }
};
</script>
<style lang="less">
.chance-wrapper {
  position: relative;
  user-select: none;
  a {
    &:hover {
      text-decoration: underline;
    }
  }
  // .chance-menus {
  //   display: block;
  //   position: fixed;
  //   top: 0;
  //   left: 0;
  // }
}
.el-table--border .el-table__expanded-cell {
  border-right: none;
}
.expand-container {
  // min-height: 140px;
  // max-height: 220px;
  background-color: #202020;
  border-bottom: 1px solid #000;
}

.chance-menus {
  display: inline-block;
  width: auto;
  position: fixed;
  top: 0;
  left: 0;
  background-color: #222;
  border: 1px solid rgb(85, 85, 85);
  box-shadow: 0 0 2px #666;
  z-index: 100;
  .menu-item {
    display: block;
    font-size: 12px;
    padding: 0 10px;
    line-height: 30px;
    color: #999;
    cursor: pointer;
    &:hover {
      background-color: #345;
      color: #aaa;
    }
  }
}
</style>
