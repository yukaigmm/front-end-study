<template>
  <div class="chance-detail-container">
    <div class="info-container" v-if="!userId">
      <div v-if="content" v-html="content" @click="contentClick"></div>
      <div class="divide-line" v-if="content"></div>
      <div v-if="attachPath" class="attach-container">
        <span>
          附件: 
          <a href="javascript: void(0)" @click="downloadAttach">{{attachName}}</a>
        </span>
      </div>
      <div class="divide-line" v-if="attachPath"></div>
    </div>
    <div class="msg-container">
      <div v-for="(msg, index) in chanceMsgs" :key="index" class="msg">
        <div class="msg-header">
          <!-- <span class="name">{{msg.userId === currentUser.userId ? '我' : (userId ? msg.userName : companyName)}}</span> -->
          <span class="name">{{getName(msg)}}</span>
          <span class="time">{{msg.createtime}}</span>
        </div>
        <div class="msg-content">
          <span class="content" v-html="msg.content.replace(/\n/g,'<br>')"></span>
        </div>
      </div>
    </div>
    <div v-if="type === 'outer'">
      <div class="contact-container" v-if="!isChanceManager">
        <vtextArea v-model="msg" placeholder="此处输入消息点击发送"></vtextArea>
        <vbutton active class="send-button" @click="sendMsg">发送</vbutton>
      </div>
      <div class="tip-container" v-else>
        <span>注：您是该机会的发布者.若您想回复消息,请在机会管理模块中进行操作</span>
      </div>
    </div>
    <div v-if="type === 'inner'">
      <div class="contact-container" v-if="this.isManager">
        <vtextArea v-model="msg" placeholder="此处输入消息点击发送"></vtextArea>
        <vbutton active class="send-button" @click="sendMsg">发送</vbutton>
      </div>
      <div class="tip-container" v-else>
        <span>注：您不是该机会的发布者,无法进行回复操作</span>
      </div>
    </div>

    <vloading v-model="loading"></vloading>
  </div>
</template>

<script>
export default {
  props: {
    chanceId: {
      type: [String, Number],
      required: true,
    },
    userId: {
      type: [String, Number],
    },
    isManager: {
      type: Boolean,
    },
    type: {
      type: String,
      default: 'outer'
    }
  },
  data () {
    return {
      loading: false,
      msg: '',
      content: '',
      attachName: '',
      attachPath: '',
      chanceMsgs: [],
      managerId: '',
      currentUser: {},
    }
  },
  computed: {
    isChanceManager () {
      return this.managerId === this.currentUser.userId;
    }
  },
  methods: {
    getChanceDetail (id) {
      let chanceId = id || this.chanceId;
      this.loading = true;
      return new Promise( (resolve, reject) => {
        this.$http.get(`chance/${chanceId}`).then( (res) => {
          this.loading = false;
          if (res.code === 20000) {
            this.content = res.data.content;
            this.attachName = res.data.attachName;
            this.attachPath = res.data.attachPath;
            this.chanceMsgs = res.data.chanceMsg;
            this.managerId = res.data.managerId;
            this.companyName = res.data.companyName;
            resolve();
          }
        })
      })
    },
    getChanceUserRecord () {
      return new Promise( (resolve, reject) => {
        this.loading = true;
        this.$http.get(`chance/message/${this.chanceId}`, {
          pageNo: 1,
          pageSize: -1,
          userId: this.userId
        }).then( (res) => {
          this.loading = false;
          if (res.code === 20000) {
            this.chanceMsgs = res.data.records;
            resolve();
          }
        })
      })
    },
    getName (msg) {
      let name = '';
      if (msg.userId === this.currentUser.userId) {
        name = '我'
      } else {
        if (this.type === 'inner') {
          name = msg.userName;
        } else if (this.type === 'outer') {
          //判断当前用户是不是该机会的发布者。
          //如果是，展示对方人名。
          //如果不是，展示发布机构。
          if (this.managerId === this.currentUser.userId) {
            name = msg.userName;
          } else {
            name = this.companyName;
          }
        }
      }
      return name;
    },
    sendMsg () {
      // console.log(this.msg.trim());
      if(this.msg.trim() === ""){
        this.$message.error("请输入消息后再发送");
        return;
      }
      this.loading = true;
      let params = {
        chanceId: this.chanceId,
        content: this.msg
      };
      if (this.userId) {
        params.recipientsId = this.userId;
      }
      this.$http.post('chance/msg', params).then( (res) => {
        this.loading = false;
        if (res.code === 20000) {
          this.$message.success('消息发送成功');
          this.getChanceInfo();
          this.msg = '';

          //设置机会联系状态
          this.$http.put('chance/usermeta', {
            chanceId: this.chanceId,
            setType: 3,
            metaValue: 1
          });
        } else {
          this.$message.error('发送失败，' + res.msg);
        }
      })
    },
    downloadAttach () {
      let viewType = 2; // 2附件下载
      this.$http.put('chance/chanceLog',{
        chanceId: [].concat(this.chanceId),
        viewType: viewType
      });
      window.open(`${this.$baseUrl[process.env.NODE_ENV]['host']}/api/common/download?fileName=${this.attachName}&filePath=${this.attachPath}`);
    },
    getChanceInfo () {
      if (!this.userId) {
        return this.getChanceDetail();
      } else {
        return this.getChanceUserRecord();
      }
    },
    //设置相应的消息为已读
    setMsgRead () {
      //管理页面
      if (this.userId) {
        this.$http.put(`chance/handle/message/${this.chanceId}`, {
          userId: this.userId,
          isRead: 1
        });
      } else {
        //外部页面
        this.$http.put(`chance/message/${this.chanceId}`, {
          chanceId: this.chanceId,
          msgStatus: 2,
        })
      }
    },
    //内容点击，如果点击内容是a链接，则进行用户行为记录
    contentClick (e) {
      let target = e.target;
      
      if (target.href) {
        let viewType = 8; // 8链接点击
        this.$http.put('chance/chanceLog',{
          chanceId: [].concat(this.chanceId),
          viewType: viewType
        })
      } 
    }
  },
  mounted () {
    
    this.getChanceInfo().then( () => {
      //将消息设置成未读
      this.setMsgRead();
    })

    let currentUser = JSON.parse(localStorage.getItem('fund_master_current_user'));
    this.currentUser = currentUser;
    
  }
}
</script>


<style lang="less" scoped>
  .chance-detail-container {
    color: #eee;
    padding: 10px 30px;
    overflow: hidden;
    position: relative;
    min-height: 100px;
    user-select: text;
    background-color: #111;
    .divide-line {
      border-top: 1px solid #333;
      margin: 3px 0;
    }
    .info-container {
      // .attach-container {
      //   margin-top: 3px;
      //   padding-top: 2px;
      //   border-top: 1px solid #333;
      // }
    }
    .msg-container {
      max-height: 300px;
      overflow-y: auto;
      .msg {
        margin: 3px 0;
        .msg-header {
          color: #2992ff;
          .name {
            margin-right: 10px;
          }
        }
      }
    }
    .contact-container {
      margin-top: 15px;
      .send-button {
        margin: 10px 0;
        float: right;
      }
    }
    .tip-container {
      margin-top: 10px;
      color: #666;
    }
  }
</style>

