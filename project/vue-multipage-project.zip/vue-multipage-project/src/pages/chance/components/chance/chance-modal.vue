<template>
  <vmodal
    ref="addChanceModal"
    class="add-chance-modal t2-el-dialog"
    :width="600"
    title="发布机会"
    @close="cancel"
  >
    <div class="chance-form-container">
      <vformConfig ref="chanceForm" :config="chanceFormConfig" v-model="form"></vformConfig>
      <vloading v-model="loading"></vloading>
      <div style="padding: 0 10px;">
        <span class="tip">
          <span class="tip-title">免责申明：</span>
          <span class="tip-content">机会主题一经发布则在平台公示，内容的真实性、合规性由发布机构全权负责并具有最终解释权，排排网作为第三方服务平台，仅提供展示。</span>
        </span>
      </div>
    </div>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="submitChance">提交</vbutton>
    </div>
    <vloading slot="loading" v-model="chanceLoading"></vloading>
  </vmodal>
</template>

<script>
import $ from "jquery";
export default {
  data() {
    return {
      form: {
        topic: "",
        companyId: "",
        isAnonymous: 0,
        managerId: "",
        chanceType: ""
      },
      defaultCompany: "",
      loading: false
    };
  },
  computed: {
    chanceFormConfig() {
      return {
        cols: 12,
        fields: [
          [
            {
              label: "主题",
              labelWidth: 95,
              colspan: 12,
              comps: [
                {
                  key: "topic",
                  compType: "vinput",
                  compConfig: {
                    placeholder: "请输入标题，不超过30个字"
                  },
                  rules: [
                    { required: true, message: "必填" },
                    {
                      type: "string",
                      min: 0,
                      max: 30,
                      message: "不能超过30个字（字母数字均占一位）"
                    }
                  ]
                }
              ]
            }
          ],
          [
            {
              label: "详情",
              labelWidth: 95,
              colspan: 12,
              comps: [
                {
                  key: "content",
                  compType: "veditor",
                  compConfig: {
                    editorId: "content",
                    editorConfig: {
                      menus: ["link"]
                    }
                  }
                }
              ]
            }
          ],
          [
            // {
            // 	label: '发布机构',
            //   labelWidth: 95,
            //   colspan: 6,
            // 	comps: [
            // 		{
            // 			key: 'companyId',
            // 			compType: 'vtext',
            //       compConfig: {
            //         text: this.defaultCompany,
            //       }
            //     },
            // 	]
            // },
            {
              label: "是否匿名",
              labelWidth: 95,
              colspan: 6,
              comps: [
                {
                  key: "isAnonymous",
                  compType: "vswitch",
                  compConfig: {
                    type: "checkbox",
                    trueValue: 1,
                    falseValue: 0,
                    trueLabel: ""
                  }
                }
              ]
            },
            {
              label: "有效时间",
              labelWidth: 95,
              colspan: 6,
              comps: [
                {
                  key: "endTime",
                  compType: "vdatePicker",
                  compConfig: {
                    placeholder: "请选择"
                  }
                }
              ]
            }
          ],
          [
            {
              label: "业务负责人",
              labelWidth: 95,
              colspan: 6,
              comps: [
                {
                  key: "managerId",
                  compType: "vselect",
                  compConfig: {
                    url: "user/account",
                    extendKey: "records",
                    searchParam: {
                      pageNo: 1,
                      pageSize: -1
                    },
                    labelKey: "realName",
                    valueKey: "officialUserId"
                  },
                  rules: [{ required: true, type: "string", message: "必选" }]
                }
              ]
            },
            {
              label: "消息类型",
              labelWidth: 95,
              colspan: 6,
              comps: [
                {
                  key: "chanceType",
                  compType: "vselect",
                  compConfig: {
                    options: [
                      {
                        value: "1",
                        label: "资金"
                      },
                      {
                        value: "2",
                        label: "人才"
                      },
                      {
                        value: "4",
                        label: "投研"
                      },
                      {
                        value: "3",
                        label: "系统"
                      },
                      {
                        value: "5",
                        label: "活动"
                      },
                      {
                        value: "6",
                        label: "招商"
                      }
                    ]
                  },
                  rules: [{ required: true, type: "string", message: "必选" }]
                }
              ]
            }
          ],
          [
            {
              label: "附件",
              labelWidth: 95,
              colspan: 12,
              comps: [
                {
                  key: "attachPath",
                  compType: "vfileUpload",
                  compConfig: {
                    url: "common/upFile",
                    fileName: "chanceAttach",
                    resName: "fileName"
                  }
                }
              ]
            }
          ],
          [
            {
              label: "备注",
              labelWidth: 95,
              colspan: 12,
              comps: [
                {
                  key: "remark",
                  compType: "vinput",
                  cols: 12,
                  validate: false
                },
                {
                  key: "tip",
                  compType: "vtext",
                  cols: 12,
                  compConfig: {
                    text: "(备注内容不对外展示，仅供公司内部查看)"
                  }
                }
              ]
            }
          ]
        ]
      };
    }
  },
  methods: {
    show(chanceId) {
      //延迟100ms 为解决编辑时表单无数据的问题，原因未明。
      setTimeout( () => {
        if (chanceId) {
          //编辑
          this.loading = true;
          this.chanceId = chanceId;
          this.$http.get(`chance/${chanceId}`).then(res => {
            this.loading = false;
            if (res.code === 20000) {
              this.form = res.data;
              this.defaultCompany = this.form.companyName;
              if (this.form.attachName && this.form.attachPath) {
                this.form.attachPath = {
                  fileName: this.form.attachName,
                  filePath: this.form.attachPath
                };
              }
              this.form.managerId = `${this.form.managerId}`;
              this.form.chanceType = `${this.form.chanceType}`;
            }
          });
        } else {
          //新增
          let currentUserInfo = JSON.parse( localStorage.getItem("fund_master_current_user") );
          this.defaultCompany = currentUserInfo.companyName;
          this.form.companyId = currentUserInfo.companyId;
          this.form.managerId = `${currentUserInfo.userId}`;
        }
        this.$refs.addChanceModal.open();
      }, 100);
    },
    hide() {
      this.$refs.addChanceModal.close();
    },
    reset() {
      this.form = {
        topic: "",
        companyId: "",
        isAnonymous: 0,
        managerId: "",
        chanceType: ""
      };
      this.chanceId = "";
      let currentUserInfo = JSON.parse(
        localStorage.getItem("fund_master_current_user")
      );
      this.defaultCompany = currentUserInfo.companyName;
      this.$refs.chanceForm.resetValid();
    },
    // 发布机会
    submitChance() {
      if (
        this.form.attachPath &&
        this.form.attachPath.fileName &&
        this.form.attachPath.filePath
      ) {
        this.form.attachName = this.form.attachPath.fileName;
        this.form.attachPath = this.form.attachPath.filePath;
      }
      if (!(window.sessionStorage.getItem("canSend") === "false")) {
        this.loading = true;
      }
      this.$refs.chanceForm.valid().then(valid => {
        if (valid) {
          if (this.chanceId) {
            //编辑
            this.$http.put(`chance/${this.chanceId}`, this.form).then(res => {
              this.loading = false;
              if (!res) return;
              if (res.code === 20000) {
                this.$message.success("修改成功");
                this.cancel();
                this.$emit("chanceModalSuccess");
              } else {
                this.$message.error(res.msg);
              }
            });
          } else {
            //新增
            this.$http.post("chance", this.form).then(res => {
              this.loading = false;
              if (!res) return;
              if (res.code === 20000) {
                this.$message.success("新增成功");

                //监听机会发布事件
                sa.event("fundMaster_addChance", {
                  isHide: this.form.isAnonymous
                });

                this.cancel();
                this.$emit("chanceModalSuccess");
              } else {
                this.$message.error(res.msg);
              }
            });
          }
        } else {
          this.$message.error("请按提示填写字段");
          this.loading = false;
        }
      });
    },
    cancel() {
      this.hide();
      this.reset();
    }
  }
};
</script>


<style lang="less" scoped>
.add-chance-modal {
  .chance-form-container {
    position: relative;
    height: 100%;
    .tip {
      display: block;
      line-height: 26px;
      font-size: 12px;
      .tip-title {
        font-weight: bold;
        float: left;
      }
      .tip-content {
        float: left;
        width: calc(~"100% - 88px");
        margin-left: 22px;
      }
      &:after {
        content: "";
        display: block;
        clear: both;
      }
    }
  }
}
</style>

