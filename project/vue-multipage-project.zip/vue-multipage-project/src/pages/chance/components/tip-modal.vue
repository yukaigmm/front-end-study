<template>
  <vmodal ref="tipModal" class="tip-modal t2-el-dialog" title="提示" @close="cancel" :deep="true" :width="1000">
    <div class="tip-img-container">
      <img
        v-for="(img, index) in tipImgsConfig"
        :key="index"
        :src="getImgSrc(img)"
        alt
        v-show="currentIndex == (index+1)"
      >
    </div>
    <div slot="modal-footer" style="position: relative;">
      <div class="button-container">
        <span class="order-button prev" @click="reduceIndex">
          <i class="el-icon el-icon-arrow-left"></i>
        </span>
        <span class="order-text">{{currentIndex + ' / ' + tipImgsConfig.length}}</span>
        <span class="order-button next" @click="addIndex">
          <i class="el-icon el-icon-arrow-right"></i>
        </span>
      </div>
      <vbutton active @click="noLongerPropmt">不再提示</vbutton>
    </div>
  </vmodal>
</template>


<script>
import { getUrlParams } from '../../../common/js/utils'; 
export default {
  data() {
    return {
      nolongerPrompt: false,
      currentIndex: 1,
      theme: "default",
    };
  },
  computed: {
    tipImgsConfig() {
      return [
        "other-chance.jpg",
        "self-chance.jpg"
      ];
    }
  },
  methods: {
    show() {
      this.$refs.tipModal.open();
      let nolongerPrompt =
        localStorage.getItem("fund_master_tip_nolonger_prompt") || 0;
      this.nolongerPrompt = parseInt(nolongerPrompt);
    },
    hide() {
      this.$refs.tipModal.close();
    },
    cancel() {
      this.hide();
      this.reset();
    },
    noLongerPropmt() {
      this.hide();
      this.reset();

      this.$http.put("user/attribute", { chanceTip: 1 });
      //监听不再提示事件
      sa.event("fundMaster_chanceNoLongerPrompt", {});
    },
    reset() {
      this.currentIndex = 1;
    },
    reduceIndex() {
      this.currentIndex--;
      this.currentIndex = this.currentIndex < 1 ? 1 : this.currentIndex;
    },
    addIndex() {
      this.currentIndex++;
      this.currentIndex =
        this.currentIndex > this.tipImgsConfig.length
          ? this.tipImgsConfig.length
          : this.currentIndex;
    },
    getImgSrc(src) {
      return `${this.$baseUrl[process.env.NODE_ENV]["page"]}/assets/images/tips/${this.theme}/${src}`;
    }
  },
  mounted() {
    let params = getUrlParams();
    if(params.theme !== undefined && ''+params.theme !== "null"){
      this.theme = params.theme;
    }
  },
};
</script>

<style lang="less">
.tip-modal {
  .tip-img-container {
    padding: 10px 10px 5px 10px;
    text-align: center;
    img {
      max-width: 100%;
      height: auto;
    }
  }
  .button-container {
    display: block;
    position: absolute;
    left: 50%;
    top: 0;
    transform: translate(-50%, 0);
    .order-button {
      display: inline-block;
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      background-color: #555;
      color: #fff;
      border-radius: 5px;
      cursor: pointer;
      &:hover {
        color: #2992ff;
      }
    }
    .order-text {
      margin: 0 3px;
    }
  }
}
</style>


