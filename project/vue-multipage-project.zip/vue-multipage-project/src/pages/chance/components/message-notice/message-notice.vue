<template>
  <div style="height:100%">
    <vpart title="公司机会列表" class="table-container message-notice-table-container">
      <div slot="search">
        <vselect v-model="searchForm.noticeType" :options="typeOptions" @change="search"></vselect>
        <vselect v-model="searchForm.isRead" :options="statusOptions" @change="search"></vselect>
        <vinput
          type="text"
          class="table-search-input"
          style="display: inline-block"
          @keyup.enter.native="search"
          v-model="searchForm.keyWord"
          placeholder="关键字搜索"
        ></vinput>
        <vbutton
          active
          title="搜索"
          @click="search"
        >搜索</vbutton>
      </div>
      <!-- <div slot="action">
        <vbutton
          active
          title="发布机会"
          @click="addChance"
        >发布机会</vbutton>
      </div> -->
      <vtable
        :key="key"
        ref="table"
        :columns="columns"
        :data="tableData"
        :usePagination="true"
        :totalItem="totalItem"
        layout="total"
        :currentPage="pageNo"
        :rowKey="row => row.id"
        :maxHeight="maxHeight"
        :tableLoadingMore="tableLoadingMore"
        @pageChange="pageChange"
        @pageSizeChange="pageSizeChange"
        @tableRowClick="tableRowClick"
        :reloadMore="reloadMore"
        @reloadMoreData="lazyload(true)"
        style="position: relative"
        :fofHide="fofHide"
      ></vtable>
      <vloading class="loading" v-model="loading"></vloading>
      <vreload v-model="reload" @reload="search"></vreload>
    </vpart>

    <!-- <chanceModal ref="chanceModal" @chanceModalSuccess="chanceModalSuccess"></chanceModal>
    <chanceRecordModal ref="chanceRecordModal" @cancel="chanceRecordModalCancel"></chanceRecordModal> -->
  </div>
</template>

<script>
// import chanceModal from "./chance-modal.vue";
// import chanceRecordModal from "./contact-record.vue";
import tableHeight from "../../../../common/mixins/table-height.js";
import getMessageConfig from "./button-config.js";
import _ from "lodash";

export default {
  components: {
    // chanceModal,
    // chanceRecordModal
  },
  props: {
    fofHide: {
      type: Boolean,
      default: false
    }
  },
  mixins: [tableHeight],
  data() {
    return {
      hasTabs: true,
      currentMenuParentKey: "chance",
      currentMenuChildKey: "chance",
      searchForm: {
        noticeType: 0,
        isRead: 0,
        topic: ""
      },
      typeOptions: [
        {
          value: 0,
          label: "全部类型"
        },
        {
          value: 1,
          label: "信披"
        },
        {
          value: 2,
          label: "活动"
        },
        {
          value: 3,
          label: "系统"
        }
      ],
      statusOptions: [
        { value: -1, label: "全部状态" },
        { value: 1, label: "已读" },
        { value: 0, label: "未读" }
      ],
      tableData: [],
      totalItem: 0,
      pageNo: 1,
      pageSize: 20,
      loading: false,
      reload: false,
      key: null,
      tableLoadingMore: false,
      moreData: true,
      reloadMore: false,
    };
  },
  computed: {
    columns() {
      let columns = [
        {
          key: "noticeType",
          title: "消息类别",
          width:80,
          showOverflowTooltip: false,
          render: (h, {row}) => {
            let map = {
              1: "信披",
              2: "活动",
              3: "系统"
            }
            return h("div", map[row.noticeType]||"--")
          }
        },
        {
          key: "noticeName",
          title: "子类别",
          width: 100,
          showOverflowTooltip: false,
        },
        {
          key: "noticeInfo",
          title: "消息内容",
          render: (h, {row}) => {
            let fillData = row.noticeData;
            let content = row.noticeInfo;
            for(let key in fillData){
              if(fillData[key] == null){
                  fillData[key] = "";
              }
              content = content.replace(key, fillData[key]);
            };
            return h("span", content)
          }
        },
        {
          key: "action",
          title: "操作",
          width: 40,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row }) => {
            let buttonConfig = getMessageConfig.call(this, {h, row});
            return h("div",{
              style: {
                textAlign: "left"
              },
              class: {
                "table-action-button-container": true
              }
            },buttonConfig[row.triggerType]["buttons"])
          }
        }
      ];
      return columns;
    }
  },
  mounted() {
  },
  methods: {
    //设置授权状态
    setAuthorizeStatus(id, status) {
        return new Promise((resolve, reject) => {
            this.$http
            .post(`masterAuth/change/${id}`, {
                authId: id,
                authStatus: status
            })
            .then(res => {
                if (res.code === 20000) {
                    this.$message.success("操作成功");
                    resolve();
                }
            });
        });
    },
    // 设置已读
    setNoticeRead(id){
        return new Promise((resolve,reject) => {
            this.$http.put("notice/"+id).then((res) => {
                resolve()
            })
        })
    },
    search() {
      this.reloadMore = false;
      return new Promise(resolve => {
        this.pageNo = 1;
        this.loading = true;
        this.getMessageData().then(() => {
          this.loading = false;
          this.$refs.table.refresh();
          setTimeout(() => {
            this.tableScroll();
          }, 100);
          resolve();
        });
      });
    },
    getMessageData() {
      return new Promise((resolve, reject) => {
        this.pageSize = this.getPageSize();
        let params = this.getParams();

        this.$http.get("notice/message", params).then(res => {
          if (res && res.code === 20000) {
            this.totalItem = res.data.total;
            this.tableData = this.dealWithTableData(res.data.records);
            this.$nextTick(() => {
              this.$refs.table.setCurrentRow("messageId", this.currentRowId);
            });
            if(res.data.records.length == this.pageSize){
              this.moreData = true;
            }
          }else{
            let msg = res && res.msg ? res.msg : "数据加载失败，请点击重试";
            this.$message.error(msg);
            this.reload = true;
            this.tableData = [];
          }
          resolve(res);
        });
      });
    },
    dealWithTableData(data){
      let tableData = JSON.parse(JSON.stringify(data));
      return tableData.map((row) => {
        let fillData = row.noticeData;
        let content = row.noticeInfo;

        for(let key in fillData){
          if(fillData[key] == null){
              fillData[key] = "";
          }
          content = content.replace(key, fillData[key]);
        };
        return Object.assign({}, row, {
          noticeInfo: content,
          noticeKeyword: row.noticeKeyword || row.noticeIndex
        })
      })
    },
    refresh() {
      this.search();
    },
    pageChange() {},
    pageSizeChange() {},
    getParams(){
      let params = {
        pageNo: this.pageNo,
        pageSize: this.pageSize,
      };
      for (let key in this.searchForm) {
        params[key] = this.searchForm[key];
      }
      return params;
    },
    // 根据页面的高度，计算出懒加载的 table 需要加载多少行才能使得 table 滚动，否则固定的 pageSize 导致屏幕较大的用户 table 不能滚动，就无法触发懒加载
    // 50 是页脚的高度， 34 是表头的高度， 35 是表格一行的高度, pageSize 取计算出来的数值和 20 两者的较大值。
    getPageSize(){
      let tbodyHeight = $(".chance-page-content").innerHeight() - $(".chance-page-content .el-tabs__header.is-top").outerHeight() - $(".chance-page-content .part-header").outerHeight() - 50 - 34;
      return Math.max(Math.ceil(tbodyHeight / 35) + 1, 20);
    },
    showContactModal(data) {
      this.$refs.contactModal.show(data);
    },
    tableRowClick({ row, column, index, event }) {
      this.currentRowId = row.messageId;
      this.$refs.table.setCurrentRow("messageId", this.currentRowId);
      this.$refs.table.toggleRowSelection(row);
    },
    showContactRecord(chanceData) {
      this.$refs.chanceRecordModal.show(chanceData);
    },
    lazyload(keepCurrentRow = false){
        this.tableLoadingMore = true;
        this.moreData = false;
        if (!keepCurrentRow) {
          this.currentRowId = "";
        }
        let params = this.getParams();
        this.$http.get("notice/message", params).then(res => {
          this.tableLoadingMore = false;
          if (res && res.code === 20000) {
            this.totalItem = res.data.total;
            this.tableData = this.tableData.concat(res.data.records);
            this.$nextTick(() => {
              this.$refs.table.setCurrentRow("messageId", this.currentRowId);
            });
            if (
                res.data.records instanceof Array &&
                res.data.records.length === this.pageSize
              ) {
                this.moreData = true;
              } else {
                this.moreData = false;
              }
          }else{
            let msg = res && res.msg ? res.msg : "数据加载失败，请点击重试";
            this.$message.error(msg);
            this.reloadMore = true;
            this.moreData = true;
          }
        })
    },
    // 表格懒加载
    tableScroll() {
      $(
        ".table-container.message-notice-table-container .el-table__body-wrapper"
      ).on("scroll", () => {
        if (this.moreData) {
          let scrollTop = document.querySelector(
            ".table-container.message-notice-table-container .el-table__body-wrapper"
          ).scrollTop;
          let scrollHeight = document.querySelector(
            ".table-container.message-notice-table-container .el-table__body-wrapper table.el-table__body"
          ).scrollHeight;
          let containerHeight = document.querySelector(
            ".table-container.message-notice-table-container .el-table__body-wrapper"
          ).offsetHeight;
          if (
            scrollTop + containerHeight > scrollHeight - 100 &&
            scrollTop > 0
          ) {
            this.pageNo++;
            this.lazyload(true)
          }
        }
      });
    }
  }
};
</script>
<style lang="less">
.message-notice-table-container{
  span.transfer{
    background: url("../../../../assets/images/message-icon/transfer.png") no-repeat;
    &:hover{
      background: url("../../../../assets/images/message-icon/transfer_hover.png") no-repeat;
    }
  }
  span.agree{
    background: url("../../../../assets/images/message-icon/agree.png") no-repeat;
    &:hover{
      background: url("../../../../assets/images/message-icon/agree_hover.png") no-repeat;
    }
  }
  span.ignore{
    background: url("../../../../assets/images/message-icon/ignore.png") no-repeat;
    &:hover{
      background: url("../../../../assets/images/message-icon/ignore_hover.png") no-repeat;
    }
  }
  span.read{
    background: url("../../../../assets/images/message-icon/read.png") no-repeat;
    &:hover{
      background: url("../../../../assets/images/message-icon/read_hover.png") no-repeat;
    }
  }
  span.refuse{
    background: url("../../../../assets/images/message-icon/refuse.png") no-repeat;
    &:hover{
      background: url("../../../../assets/images/message-icon/refuse_hover.png") no-repeat;
    }
  }
  span.reply{
    background: url("../../../../assets/images/message-icon/reply.png") no-repeat;
    &:hover{
      background: url("../../../../assets/images/message-icon/reply_hover.png") no-repeat;
    }
  }
  span.signup{
    background: url("../../../../assets/images/message-icon/signup.png") no-repeat;
    &:hover{
      background: url("../../../../assets/images/message-icon/signup_hover.png") no-repeat;
    }
  }
  span.button-action{
    display: inline-block;
    width: 18px;
    height: 18px;
    margin-right: 20px;
    background-size: 100% 100% !important;
    cursor: pointer;
  }
}
</style>
