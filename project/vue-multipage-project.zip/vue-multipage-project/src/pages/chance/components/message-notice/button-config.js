function getMessageConfig ({h, row}){
      // 回复
      let reply = h("span", {
        on: {
          click: () => {
            console.log(row);
          },
        },
        class: {
          "reply": true,
          "button-action": true
        },
        attrs: {
          title: "回复"
        }
      });
      // 忽略
      let ignore = h("span", {
        class: {
          "ignore": true,
          "button-action": true
        },
        on: {
          click: () => {
            this.setNoticeRead(row.messageId).then(() => {
              this.search();
            });
          }
        },
        attrs: {
          title: "忽略"
        }
      });
      // 传送门
      let transfer = h("span", {
        class: {
          "transfer": true,
          "button-action": true
        },
        on: {
          click: () => {
            this.setNoticeRead(row.messageId).then(() => {
              // console.log(`${this.$baseUrl[process.env.NODE_ENV]["page"]}${row.noticeLink}?keyWord=${row.noticeKeyword}&id=${row.noticeIndex}`)
              window.open(`${this.$baseUrl[process.env.NODE_ENV]["page"]}${row.noticeLink}?keyWord=${row.noticeKeyword}&id=${row.noticeIndex}`)
              // location.assign(`${this.$baseUrl[process.env.NODE_ENV]["page"]} ${row.noticeLink}?keyWord=${row.noticeKeyword}&id=${row.noticeIndex}`);
            })
          }
        },
        attrs: {
          title: "传送门"
        }
      });
      // 同意
      let agree = h("span", {
        class: {
          "agree": true,
          "button-action": true
        },
        on: {
          click: () => {
            this.setAuthorizeStatus(row.noticeIndex, 2).then((res) => {
              this.setNoticeRead(row.messageId).then(() => {
                this.search();
              });
            })
          }
        },
        attrs: {
          title: "同意"
        }
      });
      // 拒绝
      let refuse = h("span", {
        class: {
          "refuse": true,
          "button-action": true
        },
        on: {
          click: () => {
            console.log("拒绝");
            this.setAuthorizeStatus(row.noticeIndex, 4).then(() => {
              this.setNoticeRead(row.messageId).then(() => {
                this.search();
              });
            });
          }
        },
        attrs: {
          title: "拒绝"
        }
      });
      // 报名
      let signUp = h("span", {
        class: {
          "signup": true,
          "button-action": true
        },
        on: {
          click: () => {
            console.log("报名");
          }
        },
        attrs: {
          title: "报名"
        }
      });
      // 已读
      let read = h("span", {
        class: {
          "read": true,
          "button-action": true
        },
        class: {
            primary: true
        },
        on: {
          click: () => {
            console.log("已阅");
            this.setNoticeRead(row.messageId).then(() => {
              this.search();
            });
          }
        },
        attrs: {
          title: "已读"
        }
      });
      let messageConfig = {
        "101": {
          triggerType: "净值异常",
          buttons: [reply, ignore]
        },
        "102": {
          triggerType: "净值缺失",
          buttons: [transfer]
        },
        "103": {
          triggerType: "基金缺失",
          buttons: [transfer]
        },
        "104": {
          triggerType: "经理缺失",
          buttons: [transfer]
        },
        "105": {
          triggerType: "公司缺失",
          buttons: [transfer]
        },
        "106": {
          triggerType: "授权申请",
          // buttons: [agree, refuse, ignore]
          buttons: [transfer]
        },
        "201": {
          triggerType: "新活动",
          buttons: [signUp, ignore]
        },
        "202": {
          triggerType: "活动参加",
          buttons: [read]
        },
        "301": {
          triggerType: "机会回复",
          buttons: [transfer]
        },
        "302": {
          triggerType: "尽调预约",
          buttons: [agree, refuse, ignore]
        },
      }
      return messageConfig;
};
export default getMessageConfig;