<template>
  <div style="height:100%">
    <vpart title="公司机会列表" class="table-container chance-manager-table-container">
      <div slot="search">
        <vselect v-model="searchForm.chanceType" :options="typeOptions" @change="search"></vselect>
        <vselect v-model="searchForm.unreadMsg" :options="statusOptions" @change="search"></vselect>
        <vinput
          type="text"
          class="table-search-input"
          style="display: inline-block"
          @keyup.enter.native="search"
          v-model="searchForm.topic"
          placeholder="关键字搜索(主题)"
        ></vinput>
        <vbutton
          active
          title="搜索"
          @click="search"
        >搜索</vbutton>
      </div>
      <div slot="action">
        <vbutton
          active
          title="发布机会"
          @click="addChance"
        >发布机会</vbutton>
      </div>
      <vtable
        :key="key"
        ref="table"
        :columns="columns"
        :data="tableData"
        :usePagination="true"
        :totalItem="totalItem"
        layout="total"
        :currentPage="pageNo"
        :rowKey="row => row.id"
        :maxHeight="maxHeight"
        :tableLoadingMore="tableLoadingMore"
        @pageChange="pageChange"
        @pageSizeChange="pageSizeChange"
        @tableRowClick="tableRowClick"
        :reloadMore="reloadMore"
        @reloadMoreData="lazyload(true)"
        style="position: relative"
        :fofHide="fofHide"
      ></vtable>
      <vloading class="loading" v-model="loading"></vloading>
      <vreload v-model="reload" @reload="search"></vreload>
    </vpart>

    <chanceModal ref="chanceModal" @chanceModalSuccess="chanceModalSuccess"></chanceModal>
    <chanceRecordModal ref="chanceRecordModal" @cancel="chanceRecordModalCancel"></chanceRecordModal>
  </div>
</template>

<script>
import chanceModal from "../chance/chance-modal.vue";
import chanceRecordModal from "./contact-record.vue";
import tableHeight from "../../../../common/mixins/table-height.js";
import {getUrlParams} from "../../../../common/js/utils.js";
import _ from "lodash";

export default {
  components: {
    chanceModal,
    chanceRecordModal
  },
  props: {
    fofHide: {
      type: Boolean,
      default: false
    }
  },
  mixins: [tableHeight],
  data() {
    return {
      hasTabs: true,
      currentMenuParentKey: "chance",
      currentMenuChildKey: "chance",
      searchForm: {
        chanceType: 0,
        unreadMsg: -1,
        topic: ""
      },
      typeOptions: [
        {
          value: 0,
          label: "全部类型"
        },
        {
          value: 1,
          label: "资金"
        },
        {
          value: 2,
          label: "人才"
        },
        {
          value: 4,
          label: "投研"
        },
        {
          value: 3,
          label: "系统"
        },
        {
          value: 5,
          label: "活动"
        },
        {
          value: 6,
          label: "招商"
        }
      ],
      statusOptions: [
        { value: -1, label: "全部状态" },
        { value: 1, label: "已读" },
        { value: 0, label: "未读" }
      ],
      tableData: [],
      totalItem: 0,
      pageNo: 1,
      pageSize: 20,
      loading: false,
      reload: false,
      key: null,
      currentUser: {},
      tableLoadingMore: false,
      moreData: true,
      reloadMore: false,
    };
  },
  computed: {
    columns() {
      let columns = [
        {
          key: "chanceType",
          title: "类型",
          width: 52,
          showOverflowTooltip: false,
          render: (h, { row }) => {
            let titleMap = {
              1: "资金",
              2: "人才",
              3: "系统",
              4: "投研",
              5: "活动",
              6: "招商"
            };
            let bgPositionMap = {
              1: "-32px 0",
              2: "-0 0",
              3: "-64px 0",
              4: "-96px 0",
              5: "-128px 0",
              6: "-160px 0"
            };
            return h("span", {
              style: {
                display: "block",
                width: "32px",
                height: "22px",
                lineHeight: "34px",
                display: "block",
                textAlign: "center",
                backgroundImage: `url(${
                  this.$baseUrl[process.env.NODE_ENV]["page"]
                }/assets/images/sprite-chance.png)`,
                backgroundPosition: bgPositionMap[row.chanceType]
              }
            });
          }
        },
        {
          key: "topic",
          title: "主题",
          showOverflowTooltip: false,
          render: (h, { row }) => {
            let outOfDate = false;
            if (row.chanceStatus === 2) {
              outOfDate = true;
            }
            let outOfDateDomString =
              '<span style="float: left">[已过期]</span>';

            return h(
              "div",
              {
                style: {
                  width: "100%",
                  height: "100%",
                  position: "relative"
                }
              },
              [
                h("span", {
                  style: {
                    display: "block",
                    width: "100%",
                    color: "#999",
                    fontWeight: "normal",
                    maxHeight: "120px",
                    lineHeight: "2",
                    overflow: "hidden"
                  },
                  domProps: {
                    innerHTML: outOfDate
                      ? `${outOfDateDomString}${row.topic}`
                      : row.topic
                  }
                })
              ]
            );
          }
        },
        {
          key: "endTime",
          title: "有效时间",
          width: "130",
          sortKey: "end_time",
          // sortable: true,
          render: (h, { row }) => {
            let outOfDate = false;
            let endTime = row.endTime;
            if (endTime) {
              endTime = endTime.split(" ")[0];
              outOfDate = new Date(endTime) < new Date();
            } else {
              endTime = "";
            }
            if (endTime === "0000-00-00") {
              endTime = "";
            }
            return h(
              "span",
              {
                style: {
                  marginRight: "2px"
                }
              },
              endTime || "--"
            );
          }
        },
        {
          key: "managerName",
          title: "业务负责人",
          width: 100
        },
        {
          key: "createtime",
          title: "发布时间",
          width: 100,
          render: (h, { row }) => {
            let date = row.createtime.split(" ")[0];
            if (date === "0000-00-00") {
              date = "--";
            }
            return h(
              "span",
              {
                style: {
                  color: !row.isRead ? "rgb(206, 206, 206)" : "#999"
                }
              },
              date
            );
          }
        },
        {
          key: "action",
          title: "操作",
          width: 134,
          align: "center",
          showOverflowTooltip: false,
          render: (h, { row }) => {
            return h(
              "div",
              {
                class: 'table-action-button-container'
              },
              [
                h(
                  "div",
                  {
                    style: {
                      display: "inline-block",
                      marginRight: "20px",
                      position: "relative"
                    }
                  },
                  [
                    h("vbuttonSprite", {
                      props: {
                        pos:
                          row.contactMsg > 0
                            ? {
                                normal: { x: 0, y: -314 },
                                hover: { x: -18, y: -314 },
                                disabled: { x: -36, y: -314 }
                              }
                            : {
                                normal: { x: 0, y: -332 },
                                hover: { x: -18, y: -332 },
                                disabled: { x: -36, y: -332 }
                              },
                        title: row.contactMsg > 0 ? "查看留言" : "暂无留言"
                      },
                      style: {
                        verticalAlign: "middle"
                      },
                      on: {
                        click: e => {
                          this.showContactRecord(row);
                        }
                      }
                    }),
                    row.contactMsg > 0 && row.unreadMsg > 0
                      ? h(
                          "span",
                          {
                            style: {
                              position: "absolute",
                              top: "0",
                              right: "-8px",
                              display: "block",
                              width: "18px",
                              height: "18px",
                              lineHeight: "18px",
                              textAlign: "center",
                              backgroundColor: "#FF4455",
                              color: "#fff !important",
                              borderRadius: "50%",
                              transformOrigin: "center",
                              transform: "scale(0.75)"
                            }
                          },
                          row.unreadMsg > 99 ? 99 : row.unreadMsg
                        )
                      : ""
                  ]
                ),
                h("vbuttonSprite", {
                  props: {
                    pos: {
                      normal: { x: 0, y: -19 },
                      hover: { x: -18, y: -19 },
                      disabled: { x: -36, y: -19 }
                    },
                    title: "编辑",
                    // disabled: !row.isManager
                    disabled: this.isAdmin() ? false : !row.isManager
                  },
                  style: {
                    verticalAlign: "middle",
                    marginRight: "20px"
                  },
                  on: {
                    click: e => {
                      this.editChance(row);
                    }
                  }
                }),
                //删除
                h("vbuttonSprite", {
                  props: {
                    pos: {
                      normal: { x: 0, y: -241 },
                      hover: { x: -18, y: -241 },
                      disabled: { x: -36, y: -241 }
                    },
                    title: "删除",
                    // disabled: !row.isManager
                    disabled: this.isAdmin() ? false : !row.isManager
                  },
                  style: {
                    verticalAlign: "middle"
                  },
                  on: {
                    click: e => {
                      this.deleteChance(row);
                    }
                  }
                })
              ]
            );
          }
        }
      ];
      if (this.isPpwAdmin()) {
        columns.splice(2, 0, {
          key: "companyName",
          title: "发布机构",
          width: "220"
        });
      }
      return columns;
    }
  },
  mounted() {
    this.getCurrentUserInfo();
    let params = getUrlParams();
    if(params.keyWord){
      this.searchForm.chanceType = 0;
      this.searchForm.unreadMsg = -1;
      this.searchForm.topic = decodeURI(params.keyWord);
      this.currentRowId = +params.id;
      this.search().then(() => {
        let row = this.tableData.filter((row) => {
          return row.id = this.currentRowId;
        })[0]
        this.showContactRecord(row);
        // this.$refs.table.setCurrentRow("id", this.currentRowId);
      });
    }
  },
  methods: {
    //判断当前用户是否为排排网管理员
    isPpwAdmin() {
      let currentUser = this.getCurrentUserInfo();
      //排排网公司ID CO000000FD， isAmin为1表示是公司管理员
      return (
        currentUser.companyId === "CO000000FD" && currentUser.isAdmin === 1
      );
    },
    isAdmin(){
      let currentUser = this.getCurrentUserInfo();
      return currentUser.isAdmin === 1;
    },
    getCurrentUserInfo() {
      let currentUser = JSON.parse(
        localStorage.getItem("fund_master_current_user")
      );
      this.currentUser = currentUser;
      return currentUser;
    },
    search() {
      this.reloadMore = false;
      return new Promise(resolve => {
        this.pageNo = 1;
        this.loading = true;
        this.getChanceData().then(() => {
          this.loading = false;
          this.$refs.table.refresh();
          setTimeout(() => {
            this.tableScroll();
          }, 100);
          resolve();
        });
      });
    },
    getChanceData() {
      return new Promise((resolve, reject) => {
        this.pageSize = this.getPageSize();
        let params = this.getParams();

        this.$http.get("myChance", params).then(res => {
          if (res && res.code === 20000) {
            this.totalItem = res.data.total;
            let records = this.getRecords(res.data.records);
            this.tableData = records;
            this.$nextTick(() => {
              console.log(this.currentRowId)
              this.$refs.table.setCurrentRow("id", this.currentRowId);
            });
            if(records.length == this.pagesize){
              this.moreData = true;
            }
          }else{
            let msg = res && res.msg ? res.msg : "数据加载失败，请点击重试";
            this.$message.error(msg);
            this.reload = true;
            this.tableData = [];
          }
          resolve(res);
        });
      });
    },
    // 处理tableData
    getRecords(resRecords=[]){
      let records = resRecords.map((item) => {
        item.companyName = item.bread.map((orgInfo) => {
          return orgInfo.title;
        }).join(">");
        return item;
      })
      return records;
    },
    refresh() {
      // this.key = Date.now();
      this.search();
    },
    pageChange() {},
    pageSizeChange() {},
    getParams(){
      let params = {
        pageNo: this.pageNo,
        pageSize: this.pageSize,
        isAdmin: this.isPpwAdmin() ? 1 : 0
      };
      for (let key in this.searchForm) {
        params[key] = this.searchForm[key];
      }
      return params;
    },
    // 根据页面的高度，计算出懒加载的 table 需要加载多少行才能使得 table 滚动，否则固定的 pageSize 导致屏幕较大的用户 table 不能滚动，就无法触发懒加载
    // 50 是页脚的高度， 34 是表头的高度， 35 是表格一行的高度, pageSize 取计算出来的数值和 20 两者的较大值。
    getPageSize(){
      let tbodyHeight = $(".chance-page-content").innerHeight() - $(".chance-page-content .el-tabs__header.is-top").outerHeight() - $(".chance-page-content .part-header").outerHeight() - 50 - 34;
      return Math.max(Math.ceil(tbodyHeight / 35) + 1, 20);
    },
    showContactModal(data) {
      this.$refs.contactModal.show(data);
    },
    tableRowClick({ row, column, index, event }) {
      this.currentRowId = row.id;
      this.$refs.table.setCurrentRow("id", this.currentRowId);
      this.$refs.table.toggleRowSelection(row);
    },
    addChance() {
      this.$refs.chanceModal.show();
    },
    editChance(chanceData) {
      let chanceId = chanceData.id;
      this.$refs.chanceModal.show(chanceId);
    },
    deleteChance(chanceData) {
      this.currentRowId = chanceData.id;
      this.$confirm(`确认删除吗？`, "删除", {
        showCancelButton: true,
        type: "warning",
        dangerouslyUseHTMLString: true,
        closeOnClickModal: false,
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            instance.confirmButtonLoading = true;
            instance.confirmButtonText = "删除中...";
            this.$http.del("chance", chanceData.id).then(res => {
              done();
              instance.confirmButtonLoading = false;
              if (!res) return;
              if (res.code == 20000) {
                this.getChanceData();
                this.$message({
                  showClose: true,
                  message: "删除成功",
                  type: "success"
                });
              } else {
                this.$message({
                  showClose: true,
                  message: "删除失败",
                  type: "error"
                });
              }
            });
          } else {
            done();
          }
        }
      });
    },
    chanceModalSuccess() {
      this.search();
    },
    showContactRecord(chanceData) {
      this.$refs.chanceRecordModal.show(chanceData);
    },
    chanceRecordModalCancel(chanceId) {
      // this.getChanceData(true);

      //单独处理该条机会的未读数，避免表格刷新
      this.$http.get("myChance", { id: chanceId }).then(res => {
        if (res.code === 20000) {
          //获取该条机会的索引，用户后续更新
          let index = _.findIndex(this.tableData, item => {
            return item.id === chanceId;
          });
          this.tableData[index]["unreadMsg"] = res.data.records[0]["unreadMsg"];
        }
      });
    },
    lazyload(keepCurrentRow = false){
        this.tableLoadingMore = true;
        this.moreData = false;
        if (!keepCurrentRow) {
          this.currentRowId = "";
        }
        let params = this.getParams();
        this.$http.get("myChance", params).then(res => {
          this.tableLoadingMore = false;
          if (res && res.code === 20000) {
            this.totalItem = res.data.total;
            let records = this.getRecords(res.data.records);
            this.tableData = this.tableData.concat(records);
            this.$nextTick(() => {
              this.$refs.table.setCurrentRow("id", this.currentRowId);
            });
            if (
                res.data.records instanceof Array &&
                res.data.records.length === this.pageSize
              ) {
                this.moreData = true;
              } else {
                this.moreData = false;
              }
          }else{
            let msg = res && res.msg ? res.msg : "数据加载失败，请点击重试";
            this.$message.error(msg);
            this.reloadMore = true;
            this.moreData = true;
          }
        })
    },
    // 表格懒加载
    tableScroll() {
      $(
        ".table-container.chance-manager-table-container .el-table__body-wrapper"
      ).on("scroll", () => {
        if (this.moreData) {
          let scrollTop = document.querySelector(
            ".table-container.chance-manager-table-container .el-table__body-wrapper"
          ).scrollTop;
          let scrollHeight = document.querySelector(
            ".table-container.chance-manager-table-container .el-table__body-wrapper table.el-table__body"
          ).scrollHeight;
          let containerHeight = document.querySelector(
            ".table-container.chance-manager-table-container .el-table__body-wrapper"
          ).offsetHeight;
          if (
            scrollTop + containerHeight > scrollHeight - 100 &&
            scrollTop > 0
          ) {
            this.pageNo++;
            this.lazyload(true)
          }
        }
      });
    }
  }
};
</script>
<style lang="less">
.chance-wrapper {
  position: relative;
  user-select: none;
  a {
    &:hover {
      text-decoration: underline;
    }
  }
}
// .el-table--border .el-table__expanded-cell {
//   border-right: none;
// }
// .expand-container {
//   min-height: 140px;
//   max-height: 220px;
//   background-color: #202020;
//   border-bottom: 1px solid #000;
// }

.selection-action-container {
  display: inline-block;
  width: auto;
  position: fixed;
  top: 0;
  left: 0;
  background-color: #222;
  border: 1px solid rgb(85, 85, 85);
  .selection-action-item {
    display: block;
    font-size: 12px;
    width: 98px;
    padding-left: 10px;
    line-height: 30px;
    color: #999;
    cursor: pointer;
    &:hover {
      background-color: #345;
      color: #aaa;
    }
  }
}
</style>
