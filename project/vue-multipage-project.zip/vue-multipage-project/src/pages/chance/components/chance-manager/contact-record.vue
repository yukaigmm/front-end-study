<template>
  <vmodal
    ref="chanceRecordModal"
    class="chance-record-modal t2-el-dialog"
    title="留言列表"
    @close="cancel"
    :width="700"
  >
    <div style="padding: 20px 10px 0;">
      <div class="topic-container cl">
        <span class="topic-title">主题：</span>
        <span v-html="chanceData.topic" class="topic-content"></span>
      </div>

      <div class="table-container" style="position: relative;">
        <vtable
          ref="table"
          :columns="columns"
          :data="tableData"
          :usePagination="true"
          :totalItem="totalItem"
          :currentPage="pageNo"
          :pageSize="pageSize"
          :rowKey="row => row.userId"
          :expandRowKeys="expandRowKeys"
          @pageChange="pageChange"
          @pageSizeChange="pageSizeChange"
          @tableRowClick="tableRowClick"
          :fofHide="fofHide"
        ></vtable>
        <vloading v-model="loading"></vloading>
      </div>

      <span
        style="color: rgb(102, 102, 102);line-height:34px;font-size: 12px;"
      >注：若留言机构没有联系方式，您可联系私募排排网邮箱为您服务fm@simuwang.com</span>
    </div>

    <div slot="modal-footer">
      <vbutton active @click="cancel">关闭</vbutton>
    </div>
  </vmodal>
</template>

<script>
import tableHeight from "../../../../common/mixins/table-height.js";

export default {
  props: {
    fofHide: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      tableData: [],
      totalItem: 0,
      pageNo: 1,
      pageSize: 10,
      chanceData: "",
      loading: false,
      currentUser: {},
      expandRowKeys: []
    };
  },
  computed: {
    columns() {
      let columns = [
        {
          key: "expand",
          type: "expand",
          width: 30,
          render: (h, { row }) => {
            return h(
              "div",
              {
                class: "expand-container"
              },
              [
                h("chance-detail", {
                  props: {
                    chanceId: row.chanceId,
                    userId: row.userId,
                    isManager: this.chanceData.isManager,
                    type: "inner"
                  }
                })
              ]
            );
          }
        },
        {
          key: "authorName",
          title: "留言用户",
          width: 120
        },
        {
          key: "companyName",
          title: "留言机构"
        },
        {
          key: "lastTime",
          title: "最新留言时间",
          width: 100,
          align: "right",
          render: (h, { row }) => {
            let time = row.lastTime.split(" ")[0];
            return h("span", time);
          }
        },
        {
          key: "action",
          title: "操作",
          align: "center",
          showOverflowTooltip: false,
          width: 80,
          render: (h, { row }) => {
            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                h(
                  "div",
                  {
                    style: {
                      display: "inline-block",
                      marginRight: "20px",
                      position: "relative"
                    }
                  },
                  [
                    h("vbuttonSprite", {
                      props: {
                        pos: {
                          normal: { x: 0, y: -332 },
                          hover: { x: -18, y: -332 },
                          disabled: { x: -36, y: -332 }
                        },
                        title: "查看留言详情"
                      },
                      style: {
                        verticalAlign: "middle"
                      },
                      on: {
                        click: e => {
                          // this.showContactRecord(row);
                          // this.showDetail(row);
                        }
                      }
                    }),
                    row.notRead > 0 && row.notRead > 0
                      ? h(
                          "span",
                          {
                            style: {
                              position: "absolute",
                              top: "0",
                              right: "-8px",
                              display: "block",
                              width: "18px",
                              height: "18px",
                              lineHeight: "18px",
                              textAlign: "center",
                              backgroundColor: "#FF4455",
                              color: "#fff",
                              borderRadius: "50%",
                              transformOrigin: "center",
                              transform: "scale(0.75)"
                            }
                          },
                          row.notRead > 99 ? 99 : row.notRead
                        )
                      : ""
                  ]
                )
              ]
            );
          }
        }
      ];
      if (this.isPpwAdmin()) {
        columns.splice(3, 0, {
          key: "authorMobile",
          title: "联系电话",
          width: "110"
        });
      }
      return columns;
    }
  },
  mounted() {
    this.getCurrentUserInfo();
  },
  methods: {
    showDetail(data) {
      let index = this.expandRowKeys.indexOf(data.userId);
      if (index === -1) {
        this.expandRowKeys.push(data.userId);
      } else {
        this.expandRowKeys.splice(index, 1);
      }
    },
    //判断当前用户是否为排排网管理员
    isPpwAdmin() {
      let currentUser = this.getCurrentUserInfo();
      //排排网公司ID CO000000FD， isAmin为1表示是公司管理员
      return (
        currentUser.companyId === "CO000000FD" && currentUser.isAdmin === 1
      );
    },
    getCurrentUserInfo() {
      let currentUser = JSON.parse(
        localStorage.getItem("fund_master_current_user")
      );
      this.currentUser = currentUser;
      return currentUser;
    },
    show(chanceData) {
      this.$refs.chanceRecordModal.open();
      this.chanceData = chanceData;
      this.expandRowKeys = [];

      this.getContactRecordList();

      // setTimeout( () => {
      //   this.setTabelHeight();
      // }, 100)
    },
    hide() {
      this.$refs.chanceRecordModal.close();
    },
    cancel() {
      this.hide();
      this.$emit("cancel", this.chanceData.id);
    },
    getContactRecordList() {
      let params = {
        pageNo: this.pageNo,
        pageSize: this.pageSize
      };
      this.loading = true;
      this.$http.get(`chance/user/${this.chanceData.id}`, params).then(
        res => {
          this.loading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.totalItem = res.data.total;
          }
        },
        err => {
          this.loading = false;
          this.tableData = [];
          this.totalItem = 0;
        }
      );
    },
    // 分页器变化
    pageSizeChange(val) {
      this.pageSize = val;
      this.getContactRecordList();
    },
    pageChange(val) {
      this.pageNo = val;
      this.getContactRecordList();
    },
    tableRowClick({ row }) {
      //如果留言为未读，则设为已读
      // if (!row.isRead) {
      //   this.$http.post(`handle/chance/msg/${row.id}`, {
      //     id: row.id,
      //     chanceId: this.chanceData.id,
      //     isRead: 1
      //   }).then( (res) => {
      //     if(!res)return;
      //     if (res.code === 20000) {
      //       row.isRead = 1;
      //     }
      //   })
      // }

      this.currentRowId = row.userId;
      this.$refs.table.setCurrentRow("userId", this.currentRowId);

      this.showDetail(row);

      // //监听机会留言改动事件
      // let params = {
      //   pageNo: 1,
      //   pageSize: -1,
      // };
      // this.$http.get(`handle/chance/${this.chanceData.id}`, params).then( (res) => {
      //   if (res.code === 20000) {
      //     let data = res.data.records;
      //     let totalCount = res.data.total
      //     let chanceId = this.chanceData.id;
      //     let readCount = data.filter( (item) => {
      //       return item.isRead === 1;
      //     })
      //     let unreadCount = data.filter( (item) => {
      //       return item.isRead === 0;
      //     })
      //     sa.event('fundMaster_chanceRecordAction', {chanceId, totalCount, readCount, unreadCount});
      //   }
      // })
    }
  }
};
</script>

<style lang="less" scoped>
.topic-container {
  margin-bottom: 10px;
  .topic-title {
    font-weight: bold;
    float: left;
    margin-left: 6px;
  }
  .topic-content {
    float: left;
    width: calc(~"100% - 66px");
  }
}
</style>

