
import App from './app.vue';
import ErrorApp from './error.vue';

import { setOptionsMap, userInfoValidate, getUrlParams } from '../../common/js/utils'; 
import api from '../../common/js/api';

import '../../common/js/common';
import '../../common/js/comp';

import chanceDetail from '../../pages/chance/components/chance/chance-detail.vue';
Vue.component('chanceDetail', chanceDetail);

const createApp = () => {
  new Vue({
    el: '#app',
    render: h => h(App)
  })
}

const createErrorApp = () => {
  new Vue({
    el: '#app',
    render: h => h(ErrorApp)
  })
}

let params = getUrlParams();

/*
  fof=1 表示组合大师嵌入, 不需要先判断用户是否登陆。
  默认调用初始化接口进行组合大师账号绑定。绑定成功后渲染机会页面
*/
if (params.fof === '1') {
  api.get('user/initMasterUser').then( (res) => {
    if (res.code === 20000) {
      
      //储存用户信息
      let user = {
        userName: res.data.username,
        trueName: res.data.trueName,
        changeAble: res.data.changeAble,
        changeLevel: res.data.changeLevel,
        isAdmin: res.data.isAdmin,
        isVirtual: res.data.isVirtual,
        companyId: res.data.companyId,
        companyName: res.data.companyName,
        userId: res.data.userId,
        userCompanyApplicationIds: res.data.userCompanyApplicationIds,
        userPermission: res.data.userPermission,
      };
      localStorage.setItem('fund_master_origin_user', JSON.stringify(user))
      localStorage.setItem('fund_master_current_user', JSON.stringify(user))

      createApp();
    } else {
      createErrorApp();
    }
  })
} else {
  userInfoValidate().then( () => {
    setOptionsMap().then( () => {
      createApp()
    })
  })
}





