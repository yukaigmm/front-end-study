<template>
	<vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
		<div slot style="height: 100%;width: 100%;background-color: #1a1a1a;position: relative;">
			<div class="iframe-container" v-if="!noFund">
				<iframe ref="iframe" slot class="iframe" :src="iframeSrc" frameborder="0"></iframe>
				<vloading v-model="loading"></vloading>
			</div>
		</div>
	</vcommon>
</template>

<script>
import pageView from '../../../common/mixins/pageView';
import { getUrlParams } from '../../../common/js/utils';
export default {
  mixins: [pageView],
  data() {
    return {
      currentMenuParentKey: "customerInfoManager",
      currentMenuChildKey: "aboutUs",
      loading: false,
    };
  },
  computed: {
    iframeSrc() {
      return `${
        this.$baseUrl[process.env.NODE_ENV]["starManager"]
      }/About/index.html?fm=1`;
    }
  },
  methods: {
 
  },
  mounted() {
  },
  watch: {
  }
};
</script>

<style lang="less" scoped>
.iframe-container {
  position: relative;
  width: 100%;
  height: 100%;
   background-color: #1a1a1a;
  .iframe {
    width: 100%;
    height: 100%;
    html,
    body {
      margin: 0;
      padding: 0;
    }
  }
}
</style>
