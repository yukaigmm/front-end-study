<template>
  <div id="app" class="export-total-container" style="width: 1400px">
    <div class="page-container export-page">
        <div class="page" style="height: 1980px">
          <div class="page-header" style="height: 100px"></div>
          <div class="page-content" style="height: 1825px">
            <div class="page-title">
              <span class="company-title">获客报表（{{companyName}}）</span>
              <span class="user-info">亲爱的{{userName}}，贵司已入驻直营店{{joinDate}}天，获客辛苦了，请查阅成果</span>
              <span class="period">统计周期：按{{periodMap[periodType]}}（{{`${this.startDate}~${this.endDate}`}}）</span>
            </div>
            <div 
            class="tab-item" 
            v-for="(item, index) in tabConfig"
            :key="index"
            >
              <div class="tab-title">
                <span class="tab-name">{{item.title}}</span>
              </div>
              <div class="tab-content">
                <component 
                :is="item.comp"
                :startDate="startDate"
                :endDate="endDate"
                :periodType="periodType"
                :exportStatus="true"
                :exportChartConfig="exportChartConfig"
                :ref="item.comp"
                ></component>
              </div>
            </div>
          </div>
          <div class="export-page-footer" style="height: 50px">
            <span class="fl">数据来源：基金大师</span>
            <span class="fr">第1页</span>
          </div>
      </div>
    </div>
  </div>
</template>

<script>
import moment from "moment";
import customerData from "../weekly/components/customer-data.vue";
import searchData from "../weekly/components/search-data.vue";
import compareData from "../weekly/components/compare-data.vue";
import {getUrlParams} from "../../../common/js/utils.js";
import {element} from "./1.json"
export default {
  components: {
    customerData,
    searchData,
    compareData,
  },
  computed: {
    
  },
  data() {
    return {
      tabConfig: [
        {
          title: "客户数据统计",
          comp: "customerData",
        },
        {
          title: "搜索查看统计",
          comp: "searchData",
        },
        // {
        //   title: "市场同行水平",
        //   comp: "compareData",
        // },
      ],
      customerTableData: [],
      customerGraphData: [],
      compareGraphData: [],
      startDate: "",
      endDate: "",
      joinDate: "",
      userName: "",
      companyName: "",
      periodType: "week",
      periodMap: {
        "week": "周",
        "month": "月",
      },
      userId: "",
      fileKey: "",
      exportChartConfig: {
        exportCommonConfig: {
          gridLineColor: "#d8d8d8",
          lineColor: "#d8d8d8",
          tickColor: "#d8d8d8",
          alternateGridColor: "#fff",
          labelStyle: {
            color: "#555"
          }
        },
        exportTitleStyle: {
          color: "#555"
        }
      },
    }
  },
  methods: {
    getMetaData(){
      let params = getUrlParams();
      let {userId, fileKey} = params;
      this.userId = userId;
      this.fileKey = fileKey;
      this.$http.get(`${this.$baseUrl[process.env.NODE_ENV]["host"]}/expapi/fm/getMetaData/${userId}/${fileKey}`).then(res => {
        if(res && res.success == true){
          try{
            let data = res.data;
            // let data = element.storeData;
            let {
              customerTableData = [],
              customerGraphData = [],
              compareGraphData = [],
              searchTableData = [],
              viewDetailGraphData = [],
              customerSearchData = {},
              viewProductData = {}
            } = data;
            this.startDate = data.startDate;
            this.endDate = data.endDate;
            this.joinDate = data.joinDate;
            this.userName = data.userName;
            this.companyName = data.companyName;
            this.periodType = data.periodType;
            this.$nextTick(()=> {
              this.$refs['customerData'][0].updateTable(customerTableData);
              this.$refs['customerData'][0].updateGraph(customerGraphData);
              // this.$refs['compareData'][0].updateGraph(compareGraphData);
              this.$refs['searchData'][0].updateTable(searchTableData);
              this.$refs['searchData'][0].updateGraph("viewDetailGraph",viewDetailGraphData);
              this.$refs['searchData'][0].updateSeriesAndData("customerSearchGraph",customerSearchData);
              this.$refs['searchData'][0].updateSeriesAndData("viewProductGraph",viewProductData);
              this.setHeaderAndFooter();
              setTimeout(() => {
                window.status="rendered"
              }, 1000);
            })
          }catch(error){
            window.status = "rendered"
          }
        }else{
          this.setHeaderAndFooter();
          setTimeout(() => {
            window.status="rendered"
          }, 1000);
        }
      })
    },
    setHeaderAndFooter(){
      let pageHeight = 0; // 当前页面的累计高度
      let pageMaxHeight; // 页面的最大高度
      let pageIndex = 0; // 当前页面的 index
      let pageItem = $($(".page")[0]); // 当前页面
      $(".export-item").each((index, el) => {
        // 第一页多了一个获客报表的标题，高度40px
        if(pageIndex === 0){
          pageMaxHeight = 1750;
        }else{
          pageMaxHeight = 1790;
        }
        // 如果当前模块是每个tab的第一个，那么叠加模块高度的时候就要加上tab的标题高度
        // outerHeight 包括元素的margin
        let blockHeight; // 当前模块的高度
        let isTabFirstBlock = !$(el).prev().hasClass("export-item");
        if(isTabFirstBlock){
          blockHeight = $(el).outerHeight(true) + $(el).parents(".tab-item").find(".tab-title").outerHeight(true);
        }else{
          blockHeight = $(el).outerHeight(true);
        }
        pageHeight += blockHeight;

        // 当模块叠加高度超过页面最大高度时，新建一个页面，并插入当前模块，重置当前页面高度
        if(pageHeight > pageMaxHeight) {
          pageIndex++;
          pageItem = $(`
          <div class='page' style="height: 1980px">
            <div class='page-header' style="height: 100px"></div>
            <div class='page-content' style="height: 1825px"></div>
            <div class='export-page-footer cl' style="height: 50px">
              <span class="fl">数据来源：基金大师</span>
              <span class="fr">第${pageIndex + 1}页</span>
            </div>
          </div>
          `).appendTo($(".export-page"));
          pageHeight = blockHeight;
          // 如果是一个tab的第一个模块，那就带上这个tab的整体结构，否则直接放到页面内容中
          if(isTabFirstBlock){
            $(el).parents(".tab-item").appendTo(pageItem.find(".page-content"));
          }else{
            $(el).appendTo(pageItem.find(".page-content"));
          }
        }else{
          if(isTabFirstBlock){
            $(el).parents(".tab-item").appendTo(pageItem.find(".page-content"));
          }
        }
      })
    },
  },
  mounted() {
   this.getMetaData();
   setTimeout(() => {
     window.status = "rendered"
   }, 180000);
  // window.status = "rendered";
  // console.log($("link").length)
  // $("link").eq(1).remove()
  },
  created() {
    
  },
};
</script>
<style lang="less" >
  .export-total-container{
    margin: 0 auto;
      .customer-data-container .company-inner-data .el-table{
      tbody{
        tr:nth-child(1){
          background-color: #d9e9f9;
        }
      }
    }
    .fix-width-label{
      display: block;
      width: 150px;
      text-align: right;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }
    .empty-data{
      margin-top: 30px;
      background-color: #fff;
      height: calc(~"100% - 30px");
      .empty-data-content{
        position: absolute;
        left: 50%;
        top: 50%;
        color: #999;
        transform: translate(-50%, -50%);
      }
    }
  }
  .page-container.export-page{
    background-color: #fff;
    color: #555;
    .page{
      height: 1980px;
      // position: relative;
      .page-header{
        height: 100px;
        background: url("../../../assets/images/logo-fm.png") no-repeat;
        background-position: 32px 15px;
        border-bottom: 2px solid #DD2222;
      }
      .page-content{
        padding: 20px 32px;
        overflow: hidden;
        .page-title{
          height: 40px;
          line-height: 40px;
          padding: 0 10px ;
          background-color: #1177CC;
          color: #fff;
          font-size: 16px;
          .company-title{
            font-size: 20px;
            margin-right: 20px;
          }
          .period{
            float: right;
          }
        }
        .tab-item{
          padding: 10px 0;
          .tab-title{
            border-bottom: 1px solid #1166AA;
          }
          .tab-name{
            display: inline-block;
            border-radius: 2px 2px 0 0;
            padding: 0 10px;
            height: 40px;
            line-height: 40px;
            text-align: center;
            font-size: 20px;
            color: #eee;
            background-color: #1177CC;
            box-shadow: 0px 1px 0px 0px rgba(119, 255, 186, 0.35);
          }
          .tab-content{
            padding:2px;
            border: 1px solid #ccc;
            border-top: none;
          }
        }
      }
    }
    // 页脚
    .export-page-footer{
      height: 50px;
      line-height: 50px;
      border-top: 2px solid #dd2222;
      padding: 0 32px;
      span{
        color: #000;
        font-size: 16px;
      }
    }
    // 客户数据统计
    .customer-data-container{
      padding-top: 10px;
      .company-inner-data{
        margin: 0;
      }
      .customer-data-graph-container{
        .duration-data{
          height: 375px;
        }
      }
      .inner-data-title{
        color: #555;
      }
    }
    // 搜索查看统计
    .search-data-container{
      padding-top: 10px;
      background-color: #fff;
      .view-details{
        margin: 0;
      }
      .view-table,.view-graph,.customer-search-container,.view-product{
        background-color: #fff;
      }
      .customer-search-container, .view-table{
        border-right: 1px solid #d8d8d8;
      }
      .customer-search-container, .view-product{
        border-top: 1px solid #d8d8d8;
      }
      .search-details{
        height: 300px;
      }
      #customerSearch,#viewProduct{
        height: 290px;
      }
    }
    // 同行水平
    .compare-graph{
      height: 520px;
    }
    .el-table{
      border-top-color: #d8d8d8;
      background-color: #fff;
      td,th.is-leaf{
        border-color: #d8d8d8;
        color: #555;
        div.cell{
          color: #555;
        }
      }
      th{
        background-color: #E5E5E5;
        div.cell{
          color: #111 !important;
        }
      }
      tr{
        &:nth-child(2n){
          background-color: #fafafa;
        }
        &:nth-child(2n+1){
          background: #fff;
        }
      }
      .el-table__empty-block{
        background-color: #fff;
        .el-table__empty-text{
          color: #555;
        }
      }
    }
  }
</style>