<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
    <div slot style="height:100%" class="index-container-wrapper">
      <vpart title="产品货架">
        <div slot="search">
          <vinput
            type="text"
            class="table-search-input"
            style="display: inline-block"
            @keyup.enter.native="searchFund"
            v-model="searchFormValue.keyWord"
            placeholder="关键字搜索(基金ID/全称/简称/管理人)"
          ></vinput>
          <vbutton active title="搜索" @click="searchFund">搜索</vbutton>
        </div>

        <div slot="action">
          <vbutton title="停用" :disabled="ifAbandonDisable" active @click="abandon">停用</vbutton>
          <vbutton title="发布" :disabled="ifPublishDisable" active @click="publish">发布</vbutton>
          <vbutton active title="添加产品" @click="addFund">添加产品</vbutton>
        </div>

        <vtable
          class="not-show-expand-icon-table"
          ref="table"
          :columns="columns"
          :data="tableData"
          :totalItem="totalItem"
          layout="total"
          :maxHeight="maxHeight"
          :draggable="true"
          usePagination
          :rowKey="row => row.fundId"
          :expandRowKeys="expandRowKeys"
          :dragTitleExplains="['拖动该列图标可进行排序', '当无搜索排序或者过滤条件时才可拖动']"
          @sortChange="sortChange"
          @expandChange="tableRowClick"
          @tableRowClick="tableRowClick"
          @sort="dragSort"
          :changeRowColor="true"
        ></vtable>
        <vloading v-model="tableLoading" :title="loadingTitle" class="loading"></vloading>
        <vreload v-model="reload" @reload="getFundList"></vreload>
      </vpart>
    </div>

    <add-product-modal ref="addProductModal" @refreshTable="getFundList" />
  </vcommon>
</template> 

<script>
import columns from "./js/columns";
import tableHeight from "../../../common/mixins/table-height.js";
import AddProductModal from "./components/add-product-modal";
export default {
  mixins: [tableHeight],

  components: {
    AddProductModal
  },

  computed: {
    columns() {
      return columns.call(this);
    }
  },

  data() {
    return {
      expandRowKeys: [],
      ifAbandonDisable: false,
      ifPublishDisable: false,
      currentMenuParentKey: "directSale",
      currentMenuChildKey: "productList",
      searchFormValue: {
        pageSize: -1,
        keyWord: ""
      },
      retChildrenConfigArray: [
        { title: "近一月", key: "retOneMonth" },
        { title: "近三月", key: "retThreeMonth" },
        { title: "近半年", key: "retSixMonth" },
        { title: "近一年", key: "retOneYear" }
      ],
      tableData: [],
      currentRowId: "",
      tableLoading: false,
      loadingTitle: "数据加载中...",
      totalItem: 0,
      reload: false,
      selfAddFundType: []
    };
  },

  mounted() {
    this.getFundType().then(() => {
      this.getFundList();
    });
  },

  methods: {
    setAsRepresentProduct(row) {
      let type = row.representative == "1" ? 2 : 1;
      row.representative = type;
      this.$refs.table.refresh();
      let params = {
        representative: type
      };
      this.$http
        .putWithoutId(`datadis/display/fund/${row.fundId}`, params)
        .then(res => {
          if (res.code === 20000) {
            row.representative = type;
            this.$message.success("设置成功！");
            this.$refs.table.refresh();
          } else {
            this.$message.error(`${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.$message.error("设置失败！");
        });
    },

    abandon() {
      this.ifAbandonDisable = true;
      this.abandonOrPublishFunds("2");
    },

    publish() {
      this.ifPublishDisable = true;
      this.abandonOrPublishFunds("1");
    },

    abandonOrPublishFunds(status) {
      let params = {
        status
      };

      let msg = status && status == 1 ? "发布成功" : "已停用";

      this.$http.post("datadis/display/status", params).then(res => {
        this.ifPublishDisable = false;
        this.ifAbandonDisable = false;
        if (res.code === 20000) {
          this.$message.success(msg);
        } else {
          this.$message.error(res.msg);
        }
      });
    },

    searchFund() {
      this.$refs.table.clearSort();
      this.getFundList();
    },

    addFund() {
      this.$refs.addProductModal.show();
    },

    sortChange(order, prop) {
      let map = {
        fundClickRatio: "fund_click_ratio",
        // absrankRetOneYear: 'absrank_ret_one_year',
        retOneMonth: "ret_one_month",
        retThreeMonth: "ret_three_month",
        retSixMonth: "ret_six_month",
        retOneYear: "ret_one_year",
        perrankRetOneMonth: "perrank_ret_one_month",
        perrankRetThreeMonth: "perrank_ret_three_month",
        perrankRetSixMonth: "perrank_ret_six_month",
        perrankRetOneYear: "perrank_ret_one_year",
        fundType: "fund_type"
      };
      let nameMap = {
        fundClickRatio: "访问热度",
        // absrankRetOneYear: '',
        retOneMonth: "近一月收益",
        retThreeMonth: "近三月收益",
        retSixMonth: "近半年收益",
        retOneYear: "近一年收益",
        perrankRetOneMonth: "近一月相对排名",
        perrankRetThreeMonth: "近三月相对排名",
        perrankRetSixMonth: "近半年收益",
        perrankRetOneYear: "近一年收益"
      };

      this.searchFormValue.sortKey = map[prop];
      this.searchFormValue.sortOrder = order;
      this.getFundList();
    },

    dragSort(fundArr) {
      this.loadingTitle = "保存排序中...";
      this.tableLoading = true;
      let idArr = [];
      for (let item of fundArr) {
        idArr.push(item.fundId);
      }

      let params = {
        fundIds: idArr
      };

      this.$http.post("datadis/display/fund/order", params).then(res => {
        this.tableLoading = false;
        this.$refs.table.refresh();
        if (res.code === 20000) {
          this.$message.success("保存排序成功");
          this.$nextTick(() => {
            this.getFundList();
          });
        } else {
          this.$message.error("保存排序失败");
        }
      });
    },

    tableRowClick({ row }) {
      this.currentRowId = row.fundId;
      this.$refs.table.setCurrentRow("fundId", this.currentRowId);

      let index = this.expandRowKeys.indexOf(row.fundId);
      if (index === -1) {
        if (row.hasSubFund) {
          this.expandRowKeys.push(row.fundId);
        }
      } else {
        this.expandRowKeys.splice(index, 1);
      }
    },

    deleteProduct(index, row) {
      let { fundId } = row;
      let params = {
        fundIds: [fundId]
      };
      this.$confirm(
        `确认下架 <b style="color:#fff;">${row.fundShortName ||
          row.fundName}</b> ?`,
        "下架",
        {
          dangerouslyUseHTMLString: true,
          showCancelButton: true,
          closeOnClickModal: false,
          beforeClose: (action, instance, done) => {
            if (action === "confirm") {
              instance.confirmButtonLoading = true;
              // instance.confirmButtonText = "下架中";
              this.$http
                .delByParams("datadis/display/fund", params)
                .then(res => {
                  done();
                  instance.confirmButtonLoading = false;
                  if (res.code === 20000) {
                    this.$message.success("已下架");
                    this.searchFund();
                  } else {
                    this.$message.error(res.msg);
                  }
                });
            } else {
              instance.confirmButtonLoading = false;
              done();
            }
          }
        }
      );
    },

    // 处理收益和相对排名的截止日期,是请求返回的endDate的下一个月的5号
    handleEndDate(date) {
      let endDate = new Date((date + "-1").replace(/-/g, "/"));
      let endMonth = endDate.getMonth();
      // 将小于10月的月份前面补上0
      return endMonth === 11
        ? `${endDate.getFullYear() + 1}-01-05`
        : `${endDate.getFullYear()}-${
            endDate.getMonth() + 2 < 10
              ? "0" + (endDate.getMonth() + 2)
              : endDate.getMonth() + 2
          }-05`;
    },

    getFundList(keepCurrentRow = false) {
      return new Promise(resolve => {
        this.loadingTitle = "数据加载中...";
        this.tableLoading = true;
        if (!this.keepCurrentRow) {
          this.currentRowId = "";
        }
        this.$http
          .get("/datadis/display/fund", this.searchFormValue)
          .then(res => {
            this.tableLoading = false;
            if (res && res.code === 20000 && res.data) {
              this.endDate = this.handleEndDate(res.data.endDate);
              this.tableData = res.data.records;
              this.totalItem = res.data.total;
              // 返回数据有下一页时才能有懒加载
            } else {
              this.reload = true;
            }
            resolve();
          });
        this.$nextTick(() => {
          this.$refs.table.setCurrentRow("fundId", this.currentRowId);
        });
      });
    },

    getFundType() {
      return new Promise(resolve => {
        this.$http
          .get("datadis/display/fundType", {
            pageSize: -1
          })
          .then(res => {
            let data = res.data.records || [];
            resolve();
            this.selfAddFundType = data.map(item => {
              return {
                label: item.name,
                value: item.id,
                selfAdd: true
              };
            });
          });
      });
    },

    deleteSelfType(data, fundType) {
      let params = {
        ids: [data.value]
      };
      this.$http.delByParams("datadis/display/fundType", params).then(res => {
        if (res.code === 20000) {
          let index = _.findIndex(this.selfAddFundType, option => {
            return option.value == data.value || option.label == data.label;
          });

          if (index != -1) {
            this.selfAddFundType.splice(index, 1);
          }
        }
      });
    },

    addOrEditType(data) {
      //如果有id 更新，没有新增
      if (data.value) {
        this.$http
          .putWithoutId(`datadis/display/fundType/${data.value}`, {
            name: data.label
          })
          .then(res => {
            console.log(res);
          });
      } else {
        this.$http
          .post("datadis/display/fundType", {
            name: data.label
          })
          .then(res => {
            if (res.code === 20000) {
              let index = _.findIndex(this.selfAddFundType, type => {
                return type.label == res.data.name && !type.value;
              });

              this.$set(this.selfAddFundType, index, {
                label: res.data.name,
                value: ~~res.data.id,
                selfAdd: true,
                editable: false,
                disabled: false
              });
            }
          });
      }
    },

    saveFundType(data) {
      let { index, fundType, fundId } = data;

      this.$http
        .putWithoutId(`datadis/display/fund/${fundId}`, { fundType })
        .then(res => {
          if (res.code === 20000) {
            this.$set(this.tableData[index], "fundType", fundType);
          }
        })
        .catch(err => {});
    }
  }
};
</script>
 
<style lang="less">
@import "./css/app.less";
</style>

