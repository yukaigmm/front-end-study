import {
    getSessionOption
} from "../../../../common/js/utils.js";

import img from "../../../../assets/images/direct-sale/tablefold.png"

export default function generateColumns() {
    return [{
            key: "expand",
            type: "expand",
            width: 1,
            render: (h, {
                row
            }) => {
                return h("subFundTable", {
                    props: {
                        fundId: row.fundId
                    },

                })
            }
        },
        {
            key: "fundShortName",
            title: "基金简称",
            minWidth: 100,
            render: (h, {
                row,
            }) => {
                let fundName = null;

                fundName = h("span", `${row.fundShortName}`);
                let tag = null;
                if (row.representative == 1) {
                    tag = h("span", {
                        class: "represent-tag",
                    }, "代表作")
                }

                let hasExpand = this.expandRowKeys.includes(row.fundId)
                let backPosition = hasExpand ? "0 1px" : "0 -12px";


                let foldIcon = row.hasSubFund ? h("span", {
                    style: {
                        backgroundImage: `url(${img})`,
                        backgroundRepeat: "no-repeat",
                        backgroundPosition: backPosition,
                        display: "inline-block",
                        width: "16px",
                        height: "12px"
                    }
                }) : null;

                return h('div', {}, [
                    foldIcon,
                    fundName,
                    tag,
                ])
            }
        },
        {
            key: "fundType",
            title: "基金类型",
            sortable: true,
            width: 150,
            render: (h, {
                row,
                column,
                index
            }) => {
                // let map = {
                //     1: {
                //         "1": "信托计划",
                //         "2": "有限合伙",
                //         "3": "券商资管",
                //         "4": "公募专户",
                //         "5": "单账户",
                //         "6": "证券投资基金",
                //         "7": "海外基金",
                //         "8": "期货资管",
                //         "9": "保险资管",
                //         "10": "创业投资基金",
                //         "11": "股权投资基金",
                //         "12": "银行理财",
                //         "13": "类固收信托",
                //         "-1": "其他投资基金"
                //     },
                //     2: {
                //         "1": "股票型",
                //         "2": "混合型",
                //         "3": "债券型",
                //         "4": "货币型",
                //         "5": "商品型",
                //         "6": "市场中性型",
                //         "7": "FOF",
                //         "8": "海外型",
                //     }
                // }

                let map = {
                    1: [{
                            label: "信托计划",
                            value: 1
                        },
                        {
                            label: "有限合伙",
                            value: 2
                        },
                        {
                            label: "券商资管",
                            value: 3
                        },
                        {
                            label: "公募专户",
                            value: 4
                        },
                        {
                            label: "单账户",
                            value: 5
                        },
                        {
                            label: "证券投资基金",
                            value: 6
                        },
                        {
                            label: "海外基金",
                            value: 7
                        },
                        {
                            label: "期货资管",
                            value: 8
                        },
                        {
                            label: "保险资管",
                            value: 9
                        },
                        {
                            label: "创业投资基金",
                            value: 10
                        },
                        {
                            label: "股权投资基金",
                            value: 11
                        },
                        {
                            label: "银行理财",
                            value: 12
                        },
                        {
                            label: "类固收信托",
                            value: 13
                        },
                        {
                            label: "其他投资基金",
                            value: -1
                        },
                    ],
                    2: [{
                            label: "股票型",
                            value: 1
                        },
                        {
                            label: "混合型",
                            value: 2
                        },
                        {
                            label: "债券型",
                            value: 3
                        },
                        {
                            label: "货币型",
                            value: 4
                        },
                        {
                            label: "商品型",
                            value: 5
                        },
                        {
                            label: "市场中性型",
                            value: 6
                        },
                        {
                            label: "FOF",
                            value: 7
                        },
                        {
                            label: "海外型",
                            value: 8
                        },
                    ]
                }
                // 先判断是公募还是私募，公募的raiseType 为 2，取 map 中的 2；
                // fundType 私募基金类型
                // pubFundType 公募基金类型
                let fundTypeMap = row.raiseType ? map[row.raiseType] : {};
                let options = [];
                // if (row.sourceData == 2) {
                //     return "指数";
                // } else if (row.raiseType == 1) {
                //     return fundTypeMap[row.fundType]
                // } else if (row.raiseType == 2) {
                //     return fundTypeMap[row.pubFundType]
                // } else {
                //     return "--";
                // }
                options = map[row.raiseType]
                if (row.sourceData == 2) {
                    options = [{
                        label: "指数",
                        value: "指数"
                    }]
                }

                let fullOptions = JSON.parse(JSON.stringify(options))

                options = _.filter(options, option => option.value == row.oldFundType);


                options = options.concat(this.selfAddFundType)
                fullOptions = fullOptions.concat(this.selfAddFundType)


                let hasOption = _.find(options, option => option.value == row.fundType);
                return h("EditSelect", {
                    props: {
                        options,
                        fullOptions,
                        oldFundType: row.oldFundType,
                        value: hasOption ? row.raiseType == 1 ?row.fundType: row.pubFundType : row.oldFundType
                    },
                    on: {
                        addNewType: (data) => {
                            this.selfAddFundType.push({
                                selfAdd: true,
                                editable: true,
                                label: "",
                                value: "",
                                disabled: true
                            })
                        },

                        addOrEditType: data => {
                            this.addOrEditType(data);
                        },

                        deleteType: (data) => {
                            this.deleteSelfType(data);

                        },

                        changeFundType: type => {
                            let params = {
                                fundType: type,
                                fundId: row.fundId,
                                index,
                            }
                            this.saveFundType(params)
                        },

                    }
                })
            }
        },
        {
            key: "strategy",
            title: "基金策略",
            width: 90,
            render: (h, {
                row
            }) => {
                let map = getSessionOption("cFinancialStrategy");
                for (let item of map) {
                    if (item.param == row.strategy) {
                        return item.name;
                    }
                }
                return "--";
            }
        },
        {
            title: "最新净值",
            align: "center",
            key: "netvalue",
            childrens: [{
                    key: "priceDate",
                    title: "日期",
                    width: 100,
                    align: "right",
                    render: (h, {
                        row
                    }) => {
                        return row.priceDate || "--";
                    }
                },
                {
                    key: "nav",
                    title: "净值",
                    width: 80,
                    align: "right",
                    render: (h, {
                        row
                    }) => {
                        let nav = row.nav ? Number(row.nav) : "";
                        return nav ? nav.toFixed(4) : "--";
                    }
                }
            ]
        },
        {
            title: "收益",
            align: "center",
            renderHeader: h => {
                return h("span", [
                    h(
                        "span", {
                            style: {
                                marginRight: "5px"
                            }
                        },
                        "收益"
                    ),
                    h("vtooltip", {
                        props: {
                            explains: `收益截止日期:${this.endDate}`,
                            showIndex: false
                        }
                    })
                ]);
            },
            childrens: this.retChildrenConfigArray.map(({
                title,
                key
            }) => {
                return {
                    key: key,
                    title: title,
                    // sortKey: "ret_one_month",
                    sortable: true,
                    width: 80,
                    align: "right",
                    render(h, {
                        row
                    }) {
                        return h(
                            "div", {
                                style: {
                                    color: `${
                        parseFloat(row[key]) > 0
                          ? "#f45"
                          : parseFloat(row[key]) < 0
                          ? "#009819"
                          : ""
                      }`
                                }
                            },
                            row[key] ? (parseFloat(row[key]) * 100).toFixed(2) + "%" : "--"
                        );
                    },
                    renderHeader: h => {
                        return h(
                            "span", {
                                class: {
                                    "text-span": true
                                }
                            },
                            title
                        );
                    }
                }
            })
        },
        {
            key: "action",
            title: "操作",
            width: 100,
            align: "center",
            showOverflowTooltip: false,
            render: (h, {
                row,
                column,
                index
            }) => {
                return h(
                    "div", {
                        class: 'table-action-button-container'
                    },
                    [
                        //编辑
                        //删除
                        h("span", {
                            attrs: {
                                class: row.representative == "1" ? "action-btn action-represent-not-btn" : "action-btn action-represent-btn",
                                title: row.representative == "1" ? "取消代表作" : "设为代表作"
                            },
                            on: {
                                click: e => {
                                    e.stopPropagation();
                                    e.preventDefault();
                                    this.setAsRepresentProduct(row);
                                }
                            }
                        }),
                        h("span", {
                            attrs: {
                                class: "action-btn action-down-btn",
                                title: "下架"
                            },
                            on: {
                                click: e => {
                                    e.stopPropagation();
                                    e.preventDefault();
                                    this.deleteProduct(index, row);
                                }
                            }
                        }),
                        //导出pdf
                        // h("vbuttonSprite", {
                        //     props: {
                        //         pos: {
                        //             normal: {
                        //                 x: 0,
                        //                 y: -187
                        //             },
                        //             hover: {
                        //                 x: -18,
                        //                 y: -187
                        //             },
                        //             disabled: {
                        //                 x: -36,
                        //                 y: -187
                        //             }
                        //         },
                        //         // disabled: row.isVisible !== 1,
                        //         title: "导出pdf"
                        //     },
                        //     style: {
                        //         verticalAlign: "middle",
                        //         marginRight: "20px"
                        //     },
                        //     on: {
                        //         click: e => {
                        //             this.exportPdf(row.fundId, row.fundShortName);
                        //         }
                        //     }
                        // }),
                    ]
                );
            }
        }
    ];
}