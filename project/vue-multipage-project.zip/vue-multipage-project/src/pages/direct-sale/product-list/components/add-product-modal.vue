<template>
  <vmodal ref="modal" title="添加产品" @close="cancel" class="add-product-modal t2-el-dialog">
    <vpart title="添加产品">
      <div slot="search">
        <vinput
          type="text"
          class="table-search-input"
          style="display: inline-block"
          @keyup.enter.native="searchFund"
          v-model="searchFormValue.keyWord"
          placeholder="关键字搜索(基金ID/全称/简称/管理人)"
        ></vinput>
        <vbutton active title="搜索" @click="searchFund">搜索</vbutton>
      </div>
    </vpart>

    <vtable
      ref="table"
      :columns="columns"
      :max-height="tableMaxHeight"
      :data="tableData"
      useActionColumn
      usePagination
      :totalItem="totalItem"
      :currentPage="currentPage"
      changeRowColor
      @pageChange="pageChange"
      @pageSizeChange="sizeChange"
      @tableRowClick="tableRowClick"
    ></vtable>
    <vloading class="loading" v-model="loading"></vloading>
    <vreload v-model="reload" @reload="getFundList"></vreload>
  </vmodal>
</template>

<script>
export default {
  data() {
    return {
      searchFormValue: {},
      tableMaxHeight: null,
      totalItem: 0,
      currentPage: 1,
      columns: [
        {
          key: "fundId",
          title: "基金ID",
          minWidth: 100,
          render(h, { row }) {
            return h("span", row.fundId || "--");
          }
        },
        {
          key: "fundShortName",
          title: "基金简称",
          minWidth: 100,
          render(h, { row }) {
            return h("span", row.fundShortName || "--");
          }
        },
        {
          key: "action",
          title: "操作",
          width: 60,
          align: "center",
          render: (h, { row }) => {
            return h("span", {
              attrs: {
                title: "上架",
                class: "action-btn action-up-btn"
              },
              on: {
                click: () => {
                  this.addProduct(row);
                }
              }
            });
          }
        }
      ],
      tableData: [],
      currentRowId: "",
      loading: false,
      pageSize: 10,
      hasAdd: false,
      reload: false
    };
  },

  methods: {
    cancel() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.searchFormValue = {};
      this.totalItem = 0;
      this.tableData = [];
      this.currentRowId = "";
      if (this.hasAdd) {
        this.$emit("refreshTable");
        this.hasAdd = false;
      }
      this.$refs.modal.close();
    },

    show() {
      this.$refs.modal.open();
      this.getFundList();
    },

    getFundList() {
      this.loading = true;
      let params = JSON.parse(JSON.stringify(this.searchFormValue));
      params.pageSize = this.pageSize;
      params.pageNo = this.currentPage;
      this.$http.get("datadis/display/fund/add", params).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          this.reload = false;
          this.tableData = res.data.records || [];
          this.totalItem = res.data.total || 0;
          this.setTableHeight();
        } else {
          this.reload = true;
          this.tableData = [];
          this.totalItem = 0;
          this.$message.error(res.msg);
        }
      });
    },

    searchFund() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getFundList();
    },

    pageChange(page) {
      this.currentPage = page;
      this.getFundList();
    },

    sizeChange(size) {
      this.pageSize = size;
      this.getFundList();
    },

    tableRowClick({ row }) {
      this.currentRowId = row.fundId;
      this.$refs.table.setCurrentRow("fundId", this.currentRowId);
    },

    addProduct(row) {
      let { fundId } = row;
      let params = [fundId];

      this.$http
        .post("/datadis/display/fund", { fundIds: params })
        .then(res => {
          if (res.code === 20000) {
            this.hasAdd = true;
            this.$message.success("添加成功");
            this.searchFund();
          } else {
            this.$message.error(res.msg);
          }
        });
    },

    // 设置表格高度
    setTableHeight() {
      window.addEventListener("resize", () => {
        let maxHeight = $(".add-product-modal").height() - 200;
        this.tableMaxHeight = maxHeight;
      });
    }
  }
};
</script>

<style lang="less">
</style>

