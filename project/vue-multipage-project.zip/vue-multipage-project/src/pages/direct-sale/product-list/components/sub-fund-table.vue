<template>
  <div class="sub-fund-table">
    <vtable
      ref="table"
      :columns="columns"
      :data="tableData"
      :show-header="false"
      layout="total"
      :maxHeight="200"
      :rowKey="row => row.fundId"
      :dragTitleExplains="['拖动该列图标可进行排序', '当无搜索排序或者过滤条件时才可拖动']"
      :changeRowColor="true"
    ></vtable>
    <vloading v-model="tableLoading" title="数据加载中..." class="loading"></vloading>
  </div>
</template>

<script>
import columns from "../js/sub-table-columns";
export default {
  props: ["fundId"],

  computed: {
    columns() {
      return columns.call(this);
    }
  },
  data() {
    return {
      tableLoading: false,
      retChildrenConfigArray: [
        { title: "近一月", key: "retOneMonth" },
        { title: "近三月", key: "retThreeMonth" },
        { title: "近半年", key: "retSixMonth" },
        { title: "近一年", key: "retOneYear" }
      ],
      tableData: []
    };
  },

  mounted() {
    this.searchFund();
  },

  methods: {
    deleteProduct(index, row) {
      let { fundId } = row;
      let params = {
        fundIds: [fundId]
      };
      this.$confirm(
        `确认下架 <b style="color:#fff;">${row.fundShortName ||
          row.fundName}</b> ?`,
        "下架",
        {
          dangerouslyUseHTMLString: true,
          showCancelButton: true,
          closeOnClickModal: false,
          beforeClose: (action, instance, done) => {
            if (action === "confirm") {
              instance.confirmButtonLoading = true;
              // instance.confirmButtonText = "下架中";
              this.$http
                .delByParams("datadis/display/fund", params)
                .then(res => {
                  done();
                  instance.confirmButtonLoading = false;
                  if (res.code === 20000) {
                    this.$message.success("已下架");
                    this.searchFund();
                  } else {
                    this.$message.error(res.msg);
                  }
                });
            } else {
              instance.confirmButtonLoading = false;
              done();
            }
          }
        }
      );
    },

    searchFund() {
      let params = {
        pageSize: -1
      };
      this.tableLoading = true;

      this.$http
        .get(`datadis/display/subFund/${this.fundId}`, params)
        .then(res => {
          this.tableLoading = false;
          this.tableData = res.data.records;
          this.$refs.table && this.$refs.table.refresh();
        })
        .catch(err => {
          this.tableData = [];
          this.tableLoading = false;
        });
    }
  }
};
</script>

<style lang="less" scoped>
</style>

