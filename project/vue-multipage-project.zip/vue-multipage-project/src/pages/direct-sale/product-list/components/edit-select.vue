<template>
  <div class="edit-select-wrapper">
    <div class="display-area" v-if="!ifEdit">
      <span>{{activeLabel}}</span>
    </div>

    <el-select v-model="value" class="type-selctor" placeholder="请选择" @change="onChange" v-else>
      <el-option
        class="type-selector-option"
        v-for="(item,index) in options"
        :key="item[valueKey]"
        :label="item[labelKey]"
        :value="item[valueKey]"
        :disabled="item.disabled"
      >
        <span style="float: left" :key="selectKey" v-if="!item.editable">{{ item[labelKey] }}</span>
        <span style="float: left" :key="selectKey" v-else>
          <el-input
            class="edit-input"
            @click.stop.prevent.native="()=>{}"
            autofocus
            v-model="item[labelKey]"
          />
        </span>
        <span style="float: right;" class="type-action-wrapper" v-if="item.selfAdd">
          <span
            @click.stop.prevent="editType(item,index)"
            class="type-action-btn"
            :class="{'type-edit-btn':!item.editable,'type-ok-btn':item.editable}"
          ></span>
          <span @click.stop.prevent="deleteType(item)" class="type-action-btn type-delete-btn"></span>
        </span>
      </el-option>
      <span class="add-type-btn" @click="addNewType">添加新类型</span>
    </el-select>

    <span
      @click.stop.prevent="showEdit"
      class="type-action-btn"
      :class="{'type-edit-btn':!ifEdit,'type-ok-btn':ifEdit}"
    ></span>
  </div>
</template>

<script>
import _ from "lodash";
export default {
  props: {
    options: {
      type: Array,
      default: () => []
    },

    valueKey: {
      type: String,
      default: "value"
    },

    labelKey: {
      type: String,
      default: "label"
    },

    value: {
      default: ""
    },
    fullOptions: {
      type: Array,
      default: () => []
    },
    oldFundType: {
      type: [String, Number]
    }
  },

  computed: {
    activeLabel() {
      let matchData =
        _.filter(this.options, item => item[this.valueKey] == this.value) || [];
      return matchData.length ? matchData[0][this.labelKey] : "--";
    },

    finalOptions() {
      return this.options;
    }
  },

  data() {
    return {
      selectKey: null,
      ifEdit: false
    };
  },

  mounted() {},

  methods: {
    onChange(item) {
      this.$emit("change", item);
    },

    addNewType() {
      this.$emit("addNewType");
      this.selectKey = Date.now();
    },

    editType(item, index) {
      if (item.editable) {
        if (this.validateIfRepeat(item.label, index)) {
          if (!item.label) {
            this.$message.warning("类型名称不能为空！");
            return;
          } else {
            this.$emit("addOrEditType", item);
          }
        } else {
          this.$message.warning("当前类型已存在！");
          return;
        }
      }
      item.editable = !item.editable;

      this.selectKey = Date.now();
    },
    deleteType(item) {
      this.$emit("deleteType", item);

      if (this.value == item.value) {
        this.showEdit();
      }
      this.selectKey = Date.now();
    },

    showEdit() {
      if (this.ifEdit) {
        this.$emit("changeFundType", this.value);
      }
      this.ifEdit = !this.ifEdit;
    },

    validateIfRepeat(name, tIndex) {
      let index = _.findIndex(
        this.fullOptions,
        option => option.label.trim() == name.trim()
      );

      let optionIndex = _.findIndex(
        this.finalOptions,
        option => option.label.trim() == name.trim()
      );

      return index == -1 || tIndex == optionIndex;
    }
  }
};
</script>

<style lang="less">
.add-type-btn {
  text-align: center;
  border-top: 1px solid #444;
  display: inline-block;
  width: 100%;
  height: 20px;
  line-height: 20px;
  color: #999;
  cursor: pointer;
  &:hover {
    text-decoration: underline;
    color: #2992ff;
  }
}

.edit-input {
  width: 100px !important;
  .el-input__inner,
  div.el-input__inner {
    height: 20px !important;
  }
}

.edit-select-wrapper {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.type-action-btn {
  display: inline-block;
  width: 18px;
  height: 18px;
  background-image: url("../../../../assets/images/blue-white-sprite.png");
}

.type-edit-btn {
  background-position: 0px 341px;
  &:hover {
    background-position: 36px 341px;
  }
}

.type-ok-btn {
  cursor: pointer;
  background-position: 0px 0px;
  &:hover {
    background-position: 36px 0;
  }
}

.type-delete-btn {
  cursor: pointer;
  margin-left: 5px;
  background-position: 0px 119px;
  &:hover {
    background-position: 36px 119px;
  }
}

.type-selctor {
  max-width: 120px !important;
}

.type-action-wrapper {
  display: flex;
  height: 100%;
  margin-left: 5px;
  justify-content: space-between;
  align-items: center;
}

.type-selector-option {
  min-width: 168px !important;
}
</style>

