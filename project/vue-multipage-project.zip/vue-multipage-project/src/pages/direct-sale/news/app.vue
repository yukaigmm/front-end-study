<template>
  <vcommon
    :menuParentKey="currentMenuParentKey"
    :menuChildKey="currentMenuChildKey"
    class="direct-sale-page-config"
  >
    <vpart title="资讯列表">
      <div slot="search">
        <vinput
          type="text"
          class="table-search-input"
          style="display: inline-block"
          @keyup.enter.native="searchNews"
          v-model="searchFormValue.keyWord"
          placeholder="资讯标题或内容"
        />

        <vbutton active title="搜索" @click="searchNews">搜索</vbutton>
        <vswitch
          style="display: inline-block;"
          type="checkbox"
          v-model="searchFormValue.isShow"
          :trueValue="0"
          :falseValue="1"
          trueLabel="显示已隐藏的资讯"
          falseLabel
          @change="searchNews"
        ></vswitch>
      </div>

      <div slot="action">
        <vbutton title="停用" active :disabled="ifAbandonDisable" @click="abandon">停用</vbutton>
        <vbutton title="发布" active :disabled="ifPublishDisable" @click="publish">发布</vbutton>
        <vbutton active title="新增" @click="addNews">新增</vbutton>
      </div>

      <vtable
        ref="table"
        :columns="columns"
        :data="tableData"
        :totalItem="totalItem"
        useActionColumn
        usePagination
        :max-height="maxHeight"
        draggable
        :dragTitleExplains="['拖动该列图标可进行排序', '当无搜索排序或者过滤条件时才可拖动', '官网显示顺序与页面显示顺序一致']"
        :currentRowIndex="currentRowId"
        changeRowColor
        @pageChange="currentPageChange"
        @pageSizeChange="sizeChange"
        :currentPage="searchFormValue.pageNo"
        :pageSize="searchFormValue.pageSize"
        @sort="dragSort"
        @tableRowClick="tableRowClick"
      ></vtable>
    </vpart>
    <news-content-modal
      ref="newsContentModal"
      :news-type="currentNewsType"
      :modal-title="currentNewsTitle"
      :newsSource="currentNewsSrc"
    />
    <add-eidt-modal ref="addEidtModal" @refresh="searchNews" />

    <vloading class="loading" v-model="loading"></vloading>
    <vreload class="reload" v-model="reload" @reload="getNewsList"></vreload>
  </vcommon>
</template>

<script>
import generateColumns from "./js/columns";
import NewsContentModal from "./components/news-content-modal";
import AddEidtModal from "./components/add-edit-modal";
export default {
  components: {
    NewsContentModal,
    AddEidtModal
  },

  data() {
    return {
      currentMenuParentKey: "directSale",
      currentMenuChildKey: "directSalenews",
      searchFormValue: {
        pageSize: 10,
        pageNo: 1,
        keyWord: "",
        isShow: 1
      },
      tableData: [],
      totalItem: 0,
      currentRowId: "",
      maxHeight: 500,
      currentNewsType: "",
      currentNewsTitle: "",
      currentNewsSrc: "",
      loading: false,
      reload: false,
      ifAbandonDisable: false,
      ifPublishDisable: false
    };
  },

  computed: {
    columns() {
      return generateColumns.call(this);
    }
  },

  mounted() {
    this.getNewsList();
  },

  methods: {
    getStatus() {},

    setStatus(status) {
      this.$http
        .post("datadis/display/status", {
          articleStatus: status
        })
        .then(res => {
          this.ifAbandonDisable = false;
          this.ifPublishDisable = false;
          if (res.code === 20000) {
            let msg = status == 1 ? "发布成功" : "已停用";
            this.$message.success(msg);
          } else {
            this.$message.error(res.msg);
          }
        })
        .catch(err => {
          this.ifAbandonDisable = false;
          this.ifPublishDisable = false;
          this.$message.error("请求失败！");
          console.error(err);
        });
    },

    getNewsList() {
      this.loading = true;

      this.$http
        .get("datadis/display/article", this.searchFormValue)
        .then(res => {
          this.loading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records || [];
            this.totalItem = res.data.total;
            this.reload = false;
          } else {
            this.tableData = [];
            this.reload = true;
            this.totalItem = 0;
            this.$message.error(res.msg);
          }
        })
        .catch(err => {
          this.$message.error("获取列表失败！");
          this.loading = false;
          this.reload = true;
        });
    },

    searchNews() {
      if (this.searchFormValue.keyWord) {
        this.$refs.table.setUnSortable();
      } else {
        this.$refs.table.setSortabel();
      }
      this.searchFormValue.pageSize = 10;
      this.searchFormValue.pageNo = 1;
      this.getNewsList();
    },

    abandon() {
      this.ifAbandonDisable = true;
      this.setStatus(2);
    },

    publish() {
      this.ifPublishDisable = true;
      this.setStatus(1);
    },

    addNews() {
      this.$refs.addEidtModal.show();
    },

    editNews({ id }) {
      this.$refs.addEidtModal.show(id);
    },

    deleteNews({ id }) {
      this.$confirm("确认删除吗？", "删除", {
        showCancelButton: true,
        type: "warning",
        closeOnClickModal: false,

        beforeClose: (action, instance, done) => {
          if (action === "cancel") {
            done();
            return;
          }
          instance.confirmButtonLoading = true;
          instance.confirmButtonText = "删除中...";
          this.$http
            .del(`datadis/display/article/${id}`)
            .then(res => {
              instance.confirmButtonLoading = false;
              if (!res) return;

              let isSuccess = res.code == 20000;
              this.$message({
                showClose: true,
                message: isSuccess ? "删除成功" : "删除失败",
                type: isSuccess ? "success" : "error"
              });

              if (isSuccess) {
                this.searchNews();
              }
            })
            .done(() => {
              done();
            });
        }
      });
    },

    dragSort(idArr) {
      let arr = idArr || [];
      let ids = arr.map(data => data.id);

      this.$http
        .post("datadis/display/article/order", { ids })
        .then(res => {
          if (res.code === 20000) {
            this.searchNews();
            this.$refs.table.refresh();
            this.$message.success("保存排序成功！");
          } else {
            this.$message.error(res.msg);
          }
        })
        .catch(err => {
          this.$message.error("保存排序失败！");
        });
    },

    tableRowClick({ row, column, index }) {
      this.currentRowId = row.id;
      this.$refs.table.setCurrentRow("id", this.currentRowId);
    },

    currentPageChange(page) {
      this.searchFormValue.pageNo = page;
      this.searchNews();
    },

    sizeChange(pageSize) {
      this.searchFormValue.pageSize = pageSize;
      this.searchNews();
    },

    show({ id }) {
      let params = {
        isShow: 1
      };

      this.$http
        .putWithoutId(`datadis/display/article/${id}`, params)
        .then(res => {
          if (res.code === 20000) {
            this.searchNews();
            this.$message.success("修改成功！");
          } else {
            this.$message.error(res.msg);
          }
        })
        .catch(e => {
          this.$message.error("修改失败！");
        });
    },

    hide({ id }) {
      let params = {
        isShow: 2
      };

      this.$http
        .putWithoutId(`datadis/display/article/${id}`, params)
        .then(res => {
          if (res.code === 20000) {
            this.searchNews();
            this.$message.success("修改成功！");
          } else {
            this.$message.error(res.msg);
          }
        })
        .catch(e => {
          this.$message.error("修改失败！");
        });
    },

    showDetail(row) {
      this.currentNewsType = row.articleType;
      this.currentNewsTitle = row.articleTitle;
      if (row.articleType == "1") {
        this.currentNewsSrc = row.articleId;
      } else {
        this.currentNewsSrc = row.articleUrl;
      }
      this.$nextTick(() => {
        this.$refs.newsContentModal.show();
      });
    }
  }
};
</script>


<style lang="less">
.if-hide-btn {
  background-position: 0px -223px;
  &:hover {
    background-position: -18px -223px;
  }
}
.has-hidden-btn {
  background-position: 0px -258px;
  &:hover {
    background-position: -18px -258px;
  }
}

.action-btn {
  display: inline-block;
  cursor: pointer;
  margin-left: 15px;
  width: 18px;
  height: 18px;
  background-image: url("../../../assets/images/sprite.png");
  background-repeat: no-repeat;
}

.edit-disable-btn {
  cursor: not-allowed;
  background-position: -36px -19px;
}

.edit-btn {
  background-position: 0px -19px;
  &:hover {
    background-position: -18px -19px;
  }
}

.delete-btn {
  background-position: 0px -240px;
  &:hover {
    background-position: -18px -240px;
  }
}
</style>