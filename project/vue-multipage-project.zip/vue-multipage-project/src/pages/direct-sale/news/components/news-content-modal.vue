<template>
  <vmodal ref="modal" :title="modalTitle" @close="cancel" class="t2-el-dialog">
    <div class="content-wrapper">
      <img class="news-img" :src="newsSrc" alt="新闻" v-if="newsType =='3'" />
      <div class="iframe-container" ref="ifa" v-else>
        <iframe ref="iframe" :src="newsSrc" class="iframe" frameborder="0"></iframe>
      </div>
    </div>
    <vloading class="loading" v-model="loading"></vloading>
  </vmodal>
</template>
<script>
export default {
  props: {
    newsType: {
      required: true
      //   取值：1->内部新闻，2->外链 ，3-> 图片
    },
    modalTitle: {
      required: true,
      type: String,
      default: "新闻标题"
    },

    newsSource: {
      required: true,
      type: [String, Number],
      default: ""
    }
  },

  data() {
    return {
      loading: false
    };
  },

  computed: {
    newsSrc() {
      if (this.newsType == "1") {
        let mapping = {
          development: "-test",
          test: "-test",
          pre: "-pre",
          production: ""
        };

        let env = process.env.NODE_ENV;

        let src = `https://www${mapping[env]}.simuwang.com/news/show-0-${this.newsSource}.html`;

        return src;
      } else {
        return this.newsSource;
      }
    }
  },

  mounted() {},

  methods: {
    show() {
      this.$refs.modal.open();

      this.$nextTick(() => {
        try {
          let el = this.$refs.iframe;

          if (el) {
            this.loading = true;

            // if (el.onload) {
            el.onload = () => {
              this.loading = false;
            };
            // } else {
            el.onreadystatechange = () => {
              if (el.readyState == "complete") {
                this.loading = false;
              }
            };
            // }
          }
        } catch (err) {
          this.loading = false;
          console.error(err);
        }
      });
    },

    cancel() {}
  }
};
</script>

<style lang="less">
.content-wrapper {
  height: auto;
  text-align: center;
  .news-img {
    height: auto;
    max-width: 768px;
  }
}

.iframe-container {
  height: auto;
  background-color: #1a1a1a;
  .iframe {
    width: 100%;
    height: 450px;
    html,
    body {
      margin: 0;
      padding: 0;
    }
  }
}
</style>