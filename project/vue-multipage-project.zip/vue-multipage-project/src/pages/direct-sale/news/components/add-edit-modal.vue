<template>
  <vmodal ref="modal" :title="modalTitle" @close="cancel" class="t2-el-dialog" width="400">
    <el-radio-group v-model="formData.articleType" size="mini" class="cus-radio">
      <el-radio-button label="2">链接</el-radio-button>
      <el-radio-button label="3">图片</el-radio-button>
    </el-radio-group>

    <el-form ref="form" :model="formData" label-width="100px" :rules="validateRules">
      <el-form-item label="资讯标题" prop="articleTitle">
        <el-input v-model.trim="formData.articleTitle" placeholder="请输入标题" />
      </el-form-item>

      <el-form-item label="发布时间" prop="postTime">
        <el-date-picker
          v-model="formData.postTime"
          :clearable="false"
          class="cus-picker"
          style="width:100%"
          placeholder="选择发布时间"
        />
      </el-form-item>

      <el-form-item label="资讯来源" prop="author">
        <el-input v-model.trim="formData.author" placeholder="请输入资讯来源" />
      </el-form-item>

      <el-form-item label="资讯宣传图" prop="imageUrl">
        <vimageUpload
          showRecommendSize
          recommendSize="210x140"
          v-model="formData.imageUrl"
          url="file/visitingCard"
          fieldName="directSalePicture"
          fullPath
          @change="onPicChange"
          :imgStyle="{minWidth: '210px',maxWidth: '210px',height: '140px'}"
        />
      </el-form-item>

      <el-form-item label="资讯链接" prop="articleUrl" v-if="formData.articleType==2">
        <el-input v-model.trim="formData.articleUrl" placeholder="请输入资讯链接" />
      </el-form-item>

      <el-form-item label="资讯内容" prop="articleImage" v-else>
        <vfileUpload
          @getFileData="getFileData"
          v-model="formData.articleImage"
          url="datadis/company/uploadAdvFile"
          fileName="advFile"
          class="custom-file-uploader"
          resName="fileName"
          :foreignPath="true"
          :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
        />
      </el-form-item>
    </el-form>
    <vloading class="loading" :title="loadingTitle" v-model="loading"></vloading>
    <vreload class="reload" v-model="reload" @reload="getNewsDetail"></vreload>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton :disabled="reload" active @click="submit">保存</vbutton>
    </div>
    <vbutton @click="()=>{this.$refs.customizedPicModal.show()}">show</vbutton>
    <CustomizedPicModal ref="customizedPicModal" />
  </vmodal>
</template>

<script>
import baseUrlConfig from "../../../../common/js/base-url-config";
import CustomizedPicModal from "../../../../common/components/comp/customized-pic";
const validateImage = (rules, value, cb) => {
  let errors = [];

  if (!value.filePath) {
    errors.push(new Error("资讯内容不能为空"));
  }

  cb(errors);
};

export default {
  components: {
    CustomizedPicModal
  },

  data() {
    return {
      formData: {
        articleType: 2,
        articleImage: ""
      },
      validateRules: Object.freeze({
        articleTitle: {
          required: true,
          message: "资讯标题不能为空"
        },
        postTime: {
          required: true,
          message: "发布时间不能为空"
        },
        author: {
          required: true,
          message: "资讯来源不能为空"
        },
        imageUrl: {
          required: true,
          message: "资讯宣传图不能为空"
        },

        articleUrl: {
          required: true,
          message: "资讯链接不能为空"
        },
        articleImage: [
          {
            required: true,
            message: "资讯内容不能为空"
          },
          {
            validator: validateImage,
            trigger: "change"
          }
        ]
      }),
      id: "",
      loading: false,
      reload: false,
      loadingTitle: "数据加载中，请稍候！"
    };
  },

  computed: {
    modalTitle() {
      return this.id ? "编辑" : "新增";
    }
  },

  methods: {
    // 提交
    submit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          if (this.id) {
            this.editNews();
          } else {
            this.addNews();
          }
        } else {
          this.$message.warning("请按红色文字提示填写内容！");
        }
      });
    },

    // 显示
    show(id) {
      this.id = id;
      if (this.id) {
        this.getNewsDetail();
      }
      this.$refs.modal.open();
    },

    // 获取某一新闻详情
    getNewsDetail() {
      this.loading = true;

      this.$http
        .get(`datadis/display/article/${this.id}`)
        .then(res => {
          this.loading = false;
          if (res.code === 20000) {
            let keys = [
              "articleId",
              "articleImageUrl",
              "articleImageTitle",
              "articleTitle",
              "articleType",
              "articleUrl",
              "imageUrl",
              "author",
              "id",
              "postTime"
            ];
            let data = res.data || {};

            for (let key of keys) {
              this.$set(this.formData, key, data[key]);
            }
            this.$set(this.formData, "articleImage", {
              filePath: this.formData.articleImageUrl,
              fileName: this.formData.articleImageTitle
            });
            this.reload = false;
          } else {
            this.reload = true;
          }
        })
        .catch(err => {
          this.loading = false;
          this.reload = true;
          console.error(err);
        });
    },

    // 编辑新闻
    editNews() {
      this.loading = true;
      this.loadingTitle = "保存中，请稍候！";
      let params = JSON.parse(JSON.stringify(this.formData));
      if (params.articleType == 2) {
        delete params.articleImageUrl;
        delete params.articleImage;
        delete params.articleImageTitle;
      } else {
        delete params.articleUrl;
        delete params.articleImage;
      }

      this.$http
        .putWithoutId(`datadis/display/article/${this.id}`, params)
        .then(res => {
          this.loading = false;
          if (res.code === 20000) {
            this.$message.success("编辑成功！");
            this.$emit("refresh");
            this.cancel();
          } else {
            this.$message.error(res.msg);
          }
        })
        .catch(err => {
          this.loading = false;
          console.error(err);
        });
    },

    // 添加新闻
    addNews() {
      this.loading = true;
      this.loadingTitle = "保存中，请稍候！";

      let params = JSON.parse(JSON.stringify(this.formData));

      if (params.articleType == 2) {
        delete params.articleImageUrl;
        delete params.articleImage;
        delete params.articleImageTitle;
      } else {
        delete params.articleUrl;
        delete params.articleImage;
      }

      this.$http
        .post(`datadis/display/article`, params)
        .then(res => {
          this.loading = false;
          if (res.code === 20000) {
            this.$message.success("新增成功！");
            this.$emit("refresh");
            this.cancel();
          } else {
            this.$message.error(res.msg);
          }
        })
        .catch(err => {
          this.loading = false;
          console.error(err);
        });
    },

    // 取消
    cancel() {
      this.formData = {
        articleType: 2
      };
      this.loadingTitle = "数据加载中，请稍候！";
      this.id = "";

      this.$refs.form.resetFields();
      this.$refs.modal.close();
    },

    // 上传图片
    onPicChange(src) {
      // if (src) {
      //   let env = process.env.NODE_ENV;
      //   let staticSrc = `${baseUrlConfig[env].staticFile}/${src}`;
      //   this.$set(this.formData, "imageUrl", staticSrc);
      // } else {
      //   this.$set(this.formData, "imageUrl", "");
      // }

      this.$refs.form.validateField("imageUrl");
    },

    // 上传文件
    getFileData(file) {
      if (this.formData.articleImage.filePath) {
        let env = process.env.NODE_ENV;
        let staticSrc = `${baseUrlConfig[env].staticFile}/${this.formData.articleImage.filePath}`;
        this.formData.articleImageUrl = staticSrc;
        this.formData.articleImageTitle = this.formData.articleImage.fileName;
      } else {
        this.formData.articleImageUrl = "";
        this.formData.articleImageTitle = "";
      }
      this.$refs.form.validateField("articleImage");
    }
  }
};
</script>

<style lang="less">
.custom-file-uploader {
  margin-top: 7px;
  width: 95% !important;
}

.cus-picker {
  .el-input__prefix {
    top: 3px !important;
  }
}

// .cus-radio {
//   .el-radio-button__orig-radio:checked + .el-radio-button__inner {
//     background: linear-gradient(#4196e9, #0f5697) !important;
//     border-color: linear-gradient(#4196e9, #0f5697) !important;
//     color: #eeeeee;
//   }
// }
</style>