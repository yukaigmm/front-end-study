export default function generateColumns() {
    return [{
            key: "articleTitle",
            title: "资讯标题",
            render: (h, {
                row
            }) => {
                return h("a", {
                    class: "table-cell-link",
                    on: {
                        click: () => {
                            if (!row.articleTitle) return;
                            this.showDetail(row);
                        }
                    }
                }, row.articleTitle || "--")
            },
        },
        {
            key: "postTime",
            title: "发布时间",
            width: 180,
            render: (h, {
                row
            }) => {
                return h("span", row.postTime || "--")
            },
        },
        {
            key: "author",
            title: "资讯来源",
            width: 200,
            render: (h, {
                row
            }) => {
                return h("span", row.author || "--")
            },
        },
        {
            key: "isShow",
            title: "资讯状态",
            width: 100,
            render: (h, {
                row
            }) => {
                let mapping = {
                    "1": "展示中",
                    "2": "已隐藏"
                }

                return h("span", mapping[row.isShow] || "--")
            },
        },
        {
            key: "action",
            title: "操作",
            align: "center",
            width: 120,
            render: (h, {
                row
            }) => {

                let btns = [

                    h("span", {
                        class: row.isShow == 1 ? "action-btn if-hide-btn" : "action-btn has-hidden-btn",
                        attrs: {
                            title: row.isShow == 1 ? "隐藏" : "展示",
                        },
                        on: {
                            click: () => {
                                if (row.isShow == 1) {
                                    this.hide(row)
                                } else {
                                    this.show(row)
                                }
                            }
                        }
                    }),
                    h("span", {
                        class: row.articleType == "1" ? "action-btn edit-disable-btn" : "action-btn edit-btn",
                        attrs: {
                            title: row.articleType == "1" ? "排排网内部消息，不可编辑" : "编辑"
                        },
                        on: {
                            click: () => {
                                if (row.articleType == "1") return;
                                this.editNews(row)
                            }
                        }
                    }),
                    h("span", {
                        class: "action-btn delete-btn",
                        attrs: {
                            title: "删除"
                        },
                        on: {
                            click: () => {
                                this.deleteNews(row)
                            }
                        }
                    })

                ]

                return h("div", btns)
            },
        }
    ]
}