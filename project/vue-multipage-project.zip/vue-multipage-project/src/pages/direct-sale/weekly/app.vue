<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey" class="direct-sale-report">
    <vpart v-if="accountPaid" :title="`获客报表（${companyName}）`" class="direct-sale-weekly">
      <vloading v-model="loading"></vloading>
      <div 
      slot="search"
      class="notice-text"
      v-text="`亲爱的${userName}，贵司已入驻直营店${joinDate}天，获客辛苦了，请查阅成果！`"
      >
      </div>
      <div class="export-data" slot="action">
        <div class="export-pdf export-icon" @click="exportReport('pdf')" title="导出PDF"></div>
        <!-- <div class="export-word export-icon" @click="exportReport('word')" title="导出Word"></div> -->
        <div class="export-img export-icon" @click="exportReport('img')" title="导出图片"></div>
      </div>
      <div class="analysis-period">
        <span class="title">统计周期</span>
        <vselect
          class="select-period"
          v-model="periodType"
          :options="periodTypeOptions"
          @change="periodTypeChange"
        ></vselect>
        <vdate-range-picker 
          :type="periodType"
          :format="startDate && endDate ? `${startDate} ~ ${endDate}`: ' '"
          v-model="date"
          @change="dateChange"
          :picker-options="pickerOptions"
        ></vdate-range-picker>
      </div>
      <div class="weekly-tabs-container">
        <vtab 
          ref="tab" 
          :tabs="tabs" 
          @clickTab="clickTab" 
        >
          <div 
            v-for="(item,index) in tabConfig" 
            :key="index" 
            :slot="item.slot"
          >
            <component 
              :is="item.component" 
              :ref="item.slot"
              :startDate="startDate"
              :endDate="endDate"
              :periodType="periodType"
              :dateGap="dateGap"
              @getExportData="getExportData"
            ></component>
          </div>
        </vtab>
        <iframe src="" frameborder="0" style="display: none"></iframe>
      </div>
    </vpart>
    <div class="account-nopaid" v-else>
      <div class="mask-nopaid"></div>
      <div class="nopaid-notice">未付费机构暂不提供获客报表数据，付费后可查看真实数据。</div>
    </div>
  </vcommon>
</template>

<script>
import moment from "moment";
import customerData from "./components/customer-data.vue";
import searchData from "./components/search-data.vue";
import compareData from "./components/compare-data.vue";
import {getCompanyInfo} from "../../../common/js/utils.js";
export default {
  components: {
    customerData,
    searchData,
    compareData,
  },
  // moment 方法作用： 
  // day() -- 获取当月的某一天
  // utcOffset -- 设置时区
  // isoWeekday -- 获取当前日期是周几，1-7
  // subtract -- 当前时间减去某个时间段
  // add -- 当前时间加上某个时间段
  // diff -- 两个时间之间的距离
  computed: {
    startDate(){
      // 周 ：获取当周的周一
      // 月：获取当月的第一天所在周的周一，由于国际时间中，周日是第一天，所以需要特殊处理，当第一天是周日时，需要取前一周的周一而不是本周的周一
      if(moment().isBefore("2019-09-01") && this.periodType === "month"){
        return ""
      }
      let startDateMap = {
        "week": moment(this.date).day(1).utcOffset(8),
        "month": moment(this.date).date(1).isoWeekday() == 7 
        ?  
        moment(this.date).date(1).subtract(1, "days").day(1)
        : 
        moment(this.date).date(1).day(1).utcOffset(8)
      }
      return startDateMap[this.periodType].format("YYYY-MM-DD");
    },
    endDate(){
      // 周：获取当周的周日
      // 日：获取当月的最后一天所在周的周日，当最后一天是周日时，直接使用这一天；不是则获取本周六的后一天（下一周的第一天--周日）
       if(moment().isBefore("2019-09-01") && this.periodType === "month"){
        return ""
      }
       let endDateMap = {
        "week": moment(this.date).utcOffset(8).day("Saturday").add(1,"days"),
        "month": moment(this.date).date(1).add(1, "months").subtract(1,"days").isoWeekday() == 7
        ? 
         moment(this.date).date(1).add(1, "months").subtract(1,"days")
        : 
        moment(this.date).date(1).add(1, "months").subtract(1,"days").day("Saturday").add(1,"days"),
      }
      return endDateMap[this.periodType].format("YYYY-MM-DD")
    },
    dateGap(){
      return `${this.startDate}-${this.endDate}`
    }
  },
  data() {
    return {
      currentMenuParentKey: "directSale",
      currentMenuChildKey: "weekly",
      companyName: "",
      userName: "",
      joinDate: 0,
      accountPaid: false,
      // 设置日期默认为上周的周一
      date: moment().day(-6).toDate(),
      pickerOptions: {
        firstDayOfWeek: 1,
        // 禁用日期
        disabledDate: (time) => {
          let endDateMap = {
            "week": moment().day("Monday").subtract(1,"days"),
            "month": this.lastMonthSelectable() 
            ? 
            this.getLastDayOfLastWeek(moment().subtract(1, "month")) 
            : 
            this.getLastDayOfLastWeek(moment().subtract(2, "month"))
          }
          let startMap = {
            "week": moment("2019-07-29"),
            "month": moment().isAfter(moment("2019-09-01")) ? moment("2019-07-29") : moment("2019-08-05")
          }
          return  moment(time).isAfter(endDateMap[this.periodType]) || moment(time).isBefore(startMap[this.periodType]);
        }
      },
      periodType: "week",
      periodTypeOptions: [
        {label: "按周", value: "week"},
        {label: "按月", value: "month"}
      ],
      tabConfig: [
        {
          slot: "customerData",
          compId: 1,
          component: "customerData"
        },
        {
          slot: "searchData",
          compId: 3,
          component: "searchData"
        },
        // {
        //   slot: "compareData",
        //   compId: 4,
        //   component: "compareData"
        // },
      ],
      tabs: [
        {
          label: "客户数据统计",
          key: "customerData",
        },
        {
          label: "搜索查看统计",
          key: "searchData",
        },
        // {
        //   label: "市场同行水平",
        //   key: "compareData",
        // },
      ],
      exportData: {},
      userId: "",
      loading: false,
    }
  },
  methods: {
    dateChange(val){
      setTimeout(() => {
        console.log(this.startDate)
        console.log(this.endDate)
      }, 100);
    },
    periodTypeChange(val){
      if(val === "month"){
        this.date = moment().subtract(1, "months").toDate();
      }else if(val == "week"){
        this.date = moment().day(-6).toDate();
      }
    },
    // 获取账号信息
    getAccountInfo(){
      let accountInfo = getCompanyInfo();
      this.userName = accountInfo.userName;
      this.companyName = accountInfo.companyName;
      this.$http.get("directSale/getDirectSaleType").then(res => {
        if (res && res.code === 20000) {
          let startDate = moment(res.data.data.startDate);
          this.joinDate = moment().diff(startDate, "days");
        } else {
          let msg = res && res.msg ? res.msg : "数据请求出错";
          this.$message.error(msg);
        }
      });
      let currentUserInfo = localStorage.getItem("fund_master_current_user");
      let {userId} = currentUserInfo ? JSON.parse(currentUserInfo) : {};
      this.userId = userId;
    },
    // 获取需要导出的数据
    getExportData({data, name}){
      this.exportData[name] = JSON.parse(JSON.stringify(data));
    },
    // 导出
    exportReport(exportType){
      if(Object.keys(this.exportData).length !== 6){
        this.$message.error("请等待页面数据加载完毕");
        return;
      }
      this.$message.warning("正在导出报告，请稍后");
      this.loading = true;
      let optionMap = {
        word: {
          format: "docx",
          type: "word",
          url: `${this.$baseUrl[process.env.NODE_ENV]["host"]}/expapi/fm/word/prepare`
        },
        pdf: {
          format: "pdf",
          type: "pdf",
          url: `${this.$baseUrl[process.env.NODE_ENV]["host"]}/expapi/fm/pdf-img/prepare`
        },
        img: {
          format: "png",
          type: "img",
          url: `${this.$baseUrl[process.env.NODE_ENV]["host"]}/expapi/fm/pdf-img/prepare`,
          wkParams: {
            height: 1980,
            width: 1400
          }
        },
      }
      let params = {
        element: {
          storeData: Object.assign({},this.exportData, {
            startDate: this.startDate,
            endDate: this.endDate,
            userName: this.userName,
            companyName: this.companyName,
            joinDate: this.joinDate,
            periodType: this.periodType
          }),
          type: optionMap[exportType].type,
          title: "报告",
          userId: this.userId,
          format: optionMap[exportType].format,
          exportRouter: `${this.$baseUrl[process.env.NODE_ENV]["host"]}/pc/direct-sale/weekly-exports/index.html`,
        },
        wkParams: optionMap[exportType].wkParams || {
          width: "353.35mm",
          height: "499.8mm"
        }
      }
      // console.log(JSON.stringify(params));
      this.$http.post(optionMap[exportType].url, params).then((res) => {
        this.loading = false;
        if(res && res.success == true){
          let fileKey = res.fileKey;
          this.getReport(fileKey, optionMap[exportType].format);
        }
      })
    },
    getReport(fileKey, format){
      let url = `${this.$baseUrl[process.env.NODE_ENV]["host"]}/expapi/fm/getTmpFile/${this.userId}/${fileKey}/${this.startDate}~${this.endDate}获客报告/${format}`;
      $("iframe").attr("src", url).appendTo($("body")).css({
        display: "none"
      });
    },
    // 设置 highcharts 图形的层级，使得鼠标放上去的 tooltip 层级高于标签
    setHighchartsLableZindex(){
      $(".highcharts-point").on("mouseover", function(){
        $(this).parents(".highcharts-root").css({
          "z-index": 2
        })
      })
      $(".highcharts-point").on("mouseout", function(){
        $(this).parents(".highcharts-root").css({
          "z-index": 0
        })
      })
    },
    // 页面渲染完成的回调
    pageRenderedHandler(){
      this.timer = setInterval(() => {
        if(Object.keys(this.exportData).length === 6){
          clearInterval(this.timer);
            this.setHighchartsLableZindex();
        }
      }, 1000)
    },
    // 切换tab时重置table的layout
    clickTab(name){
      if(name == "customerData"){
        this.$refs.customerData[0].tableLayout();
      }
    },
    getPaidInfo(){
      let accountInfo = window.localStorage.getItem("fund_master_current_user");
      accountInfo = accountInfo ? JSON.parse(accountInfo) : {};
      let userCompanyApplicationIds = accountInfo.userCompanyApplicationIds || [];
      // if(userCompanyApplicationIds.indexOf("302") !== -1 || userCompanyApplicationIds.indexOf(302) !== -1){
        this.accountPaid = true;
      // }
    },
    // 判断本周一是否是上个月的某一天，如果是，则本周属于上个月的最后一周，上个月不可选
    lastMonthSelectable(){
      let firstDayOfCurrentWeek = moment().isoWeekday() === 7 ? moment().subtract(1, "days").day("Monday") : moment().day("Monday");
     return firstDayOfCurrentWeek.date(1).format("MM")=== moment().date(1).format("MM");
    },
    // 获取某一天所在月份的最后一周的最后一天
    getLastDayOfLastWeek(day = moment()){
      if(!moment.isMoment(day)) return;
      let lastDayOfMonth = day.endOf("month");
      return lastDayOfMonth.isoWeekday() === 7 ? lastDayOfMonth : lastDayOfMonth.day("Saturday").add(1, "days");
    }
  },
  watch: {
    dateGap: {
      handler(){
        this.exportData = {};
        this.pageRenderedHandler();
      }
    }
  },
  mounted() {
    this.getAccountInfo();
    this.pageRenderedHandler();
    this.getPaidInfo();
  },
  created() {
    
  },
};
</script>
<style lang="less" >
  .direct-sale-report .customer-data-container .company-inner-data .el-table{
    tbody{
      tr:nth-child(1){
        background-color: #102030;
      }
    }
  }
    .direct-sale-weekly{
      position: relative;
      height: 100%;
      background: #111;
      .weekly-tabs-container{
        background-color: #111;
      }
      .highcharts-root{
        position: relative;
        z-index: 0;
      }
      .highcharts-tooltip{
        z-index: 4;
      }
      .highcharts-axis-labels.highcharts-xaxis-labels{
        z-index: 1;
      }
      // 提示语
      .notice-text{
        margin-left: 10px; 
        font-size: 14px;
      }
      // 统计周期
      .analysis-period{
        padding: 10px 0 10px 10px;
        .select-period{
          margin-right: 8px;
        }
        
      }
      .el-tabs__item{
        width: 90px !important;
      }
      .export-data{
        display: flex;
        align-items: center;
        height: 40px;
        .export-icon{
          background: url("../../../assets/images/direct-sale-weekly/sprite.png") no-repeat;
          width: 20px;
          height: 22px;
          cursor: pointer;
          margin-left: 10px;
        }
        .export-pdf{
          background-position: -20px 0;
          &:hover{
            background-position: -40px 0;
          }
        }
        .export-word{
          background-position: -20px -22px;
          width: 18px;
          height: 18px;
          &:hover{
            background-position: -40px -22px;
          }
        }
        .export-img{
          background-position: -20px -40px;
          width: 18px;
          height: 18px;
          &:hover{
            background-position: -40px -40px;
          }
        }
      }
      .empty-data{
        position: absolute;
        left: 0;
        top: 0;
        z-index: 5;
        width: 100%;
        height: calc(~"100% - 30px");
        text-align: center;
        background-color: #111;
        margin-top: 30px;
        .empty-data-content{
          position: absolute;
          left: 50%;
          top: 50%;
          color: #999;
          transform: translate(-50%, -50%);
        }
      }
      .empty-data-container{
        img{
          opacity: 0;
        }
      }
    }
    .fix-width-label{
      display: block;
      width: 150px;
      text-align: right;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }
    .account-nopaid{
      background: url("../../../assets/images/weekly/unpaid.jpg") no-repeat;
      background-size: 100% auto;
      background-position: 0 0;
      position: relative;
      width: 100%;
      height: 100%;
      .mask-nopaid{
        width: 100%;
        height: 100%;
        position: absolute;
        left: 0;
        top: 0;
        right :0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.6);
      }
      .nopaid-notice{
        width: 400px;
        height: 120px;
        text-align: center;
        line-height: 120px;
        border: 1px solid #999;
        border-radius: 2px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
      }
    }
</style>