<template>
  <div class="customer-data-container">
    <div class="company-inner-data export-item">
      <vloading v-model="tableLoading"></vloading>
      <div class="inner-data-title">直营店客户数据统计</div>
      <vtable
        ref="customerTable"
        :columns="columns"
        :data="tableData"
        :maxHeight="exportStatus ? 10000 : maxHeight"
        :changeRowColor="true"
      ></vtable>
    </div>
    <div class="customer-data-graph-container export-item">
      <div class="empty-data" v-if="graphEmpty">
        <p class="empty-data-content">暂无数据</p>
      </div>
      <vloading v-model="graphLoading"></vloading>
      <div class="duration-data" id="durationData"></div>
      <div class="duration-data-legend">
        <div>与同行(直营店机构)</div>
        <div class="legend-row">
          <span class="legend-spot excellent"></span>
          <span class="text">优秀(比均值高)</span>
        </div>
        <div class="legend-row">
          <span class="legend-spot nice"></span>
          <span class="text">良好(与均值持平)</span>
        </div>
        <div class="legend-row">
          <span class="legend-spot normal"></span>
          <span class="text">一般(比均值低)</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Highcharts from "highcharts/highcharts.js";
// import Highcharts from "highcharts";
import getCommonConfig from "./common-config.js";

export default {
  props: {
    startDate: {
      type: String
    },
    endDate: {
      type: String
    },
    periodType: {
      type: String,
      default: "week"
    },
    dateGap: {
      type: String,
    },
    exportStatus: {
      type: Boolean,
      default: false
    },
    exportChartConfig: {
      type: Object,
      default: {}
    },
  },
  data() {
    return {
        weekConfig:  [
            {
                name: "星期一",
                data: [],
                color: "#88BBEE"
            },
            {
                name: "星期二",
                data: [],
                color: "#00AAFF"
            },
            {
                name: "星期三",
                data: [],
                color: "#FF99FF"
            },
            {
                name: "星期四",
                data: [],
                color: "#CC33CC"
            },
            {
                name: "星期五",
                data: [],
                color: "#FEED77"
            },
            {
                name: "星期六",
                data: [],
                color: "#FFAA01"
            },
            {
                name: "星期日",
                data: [],
                color: "#AA78FF"
            }
            ],
        monthConfig:  [
            {
                name: "第一周",
                data: [],
                color: "#88BBEE"
            },
            {
                name: "第二周",
                data: [],
                color: "#00AAFF"
            },
            {
                name: "第三周",
                data: [],
                color: "#FF99FF"
            },
            {
                name: "第四周",
                data: [],
                color: "#CC33CC"
            },
            {
                name: "第五周",
                data: [],
                color: "#FEED77"
            },
            {
                name: "第六周",
                data: [],
                color: "#FFAA01"
            },
            {
                name: "第七周",
                data: [],
                color: "#AA78FF"
            }
            ],
        chart: null,
        columns: [
            {
              key: "name",
              title: "",
              align: "left"
            },
            {
              key: "byFollowUser",
              title: "我关注的",
              align: "right",
            },
            {
              key: "likeUser",
              title: "点赞我的",
              align: "right",
            },
            {
              key: "followUser",
              title: "关注我的",
              align: "right",
            },
            {
              key: "replyUser",
              title: "客户首次回复",
              align: "right",
            },
            {
              key: "chatUser",
              title: "客户主动沟通",
              align: "right",
            },
            {
              key: "byChatUser",
              title: "主动沟通客户",
              align: "right",
            },
            {
              key: "viewUser",
              title: "查看我的",
              align: "right",
            },
        ],
        tableData: [],
        maxHeight: 175,
        tableLoading: false,
        graphLoading: false,
        graphEmpty: false,
        labelConfig: []
    };
  },
  mounted() {
    let chartConfig = getCommonConfig(this.config);
    this.chart = Highcharts.chart("durationData", chartConfig);
    if(this.exportStatus){
    }else{
      // this.setTabelHeight();
      this.getCustomerTableData();
      this.getCustomerGraphData();
    }
  },
  computed: {
    config(){
      let _this = this;
        return {
          type: "bar",
          seriesStacking: "normal",
          titleText: "本周客户数据分布",
          legendReversed: true,
          barDataLabelsEnabled: false,
          xAxisCategories: [
          "我关注的",
          "点赞我的",
          "关注我的",
          "客户首次回复",
          "客户主动沟通",
          "主动沟通客户",
          "查看我的",
          ],
          series:this.weekConfig,
          exportConfig: this.exportStatus ? this.exportChartConfig : {},
          legend: {
            // useHTML: true,
            align: "right", 
            verticalAlign: "top", 
            layout: "vertical",
            x: -2,
            y: 10,
            itemMarginBottom: 5
          },
      }
    },
  },
  methods: {
    // 获取tableData
    getCustomerTableData() {
      this.tableLoading = true;
      let params = {
        startDate: this.startDate || "2017-07-31",
        endDate: this.endDate || "2017-08-03",
      };
      this.$http.get("analysis/customer", params).then(res => {
        this.tableLoading = false;
        if (res.code === 20000 && res.data instanceof Array) {
            let tableData = res.data;
            this.$emit("getExportData", {data: tableData, name: "customerTableData"});
            this.updateTable(tableData);
        } else {
          this.$message.error(
            res.msg ? res.msg : "数据获取失败，请刷新重试或联系客服"
          );
        }
      });
    },
    // 获取图表data
    getCustomerGraphData() {
      let params = {
        // startDate: "2019-07-22",
        // endDate: "2019-07-28",
        startDate: this.startDate || "2017-07-31",
        endDate: this.endDate || "2017-08-03",
        statInterval: "day"
        // statInterval: this.periodType
      };
      this.graphLoading = true;
      this.$http.get("analysis/customerChart", params).then(res => {
        this.graphLoading = false;
        if(res.code === 20000){
            let data = res.data;
            this.$emit("getExportData", {data, name: "customerGraphData"});
            this.updateGraph(data);
        }
      });
    },

    // 获取公司各项指标和市场均值的对比情况
    getLabelConfig({byFollowUser,likeUser, followUser, replyUser, chatUser, byChatUser, viewUser}){
      return [
        (byFollowUser.self)-(byFollowUser.market),
        (likeUser.self)-(likeUser.market),
        (followUser.self)-(followUser.market),
        (replyUser.self)-(replyUser.market),
        (chatUser.self)-(chatUser.market),
        (byChatUser.self)-(byChatUser.market),
        (viewUser.self)-(viewUser.market)
      ]
    },

    // 验证数据是否是空数据
    validateData(data){
      let validArr = [];
      for(let key in data){
        validArr.push(data[key].some((item) => {
          return item != 0
        }))
      };
      return validArr.indexOf(true) !== -1;
    },
    // 更新 graph，seriesData 可能长度有变化，因此需要对 series 做增减
    updateGraph(data){
      this.graphEmpty = !this.validateData(data.buckets);
      if(this.graphEmpty)return;
      let _this = this;
      let labelConfig = this.getLabelConfig(data.label);
      let handlerMap = {
        "week": "getWeekConfig",
        "month": "getMonthConfig",
      }
      let seriesConfig = this[handlerMap[this.periodType]](data.buckets);
      let series = this.chart.series;
      if(series.length > seriesConfig.length){
        for(let i = series.length; i > seriesConfig.length; i--){
          this.chart.series[i - 1].remove();
        }
      }else if (series.length < seriesConfig.length){
        for(let i = series.length; i < seriesConfig.length ; i++){
          this.chart.addSeries({})
        }
      }
      this.chart.update({
        series: seriesConfig.reverse()
      })
      this.chart.xAxis[0].update({
        labels:{
          formatter: function(){
            let className = "default";
            if(labelConfig[this.pos] > 0){
              className = "legend-excellent"
            }else if (labelConfig[this.pos] < 0){
              className = "legend-normal"
            }else if (labelConfig[this.pos] == 0){
              className = "legend-nice"
            }
            return `<span class="fix-width-label custom-legend ${className}" title=${this.value}>${this.value}</span>`
          }
        }
      })
      let periodMap = {
        "week": "周",
        "month": "月",
      }
      this.chart.setTitle({text: `本${periodMap[this.periodType]}客户数据分布`});
      // 更新图例位置
      setTimeout(() => {
        this.updateCustomLegendPosition();
      }, 400);
    },
    updateCustomLegendPosition(){
      $(".duration-data-legend").css({
        top: +($("#durationData .highcharts-legend .highcharts-legend-box").attr("height")) + 40,
        display: "block"
      })
    },
    updateTable(data){
      if(!data.length){
        this.tableData = [];
        return;
      }
      let sumData = {
          byChatUser: 0,
          replyUser: 0,
          chatUser: 0,
          viewUser: 0,
          followUser: 0,
          likeUser: 0,
          byFollowUser: 0,
          name: "我司"
      };
      data.forEach((item, index) => {
          sumData.byChatUser += +item.byChatUser;
          sumData.replyUser += +item.replyUser;
          sumData.chatUser += +item.chatUser;
          sumData.viewUser += +item.viewUser;
          sumData.followUser += +item.followUser;
          sumData.likeUser += +item.likeUser;
          sumData.byFollowUser += +item.byFollowUser;
      })
      data.unshift(sumData);
      this.tableData = data;
    },
    // 获取周视图的 series 配置
    getWeekConfig(data){
        let {byChatUser, replyUser, chatUser, viewUser, followUser, byFollowUser, likeUser} = data;
        return this.weekConfig.map((item, index) => {
            let seriesData =  [
                    byFollowUser[index],
                    likeUser[index],
                    followUser[index],
                    replyUser[index],
                    chatUser[index],
                    byChatUser[index],
                    viewUser[index],
                ]
            return {
                name: item.name,
                color: item.color,
                data: seriesData
            }
        });
    },
    // 获取月视图的 series 配置
    getMonthConfig(data){
        let monthData = this.getTermData(data, 7);
        let {byChatUser, replyUser, chatUser, viewUser, followUser, byFollowUser, likeUser, length} = monthData;
        return this.monthConfig.slice(0, length).map((item, index) => {
            let seriesData =  [
              byFollowUser[index],
              likeUser[index],
              followUser[index],
              replyUser[index],
              chatUser[index],
              byChatUser[index],
              viewUser[index],
            ]
            return {
                name: item.name,
                color: item.color,
                data: seriesData
            }
        });
    },
    // 根据数据的每个字段的某个时间区间的数组，计算出每一个周期的加总值
    getTermData(data, term){
        for( let key in data){
            let tempArr = [];
            let index = -1;
            for(let i = 0; i < data[key].length; i++){
                // 当过完每一个周期，tempArr 向后移动一位，然后开始本周期的加总
                if(i % term === 0){
                    index++;
                    tempArr[index] = 0;
                }
                tempArr[index] += +(data[key][i]);
            }
            data[key] = tempArr;
            data.length = index + 1;
        }
        return data;
    },
    tableLayout(){
      this.$nextTick(() => {
        this.$refs.customerTable.doLayout();
      })
    }
  },
  watch: {
    dateGap: {
        handler(val) {
            this.getCustomerTableData();
            this.getCustomerGraphData();
        }
    },
  }
};
</script>
<style lang="less">
.customer-data-container {
  height: 100%;
  .company-inner-data {
    position: relative;
    margin-top: 15px;
    padding-right: 10px;
    .inner-data-title {
      text-align: center;
      color: #eee;
      font-size: 12px;
      margin-bottom: 10px;
    }
  }
  .duration-data {
    height: 400px;
    padding-top: 18px;
  }
  .customer-data-graph-container{
    position: relative;
    padding-right: 50px;
    .duration-data-legend{
      position: absolute;
      right: 10px;
      // top: 192px;]
      display: none;
      border-top: 1px solid #999;
      padding-top: 10px;
      color: #999;
      .legend-row{
        margin-top: 10px;
      }
      .legend-spot{
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        margin-right: 5px;
        &.excellent{
          background-color: #88ACFF;
        }
        &.nice{
          background-color: #348AFE;
        }
        &.normal{
          background-color: #0034FD;
        }
      }
    }
    
  }
  .custom-legend{
      position: relative;
      overflow: inherit;
      margin-right: 10px;
      &::after{
        content: "";
        position: absolute;
        width: 10px;
        height: 10px;
        right: -13px;
        top: 3px;
        z-index: 5;
        border-radius: 50%;
      }
    }
    .legend-excellent{
      // color: #88ACFF;
      &::after{
        background-color: #88ACFF;
      }
    }
    .legend-nice{
      // color: #348AFE;
      &::after{
        background-color: #348AFE;
      }
    }
    .legend-normal{
      // color: #0034FD;
      &::after{
        background-color: #0034FD;
      }
    }
}
</style>
