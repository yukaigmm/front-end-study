import { Z_BLOCK } from "zlib";

let common = {
    lineColor: '#252525',
    lineWidth: "1",
    tickWidth: 1,
    tickColor: '#252525',
    gridLineWidth: 1,
    gridLineColor: '#252525',
    gridLineDashStyle: 'ShortDash'
};
let style = {
    fontFamily: 'Microsoft YaHei',
    fontSize: '12px',
    color: '#999',
    y: 10
}
let titleStyle = {
    fontFamily: 'Microsoft YaHei',
    fontSize: '12px',
    color: '#eee',
}
let tooltipStyle = {
    enabled: true,
    // followPointer: true,
    backgroundColor: 'rgba(0,0,0,.75)',
    borderColor: '#555',
    style: {
        fontSize: "12px",
        color: '#999',
        fontWeight: 'normal',
        position: "absolute",
    },
    useHTML:  true,

}
let legendStyle = {
    symbolRadius: 0,
    itemStyle: Object.assign({}, style, { fontWeight: 'normal' }),
    symbolHeight: 10,
    symbolWidth: 10,
    symbolPadding: 10,
    itemHoverStyle: '#999',
    padding: 5,
}
let commonYAxis = Object.assign({}, common, {
    tickLength: 10,
    x: -12,
    title: {
        text: null,
        style,
    },
    labels: {
        style,
    },
    allowDecimals: false,
    floor: 0,
    endOnTick: false
})
function getPieConfig(config) {
    let {exportCommonConfig = {}, exportTitleStyle = {}} = config.exportConfig
    return {
        plotOptions: {
            pie: {
                allowPointSelect: true,
                size: '100%',
                cursor: 'pointer',
                borderWidth: 0,
                dataLabels: {
                    distance: 14,
                    style: Object.assign({}, style, {'fontWeight': 'normal', 'textOutline': ''}),
                    format: "{point.percentage:.1f} %"
                },
                point: {
                    events: {}
                },
                showInLegend: true
            }
        },
        chart: {
            type: 'pie',
            backgroundColor: "transparent"
            // backgroundColor: '#111111'
        },
        title: {
            text: config.titleText,
            style: Object.assign({}, titleStyle, exportTitleStyle),
        },
        tooltip: Object.assign({}, tooltipStyle, {pointFormat: config.tooltipPointFormat}),
        credits: {
            enabled: false
        },
        legend: {
            align: "right",
            layout: "vertical",
            verticalAlign: "middle",
            // 图例圆角弧度
            symbolRadius: 0,
            itemMarginBottom: 10,
            itemStyle: {
                color: '#999',
                fontWeight: 'normal',
                fontSize: '12px',
            },
            itemHoverStyle: {
                color: '#999'
            }
        },
        series: config.series,
    }
}
function getBarConfig(config) {
    let {exportCommonConfig = {}, exportTitleStyle = {}} = config.exportConfig;
    return {
        plotOptions: {
            series: {
                stacking: config.seriesStacking,
                fillOpacity: 1,
                enableMouseTracking: true,
                borderWidth: 0,
                connectNulls: true,
                states: {
                    hover: {
                        lineWidth: 2,
                    }
                },
                // 值为0 时的高度
                minPointLength: 3,
                // 每根柱子的宽度
                pointWidth: config.barPointWidth || 18
            },
            line: {
                lineWidth: 2,
                marker: {
                    enabled: false
                },
                shadow: false,
                threshold: null
            },
            area: {
                stacking: 'normal',
                lineWidth: 0,
                states: {
                    hover: {
                        lineWidth: 0
                    }
                },
                marker: {
                    enabled: false
                }
            },
            bar:{
                dataLabels: {
                    enabled: config.barDataLabelsEnabled === false ? false : true,
                    // allowOverlap: true, // 允许数据标签重叠,
                    style: {
                        textOutline: "none",
                        fontWeight: 'normal',
                        color: "#999"
                    },
                }
            }
        },
        chart: {
            marginTop: 25,
            backgroundColor: 'transparent',
            style,
            type: "bar",
            // marginLeft: 100,
            // marginRight: 50,
        },
        title: {
            style: Object.assign({}, titleStyle, exportTitleStyle),
            text: config.titleText,
            y: 0
        },
        xAxis: Object.assign({}, common, exportCommonConfig, {
            tickLength: 10,
            minPadding: 0.0001,
            startOnTick: false,
            alternateGridColor: exportCommonConfig.alternateGridColor || 'rgba(51,51,51,.1)',
            labels: {
                style:Object.assign({}, style, 
                    {
                        display: "block",
                        zIndex: "0"
                }, exportCommonConfig.labelStyle),
                formatter: function(){
                    return `<span class="fix-width-label" title=${this.value}>${this.value}</span>`
                },
                useHTML: true,
            },
            title: {
                style,
            },
            categories: config.xAxisCategories
        }),
        yAxis: Object.assign({}, commonYAxis, exportCommonConfig),
        tooltip: Object.assign({},tooltipStyle,{hideDelay: 0}),
        // 版权标签
        credits: {
            enabled: false
        },
        legend: Object.assign({}, legendStyle, 
            { 
                reversed: config.legendReversed , 
                enabled: config.legendEnabled == false ? false: true , 
                // useHTML: true,
                // align: "right", 
                // verticalAlign: "middle", 
                // layout: "vertical", x: 0,
                // format(value){
                //     console.log(value)
                //     return ""
                // }
            },config.legend),
        series: config.series,
    }
}
function getCommonConfig(config) {
    let map = {
        pie: getPieConfig,
        bar: getBarConfig
    }
    return map[config.type](config)
}
export default getCommonConfig;
