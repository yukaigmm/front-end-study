<template>
    <div class="compare-data-container export-item">
        <div class="empty-data" v-if="graphEmpty">
            <p class="empty-data-content">暂无数据</p>
        </div>
        <vloading v-model="loading"></vloading>
        <div class="compare-graph" id="compareGraph"></div>
    </div>
</template>
<script>
import Highcharts from "highcharts";
import getCommonConfig from "./common-config.js";
import moment from "moment";
export default {
    props: {
        startDate: {
            type: String
        },
        endDate: {
            type: String
        },
        periodType: {
            type: String
        },
        dateGap: {
            type: String
        },
        exportStatus: {
            type: Boolean
        },
        exportChartConfig: {
            type: Object,
            default: {}
        },
    },
    data(){
        return {
            series:[
                {
                    name: "本公司",
                    data: [],
                    color: "#FF4455"
                },
                {
                    name: "市场平均",
                    data: [],
                    color: "#88BBEE"
                },
            ],
            loading: false,
            chart: null,
            graphEmpty: false,
        }
    },
    computed: {
        compareConfig(){
            return {
                type: "bar",
                // titleText: "本周客户数据分布",
                xAxisCategories: [],
                series: this.series,
                exportConfig: this.exportStatus ? this.exportChartConfig : {},
                barPointWidth: 12
            }
        }
    },
    mounted() {
        let compareConfig = getCommonConfig(this.compareConfig);
        this.chart = Highcharts.chart('compareGraph', compareConfig);
        if(this.exportStatus){
        }else{
            this.getCompareGraphData();
        }
    },
    methods: {
        getCompareGraphData(){
            let params = {
                startDate: this.startDate,
                endDate: this.endDate
            }
            this.loading = true;
            this.$http.get("analysis/customerAvg", params).then((res) => {
                this.loading = false;
                if(res.code === 20000){
                    let data = [res.data.self, res.data.market];
                    this.$emit("getExportData", {data, name: "compareGraphData"});
                    this.updateGraph(data);
                }
            })
        },
        validateGraphData(data){
            return data.some((item) => {
                let flag = false;
                for(let key in item){
                    if(!!item[key] && item[key] != "0"){
                        flag = true;
                    }
                }
                return flag;
            })
        },
        updateGraph(data){
            this.graphEmpty = !this.validateGraphData(data);
            if(this.graphEmpty){
                return;
            }
            this.series.forEach((item, index) => {
                let dataItem = data[index];
                let categories = [
                    `近${moment(this.endDate).diff(moment(this.startDate), "days")+1}天活跃天数`,
                    "我关注的客户数",
                    "点赞我的客户数",
                    "关注我的客户数",
                    "客户首次回复数",
                    "客户主动沟通数",
                    "主动沟通客户数",
                    "查看我的客户数",
                    "查看公司相关用户数",
                ];
                this.chart.series[index].setData([
                    Math.ceil(+data[index].activeUser) || 0,
                    Math.ceil(+data[index].byFollowUser) || 0,
                    Math.ceil(+data[index].likeUser) || 0,
                    Math.ceil(+data[index].followUser) || 0,
                    Math.ceil(+data[index].replyUser) || 0,
                    Math.ceil(+data[index].byChatUser) || 0,
                    Math.ceil(+data[index].chatUser) || 0,
                    Math.ceil(+data[index].viewUser) || 0,
                    Math.ceil(+data[index].user) || 0,
                ]);
                this.chart.xAxis[0].setCategories(categories);
                // this.chart.update();
            })
        }
    },
    watch: {
        dateGap: {
            handler(val){
                console.log("dateGap")
                this.getCompareGraphData();
            }
        },
        // periodType: {
        //     handler(val){
        //         this.getCompareGraphData();
        //     }
        // },
    },
}
</script>
<style lang="less" scoped>
    .compare-graph{
        height: 640px;
    }
    .compare-data-container{
        padding-right: 50px;
        position: relative;
    }
</style>
