
let common = {
    lineColor: '#252525',
    lineWidth: "1",
    tickWidth: 1,
    tickColor: '#252525',
    gridLineWidth: 1,
    gridLineColor: '#252525',
    gridLineDashStyle: 'ShortDash'
};
let style = {
    fontFamily: 'Microsoft YaHei',
    fontSize: '12px',
    color: '#999'
}
let  titleStyle = {
    fontFamily: 'Microsoft YaHei',
    fontSize: '12px',
    color: '#eee'
}
let tooltiopStyle = {
    enabled: true,
    backgroundColor: 'rgba(0,0,0,.75)',
    borderColor: '#555',
    style: {
      fontSize: "12px",
      color: '#999',
      fontWeight: 'normal'
    }
}
let legendStyle = {
    symbolRadius: 0,
    itemStyle: Object.assign({}, style, {fontWeight: 'normal'}),
    symbolHeight: 10,
    symbolWidth: 10,
    symbolPadding: 10,
    itemHoverStyle: '#999',
    padding: 5,
}
let commonYAxis = Object.assign({}, common, {
    tickLength: 10,
    x: -12,
    title: {
        text: null,
        style,
    },
    labels: {
        style,
    }
})

// -----------
function getCommonConfig (config) {
    return {
        plotOptions: {
            series: {
                fillOpacity: 1,
                enableMouseTracking: true,
                borderWidth: 0,
                connectNulls: true,
                states: {
                    hover: {
                        lineWidth: 2,
                    }
                }
            },
            line: {
                lineWidth: 2,
                marker: {
                    enabled: false
                },
                shadow: false,
                threshold: null
            },
            area: {
                stacking: 'normal',
                lineWidth: 0,
                states: {
                    hover: {
                        lineWidth: 0
                    }
                },
                marker: {
                    enabled: false
                }
            }
        },
        chart: {
            marginTop: 20,
            backgroundColor: 'transparent',
            style,
        },
        title: {
            text: null,
            style: titleStyle,
        },
        xAxis: Object.assign({}, common, {
            tickLength: 10,
            minPadding: 0.0001,
            startOnTick: false,
            alternateGridColor: 'rgba(51,51,51,.1)',
            labels: {
                style,
            },
            title: {
                style,
            }
        }),
        yAxis:commonYAxis,
        tooltip: tooltiopStyle,
        credits: {
            enabled: false
        },
        legend: legendStyle,
    }
}
export default  getCommonConfig;
