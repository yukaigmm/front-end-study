<template>
    <div class="search-data-container">
        <div class="view-details export-item">
            <div class="view-table">
                <div class="inner-data-title">全站用户查看贵司相关详情数据统计</div>
                <vloading v-model="tableLoading"></vloading>
                <vtable
                    ref="table"
                    :columns="columns"
                    :data="tableData"
                    :maxHeight="maxHeight"
                    :changeRowColor="true"
                ></vtable>
            </div>
            <div class="view-graph">
                <div class="empty-data" v-if="viewDetailEmpty">
                    <p class="empty-data-content">暂无数据</p>
                </div>
                <vloading v-model="viewDetailLoading"></vloading>
                <div id="viewDetail"></div>
            </div>
        </div>
        <div class="search-details export-item">
            <vloading v-model="searchLoading"></vloading>
            <div class="customer-search-container" style="position: relative">
                <div class="empty-data" v-if="customerSearchEmpty">
                    <p class="empty-data-content">暂无数据</p>
                </div>
                <div id="customerSearch"></div>
            </div>
            <div class="view-product">
                <div class="empty-data" v-if="viewProductEmpty">
                    <p class="empty-data-content">暂无数据</p>
                </div>
                <div id="viewProduct"></div>
            </div>
        </div>
    </div>
</template>
<script>
import Highcharts from "highcharts";
import getCommonConfig from "./common-config.js";
import customerDataVue from './customer-data.vue';
export default {
    props: {
        startDate: {
            type: String
        },
        endDate: {
            type: String
        },
        dateGap: {
            type: String
        },
        exportStatus: {
            type: Boolean
        },
        exportChartConfig: {
            type: Object,
            default: {}
        },
        periodType: {
            type: String
        }
    },
    data(){
        return {
            viewDetailGraph: null,
            customerSearchGraph: null,
            viewProductGraph: null,
            tableLoading: false,
            viewDetailLoading: false,
            searchLoading: false,
            columns: [
                {key: "name", title: "", align: "left"},
                {key: "pc", title: "PC", align: "right"},
                {key: "app", title: "APP", align: "right"},
                // {key: "mobile", title: "移动站", align: "right"},
            ],
            tableData: [],
            viewDetailEmpty: false,
            customerSearchEmpty: false,
            viewProductEmpty: false,
        }
    },
    computed: {
        viewDetailConfig(){
            return {
                type: "pie",
                titleText: "查看明细数据来源",
                series: [{
                    name: 'Brands',
                    colorByPoint: true,
                    data: []
                }],
                tooltipPointFormat: '占比: <b>{point.percentage:.1f}%</b>',
                exportConfig: this.exportStatus ? this.exportChartConfig : {},
            }
        },
        customerSearchConfig(){
            return {
                type: "bar",
                titleText: "客户搜索贵司相关-top5",
                legendEnabled: false,
                xAxisCategories: [],
                series: [
                     {
                        name: "搜索次数",
                        data: [],
                        color: "#88BBEE"
                    }
                ],
                exportConfig: this.exportStatus ? this.exportChartConfig : {},
            }
        },
        viewProductConfig(){
            return {
                type: "bar",
                titleText: "客户查看贵司产品详情-top5",
                legendEnabled: false,
                xAxisCategories: [],
                series: [
                     {
                        name: "查看次数",
                        data: [],
                        color: "#88BBEE"
                    }
                ],
                exportConfig: this.exportStatus ? this.exportChartConfig : {},
            }
        }
    },
    methods: {
        // 获取tableData
        getSearchTableData(){
            let params = {
                startDate: this.startDate  || "2017-07-31",
                endDate: this.endDate  || "2017-08-03",
                statInterval: this.periodType
            }
            this.tableLoading = true;
            this.$http.get("analysis/flowDetails", params).then((res) => {
                this.tableLoading = false;
                if(res.code === 20000){
                    let {pc = {}, app = {}} = res.data;
                    let tableData = [];
                    let graphData = {};
                    if(!this.validateTableData(res.data)){
                        tableData = [];
                    }else{
                        tableData = [
                            {name: "公司详情",key: "company"},
                            {name: "产品详情", key: "product"},
                            {name: "经理详情", key: "manager"},
                            // {name: "路演详情", key: "roadshow"},
                        ];
                        tableData = tableData.map((item, index) => {
                            return {
                                name: item.name,
                                pc: pc[item.key] || 0,
                                app: app[item.key] || 0,
                            }
                        });
                        graphData = {
                            pc: (pc.company || 0) + (pc.product || 0) + (pc.manager || 0),
                            app: (app.company || 0) + (app.product || 0) + (app.manager || 0),
                        }
                    }
                    this.$emit("getExportData", {data:tableData, name: "searchTableData"});
                    this.tableData = tableData;
                    this.$emit("getExportData", {data: graphData, name: "viewDetailGraphData"});
                    this.updateGraph("viewDetailGraph", graphData);
                }else{
                    this.$message.error(res.msg || "数据请求失败，请刷新重试或联系客服");
                }
            })
        },
        validateTableData(data){
            let flag = false;
            for(let key in data){
                for(let k in data[key]){
                    if(data[key][k]){
                        flag = true;
                    }
                }
            }
            return flag;
        },
        // 查看明细数据来源
        getViewDetailData(){
            let params = {
                startDate: this.startDate || "2017-07-31",
                endDate: this.endDate || "2017-08-03",
                statInterval: this.periodType
            }
            this.viewDetailLoading = true;
            this.$http.get("analysis/flow", params).then((res) => {
                this.viewDetailLoading = false;
                if(res.code === 20000){
                    let resData = res.data;
                    this.$emit("getExportData", {data: resData, name: "viewDetailGraphData"});
                    this.updateGraph("viewDetailGraph", resData)
                    // this.$emit("getExportData", {data: graphData, name: "viewDetailGraphData"});
                    // this.updateGraph("viewDetailGraph", graphData)
                }else{
                    this.$message.error(res.msg || "数据请求失败，请刷新重试或联系客服");
                }
            })
        },
        
        // 客户搜索贵司相关
        getSearchGraphData(){
            let params = {
                startDate: this.startDate || "2017-07-31",
                endDate: this.endDate || "2017-08-03",
                statInterval: this.periodType
            };
            this.searchLoading = true;
            this.$http.get("analysis/flowSearch",params).then((res) => {
                this.searchLoading = false;
                if(res.code === 20000){
                    let {company, product} = res.data;
                    this.$emit("getExportData", {data:company, name: "customerSearchData"})
                    this.$emit("getExportData", {data: product, name: "viewProductData"})
                    this.updateSeriesAndData("customerSearchGraph", company);
                    this.updateSeriesAndData("viewProductGraph", product);
                }else{
                    this.$message.error(res.msg || "数据请求失败，请刷新重试或联系客服");
                }
            })
        },
        updateTable(data){
            this.tableData = data;
        },
        // 更新饼图
        updateGraph(graphName, resData){
            let {app, pc} = resData;
            if(!(app || pc)){
                this.viewDetailEmpty = true;
                return;
            }else{
                this.viewDetailEmpty = false;
            }
            let data = [
                {name: "PC", key: 'pc', color: "#88BBEE"},
                {name: "APP", key: 'app', color: "#00AAFF"},
                // {name: "移动站", key: 'mobile', color: "#FF99FF"},
            ];
            let graphData = data.map((item, index) => {
                return {
                    name: item.name,
                    y: resData[item.key],
                    color: item.color
                }
            })
            this[graphName].series[0].setData(graphData);
        },

        updateSeriesAndData(graphName, data){
            let graphMap = {
                customerSearchGraph: "customerSearchEmpty",
                viewProductGraph: "viewProductEmpty",
            }
            if(data.length){
                this[graphMap[graphName]] = false;
            }else{
                this[graphMap[graphName]] = true;
                return;
            }
            let categories = [];
            let seriesData = [];
            data.forEach((item) => {
                categories.push(item.title);
                seriesData.push(item.value);
            })
            this[graphName].xAxis[0].setCategories(categories);
            this[graphName].series[0].setData(seriesData);
        },
        initPageData(){
            this.getSearchTableData();
            // this.getViewDetailData();
            this.getSearchGraphData();
        }
    },
    mounted() {
        let viewDetailConfig = getCommonConfig(this.viewDetailConfig);
        this.viewDetailGraph = Highcharts.chart('viewDetail', viewDetailConfig);

        let customerSearchConfig = getCommonConfig(this.customerSearchConfig);
        this.customerSearchGraph = Highcharts.chart('customerSearch', customerSearchConfig);

        let viewProductConfig = getCommonConfig(this.viewProductConfig);
        this.viewProductGraph = Highcharts.chart('viewProduct', viewProductConfig);
        
        if(!this.exportStatus){
            this.initPageData()
        }
    },
    watch: {
        dateGap: {
            handler(val){
                this.initPageData()
            }
        },
        // periodType: {
        //     handler(val){
        //         this.initPageData()
        //     }
        // },
    }
}
</script>
<style lang="less" scoped>
.search-data-container{
    background-color: #000;
}
    .view-details{
        height: 196px;
        margin-top: 15px;
        margin-bottom: 1px;
        .inner-data-title{
            margin-bottom: 10px;
        }
    }
    .view-graph,.view-table,.customer-search-container,.view-product{
        background-color: #111;
        height: 100%;
        width: calc(~"50% - 2px");
        float: left;
        text-align: center;
        position: relative;
    }
    .view-table,.customer-search-container{
        margin-right: 1px;
    }
    #viewDetail{
        height: 100%;
    }

    .search-details{
        height: 430px;
        .customer-search-container,.view-product{
            padding-top: 18px;
            padding-right: 50px;
        }
        // background-color: #111;
    }
</style>
