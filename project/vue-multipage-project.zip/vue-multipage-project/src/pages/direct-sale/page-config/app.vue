<template>
  <vcommon
    :menuParentKey="currentMenuParentKey"
    :menuChildKey="currentMenuChildKey"
    class="direct-sale-page-config"
  >
    <vpart :title="`店铺装修${companyName}`">
      <div slot="action" v-if="showPageButtons">
        <template v-for="(item, index) in pageButtonConfig">
          <vbutton
            :key="index"
            :active="item.active"
            @click="item.clickHandler"
            v-if="!item.hide"
          >{{item.title}}</vbutton>
        </template>
      </div>
      <div class="page-config-container">
        <!-- 添加按钮 -->
        <div class="config-buttons-container">
          <div class="config-title">添加模块</div>
          <div class="button-area">
            <div
              v-for="(item, index) in addButtonConfig"
              :key="index"
              class="add-module-button"
              :class="{
                lock: item.ultimate && !isUltimate,
                [item.moduleName]:true
              }"
              active
              :title="item.title"
              @click="addModule(item.moduleName, item.ultimate)"
              v-show="!item.hide"
            >{{item.title}}</div>
          </div>
          <!-- <vbutton
              v-for="(item, index) in addButtonConfig"
              :key="index"
              class="add-module-button"
              :class="{lock: item.ultimate && !isUltimate}"
              active
              :title="item.title"
              @click="addModule(item.moduleName, item.ultimate)"
            >
              +{{item.title}}
          </vbutton>-->
        </div>
        <!-- 页面预览 -->
        <div class="page-layout">
          <div class="page-preview-container">
            <div class="page-preview-scroll-wrapper">
              <div class="page-preview-wrapper">
                <!-- <div class="page-title">
                  <div class="home-page">首页</div>
                  <div class="normal">产品</div>
                  <div class="normal">经理</div>
                  <div class="normal">档案</div>
                  <div class="normal">路演</div>
                  <div class="normal">点评</div>
                </div>-->
                <div
                  v-for="(item, index) in pageData"
                  :key="item.compKey"
                  :class="{'module-content':true,'active': index == currentIndex}"
                  @click="selectModule(index,currentIndex)"
                >
                  <div class="warning-icon" v-if="item.validate === false" title="该模块有必填项未填"></div>
                  <component :is="item.name" :moduleData="item"></component>
                  <div class="toolbar-container">
                    <div class="side-toolbar" v-if="item.name!='pageHeader' && item.name!='tabs' ">
                      <span class="move-arrow up-arrow" @click.stop="moveUp(index)"></span>
                      <span class="move-arrow down-arrow" @click.stop="moveDown(index)"></span>
                      <span class="del-icon" @click="deleteModule(index)"></span>
                    </div>
                  </div>
                  <div class="module-name" @click="(e)=> {e.stopPropagation()}">{{item.moduleTitle}}</div>
                </div>
              </div>
            </div>
          </div>

          <div class="page-edit-container">
            <div class="setting-title">模块设置</div>
            <page-config-form
              v-if="currentIndex !== -1"
              class="page-config-form"
              :formData="pageData[currentIndex]"
              :which-comp="pageData[currentIndex].name"
              @getFormData="getModuleData"
            />
          </div>
        </div>
      </div>
    </vpart>
    <vloading v-model="loading" />
  </vcommon>
</template>

<script>
import notice from "./components/notice/index.vue";
import tabs from "./components/tabs/index";
import hotPoint from "./components/hot-point/index.vue";
import ad1 from "./components/ad/ad1/index.vue";
import ad2 from "./components/ad/ad2/index.vue";
import ad from "./components/ad/index.vue";
import viewPoint from "./components/view-point/index.vue";
import product from "./components/product/index.vue";
import pageConfigForm from "./components//page-form-wrapper.vue";
import pageHeader from "./components/header/index";
import "./app.less";
import templateConfig from "./template-config.js";
import { getCompanyInfo } from "../../../common/js/utils.js";
import _ from "lodash";
export default {
  components: {
    pageConfigForm,
    notice,
    ad1,
    ad2,
    hotPoint,
    viewPoint,
    product,
    ad,
    pageHeader,
    tabs
  },
  data() {
    return {
      currentMenuParentKey: "directSale",
      currentMenuChildKey: "pageConfig",
      // 在页面处于不同状态，显示不同的页面操作按钮
      moduleConfig: [
        {
          moduleTitle: "页头",
          moduleName: "pageHeader",
          hide: true
        },
        {
          moduleTitle: "标签页",
          moduleName: "tabs",
          hide: true
        },
        {
          moduleTitle: "公告模块",
          moduleName: "notice"
        },
        {
          moduleTitle: "热点模块",
          moduleName: "hotPoint",
          ultimate: true
        },
        {
          moduleTitle: "广告模块",
          moduleName: "ad",
          ultimate: true,
          children: [{ moduleName: "ad1" }, { moduleName: "ad2" }]
        },
        {
          moduleTitle: "产品模块",
          moduleName: "product"
        },
        {
          moduleTitle: "观点模块",
          moduleName: "viewPoint"
        }
      ],
      pageData: [],
      currentIndex: -1,
      currentModuleOptions: [],
      addButtonConfig: [],
      moduleMap: {},
      bodyHeight: $("body").height() * 0.95 + "px",
      publish: false,
      isUltimate: false,
      preIndex: -1,
      showPageButtons: false,
      companyName: "",
      loading: false
    };
  },
  computed: {
    pageButtonConfig() {
      return [
        {
          title: "停用",
          active: true,
          clickHandler: this.stopUse,
          hide: !this.publish
        },
        { title: "保存草稿", active: true, clickHandler: this.saveDraft },
        { title: "发布", active: true, clickHandler: this.handlePublish }
      ];
    }
  },
  methods: {
    getPageData() {
      // 正常情况，正常组装数据，
      // 接口返回 40010 说明没有草稿，用户是第一次使用，根据用户是否是旗舰店用户选择对应的默认模板
      this.$http.get("directSale/getDraft").then(res => {
        if (res && res.code === 20000) {
          if (res.data.configStatus == 1) {
            this.publish = true;
          }
          if (
            res.data.moduleData instanceof Array &&
            res.data.moduleData.length
          ) {
            this.pageData = res.data.moduleData.map(item => {
              return JSON.parse(item);
            });
          }
        } else if (res.code === 40010) {
          if (this.isUltimate) {
            this.pageData = templateConfig.ultimate;
          } else {
            this.pageData = templateConfig.normal;
          }
        } else {
          let msg = res && res.msg ? res.msg : "数据请求出错";
          this.$message.error(msg);
        }
        this.configPageData();
      });
    },
    // 编辑右侧表单时，左边视图同时改变
    getModuleData(data, changeByValidate) {
      if (changeByValidate) {
        if (this.preIndex !== -1) {
          if (this.pageData[this.preIndex].compKey == data.compKey) {
            this.$set(this.pageData, this.preIndex, data);
          }
        }
      } else {
        this.$set(this.pageData, this.currentIndex, data);
      }
    },
    // 选中添加模块
    addModule(moduleName, ultimate) {
      if (ultimate && !this.isUltimate) {
        this.$message.error("非旗舰店用户无法使用此模块");
        return;
      }
      let addItem = {
        name: moduleName,
        moduleTitle: this.moduleMap[moduleName],
        compKey: `${moduleName}${Date.now().toFixed(0)}`
      };
      if (this.currentIndex === -1) {
        this.currentIndex = this.pageData.length - 1;
      }
      this.pageData.splice(this.currentIndex + 1, 0, addItem);
      this.selectModule(this.currentIndex + 1, this.currentIndex);
      this.setCurrentModulePosition();
    },
    // 选中当前模块
    selectModule(index, preIndex) {
      this.preIndex = preIndex;
      this.currentIndex = index;
    },
    // 模块上移下移
    moveUp(index) {
      if (index == 0 || index == 2) return;
      let moveItem = this.pageData.splice(index, 1)[0];
      this.pageData.splice(index - 1, 0, moveItem);
      this.currentIndex = index - 1;
      this.setCurrentModulePosition();
    },
    moveDown(index) {
      if (index == this.pageData.length - 1) return;
      let moveItem = this.pageData.splice(index, 1)[0];
      this.pageData.splice(index + 1, 0, moveItem);
      this.currentIndex = index + 1;
      this.setCurrentModulePosition();
    },
    // 设置当前模块始终保持在窗口顶部
    setCurrentModulePosition() {
      setTimeout(() => {
        let offset = $(".module-content.active").offset();
        let scrollTop = $(".page-preview-scroll-wrapper").scrollTop();
        $(".page-preview-scroll-wrapper").animate(
          {
            scrollTop: scrollTop + offset.top - 145
          },
          500
        );
      }, 100);
    },
    // 删除模块
    deleteModule(index) {
      this.$confirm(`确认删除吗？`, "删除", {
        showCancelButton: true,
        type: "warning",
        dangerouslyUseHTMLString: true,
        closeOnClickModal: false,
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            this.pageData.splice(index, 1);
            instance.confirmButtonLoading = false;
            // 如果删除最后一个，则需要选中删除完成后的最后一个
            if (index == this.pageData.length) {
              this.selectModule(index - 1, -1);
            }
            done();
          } else {
            done();
          }
        }
      });
    },
    validatePage() {
      return new Promise((resolve, reject) => {
        let validate = this.pageData.every(item => item.validate);
        resolve(validate);
      });
    },
    // 用户点击发布按钮
    handlePublish() {
      this.preIndex = this.currentIndex;
      this.currentIndex = -1;
      setTimeout(() => {
        this.validatePage().then(valid => {
          if (!valid) {
            this.$message({
              dangerouslyUseHTMLString: true,
              message:
                '带<i class="warning-icon"></i>模块字段未按照要求填写，无法发布！',
              type: "error",
              duration: 5000,
              showClose: true
            });
          } else {
            if (!this.pageData.length) {
              this.$message.error("未配置模块，无法发布！");
              return;
            }
            let _this = this;
            this.$confirm(`确认将配置的内容发布？`, "发布", {
              showCancelButton: true,
              type: "warning",
              dangerouslyUseHTMLString: true,
              closeOnClickModal: false,
              callback: (action, instance) => {
                if (action === "confirm") {
                  this.publishPage().then(
                    res => {
                      _this.publish = true;
                      this.$message.success("发布成功!");
                    },
                    res => {
                      this.$message.error(res.msg);
                    }
                  );
                }
              }
            });
          }
        });
      }, 100);
    },
    publishPage() {
      return new Promise((resolve, reject) => {
        this.loading = true;
        this.$http
          .post("directSale/saveAndPublishDraft", this.pageData)
          .then(res => {
            sa.event("fundMaster_open_link", {});
            this.loading = false;
            if (res && res.code === 20000) {
              resolve();
            } else {
              reject(res);
            }
          });
      });
    },
    // 用户点击保存草稿
    saveDraft() {
      this.preIndex = this.currentIndex;
      this.currentIndex = -1;
      setTimeout(() => {
        this.loading = true;
        this.$http.post("directSale/saveDraft", this.pageData).then(res => {
          this.loading = false;
          if (res && res.code == 20000) {
            this.$message.success("保存成功");
          } else {
            let msg = res && res.msg ? res.msg : "数据请求出错";
            this.$message.error(msg);
          }
        });
      }, 100);
    },
    // 停用
    stopUse() {
      this.$confirm(`确认停用配置的内容`, "停用", {
        showCancelButton: true,
        type: "warning",
        dangerouslyUseHTMLString: true,
        closeOnClickModal: false,
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            this.loading = true;
            this.$http.post("directSale/forbidConfig").then(res => {
              this.loading = false;
              if (res && res.code === 20000) {
                this.$message.success("停用成功");
                this.publish = false;
              } else {
                this.$message.error(res.msg);
              }
            });
            done();
          } else {
            done();
          }
        }
      });
    },
    // 获取添加模块按钮配置
    getAddButtonConfig(moduleConfig) {
      return moduleConfig.map((item, index) => {
        return {
          moduleName: item.moduleName,
          title: item.moduleTitle,
          ultimate: item.ultimate || false,
          hide: item.hide || false
        };
      });
    },
    // 获取每个模块的模块名称 map
    getModuleMap(moduleConfig) {
      let map = {};
      moduleConfig.forEach(item => {
        if (item.moduleName) {
          map[item.moduleName] = item.moduleTitle;
        }
        if (item.children) {
          item.children.forEach(child => {
            map[child.moduleName] = item.moduleTitle;
          });
        }
      });
      return map;
    },
    // 根据pageData组装数据，主要是加上compKey
    configPageData() {
      this.pageData = this.pageData.map(item => {
        return Object.assign({}, item, {
          moduleTitle: this.moduleMap[item.name],
          compKey: `${item.name}${(Math.random() * 1000000).toFixed(0)}`,
          validate: item.validate || false
        });
      });

      let haveTabs = _.findIndex(this.pageData, page => page.name == "tabs");
      let haveHeader = _.findIndex(
        this.pageData,
        page => page.name == "pageHeader"
      );

      if (haveTabs == -1) {
        this.pageData.unshift({
          moduleTitle: "标签页",
          name: "tabs",
          validate: true,
          tabs: [
            {
              ifHide: false,
              tabName: "index"
            },
            {
              ifHide: false,
              tabName: "product"
            },
            {
              ifHide: false,
              tabName: "manager"
            },
            {
              ifHide: false,
              tabName: "file"
            },
            {
              ifHide: false,
              tabName: "roadShow"
            },
            {
              ifHide: false,
              tabName: "comment"
            }
          ],
          compKey: "abdcdddddd"
        });
      }

      if (haveHeader == -1) {
        this.pageData.unshift({
          moduleTitle: "页头",
          styleType: "1",
          name: "pageHeader",
          validate: true,
          subIndicatorKeys: [],
          spreadIndicatorKeys: [],
          compKey: "abdcddd"
        });
      }

      this.showPageButtons = true;
    },
    // 初始化页面数据，先获取用户的直营店等级（旗舰版或普通版），根据等级渲染不同的模板
    // 然后获取页面数据，获取用户公司信息
    initData() {
      this.getUserLevel().then(() => {
        this.addButtonConfig = this.getAddButtonConfig(this.moduleConfig);

        this.moduleMap = this.getModuleMap(this.moduleConfig);
        this.getPageData();
        let companyInfo = getCompanyInfo();
        if (companyInfo && companyInfo.companyName) {
          this.companyName = `(${companyInfo.companyName})`;
        }
      });
    },
    // 基金大师重新登录接口，解决在聊天组件掉线之后用户需要重新登录才能使用的问题
    reLogin() {
      return new Promise((resolve, reject) => {
        this.$http.get("user/reLogin").then(res => {
          if (res && res.code === 20000) {
            resolve();
          } else {
            location.assign(
              this.$baseUrl[process.env.NODE_ENV]["page"] + "/login/index.html"
            );
          }
        });
      });
    },
    // 获取用户状态--是旗舰版还是普通版
    getUserLevel() {
      return new Promise((resolve, reject) => {
        this.$http.get("directSale/getDirectSaleType").then(res => {
          resolve();
          if (res && res.code === 20000) {
            this.isUltimate = res.data.type == 2 ? true : false;
          } else {
            let msg = res && res.msg ? res.msg : "数据请求出错";
            this.$message.error(msg);
            window.location.assign(
              this.$baseUrl[process.env.NODE_ENV]["page"] + "/error/index.html"
            );
          }
        });
      });
    },

    // 获取用户在官网的登录状态
    checkUserOfficialStatus() {
      return new Promise((resolve, reject) => {
        $.ajax({
          type: "GET",
          url: `${
            this.$baseUrl[process.env.NODE_ENV]["officialMobile"]
          }/member/getUserInfoApi`,
          xhrFields: {
            withCredentials: true
          },
          crossDomain: true,
          success: resp => {
            let res = resp instanceof Object ? resp : JSON.parse(resp);
            resolve(res);
          },
          error: () => {
            resolve({});
          }
        });
      });
    }
  },
  watch: {
    pageData: {
      handler(val) {}
    }
  },
  mounted() {
    // 先验证用户在官网的登录状态，掉线的就relogin
    this.checkUserOfficialStatus().then(res => {
      if (res.status == 1) {
        this.initData();
      } else {
        let reloginAble = window.sessionStorage.getItem("reloginAble");
        // reloginAble 表示用户是否可以重新登录，目前只有切换账号的用户无法重新登录
        if (reloginAble === "false") {
          this.initData();
        } else {
          this.reLogin().then(() => {
            this.initData();
          });
        }
      }
    });
  }
};
</script>