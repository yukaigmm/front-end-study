  const generateJumpTypeConfig = () => {
      return [{
              label: "外链",
              value: "1"
          },
          {
              label: "PDF",
              value: "2"
          },
          {
              label: "默认详情页",
              value: "3"
          },
          {
              label: "新内容",
              value: "4"
          },
          {
              label: "不跳转",
              value: "5"
          }
      ]
  }

  const generateHeaderConfig = function () {
      return [{
              label: "备案编码",
              value: "1"
          },
          {
              label: "所在地区",
              value: "2"
          },
          {
              label: "成立日期",
              value: "3"
          },
          {
              label: "核心策略",
              value: "4"
          },
          {
              label: "注册资本",
              value: "5"
          },
          {
              label: "管理规模",
              value: "6"
          },
          {
              label: "机构类型",
              value: "7"
          },
      ]
  }

  const generateTabConfig = function () {
      return [{
              label: "首页",
              value: "index"
          },
          {
              label: "产品",
              value: "product"
          },
          {
              label: "经理",
              value: "manager"
          },
          {
              label: "档案",
              value: "file"
          },
          {
              label: "路演",
              value: "roadShow"
          },
          {
              label: "点评",
              value: "comment"
          },

      ]
  }


  const generateTrendOrIntervalConfig = function () {
      return [{
              label: "近半年走势图",
              value: "half_year_trend"
          }, {
              label: "年化收益",
              value: "ret_incep_a"
          }, {
              label: "今年以来",
              value: "0"
          }, {
              label: "近一月收益",
              value: "1"
          }, {
              label: "近三月收益",
              value: "2"
          }, {
              label: "近半年收益",
              value: "3"
          }, {
              label: "近一年收益",
              value: "4"
          }, {
              label: "近三年收益",
              value: "6"
          },
          {
              label: "近五年收益",
              value: "7"
          },
          {
              label: "成立以来",
              value: "ret_incep"
          },
          {
              label: "最新净值",
              value: "nav"
          },
      ]
  }


  const generateThumbnailStyleMapping = function () {
      return {
          "peFund1": `background-position:0 -193px;`,
          "peFund2": `background-position:0 -92px;`,
          "commonProduct": `background-position:-111px -93px;`,
          "fixedIncome": `background-position:0 0;`,
          "privateEquity": `background-position:0 0;`,
          "ad1": `background-position:-222px 0;`,
          "ad2": `background-position:-221px -94px;`,
          "hotPoint1": `background-position:-111px 0;`,
          "notice1": `background-position:0 -297px;`,
          "viewPoint": `background-position:-112px -297px;`,
          "header": `background-position:0 -388px;`,
          undefined: `background-position:-1120px -2970px;`,
      }
  }


  export {
      generateJumpTypeConfig,
      generateTrendOrIntervalConfig,
      generateThumbnailStyleMapping,
      generateHeaderConfig,
      generateTabConfig
  }