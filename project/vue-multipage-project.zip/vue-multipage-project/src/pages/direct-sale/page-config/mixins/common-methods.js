export default {
    methods: {
        transferData(data = [], key, needTag = true, childKey) {
            return data.map(item => {
                if (!childKey) {
                    item[`${key}Data`] = {
                        fileName: item[`${key}Name`],
                        filePath: item[key]
                    };
                    if (needTag && !item.tags) {
                        item.tags = []
                    }

                } else {
                    item[childKey] = this.transferData(item[childKey] || [], "file", false)
                }

                return item;

            });
        },

        deleteUselessKeys(data = [], childKey) {
            return data.map(item => {
                if (!childKey) {
                    delete item.fileData;
                    switch (item.jumpType) {
                        case "1":
                            delete item.file;
                            delete item.fileName;
                            delete item.content;
                            break;
                        case "2":
                            delete item.link;
                            delete item.content;
                            break;
                        case "4":
                            delete item.file;
                            delete item.fileName;
                            delete item.link;
                            break;
                        case "3":
                        case "5":
                        default:
                            delete item.file;
                            delete item.fileName;
                            delete item.content;
                            delete item.link;
                            break;
                    }
                } else {
                    item[childKey] = this.deleteUselessKeys(item[childKey])
                }

                return item;
            })
        },

        setCompKeys(originBaseData, index, childKey) {
            let baseData = JSON.parse(JSON.stringify(originBaseData));
            let len = baseData.length
            for (let i = 0; i < len; i++) {
                if (!index && index !== 0) {
                    if (baseData[i] && !baseData[i].compKey) {
                        baseData[i].compKey = Date.now() + i;
                    }
                    if (childKey && baseData[i][childKey] && baseData[i][childKey].length) {
                        baseData[i][childKey] = this.setCompKeys(baseData[i][childKey])
                    } else {
                        continue;
                    }
                }
            }

            return baseData;
        }

    },
}