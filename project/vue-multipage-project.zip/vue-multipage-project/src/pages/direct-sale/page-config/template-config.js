export default {
    ultimate: [
       {name: "notice"},
       {name: "hotPoint"},
       {name: "ad"},
       {name: "product"},
       {name: "viewPoint"}
    ],
    normal: [
        {name: "notice"},
        {name: "product"},
        {name: "viewPoint"}
    ]
}