<template>
  <div>
    <div class="product-list">
      <div class="title-bar">
        <span class="product-config-title">广告列表</span>
        <span class="product-add-btn" v-if="false" @click="addHotPoint">+添加广告</span>
      </div>

      <div class="form-content">
        <div class="ad-list">
          <div
            v-for="(ad,index) in formData.ads"
            class="product-list-wrapper"
            :class="{'active-product':index ==currentIndex}"
            :key="ad.compKey"
            @click="changeAd(index)"
          >
            <span class="product-title">{{`广告${numbersMapping[index]}`}}</span>
            <div class="action-area">
              <span class="product-action-btn move-up" @click.prevent.stop="moveUp(index)"></span>
              <span class="product-action-btn move-down" @click.prevent.stop="moveDown(index)"></span>
              <span class="product-action-btn delete-product" @click.prevent.stop="deleteAd(index)"></span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <el-form
      v-for="(ad,index) in formData.ads"
      :key="ad.compKey"
      :ref="`ad${index}`"
      :rules="validateRules"
      :model="ad"
      v-show="index == currentIndex"
      label-width="60px"
      label-position="left"
    >
      <div class="title-bar">
        <div class="title product-config-title">{{`广告${numbersMapping[index]}属性`}}</div>
      </div>

      <div class="form-content">
        <el-form-item label="展示样式">
          <div
            class="style-container"
            :style="`${thumbnailStyleMapping[ad.styleType]}`"
            @click="chooseStyle"
          >
            <span v-if="!ad.styleType">请选择样式</span>
          </div>
        </el-form-item>

        <el-form
          v-for="(adItem,adIndex) in ad.pics"
          :rules="validateRules"
          label-width="60px"
          label-position="left"
          class="product-list-wrapper"
          :class="{'active-product':adIndex == picIndex}"
          :key="adItem.compKey"
          @click.native="changePic(adIndex)"
          :model="adItem"
          :ref="`adItem${index + '' + adIndex}`"
        >
          <el-form-item
            :class="{'validate-item':adItem.validate===false}"
            class="pic-el-form-item init-form-item"
            :label="`图片${numbersMapping[adIndex]}`"
            prop="pic"
          >
            <div
              class="ad-validate-icon"
              :class="{'ad1-validate-icon':ad.styleType == 'ad1','ad2-validate-icon':ad.styleType == 'ad2'}"
              title="该图片存在不正确的配置项"
              v-show="adItem.validate===false"
            ></div>
            <vimageUpload
              v-if="ad.styleType =='ad1'"
              showRecommendSize
              recommendSize="1035x303"
              v-model="adItem['pic']"
              url="file/visitingCard"
              fieldName="directSalePicture"
              @change="onPicChange(adIndex)"
              :imgStyle="{
                            minWidth: '193px',
                            maxWidth: '193px',
                            height: '47px',
                        }"
            />

            <vimageUpload
              v-else
              showRecommendSize
              recommendSize="501x465"
              v-model="adItem['pic']"
              url="file/visitingCard"
              fieldName="directSalePicture"
              @change="onPicChange(adIndex)"
              :imgStyle="{
                            minWidth: '88px',
                            maxWidth: '88px',
                            height: '82px'
                        }"
            />
          </el-form-item>

          <div class="action-area" :key="adItem.compKey">
            <span
              class="product-action-btn move-left"
              :class="{'disabled-btn':adIndex ==0}"
              @click.prevent.stop="moveLeft(adIndex)"
            ></span>
            <span
              class="product-action-btn move-right"
              :class="{'disabled-btn':adIndex == ad.pics.length -1}"
              @click.prevent.stop="moveRight(adIndex)"
            ></span>
            <span
              class="product-action-btn delete-product"
              @click.prevent.stop="deleteAdItem(adIndex)"
            ></span>
          </div>
        </el-form>

        <span
          class="add-pic-btn"
          v-show="ad.styleType =='ad1' && ad.pics.length <10"
          @click="addAdItem"
        >+添加图片</span>
      </div>

      <div class="title-bar">
        <div class="title product-config-title">{{`图片${numbersMapping[picIndex]}属性`}}</div>
      </div>

      <el-form
        v-for="(pic,picsIndex) in ad.pics"
        :rules="validateRules"
        label-width="60px"
        label-position="left"
        :key="pic.compKey"
        :ref="`pic${index+ '' +picsIndex}`"
        :model="pic"
        v-show="picsIndex == picIndex"
      >
        <div class="form-content">
          <el-form-item label="跳转" prop="jumpType" :key="pic.compKey">
            <el-select v-model="pic['jumpType']" style="width:100%;">
              <el-option value="1" label="外链"></el-option>
              <el-option value="2" label="PDF"></el-option>
              <el-option value="5" label="无跳转"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="外链" prop="link" v-if="pic['jumpType']=='1'" :key="pic.compKey">
            <el-input v-model.trim="pic['link']" placeholder="请输入链接"/>
          </el-form-item>
          <el-form-item v-if="pic['jumpType']=='2'" label="文件" prop="fileData" :key="pic.compKey">
            <vfileUpload
              @getFileData="getFileData(picsIndex)"
              v-model="pic.fileData"
              url="file/visitingCard"
              fileName="directSalePdf"
              class="custom-file-uploader"
              resName="fileName"
              :foreignPath="true"
              :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
            />
          </el-form-item>
        </div>
      </el-form>
    </el-form>

    <style-modal
      v-model="showStyleModal"
      :current-style="currentAd.styleType || null"
      :styles-list="['ad1','ad2']"
      @getStyle="getStyle"
    />
  </div>
</template>


<script>
import { isEqual } from "lodash";
import commonMethods from "../../mixins/common-methods.js";
import editor from "../../../../../common/components/inputs/editor-with-menu/editor";
import StyleModal from "../product/components/style-modal";
import { generateThumbnailStyleMapping } from "../../js/options-config";
export default {
  components: {
    editor,
    StyleModal
  },

  props: {
    configData: {
      type: [Object, Array]
    }
  },

  computed: {
    currentAd() {
      return this.formData.ads[this.currentIndex] || {};
    },

    currentAdItem() {
      return this.formData.ads[this.currentIndex]
        ? this.formData.ads[this.currentIndex].pics[this.picIndex] || {}
        : {};
    },

    numbersMapping() {
      let str = "一二三四五六七八九十";
      return str.split("");
    },

    thumbnailStyleMapping() {
      return generateThumbnailStyleMapping();
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },
      deep: true
    },
    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }

        let data = JSON.parse(JSON.stringify(val));

        data.ads =
          data.ads && data.ads.length
            ? this.transferData(data.ads, "file", false, "pics")
            : [
                {
                  styleType: "ad1",
                  pics: [
                    {
                      jumpType: "1"
                    }
                  ]
                }
              ];
        this.formData = JSON.parse(JSON.stringify(data));
        this.formData.ads = this.setCompKeys(
          this.formData.ads,
          undefined,
          "pics"
        );
      },

      deep: true,

      immediate: true
    }
  },

  mixins: [commonMethods],

  beforeDestroy() {
    this.validate();
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("文件不能为空！"));
      }

      cb(errors);
    };
    return {
      picIndex: 0,
      showStyleModal: false,
      formData: {},
      validateRules: {
        styleType: {
          required: true,
          message: "不能为空"
        },
        pic: {
          required: true,
          message: "图片不能为空"
        },

        fileData: [
          {
            required: true,
            message: "文件不能为空"
          },
          { validator: validateFileData }
        ],

        link: {
          required: true,
          message: "链接不能为空"
        }
      },
      currentIndex: 0
    };
  },

  methods: {
    onPicChange(index) {
      this.$refs[`adItem${this.currentIndex + "" + index}`][0].validateField(
        "pic"
      );
    },
    // 更换当前广告
    changeAd(index) {
      this.currentIndex = index;
      this.picIndex = 0;
    },

    //    更换当前子广告
    changePic(index) {
      this.picIndex = index;
    },

    // 添加广告
    addHotPoint() {
      this.formData.ads.push({
        styleType: "ad1",
        pics: [{}]
      });
    },

    // 添加子广告
    addAdItem() {
      this.formData.ads[this.currentIndex].pics.push({ jumpType: "1" });
    },

    //  删除广告
    deleteAd(index) {
      if (this.formData.ads.length <= 1) {
        return;
      }
      this.formData.ads.splice(index, 1);

      if (this.currentIndex === index) {
        if (this.currentIndex - 1 >= 0) {
          this.currentIndex = this.currentIndex - 1;
        }
      } else if (this.currentIndex > index) {
        this.currentIndex -= 1;
      }
    },

    switch(direction, index) {
      if (this.formData.ads.length <= 1) {
        return;
      }
      let nearIndex;

      if (direction === "up") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: `当前广告已在最上边！`,
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (index >= this.formData.ads.length - 1) {
          this.$message({
            type: "error",
            message: `当前广告已在最下边！`,
            showClose: true
          });
          return;
        }

        nearIndex = index + 1;
      }
      let currentItem = this.formData.ads[index];
      let nearItme = this.formData.ads[nearIndex];
      this.$set(this.formData.ads, nearIndex, currentItem);
      this.$set(this.formData.ads, index, nearItme);
      if (index == this.currentIndex) {
        this.currentIndex = nearIndex;
        return;
      }

      if (index == this.currentIndex + 1 && direction == "up") {
        this.currentIndex = index;
        return;
      }

      if (index == this.currentIndex - 1 && direction == "down") {
        this.currentIndex = index;
        return;
      }
    },

    switchItem(drl, index) {
      if (this.formData.ads[this.currentIndex].pics.length <= 1) {
        return;
      }
      let nearIndex;

      if (drl === "left") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: `当前子广告已在最左边！`,
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (index >= this.formData.ads[this.currentIndex].pics.length - 1) {
          this.$message({
            type: "error",
            message: `当前子广告已在最右边！`,
            showClose: true
          });
          return;
        }

        nearIndex = index + 1;
      }
      let currentItem = this.formData.ads[this.currentIndex].pics[index];
      let nearItme = this.formData.ads[this.currentIndex].pics[nearIndex];
      this.$set(
        this.formData.ads[this.currentIndex].pics,
        nearIndex,
        currentItem
      );
      this.$set(this.formData.ads[this.currentIndex].pics, index, nearItme);
      if (index == this.picIndex) {
        this.picIndex = nearIndex;
        return;
      }

      if (index == this.picIndex + 1 && drl == "left") {
        this.picIndex = index;
        return;
      }

      if (index == this.picIndex - 1 && drl == "right") {
        this.picIndex = index;
        return;
      }
    },

    moveUp(index) {
      this.switch("up", index);
    },

    moveDown(index) {
      this.switch("down", index);
    },

    moveLeft(index) {
      this.switchItem("left", index);
    },

    moveRight(index) {
      this.switchItem("right", index);
    },

    deleteAdItem(index) {
      if (this.formData.ads[this.currentIndex].pics.length <= 1) {
        return;
      }
      this.formData.ads[this.currentIndex].pics.splice(index, 1);

      if (this.picIndex === index) {
        if (this.picIndex - 1 >= 0) {
          this.picIndex = this.picIndex - 1;
        }
      } else if (this.picIndex > index) {
        this.picIndex -= 1;
      }
    },

    getFileData(index) {
      this.formData.ads[this.currentIndex].pics[
        this.picIndex
      ].file = this.formData.ads[this.currentIndex].pics[
        this.picIndex
      ].fileData.filePath;
      this.formData.ads[this.currentIndex].pics[this.picIndex].fileName = this
        .formData.ads[this.currentIndex].pics[this.picIndex].file
        ? this.formData.ads[this.currentIndex].pics[this.picIndex].fileData
            .fileName
        : "";
      this.$refs[
        `pic${this.currentIndex + "" + this.picIndex}`
      ][0].validateField("fileData");
    },

    chooseStyle() {
      this.showStyleModal = true;
    },

    getStyle(style) {
      if (this.formData.ads[this.currentIndex].styleType != style) {
        if (style == "ad1") {
          this.formData.ads[this.currentIndex].pics = [
            {
              jumpType: "1"
            }
          ];
        } else {
          this.formData.ads[this.currentIndex].pics = [
            {
              jumpType: "1"
            },
            {
              jumpType: "1"
            }
          ];
        }
      }

      this.$set(this.formData.ads[this.currentIndex], "styleType", style);
    },

    validate() {
      let finalValid = true;
      if (
        !this.$refs.ad0 &&
        !this.$refs.ad0[0] &&
        !this.$refs.ad0[0].validate
      ) {
        return;
      }
      this.validatePic();
      let ads = this.formData.ads || [];
      finalValid = ads.every((ad, adIndex) => {
        let pics = ad.pics || [];
        return (
          ad.validate &&
          pics.every((pic, picIndex) => {
            return pic.validate;
          })
        );
      });
      this.$set(this.formData, "validate", finalValid);
      let data = JSON.parse(JSON.stringify(this.formData));
      data.ads = this.deleteUselessKeys(data.ads, "pics");
      this.$emit("getFormData", data, true);
    },

    validatePic() {
      let ads = this.formData.ads || [];
      if (
        !this.$refs.ad0 &&
        !this.$refs.ad0[0] &&
        !this.$refs.ad0[0].validate
      ) {
        return;
      }

      ads.forEach((ad, adIndex) => {
        let finalValid = true;
        let singleAdValid = true;
        this.$refs[`ad${adIndex}`][0].validate(adValid => {
          singleAdValid = singleAdValid && adValid;
          let pics = ad.pics || [];
          pics.forEach((item, itemIndex) => {
            this.$refs[`pic${adIndex + "" + itemIndex}`][0].validate(valid => {
              finalValid = finalValid && valid;
              singleAdValid = finalValid && singleAdValid;
              this.$refs[`adItem${adIndex + "" + itemIndex}`][0].validate(
                iconValid => {
                  finalValid = finalValid && iconValid;
                  singleAdValid = finalValid && singleAdValid;
                  this.$set(
                    this.formData.ads[adIndex].pics[itemIndex],
                    "validate",
                    finalValid
                  );
                }
              );
            });
          });
          this.$set(this.formData.ads[adIndex], "validate", singleAdValid);
        });
      });
    }
  }
};
</script>

<style lang="less">
.custom-datepicker {
  .el-input__prefix,
  .el-input__suffix {
    top: 4px !important;
  }
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100% !important;
  }
}

.ad-list {
  display: flex;
  justify-content: flex-start;
  flex-wrap: wrap;

  .product-list-wrapper {
    margin-left: 10px;
    &:nth-child(4n + 1) {
      margin-left: 0;
    }
    &:nth-child(n + 5) {
      margin-top: 10px;
    }
    &.active-product {
      border-color: #2992ff;
    }
    height: 75px;
    width: 75px;
    text-align: center;
    border: 1px solid #444444;
    color: #999999;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    .product-title {
      height: 44px;
      line-height: 44px;
    }
    .action-area {
      margin-left: 0;
      width: 100%;
      height: 29px;
      background: #444444;
    }
  }
}

.add-pic-btn {
  margin-left: 60px;
  margin-top: 12px;
  color: #2992ff;
  font-size: 12px;
  display: inline-block;
  width: 58px;
  height: 12px;
  cursor: pointer;
}

.active-product {
  .preview-img {
    border-color: #2992ff !important;
  }
}

.ad-validate-icon {
  background: url("../../../../../assets/images/direct-sale/warning.png")
    no-repeat;
  background-position: center;
  background-size: 100%;
  display: inline-block;
  width: 15px;
  height: 15px;
  vertical-align: text-bottom;
  position: absolute;
  &.ad1-validate-icon {
    top: 46px;
    left: 0px;
  }
  &.ad2-validate-icon {
    top: 81px;
    left: 0;
  }
}
</style>

