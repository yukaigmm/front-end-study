<template>
  <div>
    <div class="title-bar">
      <div class="title product-config-title">模块属性</div>
    </div>
    <el-form
      ref="form"
      :rules="validateRules"
      :model="formData"
      label-width="60px"
      label-position="left"
    >
      <div class="form-content">
        <el-form-item label="主标题" prop="mainTitle">
          <el-input v-model.trim="formData.mainTitle" placeholder="请输入主标题，最多仅展示一行" maxlength="20">
            <span slot="append">{{formData.mainTitle?formData.mainTitle.length:0}}/20</span>
          </el-input>
        </el-form-item>

        <el-form-item label="副标题" prop="subTitle">
          <el-input v-model.trim="formData.subTitle" placeholder="请输入副标题，最多仅展示一行" maxlength="20">
            <span slot="append">{{formData.subTitle?formData.subTitle.length:0}}/20</span>
          </el-input>
        </el-form-item>
      </div>

      <div class="product-list">
        <div class="title-bar">
          <span class="product-config-title">观点列表</span>
          <span
            class="product-add-btn"
            :class="{'disabled-action-btn':formData.views.length >=5}"
            @click="addProduct"
          >+添加观点</span>
        </div>

        <div class="form-content">
          <el-form
            v-for="(view,index) in formData.views"
            :key="view.compKey"
            :model="view"
            :ref="`viewTitle${index}`"
            label-width="60px"
            label-position="left"
            :rules="validateRules"
            @click.native="onFocus(index)"
          >
            <el-form-item
              :class="{'validate-item':view.validate===false}"
              prop="title"
              :label="`观点${numberMapping[index]}`"
            >
              <div class="product-list-wrapper" :class="{'active-product':index == currentIndex}">
                <div class="view-validate-icon" title="该观点存在不正确的配置项" v-show="view.validate===false"></div>
                <el-input v-model.trim="view.title" placeholder="请输入标题" />
                <div class="action-area">
                  <span
                    :class="{'disabled-btn':index ==0}"
                    class="product-action-btn move-up"
                    @click.prevent.stop="moveUp(index)"
                  ></span>
                  <span
                    :class="{'disabled-btn':index ==formData.views.length-1}"
                    class="product-action-btn move-down"
                    @click.prevent.stop="moveDown(index)"
                  ></span>
                  <span
                    class="product-action-btn delete-product"
                    @click.prevent.stop="deleteProduct(index)"
                  ></span>
                </div>
              </div>
            </el-form-item>
          </el-form>
        </div>
      </div>

      <el-form
        :ref="`currentView${index}`"
        :rules="validateRules"
        v-for="(view,index) in formData.views"
        :key="view.compKey"
        :model="view"
        label-width="60px"
        label-position="left"
        v-show="index == currentIndex"
      >
        <div class="title-bar">
          <div class="title product-config-title">{{`观点${numberMapping[index]}属性`}}</div>
        </div>

        <div class="form-content">
          <el-form-item label="展示样式">
            <div
              class="style-container"
              :style="`${thumbnailStyleMapping[view.styleType]}`"
              @click="chooseStyle"
            >
              <span v-if="!view.styleType">请选择样式</span>
            </div>
          </el-form-item>
          <div v-if="view.styleType">
            <el-form-item label="发布时间" prop="publishTime" key="date">
              <vdatePicker
                v-model="view.publishTime"
                style="width:100%;"
                class="custom-datepicker"
                @change="dateChange(index)"
              />
            </el-form-item>

            <el-form-item label="跳转" prop="jumpType" key="jump">
              <el-select v-model="view.jumpType" style="width:100%;">
                <el-option value="1" label="外链"></el-option>
                <el-option value="2" label="PDF"></el-option>
                <el-option value="4" label="新内容"></el-option>
                <el-option value="5" label="无跳转"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="外链" prop="link" v-if="view.jumpType=='1'">
              <el-input v-model.trim="view.link" placeholder="请输入链接" />
            </el-form-item>

            <el-form-item v-if="view.jumpType=='2'" label="文件" prop="fileData">
              <vfileUpload
                v-model="view.fileData"
                @getFileData="getFileData(index)"
                url="file/visitingCard"
                fileName="directSalePdf"
                class="custom-file-uploader"
                resName="fileName"
                :foreignPath="true"
                :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
              />
            </el-form-item>

            <el-form-item
              class="pic-el-form-item init-form-item"
              v-if="view.jumpType=='4'"
              label="文本"
              prop="content"
              key="content"
            >
              <editor v-model="view.content" @change="onContentChange(index)" />
            </el-form-item>
          </div>
        </div>
      </el-form>
    </el-form>

    <style-modal
      v-model="showStyleModal"
      :current-style="currentView.styleType || null"
      :styles-list="['viewPoint1']"
      @getStyle="getStyle"
    />
  </div>
</template>


<script>
import { isEqual } from "lodash";
import commonMethods from "../../mixins/common-methods.js";
import editor from "../../../../../common/components/inputs/editor-with-menu/editor";
import StyleModal from "../product/components/style-modal";
import { generateThumbnailStyleMapping } from "../../js/options-config";
export default {
  components: {
    editor,
    StyleModal
  },

  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "product",
        views: [{}]
      })
    }
  },

  computed: {
    currentView() {
      return this.formData.views[this.currentIndex] || {};
    },

    numberMapping() {
      let str = "一二三四五六七八九十";
      return str.split("");
    },

    thumbnailStyleMapping() {
      return generateThumbnailStyleMapping();
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },
      deep: true
    },
    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }

        let data = JSON.parse(JSON.stringify(val));

        data.views =
          data.views && data.views.length
            ? this.transferData(data.views, "file")
            : [{ styleType: "viewPoint1", jumpType: "4", content: "" }];
        this.formData = JSON.parse(JSON.stringify(data));
        this.formData.views = this.setCompKeys(this.formData.views);
      },

      deep: true,

      immediate: true
    }
  },

  mixins: [commonMethods],

  beforeDestroy() {
    this.validate();
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("文件不能为空"));
      }

      cb(errors);
    };

    const validatePublishDate = (rules, value, cb) => {
      let errors = [];
      if (!value) {
        errors.push(new Error("发布时间不能为空"));
      }
      cb(errors);
    };
    return {
      showStyleModal: false,
      formData: {},
      validateRules: {
        mainTitle: {
          required: true,
          message: "不能为空"
        },
        // subTitle: {
        //   required: true,
        //   message: "不能为空"
        // },
        publishTime: [
          {
            required: true,
            message: "不能为空"
          },
          {
            validator: validatePublishDate,
            trigger: "change"
          }
        ],
        title: {
          required: true,
          message: "不能为空"
        },
        fileData: [
          {
            required: true,
            message: "不能为空"
          },
          { validator: validateFileData }
        ],
        link: {
          required: true,
          message: "不能为空"
        },
        content: {
          required: true,
          message: "不能为空"
        }
      },
      currentIndex: 0
    };
  },

  methods: {
    // 更换当前观点
    onFocus(index) {
      this.currentIndex = index;
    },

    dateChange(index) {
      this.$refs[`currentView${index}`][0].validateField("publishTime");
    },

    onContentChange(index) {
      this.$refs[`currentView${index}`][0].validateField("content");
    },

    // 添加观点
    addProduct() {
      if (this.formData.views.length >= 5) {
        this.$message.error({
          type: "error",
          message: "最多只能添加五个观点！",
          showClose: true
        });
        return;
      }
      this.formData.views.push({
        styleType: "viewPoint1",
        jumpType: "4",
        content: ""
      });
    },

    //  删除观点
    deleteProduct(index) {
      if (this.formData.views.length <= 1) {
        return;
      }
      this.formData.views.splice(index, 1);

      if (this.currentIndex === index) {
        if (this.currentIndex - 1 >= 0) {
          this.currentIndex = this.currentIndex - 1;
        }
      }
    },

    switch(direction, index) {
      if (this.formData.views.length <= 1) {
        return;
      }
      let nearIndex;

      if (direction === "up") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: "当前观点已在最上边！",
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (index >= this.formData.views.length - 1) {
          this.$message({
            type: "error",
            message: "当前观点已在最下边！",
            showClose: true
          });
          return;
        }

        nearIndex = index + 1;
      }
      let currentItem = this.formData.views[index];
      let nearItme = this.formData.views[nearIndex];
      this.$set(this.formData.views, nearIndex, currentItem);
      this.$set(this.formData.views, index, nearItme);
    },

    moveUp(index) {
      this.switch("up", index);
    },

    moveDown(index) {
      this.switch("down", index);
    },

    setCurrentProductName(name, index) {
      this.$set(this.formData.views[index], "productName", name);
    },

    getFileData(index) {
      this.formData.views[this.currentIndex].file = this.formData.views[
        this.currentIndex
      ].fileData.filePath;
      this.formData.views[this.currentIndex].fileName = this.formData.views[
        this.currentIndex
      ].file
        ? this.formData.views[this.currentIndex].fileData.fileName
        : "";
      this.$refs[`currentView${index}`][0].validateField("fileData");
    },

    chooseStyle() {
      this.showStyleModal = true;
    },

    getStyle(style) {
      this.$set(this.formData.views[this.currentIndex], "styleType", style);
    },

    validate() {
      if (
        this.$refs.currentView0 &&
        this.$refs.currentView0[0] &&
        this.$refs.currentView0[0].validate
      ) {
        this.validateCurrentView();
      }
      let finalValidate = true;
      this.$refs.form.validate(valid => {
        finalValidate = valid && finalValidate;

        let views = this.formData.views || [];
        views.forEach(view => {
          finalValidate = finalValidate && view.validate;
        });
      });

      this.$set(this.formData, "validate", finalValidate);

      let data = JSON.parse(JSON.stringify(this.formData));
      data.views = this.deleteUselessKeys(data.views);
      this.$emit("getFormData", data, true);
    },

    validateCurrentView() {
      let views = this.formData.views || [];

      views.forEach((view, index) => {
        let finalValidate = true;
        this.$refs[`viewTitle${index}`][0].validate(valid => {
          finalValidate = finalValidate && valid;

          this.$refs[`currentView${index}`][0].validate(validView => {
            finalValidate = finalValidate && validView;
            this.$set(this.formData.views[index], "validate", finalValidate);
          });
        });
      });
    }
  }
};
</script>

<style lang="less">
.custom-datepicker {
  .el-input__prefix,
  .el-input__suffix {
    top: 4px !important;
  }
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100% !important;
  }
}

.view-validate-icon {
  background: url("../../../../../assets/images/direct-sale/warning.png")
    no-repeat;
  background-position: center;
  background-size: 100%;
  display: inline-block;
  width: 15px;
  height: 15px;
  vertical-align: text-bottom;
  position: absolute;
  top: 34px;
  left: 0;
  cursor: pointer;
}
</style>

