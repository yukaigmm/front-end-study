<template>
    <div class="pe-fund4 direct-sale-module">
       <div class="title-container">
           <span class="main-title">{{compData.mainTitle}}</span>
           <span class="sub-title">{{compData.subTitle}}</span>
           <span class="tips" v-show="!moduleData.mainTitle && !moduleData.subTitle">(标题未配置将不会在首页展示)</span>
       </div>
       <div class="product-container">
           <div
           class="product-item"
           v-for="(item, index) in compData.fundInfo"
           :key="index"
           >
               <div class="product-value">
                    <div 
                    class="val" 
                    :class="item.intervalVal < 0 ? 'negative' : item.intervalVal > 0 ? 'positive': ''"
                    v-html="`${item.intervalVal}%`"
                    ></div>
                    <div class="concept-name">{{item.intervalName}}</div>
               </div>
               <div class="product-info">
                   <div class="product-shortname">{{item.productName}}</div>
                   <div class="recomend-msg">{{item.recommendation}}</div>
               </div>
           </div>
       </div>
    </div>
</template>

<script>
import {generateTrendOrIntervalConfig} from "../../../js/options-config.js";
export default {
    props: {
        fund: {
            type: Object,
            default: {}
        }
    },
    data(){
        return {
            fundInfoCache: {},
            fundInfo: [{}],
            map: {}
        }
    },
    computed: {
        fundInfo(){
            let fund = this.fundData;
            return {
                tags: fund.tags && fund.tags.length ? fund.tags : ["标签"],
                recommendation: fund.recommendation || "推荐语",
                intervalName: fund.intervalName || "累计收益",
                intervalVal: fund.intervalVal || "--",
                productName: fund.productName || "产品名称"
            }
        }
    },
    methods: {
        buildFundData(){
           let fund = this.fundData = JSON.parse(JSON.stringify(this.fund));
           if(fund.productId){
                if(this.fundInfoCache[fund.productId]){
                    this.buildFundDataFromCache(fund);
                }else{
                    this.getFundData(fund.productId).then((res) => {
                        if (!res)return;
                        if(res.data && res.data.list instanceof Array){
                                let incomeMap = {};
                                let arr = JSON.parse(JSON.stringify(res.data.list));
                                arr.forEach((item, index) => {
                                    incomeMap[index] = item.self_income
                                });
                                incomeMap.ret_incep = res.data.ret_incep;
                                incomeMap.ret_incep_a = res.data.ret_incep_a;
                                incomeMap.nav = res.data.nav;
                                incomeMap.priceDate = res.data.price_date;
                                incomeMap.runTime = this.dateCalculate(res.data);
                                this.fundInfoCache[fund.productId] = incomeMap;
                                this.buildFundDataFromCache(fund);
                            }
                    })
                }
            }
        },
        buildFundDataFromCache(fund){
            let cacheItem = this.fundInfoCache[fund.productId];
            fund.intervalName = this.map[fund.intervalIncome];
            fund.intervalVal = cacheItem[fund.intervalIncome];
            fund.nav = cacheItem.nav;
            fund.runTime = cacheItem.runTime;
            this.$set(fund, "priceDate", cacheItem.priceDate)
        },
        getFundData(id){
            let params = {id}
            return new Promise((resolve, reject) => {
                $.ajax({
                    type: "GET",
                    url: `${this.$baseUrl[process.env.NODE_ENV]["officialMobile"]}/fund/performanceApi`,
                    xhrFields: {
                      withCredentials: true
                    },
                    crossDomain: true,
                    data: params,
                    success: (resp) => {
                        let res = resp instanceof Object ? res : JSON.parse(resp);
                        resolve(res);
                    },
                    error: () => {}
                })
            });
        },
        dateCalculate (v) { // 计算私募证券运行时间
            if (!v.inception_date) return '--'
            let past = +new Date(v.inception_date.replace(/-/g, '/'))
            let now = v.liquidate_date ? +new Date(v.liquidate_date.replace(/-/g, '/')) : +new Date()
            let date = new Date(now - past)
            let day = date.getDate()
            let month = date.getMonth() + (day > 2 ? 1 : 0)
            let year = date.getFullYear() + (month === 12 ? (month = 0, 1) : 0) - 1970
            return `${year !== 0 ? `${year}年` : ''}${month !== 0 ? `${month}个月` : ''}`
        },

    },
    mounted() {
        generateTrendOrIntervalConfig().forEach(item => {
            this.map[item.value] = item.label;
        })
        this.getDiffFundData();
    },
    watch: {
        moduleData: {
            handler(val){
                this.getDiffFundData();
            }
        },
    }
}
</script>
<style lang="less" scoped>
   .pe-fund4{
        // 产品内容
        .product-container{
            // 产品简称和标签
            .product-item{
                display: flex;
                .product-value{
                    width: 107.77px;
                    padding-right: 13.36px;
                    text-align: left;
                    .val{
                        font-size: 18.70px;
                        line-height: 26.27px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }
                .product-info{
                    flex: 1;
                    text-align: left;
                    .recomend-msg{
                        font-size: 12px;
                        color: #999;
                        line-height: 16.48px;
                        width: 195.52px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                    .product-shortname{
                        line-height: 26.27px;;
                        font-size: 14.25px;
                        width: 195.52px;
                        color: #222;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }
            }
           
        }
   }
</style>