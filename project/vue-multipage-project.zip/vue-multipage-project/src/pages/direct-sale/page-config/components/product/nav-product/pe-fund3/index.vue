<template>
    <div class="pe-fund3 direct-sale-module">
       <div class="title-container">
           <span class="main-title">{{compData.mainTitle}}</span>
           <span class="sub-title">{{compData.subTitle}}</span>
           <span class="tips" v-show="!moduleData.mainTitle && !moduleData.subTitle">(标题未配置将不会在首页展示)</span>
       </div>
       <div class="product-container">
           <div 
           class="product-item" 
           v-for="(item, index) in compData.fundInfo"
           :key="index"
           >
               <div class="product-graph">
                    <img v-show="item.imgUrl" :src="item.imgUrl" alt="">
                    <span v-show="!item.imgUrl" class="img-notice">收益曲线</span>
               </div>
               <div class="product-info">
                   <div class="product-shortname">{{item.productName}}</div>
                   <div class="recomend-msg">{{item.recommendation}}</div>
                   <div class="product-stat-row">
                        <div class="accumulate-yield stat-item left">
                            <div 
                            class="val" 
                            :class="item.comulateYield < 0 ? 'negative' : item.comulateYield > 0 ? 'positive': ''"
                            v-html="`${item.comulateYield}%`"
                            ></div>
                            <div class="concept-name">累计收益</div>
                        </div>
                        <div class="inverst-term stat-item center">
                            <div 
                            class="val" 
                            v-html="`${item.fromYearYield}%`"
                            ></div>
                            <div class="concept-name">今年以来</div>
                        </div>
                        <div class="inverst-limit stat-item right">
                            <div 
                            class="val" 
                            v-html="`${item.latestYearYield}%`"
                            ></div>
                            <div class="concept-name">近一年</div>
                        </div>
                   </div>
               </div>
           </div>
       </div>
    </div>
</template>

<script>
import {generateTrendOrIntervalConfig} from "../../../js/options-config.js";
export default {
    props: {
        moduleData: {
            type: Object,
            default: {}
        }
    },
    data(){
        return {
            fundInfoCache: {},
            fundInfo: [{}],
            map: {}
        }
    },
    computed: {
        compData(){
            return {
                mainTitle: this.moduleData.mainTitle || "主标题",
                subTitle: this.moduleData.subTitle || "副标题",
                fundInfo: this.fundInfo.map((item) => {
                    return Object.assign({},item, {
                        tags: item.tags && item.tags.length ? item.tags : ["标签"],
                        comulateYield: item.comulateYield || "--",
                        fromYearYield: item.fromYearYield || "--",
                        latestYearYield: item.latestYearYield || "--",
                        recommendation: item.recommendation || "推荐语",
                        productName: item.productName || "产品名称",
                    }) 
                })
            }
        },
    },
    methods: {
        getDiffFundData(){
            if(this.moduleData.funds instanceof Array){
                this.fundInfo = JSON.parse(JSON.stringify(this.moduleData.funds));
                this.fundInfo.forEach((fund) => {
                    if(!fund.productId){
                        fund.nav = "--";
                        fund.intervalName = "累计收益";
                        fund.intervalVal = "--";
                        fund.runTime = "--";
                    }else if(this.fundInfoCache[fund.productId]){
                        this.getDataFromMap(fund);
                        // fund.data = this.fundInfoCache[fund.productId];
                    }else{
                        this.getFundData(fund.productId).then((resp) => {
                            if (!resp)return;
                            let res = resp instanceof Object ? res : JSON.parse(resp);
                            if(res.data && res.data.list instanceof Array){
                                let incomeMap = {};
                                let arr = JSON.parse(JSON.stringify(res.data.list));
                                arr.forEach((item, index) => {
                                    incomeMap[index] = item.self_income
                                });
                                incomeMap.ret_incep = res.data.ret_incep;
                                incomeMap.ret_incep_a = res.data.ret_incep_a;
                                incomeMap.nav = res.data.nav;
                                incomeMap.priceDate = res.data.price_date;
                                incomeMap.runTime = this.dateCalculate(res.data);
                                this.fundInfoCache[fund.productId] = incomeMap;
                                this.getDataFromMap(fund);
                            }
                        }) 
                    }
                })
            }
        },
        getDataFromMap(fund){
            let data = this.fundInfoCache[fund.productId];
            fund.comulateYield = data['ret_incep'];
            fund.fromYearYield = data[0];
            fund.latestYearYield = data[4];
            // fund.priceDate = data.priceDate;
            fund.imgUrl = this.getImgUrl(fund.productId, fund.trend);
            this.$set(fund, "priceDate", data.priceDate)
        },
        getImgUrl(id, trend){
            if(id!== undefined && trend !== undefined){
                return `${this.$baseUrl[process.env.NODE_ENV]["host"]}/api/directSale/getCurve?fund_id=${id}&limit=${trend}`
            }else{
            }
        },
        getFundData(id){
            let params = {
                id: id,
            }
            return new Promise((resolve, reject) => {
                $.ajax({
                    type: "GET",
                    // dataType: "jsonp",
                    url: `${this.$baseUrl[process.env.NODE_ENV]["officialMobile"]}/fund/performanceApi`,
                    xhrFields: {
                      withCredentials: true
                    },
                    crossDomain: true,
                    data: params,
                    success: (res) => {
                        resolve(res);
                    },
                    error: () => {

                    }
                })
            });
        },
        dateCalculate (v) { // 计算私募证券运行时间
            if (!v.inception_date) return '--'
            let past = +new Date(v.inception_date.replace(/-/g, '/'))
            let now = v.liquidate_date ? +new Date(v.liquidate_date.replace(/-/g, '/')) : +new Date()
            let date = new Date(now - past)
            let day = date.getDate()
            let month = date.getMonth() + (day > 2 ? 1 : 0)
            let year = date.getFullYear() + (month === 12 ? (month = 0, 1) : 0) - 1970
            return `${year !== 0 ? `${year}年` : ''}${month !== 0 ? `${month}个月` : ''}`
        },

    },
    mounted() {
        generateTrendOrIntervalConfig().forEach(item => {
            this.map[item.value] = item.label;
        })
        this.getDiffFundData();
    },
    watch: {
        moduleData: {
            handler(val){
                this.getDiffFundData();
            }
        },
    }
}
</script>
<style lang="less" scoped>
   .pe-fund3{
        // 产品内容
        .product-container{
            // 产品简称和标签
            .product-item{
                display: flex;
                .product-graph{
                    width: 84.60px;
                    height: 71.25px;
                    background-color: #e3e1e1;
                    margin: 18.7px 13.8px 0 0;
                    text-align: center;
                    line-height: 71.25px;
                    img{
                        width: 100%;
                        height: 100%;
                    }
                    .img-notice{
                        color: #9b9b9b;
                    }
                }
                .product-info{
                    flex: 1;
                    .product-shortname{
                        line-height: 20px;
                        font-size: 14.25px;
                        color: #333;
                        margin-top: 1.78px;
                        text-align: left;
                        font-weight: bold;
                    }
                    .recomend-msg{
                        line-height: 16.48px;
                        font-size: 12px;
                        color: #999;
                        text-align: left;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                        width: 191.53px;
                    }
                    .product-stat-row{
                        display: flex;
                        margin-top: 16.03px;
                        font-size: 14px;
                        justify-content: space-between;
                        text-align: left;
                        .stat-item{
                            flex: 1;
                            max-width: 72px;
                            .val{
                                font-size: 14px;
                            }
                        }
                    }
                }
            }
           
        }
   }
</style>