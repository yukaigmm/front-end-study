<template>
  <vmodal
    ref="modal"
    title="请选择样式"
    class="add-nav-modal t2-el-dialog"
    :width="modalWidth"
    @close="closeModal"
  >
    <div class="style-warpper">
      <ul>
        <li
          class="style-comp-wrapper direct-sale-module"
          :class="{'active-style':item==currentStyle}"
          v-for="(item,index) in stylesList"
          :key="index"
          @click="selectStyle(item)"
        >
          <component :is="item"></component>
        </li>
      </ul>
    </div>
  </vmodal>
</template>

<script>
import commonProduct from "../common-product/index";
import peFund1 from "../nav-product/nav1/index";
import peFund2 from "../nav-product/nav2/index";
import fixedIncome from "../fix-yield-product/index";
import privateEquity from "../equity-product/index";
import ad1 from "../../ad/ad1/index";
import ad2 from "../../ad/ad2/index";
import hotPoint1 from "../../hot-point/index";
import notice1 from "../../notice/index";
import viewPoint1 from "../../view-point/index";

export default {
  components: {
    commonProduct, // 通用产品
    peFund1, // 净值产品样式一
    peFund2, // 净值产品样式二
    fixedIncome, // 固定收益样式
    privateEquity, //私募股权
    ad1, // 广告样式一
    ad2, // 广告样式二
    hotPoint1, // 热点样式一
    notice1, // 公告样式一
    viewPoint1 //观点样式
  },

  props: {
    stylesList: {
      type: [Array, Object],
      default: () => ["peFund1", "peFund2"]
    },

    value: {
      type: Boolean,
      default: false
    },

    currentStyle: {
      default: ""
    }
  },

  model: {
    prop: "value",
    event: "change"
  },

  computed: {
    modalWidth() {
      return this.stylesList.length * 368;
    }
  },

  watch: {
    value: {
      handler(val) {
        if (val) {
          this.$refs.modal.open();
          this.$emit("change", val);
        }
      },

      immediate: true
    }
  },

  data() {
    return {};
  },

  methods: {
    closeModal() {
      this.$emit("change", false);
    },

    selectStyle(val) {
      this.$refs.modal.close();
      this.$emit("getStyle", val);
      this.closeModal();
    }
  }
};
</script>

<style lang="less" scoped>
.style-warpper {
  ul {
    background: #ffffff;
    display: flex;
    justify-content: center;
    align-items: center;
    // height: 140px;
    width: 100%;
    background-color: #ffffff;
    padding: 20px;
  }
  .style-comp-wrapper {
    padding: 4px;
    flex: 1;
    margin-left: 12px;
    &:first-child {
      margin-left: 0;
    }
    // background-color: #ffffff;
    border: 2px solid #111111;
    &:hover {
      border: 2px dashed red;
    }

    &.active-style {
      border: 2px solid red;
    }
  }
}
</style>


