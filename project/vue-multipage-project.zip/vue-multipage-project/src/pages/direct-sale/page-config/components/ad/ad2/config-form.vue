
<template>
  <div class="ad2-wrapper">
    <h2 class="config-title">
      广告模块2
      <span class="action-btn" @click="switchPosition">[左右位置互换]</span>
    </h2>

    <div class="config-content-area">
      <div v-for="(item,index) in forms" :key="item">
        <div class="content-title">
          <span class="title">{{`${index==0?'左':"右"}广告`}}</span>
        </div>

        <el-form
          class="single-content form-content-area"
          :ref="`form${index}`"
          :rules="validateRules"
          :model="formData[index]"
          label-width="75px"
          label-position="left"
        >
          <el-form-item label="图片：" prop="pic">
            <vimageUpload
              showRecommendSize
              recommendSize="501x465"
              v-model="formData[index]['pic']"
              url="file/visitingCard"
              fieldName="directSalePicture"
              @change="onPicChange(index)"
              :imgStyle="{
                            minWidth: '110px',
                            maxWidth: '110px',
                            height: '102px'
                        }"
            />
          </el-form-item>

          <el-form-item label="跳转：" prop="jumpType">
            <el-select v-model="formData[index]['jumpType']" style="width:100%;">
              <el-option value="1" label="外链"></el-option>
              <el-option value="2" label="PDF"></el-option>
              <el-option value="5" label="无跳转"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="外链：" prop="link" v-if="formData[index]['jumpType']=='1'" key="link">
            <el-input v-model.trim="formData[index]['link']" placeholder="请输入链接"/>
          </el-form-item>
          <el-form-item
            v-if="formData[index]['jumpType']=='2'"
            label="文件："
            prop="fileData"
            key="file"
          >
            <vfileUpload
              v-model="formData[index]['fileData']"
              @getFileData="getFileData(index,'file')"
              url="file/visitingCard"
              fileName="directSalePdf"
              class="custom-file-uploader"
              resName="fileName"
              :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
            />
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import { isEqual } from "lodash";
export default {
  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "ad2",
        ads: [{ jumpType: "1" }, { jumpType: "1" }]
      })
    }
  },

  beforeDestroy() {
    this.validate();
  },

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("文件不能为空！"));
      }

      cb(errors);
    };
    return {
      forms: [Date.now(), Date.now() + 1],
      formData: [{ jumpType: "1" }, { jumpType: "1" }],
      validateRules: {
        pic: {
          required: true,
          message: "图片不能为空"
        },

        fileData: [
          {
            required: true,
            message: "文件不能为空"
          },

          {
            validator: validateFileData
          }
        ],

        link: {
          required: true,
          message: "链接不能为空"
        }
      }
    };
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  watch: {
    formData: {
      handler(val) {
        let data = {
          name: "ad2",
          validate: this.configData.validate,
          moduleTitle: this.configData.moduleTitle,
          compKey: this.configData.compKey,
          ads: val
        };

        this.$emit("getFormData", data);
      },

      deep: true
    },

    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }

        let ads =
          val.ads && val.ads.length
            ? JSON.parse(JSON.stringify(val.ads))
            : [{ jumpType: "1" }, { jumpType: "1" }];
        let data = this.transferData(ads, "file");
        this.formData = JSON.parse(
          JSON.stringify(data || [{ jumpType: "1" }, { jumpType: "1" }])
        );
      },

      deep: true,

      immediate: true
    }
  },

  methods: {
    onPicChange(index) {
      this.$refs[`form${index}`][0].validateField("pic");
    },

    getFileData(index, key) {
      this.formData[index][key] = this.formData[index][`${key}Data`].filePath;
      this.formData[index][`${key}Name`] = this.formData[index][key]
        ? this.formData[index][`${key}Data`].fileName
        : "";
      this.$refs[`form${index}`][0].validateField("fileData");
    },

    transferData(data = [], key) {
      return data.map(item => {
        item[`${key}Data`] = {
          fileName: item[`${key}Name`],
          filePath: item[key]
        };
        return item;
      });
    },

    switchPosition() {
      let item0 = this.formData[0];
      let item1 = this.formData[1];
      let formItem0 = this.forms[0];
      let formItem1 = this.forms[1];
      this.$set(this.forms, 0, formItem1);
      this.$set(this.forms, 1, formItem0);
      this.$set(this.formData, 0, item1);
      this.$set(this.formData, 1, item0);
    },

    validate() {
      let finalValid = true;

      this.forms.forEach((form, index) => {
        if (this.$refs[`form${index}`][0]) {
          this.$refs[`form${index}`][0].validate(valid => {
            finalValid = finalValid && valid;
          });
        }
      });

      let ads = JSON.parse(JSON.stringify(this.formData)) || [];

      let adConfig = ads.map(ad => {
        delete ad.fileData;
        if (ad.jumpType == "1") {
          delete ad.file;
          delete ad.fileName;
        } else if (ad.jumpType == "2") {
          delete ad.link;
        } else {
          delete ad.file;
          delete ad.fileName;
          delete ad.link;
        }

        return ad;
      });

      let data = {
        name: "ad2",
        moduleTitle: this.configData.moduleTitle,
        compKey: this.configData.compKey,
        validate: finalValid,
        ads: adConfig
      };

      this.$emit("getFormData", data, true);
    },

    resetValid() {
      this.forms.forEach((form, index) => {
        if (this.$refs[`form${index}`][0]) {
          this.$refs[`form${index}`][0].clearValidate();
        }
      });
    }
  }
};
</script>

<style lang="less" >
.custom-file-uploader.file-upload-container {
  margin-top: 8px;
}

.ad2-wrapper {
  .config-title {
    // margin-bottom: 8px;
  }

  .action-btn {
    color: #1073c5;
    font-size: 12px;
    cursor: pointer;
  }

  // .content-title {
  //   margin: 8px 0;
  //   line-height: 14px;
  //   height: 14px;
  //   padding: 0 8px;
  //   .title {
  //     font-size: 14px;
  //   }
  // }
}

.el-form-item.is-success .el-input__inner:hover,
.el-form-item.is-success .el-textarea__inner:hover {
  border-color: #c0c4cc !important;
}

.el-form-item.is-success .el-input__inner,
.el-form-item.is-success .el-textarea__inner {
  border-color: #555555 !important;
}
.el-form-item.is-success .el-input__inner:focus,
.el-form-item.is-success .el-textarea__inner:focus {
  border-color: #409eff !important;
}
</style>

