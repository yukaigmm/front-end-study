
<template>
  <div class="ad1-wrapper">
    <h2 class="config-title">
      广告模块1
      <span class="ad1-tip">(提示：广告数量控制在1-10个)</span>
    </h2>
    <div class="config-content-area">
      <div v-for="(item,index) in formData" :key="compKeys[index]" class="single-content">
        <div class="content-title">
          <span class="title">{{`广告${index+1}`}}</span>
          <span
            class="action-btn move-left"
            :class="{'disable-btn':formData.length<=1}"
            @click="moveLeft(index)"
          >[左移]</span>
          <span
            class="action-btn move-right"
            :class="{'disable-btn':formData.length<=1}"
            @click="moveRight(index)"
          >[右移]</span>
          <span
            class="action-btn"
            :class="{'disable-btn':formData.length<=1}"
            @click="deleteAd1(index)"
          >[删除]</span>
        </div>

        <el-form
          :ref="`form${index}`"
          :rules="validateRules"
          :model="formData[index]"
          label-width="75px"
          label-position="left"
          class="form-content-area"
        >
          <el-form-item label="图片：" prop="pic">
            <vimageUpload
              showRecommendSize
              recommendSize="1035x303"
              v-model="formData[index]['pic']"
              url="file/visitingCard"
              fieldName="directSalePicture"
              @change="onPicChange(index)"
              :imgStyle="{
                            minWidth: '248px',
                            maxWidth: '263px',
                            height: '61px',
                        }"
            />
          </el-form-item>

          <el-form-item label="跳转：" prop="jumpType">
            <el-select v-model="formData[index]['jumpType']" style="width:100%;">
              <el-option value="1" label="外链"></el-option>
              <el-option value="2" label="PDF"></el-option>
              <el-option value="5" label="无跳转"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="外链：" prop="link" key="link" v-if="formData[index]['jumpType']=='1'">
            <el-input v-model.trim="formData[index]['link']" placeholder="请输入链接"/>
          </el-form-item>
          <el-form-item
            v-if="formData[index]['jumpType']=='2'"
            key="file"
            label="文件："
            prop="fileData"
          >
            <vfileUpload
              v-model="formData[index]['fileData']"
              url="file/visitingCard"
              fileName="directSalePdf"
              class="custom-file-uploader"
              resName="fileName"
              @getFileData="getFileData(index,'file')"
              :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
            />
          </el-form-item>
        </el-form>
      </div>
      <div class="add-btn-wrapper">
        <span
          class="action-btn add-btn"
          :class="{'disable-btn':formData.length>=10}"
          @click="addAd1"
        >+添加广告</span>
      </div>
    </div>
  </div>
</template>

<script>
import { isEqual } from "lodash";
export default {
  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "ad1",
        ads: [
          { jumpType: "1" },
          { jumpType: "1" },
          { jumpType: "1" },
          { jumpType: "1" }
        ]
      })
    }
  },
  beforeDestroy() {
    this.validate();
  },

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("文件不能为空！"));
      }

      cb(errors);
    };
    return {
      compKeys: [],
      formData: [{ jumpType: "1" }, { jumpType: "1" }],
      configData: {},
      validateRules: {
        pic: {
          required: true,
          message: "图片不能为空"
        },

        fileData: [
          {
            required: true,
            message: "文件不能为空"
          },
          { validator: validateFileData }
        ],

        link: {
          required: true,
          message: "链接不能为空"
        }
      }
    };
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  watch: {
    formData: {
      handler(val) {
        let data = {
          name: "ad1",
          validate: this.configData.validate,
          moduleTitle: this.configData.moduleTitle,
          compKey: this.configData.compKey,
          ads: val || []
        };
        // this.$nextTick(() => {

        // });

        this.$emit("getFormData", data);
      },
      deep: true
    },

    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }

        let ads =
          val.ads && val.ads.length
            ? JSON.parse(JSON.stringify(val.ads))
            : [{ jumpType: "1" }];
        let data = this.transferData(ads, "file");
        this.formData = JSON.parse(JSON.stringify(data || [{ jumpType: "1" }]));
        this.compKeys = this.setCompKeys(this.formData, this.compKeys || []);
      },

      deep: true,

      immediate: true
    }
  },

  methods: {
    onPicChange(index) {
      this.$refs[`form${index}`][0].validateField("pic");
    },

    setCompKeys(originBaseData, targetData = [], index) {
      let target = JSON.parse(JSON.stringify(targetData));
      if (index || index === 0) {
        target.splice(index, 1);
      }
      let len =
        originBaseData.length > targetData.length
          ? originBaseData.length
          : targetData.length;

      for (let i = 0; i < len; i++) {
        if (!index && index !== 0) {
          if (originBaseData[i] && !target[i]) {
            target[i] = Date.now() + i;
          }
        }
      }

      return target;
    },

    getFileData(index, key) {
      this.formData[index][key] = this.formData[index][`${key}Data`].filePath;
      this.formData[index][`${key}Name`] = this.formData[index][key]
        ? this.formData[index][`${key}Data`].fileName
        : "";
      this.$refs[`form${index}`][0].validateField("fileData");
    },

    transferData(data = [], key) {
      return data.map(item => {
        item[`${key}Data`] = {
          fileName: item[`${key}Name`],
          filePath: item[key]
        };
        return item;
      });
    },

    addAd1() {
      let len = this.formData.length;

      if (len >= 10) {
        // this.$message({
        //   type: "error",
        //   message: "最多只能添加十个广告",
        //   showClose: true
        // });
        return;
      }
      this.formData.push({ jumpType: "1" });
    },

    deleteAd1(index) {
      let len = this.formData.length;
      if (len <= 1) {
        // this.$message({
        //   type: "error",
        //   message: "至少要有一个广告",
        //   showClose: true
        // });
        return;
      }
      this.compKeys.splice(index, 1);
      this.formData.splice(index, 1);
    },

    switch(direction, index) {
      if (this.formData.length <= 1) {
        return;
      }
      let nearIndex;

      if (direction === "left") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: "当前广告已在最左边！",
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (index >= this.formData.length - 1) {
          this.$message({
            type: "error",
            message: "当前广告已在最右边！",
            showClose: true
          });
          return;
        }

        nearIndex = index + 1;
      }

      let currentKey = this.compKeys[index];
      let nearKey = this.compKeys[nearIndex];
      this.$set(this.compKeys, nearIndex, currentKey);
      this.$set(this.compKeys, index, nearKey);

      let currentItem = this.formData[index];
      let nearItme = this.formData[nearIndex];
      this.$set(this.formData, nearIndex, currentItem);
      this.$set(this.formData, index, nearItme);
    },

    moveLeft(index) {
      this.switch("left", index);
    },

    moveRight(index) {
      this.switch("right", index);
    },

    validate() {
      let finalValid = true;

      this.formData.forEach((form, index) => {
        if (this.$refs[`form${index}`][0]) {
          this.$refs[`form${index}`][0].validate(valid => {
            finalValid = finalValid && valid;
          });
        }
      });

      let ads = JSON.parse(JSON.stringify(this.formData)) || [];

      let adConfig = ads.map(ad => {
        delete ad.fileData;
        if (ad.jumpType == "1") {
          delete ad.file;
          delete ad.fileName;
        } else if (ad.jumpType == "2") {
          delete ad.link;
        } else {
          delete ad.file;
          delete ad.fileName;
          delete ad.link;
        }

        return ad;
      });
      let data = {
        name: "ad1",
        validate: finalValid,
        compKey: this.configData.compKey,
        moduleTitle: this.configData.moduleTitle,
        ads: adConfig
      };
      this.$emit("getFormData", data, true);
    },

    resetValid() {
      this.formData.forEach((form, index) => {
        if (this.$refs[`form${index}`][0]) {
          this.$refs[`form${index}`][0].clearValidate();
        }
      });
    }
  }
};
</script>

<style lang="less" >
.el-form--label-left .el-form-item__label {
  position: relative !important;
}
.config-content-area {
  width: 100%;
  padding-top: 2px;
  background-color: #292929;
  box-shadow: inset 0 1px 0 0 hsla(0, 0%, 100%, 0.24);
  border-radius: 5px;
  padding-bottom: 5px;
  overflow-y: auto;
  overflow-x: hidden;
}
.config-title,
.fund-title {
  color: #eee;
  font-size: 14px;
  font-weight: normal;
  padding: 5px 10px;
  height: 40px;
  line-height: 40px;
}

.move-left {
  margin-left: 31px;
}

.form-content-area {
  padding: 10px;
  padding-bottom: 0px;
  cursor: initial;
}

.add-btn {
  padding-top: 8px;
  padding-left: 8px;
  display: block;
  width: 80px;
}

.content-title {
  cursor: initial;
  color: #eee;
  margin: 8px 0;
  line-height: 30px;
  background-color: #1a1a1a;
  height: 30px;
  padding: 0px;
  .title {
    display: inline-block;
    font-size: 14px;
    border-left: 4px solid #17c;
    height: 14px;
    line-height: 14px;
    padding: 0;
    padding-left: 8px;
  }
}

.el-textarea__inner {
  color: #999 !important;
  font-size: 12px !important;
}

.el-form-item {
  margin-bottom: 15px !important;
}

.config-content-area {
  border-radius: 8px;
  background-color: #111;
  // padding: 10px;
  cursor: initial;
}

.el-form-item.is-required .el-form-item__label:before {
  position: absolute;
  left: -8px;
}

.action-btn {
  color: #1073c5;
  cursor: pointer;
  font-size: 12px;
}

// .single-content {
//   border-bottom: 1px solid #000;
// }

.custom-file-uploader.file-upload-container {
  margin-top: 8px;
}

.ad1-wrapper {
  .ad1-tip {
    font-size: 12px;
    font-weight: 300;
    color: #999;
  }

  .move-right {
    margin: 0 10px;
  }
}
</style>

