
<template>
  <div class="config-wrapper view-point">
    <h2 class="config-title">
      观点资讯模块
      <span class="config-tip">(提示：数量控制在1-30个)</span>
    </h2>

    <div class="config-content-area">
      <el-form
        ref="form"
        :rules="validateRules"
        :model="formData"
        label-width="75px"
        validate-on-rule-change
        label-position="left"
      >
        <div class="form-content-area">
          <el-form-item label="主标题:" prop="mainTitle">
            <el-input v-model.trim="formData.mainTitle" placeholder="请输入主标题，最多仅展示一行"/>
          </el-form-item>

          <el-form-item label="副标题:" prop="subTitle">
            <el-input v-model.trim="formData.subTitle" placeholder="请输入副标题，最多仅展示一行"/>
          </el-form-item>
        </div>

        <el-form
          class="single-content"
          :ref="`view${index}`"
          :rules="validateRules"
          validate-on-rule-change
          :model="view"
          label-width="75px"
          label-position="left"
          v-for="(view,index) in formData.views"
          :key="compKeys[index]"
        >
          <h3 class="view-title content-title">
            <span class="title">{{`观点${index+1}`}}</span>

            <span
              class="action-btn move-up"
              :class="{'disable-btn':formData.views.length<=1}"
              @click="moveUp(index)"
            >[上移]</span>
            <span
              class="action-btn move-down"
              :class="{'disable-btn':formData.views.length<=1}"
              @click="moveDown(index)"
            >[下移]</span>
            <span
              class="action-btn delete-btn"
              :class="{'disable-btn':formData.views.length<=1}"
              @click="deleteView(index)"
            >[删除]</span>
          </h3>

          <div class="form-content-area">
            <el-form-item label="标题:" prop="title">
              <el-input v-model.trim="view.title" placeholder="请输入标题"/>
            </el-form-item>

            <el-form-item label="发布时间：" prop="publishTime" key="date">
              <vdatePicker
                v-model="view.publishTime"
                style="width:100%;"
                class="custom-datepicker"
                @change="dateChange(index)"
              />
            </el-form-item>

            <el-form-item label="跳转：" prop="jumpType" key="jump">
              <el-select v-model="view.jumpType" style="width:100%;">
                <el-option value="1" label="外链"></el-option>
                <el-option value="2" label="PDF"></el-option>
                <el-option value="4" label="新内容"></el-option>
                <el-option value="5" label="无跳转"></el-option>
              </el-select>
            </el-form-item>

            <el-form-item label="外链：" prop="link" v-if="view.jumpType=='1'">
              <el-input v-model.trim="view.link" placeholder="请输入链接"/>
            </el-form-item>

            <el-form-item v-if="view.jumpType=='2'" label="文件：" prop="fileData">
              <vfileUpload
                v-model="view.fileData"
                @getFileData="getFileData(index)"
                url="file/visitingCard"
                fileName="directSalePdf"
                class="custom-file-uploader"
                resName="fileName"
                :foreignPath="true"
                :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
              />
            </el-form-item>

            <el-form-item v-if="view.jumpType=='4'" label="文本：" prop="content" key="content">
              <editor v-model="view.content" @change="onContentChange(index)"/>
            </el-form-item>
          </div>
        </el-form>
        <div class="add-btn-wrapper">
          <div
            class="add-view-btn add-fund-btn add-btn"
            :class="{'disable-btn':formData.views.length>=30}"
            @click="addview"
          >+添加观点</div>
        </div>
      </el-form>
    </div>
  </div>
</template>

<script>
import editor from "../../../../../common/components/inputs/editor-with-menu/editor";
import { isEqual } from "lodash";
import commonMethods from "../../mixins/common-methods";

export default {
  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "viewPonit",
        views: [{ jumpType: "4", content: "" }]
      })
    }
  },

  mixins: [commonMethods],

  beforeDestroy() {
    this.validate();
  },

  components: {
    editor
  },

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("文件不能为空"));
      }

      cb(errors);
    };

    const validatePublishDate = (rules, value, cb) => {
      let errors = [];
      if (!value) {
        errors.push(new Error("发布时间不能为空"));
      }
      cb(errors);
    };
    return {
      compKeys: [],
      formData: {
        name: "viewPonit",
        views: [{ content: "", jumpType: "4" }]
      },
      validateRules: {
        publishTime: [
          {
            required: true,
            message: "发布时间不能为空"
          },
          {
            validator: validatePublishDate,
            trigger: "change"
          }
        ],
        title: {
          required: true,
          message: "标题不能为空"
        },
        fileData: [
          {
            required: true,
            message: "文件不能为空"
          },
          { validator: validateFileData }
        ],
        link: {
          required: true,
          message: "链接不能为空"
        },
        content: {
          required: true,
          message: "新内容不能为空"
        }
      }
    };
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },

      deep: true
    },

    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }

        let data = JSON.parse(JSON.stringify(val));

        data.views =
          data.views && data.views.length
            ? this.transferData(data.views, "file")
            : [{ jumpType: "4", content: "" }];
        this.formData = JSON.parse(JSON.stringify(data));
        this.compKeys = this.setCompKeys(
          this.formData.views,
          this.compKeys || []
        );
      },

      deep: true,

      immediate: true
    }
  },

  methods: {
    dateChange(index) {
      this.$refs[`view${index}`][0].validateField("publishTime");
    },

    onContentChange(index) {
      this.$refs[`view${index}`][0].validateField("content");
    },

    getFileData(index) {
      this.formData.views[index].file = this.formData.views[
        index
      ].fileData.filePath;
      this.formData.views[index].fileName = this.formData.views[index].file
        ? this.formData.views[index].fileData.fileName
        : "";
      this.$refs[`view${index}`][0].validateField("fileData");
    },
    switch(direction, index) {
      if (this.formData.views.length <= 1) {
        return;
      }
      let nearIndex;

      if (direction === "up") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: "当前观点已在最上边！",
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (index >= this.formData.views.length - 1) {
          this.$message({
            type: "error",
            message: "当前观点已在最下边！",
            showClose: true
          });
          return;
        }

        nearIndex = index + 1;
      }
      let currentKey = this.compKeys[index];
      let nearKey = this.compKeys[nearIndex];
      this.$set(this.compKeys, nearIndex, currentKey);
      this.$set(this.compKeys, index, nearKey);

      let currentItem = this.formData.views[index];
      let nearItme = this.formData.views[nearIndex];
      this.$set(this.formData.views, nearIndex, currentItem);
      this.$set(this.formData.views, index, nearItme);
    },

    moveUp(index) {
      this.switch("up", index);
    },

    moveDown(index) {
      this.switch("down", index);
    },

    deleteView(index) {
      if (this.formData.views.length <= 1) {
        return;
      }
      this.compKeys.splice(index, 1);
      this.formData.views.splice(index, 1);
    },

    addview() {
      if (this.formData.views.length >= 30) {
        return;
      }
      this.formData.views.push({
        jumpType: "4",
        content: ""
      });
    },

    validate() {
      let finalValid = true;

      this.formData.views.forEach((form, index) => {
        if (this.$refs[`view${index}`][0]) {
          this.$refs[`view${index}`][0].validate(valid => {
            finalValid = finalValid && valid;
          });
        }
      });

      this.$set(this.formData, "validate", finalValid);
      let data = JSON.parse(JSON.stringify(this.formData));
      data.views = this.deleteUselessKeys(data.views);
      this.$emit("getFormData", data, true);
    },

    resetValid() {
      this.formData.views.forEach((form, index) => {
        if (this.$refs[`view${index}`][0]) {
          this.$refs[`view${index}`][0].clearValidate();
        }
      });
    }
  }
};
</script>

<style lang="less" >
.custom-datepicker {
  .el-input__prefix,
  .el-input__suffix {
    top: 4px !important;
  }
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100% !important;
  }
}

.custom-file-uploader.file-upload-container {
  margin-top: 8px;
}

.config-wrapper {
  .config-title {
    // margin-bottom: 8px;
  }

  .add-view-btn,
  .add-tag-btn {
    color: #1073c5;
    cursor: pointer;
  }

  .config-tip {
    font-size: 12px;
    font-weight: 300;
    color: #999;
  }

  .view-title {
    .action-btn {
      color: #1073c5;
      cursor: pointer;
      font-size: 12px;
    }
  }
}

.move-up {
  margin-left: 32px;
}

.move-dowm {
  margin: 0 10px;
}

.view-point {
  .el-form-item__content {
    display: flex;
    .delete-btn {
      width: 60px;
      margin-left: 10px;
    }
  }
}
</style>

