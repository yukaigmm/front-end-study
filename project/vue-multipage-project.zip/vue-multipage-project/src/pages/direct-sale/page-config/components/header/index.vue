<template>
  <div>
    <div class="icon-title-wrapper">
      <div class="header-icon-wrapper" :style="`background-image:url(${headerInfo.logo})`"></div>
      <div class="header-title-wrapper">
        <div class="main-follow-wrapper">
          <span class="main-title">
            {{headerInfo.company_short_name||headerInfo.company_name}}
            <span></span>
          </span>
          <span class="follow-btn">+加关注</span>
        </div>

        <div class="subtitle-wrapper">
          <span v-for="item in subTitleKeysData" :key="item" :title="item">{{item}}</span>
        </div>
      </div>
    </div>

    <div class="spread-key-wrapper">
      <span v-for="item in spreadKeysData" :key="item" :title="item">{{item}}</span>
    </div>
  </div>
</template>

<script>
import { getCompanyInfo } from "../../../../../common/js/utils.js";
import { ajax } from "jquery";
export default {
  props: {
    moduleData: {
      type: Object,
      default: {}
    }
  },

  data() {
    return {
      headerInfo: {},
      subTitleKeysData: [],
      spreadKeysData: []
    };
  },

  computed: {
    companyId() {
      return getCompanyInfo().companyId || "";
    }
  },

  watch: {
    moduleData: {
      handler(val) {
        this.getChosenData();
      },

      immediate: true
    },

    headerInfo: {
      handler(val) {
        this.getChosenData();
      },

      immediate: true
    }
  },

  mounted() {
    this.getCompanyInfo();
  },

  methods: {
    getCompanyInfo() {
      let params = { id: this.companyId };
      ajax({
        url: `${
          this.$baseUrl[process.env.NODE_ENV]["officialMobile"]
        }/company/headInfoApi/`,
        type: "GET",
        xhrFields: { withCredentials: true },
        crossDomain: true,
        data: params,
        success: data => {
          this.headerInfo =
            data instanceof Object ? data.data : JSON.parse(data).data;
        },
        error: e => {
          this.headerInfo = {};
        }
      });
    },

    getChosenData() {
      let mapping = {
        "1": "register_number",
        "2": "city",
        "3": "establish_date",
        "4": "core_strategy",
        "5": "registered_capital",
        "6": "company_asset_size",
        "7": "company_type"
      };

      let titleMapping = {
        "1": "备案编码：",
        "2": "所在地区：",
        "3": "成立日期：",
        "4": "核心策略：",
        "5": "注册资本：",
        "6": "管理规模：",
        "7": "机构类型："
      };

      let companyTypeMapping = {
        "1": "私募证券投资",
        "2": "公募基金公司",
        "3": "银行",
        "4": "证券公司",
        "5": "信托公司",
        "6": "审计机构",
        "7": "法律顾问",
        "8": "投资顾问",
        "9": "行政管理人",
        "10": "上市公司",
        "11": "期货公司",
        "12": "基金公司子公司",
        "13": "工作室",
        "14": "私募股权投资",
        "15": "证券公司子公司",
        "16": "期货公司子公司",
        "17": "私募创业投资",
        "18": "私募其他投资",
        "-1": "其他"
      };

      let spreadKeys = this.moduleData.spreadIndicatorKeys || [];
      let subTitleKeys = this.moduleData.subIndicatorKeys || [];
      this.spreadKeysData = [];
      this.subTitleKeysData = [];
      spreadKeys.forEach(key => {
        let info = "";
        if (key == "7") {
          info = `${titleMapping[key]}${companyTypeMapping[
            this.headerInfo[mapping[key]]
          ] || "--"}`;
        } else {
          info = `${titleMapping[key]}${this.headerInfo[mapping[key]] || "--"}`;
        }

        this.spreadKeysData.push(info);
      });

      subTitleKeys.forEach(key => {
        let info = "";
        if (key == "7") {
          info = `${titleMapping[key]}${companyTypeMapping[
            this.headerInfo[mapping[key]]
          ] || "--"}`;
        } else {
          info = `${titleMapping[key]}${this.headerInfo[mapping[key]] || "--"}`;
        }
        this.subTitleKeysData.push(info);
      });
    }
  }
};
</script>

<style lang="sass" scoped>
@function getSize($size){
    @return $size/2*336/375*1px
}

.icon-title-wrapper{
    display:flex;
    justify-content:flex-start;
    align-items:center;
   
}

.header-icon-wrapper{
    width:getSize(117);
    height:getSize(117);
    margin-right:getSize(20);
    border-radius:getSize(19);
    background-repeat:no-repeat; 
    background-size:100% 100%;
     box-shadow: 0 1px 5px rgba(0,0,0,.16);
}

.header-title-wrapper{
    flex:1;
    display:flex;
    flex-direction:column;
    justify-content:center;
    align-items:space-between;
}

.main-follow-wrapper, .subtitle-wrapper{
    flex:1;
    display:flex;
    align-items:center;
    justify-content:space-between;
}

.subtitle-wrapper{
    margin-top:6px;
    span{
        width:123px;
        overflow:hidden;
        white-space:nowrap;
        text-overflow:ellipsis; 
    }
}

span.main-title{
    font-size:getSize(43);
    color:#333;
    font-family:PingFangSC-Medium;
    font-weight:600;
}

.follow-btn{
    width:getSize(133);
    height:getSize(50);
    border-radius:getSize(25);
    border:1px solid #AC9374;
    font-size:getSize(26);
    text-align:center;
    line-height:getSize(48);
    vertical-align:center;
    color:#AC9374;
}

.spread-key-wrapper{
    display:flex;
    flex-wrap:wrap;
    align-items:center;
    justify-content:space-between;
    margin-top:getSize(30);
    span{
        width :47%;
        overflow:hidden;
        white-space:nowrap;
        text-overflow:ellipsis; 
        &:nth-child(even){
            // text-align:right;
            margin-left:6%;
        }
        &:nth-child(n+3){
            margin-top:6px;
        }
    }
}
</style>
