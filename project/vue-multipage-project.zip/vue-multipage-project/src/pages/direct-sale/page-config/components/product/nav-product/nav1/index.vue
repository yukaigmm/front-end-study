<template>
  <div class="product-item">
    <div class="product-brief">
      <div class="product-brief-intro">{{fundData.productName}}</div>
      <div class="label-container" v-if="fundData.tags.length">
        <span v-for="(tag, i) in fundData.tags" :key="i" class="product-label">{{tag}}</span>
      </div>
      <div v-for="(item, index) in fundData.intervalIncomeArr" :key="index">
        <div class="val" :class="item.className">{{item.value}}</div>
        <div class="concept-name">{{item.name}}</div>
      </div>
    </div>
    <div class="get-detail" v-if="+fundData.jumpType !== 5">查看详情</div>
  </div>
</template>

<script>
export default {
  props: {
    fundData: {
      type: Object,
      default: {
        productName: "产品名称",
        tags: ["标签"],
        intervalIncomeArr: [{ name: "累计收益", value: "%" }],
        jumpType: 1
      }
    }
  },
  data() {
    return {};
  },
  computed: {},
  methods: {},
  mounted() {},
  watch: {
    fundData: {
      handler(val) {},
      deep: true,
      immediate: true
    }
  }
};
</script>
<style lang="less" scoped>
.product-item {
  .product-brief {
    line-height: 1.5;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    text-align: center;
    .label-container {
      margin-top: 10px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .val {
      margin-top: 22.27px;
      font-weight: 700;
      // color: #e1322d;
      line-height: 26.27px;
      font-size: 18.7px;
    }
  }
}
</style>