<template>
    <div class="product-item">
        <div class="product-brief">
            <div class="product-short-name">{{fundInfo.productName}}</div>
            <div class="tag-container">
                <span
                    v-for="(tag, i) in fundInfo.tags"
                    :key="i"
                    class="product-label"
                >{{tag}}</span>
            </div>
        </div>
        <div class="product-stat-row">
            <div class="standard stat-item left">
                <div class="val" style="color: #f45">{{fundInfo.termValue}}</div>
                <div class="concept-name">存续期限</div>
            </div>
            <div class="inverst-term stat-item center">
                <div class="val" style="color: #333">{{fundInfo.purchaseAmount}}</div>
                <div class="concept-name">起投金额</div>
            </div>
            <div class="inverst-limit stat-item right">
                <div class="val" style="color: #333">{{fundInfo.investmentOrientation}}</div>
                <div class="concept-name">投资方向</div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        fund: {
            type: Object,
            default: {}
        },
    },
    data(){
        return {
            fundData: {},
            fundInfoCache: {},
            termMap: {
                1: "日",
                30: "月",
                365: "年"
            },
            amountUnitMap: {
                1: "元",
                5: "万元"
            },
            currencyMap: {
                "CNY": "人民币",
                "USD": "美元",
                "JPY": "日元",
                "EUR": "欧元",
                "GBP": "英镑",
                "KRW": "韩元",
                "HKD": "港元",
                "AUD": "澳元",
                "CAD": "加元",
            }
        }
    },
    computed: {
        fundInfo(){
            let fund = this.fundData;
            return {
                tags: fund.tags && fund.tags.length ? fund.tags : ["标签"],
                termValue: fund.termValue || "--",
                purchaseAmount: fund.purchaseAmount || "--",
                investmentOrientation: fund.investmentOrientation || "--",
                productName: fund.productName || "产品名称",
            }
        }
    },
    methods: {
        getFundData(id){
            let params = { id }
            return new Promise((resolve, reject) => {
                $.ajax({
                    type: "GET",
                    url: `${this.$baseUrl[process.env.NODE_ENV]["officialMobile"]}/equityFund/baseInfoApi`,
                    xhrFields: {
                        withCredentials: true
                    },
                    crossDomain: true,
                    data: params,
                    success: (resp) => {
                        let res = resp instanceof Object ? resp : JSON.parse(resp);
                        resolve(res);
                    },
                    error: () => {

                    }
                })
            });
        },
        buildFundData(){
            this.fundData = JSON.parse(JSON.stringify(this.fund));
            let fund = this.fundData;
            if(fund.productId){
                if(this.fundInfoCache[fund.productId]){
                    this.buildFundDataFromCache(fund);
                }else{
                    this.getFundData(fund.productId).then((res) => {
                        if (!res)return;
                        if(res.data){
                            let cacheItem = {
                                termValue: res.data.term_value + this.termMap[res.data.term_type],
                                purchaseAmount: res.data.purchase_amount + this.amountUnitMap[res.data.amount_unit] + (res.data.amount_currency_code == "CNY" ? "" : `(${this.currencyMap[res.data.amount_currency_code] || res.data.amount_currency_title})`),
                                investmentOrientation: res.data.investment_orientation
                            };
                            this.fundInfoCache[fund.productId] = cacheItem;
                            this.buildFundDataFromCache(fund);
                        }
                    })
                }
            }
        },
        buildFundDataFromCache(fund){
            let cacheItem = this.fundInfoCache[fund.productId];
            fund.termValue = cacheItem.termValue;
            fund.purchaseAmount = cacheItem.purchaseAmount;
            this.$set(fund, "investmentOrientation", cacheItem.investmentOrientation)
        }
    },
    watch: {
        fund: {
            handler(val){
                this.buildFundData();
            },
            deep: true,
            immediate: true
        }
    },
    mounted() {
    },
}
</script>
<style lang="less" scoped>
    // 产品简称和标签
    .product-item{
        .product-brief{
            line-height: 1.5;
            overflow: hidden;
            text-overflow:ellipsis;
            white-space: nowrap;
        }
    }
    // 产品数据
    .product-stat{
        margin-top: 16px;
        display: flex;
        justify-content: space-between;
        &>div{
            text-align: center;
        }
    }
</style>