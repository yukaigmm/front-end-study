<template>
  <div class="product-list">
    <div class="title-bar">
      <span class="product-config-title">标签页属性</span>
    </div>

    <div>
      <div
        class="tab-wrapper product-list-wrapper"
        v-for="(item,index) in tabs"
        :key="item.tabName"
      >
        <span>{{item.label}}</span>

        <div class="action-area">
          <span
            class="product-action-btn if-hide-btn"
            :class="{'to-hide-btn':!item.ifHide,'has-hiden-btn':item.ifHide,'if-hide-disabeld':item.tabName =='index'}"
            @click="setIfHide(item)"
          ></span>
          <span class="product-action-btn move-left" @click="moveLeft(index)"></span>
          <span class="product-action-btn move-right" @click="moveRight(index)"></span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import _ from "lodash";
export default {
  props: {
    configData: {
      type: [Object, Array]
    }
  },

  watch: {
    configData: {
      handler(val, preVal) {
        if (_.isEqual(val, preVal)) {
          return;
        }

        let data = JSON.parse(JSON.stringify(val));
        this.formData = data;
        this.getTabs();
      },

      deep: true,

      immediate: true
    },

    tabs: {
      handler(val) {
        this.getFormData();
      },

      immediate: true,

      deep: true
    },

    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },
      deep: true
    }
  },

  data() {
    return {
      formData: {},
      tabs: []
    };
  },

  methods: {
    getTabs() {
      let mapping = {
        index: "首页",
        product: "产品",
        manager: "经理",
        file: "档案",
        roadShow: "路演",
        comment: "点评"
      };
      this.tabs = [];
      let tabs = this.formData.tabs || [];

      _.forEach(tabs, tab => {
        this.tabs.push({
          label: mapping[tab.tabName],
          tabName: tab.tabName,
          ifHide: tab.ifHide
        });
      });
    },

    getFormData() {
      let tabs = JSON.parse(JSON.stringify(this.tabs));
      this.formData.tabs = _.map(tabs, item => ({
        tabName: item.tabName,
        ifHide: item.ifHide
      }));
    },

    setIfHide(data) {
      if (data.tabName == "index") {
        return;
      }
      let ifHide = !data.ifHide;
      data.ifHide = ifHide;
    },

    switch(drl, index) {
      let nearIndex;
      if (drl == "left") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: `当前标签已在最左边！`,
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (index >= this.tabs.length - 1) {
          this.$message({
            type: "error",
            message: `当前标签已在最右边！`,
            showClose: true
          });
          return;
        }
        nearIndex = index + 1;
      }

      let currentItem = this.tabs[index];
      let nearItem = this.tabs[nearIndex];

      this.$set(this.tabs, nearIndex, currentItem);
      this.$set(this.tabs, index, nearItem);
    },

    moveLeft(index) {
      this.switch("left", index);
    },

    moveRight(index) {
      this.switch("right", index);
    }
  }
};
</script>

<style lang="less" >
.tab-wrapper {
  justify-content: space-between !important;
  align-items: center;
  height: 30px;
  background-color: #000;
  margin-top: 10px;
  padding: 5px 8px;
  cursor: pointer;
  .if-hide-btn {
    background-image: url("../../../../../assets/images/显示隐藏icon.png");
    background-repeat: no-repeat;
    &.to-hide-btn {
      background-position: 0px 0px;
      &:hover {
        background-position: -16px 0px;
      }
    }

    &.has-hiden-btn {
      background-position: 0px -32px;
      &:hover {
        background-position: -16px -32px;
      }
    }

    &.if-hide-disabeld {
      cursor: not-allowed !important;
      background-position: 0px -16px !important;
    }
  }
}
</style>

