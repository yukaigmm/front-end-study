<template>
    <div class="ad1 direct-sale-module">
        <div class="banner-wrapper" :class="{default: !adConfig.length}">
            <div 
                class="banner-container" 
                ref="adContainer" 
                :style="{width: adConfig.length * 100 + '%'}"
                v-show="adConfig.length"
            >   
                <template
                >
                    <div
                        v-for="(item, index) in adConfig"
                        class="banner-item"
                        :key="index"
                        :style="{
                            background: `url(${item.pic}) no-repeat`, 
                            width: 100/adConfig.length + '%'
                        }"
                        @click="jumpToLink(item)"
                    ></div>
                </template>
            </div>
            <div class="default-placeholder" v-if="!adConfig.length">{{"广告图片"}}</div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        moduleData: {
            type: Object,
            default: {},
        }
    },
    computed: {
    },
    data(){
        return {
            adConfig: []
        }
    },
    methods: {
        autoRun(){
            if(this.timer1){
                clearInterval(this.timer1);
            }
            if(this.timer2){
                clearTimeout(this.timer2);
            }
            this.timer1 = setInterval(() => {
                this.toggleCarouselLeft(1,500);
            }, 2000);
        },
        toggleCarouselLeft(n,speed){
            let container = $(this.$refs.adContainer);
            let width = container.width()/this.adConfig.length;
            container.animate({
                left: -n * width
            }, speed, "linear");
            this.timer2 = setTimeout(() => {
                this.adConfig = this.adConfig.concat(this.adConfig.splice(0, n));
                 container.css({
                    left: 0
                })
            }, speed + 50);
        },
        jumpToLink(item){
            let link = item.link || item.file;
        },
        getAdConfig(){
            let adConfig = this.moduleData.pics || [];
            this.adConfig = adConfig.filter((item) => {
                return item.pic
            }).map((item) => {
                return Object.assign({}, item, {pic: `${this.$baseUrl[process.env.NODE_ENV]['staticFile']}/${item.pic}`})
            })
        },
        stopRun(){
            clearInterval(this.timer1);
            clearTimeout(this.timer2);
            setTimeout(() => {
                let container = $(this.$refs.adContainer);
                container.css({
                    left: 0
                });
            }, 100);
        }
    },
    mounted() {
        this.getAdConfig();
    },
    beforeDestroy() {
        this.stopRun();
    },
    watch: {
        adConfig: {
            handler(val){
                if(val.length > 1){
                    this.autoRun();
                }else{
                    this.stopRun();
                }
            },
            deep: true
        },
        moduleData: {
            handler(val){
                this.getAdConfig()
            },
            deep: true
        }
    }
}
</script>
<style lang="less" scoped>
    .ad1{
        height: 90px;
        position: relative;
        // padding-right: 13.36px;
        .banner-wrapper{
            overflow: hidden;
            position: relative;
            width: 100%;
            height: 100%;
            &.default{
                background-color: #e3e1e1;
            }
            .default-placeholder{
                height: 100%;
                width: 100%;
                text-align: center;
                line-height: 90px;
                color: #9b9b9b;
            }
        }
        .banner-container{
            height: 100%;
            position: absolute;
            .banner-item{
                height: 100%;
                float: left;
                background-position: center !important;
                background-size: contain !important;
            }
        }
    }
</style>