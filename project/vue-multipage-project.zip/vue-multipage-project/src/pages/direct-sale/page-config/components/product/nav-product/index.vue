<template>
    <component 
        :is="fundInfo.styleType"
        :fundData="fundInfo"
    ></component>
</template>

<script>
import peFund1 from "./nav1/index.vue";
import peFund2 from "./nav2/index.vue";
import {generateTrendOrIntervalConfig} from "../../../js/options-config.js";
export default {
    // fund 父组件传入的配置信息
    // fundInfo 根据 fund 组装出来用来渲染的数据
    // fundData 使用接口返回的数据组装成的需要展示的数据点
    // map 根据约定的配置生成的数据点和数据点名称的map
    // fundInfoCache 根据fundId缓存的数据点数据
    props: {
        fund: {
            type: Object,
            default: {}
        }
    },
    components: {
        peFund1,
        peFund2
    },
    computed: {
        fundInfo(){
            let fund = this.fundData;
            return {
                styleType: fund.styleType,
                intervalIncomeArr: fund.intervalIncomeArr || [],
                tags: fund.tags,
                productName: fund.productName,
                recommendation: fund.recommendation,
                img: fund.img
            } 
        }
    },
    data(){
        return {
            fundData: {},
            fundInfoCache: {},
            map: {}
        }
    },
    methods: {
        buildFundData(){
            this.fundData = JSON.parse(JSON.stringify(this.fund));
            let fund = this.fundData;
            if(this.fundInfoCache[fund.productId]){
                this.buildFundDataFromCache(fund);
            }else if(fund.productId){
                this.getFundData(fund.productId).then((res) => {
                    if (!res)return;
                    if(res.data && res.data.list instanceof Array){
                        let incomeMap = {};
                        let arr = JSON.parse(JSON.stringify(res.data.list));
                        arr.forEach((item, index) => {
                            incomeMap[index] = item.self_income + "%"
                        });
                        incomeMap.ret_incep = res.data.ret_incep + "%";
                        incomeMap.ret_incep_a = res.data.ret_incep_a + "%";
                        incomeMap.nav = res.data.nav;
                        incomeMap.priceDate = res.data.price_date;
                        incomeMap.runTime = this.dateCalculate(res.data);
                        this.fundInfoCache[fund.productId] = incomeMap;
                        this.buildFundDataFromCache(fund);
                    }
                })
            }
        },
        // 从组件缓存中获取需要渲染的字段
        buildFundDataFromCache(fund){
            let data = this.fundInfoCache[fund.productId];
            let intervalIncomeArr = [];
            let excludeArr = ["nav"];
            fund.indicatorKeys.forEach((item, index) => {
                let className = "";
                if(excludeArr.indexOf(item) === -1){
                    className = parseFloat(data[item]) > 0 ? "positive" : parseFloat(data[item]) < 0 ? "negative" : "";
                }else{
                    className = ""
                }
                if(item == "half_year_trend"){
                    fund.img = this.getImgUrl(fund.productId, 3)
                }else{
                    intervalIncomeArr.push({
                        name: this.map[item],
                        value: data[item],
                        className,
                    })
                }
            });
            this.$set(fund, "intervalIncomeArr", intervalIncomeArr)
        },
        // 
        getFundData(id){
            let params = {id};
            return new Promise((resolve, reject) => {
                $.ajax({
                    type: "GET",
                    url: `${this.$baseUrl[process.env.NODE_ENV]["officialMobile"]}/fund/performanceApi`,
                    xhrFields: {withCredentials: true},
                    crossDomain: true,
                    data: params,
                    success: (resp) => {
                        let res = resp instanceof Object ? resp : JSON.parse(resp);
                        resolve(res);
                    },
                    error: () => {}
                })
            });
        },
        dateCalculate (v) { // 计算私募证券运行时间
            if (!v.inception_date) return '--'
            let past = +new Date(v.inception_date.replace(/-/g, '/'))
            let now = v.liquidate_date ? +new Date(v.liquidate_date.replace(/-/g, '/')) : +new Date()
            let date = new Date(now - past)
            let day = date.getDate()
            let month = date.getMonth() + (day > 2 ? 1 : 0)
            let year = date.getFullYear() + (month === 12 ? (month = 0, 1) : 0) - 1970
            return `${year !== 0 ? `${year}年` : ''}${month !== 0 ? `${month}个月` : ''}`
        },
        getImgUrl(id, trend){
            if(id!== undefined && trend !== undefined){
                return `${this.$baseUrl[process.env.NODE_ENV]["host"]}/api/directSale/getCurve?fund_id=${id}&limit=${trend}`
            }else{
            }
        },
    },
    watch: {
        fund: {
            handler(val){
                this.buildFundData();
            },
            deep: true,
            immediate: true
        }
    },
    mounted() {
        generateTrendOrIntervalConfig().forEach(item => {
            this.map[item.value] = item.label;
        });
        this.buildFundData();
    },
}
</script>
