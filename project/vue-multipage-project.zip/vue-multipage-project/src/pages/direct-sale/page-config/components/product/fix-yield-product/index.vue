<template>
    <div class="product-item">
        <div class="product-brief">
            <div class="product-short-name">{{fundInfo.productName}}</div>
            <div class="tag-container">
                <span
                    v-for="(tag, i) in fundInfo.tags"
                    :key="i"
                    class="product-label"
                >{{tag}}</span>
            </div>
        </div>
        <div class="product-stat-row">
            <div class="standard stat-item left">
                <div class="val" style="color: #e1322d">{{fundInfo.results_baseline}}</div>
                <div class="concept-name">业绩比较基准</div>
            </div>
            <div class="inverst-term stat-item center">
                <div class="val" style="color: #333">{{fundInfo.period}}</div>
                <div class="concept-name">投资期限</div>
            </div>
            <div class="inverst-limit stat-item right">
                <div class="val" style="color: #333">{{fundInfo.investment_amount}}</div>
                <div class="concept-name">起投金额</div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        fund: {
            type: Object,
            default: {}
        }
    },
    computed: {
        fundInfo(){
            let fund = this.fundData;
            return {
                tags: fund.tags && fund.tags.length ? fund.tags : ["标签"],
                results_baseline: fund.results_baseline || "--",
                period: fund.period || "--",
                investment_amount: fund.investment_amount || "--",
                productName: fund.productName || "产品名称"
            }
        }
    },
    data(){
        return {
            fundInfoCache: {},
            fundData: {},
            map: {}
        }
    },
    methods: {
        buildFundData(){
            this.fundData = JSON.parse(JSON.stringify(this.fund));
            let fund = this.fundData;
            if(fund.productId){
                if(this.fundInfoCache[fund.productId]){
                    this.buildFundDataFromCache(fund);
                }else{
                    this.getFundData(fund.productId).then((res) => {
                        if (!res)return;
                            let {
                                results_baseline,
                                period,
                                investment_amount
                            } = res.data;
                            this.fundInfoCache[fund.productId] = {
                                results_baseline,
                                period,
                                investment_amount
                            };
                            this.buildFundDataFromCache(fund);
                    })
                }
            }
        },
        getFundData(id){
            let params = {
                f_id: id,
            }
            return new Promise((resolve, reject) => {
                this.$http.get(`${this.$baseUrl[process.env.NODE_ENV]["officialMobile"]}/steadyfund/fundHeadInfo`,params).then((res) => {
                    if(res){
                        resolve(res);
                    }
                })
            });
        },
        buildFundDataFromCache(fund){
            let cacheItem = this.fundInfoCache[fund.productId];
            fund.results_baseline = cacheItem.results_baseline;
            fund.period = cacheItem.period;
            this.$set(fund, "investment_amount", cacheItem.investment_amount);
        }
    },
    mounted() {
        this.buildFundData();
    },
    watch: {
        fund: {
            handler(val){
                this.buildFundData();
            }
        }
    }
}
</script>
<style lang="less" scoped>
   .fix-yield{
        // 产品内容
        .product-container{
            // 产品简称和标签
            .product-item{
                .product-brief{
                    overflow: hidden;
                    text-overflow:ellipsis;
                    white-space: nowrap;
                    width: 100%;
                    text-align: left;
                }
            }
        }
   }
</style>