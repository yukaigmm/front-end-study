<template>
    <div class="product-item">
        <div class="product-graph" v-show="fundData.img">
            <img v-show="fundData.img" :src="fundData.img" alt="">
            <span v-show="!fundData.img" class="img-notice">收益曲线</span>
        </div>
        <div class="product-info">
            <div class="product-shortname">{{fundData.productName}}</div>
            <div class="recomend-msg">{{fundData.recommendation}}</div>
            <div 
            class="product-stat-row" 
            :class="{
                [`item-${fundData.intervalIncomeArr.length}`]: true,
                'with-img': !!fundData.img
            }">
                <div 
                class="stat-item"
                v-for="(item, index) in fundData.intervalIncomeArr"
                :key="index"
                >
                    <div class="val" v-html="item.value" :class="item.className"></div>
                    <div class="concept-name">{{item.name}}</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        fundData: {
            type: Object,
            default: {
                intervalIncomeArr:[
                    { name: "累计收益",value: "%"},
                    { name: "累计收益",value: "%"},
                    { name: "累计收益",value: "%"},
                ],
                productName: "产品名称",
                recommendation: "推荐语",
            }
        }
    },
    data(){
        return {
        }
    },
    computed: {
        compData(){

        }
    },
    methods: {
        
    },
    mounted() {
    },
    watch: {
    }
}
</script>
<style lang="less" scoped>
    .product-item{
        display: flex;
        .product-graph{
            width: 84.60px;
            height: 71.25px;
            background-color: #e3e1e1;
            margin: 18.7px 13.8px 0 0;
            text-align: center;
            line-height: 71.25px;
            img{
                width: 100%;
                height: 100%;
            }
            .img-notice{
                color: #9b9b9b;
            }
            &+.product-info{
                width: calc(~"100% - 99px");
            }
        }
        .product-info{
            flex: 1;
            width: 100%;
            .product-shortname{
                line-height: 20px;
                font-size: 14.25px;
                color: #333;
                margin-top: 1.78px;
                text-align: left;
                font-weight: 400;
            }
            .recomend-msg{
                line-height: 16.48px;
                font-size: 12px;
                color: #999;
                text-align: left;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                width: 100%;
            }
            .product-stat-row{
                display: flex;
                margin-top: 16.03px;
                font-size: 14px;
                justify-content: space-between;
                text-align: left;
                width: 100%;
                &.item-2,&.item-1{
                    .stat-item{
                        text-align: left;
                        width: 50%;
                        max-width: 50%;
                        .val{
                            font-size: 18px;
                        }
                    }
                }
                &.item-3{
                   .stat-item{
                        width: 33%;
                        // max-width: 33%;
                        .val{
                            font-size: 18px;
                        }
                    } 
                }
                &.item-4{
                    .stat-item{
                        width: 25%;
                        max-width: 25%;
                        .val{
                            font-size: 14px;
                        }
                    }
                }
                &.with-img{
                    .stat-item{
                        .val{
                            font-size: 14px !important;
                        }
                    }
                }
                .stat-item{
                    flex: 1;
                    max-width: 72px;
                    .val{
                        font-size: 14px;
                    }
                }
            }
        }
    }
</style>