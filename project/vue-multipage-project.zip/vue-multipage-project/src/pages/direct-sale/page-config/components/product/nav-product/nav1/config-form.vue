
<template>
  <div class="config-wrapper style1">
    <h2 class="config-title">
      私募证券模块1
      <span class="config-tip">(提示：仅1个)</span>
    </h2>

    <div class="config-content-area">
      <el-form
        ref="form"
        :rules="validateRules"
        :model="formData"
          label-width="75px"
        label-position="left"
      >
        <div class="form-content-area">
          <el-form-item label="主标题:" prop="mainTitle">
            <el-input v-model.trim="formData.mainTitle" placeholder="请输入主标题，最多仅展示一行"/>
          </el-form-item>

          <el-form-item label="副标题:" prop="subTitle">
            <el-input v-model.trim="formData.subTitle" placeholder="请输入副标题，最多仅展示一行"/>
          </el-form-item>
        </div>

        <el-form
          class="form-content-area"
          ref="fundForm"
          :rules="validateRules"
          :model="formData.funds[0]"
            label-width="75px"
          label-position="left"
        >
          <el-form-item label="产品名称:" prop="productId">
            <vselectRemote
              index="0"
              @onChange="setCurrentProductName"
              :customerRemoteMethod="searchProduct"
              style="width:100%;"
              v-model="formData.funds[0].productId"
              searchKey="short_name"
              labelKey="short_name"
              alternativeLabelKey="name"
              valueKey="data_id"
              :defaultLabel="formData.funds[0].productName"
              placeholder="请输入关键词"
            ></vselectRemote>
          </el-form-item>

         

          <el-form-item
            v-for="(item ,index) in formData.funds[0].tags"
            :key="index"
            :label="`标签${index+1}：`"
          >
            <el-input v-model="formData.funds[0].tags[index]" placeholder="请输入标签"/>
            <span class="add-tag-btn delete-btn" @click="deleteTag(index)">[删除]</span>
          </el-form-item>
           <div class="add-tag-btn" @click="addTag">+添加标签</div>

          <el-form-item label="区间收益：" prop="intervalIncome">
            <el-select v-model="formData.funds[0]['intervalIncome']" style="width:100%;">
              <el-option
                v-for="(option,pindex) in options"
                :key="pindex"
                :value="option.value"
                :label="option.label"
              ></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="跳转：" prop="jumpType">
            <el-select v-model="formData.funds[0]['jumpType']" style="width:100%;">
              <el-option value="1" label="外链"></el-option>
              <el-option value="2" label="PDF"></el-option>
              <el-option value="3" label="默认详情页"></el-option>
              <el-option value="5" label="无跳转"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item
            label="外链："
            prop="link"
            v-if="formData.funds[0]['jumpType']=='1'"
            key="link"
          >
            <el-input v-model.trim="formData.funds[0]['link']" placeholder="请输入链接"/>
          </el-form-item>

          <el-form-item
            v-if="formData.funds[0]['jumpType']=='2'"
            label="文件："
            prop="fileData"
            key="fileData"
          >
            <vfileUpload
              v-model="formData.funds[0].fileData"
              @getFileData="getFileData(0)"
              url="file/visitingCard"
              fileName="directSalePdf"
              class="custom-file-uploader"
              resName="fileName"
              :foreignPath="true"
              :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
            />
          </el-form-item>
        </el-form>
      </el-form>
    </div>
  </div>
</template>

<script>
import { generateTrendOrIntervalConfig } from "../../../js/options-config.js";
import { isEqual } from "lodash";
import { ajax } from "jquery";
import commonMethods from "../../../mixins/common-methods";

export default {
  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "peFund1",
        funds: [{ jumpType: "3", intervalIncome: "ret_incep", tags: [""] }]
      })
    }
  },

  mixins: [commonMethods],

  beforeDestroy() {
    this.validate();
  },

  computed: {
    options() {
      return generateTrendOrIntervalConfig();
    }
  },

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("文件不能为空！"));
      }

      cb(errors);
    };
    return {
      formData: {
        name: "peFund1",
        funds: [{ jumpType: "3", intervalIncome: "ret_incep", tags: [""] }]
      },
      validateRules: {
        productId: {
          required: true,
          message: "产品名称不能为空"
        },

        fileData: [
          {
            required: true,
            message: "文件不能为空"
          },
          { validator: validateFileData }
        ],

        link: {
          required: true,
          message: "链接不能为空"
        }
      }
    };
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },

      deep: true
    },

    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }
        let data = JSON.parse(JSON.stringify(val));

        data.funds =
          data.funds && data.funds.length
            ? this.transferData(data.funds, "file")
            : [{ jumpType: "3", intervalIncome: "ret_incep", tags: [""] }];
        this.formData = JSON.parse(JSON.stringify(data));
      },

      deep: true,

      immediate: true
    }
  },

  methods: {
    getFileData(index) {
      this.formData.funds[index].file = this.formData.funds[
        index
      ].fileData.filePath;
      this.formData.funds[index].fileName = this.formData.funds[index].file
        ? this.formData.funds[index].fileData.fileName
        : "";
      this.$refs[`fund${index}`][0].validateField("fileData");
    },

    searchProduct(query) {
      let params = {
        m: "Search",
        c: "search",
        a: "quickSearch",
        count: 100,
        search_type: "fund",
        skeyword: query
      };

      return new Promise((resolve, reject) => {
        ajax({
          url: "https://serve.simuwang.com/index.php",
          type: "GET",
          dataType: "jsonp",
          data: params,
          success: data => {
            resolve(data);
          },

          error: e => {
            resolve([]);
          }
        });
      });
    },

    setCurrentProductName(name, index) {
      this.$set(this.formData.funds[index], "productName", name);
    },

    deleteTag(index) {
      this.formData.funds[0].tags.splice(index, 1);
    },

    addTag() {
      this.formData.funds[0].tags.push("");
    },

    validate() {
      let finalValid = true;

      this.$refs.form.validate(valid => {
        finalValid = finalValid && valid;
        this.$refs.fundForm.validate(validate => {
          finalValid = finalValid && validate;
        });
      });

      this.$set(this.formData, "validate", finalValid);
      let data = JSON.parse(JSON.stringify(this.formData));
      data.funds = this.deleteUselessKeys(data.funds);
      this.$emit("getFormData", data, true);
    },

    resetValid() {
      this.$refs.form.clearValidate();
      this.$refs.fundForm.clearValidate();
    }
  }
};
</script>

<style lang="less" >
.custom-file-uploader.file-upload-container {
  margin-top: 8px;
}

.config-wrapper {
  .config-title {
    // margin-bottom: 8px;
  }

  .add-tag-btn {
    color: #1073c5;
    cursor: pointer;
  }

  .config-tip {
    font-size: 12px;
    font-weight: 300;
    color: #999;
  }
}

.style1 {
  .el-form-item__content {
    display: flex;
    .delete-btn {
      width: 60px;
      margin-left: 10px;
    }
  }
}
</style>

