<template>
  <div>
    <div class="title-bar">
      <span class="product-config-title">公告属性</span>
    </div>

    <el-form
      ref="currentNotice"
      :rules="validateRules"
      :model="formData"
      label-width="75px"
      label-position="left"
    >
      <div class="form-content">
        <el-form-item label="展示样式">
          <div
            class="style-container"
            :style="`${thumbnailStyleMapping[formData.styleType]}`"
            @click="chooseStyle"
          >
            <span v-if="!formData.styleType">请选择样式</span>
          </div>
        </el-form-item>
        <el-form-item label="公告" prop="content" class="pic-el-form-item init-form-item">
          <el-input
            type="textarea"
            placeholder="请输入公告内容"
            v-model="formData.content"
            :autosize="{minRows:3,maxRows:5}"
          />
        </el-form-item>
      </div>
    </el-form>

    <style-modal
      v-model="showStyleModal"
      :current-style="formData.styleType || null"
      :styles-list="['notice1']"
      @getStyle="getStyle"
    />
  </div>
</template>


<script>
import { isEqual } from "lodash";
import StyleModal from "../product/components/style-modal";
import { generateThumbnailStyleMapping } from "../../js/options-config";
export default {
  components: {
    StyleModal
  },

  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "notice",
        content: "",
        styleType: "notice1"
      })
    }
  },

  computed: {
    thumbnailStyleMapping() {
      return generateThumbnailStyleMapping();
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },
      deep: true
    },

    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }
        val.styleType = val.styleType ? val.styleType : "notice1";
        this.formData = JSON.parse(JSON.stringify(val));
      },

      deep: true,

      immediate: true
    }
  },

  beforeDestroy() {
    this.validate();
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  data() {
    return {
      validateRules: {
        content: {
          required: true,
          message: "公告内容不能为空"
        }
      },

      formData: {},

      showStyleModal: false
    };
  },

  methods: {
    chooseStyle() {
      this.showStyleModal = true;
    },

    getStyle(style) {
      this.$set(this.formData, "styleType", style);
    },

    validate() {
      this.$refs.currentNotice.validate(valid => {
        this.$set(this.formData, "validate", valid);
        this.$emit("getFormData", this.formData, true);
      });
    }
  }
};
</script>

<style lang="less" scoped>
</style>

