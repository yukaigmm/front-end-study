<template>
    <div class="view-point direct-sale-module">
        <div class="title-container">
            <span class="main-title">{{compData.mainTitle}}</span>
            <span class="sub-title">{{compData.subTitle}}</span>
            <span class="tips" v-show="!moduleData.mainTitle && !moduleData.subTitle">(标题未配置将不会在首页展示)</span>
        </div>
        <div 
            class="view-point-item"
            v-for="(item, index) in compData.views"
            :key="index"
        >
            <div class="view-point-title">
                <div class="title-wrapper">
                    {{item.title}}
                </div>
            </div>
            <div class="view-point-info">
                <span>
                    {{item.publishTime}}
                </span>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        moduleData: {
            type: Object,
            default: {}
        },
    },
    computed: {
        compData(){
            let views = this.moduleData.views && this.moduleData.views.length ? this.moduleData.views : [{
                title: "资讯标题"
            }];
            return {
                mainTitle: this.moduleData.mainTitle || "主标题",
                subTitle: this.moduleData.subTitle || "副标题",
                views: views.map((item) => {
                    return {
                        title: item.title || "资讯标题",
                        publishTime: item.publishTime || `${(new Date()).getFullYear()}-${(new Date()).getMonth()+1}-${(new Date()).getDate()}`
                    }
                })
            }
        }
    },
    data(){
        return {
            showEllipsis: false,
        }
    },
    methods: {
        setEllipsis(){
        }
    },
    watch: {
        compData: {
            handler(val){
            }
        }
    },
    mounted() {
    },
}
</script>
<style lang="less" scoped>
    .view-point-item{
        margin-top: 17.92px;
        .view-point-title{
            font-size: 14.34px;
            line-height: 20.16px;
            color: #333;
            max-height: 40px;
            position: relative;
            overflow: hidden;
            word-break: break-word;
            &.ellipsis::after{
                content: "...";
                position: absolute;
                right: 2px;
                bottom:0;
                background-color: #fff;
                width: 14px;
            }
        }
        .view-point-info{
            display: flex;
            justify-content: space-between;
            margin-top: 5.44px;
            color: #999;
            font-size: 12px;
        }
    }
</style>