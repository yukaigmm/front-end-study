<template>
  <div>
    <div class="title-bar">
      <span class="product-config-title">页头属性</span>
    </div>

    <el-form
      ref="headerForm"
      :rules="validateRules"
      :model="formData"
      label-width="85px"
      label-position="left"
    >
      <div class="form-content">
        <el-form-item label="展示样式">
          <div
            class="style-container"
            :style="`${thumbnailStyleMapping[formData.styleType]}`"
            @click="chooseStyle"
          >
            <span v-if="!formData.styleType">请选择样式</span>
          </div>
        </el-form-item>

        <el-form-item label="副标题数据点">
          <el-select
            style="width:100%;"
            placeholder="请选择数据点"
            multiple
            collapse-tags
            v-model="formData.subIndicatorKeys"
          >
            <el-option
              v-for="(option,index) in indicatorKeysOptions"
              :key="index"
              :disabled="setIfDisabled(option.value,2,'subIndicatorKeys')"
              :value="option.value"
              :label="option.label"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="扩展数据点">
          <el-select
            style="width:100%;"
            placeholder="请选择数据点"
            multiple
            collapse-tags
            v-model="formData.spreadIndicatorKeys"
          >
            <el-option
              v-for="(option,index) in indicatorKeysOptions"
              :key="index"
              :disabled="setIfDisabled(option.value,4,'spreadIndicatorKeys')"
              :value="option.value"
              :label="option.label"
            />
          </el-select>
        </el-form-item>
      </div>
    </el-form>
  </div>
</template>

<script>
import { isEqual } from "lodash";
import StyleModal from "../product/components/style-modal";
import { generateThumbnailStyleMapping } from "../../js/options-config";
import { generateHeaderConfig } from "../../js/options-config";
export default {
  components: {
    StyleModal
  },

  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "notice",
        content: "",
        styleType: "notice1"
      })
    }
  },

  computed: {
    thumbnailStyleMapping() {
      return generateThumbnailStyleMapping();
    },
    indicatorKeysOptions() {
      let data = generateHeaderConfig();
      return data;
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },
      deep: true
    },

    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }

        val.styleType = val.styleType ? val.styleType : "header";
        val.spreadIndicatorKeys = val.spreadIndicatorKeys
          ? val.spreadIndicatorKeys
          : [];
        val.subIndicatorKeys = val.subIndicatorKeys ? val.subIndicatorKeys : [];
        this.formData = JSON.parse(JSON.stringify(val));
      },

      deep: true,

      immediate: true
    }
  },

  beforeDestroy() {
    this.validate();
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  data() {
    return {
      validateRules: {
        
      },

      formData: {},

      showStyleModal: false
    };
  },

  methods: {
    chooseStyle() {
      this.showStyleModal = true;
    },

    getStyle(style) {
      this.$set(this.formData, "styleType", style);
    },

    validate() {
      this.$refs.headerForm.validate(valid => {
        this.$set(this.formData, "validate", valid);
        this.$emit("getFormData", this.formData, true);
      });
    },

    setIfDisabled(val, len, key) {
      if (this.formData[key] && this.formData[key].length >= len) {
        return !this.formData[key].includes(val);
      } else {
        return false;
      }
    }
  }
};
</script>

<style lang="less">
</style>

