
<template>
  <div class="config-wrapper pe-fund3">
    <h2 class="config-title">
      私募证券模块3
      <span class="config-tip">(提示：数量控制在1-10个)</span>
    </h2>

    <div class="config-content-area">
      <el-form
        ref="form"
        :rules="validateRules"
        :model="formData"
        label-width="75px"
        label-position="left"
      >
        <div class="form-content-area">
          <el-form-item label="主标题:" prop="mainTitle">
            <el-input v-model.trim="formData.mainTitle" placeholder="请输入主标题，最多仅展示一行"/>
          </el-form-item>

          <el-form-item label="副标题:" prop="subTitle">
            <el-input v-model.trim="formData.subTitle" placeholder="请输入副标题，最多仅展示一行"/>
          </el-form-item>
        </div>

        <el-form
          class="single-content"
          :ref="`fund${index}`"
          :rules="validateRules"
          :model="fund"
          label-width="75px"
          label-position="left"
          v-for="(fund,index) in formData.funds"
          :key="compKeys[index]"
        >
          <h3 class="fund-title content-title">
            <span class="title">{{`基金${index+1}`}}</span>
            <span
              class="action-btn move-up"
              :class="{'disable-btn':formData.funds.length<=1}"
              @click="moveUp(index)"
            >[上移]</span>
            <span
              class="action-btn move-down"
              :class="{'disable-btn':formData.funds.length<=1}"
              @click="moveDown(index)"
            >[下移]</span>
            <span
              class="action-btn delete-btn"
              :class="{'disable-btn':formData.funds.length<=1}"
              @click="deleteFund(index)"
            >[删除]</span>
          </h3>

          <div class="form-content-area">
            <el-form-item label="产品名称:" prop="productId">
              <vselectRemote
                :index="index"
                @onChange="setCurrentProductName"
                :customerRemoteMethod="searchProduct"
                style="width:100%;"
                v-model="fund['productId']"
                searchKey="short_name"
                labelKey="short_name"
                alternativeLabelKey="name"
                valueKey="data_id"
                :defaultLabel="fund.productName"
                placeholder="请输入关键词"
              ></vselectRemote>
            </el-form-item>

            <el-form-item label="推荐语：" prop="recommendation">
              <el-input v-model.trim="fund['recommendation']" placeholder="请输入推荐语"/>
            </el-form-item>

            <el-form-item label="走势图：" prop="trend">
              <el-select v-model="fund['trend']" style="width:100%;">
                <el-option
                  v-for="(option,pindex) in trendOptions"
                  :key="pindex"
                  :value="option.value"
                  :label="option.label"
                ></el-option>
              </el-select>
            </el-form-item>

            <el-form-item label="跳转：" prop="jumpType">
              <el-select v-model="fund['jumpType']" style="width:100%;">
                <el-option value="1" label="外链"></el-option>
                <el-option value="2" label="PDF"></el-option>
                <el-option value="3" label="默认详情页"></el-option>
                <el-option value="5" label="无跳转"></el-option>
              </el-select>
            </el-form-item>

            <el-form-item label="外链：" prop="link" v-if="fund['jumpType']=='1'">
              <el-input v-model.trim="fund['link']" placeholder="请输入链接"/>
            </el-form-item>

            <el-form-item v-if="fund['jumpType']=='2'" label="文件：" prop="fileData">
              <vfileUpload
                v-model="formData.funds[index].fileData"
                @getFileData="getFileData(index)"
                url="file/visitingCard"
                fileName="directSalePdf"
                class="custom-file-uploader"
                resName="fileName"
                :foreignPath="true"
                :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
              />
            </el-form-item>
          </div>
        </el-form>
        <div class="add-btn-wrapper">
          <div
            class="add-fund-btn add-btn"
            :class="{'disable-btn':formData.funds.length>=10}"
            @click="addFund"
          >+添加基金</div>
        </div>
      </el-form>
    </div>
  </div>
</template>

<script>
import { generateTrendOrIntervalConfig } from "../../../js/options-config.js";
import { isEqual } from "lodash";
import { ajax } from "jquery";
import commonMethods from "../../../mixins/common-methods";

export default {
  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "peFund3",
        funds: [{ jumpType: "3", trend: "ret_incep" }]
      })
    }
  },

  mixins: [commonMethods],

  beforeDestroy() {
    this.validate();
  },

  computed: {
    trendOptions() {
      return generateTrendOrIntervalConfig();
    }
  },

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("文件不能为空！"));
      }

      cb(errors);
    };
    return {
      compKeys: [],
      formData: {
        name: "peFund3",
        funds: [{}]
      },
      validateRules: {
        productId: {
          required: true,
          message: "产品名称不能为空"
        },

        recommendation: {
          required: true,
          message: "推荐语不能为空"
        },

        fileData: [
          {
            required: true,
            message: "文件不能为空"
          },
          { validator: validateFileData }
        ],

        link: {
          required: true,
          message: "链接不能为空"
        }
      }
    };
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },
      deep: true
    },
    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }
        let data = JSON.parse(JSON.stringify(val));

        data.funds =
          data.funds && data.funds.length
            ? this.transferData(data.funds, "file")
            : [{ jumpType: "3", trend: "ret_incep" }];
        this.formData = JSON.parse(JSON.stringify(data));
        this.compKeys = this.setCompKeys(
          this.formData.funds,
          this.compKeys || []
        );
      },

      deep: true,

      immediate: true
    }
  },

  methods: {
    getFileData(index) {
      this.formData.funds[index].file = this.formData.funds[
        index
      ].fileData.filePath;
      this.formData.funds[index].fileName = this.formData.funds[index].file
        ? this.formData.funds[index].fileData.fileName
        : "";
      this.$refs[`fund${index}`][0].validateField("fileData");
    },
    setCurrentProductName(name, index) {
      this.$set(this.formData.funds[index], "productName", name);
    },

    searchProduct(query) {
      let params = {
        m: "Search",
        c: "search",
        a: "quickSearch",
        count: 100,
        search_type: "fund",
        skeyword: query
      };

      return new Promise((resolve, reject) => {
        ajax({
          url: "https://serve.simuwang.com/index.php",
          type: "GET",
          dataType: "jsonp",
          data: params,
          success: data => {
            resolve(data);
          },

          error: e => {
            resolve([]);
          }
        });
      });
    },

    switch(direction, index) {
      if (this.formData.funds.length <= 1) {
        return;
      }
      let nearIndex;

      if (direction === "up") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: "当前基金已在最上边！",
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (index >= this.formData.funds.length - 1) {
          this.$message({
            type: "error",
            message: "当前基金已在最下边！",
            showClose: true
          });
          return;
        }

        nearIndex = index + 1;
      }
      let currentKey = this.compKeys[index];
      let nearKey = this.compKeys[nearIndex];
      this.$set(this.compKeys, nearIndex, currentKey);
      this.$set(this.compKeys, index, nearKey);

      let currentItem = this.formData.funds[index];
      let nearItme = this.formData.funds[nearIndex];
      this.$set(this.formData.funds, nearIndex, currentItem);
      this.$set(this.formData.funds, index, nearItme);
    },

    moveUp(index) {
      this.switch("up", index);
    },

    moveDown(index) {
      this.switch("down", index);
    },

    deleteFund(index) {
      if (this.formData.funds.length <= 1) {
        return;
      }
      this.compKeys.splice(index, 1);
      this.formData.funds.splice(index, 1);
    },

    addFund() {
      if (this.formData.funds.length >= 10) {
        return;
      }
      this.formData.funds.push({
        jumpType: "3",
        trend: "ret_incep"
      });
    },

    validate() {
      let finalValid = true;

      this.formData.funds.forEach((form, index) => {
        if (this.$refs[`fund${index}`][0]) {
          this.$refs[`fund${index}`][0].validate(valid => {
            finalValid = finalValid && valid;
          });
        }
      });

      this.$set(this.formData, "validate", finalValid);
      let data = JSON.parse(JSON.stringify(this.formData));
      data.funds = this.deleteUselessKeys(data.funds);
      this.$emit("getFormData", data, true);
    },

    resetValid() {
      this.formData.funds.forEach((form, index) => {
        if (this.$refs[`fund${index}`][0]) {
          this.$refs[`fund${index}`][0].clearValidate();
        }
      });
    }
  }
};
</script>

<style lang="less" >
.custom-file-uploader.file-upload-container {
  margin-top: 8px;
}

.config-wrapper {
  .config-title {
    // margin-bottom: 8px;
  }

  .add-fund-btn,
  .add-tag-btn {
    color: #1073c5;
    cursor: pointer;
  }

  .config-tip {
    font-size: 12px;
    font-weight: 300;
    color: #999;
  }

  .fund-title {
    font-size: 14px;
    margin: 8px 0;
    .action-btn {
      color: #1073c5;
      cursor: pointer;
      font-size: 12px;
    }
  }
}

.move-up {
  margin-left: 32px;
}

.move-dowm {
  margin: 0 10px;
}

.pe-fund3 {
  .el-form-item__content {
    display: flex;
    .delete-btn {
      width: 60px;
      margin-left: 10px;
    }
  }
}
</style>

