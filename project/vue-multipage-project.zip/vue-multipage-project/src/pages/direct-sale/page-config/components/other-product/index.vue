<template>
    <div class="other-product direct-sale-module">
       <div class="title-container">
           <span class="main-title">{{compData.mainTitle || "主标题"}}</span>
           <span class="sub-title">{{compData.subTitle || "副标题"}}</span>
           <span class="tips" v-show="!moduleData.mainTitle && !moduleData.subTitle">(标题未配置将不会在首页展示)</span>
       </div>
       <div class="product-container">
           <div 
           class="product-item"
           v-for="(item, index) in compData.funds"
           :key="index"
           >
               <div class="product-brief">
                    <div class="product-brief-intro">{{item.productName}}</div>
                    <div class="product-describe">
                        {{item.description}}
                    </div>
               </div>
               <div class="get-detail" v-if="+item.jumpType !== 5">查看详情</div>
           </div>
       </div>
    </div>
</template>

<script>
export default {
   props: {
        moduleData: {
            type: Object,
            default: {}
        },
    },
    computed: {
        compData(){
            let funds = this.moduleData.funds && this.moduleData.funds.length ? this.moduleData.funds : [{
                productName: "产品名称",
                description: "产品介绍"
            }];
            return {
                mainTitle: this.moduleData.mainTitle || "主标题",
                subTitle: this.moduleData.subTitle || "副标题",
                funds: funds.map((item) => {
                    return Object.assign({}, item, {
                        productName: item.productName || "产品名称",
                        description: item.description || "产品介绍",
                    })
                })
            }
        }
    },
    data(){
        return {
            views: {}
        }
    },
    watch: {
    }
}
</script>
<style lang="less" scoped>
   .other-product{
        // 产品内容
        .product-container{
            // 产品简称和标签
            .product-item{
                .product-brief{
                    text-align: center;
                    .product-describe{
                        color: #999;
                        margin: 7.13px auto 0;
                        white-space: normal;
                        // text-align: left;
                    }
                }
            }
        }
   }
</style>