<template>
    <div class="direct-sale-module">
        <component
        v-for="item in compData.ads"
        :key="item.compKey"
        :is="item.styleType"
        :moduleData="item"
        ></component>
    </div>
</template>
<script>
import ad1 from "./ad1/index.vue";
import ad2 from "./ad2/index.vue";
export default {
    props: {
        moduleData: {
            type: Object,
            default: {}
        }
    },
    computed: {
        compData(){
            return {
                ads:  this.moduleData.ads || [],
            }
        }
    },
    components: {
        ad1,
        ad2
    },
    watch: {
        moduleData:{
            handler(val){},
            deep: true,
            immediate: true
        }
    }
}
</script>

<style lang="less" scoped>
    .direct-sale-module{
        min-height: 90px;
    }
</style>


