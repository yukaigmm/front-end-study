<template>
  <div class="config-form">
    <component
      :is="configComp"
      :key="formData.compKey"
      ref="configForm"
      @getFormData="getData"
      :configData="formData"
    ></component>
  </div>
</template>

<script>
import pageHeader from "./header/form";
import notice from "./notice/form.vue";
import tabs from "./tabs/form";
import ad from "./ad/form.vue";
// import ad1 from "./ad/ad1/config-form";
import hotPoint from "./hot-point/form";
// import newProduct from "./new-product/config-form";
// import otherProduct from "./other-product/config-form";
// import peFund1 from "./pe-fund/pe-fund1/config-form";
// import peFund2 from "./pe-fund/pe-fund2/config-form";
// import peFund3 from "./pe-fund/pe-fund3/config-form";
// import peFund4 from "./pe-fund/pe-fund4/config-form";
import viewPoint from "./view-point/form";
// import fixedIncome from "./fix-yield/config-from";
// import privateEquity from "./pe/config-form";
import product from "./product/product-config-form.vue";
export default {
  props: {
    whichComp: {
      type: [Object, String],
      default: () => ({})
    },

    formData: {
      type: [Object, Array],
      default: () => []
    }
  },

  computed: {
    configComp() {
      return this.whichComp.name || this.whichComp;
    }
  },

  watch: {},

  components: {
    pageHeader,
    tabs,
    notice,
    // ad1,
    // ad2,
    ad,
    hotPoint,
    // newProduct,
    // otherProduct,
    // peFund1,
    // peFund2,
    // peFund3,
    // peFund4,
    viewPoint,
    product
    // fixedIncome,
    // privateEquity
  },

  data() {
    return {};
  },

  mounted() {
    this.setMaxHeightOfEditArea();
  },

  methods: {
    setMaxHeightOfEditArea() {
      let containerHeight = $(".page-layout").height();
      let targetContainer = $(".config-content-area");
      targetContainer.css({ maxHeight: `${containerHeight - 40}px` });
      window.onresize = () => {
        let containerHeight = $(".page-layout").height();
        let targetContainer = $(".config-content-area");
        targetContainer.css({ maxHeight: `${containerHeight - 40}px` });
      };
    },

    getData(data, lastChange) {
      // console.log("data", data);
      let configData = JSON.parse(JSON.stringify(data));
      this.$emit("getFormData", configData, lastChange);
    },

    validate() {
      if (this.$refs.configForm && this.$refs.configForm.validate) {
        this.$refs.configForm.validate();
      }
    }
  }
};
</script>

<style lang="less" scoped>
</style>

