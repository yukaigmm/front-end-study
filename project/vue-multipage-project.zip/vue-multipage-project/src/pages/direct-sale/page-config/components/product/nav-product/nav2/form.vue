<template>
  <div>
    <el-form-item label="推荐语">
      <el-input v-model.trim="fund.recommendation" placeholder="请输入推荐语"/>
    </el-form-item>

    <el-form-item label="数据点" prop="indicatorKeys" :rules="rules">
      <el-select
        style="width:100%;"
        placeholder="请选择数据点"
        multiple
        collapse-tags
        v-model="fund.indicatorKeys"
        @change="onchange"
      >
        <el-option
          v-for="(option,pindex) in indicatorKeysOptions"
          :disabled="setIfDisabled(option.value)"
          :key="pindex"
          :value="option.value"
          :label="option.label"
        />
      </el-select>
    </el-form-item>

    <el-form-item label="点击动作" prop="jumpType">
      <el-select v-model="fund['jumpType']" style="width:100%;" @change="onchange">
        <el-option value="1" label="外链"></el-option>
        <el-option value="2" label="PDF"></el-option>
        <el-option value="3" label="默认详情页"></el-option>
        <el-option value="5" label="无跳转"></el-option>
      </el-select>
    </el-form-item>

    <el-form-item label="外链：" prop="link" v-if="fund['jumpType']=='1'" key="link">
      <el-input v-model.trim="fund['link']" placeholder="请输入链接" @change="onchange"/>
    </el-form-item>

    <el-form-item v-if="fund['jumpType']=='2'" label="文件：" prop="fileData" key="fileData">
      <vfileUpload
        @change="onchange"
        v-model="fund.fileData"
        @getFileData="getFileData(0)"
        url="file/visitingCard"
        fileName="directSalePdf"
        class="custom-file-uploader"
        resName="fileName"
        :foreignPath="true"
        :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
      />
    </el-form-item>
  </div>
</template>


<script>
import { generateTrendOrIntervalConfig } from "../../../../js/options-config.js";
export default {
  props: {
    fund: ""
  },

  model: {
    prop: "fund",
    event: "change"
  },

  data() {
    const validateIndicatorKeys = (rules, value, cb) => {
      let errors = [];
      if (value && value.length < 2) {
        errors.push(new Error("至少需要两个数据点"));
      }
      cb(errors);
    };
    return {
      indicatorKeysOptions: generateTrendOrIntervalConfig(),
      rules: [
        {
          required: true,
          message: "不能为空"
        },
        {
          validator: validateIndicatorKeys,
          trigger: "change"
        }
      ]
    };
  },

  methods: {
    setIfDisabled(key) {
      if (this.fund.indicatorKeys && this.fund.indicatorKeys.length >= 4) {
        return !this.fund.indicatorKeys.includes(key);
      } else {
        return false;
      }
    },

    deleteTag(index) {
      this.fund.tags.splice(tagIndex, 1);
      this.$emit("change", this.fund);
    },

    addTag(index) {
      this.fund.tags.push("");
      this.$emit("change", this.fund);
    },

    getFileData(index) {
      this.fund.file = this.fund.fileData.filePath;
      this.fund.fileName = this.fund.file ? this.fund.fileData.fileName : "";
      this.$emit("change", this.fund);
      this.$emit("validate", "fileData");
    },

    onchange() {
      this.$emit("change", this.fund);
    }
  }
};
</script>


<style lang="less" scoped>
</style>
