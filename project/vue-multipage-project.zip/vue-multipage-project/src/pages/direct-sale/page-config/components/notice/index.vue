<template>
    <div class="notice direct-sale-module">
        <div class="notice-wrapper">
            <span class="notice-icon"></span>
            <div 
            class="notice-content"
            >
                <div 
                    v-html="compData.noticeText"
                    v-if="compData.noticeText" 
                    class="notice-text"
                    ref="noticeText"
                >
                </div>
                <div v-else>请输入公告内容</div>
                <div 
                class="attach-text"
                :class="{'all-text':showEllipsis}"
                >
                    <span>...</span>
                    <span class="show-more">全文</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        moduleData: {
            type: Object,
            default: {}
        }
    },
    computed: {
        compData(){
            let text = this.moduleData.content || "";
            if(text.length > 500){
                text = text.substring(0, 500);
            }
            return {
                noticeText: text
            }
        }
    },
    data(){
        return {
            noticeText: "",
            showEllipsis: false,
        }
    },
    methods: {
        setEllipsis(){
            if($(this.$refs.noticeText).height() > 108){
                this.showEllipsis = true;
            }else{
                this.showEllipsis = false;
            }
        }
    },
    watch: {
        compData: {
            handler(val){
                if(this.timer){
                    clearTimeout(this.timer);
                }
                this.timer = setTimeout(() => {
                    this.setEllipsis();
                }, 200);
            }
        }
    },
    mounted() {
        this.setEllipsis()
    },
}
</script>
<style lang="less" scoped>
    .notice{
        // margin-right: 13.36px;
        padding: 7.13px 5.79px;
        border: 1px solid #c8aa87;
        text-align: justify;
        text-indent: -3.12px;
        line-height: 16.48px;
        font-size: 12px;
        color: #999;
        .notice-content{
            text-indent: 4em;
            line-height: 18px;
            display: inline-block;
            max-height: 108px;
            overflow: hidden;
            position: relative;
            white-space: pre-wrap;
            word-break: break-word;
            .attach-text{
                display: none;
                &.all-text{
                    display: flex;
                    justify-content: center;
                    position: absolute;
                    bottom: 0;
                    right: 0;
                    background-color: #fff;
                    span{
                        text-indent: 0;
                        display: block;
                        width: 12px;
                        height: 18px;
                    }
                    .show-more{
                        color: #c8aa87;
                        width: 24px;
                        cursor: pointer;
                    }
                }
            }
        }
        .notice-text{
            color: #333;
            width: 293px;
        }
        .notice-wrapper{
            position: relative;
        }
        .notice-icon{
            display: inline-block;
            width: 35.63px;
            height: 16.47px;
            vertical-align: bottom;
            background: url("../../../../../assets/images/direct-sale/notice.svg") no-repeat center/100%;
            position: absolute;
            left: -2.67px;
            top: 0;
        }
    }
</style>