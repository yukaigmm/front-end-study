<template>
  <div class="tabs">
    <div class="page-title">
      <div
        v-for="item in tabs"
        :key="item.tabName"
        :class="{'home-page':item.tabName =='index','normal':item.tabName !='index'}"
      >{{item.label}}</div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    moduleData: {
      type: Object,
      default: {}
    }
  },

  computed: {
    tabs() {
      let mapping = {
        index: "首页",
        product: "产品",
        manager: "经理",
        file: "档案",
        roadShow: "路演",
        comment: "点评"
      };
      let oriTabs = _.filter(
        JSON.parse(JSON.stringify(this.moduleData.tabs || [])),
        item => !item.ifHide
      );
      return _.map(oriTabs, tab => ({
        label: mapping[tab.tabName],
        tabName: tab.tabName
      }));
    }
  },

 

  data() {}
};
</script>

<style lang="less">
.page-title {
  width: 100%;
  display: flex;
  justify-content: flex-start;
  padding-top: 8px;

  div {
    font-size: 14px;
    font-weight: bold;
    width: 15%;
    &:nth-child(n + 1) {
      margin-left: 4%;
    }

    &.home-page {
      color: #98764b;
      position: relative;

      &::after {
        position: absolute;
        content: "";
        width: 20px;
        height: 2px;
        background-color: #98764b;
        bottom: -13px;
        // left: 50%;
        transform: translate(-100%, 0);
      }

      // border-bottom: 2px solid #98764b;
    }

    span {
      font-weight: normal;
      font-size: 12px;
      color: #999;
    }
  }
}

.tabs {
  height: 40px;
}
</style>

