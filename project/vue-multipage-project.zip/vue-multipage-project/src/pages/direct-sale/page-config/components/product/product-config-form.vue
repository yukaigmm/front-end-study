<template>
  <div>
    <div class="title-bar">
      <div class="title product-config-title">模块属性</div>
    </div>
    <el-form
      ref="form"
      :rules="mainFormRules"
      :model="formData"
      label-width="60px"
      label-position="left"
    >
      <div class="form-content">
        <el-form-item label="主标题" prop="mainTitle">
          <el-input v-model.trim="formData.mainTitle" placeholder="请输入主标题，最多仅展示一行" maxlength="20" >
            <span slot="append">{{formData.mainTitle?formData.mainTitle.length:0}}/20</span>
          </el-input>
        </el-form-item>

        <el-form-item label="副标题" prop="subTitle">
          <el-input v-model.trim="formData.subTitle" placeholder="请输入副标题，最多仅展示一行" maxlength="20">
            <span slot="append">{{formData.subTitle?formData.subTitle.length:0}}/20</span>
          </el-input>
        </el-form-item>
      </div>

      <div class="product-list">
        <div class="title-bar">
          <span class="product-config-title">产品列表</span>
          <div>
            <span
              class="product-add-btn"
              :class="{'disabled-action-btn':formData.funds.length >=5}"
              @click="addProduct"
            >+添加产品</span>
            <el-select
              class="type-selector"
              :class="{'to-select':selecting}"
              v-model="productType"
              @change="onProductTypeChange"
              placeholder="请选择产品类型"
            >
              <el-option
                v-for="(option,pindex) in productTypeOptions"
                :key="pindex"
                :value="option.value"
                :label="option.label"
              />
            </el-select>
          </div>
        </div>

        <div class="form-content">
          <el-form
            v-for="(fund,fundIndex) in formData.funds"
            :key="fund.compKey"
            :model="fund"
            :ref="`fundForm${fundIndex}`"
            label-width="60px"
            label-position="left"
            :rules="validateFundRules"
            @click.native="onFocus(fundIndex)"
          >
            <el-form-item
              :class="{'validate-item':fund.validate===false}"
              :label="`产品${numberMapping[fundIndex]}`"
              prop="productId"
            >
              <div class="fund-validate-icon" title="该产品存在不正确的配置项" v-show="fund.validate===false"></div>
              <div
                class="product-list-wrapper"
                :class="{'active-product':fundIndex ==currentIndex}"
              >
                <vselectRemote
                  :allow-create="fund.productType=='1'"
                  :default-first-option="fund.productType=='1'"
                  @focus="onFocus(fundIndex)"
                  :index="fundIndex"
                  @onChange="setCurrentProductName"
                  :customerRemoteMethod="searchProduct"
                  style="width:200px;"
                  v-model="fund['productId']"
                  searchKey="short_name"
                  labelKey="short_name"
                  alternativeLabelKey="name"
                  valueKey="data_id"
                  :defaultLabel="fund.productName"
                  placeholder="请输入关键词"
                />

                <div class="action-area">
                  <span
                    class="product-action-btn move-up"
                    :class="{'disabled-btn':fundIndex ==0}"
                    @click.prevent.stop="moveUp(fundIndex)"
                  ></span>
                  <span
                    class="product-action-btn move-down"
                    :class="{'disabled-btn':fundIndex ==formData.funds.length-1}"
                    @click.prevent.stop="moveDown(fundIndex)"
                  ></span>
                  <span
                    class="product-action-btn delete-product"
                    @click.prevent.stop="deleteProduct(fundIndex)"
                  ></span>
                </div>
              </div>
            </el-form-item>
          </el-form>
        </div>
      </div>

      <div v-if="formData.funds.length">
        <el-form
          :ref="`currentFund${index}`"
          v-for="(fund,index) in formData.funds"
          :key="fund.compKey"
          :rules="validateRules"
          :model="fund"
          label-width="60px"
          label-position="left"
          v-show="index == currentIndex"
        >
          <div class="title-bar">
            <div class="title product-config-title">{{`产品${numberMapping[index]}属性`}}</div>
            <span class="product-add-btn" v-if="showAddTagBtn" @click="addTag">+添加标签</span>
          </div>

          <div class="form-content">
            <el-form-item label="产品类型">
              <span>{{getProductType(index)||"--"}}</span>
            </el-form-item>

            <el-form-item label="展示样式" v-if="getProductType(index)">
              <div
                class="style-container"
                title="点击更换样式"
                :style="`${thumbnailStyleMapping[formData.funds[index].styleType]}`"
                @click="chooseStyle"
              >
                <span v-if="!formData.funds[index].styleType">请选择样式</span>
              </div>
            </el-form-item>

            <component
              :is="getCurrentComp(index)"
              @validate="validateField"
              v-model="formData.funds[index]"
            ></component>
          </div>
        </el-form>
      </div>
    </el-form>

    <style-modal
      v-model="showStyleModal"
      :current-style="currentFund.styleType || null"
      :styles-list="styleTypeMapping"
      @getStyle="getStyle"
    />
  </div>
</template>


<script>
import { ajax } from "jquery";
import { isEqual } from "lodash";
import StyleModal from "./components/style-modal.vue";
import {
  generateTrendOrIntervalConfig,
  generateThumbnailStyleMapping
} from "../../js/options-config.js";
import commonMethods from "../../mixins/common-methods.js";
import nav1 from "./nav-product/nav1/form";
import nav2 from "./nav-product/nav2/form";
import fixedIncome from "./fix-yield-product/form";
import privateEquity from "./equity-product/form";
import commonProduct from "./common-product/form";
import baseUrlConfig from "../../../../../common/js/base-url-config";

export default {
  components: {
    StyleModal,
    nav1,
    nav2,
    fixedIncome,
    commonProduct,
    privateEquity
  },

  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "product",
        funds: [{}]
      })
    }
  },

  computed: {
    thumbnailStyleMapping() {
      return generateThumbnailStyleMapping();
    },

    numberMapping() {
      let str = "一二三四五六七八九十";
      return str.split("");
    },

    currentFund() {
      return this.formData.funds[this.currentIndex] || {};
    },

    styleTypeMapping() {
      let mapping = [];
      let fund = this.formData.funds[this.currentIndex] || {};
      let productType = fund.productType || undefined;
      switch (productType + "") {
        case "1":
          mapping = ["commonProduct"];
          break;
        case "2":
          mapping = ["peFund1", "peFund2"];
          break;
        case "3":
          mapping = ["fixedIncome"];
          break;
        case "4":
          mapping = ["privateEquity"];
          break;
        default:
          mapping = [];
          break;
      }

      return mapping;
    },

    showAddTagBtn() {
      let styleType = this.formData.funds[this.currentIndex]
        ? this.formData.funds[this.currentIndex].styleType
        : "";
      return (
        styleType && styleType != "commonProduct" && styleType != "peFund2"
      );
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },
      deep: true
    },
    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }
        let data = JSON.parse(JSON.stringify(val));

        data.funds =
          data.funds && data.funds.length
            ? this.transferData(data.funds, "file")
            : [];
        this.formData = JSON.parse(JSON.stringify(data));
        this.formData.funds = this.setCompKeys(this.formData.funds);
      },

      deep: true,

      immediate: true
    }
  },

  beforeDestroy() {
    this.validate();
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  mixins: [commonMethods],

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("文件不能为空！"));
      }

      cb(errors);
    };

    return {
      productType: null,
      selecting: false,
      showStyleModal: false,
      formData: {},
      mainFormRules: {
        mainTitle: [
          { required: true, message: "不能为空" },
          {
            min: 0,
            max: 20,
            message: "最多20个字"
          }
        ]
      },
      validateFundRules: {
        productId: {
          required: true,
          message: "不能为空"
        }
      },
      validateRules: {
        description: { required: true, message: "不能为空" },
        jumpType: [
          {
            required: true,
            message: "不能为空"
          }
        ],
        link: {
          required: true,
          message: "链接不能为空"
        },
        fileData: [
          {
            required: true,
            message: "文件不能为空"
          },
          { validator: validateFileData }
        ]
      },
      currentIndex: 0,
      preIndex: 0,
      indicatorKeysOptions: generateTrendOrIntervalConfig(),
      productTypeOptions: [
        {
          label: "通用类产品",
          value: "1"
        },
        {
          label: "净值类产品",
          value: "2"
        },
        {
          label: "固收类产品",
          value: "3"
        },
        {
          label: "股权类产品",
          value: "4"
        }
      ]
    };
  },

  methods: {
    // validateFund(prop, validate, msg) {
    //   console.log("validate", validate);
    //   this.$set(this.formData.funds[this.currentIndex], "validate", !!validate);
    // },

    getCurrentComp(index) {
      let comp = undefined;
      let data = this.formData.funds[index] || {};
      switch (data.productType) {
        case "1":
          if (data.styleType == "commonProduct") {
            comp = "commonProduct";
          }
          break;
        case "2":
          if (data.styleType == "peFund1") {
            comp = "nav1";
          } else if (data.styleType == "peFund2") {
            comp = "nav2";
          }
          break;
        case "3":
          if (data.styleType == "fixedIncome") {
            comp = "fixedIncome";
          }
          break;
        case "4":
          if (data.styleType == "privateEquity") {
            comp = "privateEquity";
          }
          break;
        default:
          break;
      }
      return comp;
    },

    getProductType(index) {
      if (JSON.stringify(this.formData.funds[index]) == "{}") {
        return false;
      }
      let matchType = null;
      matchType =
        this.productTypeOptions.filter(item => {
          return item.value == this.formData.funds[index].productType;
        })[0] || null;

      return matchType ? matchType.label : false;
    },

    // 验证某个字段
    validateField(key) {
      this.$refs[`currentFund${this.currentIndex}`][0].validateField(key);
    },

    // 更换当前产品
    onFocus(index) {
      // this.valiateCurrentFund();
      this.preIndex = this.currentIndex;
      this.currentIndex = index;
    },

    // 添加产品
    addProduct() {
      if (this.formData.funds.length >= 5) {
        this.$message({
          type: "error",
          message: "最多只能添加五只基金！",
          showClose: true
        });
        return;
      }
      this.selecting = true;
    },

    // 添加产品
    onProductTypeChange(val) {
      let styleType;
      switch (this.productType) {
        case "1":
          styleType = "commonProduct";
          break;
        case "2":
          styleType = "peFund1";
          break;
        case "3":
          styleType = "fixedIncome";
          break;
        case "4":
          styleType = "privateEquity";
          break;
        default:
          break;
      }
      this.formData.funds.push({ productType: this.productType, styleType });
      this.productType = null;
      this.selecting = false;
    },

    //  删除产品
    deleteProduct(index) {
      if (this.formData.funds.length <= 1) {
        this.$message({
          type: "error",
          message: "至少要有一只基金！",
          showClose: true
        });
        return;
      }
      this.formData.funds.splice(index, 1);

      if (this.currentIndex === index) {
        if (this.currentIndex - 1 >= 0) {
          this.currentIndex = this.currentIndex - 1;
        }
      } else if (this.currentIndex > index) {
        this.currentIndex -= 1;
      }
    },

    // 添加标签
    addTag() {
      this.formData.funds[this.currentIndex].tags.push("");
    },

    switch(direction, index) {
      if (this.formData.funds.length <= 1) {
        return;
      }
      let nearIndex;

      if (direction === "up") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: "当前基金已在最上边！",
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (index >= this.formData.funds.length - 1) {
          this.$message({
            type: "error",
            message: "当前基金已在最下边！",
            showClose: true
          });
          return;
        }

        nearIndex = index + 1;
      }

      let currentItem = this.formData.funds[index];
      let nearItme = this.formData.funds[nearIndex];
      this.$set(this.formData.funds, nearIndex, currentItem);
      this.$set(this.formData.funds, index, nearItme);
      if (index == this.currentIndex) {
        this.currentIndex = nearIndex;
        return;
      }

      if (index == this.currentIndex + 1 && direction == "up") {
        this.currentIndex = index;
        return;
      }

      if (index == this.currentIndex - 1 && direction == "down") {
        this.currentIndex = index;
        return;
      }
    },

    moveUp(index) {
      this.switch("up", index);
    },

    moveDown(index) {
      this.switch("down", index);
    },

    setCurrentProductName(name, index) {
      if (this.formData.funds[index].productType == "1") {
        this.$set(this.formData.funds[index], "selfAdd", !!!name);
        if (!!!name && !!!this.formData.funds[index].productId) {
          this.$set(this.formData.funds[index], "selfAdd", "");
        }
      }

      this.$set(this.formData.funds[index], "productName", name);
    },

    searchProduct(query) {
      let productType = this.formData.funds[this.currentIndex].productType;
      // 通用和净值
      if (productType == "1" || productType == "2") {
        let params = {
          m: "Search",
          c: "search",
          a: "quickSearch",
          count: 100,
          search_type: "fund,fund_public",
          skeyword: query
        };

        return new Promise((resolve, reject) => {
          ajax({
            url: "https://serve.simuwang.com/index.php",
            type: "GET",
            dataType: "jsonp",
            data: params,
            success: data => {
              resolve(data);
            },

            error: e => {
              resolve([]);
            }
          });
        });
      } else if (productType == "3" || productType == "4") {
        //固收和股权
        let typeMapping = {
          "3": "steady",
          "4": "equity"
        };
        let params = {
          type: typeMapping[productType],
          kw: query
        };

        let baseUrl = baseUrlConfig[process.env.NODE_ENV].officialMobile;

        return new Promise((resolve, reject) => {
          this.$http
            .get(`${baseUrl}/fund/searchFinishedDirectPPFundListByKey/`, params)
            .then(res => {
              resolve(res.data);
            })
            .catch(e => {
              resolve([]);
            });
        });
      }
    },

    getFileData(index) {
      this.formData.funds[this.currentIndex].file = this.formData.funds[
        this.currentIndex
      ].fileData.filePath;
      this.formData.funds[this.currentIndex].fileName = this.formData.funds[
        this.currentIndex
      ].file
        ? this.formData.funds[this.currentIndex].fileData.fileName
        : "";
      this.$refs.currentFund.validateField("fileData");
    },

    chooseStyle() {
      this.showStyleModal = true;
    },

    getStyle(style) {
      if (this.formData.funds[this.currentIndex].styleType != style) {
        this.$set(this.formData.funds, this.currentIndex, {
          productType: this.formData.funds[this.currentIndex].productType,
          styleType: style,
          productId: this.formData.funds[this.currentIndex].productId,
          productName: this.formData.funds[this.currentIndex].productName,
          tags: [],
          compKey: this.formData.funds[this.currentIndex].compKey
        });
      }

      this.$set(this.formData.funds[this.currentIndex], "styleType", style);
    },

    validate() {
      if (
        this.$refs.currentFund0 &&
        this.$refs.currentFund0[0] &&
        this.$refs.currentFund0[0].validate
      ) {
        this.valiateCurrentFund();
      }
      let finalValidate = true;
      this.$refs.form.validate(valid => {
        finalValidate = valid && finalValidate;

        let funds = this.formData.funds || [];
        funds.forEach(fund => {
          fund.validate = !!(fund.productId && fund.validate);

          finalValidate = finalValidate && fund.validate;
        });

        if (!funds.length) {
          finalValidate = false;
        }
      });

      this.$set(this.formData, "validate", finalValidate);

      let data = JSON.parse(JSON.stringify(this.formData));
      data.funds = this.deleteUselessKeys(data.funds);
      this.$emit("getFormData", data, true);
    },

    valiateCurrentFund() {
      let funds = this.formData.funds || [];
      funds.forEach((fund, index) => {
        let finalValidate = true;
        this.$refs[`fundForm${index}`][0].validate(valid => {
          finalValidate = finalValidate && valid;
          this.$refs[`currentFund${index}`][0].validate(validFund => {
            finalValidate = finalValidate && validFund;
            this.$set(this.formData.funds[index], "validate", finalValidate);
          });
        });
      });
    }
  }
};
</script>

<style lang="less">
.title-bar {
  background-color: #111111;
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 40px;
  line-height: 40px;
  background-color: #222222;
  .product-config-title {
    height: 14px;
    line-height: 14px;
    font-size: 14px;
    padding-left: 6px;
    border-left: 4px solid #2992ff;
    color: #ffffff;
  }

  .product-add-btn {
    height: 12px;
    line-height: 12px;
    font-size: 12px;
    color: #2992ff;
    margin: 0 10px;
    cursor: pointer;
    &.disabled-action-btn {
      color: #999999;
      cursor: not-allowed;
    }
  }
}

.product-list-wrapper {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  &.append-fix {
    margin-top: 6px;
  }
  .action-area {
    height: 100%;
    width: 72px;
    margin-left: 8px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    position: relative;
    .product-action-btn {
      width: 16px;
      height: 16px;
      cursor: pointer;
    }

    .move-down {
      background: url("../../../../../assets/images/direct-sale/move.png")
        no-repeat;
      background-position: 0px -32px;
      &:hover {
        background-position: 0 0;
      }
      &.disabled-btn {
        background-position: 0px -48px;
        cursor: not-allowed;
      }
    }

    .move-up {
      background: url("../../../../../assets/images/direct-sale/move.png")
        no-repeat;
      background-position: 0px -16px;
      &:hover {
        background-position: 0px -112px;
      }
      &.disabled-btn {
        background-position: 0px -96px;
        cursor: not-allowed;
      }
    }

    .delete-product {
      background: url("../../../../../assets/images/direct-sale/move.png")
        no-repeat;
      background-position: 0px -64px;
      &:hover {
        background-position: 0 -80px;
      }
    }

    .move-left {
      background: url("../../../../../assets/images/direct-sale/move.png")
        no-repeat;
      background-position: -1px -172px;
      &:hover {
        background-position: -1px -154px;
      }

      &.disabled-btn {
        background-position: -1px -134px;
        cursor: not-allowed;
      }
    }

    .move-right {
      background: url("../../../../../assets/images/direct-sale/move.png")
        no-repeat;
      background-position: 0 -232px;
      &:hover {
        background-position: 0 -212px;
      }
      &.disabled-btn {
        background-position: 0 -193px;
        cursor: not-allowed;
      }
    }
  }
  &.active-product {
    .el-select .el-input .el-input__inner,
    .el-input .el-input__inner,
    .el-input__inner {
      border-color: #2992ff !important;
    }

    .move-down {
      background: url("../../../../../assets/images/direct-sale/move.png")
        no-repeat;

      background-position: 0px 0px;
      &.disabled-btn {
        background-position: 0px -48px;
      }
    }

    .move-up {
      background: url("../../../../../assets/images/direct-sale/move.png")
        no-repeat;
      background-position: 0px -112px;
      &.disabled-btn {
        background-position: 0px -96px;
      }
    }

    .delete-product {
      background: url("../../../../../assets/images/direct-sale/move.png")
        no-repeat;
      background-position: 0px -80px;
    }

    .move-left {
      background: url("../../../../../assets/images/direct-sale/move.png")
        no-repeat;

      background-position: -1px -154px;
      &.disabled-btn {
        background-position: -1px -134px;
        cursor: not-allowed;
      }
    }

    .move-right {
      background: url("../../../../../assets/images/direct-sale/move.png")
        no-repeat;
      background-position: 0 -212px;
      &.disabled-btn {
        background-position: 0 -193px;
        cursor: not-allowed;
      }
    }
  }
}

.style-container {
  cursor: pointer;
  width: 82px;
  height: 82px;
  line-height: 82px;
  color: #666666;
  border: 1px solid #444444;
  text-align: center;
  background: url("../../../../../assets/images/direct-sale/thumbnail.png")
    no-repeat;
}

.type-selector {
  visibility: hidden;
  width: 0;
  transition: all 0.3s;
  &.to-select {
    visibility: visible;
    width: 150px;
  }
}

.form-content {
  padding: 8px 10px;
  .el-form-item {
    position: relative;
  }
}

.el-form--label-left .el-form-item__label {
  color: #eee !important;
  font-size: 12px !important;
  font-weight: normal !important;
}

.el-form-item.is-required .el-form-item__label:before {
  position: absolute;
  left: -6px;
}

.el-form-item {
  &.is-error {
    .el-select .el-input .el-input__inner,
    .el-input .el-input__inner,
    .el-input__inner {
      border-color: #f56c6c !important;
    }
  }

  .active-product {
    .el-select .el-input .el-input__inner,
    .el-input .el-input__inner,
    .el-input__inner {
      border-color: #2992ff !important;
    }
  }
  &.position-item {
    position: relative;
  }
  margin-bottom: 1px !important;
  &.pic-el-form-item {
    margin-top: 14px;
  }
}

.el-form-item__error {
  top: 78% !important;
  // padding-top: 0 !important;
}

.validate-item {
  .el-form-item__error {
    left: 15px;
  }
}

.init-form-item {
  &.el-form-item {
    margin-bottom: 5px !important;
  }
  .el-form-item__error {
    top: 100% !important;
    padding-top: 0 !important;
  }
}

.custom-file-uploader.file-upload-container {
  margin-top: 8px;
}

.fund-validate-icon {
  background: url("../../../../../assets/images/direct-sale/warning.png")
    no-repeat;
  background-position: center;
  background-size: 100%;
  display: inline-block;
  width: 15px;
  height: 15px;
  vertical-align: text-bottom;
  position: absolute;
  top: 34px;
  left: 0;
}

.el-input-group__append {
  background-color: transparent !important;
  border: none !important;
  padding: 0;
  color: rgba(255, 255, 255, 0.25);
  font-size: 12px;
  span{
    display: inline-block;
    width: 36px;
    text-align: center;
  }
}

.el-input-group--append .el-input__inner {
  width: calc(~"100% + 36px");
  border-radius: 2px;
}
</style>

