
<template>
  <div class="hot-point-wrapper">
    <h2 class="config-title">
      热点模块
      <span class="hot-point-tip">(提示：热点数量控制在2-4个)</span>
    </h2>

    <div class="config-content-area">
      <div v-for="(spot,index) in formData.spots" :key="compKeys[index]" class="single-content">
        <div class="content-title">
          <span class="title">{{`热点${index+1}`}}</span>
          <span
            class="action-btn move-left"
            @click="moveLeft(index)"
            :class="{'disable-btn':formData.spots.length<=1}"
          >[左移]</span>
          <span
            class="action-btn move-right"
            @click="moveRight(index)"
            :class="{'disable-btn':formData.spots.length<=1}"
          >[右移]</span>
          <span
            class="action-btn"
            :class="{'disable-btn':formData.spots.length<=2}"
            @click="deleteHotPoint(index)"
          >[删除]</span>
        </div>

        <el-form
          class="form-content-area"
          :ref="`spot${index}`"
          :rules="validateRules"
          :model="spot"
          label-width="75px"
          label-position="left"
        >
          <el-form-item label="标题：" prop="title">
            <el-input v-model.trim="formData.spots[index]['title']" placeholder="5个字以内(含5个字)"/>
          </el-form-item>

          <el-form-item label="图标：" prop="icon">
            <vimageUpload
              showRecommendSize
              recommendSize="94x94"
              v-model="formData.spots[index]['icon']"
              url="file/visitingCard"
              fieldName="directSalePicture"
              @change="onIconChange(index)"
              :imgStyle="{
                            minWidth: '94px',
                            maxWidth: '94px',
                            height: '94px'
                        }"
            />
          </el-form-item>

          <el-form-item label="跳转：" prop="jumpType">
            <el-select v-model="formData.spots[index]['jumpType']" style="width:100%;">
              <el-option value="1" label="外链"></el-option>
              <el-option value="2" label="PDF"></el-option>
              <el-option value="5" label="无跳转"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item
            label="外链："
            prop="link"
            v-if="formData.spots[index]['jumpType']=='1'"
            key="link"
          >
            <el-input v-model.trim="formData.spots[index]['link']" placeholder="请输入链接"/>
          </el-form-item>
          <el-form-item
            v-if="formData.spots[index]['jumpType']=='2'"
            label="文件："
            prop="fileData"
            key="file"
          >
            <vfileUpload
              @getFileData="getFileData(index)"
              v-model="formData.spots[index].fileData"
              url="file/visitingCard"
              fileName="directSalePdf"
              class="custom-file-uploader"
              resName="fileName"
              :foreignPath="true"
              :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
            />
          </el-form-item>
        </el-form>
      </div>
      <div class="add-btn-wrapper">
        <span
          class="action-btn add-btn"
          :class="{'disable-btn':formData.spots.length>=4}"
          @click="addHotPoint"
        >+添加热点</span>
      </div>
    </div>
  </div>
</template>

<script>
import { isEqual } from "lodash";
import commonMethods from "../../mixins/common-methods";
export default {
  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "hotPoint",
        spots: [
          { jumpType: "1" },
          { jumpType: "1" },
          { jumpType: "1" },
          { jumpType: "1" }
        ]
      })
    }
  },

  mixins: [commonMethods],

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("文件不能为空！"));
      }

      cb(errors);
    };
    return {
      compKeys: [],
      formData: {
        name: "hotPoint",
        spots: [
          { jumpType: "1" },
          { jumpType: "1" },
          { jumpType: "1" },
          { jumpType: "1" }
        ]
      },
      validateRules: {
        title: [
          {
            required: true,
            message: "标题不能为空"
          },
          {
            min: 0,
            max: 5,
            message: "最多5个字"
          }
        ],

        icon: {
          required: true,
          message: "图标不能为空"
        },

        fileData: [
          {
            required: true,
            message: "文件不能为空"
          },
          { validator: validateFileData }
        ],

        link: {
          required: true,
          message: "链接不能为空"
        }
      }
    };
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },

      deep: true
    },

    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }
        let data = JSON.parse(JSON.stringify(val));
        data.spots =
          data.spots && data.spots.length
            ? this.transferData(data.spots, "file")
            : [
                { jumpType: "1" },
                { jumpType: "1" },
                { jumpType: "1" },
                { jumpType: "1" }
              ];

        this.formData = JSON.parse(JSON.stringify(data));
        this.compKeys = this.setCompKeys(
          this.formData.spots,
          this.compKeys || []
        );
      },

      deep: true,

      immediate: true
    }
  },

  beforeDestroy() {
    this.validate();
  },

  methods: {
    onIconChange(index) {
      this.$refs[`spot${index}`][0].validateField("icon");
    },

    getFileData(index) {
      this.formData.spots[index].file = this.formData.spots[
        index
      ].fileData.filePath;
      this.formData.spots[index].fileName = this.formData.spots[index].file
        ? this.formData.spots[index].fileData.fileName
        : "";
      this.$refs[`spot${index}`][0].validateField("fileData");
    },

    addHotPoint() {
      let len = this.formData.spots.length;

      if (len >= 4) {
        // this.$message({
        //   type: "error",
        //   message: "最多只能添加四个热点",
        //   showClose: true
        // });
        return;
      }
      this.formData.spots.push({ jumpType: "1" });
    },

    deleteHotPoint(index) {
      let len = this.formData.spots.length;
      if (len <= 2) {
        // this.$message({
        //   type: "error",
        //   message: "至少要有两个热点",
        //   showClose: true
        // });
        return;
      }
      this.compKeys.splice(index, 1);
      this.formData.spots.splice(index, 1);
    },

    switch(direction, index) {
      if (this.formData.spots.length <= 1) {
        return;
      }
      let nearIndex;

      if (direction === "left") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: "当前热点已在最左边！",
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (index >= this.formData.spots.length - 1) {
          this.$message({
            type: "error",
            message: "当前热点已在最右边！",
            showClose: true
          });
          return;
        }

        nearIndex = index + 1;
      }
      let currentKey = this.compKeys[index];
      let nearKey = this.compKeys[nearIndex];
      this.$set(this.compKeys, nearIndex, currentKey);
      this.$set(this.compKeys, index, nearKey);

      let currentItem = this.formData.spots[index];
      let nearItme = this.formData.spots[nearIndex];
      this.$set(this.formData.spots, nearIndex, currentItem);
      this.$set(this.formData.spots, index, nearItme);
    },

    moveLeft(index) {
      this.switch("left", index);
    },

    moveRight(index) {
      this.switch("right", index);
    },

    validate() {
      let finalValid = true;

      this.formData.spots.forEach((form, index) => {
        if (this.$refs[`spot${index}`][0]) {
          this.$refs[`spot${index}`][0].validate(valid => {
            finalValid = finalValid && valid;
          });
        }
      });
      this.$set(this.formData, "validate", finalValid);
      let data = JSON.parse(JSON.stringify(this.formData));
      data.spots = this.deleteUselessKeys(data.spots);
      this.$emit("getFormData", data, true);
    },

    resetValid() {
      this.formData.spots.forEach((form, index) => {
        if (this.$refs[`spot${index}`][0]) {
          this.$refs[`spot${index}`][0].clearValidate();
        }
      });
    }
  }
};
</script>

<style lang="less" >
.disable-btn {
  cursor: not-allowed !important;
  color: #999 !important;
}

.custom-file-uploader.file-upload-container {
  margin-top: 8px;
}

.hot-point-wrapper {
  .hot-point-tip {
    font-size: 12px;
    font-weight: 300;
    color: #999;
  }

  .action-btn {
    color: #1073c5;
    cursor: pointer;
  }

  // .add-btn {
  //   display: block;
  //   width: 80px;
  // }

  .content-title {
    margin: 8px 0;
    .title {
      font-size: 14px;
    }
  }

  .move-right {
    margin: 0 10px;
  }
}
</style>

