<template>
    <div class="product-item">
        <div class="product-brief">
            <div class="product-brief-intro">{{(fund.selfAdd ? fund.productId : fund.productName)||"产品名称" }}</div>
            <div class="product-describe">
                {{fund.description || "产品描述"}}
            </div>
        </div>
        <div class="get-detail" v-if="+fund.jumpType !== 5">查看详情</div>
    </div>
</template>

<script>
export default {
    props: {
        fund: {
            type: Object,
            default: {}
        }
    },
    data(){
        return {
            
        }
    },
    methods: {

    },
    mounted() {
    },
    watch: {
        // moduleData: {
        //     handler(val){
        //     }
        // }
    }
}
</script>
<style lang="less" scoped>
            // 产品简称和标签
    .product-item{
        .product-brief{
            text-align: center;
            white-space: normal;
            .product-describe{
                // height: 50px;
                width: 273.88px;
                color: #999;
                font-size: 12px;
                line-height: 16.48px;
                margin: 7.13px auto 0;
                word-break: break-all;
            }
        }
   }
</style>