<template>
  <new-product-config-form
    ref="form"
    @getFormData="getData"
    configTitle="新品发布模块"
    :configData="configData"
  />
</template>

<script>
import NewProductConfigForm from "../new-or-other-product-form.vue";

export default {
  props: {
    configData: {
      type: [Object, Array]
    }
  },
  components: {
    NewProductConfigForm
  },

  // beforeDestroy() {
  //   this.getData();
  // },

  methods: {
    getData(data, changeByValidate) {
      this.$emit("getFormData", data, changeByValidate);
    }
  }
};
</script>

<style lang="less" scoped>
</style>


