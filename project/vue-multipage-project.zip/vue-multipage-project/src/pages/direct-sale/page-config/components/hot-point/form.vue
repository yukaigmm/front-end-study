<template>
  <div>
    <div class="product-list">
      <div class="title-bar">
        <span class="product-config-title">热点列表</span>
        <span class="product-add-btn" v-if="false" @click="addHotPoint">+添加热点</span>
      </div>
      <div class="form-content">
        <div class="ad-list">
          <div
            v-for="(spot,index) in formData.spots"
            :class="{'active-product':index ==currentIndex}"
            class="product-list-wrapper"
            :key="spot.compKey"
            @click="changeHotPoint(index)"
          >
            <div class="validate-icon" v-show="spot.validate === false"></div>
            <span class="product-title">{{`热点${numbersMapping[index]}`}}</span>
            <div class="action-area">
              <span
                class="product-action-btn move-up"
                :class="{'disabled-btn':index ==0}"
                @click.prevent.stop="moveUp(index)"
              ></span>
              <span
                class="product-action-btn move-down"
                :class="{'disabled-btn':index ==formData.spots.length-1}"
                @click.prevent.stop="moveDown(index)"
              ></span>
              <span
                class="product-action-btn delete-product"
                @click.prevent.stop="deleteProduct(index)"
              ></span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <el-form
      v-for="(spot,index) in formData.spots"
      :key="spot.compKey"
      :rules="validateRules"
      label-width="60px"
      label-position="left"
      :model="spot"
      v-show="index == currentIndex"
      :ref="`spot${index}`"
    >
      <div class="title-bar">
        <div class="title product-config-title">{{`热点${numbersMapping[index]}属性`}}</div>
      </div>

      <div class="form-content">
        <el-form-item label="展示样式">
          <div
            class="style-container"
            :style="`${thumbnailStyleMapping[spot.styleType]}`"
            @click="chooseStyle"
          >
            <span v-if="!spot.styleType">请选择样式</span>
          </div>
        </el-form-item>

        <el-form
          v-for="(spotItem,titleIndex) in spot.spotItems"
          :rules="validateRules"
          label-width="60px"
          label-position="left"
          class="product-list-wrapper"
          :class="{'active-product':titleIndex == iconIndex}"
          @click.native="onItemFocus(titleIndex)"
          :model="spotItem"
          :key="spotItem.compKey"
          :ref="`spotItem${index + '' + titleIndex}`"
        >
          <el-form-item
            class="pic-el-form-item init-form-item"
            :class="{'validate-item':spotItem.validate===false}"
            :label="`图标${numbersMapping[titleIndex]}`"
            prop="icon"
            :key="spotItem.compKey"
          >
            <div
              class="hot-point-validate-icon"
              title="该图标存在不正确的配置项"
              v-show="spotItem.validate===false"
            ></div>
            <vimageUpload
              showRecommendSize
              recommendSize="94x94"
              v-model="spotItem.icon"
              url="file/visitingCard"
              fieldName="directSalePicture"
              @change="onIconChange(iconIndex)"
              :imgStyle="{
                            minWidth: '80px',
                            maxWidth: '80px',
                            height: '80px'
                        }"
            />
          </el-form-item>
          <div class="action-area" :key="spotItem.compKey">
            <span
              class="product-action-btn move-left"
              :class="{'disabled-btn':titleIndex ==0}"
              @click.prevent.stop="moveLeft(titleIndex)"
            ></span>
            <span
              class="product-action-btn move-right"
              :class="{'disabled-btn':titleIndex ==spot.spotItems.length-1}"
              @click.prevent.stop="moveRight(titleIndex)"
            ></span>
            <span
              class="product-action-btn delete-product"
              @click.prevent.stop="deleteSpotItem(titleIndex)"
            ></span>
          </div>
        </el-form>

        <span class="add-pic-btn" v-show="spot.spotItems.length <4" @click="addSpotItem">+添加图标</span>
      </div>

      <div class="title-bar">
        <div class="title product-config-title">{{`图标${numbersMapping[iconIndex]}属性`}}</div>
      </div>

      <el-form
        v-for="(spotItem,picIndex) in spot.spotItems"
        :rules="validateRules"
        label-width="60px"
        label-position="left"
        :model="spotItem"
        :key="spotItem.compKey"
        :ref="`iconItem${index+ '' +picIndex}`"
        v-show="picIndex == iconIndex"
      >
        <div class="form-content">
          <el-form-item label="标题" prop="title" :key="spotItem.compKey">
            <el-input v-model.trim="spotItem['title']" placeholder="5个字以内(含5个字)"/>
          </el-form-item>

          <el-form-item label="跳转" prop="jumpType" :key="spotItem.compKey">
            <el-select v-model="spotItem['jumpType']" style="width:100%;">
              <el-option value="1" label="外链"></el-option>
              <el-option value="2" label="PDF"></el-option>
              <el-option value="5" label="无跳转"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item
            label="外链"
            prop="link"
            v-if="spotItem['jumpType']=='1'"
            :key="spotItem.compKey"
          >
            <el-input v-model.trim="spotItem['link']" placeholder="请输入链接"/>
          </el-form-item>
          <el-form-item
            v-if="spotItem['jumpType']=='2'"
            label="文件"
            prop="fileData"
            :key="spotItem.compKey"
          >
            <vfileUpload
              @getFileData="getFileData(iconIndex)"
              v-model="spotItem.fileData"
              url="file/visitingCard"
              fileName="directSalePdf"
              class="custom-file-uploader"
              resName="fileName"
              :foreignPath="true"
              :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
            />
          </el-form-item>
        </div>
      </el-form>
    </el-form>

    <style-modal
      v-model="showStyleModal"
      :current-style="currentSpot.styleType || null"
      :styles-list="['hotPoint1']"
      @getStyle="getStyle"
    />
  </div>
</template>


<script>
import { isEqual } from "lodash";
import commonMethods from "../../mixins/common-methods.js";
import editor from "../../../../../common/components/inputs/editor-with-menu/editor";
import StyleModal from "../product/components/style-modal";
import { generateThumbnailStyleMapping } from "../../js/options-config";
export default {
  components: {
    editor,
    StyleModal
  },

  props: {
    configData: {
      type: [Object, Array]
    }
  },

  computed: {
    currentSpot() {
      return this.formData.spots[this.currentIndex] || {};
    },

    currentSpotItem() {
      return this.formData.spots[this.currentIndex]
        ? this.formData.spots[this.currentIndex].spotItems[this.iconIndex] || {}
        : {};
    },

    numbersMapping() {
      let str = "一二三四五六七八九十";
      return str.split("");
    },

    thumbnailStyleMapping() {
      return generateThumbnailStyleMapping();
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },
      deep: true
    },
    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }

        let data = JSON.parse(JSON.stringify(val));

        data.spots =
          data.spots && data.spots.length
            ? this.transferData(data.spots, "file", false, "spotItems")
            : [
                {
                  // 热点一
                  styleType: "hotPoint1",
                  spotItems: [
                    {
                      jumpType: "1"
                    },
                    {
                      jumpType: "1"
                    }
                  ]
                }
              ];
        this.formData = JSON.parse(JSON.stringify(data));
        this.formData.spots = this.setCompKeys(
          this.formData.spots,
          undefined,
          "spotItems"
        );
      },

      deep: true,

      immediate: true
    }
  },

  mixins: [commonMethods],

  beforeDestroy() {
    this.validate();
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("不能为空！"));
      }

      cb(errors);
    };
    return {
      iconIndex: 0,
      currentIndex: 0,
      showStyleModal: false,
      formData: {},
      validateRules: {
        title: [
          {
            required: true,
            message: "不能为空"
          },
          {
            min: 0,
            max: 5,
            message: "最多5个字"
          }
        ],

        icon: {
          required: true,
          message: "不能为空"
        },

        fileData: [
          {
            required: true,
            message: "不能为空"
          },
          { validator: validateFileData }
        ],

        link: {
          required: true,
          message: "不能为空"
        }
      }
    };
  },

  methods: {
    // 更换当前观点
    changeHotPoint(index) {
      this.currentIndex = index;
      this.iconIndex = 0;
    },

    //    更换当前子热点
    onItemFocus(index) {
      this.iconIndex = index;
    },

    // 添加热点
    addHotPoint() {
      this.formData.spots.push({
        styleType: "hotPoint1",
        spotItems: [
          {
            jumpType: "1"
          },
          {
            jumpType: "1"
          }
        ]
      });
    },

    // 添加子热点
    addSpotItem() {
      this.formData.spots[this.currentIndex].spotItems.push({ jumpType: "1" });
    },

    //  删除热点
    deleteProduct(index) {
      if (this.formData.spots.length <= 1) {
        return;
      }
      this.formData.spots.splice(index, 1);

      if (this.currentIndex === index) {
        if (this.currentIndex - 1 >= 0) {
          this.currentIndex = this.currentIndex - 1;
        }
      } else if (this.currentIndex > index) {
        this.currentIndex -= 1;
      }
    },

    switch(direction, index) {
      if (this.formData.spots.length <= 1) {
        return;
      }
      let nearIndex;

      if (direction === "up") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: `当前热点已在最上边！`,
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (index >= this.formData.spots.length - 1) {
          this.$message({
            type: "error",
            message: `当前热点已在最下边！`,
            showClose: true
          });
          return;
        }

        nearIndex = index + 1;
      }
      let currentItem = this.formData.spots[index];
      let nearItme = this.formData.spots[nearIndex];
      this.$set(this.formData.spots, nearIndex, currentItem);
      this.$set(this.formData.spots, index, nearItme);

      if (index == this.currentIndex) {
        this.currentIndex = nearIndex;
        return;
      }

      if (index == this.currentIndex + 1 && direction == "up") {
        this.currentIndex = index;
        return;
      }

      if (index == this.currentIndex - 1 && direction == "down") {
        this.currentIndex = index;
        return;
      }
    },

    switchItem(drl, index) {
      if (this.formData.spots[this.currentIndex].spotItems.length <= 1) {
        return;
      }
      let nearIndex;

      if (drl === "left") {
        if (index <= 0) {
          this.$message({
            type: "error",
            message: `当前子热点已在最左边！`,
            showClose: true
          });
          return;
        }
        nearIndex = index - 1;
      } else {
        if (
          index >=
          this.formData.spots[this.currentIndex].spotItems.length - 1
        ) {
          this.$message({
            type: "error",
            message: `当前子热点已在最右边！`,
            showClose: true
          });
          return;
        }

        nearIndex = index + 1;
      }
      let currentItem = this.formData.spots[this.currentIndex].spotItems[index];
      let nearItme = this.formData.spots[this.currentIndex].spotItems[
        nearIndex
      ];
      this.$set(
        this.formData.spots[this.currentIndex].spotItems,
        nearIndex,
        currentItem
      );
      this.$set(
        this.formData.spots[this.currentIndex].spotItems,
        index,
        nearItme
      );

      if (index == this.iconIndex) {
        this.iconIndex = nearIndex;
        return;
      }

      if (index == this.iconIndex + 1 && drl == "left") {
        this.iconIndex = index;
        return;
      }

      if (index == this.iconIndex - 1 && drl == "right") {
        this.iconIndex = index;
        return;
      }
    },

    moveUp(index) {
      this.switch("up", index);
    },

    moveDown(index) {
      this.switch("down", index);
    },

    moveLeft(index) {
      this.switchItem("left", index);
    },

    moveRight(index) {
      this.switchItem("right", index);
    },

    deleteSpotItem(index) {
      if (this.formData.spots[this.currentIndex].spotItems.length <= 2) {
        this.$message({
          type: "error",
          message: `至少需要两个子热点！`,
          showClose: true
        });
        return;
      }
      this.formData.spots[this.currentIndex].spotItems.splice(index, 1);

      if (this.iconIndex === index) {
        if (this.iconIndex - 1 >= 0) {
          this.iconIndex = this.iconIndex - 1;
        }
      } else if (this.iconIndex > index) {
        this.iconIndex -= 1;
      }
    },

    onIconChange(index) {
      this.$refs[`spotItem${this.currentIndex + "" + index}`][0].validateField(
        "icon"
      );
    },

    getFileData(index) {
      this.formData.spots[this.currentIndex].spotItems[
        this.iconIndex
      ].file = this.formData.spots[this.currentIndex].spotItems[
        this.iconIndex
      ].fileData.filePath;
      this.formData.spots[this.currentIndex].spotItems[
        this.iconIndex
      ].fileName = this.formData.spots[this.currentIndex].spotItems[
        this.iconIndex
      ].file
        ? this.formData.spots[this.currentIndex].spotItems[this.iconIndex]
            .fileData.fileName
        : "";
      this.$refs[
        `iconItem${this.currentIndex + "" + this.iconIndex}`
      ][0].validateField("fileData");
    },

    chooseStyle() {
      this.showStyleModal = true;
    },

    getStyle(style) {
      this.$set(this.formData.spots[this.currentIndex], "styleType", style);
    },

    validate() {
      let finalValid = true;
      this.validateIcon();
      let spots = this.formData.spots || [];
      finalValid = spots.every((spot, spotIndex) => {
        let spotItems = spot.spotItems || [];
        return spotItems.every((icon, iconIndex) => {
          return icon.validate;
        });
      });
      this.$set(this.formData, "validate", finalValid);
      let data = JSON.parse(JSON.stringify(this.formData));
      data.spots = this.deleteUselessKeys(data.spots, "spotItems");
      this.$emit("getFormData", data, true);
    },

    validateIcon() {
      let spots = this.formData.spots || [];
      spots.forEach((spot, spotIndex) => {
        let finalValid = true;
        let spotItems = spot.spotItems || [];
        spotItems.forEach((item, itemIndex) => {
          this.$refs[`iconItem${spotIndex + "" + itemIndex}`][0].validate(
            valid => {
              finalValid = finalValid && valid;
              this.$refs[`spotItem${spotIndex + "" + itemIndex}`][0].validate(
                iconValid => {
                  finalValid = finalValid && iconValid;
                  this.$set(
                    this.formData.spots[spotIndex].spotItems[itemIndex],
                    "validate",
                    finalValid
                  );
                }
              );
            }
          );
        });
      });
    }
  }
};
</script>

<style lang="less">
.custom-datepicker {
  .el-input__prefix,
  .el-input__suffix {
    top: 4px !important;
  }
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100% !important;
  }
}

.hot-point-validate-icon {
  background: url("../../../../../assets/images/direct-sale/warning.png")
    no-repeat;
  background-position: center;
  background-size: 100%;
  display: inline-block;
  width: 15px;
  height: 15px;
  vertical-align: text-bottom;
  position: absolute;
  top: 79px;
  left: 0px;
  cursor: pointer;
}
</style>

