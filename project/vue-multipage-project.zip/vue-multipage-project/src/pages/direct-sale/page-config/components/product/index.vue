<template>
    <div class="product-container direct-sale-module">
        <div class="title-container">
           <span class="main-title">{{compData.mainTitle}}</span>
           <span class="sub-title">{{compData.subTitle}}</span>
           <span class="tips" v-show="!moduleData.mainTitle && !moduleData.subTitle">
               (标题未配置将不会在首页展示)
            </span>
       </div>
        <div class="product-container">
            <component 
                v-for="item in compData.funds"
                :key="item.compKey"
                :is="item.productType" 
                :fund="item"
            >
            </component>
        </div>
    </div>
</template>

<script>
import fixYield from "./fix-yield-product/index.vue";
import equity from "./equity-product/index.vue";
import navProduct from "./nav-product/index.vue";
import common from "./common-product/index.vue";
export default {
    props: {
        moduleData: {
            type: Object,
            default: {}
        }
    },
    components: {
        fixYield,
        equity,
        navProduct,
        common,
    },
    computed: {
        compData(){
            return {
                mainTitle: this.moduleData.mainTitle || "主标题",
                subTitle: this.moduleData.subTitle || "副标题",
                funds: this.moduleData.funds ? this.moduleData.funds.map((item, index) => {
                    return {
                        productType: this.map[item.productType],
                        styleType: item.styleType,
                        productId: item.productId,
                        productName: item.productName || "产品名称",
                        indicatorKeys: item.indicatorKeys || [],
                        tags: item.tags && item.tags.length ? item.tags : ["标签"],
                        recommendation: item.recommendation || "推荐语",
                        compKey: item.compKey,
                        description: item.description,
                        jumpType: item.jumpType,
                        selfAdd: item.selfAdd
                    }
                }) : []
            }
        }
    },
    data(){
        return {
            // moduleData: {
            //     name: "product",
            //     mainTitle: "",
            //     subTitle: "",
            //     funds: [
            //         {
            //             productType: "1",
            //             productId: "HF00000BDJ",
            //             styleType: "peFund2",
            //             indicatorKeys: [2,3],
            //             tags: ["标签"],
            //         },
            //         {
            //             productType: "2",
            //             productId: "HF00000BDJ",
            //             styleType: "peFund2",
            //             indicatorKeys: [2,3],
            //             tags: ["标签"],
            //         },
            //         {
            //             productType: "2",
            //             productId: "HF00000BDJ",
            //             styleType: "peFund1",
            //             indicatorKeys: [2,3],
            //             tags: ["标签"],
            //         },
            //         {
            //             productType: "3",
            //             productId: "401",
            //             tags: ["标签"],
            //         },
            //         {
            //             productType: "4",
            //             productId: "HF00000GE1",
            //             tags: ["标签"],
            //         },
            //     ]
            // },
            map: {
                1: "common",
                2: "navProduct",
                3: "fixYield",
                4: "equity",
            }
        }
    },
    methods: {
        
    },
    watch: {
        moduleData: {
            handler(val){
            },
            deep: true,
            immediate: true
        }
    }
}
</script>
<style lang="less" scoped>
    .direct-sale-module{
        min-height: 80px;
    }
</style>

