
<template>
  <div class="config-wrapper">
    <h2 class="config-title">
      {{configTitle}}
      <span class="config-tip">(提示：仅1个)</span>
    </h2>

    <div class="config-content-area">
      <el-form
        ref="form"
        :rules="validateRules"
        :model="formData"
        label-width="75px"
        label-position="left"
      >
        <div class="form-content-area">
          <el-form-item label="主标题:" prop="mainTitle">
            <el-input v-model.trim="formData.mainTitle" placeholder="请输入主标题，最多仅展示一行"/>
          </el-form-item>

          <el-form-item label="副标题:" prop="subTitle">
            <el-input v-model.trim="formData.subTitle" placeholder="请输入副标题，最多仅展示一行"/>
          </el-form-item>
        </div>

        <el-form
          class="form-content-area"
          ref="fund"
          :rules="validateRules"
          :model="formData.funds[0]"
          label-width="75px"
          label-position="left"
        >
          <el-form-item label="产品名称:" prop="productId">
            <vselectRemote
              allowCreate
              defaultFirstOption
              index="0"
              @onChange="setCurrentProductName"
              :customerRemoteMethod="searchProduct"
              style="width:100%;"
              v-model="formData.funds[0].productId"
              searchKey="short_name"
              labelKey="short_name"
              alternativeLabelKey="name"
              valueKey="data_id"
              :defaultLabel="formData.funds[0].productName"
              placeholder="请输入关键词"
            ></vselectRemote>
          </el-form-item>

          <el-form-item label="描述" prop="description">
            <el-input
              placeholder="请输入产品描述，字数不限"
              v-model="formData.funds[0].description"
              type="textarea"
              :autosize="{minRows:3,maxRows:5}"
            />
          </el-form-item>

          <el-form-item label="跳转：" prop="jumpType">
            <el-select v-model="formData.funds[0]['jumpType']" style="width:100%;">
              <el-option value="1" label="外链"></el-option>
              <el-option value="2" label="PDF"></el-option>
              <!-- <el-option value="3" label="默认详情页" v-if="configData.name == 'newProduct'"></el-option> -->
              <el-option value="3" label="默认详情页" v-if="formData.funds[0].selfAdd ===false"></el-option>
              <el-option value="5" label="无跳转"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item
            label="外链："
            prop="link"
            v-if="formData.funds[0]['jumpType']=='1'"
            key="link"
          >
            <el-input v-model.trim="formData.funds[0]['link']" placeholder="请输入链接"/>
          </el-form-item>

          <el-form-item
            v-if="formData.funds[0]['jumpType']=='2'"
            label="文件："
            prop="fileData"
            key="fileData"
          >
            <vfileUpload
              v-model="formData.funds[0].fileData"
              @getFileData="getFileData(0)"
              url="file/visitingCard"
              fileName="directSalePdf"
              class="custom-file-uploader"
              resName="fileName"
              :foreignPath="true"
              :emptyFileObj="{
                filePath: '',
                fileName: ''
              }"
            />
          </el-form-item>
        </el-form>
      </el-form>
    </div>
  </div>
</template>

<script>
import { isEqual } from "lodash";
import { ajax } from "jquery";
import commonMethods from "../mixins/common-methods";
export default {
  props: {
    configTitle: {
      type: String,
      default: ""
    },

    configData: {
      type: [Object, Array],
      default: () => ({})
    }
  },

  mixins: [commonMethods],

  beforeDestroy() {
    this.validate();
  },

  data() {
    const validateFileData = (rules, value, cb) => {
      let errors = [];
      if (!value.filePath) {
        errors.push(new Error("文件不能为空！"));
      }

      cb(errors);
    };
    return {
      formData: { funds: [] },
      validateRules: {
        description: {
          required: true,
          message: "描述不能为空"
        },

        fileData: [
          {
            required: true,
            message: "文件不能为空"
          },
          { validator: validateFileData }
        ],

        link: {
          required: true,
          message: "链接不能为空"
        }

        // productId: {
        //   required: true,
        //   message: "产品名称不能为空"
        // }
      }
    };
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  // computed: {
  //   validateRules() {

  //     let data =

  //     if (this.configData.name == "newProduct") {
  //       return data;
  //     } else {
  //       delete data.productId;
  //       return data;
  //     }
  //   }
  // },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },

      deep: true
    },

    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }
        let data = JSON.parse(JSON.stringify(val));
        if (data.name == "newProduct") {
          data.funds =
            data.funds && data.funds.length
              ? this.transferData(data.funds, "file")
              : [{ jumpType: "5" }];
        } else {
          data.funds =
            data.funds && data.funds.length
              ? this.transferData(data.funds, "file")
              : [{ jumpType: "5" }];
        }
        this.formData = JSON.parse(JSON.stringify(data));
      },

      deep: true,

      immediate: true
    }
  },

  methods: {
    getFileData(index) {
      this.formData.funds[index].file = this.formData.funds[
        index
      ].fileData.filePath;
      this.formData.funds[index].fileName = this.formData.funds[index].file
        ? this.formData.funds[index].fileData.fileName
        : "";
      this.$refs.fund.validateField("fileData");
    },

    setCurrentProductName(name, index) {
      if (!!!name) {
        this.$set(this.formData.funds[index], "jumpType", "5");
      }
      this.$set(this.formData.funds[index], "selfAdd", !!!name);
      if (!!!name && !!!this.formData.funds[index].productId) {
        this.$set(this.formData.funds[index], "selfAdd", "");
      }
      this.$set(this.formData.funds[index], "productName", name);
    },

    searchProduct(query) {
      let params = {
        m: "Search",
        c: "search",
        a: "quickSearch",
        count: 100,
        search_type: "fund",
        skeyword: query
      };

      return new Promise((resolve, reject) => {
        ajax({
          url: "https://serve.simuwang.com/index.php",
          type: "GET",
          dataType: "jsonp",
          data: params,
          success: data => {
            resolve(data);
          },

          error: e => {
            resolve([]);
          }
        });
      });
    },

    validate() {
      let finalValid = true;

      this.$refs.form.validate(valid => {
        finalValid = finalValid && valid;
        this.$refs.fund.validate(fvalid => {
          finalValid = finalValid && fvalid;
        });
      });
      this.$set(this.formData, "validate", finalValid);
      let data = JSON.parse(JSON.stringify(this.formData));
      data.funds = this.deleteUselessKeys(data.funds);
      this.$emit("getFormData", data, true);
    },

    resetValid() {
      this.$refs.form.clearValidate();
      this.$refs.fund.clearValidate();
    }
  }
};
</script>

<style lang="less" >
.el-textarea {
  textarea {
    background: transparent !important;
    border-color: #444 !important;
    &:hover {
      border-color: #89a !important;
    }
    &:focus {
      border-color: #1073c5 !important;
    }
  }
}

.is-error {
  .el-textarea textarea,
  .el-select .el-input .el-input__inner {
    border-color: #f56c6c !important;
  }
}

.custom-file-uploader.file-upload-container {
  margin-top: 8px;
}

.config-wrapper {
  .config-title {
    // margin-bottom: 8px;
  }

  .config-tip {
    font-size: 12px;
    font-weight: 300;
    color: #999;
  }

  .action-btn {
    color: #1073c5;
    cursor: pointer;
  }
}
</style>

