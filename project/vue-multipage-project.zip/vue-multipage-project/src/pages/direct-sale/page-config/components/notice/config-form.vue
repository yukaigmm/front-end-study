<template>
  <div class="notice-wrapper">
    <h2 class="config-title">公告模块</h2>
    <div class="config-content-area">
      <el-form
        class="form-content-area"
        ref="form"
        :rules="validateRules"
        :model="formData"
        label-width="75px"
        label-position="left"
      >
        <el-form-item label="公告：" prop="content">
          <el-input type="textarea" placeholder="请输入公告内容" v-model="formData.content" :autosize="{minRows:3,maxRows:5}"/>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>



<script>
import { isEqual } from "lodash";
export default {
  props: {
    configData: {
      type: [Object, Array],
      default: () => ({
        name: "notice",
        content: ""
      })
    }
  },

  data() {
    return {
      validateRules: {
        content: {
          required: true,
          message: "公告内容不能为空"
        }
      },
      formData: {
        name: "notice",
        content: ""
      }
    };
  },

  beforeDestroy() {
    this.validate();
  },

  mounted() {
    if (this.configData.validate === false) {
      this.validate();
    }
  },

  watch: {
    formData: {
      handler(val) {
        this.$emit("getFormData", val);
      },
      deep: true
    },

    configData: {
      handler(val, preVal) {
        if (isEqual(val, preVal)) {
          return;
        }
        this.formData = JSON.parse(JSON.stringify(val));
      },

      deep: true,

      immediate: true
    }
  },

  methods: {
    validate() {
      let finalValid;
      this.$refs.form.validate(valid => {
        finalValid = valid;
      });

      this.$set(this.formData, "validate", finalValid);
      this.$emit("getFormData", this.formData, true);
    },

    resetValid() {
      this.$refs.form.clearValidate();
    }
  }
};
</script>


<style lang="less" scoped>
</style>
