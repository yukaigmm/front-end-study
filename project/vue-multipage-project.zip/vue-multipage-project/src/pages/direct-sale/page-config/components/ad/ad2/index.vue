<template>
    <div class="ad2 direct-sale-module">
            <div 
            class="ad2-item"
            v-for="(item, index) in adConfig"
            :key="index"
            :style="{
                background: item.pic ? `url(${item.pic}) no-repeat` :'',
            }"
            :class="{default: !item.pic}"
            >{{item.pic ? "": "广告图片"}}</div>
    </div>
</template>

<script>
export default {
    props: {
        moduleData: {
            type: Object,
            default: {}
        }
    },
    computed: {
    },
    data(){
        return {
            adConfig: [1,2],
        }
    },
    methods: {
        getAdConfig(){
            let adConfig = this.moduleData.pics || [1,2];
            this.adConfig = adConfig.map((item) => {
                return Object.assign({}, item, {pic: item.pic ? `${this.$baseUrl[process.env.NODE_ENV]['staticFile']}/${item.pic}`:""})
            })
        }
    },
    watch: {
        moduleData: {
            handler(val){
                this.getAdConfig();
            },
            deep: true
        }
    },
    mounted() {
        this.getAdConfig();
    },
}
</script>
<style lang="less" scoped>
    .ad2{
        height: 138px;
        .ad2-item{
            height: 100%;
            width: 148.73px;
            float: left;
            background-size: contain !important;
            background-position: center !important;
            &:nth-child(2){
                // margin-right: 13.6px;
                float:right;
            }
            &.default{
                background: #e3e1e1 !important;
                text-align: center;
                line-height: 138px;
                color: #9b9b9b;
            }
        }
    }
</style>