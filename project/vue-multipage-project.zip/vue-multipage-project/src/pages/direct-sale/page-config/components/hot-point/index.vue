<template>
    <div class="hot-point direct-sale-module">
        <div 
        v-for="item in dataConfig"
        :key="item.compKey"
        class="hot-ponit-item"
        >
            <div 
            class="hot-item"
            v-for="si in item.spotItems"
            :key="si.compKey"
            >
                <div class="img-container">
                    <img v-if="si.icon" :src="si.icon" alt="">
                    <div v-else class="img-placeholder">icon</div>
                </div>
                <span>{{si.title}}</span>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        moduleData: {
            type: Object,
            default: {
                spots: [
                    {spotItems: [1,2,3,4]}
                ]
            }
        }
    },
    data(){
        return {}
    },
    computed: {
        dataConfig(){
            let data = this.moduleData.spots || [{spotItems: [1,2]}];
            return data.map((item) => {
                let spotItems = item.spotItems.map((si) => {
                    return {
                        title: si.title  || "子热点",
                        icon: si.icon ? `${this.$baseUrl[process.env.NODE_ENV]["staticFile"]}/${si.icon}`: ''
                    }
                });
                return Object.assign({}, item, {spotItems});
            })
        }
    },
    watch: {
        moduleData: {
            handler(val){},
            deep: true,
        }
    },
}
</script>
<style lang="less" scoped>
    .hot-ponit-item{
        height: 88px;
        display: flex;
        justify-content: center;
        align-items: center;
        .hot-item{
            display: inline-block;
            width: 76.83px;
            height: 67.77px;
            text-align: center;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: 13.36px;
            .img-container{
                display: block;
                margin: 0 auto 8.91px;
                width: 41.86px;
                height: 41.86px;
                text-align: center;
                line-height: 41.86px;
            }
            img,.img-placeholder{
                max-width: 100%;
                max-height: 100%;
            }
            .img-placeholder{
                background-color: #e3e1e1;
                width: 100%;
                height: 100%;
                color: #9b9b9b;
            }
        }
    }
</style>