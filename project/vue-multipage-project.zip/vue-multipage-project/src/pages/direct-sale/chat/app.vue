<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey" class="direct-sale-chat">
    <vpart title="聊天" style="height: 100%">
      <div id="chat"></div>
    </vpart>
  </vcommon>
</template>

<script>
export default {
  data() {
    return {
      currentMenuParentKey: "directSale",
      currentMenuChildKey: "chat"
    }
  },
  methods: {
    // 初始化聊天组件
    initPPWChat() {
      let env = process.env.NODE_ENV;
      var container = document.getElementById("chat");
      let _this = this;
      window["ppw-chat"].bindTo(
        container,
        function(vueInst, error) {
          vueInst.$on("statechange", function(state, data) {
            if ("login" == state) {
              //组件触发登录成功事件，在这之后才可以调用vueInst的方法

            }
            if ("minimize" == state) {
              //组件触发最小化的事件，此处调用者自行处理组件是否隐藏
            }
            if("logout" == state){
              // 组件在使用过程中被官网踢出登录，就调用重新登录的接口
              _this.reLogin();
            }
          });
          //vueInst是vue组件的实例，调用者需要保存它的一个引用，以方便调用实例的方法
          window.chatComp = vueInst;
        },
        {
          getEnv: () => {
            // let chatEnv = env === "production" ? "" : "test";
            let chatEnv = "test";
            switch (env) {
              case "pre":
                chatEnv = "pre";
                break;
              case "production":
                chatEnv = "";
                break;
              case "development":
              case "test":
                chatEnv = "test";
                break;
            }
            return chatEnv;
		  },
		  system: "fm"
        }
      );
    },
    // 导入聊天组件依赖资源
    importAlias(){
      let aliasArr = [
        "sdk/webim.js",
        "sdk/json2.js",
        "sdk/lib/md5/spark-md5.js",
        "dist/index.js",
        "dist/index.css"
      ];
      return Promise.all(aliasArr.map((item) => {
        return this.importSingleAlia(item);
      }))
    },
    // 导入单个资源
    importSingleAlia(item){
      return new Promise((resolve) => {
        if(item.indexOf(".js") !== -1){
          let el = document.createElement("script");
          el.type = "text/javascript";
          el.src =  `${this.$baseUrl[process.env.NODE_ENV]["page"]}/assets/lib/chat/${item}`;
          document.querySelector("body").appendChild(el);
          el.onload = () => {
            resolve();
          }
        }else if (item.indexOf(".css") !== -1){
          let el = document.createElement("link");
          el.type = "text/css";
          el.rel = "stylesheet";
          el.href =  `${this.$baseUrl[process.env.NODE_ENV]["page"]}/assets/lib/chat/${item}`;
          document.querySelector("head").appendChild(el);
          el.onload = () => {
            resolve();
          }
        }
      })
    },
    // 基金大师重新登录接口，解决在聊天组件掉线之后用户需要重新登录才能使用的问题
    reLogin(){
      return new Promise((resolve, reject) => {
        this.$http.get("user/reLogin").then((res) => {
          if(res && res.code === 20000){
            resolve()
          }else{
            location.assign(
              this.$baseUrl[process.env.NODE_ENV]["page"] + "/login/index.html"
            );
          }
        })
      })
    },
    checkUserOfficialStatus(){
      return new Promise((resolve, reject) => {
          $.ajax({
              type: "GET",
              url: `${this.$baseUrl[process.env.NODE_ENV]["officialMobile"]}/member/getUserInfoApi`,
              xhrFields: {
                withCredentials: true
              },
              crossDomain: true,
              success: (resp) => {
                  let res = resp instanceof Object ? resp : JSON.parse(resp);
                  resolve(res);
              },
              error: () => {
                resolve({})
              }
          })
      });
    }
  },
  mounted() {
    // this.reLogin().then(() => {
    //   this.initPPWChat();
    // })
  },
  beforeCreate() {
	  window["PPW_CHAT_COMP_PATH"] = `${this.$baseUrl[process.env.NODE_ENV]["page"]}/assets/lib/chat/dist`;
  },
  created() {
    let reloginAble = window.sessionStorage.getItem("reloginAble");
    // 导入所有资源，资源加载完成之后再初始化组件
	  this.importAlias().then(() => {
      this.checkUserOfficialStatus().then((res) => {
        if(res.status == 1){
          this.initPPWChat();
        }else{
          if(reloginAble === "false"){
            this.initPPWChat();
          }else{
              this.reLogin().then(() => {
                  this.initPPWChat();
              })
          }
        }
      })
    });
  },
};
</script>
<style lang="less">
  .direct-sale-chat{
    .part-content{
      overflow-y: auto;
      color: #000;
      #chat{
        width: 100%; 
        height: 100%;
        min-height: 630px;
        img{
            // height: 16px !important;
            // width: auto;
            box-sizing: content-box !important;
          }
        .ppw-chat-input-box{
          img{
            // height: 16px !important;
            // width: auto;
            box-sizing: content-box !important;
          }
          #send-content{
            // padding-left: 8px;
          }
        }
      }
    }
  }
</style>