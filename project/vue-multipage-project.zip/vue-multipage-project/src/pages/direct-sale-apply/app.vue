<template>
  <div class="apply-container" ref="applyContainer">
    <div class="info">
      <img src="../../assets/images/apply/apply-logo.png" class="logo" alt>
      <span class="intro">私募直营店</span>
    </div>
    <div class="form">
      <div class="title">
        <span class="title-text">试用申请</span>
      </div>
      <div class="form-content" v-if="!applySuccess">
        <div class="form-row">
          <div class="input-row">
            <span class="row-label required">
              <span>用户姓名</span>
            </span>
            <div class="row-input-container">
              <i class="row-icon user"></i>
              <input type="text" class="row-input" placeholder="请输入用户姓名" v-model="form.realName">
            </div>
          </div>
        </div>

        <div class="form-row">
          <div class="input-row">
            <span class="row-label required">
              <span>联系电话</span>
            </span>
            <div class="row-input-container">
              <i class="row-icon tel"></i>
              <input type="number" class="row-input" placeholder="请输入联系电话" v-model="form.mobile">
            </div>
          </div>
        </div>

        <div class="form-row">
          <div class="input-row card-row">
            <span class="row-label required">
              <span>个人名片</span>
            </span>
            <div class="row-input-container">
              <i class="row-icon business-card"></i>
              <!-- <div class="row-input" ref="cardUploadDiv" style="color: #bababa" @click="uploadBusinessCard">请点此上传文件</div> -->
              <input
                type="text"
                readonly
                class="row-input"
                :placeholder="fileInputPlaceholder"
                @click="uploadBusinessCard"
              >
            </div>
            <div class="upload-btn" @click="uploadBusinessCard">{{uploadBtnText}}</div>
          </div>
        </div>

        <div class="form-row" style="margin-top: 0.6rem">
          <div class="submit-button" @click="applySubmit">{{submitLoading ? '申请中...' : '申请' }}</div>
        </div>

        <form ref="uploadFileForm" style="display: none">
          <input
            type="file"
            accept="image/*"
            name="visitingCard"
            ref="uploadFileInput"
            @change="uploadFileInputChange"
          >
        </form>
      </div>

      <div class="success-tip" v-else>
        <img src="../../assets/images/apply/success.png" alt class="success-img">
        <span class="success-text">申请成功</span>
        <span class="success-desc">后续将有排排网的工作人员与您取得联系开通试用</span>
      </div>
    </div>
    <div class="contact">
      <div class="contact-content-container">
        <span class="label">联系电话：</span>
        <div class="content">
          <span v-for="(person, index) in contact.cell" :key="index" style="display: block;">
            <span>{{person.name}}</span>
            <a :href="`tel:${person.cell}`">{{person.cell}}</a>
          </span>
        </div>
      </div>
      <div class="contact-content-container">
        <span class="label">联系邮箱：</span>
        <div class="content">
          <a
            v-for="(email, index) in contact.email"
            :key="index"
            :href="`mailto:${email}`"
          >{{email}}</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {getUrlParams} from "../../common/js/utils.js"
export default {
  data() {
    return {
      form: {
        realName: "",
        mobile: "",
        visitingCard: ""
      },
      uploadFileLoading: false,
      submitLoading: false,
      applySuccess: false,
      contact: {
        // cell: ['18038092195', '18122062901'],
        cell: [
          {
            name: "郭先生",
            cell: "18038092195"
          },
          {
            name: "刘先生",
            cell: "18122062901"
          }
        ],
        email: ["fm@simuwang.com"]
      }
    };
  },
  computed: {
    fileInputPlaceholder() {
      return this.uploadFileLoading
        ? "上传中..."
        : this.form.visitingCard
        ? "上传成功"
        : "请上传个人名片";
    },
    uploadBtnText() {
      return this.form.visitingCard ? "更换" : "上传";
    }
  },
  methods: {
    uploadFileInputChange(e) {
      let files = event.target.files || window.event.target;
      let file = files[0] || {};

      let form = this.$refs.uploadFileForm;
      let formData = new FormData(form);
      this.uploadFileLoading = true;
      this.$http.post("file/visitingCard", formData).then(res => {
        this.uploadFileLoading = false;
        if (res.code === 20000) {
          this.$message.success("上传成功");
          this.form.visitingCard = res.data.filePath;
          this.$refs.uploadFileInput.value = "";
        } else {
          this.$message.error(`上传失败：${res.data.errorMsg}`);
        }
      });
    },
    uploadBusinessCard() {
      //如果不处于上传中状态，则进行文件上传
      if (!this.uploadFileLoading) {
        this.$refs.uploadFileInput.click();
      }
    },
    applySubmit() {
      let params = getUrlParams();
      let form = JSON.parse(JSON.stringify(this.form));

      //私募直营店 类型字段 2
      form.application = 2;
      form.source = params.source || 1;

      //手机号正则
      let mobileReg = /^(0?(13[0-9]|15[012356789]|17[013678]|18[0-9]|14[579]|19[89])[0-9]{8}$)|((400|800)([0-9\\-]{7,10})|((((((^010)|^02[012345789]{1}))(-| )?)([0-9]){8}$)|((((^0[3456789]{1})[0-9]{2})(-| )?)([0-9]{7,8}$)))((-| |转)*([0-9]{1,4}))?)$/;

      if (!this.submitLoading) {
        if (!form.realName) {
          this.$message.error("请输入用户姓名");
          return false;
        }
        if (!form.mobile) {
          this.$message.error("请输入联系电话");
          return false;
        }

        if (form.mobile && !mobileReg.test(form.mobile)) {
          this.$message.error("联系电话格式不正确");
          return false;
        }
        if (!form.visitingCard) {
          this.$message.error("请上传名片");
          return false;
        }
        this.submitLoading = true;
        this.$http.post("user/probation", form).then(res => {
          this.submitLoading = false;
          if (res.code === 20000) {
            // this.$message.success('申请成功');
            this.applySuccess = true;
          } else {
            this.$message.error(`申请失败：${res.data.errorMsg}`);
          }
        });
      }
    },
    setResizeListener() {
      let height = $(this.$refs.applyContainer).height();
      window.addEventListener("resize", () => {
        $(this.$refs.applyContainer).height(height);
      });
    }
  },
  mounted() {
    this.setResizeListener();
  }
};
</script>

<style lang="less" scoped>
.apply-container {
  width: 100%;
  // height: 100%;
  height: auto;
  overflow: hidden;
  // background-color: #1a1a1a;
  background-image: url("../../assets/images/direct-sale-apply/bg.jpg");
  // background-size: 100% auto;
  background-size: 100% 100%;
  background-repeat: no-repeat;
  position: relative;
  color: #fff;
  .info {
    text-align: center;
    overflow: hidden;
    margin-bottom: 0.54rem;
    .logo {
      width: 2.03rem;
      height: 2.09rem;
      margin-top: 0.6rem;
      margin-bottom: 0.6rem;
    }
    .intro {
      display: block;
      text-align: center;
      font-size: 0.54rem;
      color: #c31111;
      font-weight: bold;
    }
  }
  .form {
    width: 9.06rem;
    height: 6.74rem;
    margin: 7rem auto 0;
    font-size: 0;
    background-color: rgba(255, 255, 255, 0.18);
    overflow: hidden;
    position: relative;
    border-radius: 0.03rem;
    .title {
      display: block;
      text-align: center;
      font-size: 0.54rem;
      color: #fff;
      margin-top: 0.8rem;
      .title-text {
        display: inline-block;
        position: relative;
        &:before,
        &:after {
          content: "";
          display: block;
          width: 0.62rem;
          height: 0.02rem;
          background-color: rgba(226, 226, 226, 0.5);
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
        }
        &:before {
          left: -0.84rem;
        }
        &:after {
          right: -0.84rem;
        }
      }
    }
    .form-content {
      font-size: 0.4rem;
      margin-top: 0.76rem;
      .form-row {
        width: 100%;
        height: 0.6rem;
        line-height: 0.6rem;
        padding: 0 0.43rem;
        margin: 0 auto 0.5rem;
        .input-row {
          text-align: left;
          width: 100%;
          height: 100%;
          padding-left: 2.18rem;
          position: relative;
          font-size: 0;
          .row-label {
            width: 1.9rem;
            display: block;
            position: absolute;
            left: 0;
            text-align: right;
            color: #fff;
            font-size: 0.4rem;
            & > span {
              position: relative;
            }
            &.required > span:after {
              content: "*";
              color: red;
              font-size: 0.4rem;
              position: absolute;
              left: -0.3rem;
              top: 50%;
              transform: translateY(-50%);
            }
          }
          .row-input-container {
            display: block;
            width: 100%;
            height: 100%;
            position: relative;
            padding-left: 1.14rem;
            padding-right: 0.2rem;
            background-color: #fff;
            border-radius: 0.05rem;
            .row-icon {
              width: 0.34rem;
              height: 0.37rem;
              position: absolute;
              display: block;
              top: 50%;
              left: 0.3rem;
              transform: translateY(-50%);
              background-repeat: no-repeat;
              background-position: center center;
              &:after {
                content: "";
                display: block;
                position: absolute;
                top: 50%;
                right: -0.3rem;
                transform: translateY(-50%);
                height: 0.27rem;
                border-right: 0.03rem solid #bababa;
              }
              &.user {
                background-image: url("../../assets/images/apply/user.png");
                background-size: 100% auto;
              }
              &.tel {
                background-image: url("../../assets/images/apply/tel.png");
                background-size: 100% auto;
              }
              &.business-card {
                background-image: url("../../assets/images/apply/card.png");
                background-size: 100% auto;
              }
            }
            .row-input {
              width: 100%;
              height: 0.6rem !important;
              line-height: 1 !important;
              border: none !important;
              font-size: 0.3rem !important;
              float: left;
              color: #828282 !important;
            }
          }
          &.card-row {
            padding-right: 2.24rem;
            .row-input-container {
              width: auto;
            }
            .upload-btn {
              width: 2rem;
              height: 0.6rem;
              color: #fff;
              background-color: #0e60cb;
              border-radius: 0.05rem;
              font-size: 0.32rem;
              text-align: center;
              position: absolute;
              right: 0;
              top: 0;
            }
          }
        }
      }
      .submit-button {
        width: 100%;
        height: 0.8rem;
        line-height: 0.8rem;
        font-size: 0.4rem;
        text-align: center;
        box-shadow: none;
        border-radius: 0.05rem !important;
        background-color: #dd2222;
        color: #fff;
      }
    }

    .success-tip {
      text-align: center;
      margin-top: 1rem;
      padding-bottom: 0.5rem;
      .success-img {
        width: 1.84rem;
        height: 1.84rem;
      }
      .success-text {
        display: block;
        color: #fff;
        font-size: 0.4rem;
        margin: 0.3rem auto;
        text-align: center;
      }
      .success-desc {
        display: block;
        width: 100%;
        height: 1.21rem;
        line-height: 1.21rem;
        position: absolute;
        bottom: 0;
        font-size: 0.32rem;
        color: #fff;
        background-color: #dd2222;
        text-align: center;
        border-bottom-left-radius: 0.03rem;
        border-bottom-right-radius: 0.03rem;
      }
    }
  }
  .contact {
    font-size: 0.36rem;
    text-align: center;
    // position: absolute;
    // margin-top: 1.1rem;
    // margin-bottom: 0.7rem;
    color: #8d9095;
    display: block;
    margin: 1.1rem auto 0.7rem;
    .contact-content-container {
      display: flex;
      justify-content: center;
      line-height: 0.7rem;

      .label {
        float: left;
      }
      .content {
        float: left;
        a {
          margin-right: 0.1rem;
          color: #0e60cb;
        }
      }
      &:after {
        content: "";
        display: block;
        clear: both;
      }
    }
  }
}
</style>



