
<template>
  <vmodal ref="modal" class="account-modal t2-el-dialog" :width="600" title="账号信息" @close="cancel">
    <!-- <div class="account-form-container"> -->
      <vformConfig ref="form" :config="formConfig" v-model="form"></vformConfig>
      <div class="user-list-icon" @click.stop="showPersonListSelect" :style="userIconPosition">
        <div class="user-select-container" v-show="showPersonList">
          <ul class="user-select">
            <li v-for="(item,index) in personList" :key="index" @click.stop="selectPerson(item)">{{item.personnelName}}</li>
          </ul>
        </div>
      </div>
      <div class="pwd-eye-icon" @click.stop="togglePwdShow" :class="{'pwd-hide': !pwdShow, 'disabled': !canEditPass}" :style="eyeIconPosition"></div>
    <!-- </div> -->
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="submit">提交</vbutton>
    </div>
    <vloading slot="loading" v-model="loading"></vloading>
  </vmodal>
</template>



<script>
// import service from "../service.js";
import { validatePhoneNumber } from "../../../common/js/validator.js";

export default {
  data() {
    return {
      // 1-都有 2-官网有 3-申报有 4-都没有
      accStatus: 1,
      loading: false,
      initForm: {
        realName: '',
        mobile: '',
        initPsw: '',
        userPermission: 1,
        isAdmin: 0,
      },
      form: {
        realName: '',
        mobile: '',
        initPsw: '',
        userPermission: 1,
        isAdmin: 0,
      },
      userIconPosition: {},
      showPersonList: false,
      canEditPass: true,
      pwdShow: true,
    }
  },
  computed: {
    formConfig () {
      return {
        cols:12,
        fields:[
          [
            {
              label: "姓名",
              labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "realName",
                  compType: "vinput",
                  compConfig: {
                    placeholder: '请输入姓名或从右侧选择人物'
                  },
                  rules: [
                    { required: true, type: 'string', message: '必填' },
                  ],
                }
              ]
            }
          ],
          [
            {
              label: "手机号",
              labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "mobile",
                  compType: "vinput",
                  compConfig: {
                    placeholder: '请输入手机号'
                  },
                  rules: [
                    { required: true, type: 'string', message: '必填' },
                    validatePhoneNumber()
                  ],
                }
              ]
            }
          ],
          [
            {
              label: "密码",
              labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "initPsw",
                  compType: "vinput",
                  compConfig: {
                    placeholder: this.canEditPass ? '密码需在6~16位之间' : '账号已在官网注册，请使用官网密码登陆',
                    disabled: !this.canEditPass,
                    inputType: this.pwdShow ? 'text' : 'password'
                  },
                  rules: this.canEditPass ? [
                    {required: true, type: 'string', message: '必填' },
                    {type: 'string', min: 6, max: 16, message: '密码长度需在6-16位之间'}
                  ] : [],
                }
              ]
            }
          ],
          [
            {
              label: "账号权限",
              labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "userPermission",
                  compType: "vselect",
                  compConfig: {
                    options: [
                      {
                        label: '可读写',
                        value: 1,
                      },
                      {
                        label: '只读',
                        value: 2,
                      }
                    ]
                  },
                }
              ]
            }
          ],
          [
            {
              label: "管理员",
              labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "isAdmin",
                  compType: "vswitch",
                  compConfig: {
                    type: 'checkbox',
                    trueValue: 1,
                    falseValue: 0,
                    trueLabel: '',
                  },
                }
              ]
            }
          ],
        ]
      }
    }
  },
  // 监听页面点击关闭下拉
  // 设置默认用户数据
  // 初始化用户选择列表
  //
  mounted() {
    this.getPersonList();
		document.addEventListener('click', () => {
			this.showPersonList = false;
		});
  },

  methods: {
    show () {
      this.open();
      this.setIconPosition();
    },
    hide () {
      this.close();
    },
    open() {
      this.$refs.modal.open();
    },
    close() {
      this.$refs.modal.close();
    },
    reset () {
      this.form = JSON.parse(JSON.stringify(this.initForm));
      this.$refs.form.resetValid();
    },
    cancel () {
      this.hide();
      this.reset();
    },
    submit () {
      this.$refs.form.valid().then( (valid) => {
        if (valid) {
          this.loading = true;
          this.$http.post('user/account', this.form).then( (res) => {
            this.loading = false;
            if (res.code === 20000) {
              this.$message.success('添加成功');
              this.$emit('success');
              this.cancel();
            } else {
              this.$message.error(res.msg);
            }
          }, (error) => {
            this.loading = false;
          })
          
        } else {
          this.$message.error('请按提示补充或修改信息');
        }
      })
    },
    // 获取主讲人列表
		getPersonList() {
			this.$http.post('datadis/company/getSelfPersonnel').then(res => {
				if (res.code !== 20000) {
          this.personList = [];
					this.$message({
						showClose: true,
						message: res.msg,
						type: 'error',
					});
					return;
				}
				this.personList = JSON.parse(JSON.stringify(res.data));
			});
    },
    showPersonListSelect() {
			this.showPersonList = true;
    },
    togglePwdShow () {
      this.pwdShow = !this.pwdShow;
    },
    selectPerson (person) {
      this.form.realName = person.personnelName;
      this.form.mobile = person.mobile;

      this.$nextTick(()=>{
        $('div[item-key="realName"] input').trigger('focus').trigger('blur');
        this.showPersonList = false;
      })
    },
    //设置选择人物图标的位置
		setIconPosition(){
			setTimeout(() => {
				let userOffsetLeft = document.querySelector('div[item-key="realName"]').offsetLeft;
				let userOffsetTop = document.querySelector('div[item-key="realName"]').offsetTop;
        let userItemLength = document.querySelector('div[item-key="realName"]').offsetWidth;
        
				this.userIconPosition = {
					left: userOffsetLeft + userItemLength - 31 + 'px',
					top: userOffsetTop + 1 +  'px'
        }

        let eyeOffsetLeft = document.querySelector('div[item-key="initPsw"]').offsetLeft;
				let eyeOffsetTop = document.querySelector('div[item-key="initPsw"]').offsetTop;
				let eyeItemLength = document.querySelector('div[item-key="initPsw"]').offsetWidth;
				this.eyeIconPosition = {
					left: eyeOffsetLeft + eyeItemLength - 31 + 'px',
					top: eyeOffsetTop + 1 +  'px'
        }

        

			}, 100);
    }
    
  },
  watch: {
    'form.mobile': {
      handler (val) {
        //如果手机号符合格式，再进行用户验证
        let phoneReg = /^(0?(13[0-9]|15[012356789]|17[013678]|18[0-9]|14[579]|19[89])[0-9]{8}$)|((400|800)([0-9\\-]{7,10})|((((((^010)|^02[012345789]{1}))(-| )?)([0-9]){8}$)|((((^0[3456789]{1})[0-9]{2})(-| )?)([0-9]{7,8}$)))((-| |转)*([0-9]{1,4}))?)$/;

        if (val && phoneReg.test(val)) {
          this.$http.get('user/account/checkAccStatus', { mobile: val}).then( (res) => {
            if (res.code === 20000) {
              let accStatus = res.data.userStatus;
              this.canEditPass = accStatus > 2;
            }
          })
        } else {
          this.canEditPass = true;
        }
      },
      deep: true,
    },
    canEditPass: {
      handler (val) {
        if (!val) {
          this.form.initPsw = '';
          this.$refs.form.resetValid('initPsw');
        }
      },
      deep: true
    }
  }
};
</script>


<style lang="less">
  .account-modal {
    .account-form-container {
      position: relative;
    }
    .el-dialog__body {
      overflow: visible;
    }
    .user-list-icon {
      width: 30px;
      height: 24px;
      background: url('../../../assets/images/users.svg') no-repeat center right;
      cursor: pointer;
      position: absolute;
      top: 0;
      left: 0;
      z-index: 999;
      // right: 12px;
      background-color: #1a1a1a;
      .user-select-container {
        position: absolute;
        z-index: 999;
        &:before {
          content: '';
          position: absolute;
          top: 32px;
          right: -20px;
          width: 0px;
          height: 0px;
          border: 8px solid #202020;
          border-right-color: transparent;
          border-bottom-color: transparent;
          transform: rotate(45deg);
        }
      }
      // 主讲人列表
      ul.user-select {
        width: 140px;
        max-height: 240px;
        margin: 0;
        overflow: auto;
        background-color: #202020;
        position: absolute;
        left: -100px;
        top: 40px;
        // 此处设置z-index 999 ,编译出来之后是1，因此样式在common.less中设置了
        // z-index: 999 !important;
        box-shadow: 0 0 10px #666;
        li {
          height: 34px;
          line-height: 34px;
          // border-bottom: 1px solid #444;
          color: #eee;
          text-align: center;
          &:hover {
            background: #333;
          }
        }
      }
      ul.user-select {
        width: 140px;
        max-height: 240px;
        margin: 0;
        overflow: auto;
        background-color: #202020;
        position: absolute;
        left: -100px;
        top: 40px;
        // 此处设置z-index 999 ,编译出来之后是1，因此样式在common.less中设置了
        // z-index: 999 !important;
        box-shadow: 0 0 10px #666;
        li {
          height: 34px;
          line-height: 34px;
          // border-bottom: 1px solid #444;
          color: #eee;
          text-align: center;
          &:hover {
            background: #333;
          }
        }
      }
    }
    .pwd-eye-icon {
      width: 30px;
      height: 24px;
      background: url('../../../assets/images/eye.svg') no-repeat center right;
      cursor: pointer;
      position: absolute;
      top: 0;
      left: 0;
      z-index: 10;
      &.pwd-hide {
        background: url('../../../assets/images/eye-off.svg') no-repeat center right;
      }
      &.disabled {
        pointer-events: none;
      }
    }
  }
</style>
