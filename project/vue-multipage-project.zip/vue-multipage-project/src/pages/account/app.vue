<template>
  <vcommon :menuParentKey="currentMenuParentKey">
    <div slot>
      <vpart title="公司账户信息">
        <div slot="search">
          <vinput
            type="text"
            class="table-search-input"
            style="display: inline-block"
            @keyup.enter.native="searchAccount"
            v-model.trim="params.keyWord"
            placeholder="请输入姓名/用户名/手机号"
          ></vinput>
          <vbutton active title="搜索" @click="searchAccount">搜索</vbutton>
        </div>
        <div slot="action">
          <vbutton active title="添加账户" @click="addAccount">添加</vbutton>
        </div>
        <vtable
          ref="table"
          :key="key"
          :columns="columns"
          :data="tableData"
          :useActionColumn="true"
          :usePagination="true"
          :totalItem="totalItem"
          :currentPage="params.pageNo"
          :pageSize="params.pageSize"
          :maxHeight="maxHeight"
          @pageChange="pageChange"
          @pageSizeChange="pageSizeChange"
        ></vtable>
        <vloading class="loading" v-model="loading"></vloading>
      </vpart>

      <!-- 账户编辑 -->
      <account-modal class="account-modal" ref="accountModal" @success="getAccountList"></account-modal>
    </div>
  </vcommon>
</template>




<script>
import accountModal from "./components/account-modal.vue";
import tableHeight from "../../common/mixins/table-height";
import pageView from "../../common/mixins/pageView";

export default {
  components: {
    accountModal
  },
  mixins: [tableHeight, pageView],
  data() {
    let _this = this;
    let currentUserInfo = JSON.parse(
      localStorage.getItem("fund_master_current_user")
    );

    // 检测是否是自己
    function checkYourSelf(user) {
      return user.id === currentUserInfo.userId;
    }

    return {
      currentMenuParentKey: "accountManager",
      loading: true,
      key: null,
      columns: [
        {
          key: "realName",
          title: "姓名",
          render: (h, { row }) => {
            return h("span", row.realName || row.linkMan || "--");
          }
        },
        // {
        //   key: "name",
        //   title: "用户名"
        // },
        {
          key: "mobile",
          title: "手机号",
          // align: "right"
        },
        {
          key: "userPermission",
          title: "账号权限",
          render: (h, { row }) => {
            return h("div", [
              h("vselect", {
                props: {
                  value: row.userPermission || 1,
                  disabled: checkYourSelf(row),
                  options: [
                    { label: "可读写", value: 1 },
                    { label: "只读", value: 2 }
                  ]
                },
                on: {
                  change: value => {
                    _this.setStatus(row.id, "userPermission", value);
                  }
                }
              })
            ]);
          }
        },
        {
          key: "status",
          title: "账号状态",
          render(h, { row, column, index }) {
            // 原来的离职变成禁用
            row.status = row.status === 3 ? 2 : row.status;

            return h("div", [
              h("vselect", {
                props: {
                  value: row.status,
                  disabled: checkYourSelf(row),
                  options: [
                    { label: "正常", value: 1 },
                    { label: "禁用", value: 2 },
                    { label: "删除", value: 4 },
                  ]
                },
                on: {
                  change: value => {
                    _this.setStatus(row.id, "status", value);
                  }
                }
              })
            ]);
          }
        },
        {
          key: "isAdmin",
          title: "是否管理员",
          render(h, { row, column, index }) {
            let isAdmin = row.isAdmin ? 1 : 0;

            return h("div", [
              h("vselect", {
                props: {
                  value: isAdmin,
                  disabled: checkYourSelf(row),
                  options: [
                    { label: "否", value: 0 },
                    { label: "是", value: 1 }
                  ]
                },
                on: {
                  change: value => {
                    _this.setStatus(row.id, "isAdmin", value);
                  }
                }
              })
            ]);
          }
        },
        {
          key: "action",
          title: "操作",
          width: 58,
          align: "center",
          showOverflowTooltip: false,
          render(h, { row, column, index }) {
            return h(
              "div",
              {
                class: "table-action-button-container"
              },
              [
                //删除
                h("vbuttonSprite", {
                  props: {
                    pos: {
                      normal: { x: 0, y: -241 },
                      hover: { x: -18, y: -241 },
                      disabled: { x: -36, y: -241 }
                    },
                    title: "删除",
                    disabled: checkYourSelf(row)
                  },
                  style: {
                    verticalAlign: "middle"
                  },
                  on: {
                    click: e => {
                      _this.deleteAccount(row);
                    }
                  }
                })
              ]
            );
          }
        }
      ],
      tableData: [],
      totalItem: 0,

      params: {
        keyWord: "",
        pageNo: 0,
        pageSize: 10
      }
    };
  },

  // firstLoad：标记第一次加载
  // 避免触发pageChange的时候重复加载
  //
  mounted() {
    this.firstLoad = true;
    this.searchAccount();
  },

  methods: {
    searchAccount() {
      this.params.pageNo = 1;
      this.params.pageSize = 10;
      this.getAccountList();
    },
    // 数据查询
    // 包含初次加载和关键字查询
    // 如果是输入查询的关键字是数字， 则用mobile方式查询
    // 否则查询 用户名或姓名
    //
    getAccountList() {
      let params = Object.assign({}, this.params);
      this.loading = true;

      // if (/^\d+$/.test(params.keywords)) {
      //   params.mobile = params.keywords;
      //   delete params.userName;
      // } else {
      //   params.userName = params.keywords;
      //   delete params.mobile;
      // }

      // 去除多余参数
      // delete params.keywords;
      this.$http
        .get("user/account", params)
        .then(res => {
          if (!res) return;
          if (res && res.code !== 20000) {
            this.$message({
              showClose: true,
              message: res.msg,
              type: "error"
            });
            return;
          }

          this.tableData = res.data.records;
          this.totalItem = res.data.total;
          this.key = Date.now();
        })
        .done(() => {
          this.loading = false;
        });
    },

    // 账户编辑
    // index: 行下标
    // item: 账号信息
    // 传入则更改， 不传入则添加
    //
    addAccount(index, item) {
      this.$refs.accountModal.show();
    },

    // 根据账号id
    // 从服务器删除数据
    // 删除操作，将status变成4
    // 删除成功则清除页面数据
    //
    deleteAccount(item) {
      //
      this.$confirm("确认删除吗？", "删除", {
        showCancelButton: true,
        type: "warning",
        closeOnClickModal: false,

        beforeClose: (action, instance, done) => {
          if (action === "cancel") {
            done();
            return;
          }

          instance.confirmButtonLoading = true;
          instance.confirmButtonText = "删除中...";

          //
          this.$http
            .put(
              "user/account/accSetStatus",
              {
                status: 4,
                isAdmin: 0
              },
              item.id
            )
            .then(res => {
              instance.confirmButtonLoading = false;
              if (!res) return;

              let isSuccess = res.code == 20000;
              this.$message({
                showClose: true,
                message: isSuccess ? "删除成功" : "删除失败",
                type: isSuccess ? "success" : "error"
              });

              if (isSuccess) {
                this.searchAccount();
                this.$refs.accountModal.getPersonList();
              }
            })
            .done(() => {
              done();
            });
        }
      });
    },

    // 编辑状态
    // 设置或取消管理员
    //
    setStatus(id, key, value) {
      this.loading = true;

      this.$http
        .put(
          "user/account/accSetStatus",
          {
            [key]: value
          },
          id
        )
        .then(res => {
          if (!res) {
            return;
          }
          if (res.code === 20000) {
            this.$message.success("设置成功");
          } else {
            this.$message.error(res.msg);
            return;
          }

          this.searchAccount();
        })
        .done(() => {
          this.loading = false;
        });
    },

    // 分页操作相关
    //
    pageChange(page) {
      // if( this.firstLoad ){
      // 	this.firstLoad = false;
      // 	return;
      // }

      this.params.pageNo = page;
      this.getAccountList();
    },

    pageSizeChange(size) {
      this.params.pageSize = size;

      this.getAccountList();
    }

    //点击单行
    // tableRowClick ({row, column, index}) {
    // 	this.currentRowId = row.mobile;
    // 	this.$refs.table.setCurrentRow('mobile', this.currentRowId);
    // },
  }
};
</script>




<style lang="less">
.form {
  padding: 0 10px;
  background-color: #1a1a1a;
}
.account-table-container {
  position: relative;
}
</style>


