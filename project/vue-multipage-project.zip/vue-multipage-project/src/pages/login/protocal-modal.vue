<style lang="less" src="./login.less"></style>
<template>
  <vmodal ref="protocalModal" class="protocal-modal t2-el-dialog" @close="close" :title="`基金大师服务协议`" :width="800">
    <div class="content-protocal" v-html="pContent"></div>
    <div slot="modal-footer" style="font-size:12px;" class="cl" v-show="showBtn">
      <div class="agree-checkbox">
        <vcheckbox v-model="agreeStatus" :options="options"></vcheckbox>
      </div>
      <vbutton
        :active="agreeStatus[0]"
        :disabled="!agreeStatus[0]"
        @click="agreeProtocal"
        class="protocal-button"
      >确定</vbutton>
    </div>
  </vmodal>
</template>

<script>
import pContent from "./protocal";
export default {
  props: {
    showBtn: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      pContent,
      agreeStatus: [],
      options: [{ label: "我已阅读并同意所有协议", value: true }]
    };
  },
  methods: {
    agreeProtocal() {
      if (this.agreeStatus[0]) {
        this.$refs.protocalModal.close();
        this.$emit("login", this.agreeStatus[0]);
      } else {
        return false;
      }
    },
    open() {
      this.$refs.protocalModal.open();
    },
    close() {
      this.$refs.protocalModal.close();
    }
  }
};
</script>

<style lang="less">
.protocal-modal {
  .modal-content {
    span {
      float: left;
    }
  }
  // 协议样式
  .content-protocal {
    line-height: 30px;
    white-space: pre-wrap;
    word-break: break-all;
    font-size: 14px;
    color: #aaa;
    strong {
      font-weight: bold;
      color: #fefefe;
    }
  }
  .agree-checkbox {
    float: left;
    margin-left: 15px;
    .checkbox-content {
      line-height: 30px !important;
      width: 100%;
      .checkbox-label {
        width: 100%;
        span {
          float: left;
        }
      }
    }
  }
  .modal-footer {
    & > .cl {
      margin-top: 6px;
      font-size: 12px;
    }
    .protocal-button {
      float: left;
    }
  }
}
</style>
