<style lang="less" src="./login.less"></style>

<template>
	<div class="login-page-container">
		<div class="logo-container"></div>
		<div class="inner cl">
			<div class="carousel-total-container fl">
				<div class="carousel-container">
					<ul class="carousel-lists cl" :style="{width:(carouselPics.length+1) * 5.72+'rem'}">
						<li v-for="(item,index) in carouselPics" :key="index" class="carousel-item">
							<img :src="getCarouselPic(item)" alt="">
						</li>
					</ul>
				</div>
				<div class="click-tools-container">
					<ul class="click-lists">
						<li class="click-item" v-for="(item,ind) in carouselPics" :key="ind" @click="showCorrespondingPic(ind)" :class="{current:index==ind || (ind==0&&index==carouselPics.length)}"></li>
					</ul>
				</div>
			</div>
			<div class="login-main-container fl">
				<div class="fund-string"></div>
				<div class="login-container">
					<div class="form">
						<p class="login-title">用户登录</p>
						<form class="login-form">
							<div class="input-row">
								<input type="text" v-model.trim="userName" autofocus placeholder="请输入手机号" class="username" :class="userActived" @click="autoSelect" @input="validForm">
								<i class="user-icon" :class="userActived"></i>
							</div>
							<div class="input-row">
								<input type="password" v-model.trim="password" placeholder="请输入密码" class="password" :class="pswActived" @click="autoSelect" @input="validForm">
								<i class="psw-icon" :class="pswActived"></i>
							</div>
						</form>
						<div class="login">
							<vbutton @click="login" class="login-button" :disabled="isLogining" :class="buttonColor">{{isLogining?'登录中...':'登录'}}</vbutton>
						</div>
						<span class="forget-button" @click="forgetPwd">忘记密码</span>
						<span class="apply-button" @click="applyUse">申请试用</span>
					</div>
				</div>
			</div>
			<div class="contact-info">
				联系我们：<a class="mail-contact" href="mailto:fm@simuwang.com">fm@simuwang.com</a>
				<p class="copyright">版权所有&copy;深圳市排排网投资管理股份有限公司ICP证粤B2-20110208 粤ICP备09068203号</p>
			</div>
			<protocal-modal ref="protocalModal" :showBtn="showBtn" @login="login" @disagree="disagree"></protocal-modal>
		</div>
	</div>
</template>
<script>
import pageView from "../../common/mixins/pageView";
import protocalModal from "./protocal-modal.vue";
import {refreshToken} from "../../common/js/utils.js"
export default {
  components: {
    protocalModal
  },
  mixins: [pageView],
  data() {
    return {
      carouselPics: [
        "information-disclosure.png",
        "analysis.png",
        "report.png",
        "opportunity.png"
      ],
      index: 0,
      userName: "",
      password: "",
      remember: false,
      buttonColor: "",
      agreeStatus: [],
      isLogining: false,
      showBtn: false
    };
  },
  mounted() {
    document.body.onkeydown = e => {
      if (e.keyCode == 13) {
        this.login();
      }
    };

    if (this.userName != "") {
      this.buttonColor = "color-red";
    }
    this.setRem();
    window.addEventListener("resize", this.resizeSetRem);
    this.autoRun();
  },
  methods: {
    // 设置页面响应式的rem
    setRem() {
      $("html").css({
        "font-size": ($(document.body).width() * 10) / 192 + "px"
      });
    },
    resizeSetRem() {
      if ($(document.body).width() < 1200) {
        return;
      }
      this.setRem();
    },
    getCarouselPic(item) {
      return `${
        this.$baseUrl[process.env.NODE_ENV]["page"]
      }/assets/images/banner/${item}`;
    },
    // 自动轮播处理index;
    dealIndex() {
      this.index++;
      if (this.index === this.carouselPics.length) {
        // this.goOrigin();
        this.index = 0;
      }
      this.moveToIndex(this.index);
    },
    // 点击工具条显示对应的图片
    showCorrespondingPic(index) {
      this.index = index;
      clearInterval(this.timer);
      this.moveToIndexByClick(index);
      this.autoRun();
    },
    // 到最后一张图的时候快速回到第一张图
    goOrigin() {
      $(".carousel-lists").css({
        left: "0px"
      });
    },
    // 根据index调到对应图片
    moveToIndex(index) {
      // $('.carousel-lists').animate({
      // 	'left':-(index * $('.carousel-lists li').width())+'px'
      // },200)
      $(".carousel-lists li")
        .eq(index)
        .fadeIn(1500)
        .siblings()
        .fadeOut(1500);
    },
    moveToIndexByClick(index) {
      $(".carousel-lists li").stop();
      $(".carousel-lists li")
        .eq(index)
        .fadeIn(500)
        .siblings()
        .fadeOut(500);
    },
    // 自动轮播
    autoRun() {
      this.timer = setInterval(() => {
        this.dealIndex();
      }, 2500);
    },
    refreshToken({ token, companyId, userName, userIdEncrypted }) {

      return new Promise((resolve, reject) => {
        $.ajax({
          type: "get",
          url: `${
            this.$baseUrl[process.env.NODE_ENV]["master"]
          }/fundMaster/Index/flush`,
          dataType: "jsonp",
          data: {
            token,
            companyId,
            userName,
            userIdEncrypted
          },
          // jsonp: "callback",
          jsonpCallback: "success_jsonpCallback",
          success: json => {
            // debugger
            if(+json.suc === 1){
              resolve();
            }else{
              reject();
            }
            // resolve();
          },
          fail: () => {
            reject();
          },
          error: () => {
            reject();
          },
          beforeSend: () => {}
        });
      });
    },

    // 同意协议才能登录
    //
    login(isAgree) {
      this.isLogining = true;
      if (!this.buttonColor) {
        this.$message.error("请填写完整信息");
        this.isLogining = false;
        return;
      }
      let loginInfo = {
        userName: this.userName,
        password: this.password,
        remember: 1,
        isAgree: Number(isAgree)
      };

      this.$http.post("user/checkLogin", loginInfo).then(
        res => {
          if (res.code != 20000) {
            if (res.code == 40024) {
              this.showProtocal(true);
              this.isLogining = false;
              return;
            }
            this.$message.error(res.msg);
            this.isLogining = false;
            return;
          }

          //localStorage存储源用户和当前用户的信息，用于页面中判断用户状态进行相应处理
          let user = {
            userName: res.data.username,
            trueName: res.data.trueName,
            changeAble: res.data.changeAble,
            changeLevel: res.data.changeLevel,
            isAdmin: res.data.isAdmin,
            companyId: res.data.companyId,
            companyName: res.data.companyName,
            userId: res.data.userId,
            userCompanyApplicationIds: res.data.userCompanyApplicationIds,
            userPermission: res.data.userPermission || 1,
            smUserName: res.data.smUserName,
            smUserId: res.data.smUserId
          };
          localStorage.setItem("fund_master_origin_user", JSON.stringify(user));
          localStorage.setItem(
            "fund_master_current_user",
            JSON.stringify(user)
          );
          //登陆操作时，所有接口都可调用
          sessionStorage.setItem("canSend", true);

          //刷新token，用于报告工厂和组合大师分析页面
          let token = res.data.userCenter.token;
          let companyId = res.data.companyId || res.data.orgId;
          let userName = res.data.trueName;
          let userIdEncrypted = res.data.userCenter.userIdEncrypted;

          refreshToken({
            token,
            companyId,
            userName,
            userIdEncrypted
          }).then(
            () => {
              setTimeout(() => {
                this.isLogining = false;
                // 设置组合大师token状态可用
                this.setMasterUseable()
                //跳转到首页
                location.href =
                  this.$baseUrl[process.env.NODE_ENV]["page"] +
                  "/index/index.html";
              }, 1000);
            },
            () => {
              // this.$message.error("登陆失败，请重试");
              setTimeout(() => {
                this.isLogining = false;
                // 如果组合大师token刷新不成功，先记录下来，然后在用户使用组合大师功能的时候提示
                this.setMasterUnable();
                //跳转到首页
                location.href =
                  this.$baseUrl[process.env.NODE_ENV]["page"] +
                  "/index/index.html";
              }, 1000);
            }
          );

          //神策监听用户登陆
          sa.login(user.userId);
          sa.event("fundMaster_login", {});
        },
        err => {
          this.$message.error("登陆失败，请重试");
        }
      );
    },

    forgetPwd() {
      window.open(
        this.$baseUrl[process.env.NODE_ENV]["official"] +
          "/passport/passwordReset"
      );
    },
    applyUse(){
      window.location.assign(this.$baseUrl[process.env.NODE_ENV]["page"] +
          "/apply-pc/index.html"
      )
    },
    // 如果组合大师token刷新不成功，先记录下来，然后在用户使用组合大师功能的时候提示
    setMasterUnable(){
      window.sessionStorage.setItem("masterUseable", false);
    },
    setMasterUseable(){
      window.sessionStorage.setItem("masterUseable", true);
    },


    // 协议窗口相关
    // showBtn: 是否显示操作按钮
    //
    showProtocal(showBtn) {
      this.showBtn = showBtn;
      this.$refs.protocalModal.open();
    },

    // cancelProtocal(){
    // 	this.$refs.protocalModal.close()
    // },

    // agreeProtocal(){
    // 	if(this.agreeStatus[0]){
    // 		this.cancelProtocal()
    // 		this.login( this.agreeStatus[0] )
    // 	}else{
    // 		return false;
    // 	}
    // },

    // 表单验证
    validForm() {
      this.buttonColor =
        this.userName === "" || this.password === "" ? "" : "color-red";
      this.userActived = this.userName === "" ? "" : "actived";
      this.pswActived = this.password === "" ? "" : "actived";
    },

    // 点击自动全选
    autoSelect(e) {
      e.target.select();
    }
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.resizeSetRem);
  }
};
</script>
