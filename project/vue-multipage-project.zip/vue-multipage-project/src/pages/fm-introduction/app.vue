<template>
    <div slot class="introdution-container">
      <img src="../../assets/images/intro.jpg" alt="">
    </div>
</template>

<script>
  export default {
    components: {
    },
    data () {
      return {
        notes: []
      }
    },
    methods: {

    },
    mounted () {
    }
  }
</script>


<style lang="less" scoped>
  .introdution-container{
    width: 100%;
    height: 100%;
    background-color: #dedede;
      img{
      width: 100%;
    }
  }
</style>
