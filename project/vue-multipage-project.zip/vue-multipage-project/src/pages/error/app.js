
import App from './app.vue'

import '../../common/js/common';
import '../../common/js/comp';


const createApp = () => {
  new Vue({
    el: '#app',
    render: h => h(App)
  })
}



createApp()

