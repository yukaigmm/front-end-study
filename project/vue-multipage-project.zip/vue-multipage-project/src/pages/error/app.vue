<template>
  <div class="error-container">
    <img class="img" src="../../assets/images/error.png" alt="">
    <vbutton active @click="backHome">返回首页</vbutton>
    <!-- <vcheckbox :options="[{value: 1, label: '1'},{value: 2, label: '2'}]"></vcheckbox> -->
  </div>
</template>

<script>
export default {
  data () {
    return {

    }
  },
  methods: {
    backHome () {
      location.assign(`${this.$baseUrl[process.env.NODE_ENV]['page']}/index/index.html`)
    }
  }
}
</script>

<style lang="less" scoped>
  .error-container {
    width: 100%;
    height: 100%;
    background-color: #2B3238;
    text-align: center;
    overflow: hidden;
    .img {
      display: block;
      margin: 100px auto 0;
    }
    .button {
      margin-top: 10px;
    }
  }
</style>


