<template>
  <vmodal
    :title="`${status === 'add' ? '新增' :'编辑'}路演`"
    ref="addModal"
    class="roadshow-add-modal t2-el-dialog"
    @close="cancel"
    :width="720"
  >
    <vformConfig ref="addForm" :config="addFormConfig" v-model="addFormValue"></vformConfig>
    <div class="user-list-icon" @click.stop="showSpeakerSelect" :style="iconPosition">
      <div class="user-select-container" v-show="showSpeakerList">
        <ul class="user-select">
          <li
            v-for="(item,index) in speakerList"
            :key="index"
            @click.stop="selectSpeaker(item)"
          >{{item.personnelName}}</li>
        </ul>
      </div>
    </div>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="submitRoadshow">提交</vbutton>
    </div>
    <vloading slot="loading" v-model="modalLoading"></vloading>
  </vmodal>
</template>

<script>
import { validatePhoneNumber } from "../../../common/js/validator.js";
export default {
  data() {
    return {
      modalLoading: false,
      speakerList: [],
      showSpeakerList: false,
      status: "",
      roadshowId: "",
      addFormValue: {
        topic: "",
        speakerName: "",
        speakerIntroduce: "",
        subject: "",
        roadshowVideoInfo: "",
        summary: "",
        recordDate: "",
        uploadUserId: "",
        contactNumber: ""
      },
      speakerId: "",
      previewUrl: "",
      preValue: "",
      currentEditorValue: "",
      iconPosition: ""
    };
  },
  methods: {
    open(status) {
      this.status = status;
      this.setSpeakerPosition();
      this.$refs.addModal.open();
      if (status === "add") {
        let currentUserInfo = JSON.parse(
          localStorage.getItem("fund_master_current_user")
        );
        this.$set(this.addFormValue, "uploadUserId", currentUserInfo.userId);
      }
    },
    cancel() {
      this.$refs.addModal.close();
      this.addFormValue = {};
      this.speakerId = "";
      this.$refs.addForm.resetValid();
    },
    // 获取主讲人列表
    getSpeakerList() {
      this.$http.post("datadis/company/getSelfPersonnel").then(res => {
        if (res.code !== 20000) {
          this.$message({
            showClose: true,
            message: res.msg,
            type: "error"
          });
          return;
        }
        this.speakerList = JSON.parse(JSON.stringify(res.data));
      });
    },
    // 显示主讲人列表
    showSpeakerSelect() {
      this.showSpeakerList = true;
    },
    // 选择主讲人
    selectSpeaker(item) {
      this.preValue = this.addFormValue.personSummary;
      this.$set(this.addFormValue, "speakerName", item.personnelName);
      this.$nextTick(() => {
        $('div[item-key="speakerName"] input')
          .trigger("focus")
          .trigger("blur");
        $(".roadshow-add-modal .edit-container .w-e-toolbar").css({
          display: "flex"
        });
        $(
          ".roadshow-add-modal .edit-container .w-e-text-container w-e-text"
        ).css({
          paddingBottom: "15px"
        });
      });
      this.speakerId = item.personnelId;
      this.$http
        .get(`datadis/personnel/profile/${item.personnelId}`)
        .then(res => {
          if (res.code === 20000) {
            // this.currentEditorValue = res.data;
            this.$set(this.addFormValue, "personSummary", res.data);
          } else {
            // this.currentEditorValue = '';
            this.$set(this.addFormValue, "personSummary", "");
          }
        });
      this.showSpeakerList = false;
    },
    // 修改时获取路演详情
    getRoadshowInfo(id) {
      this.roadshowId = id;
      this.modalLoading = true;
      this.$http
        .get(`roadshow/${id}`)
        .then(res => {
          if (res.code === 20000) {
            let data = JSON.parse(JSON.stringify(res.data));
            this.addFormValue = data;
            this.addFormValue.roadshowVideoInfo = {
              fileName: data.videoName,
              filePath: data.tempLinkPath,
              fileSize: data.videoSize,
              createtime: data.uploadDate
            };
            this.speakerId = data.speakerId;
            this.previewUrl =
              this.$baseUrl[process.env.NODE_ENV]["staticFile"] +
              data.tempLinkPath;
          }
        })
        .done(() => {
          this.modalLoading = false;
        });
    },
    // 提交路演信息
    submitRoadshow() {
      if (!(window.sessionStorage.getItem("canSend") === "false")) {
        this.modalLoading = true;
      }
      this.$refs.addForm.valid().then(valid => {
        if (valid) {
          let params = this.getSubmitParams(this.addFormValue);
          // let params = Object.assign({},this.addFormValue,this.additionFormValue);
          if (this.status === "add") {
            this.addRoadshow(params);
          } else {
            this.modifyRoadshow(params);
          }
        } else {
          this.modalLoading = false;
        }
      });
    },
    // 获取提交路演的参数
    getSubmitParams(formValue) {
      let roadshowVideoInfo = formValue.roadshowVideoInfo;
      let submitParams = Object.assign({}, formValue, {
        tempLinkPath: roadshowVideoInfo.filePath,
        videoSize: roadshowVideoInfo.fileSize,
        videoName: roadshowVideoInfo.fileName,
        uploadDate: roadshowVideoInfo.createtime
        // speakerId: this.speakerId,
        // id: this.roadshowId,
      });

      // 判断是否有speakerId,验证speakerId是否和人物一致
      if (this.speakerId) {
        submitParams.speakerId = this.speakerId;
      }
      let useSpeakerId = this.validateSpeakerId(
        submitParams.speakerId,
        submitParams.speakerName
      );
      if (!useSpeakerId) {
        delete submitParams.speakerId;
      }
      // 删除多余参数
      delete submitParams.roadshowVideoInfo;
      return submitParams;
    },
    // 验证speakerId和name是否一致
    validateSpeakerId(id, name) {
      for (let item of this.speakerList) {
        if (item.personnelName === name) {
          if (item.personnelId === id) {
            return true;
          }
        }
      }
      return false;
    },
    // 新增路演
    addRoadshow(params) {
      this.$http
        .post("roadshow", params)
        .then(res => {
          if (!res) return;
          if (res.code === 20000) {
            //监听路演发布事件
            sa.event("fundMaster_addRoadShow", {});

            this.cancel();
            this.$emit("getRoadshowList");
            this.$message.success("新增路演成功");
          } else {
            this.$message.error(res.msg);
          }
        })
        .done(() => {
          this.modalLoading = false;
        });
    },
    // 修改路演
    modifyRoadshow(params) {
      this.$http
        .put(`roadshow/${this.roadshowId}`, params)
        .then(res => {
          if (!res) return;
          if (res.code === 20000) {
            this.cancel();
            this.$emit("getRoadshowList");
            this.$message.success("修改路演成功");
          } else {
            this.$message.error(res.msg);
          }
        })
        .done(() => {
          this.modalLoading = false;
        });
    },
    //设置主讲人图标的位置
    setSpeakerPosition() {
      setTimeout(() => {
        let offsetLeft = document.querySelector('div[item-key="speakerName"]')
          .offsetLeft;
        let offsetTop = document.querySelector('div[item-key="speakerName"]')
          .offsetTop;
        let itemLength = document.querySelector('div[item-key="speakerName"]')
          .offsetWidth;
        this.iconPosition = {
          left: offsetLeft + itemLength - 31 + "px",
          top: offsetTop + 1 + "px"
        };
      }, 100);
    }
  },
  mounted() {
    this.getSpeakerList();
    document.addEventListener("click", () => {
      this.showSpeakerList = false;
    });
  },
  computed: {
    addFormConfig() {
      return {
        cols: 12,
        fields: [
          [
            {
              label: "路演标题",
              labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "topic",
                  compType: "vinput",
                  rules: [{ required: true, message: "请输入路演标题" }]
                }
              ]
            }
          ],
          [
            {
              label: "路演视频",
              colspan: 6,
              labelWidth: 90,
              comps: [
                {
                  key: "roadshowVideoInfo",
                  compType: "vvideoUpload",
                  rules: [{ required: true, message: "请上传路演视频" }],
                  notice: "注：视频时长在10分钟以内，大小为50M以内",
                  compConfig: {
                    url: "common/upFile",
                    fileName: "roadshowVideo",
                    resName: "fileName",
                    acceptType: "video/*",
                    acceptDetail: ["mp3", "mp4", "flv"],
                    typeWarn: "只支持mp3，mp4，flv文件",
                    // 删除上传文件返回的文件对象
                    emptyFileObj: {
                      filePath: "",
                      fileName: ""
                    },
                    // 预览地址
                    previewUrl: this.previewUrl
                  }
                }
              ]
            }
          ],
          [
            {
              label: "主讲人",
              labelWidth: 90,
              colspan: 6,
              comps: [
                {
                  key: "speakerName",
                  compType: "vinput",
                  rules: [{ required: true, message: "请输入或选择主讲人" }]
                }
              ]
            },
            {
              label: "录制时间",
              colspan: 6,
              labelWidth: 90,
              comps: [
                {
                  key: "recordDate",
                  compType: "vdatePicker"
                }
              ]
            }
          ],
          [
            {
              label: "主讲人介绍",
              labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "personSummary",
                  compType: "veditor",
                  compConfig: {
                    editorId: "personSummary",
                    currentValue: this.currentEditorValue,
                    preValue: this.preValue
                  }
                }
              ]
            }
          ],
          [
            {
              label: "上传者",
              labelWidth: 90,
              colspan: 6,
              comps: [
                {
                  key: "uploadUserId",
                  compType: "vselect",
                  compConfig: {
                    url: "user/account",
                    extendKey: "records",
                    searchParam: {
                      pageNo: 1,
                      pageSize: -1
                    },
                    labelKey: "realName",
                    valueKey: "officialUserId"
                  },
                  rules: [{ required: true, message: "请选择上传者" }]
                }
              ]
            },
            {
              label: "联系电话",
              labelWidth: 90,
              colspan: 6,
              comps: [
                {
                  key: "contactNumber",
                  compType: "vinput",
                  compConfig: {},
                  rules: [
                    { required: true, message: "请输入联系电话" },
                    validatePhoneNumber()
                  ]
                }
              ]
            }
          ],
          [
            {
              label: "路演主题",
              labelWidth: 90,
              colspan: 6,
              comps: [
                {
                  key: "subject",
                  compType: "vselect",
                  rules: [{ required: true, message: "请选择路演主题" }],
                  compConfig: {
                    // options: getSessionOption("cPersonnelType"),
                    // valueKey: "param",
                    // labelKey: "name"
                    options: [
                      {
                        label: "春瑜会客厅",
                        value: "春瑜会客厅"
                      },
                      {
                        label: "透过榜单看私募",
                        value: "透过榜单看私募"
                      },
                      {
                        label: "王牌学院",
                        value: "王牌学院"
                      },
                      {
                        label: "看财经",
                        value: "看财经"
                      },
                      {
                        label: "新浪网红财经大赛",
                        value: "新浪网红财经大赛"
                      },
                      {
                        label: "股灾专题",
                        value: "股灾专题"
                      },
                      {
                        label: "CTA",
                        value: "CTA"
                      },
                      {
                        label: "大讲堂系列",
                        value: "大讲堂系列"
                      },
                      {
                        label: "策略报告",
                        value: "策略报告"
                      },
                      {
                        label: "股票",
                        value: "股票"
                      },
                      {
                        label: "期货",
                        value: "期货"
                      },
                      {
                        label: "宏观对冲",
                        value: "宏观对冲"
                      },
                      {
                        label: "股权",
                        value: "股权"
                      },
                      {
                        label: "海外",
                        value: "海外"
                      },
                      {
                        label: "固收",
                        value: "固收"
                      },
                      {
                        label: "债券",
                        value: "债券"
                      },
                      {
                        label: "复合策略",
                        value: "复合策略"
                      },
                      {
                        label: "价值投资",
                        value: "价值投资"
                      },
                      {
                        label: "alpha策略",
                        value: "alpha策略"
                      },
                      {
                        label: "套利",
                        value: "套利"
                      },
                      {
                        label: "定增",
                        value: "定增"
                      },
                      {
                        label: "新三板",
                        value: "新三板"
                      },
                      {
                        label: "FOF",
                        value: "FOF"
                      },
                      {
                        label: "量化",
                        value: "量化"
                      },
                      {
                        label: "相对价值",
                        value: "相对价值"
                      },
                      {
                        label: "网下打新",
                        value: "网下打新"
                      },
                      {
                        label: "2016私募冠军",
                        value: "2016私募冠军"
                      }
                    ]
                  }
                }
              ]
            },
            {
              label: "类型",
              labelWidth: 90,
              colspan: 6,
              comps: [
                {
                  key: "roadshowType",
                  compType: "vselect",
                  compConfig: {
                    options: [
                      {
                        label: "上市公司",
                        value: "1"
                      },
                      {
                        label: "机构观点",
                        value: "2"
                      },
                      {
                        label: "私募基金",
                        value: "3"
                      }
                    ]
                  },
                  rules: [
                    {
                      required: true,
                      type: "string",
                      message: "请选择路演类型"
                    }
                  ]
                }
              ]
            }
          ],

          [
            {
              label: "路演介绍",
              labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "summary",
                  compType: "veditor",
                  compConfig: {
                    editorId: "summary",
                    editorConfig: {
                      menus: []
                    }
                  }
                }
              ]
            }
          ]
        ]
      };
    }
  }
};
</script>


<style lang="less">
.roadshow-add-modal {
  // min-width: 0px;
  // width: 720px;
  // height: 630px !important;
  // top: 7% !important;
  .content {
    position: relative;
  }
  // 路演主题下拉列表样式设置
  .select-wrapper .dropdown-content {
    max-height: 151px;
  }
  // 主讲人列表icon
  .user-list-icon {
    width: 30px;
    height: 24px;
    background: url("../../../assets/images/users.svg") no-repeat center right;
    cursor: pointer;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 999;
    // right: 12px;
    background-color: #1a1a1a;
    .user-select-container {
      position: absolute;
      z-index: 999;
      &:before {
        content: "";
        position: absolute;
        top: 32px;
        right: -20px;
        width: 0px;
        height: 0px;
        border: 8px solid #202020;
        border-right-color: transparent;
        border-bottom-color: transparent;
        transform: rotate(45deg);
      }
    }
    // 主讲人列表
    ul.user-select {
      width: 140px;
      max-height: 240px;
      margin: 0;
      overflow: auto;
      background-color: #202020;
      position: absolute;
      left: -100px;
      top: 40px;
      // 此处设置z-index 999 ,编译出来之后是1，因此样式在common.less中设置了
      // z-index: 999 !important;
      box-shadow: 0 0 10px #666;
      li {
        height: 34px;
        line-height: 34px;
        // border-bottom: 1px solid #444;
        color: #eee;
        text-align: center;
        &:hover {
          background: #333;
        }
      }
    }
  }
  .edit-container {
    position: relative;
    .w-e-toolbar {
      position: absolute;
      bottom: 0;
      left: 0;
      // display: flex !important;
      display: none;
      width: 100%;
      height: 25px;
      padding-bottom: 3px;
      .w-e-menu {
        i {
          color: #666;
        }
        &:hover {
          i {
            color: #aaa;
          }
        }
      }
    }
  }
  .w-e-text-container {
    z-index: 1 !important;
    .w-e-text {
      max-height: 100px !important;
      p {
        margin: 5px 0;
      }
    }
  }
  // 路演视频提示信息
  div[item-key="roadshowVideoInfo"] {
    .valid-container {
      margin-bottom: 4px;
    }
  }
}
</style>

