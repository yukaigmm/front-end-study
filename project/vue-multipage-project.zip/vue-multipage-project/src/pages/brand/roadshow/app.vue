<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
    <div style="height:100%">
      <vpart title="公司路演信息">
        <div slot="search">
          <vselect
            v-model="searchFormValue.roadshowType"
            @change="searchRoadshow"
            :options="roadshowTypeOption"
          ></vselect>
          <vselect
            v-model="searchFormValue.status"
            @change="searchRoadshow"
            :options="roadshowStatusOption"
          ></vselect>
          <vinput
            type="text"
            class="table-search-input"
            style="display: inline-block;"
            @keyup.enter.native="searchRoadshow"
            v-model="searchFormValue.keyWord"
            placeholder="关键字搜索(路演标题)"
          ></vinput>
          <vbutton active title="搜索" @click="searchRoadshow">搜索</vbutton>
        </div>
        <div slot="action">
          <vbutton active title="添加路演" @click="addRoadshow">新增</vbutton>
        </div>
        <vtable
          :key="key"
          ref="table"
          :columns="columns"
          :data="tableData"
          :usePagination="true"
          :totalItem="totalItem"
          layout="total"
          :currentPage="pageNo"
          :rowKey="row => row.id"
          :maxHeight="maxHeight"
          @pageChange="pageChange"
          @pageSizeChange="pageSizeChange"
          @tableRowClick="tableRowClick"
          style="position: relative"
        ></vtable>
        <vloading class="loading" v-model="loading"></vloading>
      </vpart>

      <!-- 新增modal -->
      <add-modal ref="addModal" @getRoadshowList="getRoadshowList"></add-modal>
      <!-- 预览路演 -->
      <video-preview ref="previewModal" class="roadshow-video-preview"></video-preview>
    </div>
  </vcommon>
</template>

<script>
import tableHeight from "../../../common/mixins/table-height.js";
import addModal from "./add-modal.vue";

import videoPreview from "../../../common/components/comp/video-preview.vue";
// import { getSessionOption } from "../../../common/js/utils";
export default {
  components: {
    addModal,
    videoPreview
  },
  mixins: [tableHeight],
  data() {
    return {
      hasTabs: true,
      currentMenuParentKey: "brand",
      currentMenuChildKey: "roadshow",
      currentCompany: "",
      totalItem: 0,
      page: 1,
      pageSize: 1000,
      loading: false,
      roadshowStatusOption: [
        {
          label: "全部状态",
          value: 0
        },
        {
          label: "待审核",
          value: 1
        },
        {
          label: "审核中",
          value: 2
        },
        {
          label: "审核不通过",
          value: 3
        },
        {
          label: "已审核",
          value: 4
        },
        {
          label: "已下架",
          value: 5
        },
        {
          label: "已上架",
          value: 7
        }
      ],
      roadshowTypeOption: [
        {
          label: "全部类型",
          value: 0
        },
        {
          label: "上市公司",
          value: 1
        },
        {
          label: "机构观点",
          value: 2
        },
        {
          label: "私募基金",
          value: 3
        }
      ],
      currentRoadshowId: "",
      status: "add",
      searchFormValue: {
        status: 0,
        roadshowType: 0,
        keyWord: ""
      },
      columns: [
        {
          key: "roadshowType",
          title: "类型",
          width: 76,
          showOverflowTooltip: false,
          render: (h, { row }) => {
            let bgPositionMap = {
              // 3: '0 0',
              // 2: '-56px 0',
              // 1: '-112px 0',
              1: "-112px 0",
              2: "0 0",
              3: "-56px 0"
            };
            return h("span", {
              style: {
                display: "block",
                width: "56px",
                height: "22px",
                lineHeight: "34px",
                display: "block",
                textAlign: "center",
                backgroundImage: row.roadshowType
                  ? `url(${
                      this.$baseUrl[process.env.NODE_ENV]["page"]
                    }/assets/images/sprite-roadshow.png)`
                  : "",
                backgroundPosition: bgPositionMap[row.roadshowType]
              }
            });
          }
        },
        {
          key: "topic",
          title: "路演标题",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h(
              "div",
              {
                style: {
                  width: "100%",
                  height: "100%",
                  position: "relative"
                }
              },
              [
                h("span", {
                  style: {
                    display: "block",
                    width: "100%",
                    color: "#999",
                    fontWeight: "normal",
                    maxHeight: "112px",
                    lineHeight: "2",
                    overflow: "hidden"
                  },
                  domProps: {
                    innerHTML: row.topic
                  }
                })
              ]
            );
          }
        },
        {
          key: "suject",
          title: "路演主题",
          width: 150,
          render(h, { row }) {
            return row.subject || "--";
          }
        },
        {
          key: "companyName",
          title: "发布机构",
          width: 180
        },
        {
          key: "uploadUser",
          title: "上传人",
          width: 70
        },
        {
          key: "contactNumber",
          title: "联系电话",
          width: 115,
          align: "right"
        },
        {
          key: "recordDate",
          title: "录制日期",
          width: 90,
          align: "right",
          render(h, { row }) {
            return row.recordDate || "--";
          }
        },
        {
          key: "speakerName",
          title: "主讲人",
          align: "left",
          width: 70,
          render(h, { row }) {
            return row.speakerName || "--";
          }
        },
        {
          key: "status",
          title: "进度状态",
          width: 90,
          render(h, { row }) {
            let map = {
              1: "待审核",
              2: "审核中",
              3: "审核不通过",
              4: "已审核",
              5: "已下架",
              6: "已下架",
              7: "已上架"
            };
            if (row.status + "" === "3") {
              return h(
                "el-tooltip",
                {
                  props: {
                    placement: "bottom-start",
                    enterable: false
                  }
                },
                [
                  h(
                    "div",
                    {
                      slot: "content",
                      class: {
                        "tooltip-content": true
                      },
                      style: {
                        maxWidth: "150px",
                        lineHeight: "18px"
                      }
                    },
                    [
                      h("span", [
                        h(
                          "span",
                          {
                            style: {
                              display: "inline-block"
                            }
                          },
                          `原因：${row.auditRemark}`
                        )
                      ])
                    ]
                  ),
                  h(
                    "span",
                    {
                      style: {
                        color: "rgba(255, 68, 85, 0.8)"
                      }
                    },
                    map[row.status]
                  )
                ]
              );
            }
            return map[row.status] || "--";
          }
        },
        // {
        //   key: "viewsNumber",
        //   title: "访问热度",
        //   width:78,
        //   render(h, { row, column, index }) {
        //     let colorMap = [
        //       "rgba(250, 200, 41, 1)",
        //       "rgba(255, 150, 41, 1)",
        //       "rgba(255, 100 ,41, 1)",
        //       "rgba(255, 50, 41, 1)",
        //       // "rgba(255, 0, 41, 1)"
        //     ];
        //     return h(
        //       "div",
        //       {
        //         style: {
        //           lineHeight: 1,
        //           height: "18px",
        //           border: "1px solid #aaa",
        //           position: "relative",
        //           borderRadius: "3px",
        //           width: '52px',
        //           margin: '0 auto'
        //         },
        //         class: {
        //           "click-ratio-battery": true
        //         }
        //       },
        //       colorMap.map((value, index) => {
        //         return h("span", {
        //           style: {
        //             display: "inline-block",
        //             // float: 'left',
        //             height: "14px",
        //             width: "10px",
        //             background:
        //               row.viewsNumber > index ? value : "transparent",
        //             border:
        //               row.viewsNumber > index
        //                 ? `1px solid ${value}`
        //                 : "1px dashed rgba(255,255,255,.2)",
        //             // background: value,
        //             // border: `1px solid ${value}`,
        //             borderRadius: "2px",
        //             margin: "1px 2px 2px 0px",
        //             marginLeft: index === 0 ? "2px" : "0"
        //           }
        //         });
        //       })
        //     );
        //   },
        // },
        {
          key: "action",
          title: "操作",
          align: "center",
          showOverflowTooltip: false,
          width: 134,
          render: (h, { row, column, index }) => {
            let self = this;
            return h("div", {
              class: 'table-action-button-container'
            },[
              // 在状态为待审核和审核不通过时可以编辑
              h("vbuttonSprite", {
                props: {
                  pos: {
                    normal: { x: 0, y: -19 },
                    hover: { x: -18, y: -19 },
                    disabled: { x: -36, y: -19 }
                  },
                  disabled: "" + row.status !== "1" && "" + row.status !== "3",
                  title: "编辑"
                },
                style: {
                  verticalAlign: "middle",
                  marginRight: "20px"
                },
                on: {
                  click: () => {
                    self.modifyRoadshow(row);
                  }
                }
              }),
              // 在状态为已审核时可以预览
              h("vbuttonSprite", {
                props: {
                  pos: {
                    normal: { x: 0, y: -295 },
                    hover: { x: -18, y: -295 },
                    disabled: { x: -36, y: -295 }
                  },
                  disabled: "" + row.status !== "4",
                  title: "预览"
                },
                style: {
                  verticalAlign: "middle",
                  marginRight: "20px"
                },
                on: {
                  click: () => {
                    self.previewRoadshow(row);
                  }
                }
              }),
              h("vbuttonSprite", {
                props: {
                  pos: {
                    normal: { x: 0, y: -241 },
                    hover: { x: -18, y: -241 },
                    disabled: { x: -36, y: -241 }
                  },
                  title: "删除",
                  disabled: "" + row.status !== "1"
                },
                style: {
                  verticalAlign: "middle",
                  marginRight: "20px"
                },
                on: {
                  click: e => {
                    this.deleteRoadshow(row);
                  }
                }
              })
            ]);
          }
        }
      ],
      tableData: [],
      recordId: "",
      recordKey: ""
    };
  },
  mounted() {
    this.getRoadshowList();
  },
  methods: {
    // 获取路演列表
    getRoadshowList(keepCurrentRow = false) {
      this.loading = true;

      if (!keepCurrentRow) {
        this.currentRowId = "";
      }

      let params = Object.assign(
        {
          pageNo: 1,
          pageSize: 1000
        },
        this.searchFormValue
      );
      this.$http.get("roadshow", params).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          if (res.data.records.length) {
            this.tableData = JSON.parse(JSON.stringify(res.data.records));
            this.totalItem = res.data.total;
          } else {
            // 在删除table数据的时候，如果某一页删完了，需要获得上一页的数据
            if (this.page > 1) {
              this.page -= 1;
              this.getPersonList();
            } else {
              this.tableData = [];
            }
          }
        } else {
          this.tableData = [];
        }
        this.$nextTick(() => {
          this.$refs.table.setCurrentRow("id", this.currentRowId);
        });
      });
    },
    refresh() {
      // this.key = Date.now();
      this.getRoadshowList();
    },
    // 条件搜索路演
    searchRoadshow() {
      this.page = 1;
      this.pageSize = 10;
      this.getRoadshowList();
      this.$refs.table.refresh();
    },
    // 分页器变化
    pageSizeChange(val) {
      this.pageSize = val;
      this.getRoadshowList();
    },
    pageChange(val) {
      this.page = val;
      this.getRoadshowList();
    },
    // 打开新增和修改路演modal
    addRoadshow() {
      this.$refs.addModal.open("add");
    },
    modifyRoadshow(rowData) {
      this.$refs.addModal.getRoadshowInfo(rowData.id);
      this.$refs.addModal.open("modify");
    },
    previewRoadshow(row) {
      // if(row.paramQueryId){
      //   window.open(this.$baseUrl[process.env.NODE_ENV]['roadshow'] + '/info/?rid='+row.paramQueryId)
      // }
      if (row.tempLinkPath) {
        let videoUrl =
          this.$baseUrl[process.env.NODE_ENV]["staticFile"] + row.tempLinkPath;
        this.$refs.previewModal.open(videoUrl);
      }
    },
    // 删除路演
    deleteRoadshow(row) {
      this.$confirm(
        `确认删除<b style="color:#fff">&nbsp;${row.topic}&nbsp;</b>吗?`,
        "删除",
        {
          showCancelButton: true,
          dangerouslyUseHTMLString: true,
          type: "warning",
          closeOnClickModal: false,
          beforeClose: (action, instance, done) => {
            if (action === "confirm") {
              instance.confirmButtonLoading = true;
              instance.confirmButtonText = "删除中...";
              this.$http.del("roadshow", row.id).then(res => {
                done();
                instance.confirmButtonLoading = false;
                if (!res) return;
                if (res.code == 20000) {
                  this.getRoadshowList();
                  this.$message.success("删除路演成功!");
                } else {
                  this.$message.error(res.msg);
                }
              });
            } else {
              done();
            }
          }
        }
      );
    },
    // 设置点击表格某一行高亮
    tableRowClick({ row, column, index }) {
      this.currentRowId = row.id;
      this.$refs.table.setCurrentRow("id", this.currentRowId);
    }
  }
};
</script>

<style lang="less" scoped>
.roadshow-wrapper {
  position: relative;
}
.roadshow-video-preview {
  top: 5%;
}
</style>

