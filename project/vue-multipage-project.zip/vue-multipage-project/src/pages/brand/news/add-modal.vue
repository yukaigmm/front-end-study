<template>
  <vmodal
    :title="`${status === 'add' ? '新增' :'编辑'}资讯`"
    ref="addModal"
    class="news-add-modal t2-el-dialog"
    @close="cancel"
    :width="720"
  >
    <vformConfig ref="addForm" :config="addFormConfig" v-model="formValue"></vformConfig>
    <div class="user-list-icon" @click.stop="showAuthorSelect" :style="iconPosition">
      <div class="user-select-container" v-show="showAuthorList">
        <ul class="user-select">
          <li
            v-for="(item,index) in authorList"
            :key="index"
            @click.stop="selectAuthor(item)"
          >{{item.personnelName}}</li>
        </ul>
      </div>
    </div>
    <div slot="modal-footer">
      <vbutton @click="cancel">取消</vbutton>
      <vbutton active @click="submit">提交</vbutton>
    </div>
    <vloading slot="loading" v-model="modalLoading"></vloading>
  </vmodal>
</template>

<script>
import { validatePhoneNumber } from "../../../common/js/validator.js";
export default {
  data() {
    return {
      modalLoading: false,
      authorList: [],
      showAuthorList: false,
      status: "",
      newsId: "",
      formValue: {},
      authorId: "",
      previewUrl: "",
      preValue: "",
      currentEditorValue: "",
      iconPosition: ""
    };
  },
  methods: {
    open(status) {
      this.status = status;
      this.setAuthorPosition();
      this.$refs.addModal.open();
    },
    cancel() {
      this.$refs.addModal.close();
      this.formValue = {};
      this.authorId = "";
      this.$refs.addForm.resetValid();
    },
    // 获取主讲人列表
    getAuthorList() {
      this.$http.post("datadis/company/getSelfPersonnel").then(res => {
        if (res.code !== 20000) {
          this.$message({
            showClose: true,
            message: res.msg,
            type: "error"
          });
          return;
        }
        this.authorList = JSON.parse(JSON.stringify(res.data));
      });
    },
    // 显示主讲人列表
    showAuthorSelect() {
      this.showAuthorList = true;
    },
    // 选择主讲人
    selectAuthor(item) {
      this.$set(this.formValue, "author", item.personnelName);
      this.$nextTick(() => {
        $('div[item-key="author"] input')
          .trigger("focus")
          .trigger("blur");
        $(".news-add-modal .edit-container .w-e-toolbar").css({
          display: "flex"
        });
        $(".news-add-modal .edit-container .w-e-text-container w-e-text").css({
          paddingBottom: "15px"
        });
      });
      this.showAuthorList = false;
    },
    // 修改时获取资讯详情
    getNewsInfo(id) {
      this.newsId = id;
      this.modalLoading = true;
      this.$http
        .get(`article/${id}`)
        .then(res => {
          if (res.code === 20000) {
            let data = JSON.parse(JSON.stringify(res.data));
            this.formValue = data;

            if (this.formValue.articleFile) {
              this.formValue.articleFile = {
                filePath: this.formValue.articleFile,
                fileName: this.formValue.articleFilename
              };
            }
            // if (this.formValue.imageUrl) {
            // 	this.formValue.imageUrl = {
            // 		filePath: this.formValue.imageUrl,
            // 		fileName: this.formValue.imageName,
            // 	};
            // }
          }
        })
        .done(() => {
          this.modalLoading = false;
        });
    },
    // 提交资讯信息
    submit() {
      if (!(window.sessionStorage.getItem("canSend") === "false")) {
        this.modalLoading = true;
      }
      this.$refs.addForm.valid().then(valid => {
        if (valid) {
          let params = this.getSubmitParams(
            JSON.parse(JSON.stringify(this.formValue))
          );
          if (this.status === "add") {
            this.addNews(params);
          } else {
            this.modifyNews(params);
          }
        } else {
          this.modalLoading = false;
        }
      });
    },
    getSubmitParams(data) {
      let article = JSON.parse(JSON.stringify(data.articleFile));
      data.articleFile = article.filePath;
      data.articleFilename = article.fileName;
      // data.imageUrl = data.imageUrl.filePath;

      return data;
    },
    // 验证AuthorId和name是否一致
    validateAuthorId(id, name) {
      for (let item of this.authorList) {
        if (item.personnelName === name && item.personnelId === id) {
          return true;
        }
      }
      return false;
    },
    // 新增资讯
    addNews(params) {
      this.$http.post("article", params).then(res => {
        this.modalLoading = false;
        if (!res) return;
        if (res.code === 20000) {
          //监听资讯发布事件
          sa.event("fundMaster_addNews", {});

          this.cancel();
          this.$emit("getNewsList");
          this.$message.success("新增资讯成功");
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 修改资讯
    modifyNews(params) {
      this.$http.put(`article/${this.newsId}`, params).then(res => {
        this.modalLoading = false;
        if (!res) return;
        if (res.code === 20000) {
          this.cancel();
          this.$emit("getNewsList");
          this.$message.success("修改资讯成功");
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    //设置主讲人图标的位置
    setAuthorPosition() {
      setTimeout(() => {
        let offsetLeft = document.querySelector('div[item-key="author"]')
          .offsetLeft;
        let offsetTop = document.querySelector('div[item-key="author"]')
          .offsetTop;
        let itemLength = document.querySelector('div[item-key="author"]')
          .offsetWidth;
        this.iconPosition = {
          left: offsetLeft + itemLength - 31 + "px",
          top: offsetTop + 1 + "px"
        };
      }, 100);
    }
  },
  mounted() {
    this.getAuthorList();
    document.addEventListener("click", () => {
      this.showAuthorList = false;
    });
  },
  computed: {
    addFormConfig() {
      return {
        cols: 12,
        labelWidth: 100,
        fields: [
          [
            {
              label: "标题",
              // labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "articleTitle",
                  compType: "vtextArea",
                  rules: [{ required: true, message: "请输入标题" }]
                }
              ]
            }
          ],
          [
            {
              label: "资讯文件",
              // labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "articleFile",
                  compType: "vfileUpload",
                  compConfig: {
                    url: "common/upFile",
                    fileName: "articleAttach",
                    resName: "fileName"
                  },
                  rules: [{ required: true, message: "请选择资讯文件" }]
                }
              ]
            }
          ],
          [
            {
              label: "作者",
              // labelWidth: 90,
              colspan: 6,
              comps: [
                {
                  key: "author",
                  compType: "vinput",
                  rules: [{ required: true, message: "请输入或选择主讲人" }]
                }
              ]
            }
          ],
          [
            {
              label: "发布时间",
              colspan: 6,
              comps: [
                {
                  key: "postTime",
                  compType: "vdatePicker",
                  compConfig: {
                    placeholder: "请选择"
                  }
                }
              ]
            }
          ],
          [
            {
              label: "是否定时发布",
              // labelWidth: 90,
              colspan: 6,
              comps: [
                {
                  key: "postStatus",
                  compType: "vswitch",
                  compConfig: {
                    type: "checkbox",
                    trueValue: 1,
                    falseValue: 0,
                    trueLabel: ""
                  }
                }
              ]
            }
          ],
          [
            {
              label: "宣传图片",
              // labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "imageUrl",
                  compType: "vimageUpload",
                  compConfig: {
                    url: "common/upFile",
                    fieldName: "articlePic",
                    imgStyle: {
                      width: "auto",
                      height: "150px",
                      minWidth: "150px",
                      maxWidth: "100%"
                    }
                  },
                  rules: [{ required: true, message: "请上传宣传图片" }]
                }
              ]
            }
          ],
          [
            {
              label: "图片描述",
              // labelWidth: 90,
              colspan: 12,
              comps: [
                {
                  key: "imageAlt",
                  compType: "vtextArea",
                  compConfig: {
                    placeHolder:
                      this.status === "add" ? "默认使用标题内容展示" : ""
                  }
                }
              ]
            }
          ]
        ]
      };
    }
  }
};
</script>


<style lang="less">
.news-add-modal {
  // min-width: 0px;
  // width: 720px;
  // height: 630px !important;
  // top: 7% !important;
  .content {
    position: relative;
  }
  // 资讯主题下拉列表样式设置
  .select-wrapper .dropdown-content {
    max-height: 151px;
  }
  // 主讲人列表icon
  .user-list-icon {
    width: 30px;
    height: 24px;
    background: url("../../../assets/images/users.svg") no-repeat center right;
    cursor: pointer;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 999;
    // right: 12px;
    background-color: #1a1a1a;
    .user-select-container {
      position: absolute;
      z-index: 999;
      &:before {
        content: "";
        position: absolute;
        top: 32px;
        right: -20px;
        width: 0px;
        height: 0px;
        border: 8px solid #202020;
        border-right-color: transparent;
        border-bottom-color: transparent;
        transform: rotate(45deg);
      }
    }
    // 主讲人列表
    ul.user-select {
      width: 140px;
      max-height: 240px;
      margin: 0;
      overflow: auto;
      background-color: #202020;
      position: absolute;
      left: -100px;
      top: 40px;
      // 此处设置z-index 999 ,编译出来之后是1，因此样式在common.less中设置了
      // z-index: 999 !important;
      box-shadow: 0 0 10px #666;
      li {
        height: 34px;
        line-height: 34px;
        // border-bottom: 1px solid #444;
        color: #eee;
        text-align: center;
        &:hover {
          background: #333;
        }
      }
    }
  }
  .edit-container {
    position: relative;
    .w-e-toolbar {
      position: absolute;
      bottom: 0;
      left: 0;
      // display: flex !important;
      display: none;
      width: 100%;
      height: 25px;
      padding-bottom: 3px;
      .w-e-menu {
        i {
          color: #666;
        }
        &:hover {
          i {
            color: #aaa;
          }
        }
      }
    }
  }
  .w-e-text-container {
    .w-e-text {
      max-height: 100px !important;
      p {
        margin: 5px 0;
      }
    }
  }
}
</style>

