<template>
  <vcommon :menuParentKey="currentMenuParentKey" :menuChildKey="currentMenuChildKey">
    <div style="height:100%">
      <vpart title="公司资讯信息">
        <div slot="search">
          <vselect
            v-model="searchForm.auditStatus"
            @change="searchNews"
            :options="newsStatusOption"
          ></vselect>
          <vinput
            type="text"
            class="table-search-input"
            style="display: inline-block;"
            @keyup.enter.native="searchNews"
            v-model="searchForm.keyword"
            placeholder="关键字搜索(资讯标题)"
          ></vinput>
          <vbutton active title="搜索" @click="searchNews">搜索</vbutton>
        </div>
        <div slot="action">
          <vbutton active title="添加资讯" @click="addNews">新增</vbutton>
        </div>
        <vtable
          :key="key"
          ref="table"
          :columns="columns"
          :data="tableData"
          :usePagination="true"
          :totalItem="totalItem"
          layout="total"
          :currentPage="pageNo"
          :rowKey="row => row.articleId"
          :maxHeight="maxHeight"
          @pageChange="pageChange"
          @pageSizeChange="pageSizeChange"
          @tableRowClick="tableRowClick"
          style="position: relative"
        ></vtable>
        <vloading class="loading" v-model="loading"></vloading>
      </vpart>

      <!-- 新增modal -->
      <add-modal ref="addModal" @getNewsList="getNews"></add-modal>
    </div>
  </vcommon>
</template>

<script>
import tableHeight from "../../../common/mixins/table-height.js";
import addModal from "./add-modal.vue";

// import { getSessionOption } from "../../../common/js/utils";
export default {
  components: {
    addModal
  },
  mixins: [tableHeight],
  data() {
    return {
      currentMenuParentKey: "brand",
      currentMenuChildKey: "news",
      currentCompany: "",
      totalItem: 0,
      page: 1,
      pageSize: 1000,
      loading: false,
      newsStatusOption: [
        {
          label: "全部状态",
          value: 0
        },
        {
          label: "待审核",
          value: 1
        },
        {
          label: "待发布",
          value: 2
        },
        {
          label: "已发布",
          value: 3
        },
        {
          label: "已拒绝",
          value: 4
        }
      ],
      currentNewsId: "",
      status: "add",
      searchForm: {
        auditStatus: 0,
        keyword: ""
      },
      columns: [
        {
          key: "articleTitle",
          title: "标题",
          showOverflowTooltip: false,
          render: (h, { row, column, index }) => {
            return h(
              "div",
              {
                style: {
                  width: "100%",
                  height: "100%",
                  position: "relative"
                }
              },
              [
                h("span", {
                  style: {
                    display: "block",
                    width: "100%",
                    color: "#999",
                    fontWeight: "normal",
                    maxHeight: "112px",
                    lineHeight: "2",
                    overflow: "hidden"
                  },
                  domProps: {
                    innerHTML: row.articleTitle
                  }
                })
              ]
            );
          }
        },
        {
          key: "author",
          title: "作者",
          width: 100,
          render(h, { row }) {
            return row.author || "--";
          }
        },
        {
          key: "postStatus",
          title: "是否定时发布",
          width: 100,
          render: (h, { row }) => {
            return h("span", row.postStatus ? "是" : "否");
          }
        },
        {
          key: "postTime",
          title: "发布时间",
          width: 100,
          render: (h, { row }) => {
            let time = row.postTime ? row.postTime.split(" ")[0] : "--";
            return h("span", time || "--");
          }
        },
        {
          key: "imageAlt",
          title: "图片描述",
          width: 150
        },
        {
          key: "auditStatus",
          title: "文章状态",
          width: 100,
          render: (h, { row }) => {
            let map = {
              1: "待审核",
              2: "待发布",
              3: "已发布",
              4: "已拒绝",
              5: "已撤回"
            };
            return h("div", [
              h("span", map[row.auditStatus]),
              row.auditStatus === 4
                ? h("vtooltip", {
                    props: {
                      title: "原因",
                      explains: row.auditRemark,
                      placement: "bottom",
                      showIndex: false
                    },
                    style: {
                      marginLeft: "2px"
                    }
                  })
                : ""
            ]);
          }
        },
        {
          key: "action",
          title: "操作",
          align: "center",
          showOverflowTooltip: false,
          width: 134,
          render: (h, { row, column, index }) => {
            let self = this;
            return h("div", {
              class: 'table-action-button-container'
            },[
              h("vbuttonSprite", {
                props: {
                  pos: {
                    normal: { x: 0, y: -19 },
                    hover: { x: -18, y: -19 },
                    disabled: { x: -36, y: -19 }
                  },
                  title: "编辑",
                  disabled: !(row.auditStatus === 1 || row.auditStatus === 4)
                },
                style: {
                  verticalAlign: "middle",
                  marginRight: "20px"
                },
                on: {
                  click: () => {
                    self.modifyNews(row);
                  }
                }
              }),
              h("vbuttonSprite", {
                props: {
                  pos: {
                    normal: { x: 0, y: -241 },
                    hover: { x: -18, y: -241 },
                    disabled: { x: -36, y: -241 }
                  },
                  title: "删除",
                  disabled: !(row.auditStatus === 1 || row.auditStatus === 4)
                },
                style: {
                  verticalAlign: "middle",
                  marginRight: "20px"
                },
                on: {
                  click: e => {
                    this.deleteNews(row);
                  }
                }
              }),
              row.auditStatus === 3 && row.articleUrl
                ? h("vbuttonSprite", {
                    props: {
                      pos: {
                        normal: { x: 0, y: -259 },
                        hover: { x: -18, y: -259 },
                        disabled: { x: -36, y: -259 }
                      },
                      title: "官网链接"
                    },
                    style: {
                      verticalAlign: "middle"
                    },
                    on: {
                      click: e => {
                        // this.deleteNews(row);
                        this.viewArticle(row.articleUrl);
                      }
                    }
                  })
                : ""
            ]);
          }
        }
      ],
      tableData: [],
      recordId: "",
      recordKey: ""
    };
  },
  mounted() {
    this.getNews();
  },
  methods: {
    // 获取资讯列表
    getNews(keepCurrentRow = false) {
      this.loading = true;

      if (!keepCurrentRow) {
        this.currentRowId = "";
      }

      let params = Object.assign(
        {
          pageNo: 1,
          pageSize: 1000
        },
        this.searchForm
      );
      this.$http.get("article", params).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          if (res.data.records.length) {
            this.tableData = JSON.parse(JSON.stringify(res.data.records));
            this.totalItem = res.data.total;
          } else {
            // 在删除table数据的时候，如果某一页删完了，需要获得上一页的数据
            if (this.page > 1) {
              this.page -= 1;
              this.getPersonList();
            } else {
              this.tableData = [];
            }
          }
        } else {
          this.tableData = [];
        }
        this.$nextTick(() => {
          this.$refs.table.setCurrentRow("id", this.currentRowId);
        });
      });
    },
    refresh() {
      // this.key = Date.now();
      this.getNews();
    },
    // 条件搜索资讯
    searchNews() {
      this.page = 1;
      this.pageSize = 10;
      this.getNews();
      this.$refs.table.refresh();
    },
    // 分页器变化
    pageSizeChange(val) {
      this.pageSize = val;
      this.getNews();
    },
    pageChange(val) {
      this.page = val;
      this.getNews();
    },
    // 打开新增和修改modal
    addNews() {
      this.$refs.addModal.open("add");
    },
    modifyNews(rowData) {
      this.$refs.addModal.getNewsInfo(rowData.articleId);
      this.$refs.addModal.open("modify");
    },
    // 删除
    deleteNews(row) {
      this.$confirm(
        `确认删除<b style="color:#fff">&nbsp;${row.articleTitle}&nbsp;</b>吗?`,
        "删除",
        {
          showCancelButton: true,
          dangerouslyUseHTMLString: true,
          type: "warning",
          closeOnClickModal: false,
          beforeClose: (action, instance, done) => {
            if (action === "confirm") {
              instance.confirmButtonLoading = true;
              instance.confirmButtonText = "删除中...";
              this.$http.del("article", row.articleId).then(res => {
                done();
                instance.confirmButtonLoading = false;
                if (!res) return;
                if (res.code == 20000) {
                  this.getNews();
                  this.$message.success("删除资讯成功!");
                } else {
                  this.$message.error(res.msg);
                }
              });
            } else {
              done();
            }
          }
        }
      );
    },
    viewArticle(articleUrl) {
      window.open(`${articleUrl}`);
    },
    // 设置点击表格某一行高亮
    tableRowClick({ row, column, index }) {
      this.currentRowId = row.articleId;
      this.$refs.table.setCurrentRow("articleId", this.currentRowId);
    }
  }
};
</script>

<style lang="less" scoped>
.news-wrapper {
  position: relative;
}
.news-video-preview {
  top: 5%;
}
</style>

