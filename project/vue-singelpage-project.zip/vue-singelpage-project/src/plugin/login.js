import { fetchLogin } from "../service/getData"
import { isEmpty } from "lodash"
import router from '../router'
import { warning,config } from "../service/notify.js"
import store from "../store/index.js"
class Login {
  constructor() {

  }

  //   获取url中返回的参数
  getQueryParams() {
    let windowParams = JSON.parse(JSON.stringify(window.location));
    let queryString = windowParams.search.slice(1);
    let queryStringArr = queryString.split("&");
    let params = {};
    queryStringArr
      .filter(item => {
        return (item.indexOf("=") !== -1)
      })
      .forEach(item => {
        let [key, value] = item.split("=");
        params[key] = value;
      })
    return params;
  }

  // 登录
  loginIn() {
    let queryParams = this.getQueryParams();
    let params = Object.assign({}, queryParams);
    //url中没有参数直接跳到登录页
    if (isEmpty(params)) {
      store.dispatch('setIfBinded',{ifBinded:true})
      router.push('/login');
    } else {
        // url中有参数进行登录请求
      fetchLogin(params).then(res => {
        if (res.code === 20000) {
          store.dispatch('setIfBinded',{ifBinded:true})
          router.push('/index');
        } else {
          // warning({
          //   content:"<p style='text-align:left'>您已经通过微信扫码成功登陆！<br/> 第一次使用微信扫码登录，需要输入用户名和密码确认系统身份。 <br/> 身份确认仅需一次，谢谢配合！</p>",
          //   duration:0,
          //   closable:true,
          // });
          store.dispatch('setIfBinded',{ifBinded:false})
          router.push('/login');
        }
      })
    }
  }
}

const wxLogin = () => {
  let login = new Login();
  login.loginIn();
}

export {
  wxLogin,
}
