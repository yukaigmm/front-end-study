import Vue from 'vue'
import iView from 'iview'
// import wordcloud from "js2wordcloud"
import managerPoptip from "../page/account-justify/support/poptip.vue"
import remarkPoptip from "../page/welcome-page/support/remark-poptip.vue"
import YModal from "../components/y-modal.vue"
import {
  Select,
  Option,
  Loading,
  Cascader,
  Tree,
  Table,
  Form,
  FormItem,
  TableColumn,
  Button as elButton
} from 'element-ui'
Vue.use(Select)
Vue.use(Option)
Vue.use(Table)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(TableColumn)
Vue.use(Loading.directive)
Vue.use(Cascader)
Vue.use(Tree)
Vue.use(elButton)
Vue.use(iView)
// Vue.use(wordcloud)
Vue.component("managerPoptip",managerPoptip);
Vue.component("remarkPoptip",remarkPoptip);
Vue.component("YModal",YModal);