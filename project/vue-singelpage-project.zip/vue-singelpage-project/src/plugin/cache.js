import store from '@/store'
import {
  isEmpty,
  filter,
  get,
  first
} from 'lodash'
const getCache = (type, values = false, enums) => {
  let cacheData = store.getters.getEnums
  let data = cacheData[type]
  if (values !== false) {
    let name = get(first(filter(data, (item) => {
      return item.value === `${values}`
    })), 'name')
    return isEmpty(name) ? '未知' : name
  }
  return data
}

export {
  getCache
}
