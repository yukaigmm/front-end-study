import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)


const login = () => import('@/page/login/index');
const index = () => import('@/page/index/index');

export default new Router({
  // mode: 'history',
  routes: [{
      path: '/',
      redirect: '/login'
    },
    {
      path: '/login',
      component: login
    },
    {
      path: '/index',
      component: index,
    },
    {
      path: '*',
      component: require('@/page/not-found/not-found')
    }
  ]
})
