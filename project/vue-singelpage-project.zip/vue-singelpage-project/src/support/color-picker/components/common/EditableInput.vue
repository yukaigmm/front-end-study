<template>
  <div class="editable-input">
    <input class="input__input"
      ref="input"
      v-model="val"
      @keydown="handleKeyDown"
      @input="update">
    <span class="input__label" v-if="label">{{label}}</span>
  </div>
</template>

<script>
export default {
  name: 'editableInput',
  props: {
    label: String,
    value: [String, Number],
    max: Number,
    min: Number,
    arrowOffset: {
      type: Number,
      default: 1
    }
  },
  computed: {
    val () {
      return this.value
    }
  },
  filters: {
    maxFilter: {
      read (val) {
        if (this.max && val > this.max) {
          return this.max
        } else {
          return val
        }
      },
      write (val, oldVal) {
        return val
      }
    }
  },
  methods: {
    update (e) {
      this.handleChange(e.target.value)
    },
    handleChange (newVal) {
      let data = {};
      if(typeof this.max == 'number') {
        newVal = newVal > this.max ? this.max : newVal;
        this.$refs.input.value = newVal;
      }
      if(typeof this.min == 'number') {
        newVal = newVal < this.min ? this.min : newVal;
        this.$refs.input.value = newVal;
      }
      data[this.label] = newVal
      if (data.hex === undefined && data['#'] === undefined) {
        this.$emit('change', data)
      } else if (newVal.length > 5) {
        this.$emit('change', data)
      }
    },
    handleBlur (e) {

    },
    handleKeyDown (e) {
      let val = this.val
      let number = Number(val)

      if (number) {
        let amount = this.arrowOffset || 1

        // Up
        if (e.keyCode === 38) {
          val = number + amount
          this.handleChange(val)
          e.preventDefault()
        }

        // Down
        if (e.keyCode === 40) {
          val = number - amount
          this.handleChange(val)
          e.preventDefault()
        }
      }
    },
    handleDrag (e) {

    },
    handleMouseDown (e) {
      
    }
  }
}
</script>

<style scoped>
.editable-input {
  position: relative;
}
.input__input {
  padding: 0;
  border: 0;
  outline: none;
}
.input__label {
  text-transform: capitalize;
}
</style>
