<template lang="html">
  <div class="m-colorPicker" ref="colorPicker" v-bind:style="parentCustomStyle" @click="pickerClick">
    <!-- 颜色显示小方块 -->
    <div class="colorBtn"
    v-bind:style="computedStyle"
    v-on:click="toggleBox"
    v-bind:class="[customClass, showColor==='transparent' ? 'transparent' : '']"
    ></div>

    <!-- 颜色色盘 -->
    <div class="box" v-bind:class="{ open: openStatus }"  :style="computedBoxStyle" @click.stop="() => false">
      <!-- 用以激活HTML5颜色面板 -->
      <div class="chrome-container" v-show="sketchStatus" @click.stop>
        <!-- <chrome :value="sketchColor" @input="updateSkecthColor" :customColors="[]"></chrome> -->
        <Chrome :value="sketchColor" @input="updateSkecthColor"></Chrome>
        <Button @click="confirmSketch" type="primary">确定</Button>
        <Button @click="cancelSketch" >取消</Button>
      </div>
      <div class="default-container" v-show="!sketchStatus">
        <div class="hd">
          <div class="colorView" v-bind:style="`background-color: ${showPanelColor}`"></div>
          <div class="defaultColor"
          v-if="hasTransparentColor"
          v-on:click="handleColor('transparent')"
          v-on:mouseover="hoveColor = 'transparent'"
          v-on:mouseout="hoveColor = null"
          >透明色</div>
          <div class="defaultColor"
          v-else
          v-on:click="handleColor(defaultColor)"
          v-on:mouseover="hoveColor = defaultColor"
          v-on:mouseout="hoveColor = null"
          >默认颜色</div>
        </div>
        <div class="bd">
          <h3>主题颜色</h3>
          <ul class="tColor">
            <li
            v-for="color of tColor"
            v-bind:style="{ backgroundColor: color }"
            v-on:mouseover="hoveColor = color"
            v-on:mouseout="hoveColor = null"
            v-on:click="updataValue(color)"
            ></li>
          </ul>
          <ul class="bColor">
            <li v-for="item of colorPanel">
              <ul>
                <li
                v-for="color of item"
                v-bind:style="{ backgroundColor: color }"
                v-on:mouseover="hoveColor = color"
                v-on:mouseout="hoveColor = null"
                v-on:click="updataValue(color)"
                ></li>
              </ul>
            </li>
          </ul>
          <template v-if="bColor.length">
            <h3>标准颜色</h3>
            <ul class="tColor">
              <li
              v-for="color of bColor"
              v-bind:style="{ backgroundColor: color }"
              v-on:mouseover="hoveColor = color"
              v-on:mouseout="hoveColor = null"
              v-on:click="updataValue(color)"
              ></li>
            </ul>
          </template>
          <h3 v-on:click="triggerHtml5Color" style="cursor:pointer">更多颜色...</h3>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import Chrome from './components/Chrome'
  export default {
    name: 'colorPicker',
    components: {
      Chrome
    },
    props: {
    // 当前颜色值
    value: {
      type: String,
      // required: true
    },
    // 默认颜色
    defaultColor: {
      type: String,
      default: '#000'
    },
    // 禁用状态
    disabled: {
      type: Boolean,
      default: false
    },
    fundIndex: {
      type: Number,
    },
    parentCustomStyle: {
      type: Object,
      default: () => {
        return {}
      }
    },
    customStyle: {
      type: Object,
      default: () => {
        return {}
      }
    },
    customClass: {
      type: String,
    },
    boxStyle: {
      type: Object,
    },
    needPostion: {
      type: Boolean,
      default: true
    },
    hasTransparentColor: {
      type: Boolean,
      default: true
    }
  },
  data () {
    return {
      // 面板打开状态
      openStatus: false,
      // 鼠标经过的颜色块
      hoveColor: null,
      //更多颜色状态
      sketchStatus: false,
      sketchColor: {},
      // 主题颜色
      tColor: ['#000', '#fff', '#eeece1', '#1e497b', '#4e81bb', '#e2534d', '#9aba60', '#8165a0', '#47acc5', '#f9974c'],
      // 颜色面板
      colorConfig: [
      ['#7f7f7f', '#f2f2f2'],
      ['#0d0d0d', '#808080'],
      ['#1c1a10', '#ddd8c3'],
      ['#0e243d', '#c6d9f0'],
      ['#233f5e', '#dae5f0'],
      ['#632623', '#f2dbdb'],
      ['#4d602c', '#eaf1de'],
      ['#3f3150', '#e6e0ec'],
      ['#1e5867', '#d9eef3'],
      ['#99490f', '#fee9da']
      ],
      // 标准颜色
      bColor: ['#ff4455', '#2e4ad8', '#00bbff', '#7499cf', '#612b82', '#edd600', '#ba00a4', '#ffaa00', '#009999', '#86b94c'],
      // bColor: [],
      html5Color: this.value,
      index: this.fundIndex,
      sideLength: 26,
      top: 0,
      left: 0,
    }
  },
  watch: {
  },
  computed: {
    computedStyle () {
      return {
        'width':`${this.sideLength}px`,
        'height':`${this.sideLength}px`,
        'background-color': `${this.showColor}`,
        ...this.customStyle
      }
    },
    computedBoxStyle () {
      return {
        top: this.needPostion ?`${this.top+this.sideLength}px` : 'auto',
        left: this.needPostion ? `${this.left+this.sideLength}px` : 'auto',
        ...this.boxStyle
      }
    },
    // 显示面板颜色
    showPanelColor () {
      if (this.hoveColor) {
        return this.hoveColor
      } else {
        return this.showColor
      }
    },
    // 显示颜色
    showColor () {
      if (this.value) {
        return this.value
      } else {
        return this.defaultColor
      }
    },
    // 颜色面板
    colorPanel () {
      let colorArr = []
      for (let color of this.colorConfig) {
        colorArr.push(this.gradient(color[1], color[0], 5))
      }
      return colorArr
    }
  },
  methods: {
    triggerHtml5Color () {
      this.sketchColor = {
        hex: this.value,
      }
      this.sketchStatus = true;
    },
    // 更新组件的值 value
    updataValue (value) {
      this.$emit('input', value)
      this.$emit('change', value, this.index)
      this.openStatus = false
    },
    // 设置默认颜色
    handleColor (color) {
      this.updataValue(color)
    },
    // 格式化 hex 颜色值
    parseColor (hexStr) {
      if (hexStr.length === 4) {
        hexStr = '#' + hexStr[1] + hexStr[1] + hexStr[2] + hexStr[2] + hexStr[3] + hexStr[3]
      } else {
        return hexStr
      }
    },
    // RGB 颜色 转 HEX 颜色
    rgbToHex (r, g, b) {
      let hex = ((r << 16) | (g << 8) | b).toString(16)
      return '#' + new Array(Math.abs(hex.length - 7)).join('0') + hex
    },
    // HEX 转 RGB 颜色
    hexToRgb (hex) {
      hex = this.parseColor(hex)
      let rgb = []
      for (let i = 1; i < 7; i += 2) {
        rgb.push(parseInt('0x' + hex.slice(i, i + 2)))
      }
      return rgb
    },
    // 计算渐变过渡颜色
    gradient (startColor, endColor, step) {
      // 讲 hex 转换为 rgb
      let sColor = this.hexToRgb(startColor)
      let eColor = this.hexToRgb(endColor)

      // 计算R\G\B每一步的差值
      let rStep = (eColor[0] - sColor[0]) / step
      let gStep = (eColor[1] - sColor[1]) / step
      let bStep = (eColor[2] - sColor[2]) / step

      let gradientColorArr = []
      // 计算每一步的hex值
      for (let i = 0; i < step; i++) {
        gradientColorArr.push(this.rgbToHex(parseInt(rStep * i + sColor[0]), parseInt(gStep * i + sColor[1]), parseInt(bStep * i + sColor[2])))
      }
      return gradientColorArr
    },
    toggleBox (e) {
      // this.openStatus = !this.openStatus
      let target = e.target;
      this.top = ($(target).offset().top);
      this.left = ($(target).offset().left);
      this.$emit("status", this.index, this.openStatus)
    },
    pickerClick (e) {
      if(this.openStatus){
        this.openStatus = false;
      }else {
        setTimeout( () => {
          this.openStatus = true;
        }, 0)
      }
    },
    getCustomStyle (style) {
      let str = '';
      _.forEach(style, (value, key) => {
        str += `${key}:${value};`;
      })

      return str;
    },
    updateSkecthColor (val) {
      let {r,g,b,a} = val.rgba;
      let color = `rgba(${r}, ${g}, ${b}, ${a})`;
      this.hoveColor = color;
    },
    confirmSketch () {
      this.sketchStatus = false;
      this.updataValue(this.hoveColor ? this.hoveColor :this.value);
    },
    cancelSketch () {
      this.sketchStatus = false;
    }
  },
  mounted () {
    // 点击页面上其他地方，关闭弹窗
    $(document).click( () => {
      this.openStatus = false;
      this.sketchStatus = false;
    })
  }
}
</script>

<style lang="less" scoped>
  .m-colorPicker{
    text-align: left; font-size: 14px; display: inline-block;cursor: pointer;
    ul,li,ol{ list-style: none; margin: 0; padding: 0; }
    input{ display: none; }
    .colorBtn{
      width: 15px; height: 15px;
      &.transparent {
        background-image: url('/static/assets/editor/images/icons/transparent.png')
      }
    }
    .colorBtn.disabled{ cursor: no-drop; }
    .box{
      position: fixed; width: 215px;   visibility: hidden;  opacity: 0; transition: opacity .3s ease;cursor: default;
      h3{ margin: 0; font-size: 14px; font-weight: normal; margin-top: 10px; margin-bottom: 5px; line-height: 1; color:black; }
    }
    .box.open{ visibility: visible; opacity: 1; z-index: 100; }
    .hd{
      overflow: hidden; line-height: 29px;
      .colorView{ width: 100px; height: 30px; float: left; transition: background-color .3s ease; }
      .defaultColor{color:black; width: 80px; float: right; text-align: center; border: 1px solid #ddd; cursor: pointer; }
    }
    .tColor{
      li{ width: 15px; height: 15px; display: inline-block; margin: 0 2px; }
      li:hover{ box-shadow: 0 0 5px rgba(0,0,0,.4); transform: scale(1.3); }
    }
    .bColor{
      li{
        width: 15px; display: inline-block; margin: 0 2px;
        li{ display: block; width: 15px; height: 15px; margin: 0; }
        li:hover{ box-shadow: 0 0 5px rgba(0,0,0,.4); transform: scale(1.3); }
      }
    }
    .default-container {
      border: 1px solid #ddd;border-radius: 2px;background: #fff; margin-top: 2px; padding: 10px; padding-bottom: 5px; box-shadow: 0 0 5px rgba(0,0,0,.15);
    }
    .chrome-container {
      width: 100%;
      margin-top: 2px;
      position: absolute;
      left: 0;
      top: 0;
      border-radius: 2px;
      background-color: #fff;
      padding-bottom: 5px;
      & > button {
        float:right;
        margin-top: 5px;
        margin-right: 5px;
      }
      &:after {
        content: '';
        display: block;
        clear: both;
      }
      .c-chrome {
        width: 100% !important;
        box-sizing: border-box !important;
      }
    }
  }
</style>
