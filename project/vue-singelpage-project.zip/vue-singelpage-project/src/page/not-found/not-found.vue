<template>
  <div style="text-align: center; margin-top: 10px;">
    您所访问的页面不存在！！！！！！3秒后跳转至登录页面
  </div>
</template>

<script>
  export default {
    mounted () {
      setTimeout(() => {
        this.$router.push('/login')
      }, 3000)
    }
  }
</script>
