<template>
  <div class="reply-wrap">
    <Form class="search-area" :label-width="80" @keydown.enter.native.prevent="search">
      <Row>
        <i-col span="8">
          <FormItem label="申请人信息">
            <i-input type="text" v-model.trim="searchData.user_key_word" placeholder="请输入用户名/手机号"/>
          </FormItem>
        </i-col>

        <i-col span="8">
          <FormItem label="处理状态">
            <i-select v-model="searchData.status" clearable>
              <i-option
                v-for="item in statusOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </FormItem>
        </i-col>

        <i-col span="8" style="padding-left:20px;">
          <Button type="primary" @click="search">搜索</Button>
          <Button @click="reset">重置</Button>
        </i-col>
      </Row>

      <Row>
        <i-col span="8">
          <FormItem label="申请时间">
            <DatePicker v-model="searchData.createtime" style="width:100%;" placeholder="请选择申请日期"></DatePicker>
          </FormItem>
        </i-col>
      </Row>
    </Form>

    <div class="table-area">
      <Table
        :data="tableData"
        :columns="columns"
        border
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
      />
    </div>

    <div class="page-load">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      />
    </div>

    <add-remark-modal ref="addRemarkModal" :btn-loading="btnLoading" @ok="editRemark"/>
  </div>
</template>

<script>
import AddRemarkModal from "../fm-callback-reply/components/add-remark.vue";
import setMaxHeightToTable from "@/mixins/setMaxHeightToTable.js";
import moment from "moment";

export default {
  components: {
    AddRemarkModal
  },

  mixins: [setMaxHeightToTable],

  data() {
    return {
      btnLoading: false,
      searchData: {},
      statusOptions: [
        {
          label: "未处理",
          value: 0
        },
        {
          label: "处理中",
          value: 3
        },
        {
          label: "处理完成",
          value: 1
        },
        {
          label: "已拒绝",
          value: 2
        }
      ],
      tableData: [],
      columns: [
        {
          title: "姓名",
          key: "realName",
          width: 120,
          render: (h, { row }) => {
            return h(
              "div",
              {
                attrs: {
                  title: row.realName
                },
                style: {
                  "max-width": "110px",
                  "text-overflow": "ellipsis",
                  overflow: "hidden",
                  "white-space": "nowrap"
                }
              },
              row.realName || "--"
            );
          }
        },
        {
          title: "电话",
          key: "mobile",
          width: 120,
          render: (h, { row }) => {
            return h(
              "div",
              {
                attrs: {
                  title: row.mobile
                },
                style: {
                  "max-width": "110px",
                  "text-overflow": "ellipsis",
                  overflow: "hidden",
                  "white-space": "nowrap"
                }
              },
              row.mobile || "--"
            );
          }
        },
        {
          title: "名片",
          key: "visitingCard",
          width: 100,
          render: (h, { row }) => {
            if (row.visitingCard) {
              return h(
                "a",
                {
                  on: {
                    click: () => {
                      let baseUrl =
                        process.env.NODE_ENV === "production"
                          ? "https://static.simuwang.com"
                          : "https://static-test.simuwang.com";
                      if (row.visitingCard.includes("Uploads/crm/")) {
                        window.open(`${baseUrl}/${row.visitingCard}`);
                      } else {
                        window.open(
                          `${baseUrl}/Uploads/crm/${row.visitingCard}`
                        );
                      }
                    }
                  }
                },
                "查看名片"
              );
            } else {
              return h("span", "--");
            }
          }
        },
        {
          title: "申请类型",
          key: "application",
          width: 100,
          render: (h, { row }) => {
            let mapping = {
              "1": "基金大师",
              "2": "私募直连",
              "3": "蓝V"
            };
            return h(
              "div",
              {
                attrs: {
                  title: mapping[row.application]
                },
                style: {
                  "max-width": "90px",
                  "text-overflow": "ellipsis",
                  overflow: "hidden",
                  "white-space": "nowrap"
                }
              },
              mapping[row.application] || "--"
            );
          }
        },
        {
          title: "申请时间",
          key: "createtime",
          width: 100,
          render: (h, { row }) => {
            return h(
              "div",
              {
                attrs: {
                  title: row.createtime
                },
                style: {
                  "max-width": "90px",
                  "text-overflow": "ellipsis",
                  overflow: "hidden",
                  "white-space": "nowrap"
                }
              },
              row.createtime || "--"
            );
          }
        },

        {
          title: "处理情况",
          key: "status",
          width: 100,
          render: (h, { row }) => {
            let mapping = {
              "0": "未处理",
              "3": "处理中",
              "1": "处理完成",
              "2": "已拒绝"
            };
            return h(
              "div",
              {
                attrs: {
                  title: mapping[row.status]
                },
                style: {
                  "max-width": "90px",
                  "text-overflow": "ellipsis",
                  overflow: "hidden",
                  "white-space": "nowrap"
                }
              },
              mapping[row.status] || "--"
            );
          }
        },
        {
          title: "最后更新时间",
          key: "updatetime",
          width: 100,
          render: (h, { row }) => {
            return h(
              "div",
              {
                attrs: {
                  title: row.updatetime
                },
                style: {
                  "max-width": "90px",
                  "text-overflow": "ellipsis",
                  overflow: "hidden",
                  "white-space": "nowrap"
                }
              },
              row.updatetime || "--"
            );
          }
        },
        {
          title: "最后更新人",
          key: "updaterName",
          width: 120,
          render: (h, { row }) => {
            return h(
              "div",
              {
                attrs: {
                  title: row.updaterName
                },
                style: {
                  "max-width": "110px",
                  "text-overflow": "ellipsis",
                  overflow: "hidden",
                  "white-space": "nowrap"
                }
              },
              row.updaterName || "--"
            );
          }
        },

        {
          title: "备注",
          key: "remark",
          width: 250,
          render: (h, { row }) => {
            return h(
              "div",
              {
                attrs: {
                  title: row.remark
                },
                style: {
                  "max-width": "240px",
                  "text-overflow": "ellipsis",
                  overflow: "hidden",
                  "white-space": "nowrap"
                }
              },
              row.remark || "--"
            );
          }
        },
        {
          title: "操作",
          key: "action",
          width: 150,
          fixed: "right",
          render: (h, { row }) => {
            let actionText = "";
            switch (row.status) {
              case 0:
                actionText = "开始处理";
                break;

              case 3:
                actionText = "处理完成";
                break;
              default:
                break;
            }
            return h("div", [
              h(
                "div",
                {
                  class:
                    row.status != 2 && row.status != 1
                      ? "deleteBtn"
                      : "disabeldBtn",
                  on: {
                    click: () => {
                      switch (row.status) {
                        case 0:
                          this.startDeal(row.id);
                          break;
                        case 3:
                          this.finishDeal(row.id);
                          break;
                        default:
                          break;
                      }
                    }
                  }
                },
                actionText
              ),
              h(
                "div",
                {
                  class: "deleteBtn",
                  on: {
                    click: () => {
                      this.showRemarkModal(row.id, row.remark);
                    }
                  }
                },
                "填写备注"
              )
            ]);
          }
        }
      ],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  mounted() {
    this.getTableList();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".page-load"],
      ".table-area",
      120
    );
  },

  methods: {
    getTableList() {
      let searchData = JSON.parse(JSON.stringify(this.searchData));

      for (let key in searchData) {
        if (!searchData[key] && searchData[key] !== 0) {
          delete searchData[key];
        }
      }

      if (searchData.createtime) {
        searchData.createtime = moment(searchData.createtime).format(
          "YYYY-MM-DD"
        );
      } else {
        delete searchData.createtime;
      }

      let params = {
        pageNo: this.currentPage,
        pageSize: this.pageSize,
        ...searchData
      };
      this.tableLoading = true;
      this.$http
        .get("applyProbationList", params)
        .then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.total = res.data.total;
            this.tableData = res.data.records;
          } else {
            this.$Message.error(`获取列表失败:${res.msg}`);
          }
        })
        .catch(e => {
          console.error(e);
          this.tableLoading = false;
          this.$Message.error("获取列表失败！");
        });
    },

    search() {
      this.pageSize = 10;
      this.currentPage = 1;
      this.getTableList();
    },

    reset() {
      this.searchData = {};
      this.search();
    },

    onPageChange(val) {
      this.currentPage = val;
      this.getTableList();
    },

    onPageSizeChange(val) {
      this.pageSize = val;
      this.getTableList();
    },

    // 处理反馈
    dealCallback(params, msg) {
      return new Promise((resolve, reject) => {
        this.$http
          .post("updateApplyProbation", params)
          .then(res => {
            if (res.code === 20000) {
              this.$Message.success(msg);
              this.search();
              resolve();
            } else {
              this.$Message.error(`处理失败：${res.msg}`);
              reject();
            }
          })
          .catch(e => {
            console.error(e);
            reject();
            this.$Message.error("处理失败！");
          });
      });
    },

    // 编辑备注
    showRemarkModal(id, remark) {
      this.$refs.addRemarkModal.show(remark, id);
    },

    // 编辑备注
    editRemark(remark, id) {
      let params = {
        id,
        remark
      };
      this.btnLoading = true;
      this.dealCallback(params, "设置成功！").then(() => {
        this.btnLoading = false;
        this.$refs.addRemarkModal.cancel();
      });
    },

    //   完成处理
    finishDeal(id) {
      let params = {
        id,
        status: 1
      };
      this.dealCallback(params, "申请已处理完成");
    },

    // 开始处理
    startDeal(id) {
      let params = {
        id,
        status: 3
      };
      this.dealCallback(params, "申请正在处理中");
    }
  }
};
</script>


<style lang="less" scoped>
.table-area {
  margin: 15px 0;
}
.page-load {
  text-align: right;
  margin-right: 15px;
}
</style>
