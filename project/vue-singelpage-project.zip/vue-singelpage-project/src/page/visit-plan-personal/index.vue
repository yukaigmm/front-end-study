<template>
  <div style="margin-top: 10px;" class="plan-calender-view">
     <div class="help-icon">
      <Poptip  placement="left-start" trigger="hover" width="250" >
       <span style="font-size:12px;">帮助<Icon type="help-circled" style="font-size: 16px;vertical-align:text-bottom;"></Icon></span>
        <div slot="content" >
          <p>
           &nbsp;&nbsp;<Icon type="checkmark-circled" style="color:green;"></Icon>&nbsp;&nbsp;已完成
          </p>
           <p>
           &nbsp;&nbsp;<Icon type="clock" style="color:#b38418e0;"></Icon>&nbsp;&nbsp;待完成
          </p>
           <p>
            &nbsp;&nbsp;<Icon type="close-circled" style="color:red;"></Icon>&nbsp;&nbsp;超过缓冲期未完成
          </p>
           <p>
           &nbsp;&nbsp;<Icon type="alert-circled" style="color:#695f5f;opacity:.6;"></Icon>&nbsp;&nbsp;已取消
          </p>
          <br>
          <p style="position:relative;">
             <iCircle :percent="50" stroke-color="rgba(26,162,96, 0.6)" trail-color="rgba(197,183,181, 0.6)" :size="30">
                <span style="font-size:12px;">1/2</span>
             </iCircle>&nbsp;&nbsp;
             <span style="position:absolute;top:6px;">拜访计划共2条，已完成1条</span>

          </p>
           <p  style="position:relative;">
             <iCircle :percent="0" stroke-color="rgba(26,162,96, 0.6)" trail-color="rgba(197,183,181, 0.6)" :size="30">
                <span style="font-size:12px;">0/2</span>
             </iCircle>&nbsp;&nbsp;
             <span style="position:absolute;top:6px;">拜访计划均未完成</span>
          </p>
           <p  style="position:relative;">
             <iCircle :percent="100" stroke-color="rgba(26,162,96, 0.6)" trail-color="rgba(197,183,181, 0.6)" :size="30">
                <span style="font-size:12px;">2/2</span>
             </iCircle>&nbsp;&nbsp;
              <span style="position:absolute;top:6px;">拜访计划均已完成</span>
          </p>
          <p >
            &nbsp;&nbsp;(tip:已取消的计划不纳入计算)
          </p>
        </div>
      </Poptip >
    </div>
    <Spin fix v-show="loading">
      <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
      <div>正在加载...</div>
    </Spin>
    <div class="full-calendar" v-show="!loading">
      <div class="over-view-action">
      </div>
    </div>
    <Tooltip placement="top" class="plan_tooltip" :delay="1000">
      <div slot="content" class="tooltip-content">
        <p>
          <span class="title">计划标题： </span>
          <span class="content">{{tipData.topic}}</span>
        </p>
        <p>
          <span class="title">拜访时间： </span>
          <span class="content">{{tipData.visit_date}}</span>
        </p>
        <p>
          <span class="title">拜访人： </span>
          <span class="content">{{tipData.visit_member_name}}</span>
        </p>
        <p>
          <span class="title">拜访对象： </span>
          <span class="content">{{tipData.contacts_id ? tipData.contacts_name : '无'}}</span>
        </p>
        <p>
          <span class="title">需求点： </span>
          <span class="content">{{getDemandsName(tipData.demand_ids)}}</span>
        </p>
        <p>
          <span class="title">拜访类别： </span>
          <span class="content">{{getVisitTypeName(tipData.visit_type)}}</span>
        </p>
        <p>
          <span class="title">备忘提醒： </span>
          <span class="content">{{tipData.plan_content || '无'}}</span>
        </p>
        <p>
          <span class="title">计划状态： </span>
          <span class="content">{{tipData.isvalid ===0?'已取消':(tipData.status === 1 ? '未完成' : '已完成')}}</span>
        </p>
      </div>
    </Tooltip>

    <template v-for="(eventArr, date) in resultGroupByDate">
      <iCircle v-if="getPercent(eventArr).total" :percent="getPercent(eventArr).percent" class="tip-circle" style="display: none" :name="`circle-${date}`" stroke-color="rgba(26,162,96, 0.6)" trail-color="rgba(197,183,181, 0.6)" :size="40" :stroke-width="10" :trail-width="8">
        <span class="demo-Circle-inner" style="font-size:12px">{{getPercent(eventArr).compeleted + '/' + getPercent(eventArr).total}}</span>
      </iCircle>
    </template>
    <visit-plan ref="visitPlan" @reload="reload"></visit-plan>
  </div>
</template>
<script>
import $ from 'jquery';
import * as calendar from 'fullcalendar';
import moment from 'moment';
import _ from 'lodash';
import { mapGetters } from 'vuex';
import visitPlan from './plan-modal';
import { getMonthViewOfPlans, getDayViewOfPlans, delPlan } from '@/service/getData';


export default {
  components: {
    visitPlan
  },
  data() {
    return {
      intervalId:"",
      // isShowEdit:false,
      loading: false,
      fullCalendarDom: '',
      eventData: [],
      resultGroupByDate: {},
      cacheData: [],
      currentMonth: '',
      viewType: 1,
      tipData: {},
    }
  },
  computed: {
    ...mapGetters({
      enums: 'getEnums'
    }),
    demandType() {
      return this.enums.c_demand;
    },
    visitType() {
      return this.enums.c_visit_type;
    },
    currentMonthString() {
      return moment(new Date()).format('YYYY-MM');
    },
   maxCacheTime(){
      return this.enums.c_max_exec_time[0].value;
    },
  },
  methods: {
    loadData() {
      $(this.$el).find(`.full-calendar td.fc-day`).find('.tip-circle').remove();
      this.loading = true;
      let params = {
        rows: -1,
        view_type: this.viewType,
        visit_month: [this.currentMonth]
      }
      getMonthViewOfPlans(params).then((resp) => {
        if (resp.code === 20000) {
          let result = [];
          _.each(resp.data.data, (val) => {
            result.push({
              id: val.id,
              start: val.visit_date,
              end: val.visit_date,
              title: val.topic,
              // color: val.isvalid == 1 ? 'rgb(238,238,238)' : 'rgb(250,250,250)',
              datas: val
            })
          })
          this.eventData = JSON.parse(JSON.stringify(result));

          //设置每个日期的计划完成数/计划总数
          let resultGroupByDate = _.groupBy(result, (data) => {
            return moment(new Date(data.start)).format('YYYY-MM-DD');
          });
          this.resultGroupByDate = resultGroupByDate;

          setTimeout(() => {
            //设置当天日期的格式
            let currentDateSpan = $(this.$el).find(`.full-calendar td.fc-day-top[data-date=${moment(new Date()).format('YYYY-MM-DD')}] > span`);
            if (currentDateSpan.length) {
              currentDateSpan.css({
                position: 'relative',
                paddingRight: '6px'
              }).html($('<span>').text(currentDateSpan.text())).append($('<span>').css({
                display: 'inline-block',
                width: '5px',
                height: '5px',
                borderRadius: '50%',
                backgroundColor: '#2D8CF0',
                position: 'absolute',
                top: '50%',
                right: 0,
                transform: 'translate(0, -50%)'
              }))
            }
            //填充circle
            _.forEach(resultGroupByDate, (arr, date) => {
              let tip = $(this.$el).find(`.tip-circle[name=circle-${date}]`).clone(true).show();
              let cell = $(this.$el).find(`.full-calendar td.fc-day[data-date=${date}]`);
              cell.append(tip);
            })

            //add-button 显示隐藏
            $(this.$el).find('.full-calendar .fc-content-skeleton thead td.fc-day-top').hover(function(e) {
              let date = $(this).attr('data-date');
              $('.full-calendar').find(`.fc-bg td.fc-day[data-date=${date}]`).find('.add-button').toggle();
            })
            $(this.$el).find('.full-calendar .fc-content-skeleton tbody td').hover(function(e) {
              let date = '';
              let hoverTd = $(this);
              //如果td含有子元素，则表示它包含event，直接获取date
              if (hoverTd.children().length) {
                date = hoverTd.find('a.fc-day-grid-event').attr('data-date');
              } else {
                //如果td没有包含子元素，则获取它兄弟元素中包含event的td
                let firstSiblingTdHasEvent = hoverTd.siblings('td:not(:empty)').eq(0);
                let firstSiblingTdHasEventIndex = firstSiblingTdHasEvent.index();
                let hoverTdIndex = hoverTd.index();
                let firstSiblingTdHasEventDate = firstSiblingTdHasEvent.find('a.fc-day-grid-event').attr('data-date');
                //通过之间的索引差值求出hoverTd对应的日期
                date = moment(new Date(firstSiblingTdHasEventDate)).add(hoverTdIndex - firstSiblingTdHasEventIndex, 'days').format('YYYY-MM-DD');
              }



              $('.full-calendar').find(`.fc-bg td.fc-day[data-date=${date}]`).find('.add-button').toggle();
            })
            $('.full-calendar').find(`.fc-bg td.fc-day`).mouseover(function(e) {
              $(this).find('.add-button').show()
            }).mouseout(function(e) {
              $(this).find('.add-button').hide()
            })





          }, 0)




          // _.forEach(resultGroupByDate, (arr, date) => {
          //  let dateString = moment(new Date(date)).format('YYYY-MM-DD');
          //  //获取日期对应的td元素
          //  let dateCell = $(this.$el).find('.full-calendar').find(`td.fc-day[data-date=${dateString}]`);
          //  //计划总数
          //  let itemsTotalLength = arr.length;
          //  //计划总数为0时，不展示tip
          //  if(itemsTotalLength === 0) {
          //    dateCell.find('.tip-circle').hide();
          //    dateCell.find('.color-header').hide();
          //  }else {
          //    //计划完成数
          //    let itemCompeletedLength = arr.filter( (item) => {
          //      return item.datas.status == 2;
          //    }).length;
          //    dateCell.find('.tip-circle').show().attr('title',`共${itemsTotalLength}个计划，已完成${itemCompeletedLength}个`);
          //    // dateCell.find('.color-header').show();
          //    //tip显示的颜色： 全部完成为绿色，部分完成为黄色，全未完成为红色
          //    // let color = itemCompeletedLength === itemsTotalLength ? '#30C47A' : (itemCompeletedLength === 0 ? '#ED3F14' : '#FF9900');
          //    // dateCell.find('.tip').css('backgroundColor', color);
          //    dateCell.find('.compeleted-items').text(itemCompeletedLength);
          //    dateCell.find('.total-items').text(itemsTotalLength);

          //    //color-header渐变色设置
          //    let percent = parseInt( itemCompeletedLength / itemsTotalLength * 100 );

          //    // if(percent === 0 || percent === 100) {
          //    //  dateCell.find('.color-header').css('background', `linear-gradient(to right, green ${percent}%, red ${percent}%)`);
          //    // }else {
          //    //  dateCell.find('.color-header').css('background', `linear-gradient(to right, green ${percent-10}%, red ${percent+10}%)`);
          //    // }
          //    dateCell.find('.tip-circle .ivu-chart-circle-inner').text(`${percent}%`);
          //  }

          // })
        } else {
          this.eventData = [];
        }
        this.loading = false;
      })
    },
    initFullCalendar() {
      this.fullCalendarDom.fullCalendar({
        theme: false,
        events: [],
        header: {
          left: 'prevYear,prev,next,nextYear, today',
          center: 'title',
          right: ''
        },
        buttonText: {
          today: '今天'
        },
        fixedWeekCount: false,
        // height: 'auto',
        showNonCurrentDates: false,
        locale: 'zh-cn',
        defaultDate: moment(new Date).format('YYYY-MM-DD'),
        // navLinks: true, // can click day/week names to navigate views
        selectable: false,
        selectHelper: false,
        handleWindowResize: false,
        displayEventTime: false,
        titleFormat: 'YYYY年MM月',
        timeFormat: 'H:mm',
        eventClick: (calEvent, jsEvent, view) => {
          let cancelOrRecovery = calEvent.datas.isvalid == 1 ? "cancel" : "recovery";
          let isShowEdit;
          let now = new Date().getTime();
          let planTime = new Date(calEvent.datas.visit_date).getTime();
          if ((calEvent.datas.status === 1) && (planTime > now)) {
            // 待完成
            isShowEdit = true;
          } else if ((calEvent.datas.status === 1) && (planTime < now)) {
            // 未完成
            isShowEdit = false;
          } else {
            isShowEdit = false;
          }
          this.$refs.visitPlan.show('edit', calEvent.datas.id, calEvent.datas.visit_date, isShowEdit, cancelOrRecovery, calEvent.datas.isvalid,calEvent.datas.status);
        },
        eventRender: (event, element) => {
         let now = new Date().getTime();
          let planTime = new Date(event.datas.visit_date).getTime()+this.maxCacheTime*3600*1000;
          let compeletedIcon =
            `
                <i class="ivu-icon ivu-icon-checkmark-circled completed-icon" style="font-size: 12px;display: inline-block" title="已完成"></i>
              `
          let uncompeletedIcon =
            `
                <i class="ivu-icon ivu-icon-close-circled uncompleted-icon completed-icon" style="font-size: 12px;display: inline-block" title="超过缓冲期未完成"></i>
              `
          let toCompeletedIcon =
            `
                <i class="ivu-icon ivu-icon-clock to-completed-icon completed-icon" style="font-size: 12px;display: inline-block" title="待完成"></i>
              `
          let canceledIcon =
            `
                <i class="ivu-icon ivu-icon-alert-circled canceled-icon completed-icon" style="font-size: 12px;display: inline-block" title="已取消"></i>
              `
          let delBtn =
            `
                <span title="删除计划" class="del-event-button">×</span>
              `
          let tooltip = $(this.$el).find('.ivu-tooltip-popper');
          $(element).attr('data-date', event.datas.visit_date.split(' ')[0]).append($(delBtn).click((e) => {
            e.preventDefault();
            e.stopPropagation();

            this.delPlan(event.datas.id);

            return false;
          })).mouseover((e) => {
           clearInterval(this.intervalId);
            this.tipData = JSON.parse(JSON.stringify(event.datas));
            let currentTarget = $(e.currentTarget);

            let windowWidth = $(window).width();
            let windowHeight = $(window).height();

            let currentTargetOffsetTop = currentTarget.offset().top;
            let currentTargetOffsetLeft = currentTarget.offset().left;

            let tooltipWidth = tooltip.width();
            let tooltipHeight = tooltip.height();

            let currentTargetWidth = currentTarget.width();
            //控制tooltip的显示位置，防止溢出页面
            let finalTop = 0;
            let tooltipArrowClass = '';
            if (windowHeight < currentTargetOffsetTop + tooltipHeight + 30) {
              finalTop = currentTargetOffsetTop - tooltipHeight - 10;
              tooltipArrowClass = 'tooltip-arrow-up';
            } else {
              finalTop = currentTarget.offset().top + 30;
              tooltipArrowClass = 'tooltip-arrow-down';
            }

            let finalLeft = 0;
            let arrowLeftOrRight = "";
            if (windowWidth < currentTargetOffsetLeft + tooltipWidth) {
              finalLeft = currentTargetOffsetLeft - (tooltipWidth - currentTargetWidth - 15);
              //   console.log(finalLeft);
              arrowLeftOrRight = 'tooltip-arrow-right';
            } else {
              finalLeft = currentTargetOffsetLeft;
              arrowLeftOrRight = 'tooltip-arrow-left';
            }
          // 延迟出现，避免用户晃动光标时，频繁出现
            this.intervalId =  setTimeout(()=>{
            tooltip.show().css({
              position: 'fixed',
              left: `${finalLeft}px`,
              top: `${finalTop}px`
            }).find('.ivu-tooltip-arrow').removeClass('tooltip-arrow-up tooltip-arrow-down tooltip-arrow-left tooltip-arrow-right').addClass(tooltipArrowClass + ' ' + arrowLeftOrRight);
          },500)
          }).mouseout((e) => {
            clearInterval(this.intervalId);
            tooltip.hide();
          })
          if (event.datas.isvalid === 0) {
            $(element).prepend($(canceledIcon));
            $(element).css({
              color: "#cbc",
              background: 'rgb(250,250,250)',
              textDecoration:"line-through"
            })
          } else {
            if ((event.datas.status === 1) && (planTime > now)) {
              // 待完成
              $(element).prepend($(toCompeletedIcon))
            } else if ((event.datas.status === 1) && (planTime < now)) {
              // 未完成
              $(element).prepend($(uncompeletedIcon))
            } else {
              $(element).prepend($(compeletedIcon))
            }
          }

        },
        viewRender: (view, element) => {
          this.currentMonth = moment(new Date(view.intervalStart)).format('YYYY-MM');
        },
        dayRender: (date, cell) => {
          //当月日期才需要渲染
          // console.log(date.format('YYYY-MM-DD'));
          // console.log(this.currentMonth);
          setTimeout(() => {
            if (date.format('YYYY-MM-DD').indexOf(this.currentMonth) !== -1) {
              let markup =
                `
                    <div class="add-button">
                      <span>+</span>
                    </div>
                  `;

              // let tip =
              //  `
              //    <div class="tip">
              //      <span class="compeleted-items"></span>
              //      <span class="divide"></span>
              //      <span class="total-items"></span>
              //    </div>
              //  `
              // let header =
              //  `
              //    <div class="color-header"></div>
              //  `
              let tip = $(this.$el).find('.tip-circle[name=circle]')
              $(cell).css('paddingBottom', '20px').append($(markup).mousedown((e) => {
                e.preventDefault();
                e.stopPropagation();

                this.$refs.visitPlan.show('add', null, date.format('YYYY-MM-DD'));

                return false;
              })).append($(tip))
            }
          }, 0)
        }
      })
    },
    //通过月份获取上下两月的日期，主要解决日期控件中当前月前后不展示数据的问题
    getContextMonth(monthString) {
      let currentMonth = moment(monthString);
      let prevMonth = moment(currentMonth.format('YYYY-MM'));
      let nextMonth = moment(currentMonth.format('YYYY-MM'));
      prevMonth.subtract(1, 'months');
      nextMonth.add(1, 'months');

      return [prevMonth, currentMonth, nextMonth].map((moment) => {
        return moment.format('YYYY-MM');
      })
    },
    reload() {
      this.loadData()
    },
    delPlan(id) {
      this.$Modal.confirm({
        title: '确认删除',
        content: '确认删除此条计划吗？',
        loading: true,
        onOk: () => {
          delPlan(id).then((resp) => {
            if (resp.code === 20000) {
              this.$Message.success('删除成功')
            } else {
              this.$Message.success('删除失败 ' + resp.msg);
            }
            this.loadData();
            this.$Modal.remove();
          })
        }
      })
    },
    getDemandsName(demandIds) {
      demandIds = demandIds ? JSON.parse(demandIds) : [];
      let name = demandIds.map((id) => {
        let demand = _.find(this.demandType, (type) => {
          return type.value === `${id}`;
        })
        return demand.name;
      })
      return name.length ? name.join(', ') : '无';
    },
    getVisitTypeName(visitType) {
      visitType = visitType || 99;
      let type = _.find(this.visitType, (type) => {
        return type.value === `${visitType}`;
      })
      return type.name;
    },
    getPercent(eventArr) {
      let eventArrWithCanceled = eventArr.length?JSON.parse(JSON.stringify(eventArr)):[];
    let eventArrWithoutCanceled = eventArrWithCanceled.filter(item=>{
       return item.datas.isvalid ===1 ;
     })
      let itemsTotalLength = eventArrWithoutCanceled.length;
      let itemCompeletedLength = eventArrWithoutCanceled.filter((item) => {
        return item.datas.status == 2;
      }).length;
      let percent = parseInt(itemCompeletedLength / itemsTotalLength * 100);
      return {
        percent,
        total: itemsTotalLength,
        compeleted: itemCompeletedLength
      }
    }
  },
  mounted() {
    this.fullCalendarDom = $(this.$el).find('.full-calendar');
    this.initFullCalendar();




  },
  watch: {
    eventData(val) {
      this.fullCalendarDom.fullCalendar('removeEvents')
      this.fullCalendarDom.fullCalendar('renderEvents', val);
    },
    currentMonth(val) {
      this.loadData();
    }
  }
}

</script>
<style lang="less" rel="styleSheet/less">
.full-calendar {
  margin-bottom: 20px;
  position: relative;
  .over-view-action {
    position: absolute;
    right: 0px;
    top: 0px;
    .over-view-label {
      margin-right: 70px;
    }
  }
  .fc-toolbar.fc-header-toolbar {
    position: relative;
    &:after {
      content: '';
      display: block;
      clear: both;
    }
  }
  .fc-center {
    display: inline-block;
    position: absolute;
    left: 50%;
    transform: translate(-50%, 0);
  }
  .fc-scroller.fc-day-grid-container {
    height: auto !important;
  }
  .fc-row.fc-week.fc-widget-content {
    padding-bottom: 26px;
    height: auto !important;
  }
  .fc-day {
    position: relative; // &:hover {
    //  .add-button {
    //    display: block;
    //  }
    // }
  }
  .fc-day-number {
    font-size: 24px;
    color: #2D8CF0;
    float: left !important;
  }
  .fc-day-grid-event {
    position: relative;
    background-color: #eee;
    color: #000;
    border: none;
    padding: 2px 5px 2px 15px;
    &:hover {
      color: #000;
      .del-event-button {
        cursor: pointer;
        display: block;
      }
    }
    .fc-content {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .del-event-button {
      display: none;
      font-size: 20px;
      position: absolute;
      z-index: 10;
      right: 0;
      top: 0;
      height: 100%;
      line-height: 21px;
      padding-left: 5px;
      background-color: #eee;
    }
    .completed-icon {
      position: absolute;
      z-index: 10;
      left: 0;
      top: 0;
      display: block;
      width: 15px;
      height: 15px;
      top: 50%;
      color: rgba(26,162,96, 0.6);
      transform: translate(0, -50%);
    }
    .uncompleted-icon {
      color: rgba(203,27,4, 0.6);
    }
    .to-completed-icon {
      color: #b38418e0;
    }
    .canceled-icon {
      color: #cbc;
    }
  }
}

.add-button {
  width: 20px;
  height: 20px;
  text-align: center;
  line-height: 20px;
  background-color: #ccc;
  color: #666;
  font-size: 24px;
  border-radius: 50%;
  position: absolute;
  bottom: 1px;
  left: 1px;
  display: none;
  &:hover {
    color: #D02109;
    cursor: pointer;
  }
}

.tip-circle {
  position: absolute !important;
  right: 0;
  top: 0;
  transform-orgin: right top;
  transform: scale(0.9);
}

.tip {
  width: 20px;
  height: 25px;
  position: absolute;
  right: 0;
  top: 0;
  border-radius: 0 0 0 100%;
  display: none;
  .compeleted-items {
    position: absolute;
    left: 0;
    top: 0;
  }
  .total-items {
    position: absolute;
    right: 0;
    bottom: 0;
  }
  .divide {
    display: block;
    width: 1px;
    height: 100%;
    position: absolute;
    left: 50%;
    top: 0;
    background-color: #000;
    transform-origin: center;
    transform: translate(-50%, 0) scale(0.7) rotate(35deg);
  }
}

.color-header {
  height: 3px;
  width: 100%;
  position: absolute;
  top: 0; // background: linear-gradient(to right, red 10%, green 20%);
  display: none;
}

.plan_tooltip {
  .ivu-tooltip-inner {
    max-width: none;
  }
}

.tooltip-content {
  .title {
    display: inline-block;
    width: 70px;
    text-align: justify;
  }
  .content {
    display: inline-block;
    width: 300px;
    height: auto;
    vertical-align: top;
    overflow: unset; // text-overflow: ellipsis;
    // overflow: hidden;
    white-space: pre-wrap;
  }
}

.tooltip-arrow-right {
  right: 10px;
}

.tooltip-arrow-left {
  left: 10px;
}

.tooltip-arrow-up {
  border-width: 5px;
  border-top-color: rgba(70, 76, 91, 0.9) !important;
  bottom: -10px; // left: 10px;
  // display: none;
}

.tooltip-arrow-down {
  border-width: 5px;
  border-bottom-color: rgba(70, 76, 91, .9) !important;
  top: -10px; // left: 10px;
  // display: none;
}
.help-icon{
  position: absolute;
  right: 20px;
  top:40px;
  color:#2d8cf0;
  font-size: 16px;
  z-index:1;
}
.staus-line{
  border-bottom: 1px dashed #ccc;
  padding: 5px 0;
}

</style>
