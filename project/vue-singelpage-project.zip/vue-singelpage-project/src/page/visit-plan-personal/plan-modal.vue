<template>
  <div>
    <Modal v-model="modal" :width="800" :title="title" :mask-closable="false" @on-cancel="cancel" :animate="false">
      <div slot="footer">
        <template v-if="status=='edit' && type=='show'">
          <Button @click="cancel">关闭</Button>
        </template>
        <template v-else>
          <Button type="primary" @click="ok">确定</Button>
          <Button @click="cancel">取消</Button>
        </template>
      </div>
      <div style="height: 30px;">
        <div class="action-container" v-if="status=='edit'">
          <span class="action-button" type="warning" @click="setPlanStatus">{{cancelOrRecovery=="cancel"?"取消计划":"恢复计划"}}</span>
          <span class="action-button" :class="{selected: type=='edit'}" @click="editPlan" v-show="isShowEdit&&(cancelOrRecovery=='cancel')">编辑计划</span>
          <span class="action-button" type="warning" @click="addRecord" v-show="cancelOrRecovery=='cancel'">添加拜访记录</span>
          <!-- <span class="action-button" :class="{selected: editType=='record'}" @click="editRecord">完成计划</span> -->
        </div>
      </div>
      <div v-show="status=='edit' && type=='show' ">
        <Spin fix v-show="planLoading">
          <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
          <div>Loading</div>
        </Spin>
        <Form v-show="!planLoading" ref="showForm" :modal="showData" :label-width="100">
          <Row>
            <Col span="10">
            <FormItem label="计划标题">
              <span>{{showData.topic}}</span>
            </FormItem>
            </Col>
            <Col span="13">
             <FormItem label="计划状态">
              <span>{{originPlanStatusText}}</span>
            </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span="10">
            <FormItem label="拜访人">
              <span>{{showData.visit_member_name}}</span>
            </FormItem>
            </Col>
            <Col span="13">
            <FormItem label="拜访对象">
              <template v-if="showData.contacts_id">
                <Tooltip>
                  <div slot="content">{{getDeptInfo(showData.bread)}}</div>
                  <span>{{showData.contacts_name}}</span>
                  <span>
                      (
                      <span class="visitor">{{getDeptInfo(showData.bread)}}</span> )
                  </span>
                </Tooltip>
              </template>
              <template v-else>
                <span>无</span>
              </template>
            </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span="10">
            <FormItem label="拜访日期">
              <span>{{showData.visit_date}}</span>
            </FormItem>
            </Col>
            <Col span="10">
            <FormItem label="拜访类别">
              <span>{{getVisitTypeName(showData.visit_type)}}</span>
            </FormItem>
            </Col>
          </Row>
          <!-- <Row>
            <Col span="24">
              <FormItem label="意向">
                <span></span>
              </FormItem>
            </Col>
          </Row> -->
          <Row>
            <Col span="24">
            <FormItem label="需求点">
              <span>{{getDemandName(showData.demand_ids) || '无'}}</span>
            </FormItem>
            </Col>
          </Row>
          <!-- <Row>
            <Col span="24">
              <FormItem label="交谈内容">
                <span></span>
              </FormItem>
            </Col>
          </Row> -->
          <Row>
            <Col span="24">
            <FormItem label="备忘提醒">
              <span>{{showData.plan_content || '无'}}</span>
            </FormItem>
            </Col>
          </Row>
        </Form>
      </div>
      <div v-show="!(status=='edit' && type=='show')">
        <Form ref="form" :model="form" :label-width="100" :rules="rules">
          <Row>
            <Col span="24">
            <FormItem label="计划标题" prop="topic">
              <Input placeholder="请输入计划标题" v-model="form.topic"></Input>
            </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span="10">
            <FormItem label="拜访人">
              <span>{{form.visit_member_name}}</span>
            </FormItem>
            </Col>
            <Col span="10">
            <FormItem label="拜访对象" prop="contacts_id">
              <Input v-model="form.contacts_id" style="display: none"></Input>
              <span>{{contact_person.name}}</span>
              <Button type="primary" size="small" @click="chooseTarget">{{form.contacts_name ? '更换' : '选择'}}</Button>
            </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span="10">
            <FormItem label="拜访日期" prop="date">
              <DatePicker type="date" v-model="form.date" placeholder="日期" style="width: 120px" @on-change="dateChange"></DatePicker>
              <TimePicker type="time" format="HH:mm" v-model="form.time" placeholder="时间" style="width: 90px" @on-change="timeChange"></TimePicker>
            </FormItem>
            </Col>
            <Col span="10">
            <FormItem label="拜访类别">
              <Select v-model="form.visit_type">
                <Option v-for="(item,index) in visitType" :key="index" :value="item.value">{{item.name}}</Option>
              </Select>
            </FormItem>
            </Col>
          </Row>
          <!-- <Row>
            <Col span="24">
              <FormItem label="意向">
                <radio-url :config="{cacheKey:'c_intention'}" v-model="form.intention_type" ></radio-url>
              </FormItem>
            </Col>
          </Row> -->
          <Row>
            <Col span="24">
            <FormItem label="需求点">
              <checkbox-url :config="{cacheKey:'c_demand'}" v-model="form.demand_ids"> </checkbox-url>
            </FormItem>
            </Col>
          </Row>
          <!-- <Row>
            <Col span="24">
              <FormItem label="交谈内容">
                <checkbox-url :config="{cacheKey:'c_chat_content'}" v-model="form.chat_ids" > </checkbox-url>
              </FormItem>
            </Col>
          </Row> -->
          <Row>
            <Col span="24">
            <FormItem label="备忘提醒" prop="plan_content">
              <Input v-model="form.plan_content" type="textarea" :autosize="{minRows: 4,maxRows: 7}" placeholder="请输入内容"></Input>
            </FormItem>
            </Col>
          </Row>
        </Form>
      </div>
    </Modal>
    <choose-visit ref="chooseVisit" @confirmVisitTarget="confirmVisitTarget"></choose-visit>
    <visit-record ref="visitRecord" @addVisitSuccess="addVisitSuccess"></visit-record>
  </div>
</template>
<script>
import SelectUrl from "@/components/inputs/select-url";
import CheckboxUrl from "@/components/inputs/checkbox-url";
import RadioUrl from "@/components/inputs/Radio-url";
import chooseVisit from "../visit-record-manager/choose-visit-target";
import visitRecord from "../visit-record-manager/visit-record-without-target";
import {
  getPlanDetail,
  addPlan,
  editPlan,
  setPlanStatus,
  cancelOrRecoveryPlan
} from "@/service/getData";
import moment from "moment";
import { mapGetters } from "vuex";
export default {
  components: {
    SelectUrl,
    CheckboxUrl,
    RadioUrl,
    chooseVisit,
    visitRecord
  },
  data() {
    return {
      visitPlanStatus:'',
      planTime:"",
      originPlanStatusText:'',
      ifStatusChanged: false, // true 更改了计划的取消与恢复状态
      originPlanId: "",
      originPlanStatus: "", //计划的初始状态
      cancelOrRecovery: '', // cancel 取消计划 recovery 恢复计划
      isShowEdit: false, // true 显示编辑计划按钮
      modal: false,
      planLoading: false,
      status: "add", // add 新增计划  edit 编辑计划
      type: "show", //show 展示  edit 编辑
      editType: "", // plan 编辑计划 record 生成记录
      initForm: {
        demand_ids: [],
        plan_content: "",
        date: '',
        time: '',
        contacts_id: '',
        contacts_name: '',
      },
      form: {},
      showData: {},
      rules: {
        topic: [{
          required: true,
          message: "必填",
          trigger: "blur, change"
        }],
        // contacts_id: [
        //   {
        //     required: true,
        //     message: "必选",
        //     trigger: "blur, change"
        //   }
        // ],
        date: [{
          required: true,
          type: "date",
          message: "必选",
          trigger: "blur, change"
        }]
      },
      visitType: [],
      initVisitType: "",
      visitTimeString: "",
      orderTimeString: "",
      contact_person: {},
      date: "",
      time: "",
      planId: 0 //计划id，用于拜访记录添加成功后改变计划状态
    };
  },
  computed: {
    ...mapGetters({
      user: "getUser",
      enums: "getEnums"
    }),
    title() {
      return this.status === "add" ? "添加计划" : "计划详情";
    }
  },
  methods: {
    // 获取计划状态
    getPlanStatus(time,visitPlanStatus){
      let now = new Date().getTime();
      let planTime = new Date(time).getTime();
      if(!this.originPlanStatus){
        this.$nextTick(()=>{
          this.originPlanStatusText = "已取消";
        })
        return;
      };
      // 待完成
      if ((planTime > now) && (visitPlanStatus == 1)) {
        this.$nextTick(()=>{
          this.originPlanStatusText = "待完成";
        })
      } else if ((planTime < now) && (visitPlanStatus == 1)) {
        this.$nextTick(()=>{
          this.originPlanStatusText = "未完成";
        })
        // 未完成
      } else {
        // 已完成
        this.$nextTick(()=>{
          this.originPlanStatusText = "已完成";
        })

      }
    },
    // 切换计划状态
    setPlanStatus() {
      let contentText = this.originPlanStatus == 0 ? "确定恢复计划？" : "确定取消计划？";
      let confirmTitle = this.originPlanStatus == 0 ? "恢复" : "取消";
      this.$Modal.confirm({
        title: confirmTitle,
        content: contentText,
        loading: true,
        width:300,
        onOk: () => {
          this.changePlanStatus().then(()=>{
            this.$Modal.remove();
          });
        }
      })
    },
    // 切换计划状态
    changePlanStatus() {
      return new Promise((resolve,reject) => {
        let params = {
          id: this.originPlanId,
          status: this.originPlanStatus == 0 ? 1 : 0,
        }
        cancelOrRecoveryPlan(params).then(res => {
          if (res.code == 20000) {
            this.$Message.info('设置成功！');
            resolve();
            this.$nextTick(() => {
              this.cancelOrRecovery = params.status == 1 ? "cancel" : "recovery";
              this.originPlanStatus = params.status;
              this.getPlanStatus(this.planTime,this.visitPlanStatus);
            })
            this.ifStatusChanged = true;
          } else {
            reject();
            this.$Message.info('设置失败！');
          }
        })
      })
    },
    /**
     *
     * @param  {[string]} status [modal打开的模式 add edit]
     * @param  {[object]} data   [编辑时传递过来的计划id]
     * @param  {[string]} date   [点击单元格的日期,只在新增时传递]
     * @param {[number]} planID [当前计划的id]
     * @param {[boolean]} isShowEdit [是否显示编辑按钮]
     * @param {[string]} cancelOrRecovery [取消或者恢复]
     * @param {[number]} planStatus [计划的当前状态]
     */
    show(status, planId, date, isShowEdit, cancelOrRecovery, planStatus,visitPlanStatus) {
      this.visitPlanStatus = visitPlanStatus;
      this.originPlanId = planId;
      this.originPlanStatus = planStatus;
      this.planTime = date;
      this.$nextTick(() => {
        this.isShowEdit = isShowEdit;
        this.cancelOrRecovery = cancelOrRecovery;
        this.getPlanStatus(this.planTime,this.visitPlanStatus);
      })
      this.status = status;
      this.modal = true;
      if (status == 'add') {
        this.date = date;
        this.time = '08:00:00';
        this.form = {
          ...this.form,
          date: date,
          time: '08:00:00',
          visit_type: this.initVisitType,
          visit_member_name: this.user.trueName,
          visit_member_id: this.user.id,
          demand_ids: []
        };
        if (date) {
          this.form.visit_date = date;
        }
      } else if (status == 'edit') {
        this.planLoading = true;
        getPlanDetail({ id: planId }).then(resp => {
          this.planLoading = false;
          this.form = {
            ...this.form,
            ...resp.data
          };
          this.form.demand_ids = this.form.demand_ids ?
            JSON.parse(this.form.demand_ids) : [];
          this.form.contacts_id = _.isNull(this.form.contacts_id) ? '' : this.form.contacts_id + '';
          this.form.visit_type = this.form.visit_type + '';
          this.form.date = this.form.visit_date.split(' ')[0];
          this.form.time = this.form.visit_date.split(' ')[1];
          this.showData = JSON.parse(JSON.stringify(this.form));
          this.date = this.form.visit_date.split(' ')[0];
          this.time = this.form.visit_date.split(' ')[1];
          this.contact_person = {
            id: this.form.contacts_id,
            name: this.form.contacts_name
          };
        });
      }
    },
    hide() {
      this.modal = false;
    },
    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.form.visit_date = [this.date, this.time].join(" ");
          if (this.status == "add") {
            //新增计划
            let data = { ...this.form };
            addPlan(data).then(resp => {
              if (resp.code === 20000) {
                this.$Message.success("添加成功");
                this.$emit("reload");
              } else {
                this.$Message.error("添加失败 " + resp.msg);
              }
            });
          } else {
            //编辑计划
            let data = { ...this.form };
            editPlan(data).then(resp => {
              if (resp.code === 20000) {
                this.$Message.success("修改成功");
                this.$emit("reload");
              } else {
                this.$Message.error("修改失败 " + resp.msg);
              }
            });
          }
          this.hide();
          this.resetForm();
        } else {
          this.$Message.error("请按提示补充内容");
        }
      });
    },
    resetForm() {
      this.$nextTick(() => {
        this.form = JSON.parse(JSON.stringify(this.initForm));
        this.showData = JSON.parse(JSON.stringify(this.initForm));
        this.$refs.form.resetFields();
        this.contact_person = {};
        this.type = "show";
        this.status = "add";
        this.editType = "";
      });
    },
    cancel() {
      // 如果状态发生改变刷新日历视图
      if (this.ifStatusChanged) {
        this.ifStatusChanged = false;
        this.$emit("reload");
      };
      this.hide();
      this.resetForm();
    },
    editPlan() {
      if (this.form.visit_member_id !== this.user.id) {
        this.$Message.warning("他人计划无法进行此操作");
      } else if (this.form.status == 2) {
        this.$Message.warning("已完成的计划无需编辑");
      } else {
        this.type = this.type === "show" ? "edit" : "show";
      }
    },
    chooseTarget() {
      this.$refs.chooseVisit.show();
    },
    confirmVisitTarget(person) {
      this.form.contacts_id = person.id + "";
      this.form.contacts_name = person.title;
      this.contact_person = {
        name: person.title,
        id: person.id
      };
      this.form.org_id = person.org_id;
    },
    getVisitTypeName(key) {
      let visitType =
        this.visitType.filter(v => {
          return v.value === key;
        })[0] || {};
      let visitTypeName = visitType.name || "无";
      return visitTypeName;
    },
    getDemandName(keys) {
      let demandNames = [];
      let demands = this.enums.c_demand;
      _.forEach(keys, key => {
        let item =
          _.filter(demands, d => {
            return d.value === key;
          })[0] || {};
        if (item.name) {
          demandNames.push(item.name);
        }
      });
      return demandNames.length ? demandNames.join(", ") : '';
    },
    addRecord() {
      if (this.form.visit_member_id !== this.user.id) {
        this.$Message.warning("他人计划无法进行此操作");
      } else {
        let promise = new Promise((resolve, reject) => {
          if (this.form.status == 2) {
            this.$Modal.confirm({
              title: "确认",
              content: "该条计划已添加过拜访记录，是否继续添加？",
              loading: true,
              onOk: () => {
                this.$Modal.remove();
                resolve();
              }
            });
          } else {
            resolve();
          }
        }).then(() => {
          this.hide();
          this.planId = this.form.id;
          let {
            contacts_id,
            contacts_name,
            demand_ids,
            org_id,
            visit_date,
            visit_member_id,
            visit_member_name,
            visit_type
          } = this.form;
          this.$refs.visitRecord.show({
            contacts_id,
            contacts_name,
            demand_ids,
            org_id,
            visit_member_id,
            visit_member_name,
            visit_type,
            visit_time: visit_date.split(" ")[0]
          });
          this.resetForm();
        });
      }

    },
    addVisitSuccess() {
      //添加拜访记录成功，此时把计划设为已完成状态
      setPlanStatus({
        id: this.planId,
        status: 2 // 计划已完成状态
      }).then(resp => {
        if (resp.code === 20000) {
          this.$Message.success("计划已完成");
        }
        this.$emit("reload");
      });
    },
    dateChange(date) {
      this.date = date;
    },
    timeChange(time) {
      this.time = time;
    },
    getDeptInfo(bread) {
      bread = bread || [];
      bread = bread.filter((b, index) => {
        return b.id !== 0;
      });

      let deptNameArr = _.map(bread, "title");

      return deptNameArr.join(" ");
    }
  },
  mounted() {
    this.form = JSON.parse(JSON.stringify(this.initForm));
    let mapping = this.enums.c_visit_type_mapping;
    this.visitType = this.enums.c_visit_type;
    mapping.forEach(item => {
      if (item.name == this.user.dept_id) {
        this.initVisitType = item.value;
      } else {
        this.initVisitType = "99";
      }
    });
    let mapOfFilter = mapping.filter(m => {
      return m.name === `${this.user.dept_id}`;
    });
    this.initVisitType = mapOfFilter.length ? mapOfFilter[0].value : "99";
  }
};

</script>
<style lang="less" ref="styleSheet/less">
.action-container {
  float: right;
  .action-button {
    display: inline-block;
    padding: 5px 5px;
    cursor: pointer;
    color: #2d8cf0;
    &:hover {
      color: #57a3f3;
    }
    &.selected {
      background-color: #2d8cf0;
      color: #fff;
    }
  }
}

.visitor {
  cursor: pointer;
  display: inline-block;
  max-width: 250px;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  vertical-align: bottom;
}

</style>
