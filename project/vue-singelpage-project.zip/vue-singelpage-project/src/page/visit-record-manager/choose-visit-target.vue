<template>
  <Modal v-model="modal" class="choose-visit-target" :title="title ? title : '选择拜访对象'" :width="332" @on-cancel="cancel" >
    <Poptip 
      placement="bottom" 
      width="300" 
      @on-ok="getChosenNode" 
      @on-cancel="cancel" 
      confirm>
      <Input 
         v-model.trim="outerKeywords" 
         :placeholder="searchType==2?'请输入关键字,如：总部 分部':'请输入关键字'" 
         style="width:300px;" 
         @input="getOuterList">
         <div @click="stopPropagation" slot="append">
           <Select v-model="searchType" style="width: 60px" transfer>
             <Option value="2">机构</Option>
             <Option value="3">人物</Option>
           </Select>
         </div>
      </Input>
      <div slot="title">
        <Spin fix v-if="outerListLoading">
          <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
          <div>加载中...</div>
        </Spin>
        <div v-else>
            <el-tree 
              class="radio-tree"
              :data="outerList" 
              show-checkbox 
              node-key="id" 
              ref="tree" 
              :auto-expand-parent="true" 
              :props="defaultProps" 
              @check="currentChange" 
              :default-expanded-keys="expandIdArr" 
              @node-click="nodeClick">
            </el-tree>
        </div>
      </div> 
    </Poptip>
  </Modal>
</template>
<script>
import _ from "lodash";
import { fetchUser, fetchGrid } from "@/service/getData";
export default {
  props: ["title"],
  data() {
    return {
      defaultProps: {
        children: "children",
        label: "title"
      },
      modal: false,
      outerKeywords: "",
      outerListLoading: false,
      outerList: [],
      searchType: "2",
      lastPerson: {},
      lastTreeData: [],
      expandIdArr: []
    };
  },
  methods: {
    show() {
      this.modal = true;
    },
    hide() {
      this.modal = false;
    },

    pickSingleSelected(current, last) {
      let lastLeaf = _.find(last, function(o) {
        return o ? !o.children : false;
      });
      let curr = _.find(current, function(o) {
        if (o && lastLeaf) {
          return !o.children && o.id !== lastLeaf.id;
        } else if (o) {
          return !o.children;
        }
        return false;
      });
      return curr ? curr : null;
    },

    checkChange(arr, ifChecked) {
      let lastTreeData = this.lastTreeData || [];
      let currentTreeData = arr;
      let selected = this.pickSingleSelected(currentTreeData, lastTreeData) || {
        id: -1
      };
      this.lastTreeData = JSON.parse(JSON.stringify([selected]));
      arr.forEach(item => {
        if (item.id !== selected.id) {
          item.checked = false;
        }
      });
      this.lastPerson = JSON.parse(JSON.stringify(selected));
    },
    currentChange(data, nodeInfo) {
      if (data.type === 2 && nodeInfo.checkedKeys.length) {
        this.$refs.tree.setCheckedNodes([data]);
        let parent = this.$refs.tree.getNode(data.id).parent || {};
        let orgName = this.getCompanyName(parent) || "";
        this.lastPerson = {
          id: data.id,
          title: data.title,
          org_id: data.org_id,
          orgName: orgName,
          position: data.post,
        };
      } else {
        this.lastPerson = {};
      }
    },
    nodeClick(data, node, comp) {
      let checkedIds = this.$refs.tree.getCheckedNodes(true).map(node => {
        return node["node-key"];
      });
      if (data.type === 2) {
        if (checkedIds.indexOf(data["node-key"]) !== -1) {
          this.$refs.tree.setCheckedNodes([null]);
          this.lastPerson = {};
        } else {
          let parent = node.parent || {};
          let orgName = this.getCompanyName(parent) || "";
          this.$refs.tree.setCheckedNodes([data]);
          this.lastPerson = {
            id: data.id,
            title: data.title,
            org_id: data.org_id,
            orgName: orgName,
            position: data.post,
          };
        }
      }
    },
    // 获取选定的节点
    getChosenNode() {
      this.$emit("confirmVisitTarget", this.lastPerson);
      this.modal = false;
      this.outerList = [];
      this.outerKeywords = "";
    },
    // 选择的人员所在机构
    getCompanyName(node){
      let arr = [];
      let getLabels = (node) => {
        arr.push(node.label);
        if(node.parent){
          getLabels(node.parent);
        }
      };
      getLabels(node);
      arr.length = arr.length -2;
      arr.reverse();
      return arr.join(" ");
    },
    cancel() {
      this.modal = false;
      this.outerList = [];
      this.outerKeywords = "";
    },
    setAllParentNodeAsFalse(data, disabledKey, expandIdArr) {
      data["node-key"] = data.id + "-" + data.type;
      if (data.children && data.children.length) {
        data[disabledKey] = true;
        expandIdArr.push(data.id);
        _.forEach(data.children, per => {
          if (per.type == 1) {
            per[disabledKey] = true;
            expandIdArr.push(per.id);
          }
          if (per.children && per.children.length) {
            per[disabledKey] = true;
            expandIdArr.push(per.id);
            _.forEach(per.children, c => {
              this.setAllParentNodeAsFalse(c, disabledKey, expandIdArr);
            });
          }
        });
      } else {
        if (data.type == 1) {
          data[disabledKey] = true;
          expandIdArr.push(data.id);
        }
      }
    },
    // 获取外部部门列表
    getOuterList() {
      this.outerList = [];
      if (!this.outerKeywords) {
        return;
      }
      let outerKeywords = this.outerKeywords.trim().split(/[ ]+/);
      let params = {
        type: this.searchType,
        keywords: outerKeywords,
        disabled: true,
        // disabledKey: 'disableCheckbox'
        disabledKey: "disabled"
      };
      this.outerListLoading = true;
      clearTimeout(this.id);
      this.id = setTimeout(() => {
        fetchGrid("visit/gettreebytype", params).then(res => {
          // this.outerList = res.data;
          _.forEach(res.data, data => {
            this.setAllParentNodeAsFalse(data, "disabled", this.expandIdArr);
          });
          this.outerList = [
            {
              id: -1,
              checked: false,
              disabled: true,
              expand: true,
              title: "所有",
              children: [].concat(res.data)
            }
          ];
          this.expandIdArr.unshift(-1);
          this.lastTreeData = [];
          this.outerListLoading = false;
        });
      }, 800);
    },
    stopPropagation(e) {
      e.stopPropagation();
    }
  }
};
</script>
<style>
</style>
