<template>
  <div class="grid-content">
    <!-- 搜索表单区域 -->
    <div class="searchArea keydown-box">
      <search-area ref="form" @changeSearchParam="changeSearchParam" @onKeydownSearch="search">
        <div slot="default">
          <Row>
            <Col span='8'>
            <Form-item prop='contacts_name' label="关键词">
              <Row>
                <Col span="12" style="padding-right: 3px">
                <Input style="width:100%;" v-model.trim="formSearch['org_name']" placeholder="机构,如:总部 分部"></Input>
                </Col>
                <Col span="12" style="padding-left: 3px">
                <Input style="width:100%;" v-model.trim="formSearch['contacts_name']" placeholder="拜访对象或其他接待人"></Input>
                </Col>
              </Row>
            </Form-item>
            </Col>
            <Col span='8'>
            <Form-item prop='visit_time' label="拜访时间">
              <DatePicker style="width:100%;" type='daterange' v-model="formSearch['visit_time']" placeholder="请输入拜访时间"></DatePicker>
            </Form-item>
            </Col>
            <Col span="4" offset="1">
            <Button type="primary" @click="search">搜索</Button>
            <Button @click='onReset'>重置</Button>
            </Col>
          </Row>
        </div>
        <div slot="extend">
          <Row>
            <Col span='8'>
            <Form-item prop='order_time' label="预设回访时间">
              <DatePicker style="width:100%;" type='daterange' v-model="formSearch['order_time']" placeholder="请输入回访时间"></DatePicker>
            </Form-item>
            </Col>
            <Col span='8'>
            <FormItem label="机构类型">
              <Row>
                <Col span="12"  style="padding-right:3px;">
                   <Select v-model="formSearch.oc_id" clearable placeholder="请选择">
                     <Option v-for="item in enums.c_org" :value="item.value" :key="item.value">{{item.name}}</Option>
                  </Select>
                </Col>
                <Col span="12" style="padding-left:3px;">
                   <Select v-model="formSearch.depart_id" not-found-text='无匹配数据' clearable placeholder="请选择机构" style="width:100%;">
                    <Option v-for="item in orgList" :key="item.value" :label="item.name" :value="item.value">
                    </Option>
                  </Select>
                </Col>
              </Row>
            </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span='8'>
            <Form-item label='拜访人'>
              <Col span='12' style="padding-right: 3px">
              <Select v-model="formSearch.dept_id" placeholder="请选择部门" clearable @on-change='onDepartChange'>
                <Option v-for="item in department" :key="item.value" :label="item.label" :value="item.value">
                </Option>
              </Select>
              </Col>
              <Col span='12' style="padding-left: 3px">
              <Select v-model="formSearch.update_member_id" not-found-text='无匹配数据' :key="visitStatus.saleId" :disabled='!hasDept' clearable placeholder="请选择拜访人" style="width:100%;">
                <Option v-for="item in workmate" :key="item.value" :label="item.label" :value="item.value">
                </Option>
              </Select>
              </Col>
            </Form-item>
            </Col>
            <Col span='8'>
            <Form-item label='意向'>
              <Col span='12' style="padding-right:3px;">
              <!-- <component style="width:100%;" :is='"SelectUrl"' v-model="formSearch['demand_ids']" placeholder='请选择需求点' :config="{ url: '/common/getSelect/c_demand', placeholder: '请选择需求点', name: 'name', value: 'value', multiple: true }">
              </component> -->
                 <Select v-model="formSearch.demand_ids" multiple placeholder="请选择需求点" clearable>
                   <Option v-for="(item,index) in enums.c_demand" :key="index" :label="item.name" :value="item.value">
                   </Option>
                 </Select>
              </Col>
              <Col span='12' style="padding-left:3px;">
              <!-- <component style="width:100%;" :is='"SelectUrl"' v-model="formSearch['intention_type']" placeholder='请选择意向' :config="{ cacheKey: 'c_intention', placeholder: '请选择意向' }">
              </component> -->
              <Select v-model="formSearch.intention_type" placeholder='请选择意向' clearable>
                <Option v-for="(item,index) in enums.c_intention" :key="index" :value="item.value" :label="item.name"></Option>
              </Select>
              </Col>
            </Form-item>
            </Col>
          </Row>
          <Row>
            <Col span="8">
            <FormItem label="拜访类型">
              <Select v-model="formSearch.visit_type" not-found-text='无匹配数据' clearable placeholder="请选择拜访类型" style="width:100%;">
                <Option v-for="item in typeList" :key="item.value" :label="item.name" :value="item.value">
                </Option>
              </Select>
            </FormItem>
            </Col>
          </Row>
          </Row>
        </div>
      </search-area>
    </div>
    <!-- 导出按钮 -->
    <div class="clear">
      <Button type="primary" @click="fastAddRecord" style="margin-right: 5px;">快速新增私募拜访记录</Button>
      <Button type="primary" style="margin-right: 5px;" @click="addVisitWithNoTarget">新增拜访记录</Button>
      <Button type="primary"  @click="onExport(3)">导出</Button>
    </div>
    <!-- 表格 -->
    <div class="tableContainer">
      <Table 
        class="table-grid" 
        ref="commontable" 
        border 
        :columns="columns" 
        :data="tableData" 
        v-loading="tableLoading" 
        element-loading-text="拼命加载中" />
    </div>
    <!-- 分页器 -->
    <div class="page-load">
      <div class="float-right">
        <Page :total="total" placement="top" :current="currentPage" :page-size="pageSize" @on-change="onPageChange" @on-page-size-change="onPageSizeChange" show-elevator show-sizer show-total />
      </div>
    </div>
    <!-- 子组件，显示编辑界面 -->
    <visit-contact-dialog ref="vistContact" :orgId="visitProps.orgId" :memberData="visitProps.memberData" :showType='showType' @refreshTable="refreshTable">
    </visit-contact-dialog>
    <share ref="share"></share>
    <visit-record-without-target ref="visitRocordWithoutTarget" @refreshTable="refreshTable"></visit-record-without-target>
    <fastAddModal ref="fastAddModal" @refreshTable="refreshTable"></fastAddModal>
  </div>
</template>
<script>
import searchArea from "../../components/search-area";
import SelectUrl from "@/components/inputs/select-url";
import { getCache } from "@/plugin/cache";
import { extend, each } from "underscore";
import {
  fetchGrid,
  fetchWorkmate,
  getReciver,
  delRow,
  fetchUser
} from "@/service/getData";
import visitContactDialog from "../contact-manager/visit-contact-dialog";
import visitRocordWithoutTarget from "./visit-record-without-target";
import fastAddModal from "./fast-add-modal.vue";
import { mapGetters } from "vuex";
import share from "./share";
import $ from "jquery";
import moment from "moment";
import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  mixins: [getMinusNumber],
  components: {
    SelectUrl,
    visitContactDialog,
    searchArea,
    share,
    fastAddModal,
    "visit-record-without-target": visitRocordWithoutTarget
  },
  watch: {
    "formSearch.visit_time": {
      handler(val) {
        if (val && val[0]) {
          this.formSearch.visit_time[0] = this.setTimeZone(val[0]);
          this.formSearch.visit_time[1] = this.setTimeZone(val[1]);
        }
      },
      deep: true
    },
    "formSearch.order_time": {
      handler(val) {
        if (val && val[0]) {
          this.formSearch.order_time[0] = this.setTimeZone(val[0]);
          this.formSearch.order_time[1] = this.setTimeZone(val[1]);
        }
      },
      deep: true
    },

    visitStatus: {
      handler(val) {
        if (val.saleId) {
          this.$set(this.formSearch, "dept_id", 16);
          this.$set(this.formSearch, "update_member_id", val.saleId);
          this.$set(this.formSearch, "visit_time", [
            val.startDate,
            val.endDate
          ]);
          this.onDepartChange(this.formSearch.dept_id);
          this.showByAlysis = true;
          setTimeout(() => {
            this.$refs.form.expandMore();
          }, 0);
          this.changeSearchParam(true);
          this.search();
        }
      },

      deep: true,

      immediate: true
    }
  },

  destroyed() {
    this.$store.dispatch("setVisitStatus", {
      saleId: "",
      startDate: "",
      endDate: ""
    });
    this.showByAlysis = false;
    this.isShowMoreParams = false;
  },

  data() {
    return {
      hasDept: false,
      // 是否是通过统计页面跳转过来
      showByAlysis: false,
      typeList: [],
      // deptId: "",
      isShowMoreParams: false,
      orgList: [],
      paramsOfDownload: {},
      tableLoading: false,
      //加载动画
      loading: false,
      //表格数据
      tableData: [],
      //每页数量
      pageSize: 10,
      //总数量
      total: 0,
      //当前页面
      currentPage: 1,
      //判断是否是搜索，便于加载不同的表格
      isSearch: false,
      //传递给服务器的参数
      formSearch: {
        contacts_name: "",
        visit_time: [],
        depart_id: [],
        oc_id: [],
        order_time: [],
        dept_id: "",
        update_member_id: "",
        intention_type: "",
        demand_ids: [],
        org_name: "",
        visit_type: ""
      },
      listUrl: "/index/visit",
      export: "/index/visitexport",
      dialogShow: false,
      visitProps: {
        memberData: {}
      },
      showType: "visit",
      chosenDepartment: "",
      department: [],
      // 拜访时间
      dateV: [],
      // 回访时间
      dateO: [],
      workmate: [],
      choose: true,
      person: ""
    };
  },

  mounted() {
    // this.getDeptId();
    this.loading = true;
    if (!this.showByAlysis) {
      this.updateGrid();
    }
    this.getDepartment();
    this.orgList = this.enums.c_depart;
    this.typeList = this.enums.c_visit_type;
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".searchArea", ".clear", ".page-load"],
      ".tableContainer"
    );
  },

  computed: {
    ...mapGetters({
      userId: "getUserId",
      enums: "getEnums",
      tabs: "getTabs",
      visitStatus: "getVisitStatus"
    }),

    // 表头
    columns() {
      return [
        {
          title: "拜访时间",
          key: "visit_time",
          width: 90,
          fixed: "left",
          render(h, params) {
            return h(
              "p",
              params.row.visit_time ? params.row.visit_time : "未设"
            );
          }
        },
        {
          title: "拜访人",
          width: 80,
          key: "update_member_id",
          fixed: "left",
          render(h, params) {
            return h("p", params.row.visit_member_name);
          }
        },
        {
          title: "拜访对象",
          key: "contacts_name",
          width: 80,
          fixed: "left"
        },
        {
          title: "其他接待人",
          key: "other_contacts_name",
          width: 80,
          fixed: "left",
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  maxWidth: "80px",
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  cursor: "pointer"
                },
                attrs: {
                  title:
                    row.other_contacts_name.map(item => item.name).join(",") ||
                    ""
                }
              },
              row.other_contacts_name.map(item => item.name).join(",") || "--"
            );
          }
        },
        {
          title: "机构名称",
          key: "org_name",
          width: 400,
          render: (h, params) => {
            if (params.row.bread.length >= 3) {
              return h(
                "div",
                params.row.bread
                  .map((bread, index, breads) => {
                    return h(
                      "a",
                      {
                        on: {
                          click: e => {
                            let tab = {
                              activeName: bread.title,
                              pid: bread.id,
                              name: `${bread.title}${bread.id}`,
                              component: "departmentDetails",
                              isShow: true
                            };
                            this.$store.dispatch("setTabs", tab);
                            // if (
                            //   this.tabs.some(item => {
                            //     return (
                            //       item.name === tab.name && item.pid === tab.pid
                            //     );
                            //   })
                            // ) {
                            //   let newtabs = this.tabs.map(item => {
                            //     if (item.name == tab.name) {
                            //       item.isShow = true;
                            //     }
                            //     return item;
                            //   });
                            //   this.$store.dispatch("setTabsAll", newtabs);
                            //   this.$store.dispatch("setActiveTab", {
                            //     activeTab: tab.name
                            //   });
                            // } else {
                            //   this.$store.dispatch("setTabs", tab);
                            //   this.$store.dispatch("setActiveTab", {
                            //     activeTab: tab.name
                            //   });
                            // }
                            e.stopPropagation();
                          }
                        }
                      },
                      index === breads.length - 1
                        ? `${bread.title}`
                        : `${bread.title}>`
                    );
                  })
                  .splice(1)
              );
            } else {
              return h(
                "a",
                {
                  on: {
                    click: e => {
                      let tab = {
                        activeName: params.row.org_name,
                        pid: params.row.org_id,
                        name: `${params.row.org_name}${params.row.org_id}`,
                        component: "departmentDetails",
                        isShow: true
                      };
                      this.$store.dispatch("setTabs", tab);
                      // if (
                      //   this.tabs.some(item => {
                      //     return item.name === tab.name && item.pid === tab.pid;
                      //   })
                      // ) {
                      //   let newtabs = this.tabs.map(item => {
                      //     if (item.name == tab.name) {
                      //       item.isShow = true;
                      //     }
                      //     return item;
                      //   });
                      //   this.$store.dispatch("setTabsAll", newtabs);
                      //   this.$store.dispatch("setActiveTab", {
                      //     activeTab: tab.name
                      //   });
                      // } else {
                      //   this.$store.dispatch("setTabs", tab);
                      //   this.$store.dispatch("setActiveTab", {
                      //     activeTab: tab.name
                      //   });
                      // }
                      e.stopPropagation();
                    }
                  }
                },
                params.row.org_name
              );
            }
          }
        },
        {
          title: "部门类型",
          key: "depart_id",
          width: 100,
          render: (h, params) => {
            let cDepart = getCache("c_depart", params.row.depart_id);
            return h("p", cDepart);
          }
        },
        {
          title: "意向",
          width: 100,
          key: "intention_type",
          render: (h, params) => {
            let cDepart = getCache("c_intention", params.row.intention_type);
            return h("p", cDepart);
          }
        },
        {
          title: "需求点",
          width: 200,
          key: "demand_ids",
          render: (h, params) => {
            let demand_ids = params.row.demand_ids
              ? JSON.parse(params.row.demand_ids)
              : [];
            let demandsAll = getCache("c_demand");
            let demands = [];
            for (let i = 0; i < demand_ids.length; i++) {
              for (let j = 0; j < demandsAll.length; j++) {
                if (demandsAll[j].value == demand_ids[i]) {
                  demands.push(demandsAll[j].name);
                }
              }
            }
            if (demands.length == 0) {
              demands.push("未知");
            }
            return h("p", demands ? demands.join(",") : "未知");
          }
        },
       
         {
          title: "拜访类型",
          key: "visit_type",
          width: 80,
          render: (h, { row }) => {
            let visitType = getCache("c_visit_type");
            let map = {};
            visitType.forEach(v => {
              map[v.value] = v.name;
            });
            return h("span", map[row.visit_type]);
          }
        },
        {
          title: "预设回访时间",
          key: "order_time",
          width: 100,
          render(h, params) {
            return h(
              "p",
              params.row.order_time ? params.row.order_time : "未设"
            );
          }
        },
        {
          title: "更新时间",
          key: "update_time",
          width: 100,
          render: (h, row) => {
            let date = row.row.update_time;
            return h("span", date.split(" ")[0]);
          }
        },
        {
          title: "操作",
          key: "action",
          align: "left",
          width: 140,
          fixed: "right",
          render: (h, params) => {
            return h(
              "div",
              {
                on: {
                  click: e => {
                    e.stopPropagation();
                    return false;
                  }
                }
              },
              [
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    style: {
                      backgroundColor: "none"
                    },
                    on: {
                      click: () => {
                        this.onRowDblclick(params.row);
                      }
                    }
                  },
                  "拜访"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    style: {
                      backgroundColor: "none"
                    },
                    on: {
                      click: () => {
                        this.$refs.share.show(
                          JSON.parse(JSON.stringify(params.row))
                        );
                      }
                    }
                  },
                  "分享"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: params.row.visit_member_id == this.userId ? "deleteBtn" : "disabledBtn",
                      // disabled: true
                    },
                    style: {
                      backgroundColor: "none",
                    },
                    on: {
                      click: () => {
                        this.deleteVisitRow(
                          params.row.visit_member_id,
                          params.row.id
                        );
                      }
                    }
                  },
                  "删除"
                )
              ]
            );
          }
        }
      ];
    }
  },

  methods: {
    // 快速添加拜访记录
    fastAddRecord() {
      this.$refs.fastAddModal.show("fastAdd");
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 113;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },
    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },
    // 新增或者修改后刷新表格
    refreshTable() {
      this.updateGrid();
    },

    // getDeptId() {
    //   fetchUser().then(res => {
    //     this.deptId = res.data.dept_id;
    //   });
    // },

    // 控制更多打开时传递的参数

    changeSearchParam(val) {
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".searchArea", ".clear", ".page-load"],
          ".tableContainer"
        );
      });

      this.isShowMoreParams = val;
    },

    // 获取部门下拉

    getDepartment() {
      fetchWorkmate().then(res => {
        if (res.code == 20000) {
          this.department = res.data;
        }
      });
    },

    // onCascaderChange(val) {
    //   this.choose = true;
    //   this.workmate = [];
    //   this.formSearch.dept_id = val;
    //   let data = {
    //     dept_id: this.formSearch.dept_id,
    //     type: 1
    //   };
    //   if (!val) {
    //     return;
    //   }
    //   this.getWorkmate(data);
    // },

    onDepartChange(val) {
      this.workmate = [];
      let data = {
        dept_id: val,
        type: 1
      };

      if (!val) {
        this.hasDept = false;
        return;
      }
      this.hasDept = true;
      this.getWorkmate(data);
    },

    getWorkmate(data) {
      getReciver(data).then(res => {
        if (res.code == 20000) {
          this.workmate = res.data;
        }
      });
    },

    onPersonChange(val) {
      if (!val) {
        this.hasDept = false;
      }
    },

    // 清除没有值的参数
    abandonUselessParams(params) {
      let param = {};
      for (let key in params) {
        if (Array.isArray(params[key])) {
          if (params[key].length && params[key][0]) {
            param[key] = params[key];
          }
        } else {
          if (params[key]) {
            param[key] = params[key];
          }
        }
      }
      return param;
    },

    //用于管理传递的参数
    params(val) {
      let searchKeys = {};
      let beginingParams = this.abandonUselessParams(this.formSearch);
      if (this.searching) {
        // 搜索条件打开与收起时发送的参数不同
        if (!this.isShowMoreParams) {
          for (let key in beginingParams) {
            if (
              key == "visit_time" ||
              key == "contacts_name" ||
              key == "org_name"
            ) {
              // 收起参数时，最多只能有这三个键值
              searchKeys[key] = beginingParams[key];
              if (beginingParams.org_name) {
                searchKeys.org_name = JSON.parse(
                  JSON.stringify(beginingParams.org_name)
                )
                  .trim()
                  .split(/[ ]+/);
              } else {
                searchKeys.org_name = [];
              }
            }
          }
        } else {
          for (let key in beginingParams) {
            searchKeys[key] = beginingParams[key];
            if (beginingParams.org_name) {
              searchKeys.org_name = JSON.parse(
                JSON.stringify(beginingParams.org_name)
              )
                .trim()
                .split(/[ ]+/);
            } else {
              searchKeys.org_name = [];
            }
          }
        }
      } else if (val) {
        // 重置
        searchKeys = beginingParams;
      }
      this.paramsOfDownload = searchKeys;
      searchKeys.order = "visit_time desc,update_time desc";
      return extend(
        {
          rows: this.pageSize,
          page: this.currentPage
        },
        searchKeys
      );
    },

    //导出参数
    paramsDown(val) {
      return extend(
        {
          rows: this.total > 1000 ? 1000 : this.total,
          page: this.currentPage
        },
        this.paramsOfDownload
      );
    },

    //更新表格
    updateGrid(val) {
      this.tableLoading = true;
      fetchGrid(this.listUrl, this.params(val)).then(
        resp => {
          resp = resp.data;
          this.tableData = resp.data;
          this.total = resp.total;
          this.loading = false;
          this.tableLoading = false;
        },

        error => {
          this.loading = false;
          console.log(error);
        }
      );
    },

    //搜索
    search() {
      this.searching = true;
      this.cleanAndUpdateGrid();
    },

    //回到第一页并更新表格
    cleanAndUpdateGrid(val) {
      this.currentPage = 1;
      this.pageSize = 10;
      this.updateGrid(val);
    },

    //页码改变
    onPageChange(val) {
      this.currentPage = val;
      this.updateGrid();
    },

    //单页显示数量发生改变
    onPageSizeChange(val) {
      this.currentPage = 1;
      this.pageSize = val;
      this.updateGrid();
    },

    //重置
    onReset() {
      this.searching = false;
      this.formSearch.contacts_name = "";
      this.formSearch.visit_time = [];
      this.formSearch.depart_id = [];
      this.formSearch.oc_id = [];
      this.formSearch.order_time = [];
      this.person = "";
      this.chosenDepartment = "";
      this.formSearch.dept_id = "";
      this.formSearch.update_member_id = "";
      this.formSearch.intention_type = "";
      this.formSearch.demand_ids = [];
      this.formSearch.org_name = "";
      this.formSearch.visit_type = "";
      this.cleanAndUpdateGrid(true);
    },

    //导出
    onExport(type) {
      if (this.total === 0) {
        this.$Message.warning({
          content: "无可导出数据"
        });
        return;
      }
      this.$Message.loading({
        content: "正在导出中，请稍候...",
        duration: 0
      });
      fetchGrid(this.export, this.paramsDown()).then(
        resp => {
          if (resp.code == 20000) {
            resp = resp.data;
            const link = document.createElement("a");
            link.href = resp.url;
            link.target = "_blank";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }
          this.$Message.destroy();
          this.$Message.info("导出成功！");
        },

        error => {
          this.$Message.destroy();
          this.$Message.warning("导出失败！");
          console.log(error);
        }
      );
    },

    //   编辑显示模态框
    onRowDblclick(row) {
      let params = {
        tabShow: "visit",
        personId: row.contacts_id,
        personName: row.contacts_name,
        orgId: row.org_id,
        visitorId: row.visit_member_id
      }
      this.$refs.vistContact.show(params);
    },

    //重置搜索区域
    handleReset(name) {
      this.$refs[name].$refs[name].resetFields();
    },

    //删除当前行拜访记录
    deleteVisitRow(id, contactId) {
      // let contactId = contactId
      let that = this;
      if (id == this.userId) {
        this.$Modal.confirm({
          title: "删除",
          content: "删除当前拜访记录？",
          okText: "确定",
          cancelText: "取消",
          loading: true,
          onOk: id => {
            delRow("index/visit/", contactId).then(function(response) {
              if (response.code === 20000) {
                that.$Message.info("删除成功");
                that.cleanAndUpdateGrid();
              } else {
                that.$Message.error(response.msg);
              }
              that.$Modal.remove();
            });
          }
        });
      } else {
        this.$Modal.remove();
        // this.$Message.warning("只能删除自己的拜访信息");
        return false;
      }
    },

    addVisitWithNoTarget() {
      this.$refs.visitRocordWithoutTarget.show();
    }
  }
};
</script>
<style lang="less" scoped>
// 组件整体样式
.grid-content {
  // margin: 5px;
  // padding-top: 30px;
  position: relative;
}

//  搜索区域样式
.form.ivu-form.ivu-form-label-right {
  border-bottom: 1px solid rgb(233, 234, 236);
  padding: 30px 200px 20px 0px;
}

.clear{
  margin: 15px 0
}

//搜索选项样式
.ivu-form-item {
  // width: 90%;
}

//  导出按钮样式
.pull-right.ivu-btn.ivu-btn-primary {
  float: right;

  margin: 8px 0px;
} //  表格样式
.table-grid {
  margin-top: 5px;
}

// 分页器样式
.page-load {
  margin: 10px;
  overflow: hidden;
  .float-right {
    float: right;
  }
}
</style>
