<template>
  <Modal
    :width="modalWidth"
    v-model="modal"
    title="快速新增私募拜访记录"
    :loading="modalLoading"
    :mask-closable="false"
    class="fullfill-modal fast-add add-contracts-modal"
    :animated ="false"
   >

    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button size="large" style="width:70px;" @click="cancel">取消</Button>
      <Button type="primary" size="large" style="width:70px;" :loading="buttonLoading" @click="ok">提交</Button>
    </div>

    <div class="fast-add-info">
      <div  class="fast-add-info org-fast-add">
          <div >
            <!-- 机构 -->
             <Form ref="formOrg" :model="orgInfo" :label-width="100" :rules='orgValidateRules'>
               <Row class="form-title">
                 <Col span="24">
                   <h3>机构<span style="font-size:12px;">（仅含私募）</span></h3>
                 </Col>
               </Row>

               <Row>
                 <Col span="11">
                  <FormItem label="机构" prop="orgId">
                    <Select
                      placeholder="请选择私募"
                      transfer
                      style="width:300px;"
                      v-model="orgInfo.orgId"
                      filterable
                      remote
                      :remote-method="remoteOrg"
                      :loading="orgLoading"
                      @on-change="selectOrg">
                      <Option v-for="(option, index) in orgOptions" :value="option.value +''" :key="index">{{option.name}}</Option>
                    </Select>
                  </FormItem>
                  <FormItem label="部门" prop="deptId" v-if="deptOptions.length > 0">
                    <Select
                      transfer
                      clearable
                      style="width:300px;"
                      v-model="orgInfo.deptId"
                      :loading="deptLoading"
                      @on-change="selectDept">
                      <Option v-for="(option, index) in deptOptions" :value="option.value" :key="index">{{option.name}}</Option>
                    </Select>
                  </FormItem>
                </Col>
               </Row>
               <Row>
                  <Col span="24" style="padding-left:100px;">
                    <span style="color:#ed3f14;" v-if="orgId">{{addDept}}</span>
                  </Col>  
               </Row> 
                <p style="color:#ed3f14;margin-left:100px;margin-top:-10px;" v-if="ifHasContacts">注:该机构/部门下暂无直属联系人</p>
             </Form>
             <!-- 机构end -->


             <!-- 联系人 -->
             <div >
               <Form ref="formContact" :model="contactInfo" :label-width="100" :rules='cantactValidateRules' >
                 <Row class="form-title">
                   <Col span="24">
                     <h3>联系人</h3>
                   </Col>
                 </Row>

                <Row>
                  <Col>
                    
                    <Form ref="contactTypeForm" :model="contactType" :label-width="100" :rules="cantactTypeValidateRules">
                       <FormItem label="请选择" prop="isNewContact">
                         <RadioGroup v-model="contactType.isNewContact" @on-change="onChooseContactType" >
                            <Radio label="oldPerson">
                              <span>选择已有联系人</span>
                            </Radio>
                            <Radio label="newPerson">
                              <span>新建联系人</span>
                            </Radio>
                         </RadioGroup>
                       </FormItem>
                    </Form>

                  </Col>
                </Row>
                <div v-if="contactType.isNewContact">
                  <Row>
                     <Col span="11" v-if="contactType.isNewContact=='newPerson'">
                       <FormItem label="姓名" prop="name" class="ivu-form-item-required">
                         <Input
                           placeholder="请输入姓名"
                           class="org-name-input"
                           v-model.trim="contactInfo.name"
                         >
                         </Input>
                       </FormItem>
                     </Col>

                     <Col v-else span="11" >
                       <FormItem label="姓名" prop="contactId" class="ivu-form-item-required">
                         
                         <div @click.once="onContactSelectFocus">
                             <Select
                               ref="contactSelect"
                               v-model="contactInfo.contactId"
                               label-in-value
                               filterable
                               remote
                               :remote-method="remoteContact"
                               :loading="contactLoading"
                               @on-change="selectContact"
                               >
                                 <Option v-for="(option, index) in contactOptions" :value="option.value" :key="index">{{option.name}}</Option>
                             </Select>
                         </div>
                         
                       </FormItem>
                     </Col>
                     <Col span="11" v-if="contactType.isNewContact=='newPerson'">
                        <FormItem label="职务" prop="post">
                           <Input
                              placeholder="请输入职务"
                              :disabled="ifContactDisabled"
                              v-model.trim="contactInfo.post"
                              style="width:100%;">
                           </Input>
                        </FormItem>
                     </Col>
                   </Row>

                   <div v-if="contactType.isNewContact=='newPerson'">
                       <Row>
                         <Col span="11">
                           <FormItem label="电话" prop="telephone">
                              <Input
                                 placeholder="请输入电话"
                                 :disabled="ifContactDisabled"
                                 v-model.trim="contactInfo.telephone"
                                 style="width:100%;">
                              </Input>
                           </FormItem>
                         </Col>
                         <Col span="11">
                           <FormItem label="微信" prop="weichat">
                             <Input
                                 placeholder="请输入微信"
                                 :disabled="ifContactDisabled"
                                 v-model.trim="contactInfo.weichat"
                                 style="width:100%;">
                              </Input>
                           </FormItem>
                         </Col>
                       </Row>

                       <Row>
                         <Col span="11">
                           <FormItem label="用户" prop="contacts_type">
                             <Select v-model="contactInfo.contacts_type" placeholder="请选择" :disabled="ifContactDisabled">
                               <Option v-for="item in emnus.c_usertype" :value="item.value" :key="item.value">
                                 {{item.name}}
                               </Option>
                             </Select>
                           </FormItem>
                         </Col>
                         <Col span="11">
                           <FormItem label="邮箱" prop="email">
                             <Input
                                 placeholder="请输入邮箱"
                                 :disabled="ifContactDisabled"
                                 v-model.trim="contactInfo.email"
                                 style="width:100%;">
                              </Input>
                           </FormItem>
                         </Col>
                       </Row>

                       <Row>
                         <Col span="11">
                            <FormItem label="性别" prop="sex">
                              <Select v-model="contactInfo.sex" placeholder="请选择" :disabled="ifContactDisabled">
                                <Option v-for="item in emnus.c_sex" :value="item.value" :key="item.value">
                                  {{item.name}}
                                </Option>
                              </Select>
                            </FormItem>
                         </Col>
                         <Col span="11">
                            <FormItem label="年龄" prop="age">
                              <Select v-model="contactInfo.age" placeholder="请选择" :disabled="ifContactDisabled">
                                <Option v-for="item in emnus.c_age" :value="item.value" :key="item.value">
                                  {{item.name}}
                                </Option>
                              </Select>
                            </FormItem>
                         </Col>
                       </Row>

                       <Row>
                         <Col span="22">
                         <FormItem label="画像" prop="portrait">
                           <Select v-model="contactInfo.portrait" multiple placeholder="请选择">
                             <Option v-for="item in emnus.c_port_all" :value="item.value" :key="item.value">
                               <Tag :style="item.style">{{item.name}}</Tag>
                             </Option>
                           </Select>
                         </FormItem>
                         </Col>
                       </Row>
                    </div>
                </div>
              </Form>
            </div>
      <!-- 联系人end -->


       <!-- 拜访记录 -->
              <Form ref="formVisit" :model="visitInfo" :label-width="100" :rules='visitRecordValidateRules'>
                <Row class="form-title">
                  <Col span="24">
                    <h3>拜访记录</h3>
                  </Col>
                </Row>

                <Row>
                  <Col span="11">
                     <FormItem label="拜访人" prop="trueName">
                       <span>{{sysUserInfo.trueName}}</span>
                     </FormItem>
                  </Col>
                  <Col span="11">
                     <FormItem label="拜访对象" prop="name">
                       <span>{{contactInfo.name}}</span>
                     </FormItem>
                  </Col>
                </Row>

                <Row>
                  <Col span="11">
                     <FormItem label="拜访日期" prop="visitTime">
                       <Date-picker type="date" v-model="visitInfo.visitTime" placeholder="拜访日期" style="width:100%;">
                       </Date-picker>
                     </FormItem>
                  </Col>
                  <Col span="11">
                     <FormItem label="预设回访" prop="orderTime">
                       <Date-picker type="date" v-model="visitInfo.orderTime" placeholder="预设拜访" style="width:100%;">
                       </Date-picker>
                     </FormItem>
                  </Col>
                </Row>

                <Row>
                  <Col span="11">
                     <FormItem label="拜访类别" prop="visitType">
                       <Select v-model="visitInfo.visitType">
                         <Option v-for="(item, index) in emnus.c_visit_type" :key="index" :value="item.value">
                           {{item.name}}
                         </Option>
                       </Select>
                     </FormItem>
                  </Col>
                </Row>

                <Row>
                  <Col span="22">
                     <FormItem label="意向" prop="intentionType">
                       <RadioGroup v-model="visitInfo.intentionType">
                         <Radio v-for="(item, index) in emnus.c_intention" :key="index" :label="item.value">
                           {{item.name}}
                         </Radio>
                       </RadioGroup>
                     </FormItem>
                  </Col>
                </Row>

                <Row>
                  <Col span="22">
                     <FormItem label="需求点" prop="demandIds">
                       <Checkbox-group v-model="visitInfo.demandIds">
                         <Checkbox v-for="(item, index) in emnus.c_demand" :label="item.value" :key="index">
                           {{ item.name }}
                         </Checkbox>
                       </Checkbox-group>
                     </FormItem>
                  </Col>
                </Row>

                <Row>
                  <Col span="22">
                     <FormItem label="交谈内容" prop="chatIds">
                       <Checkbox-group v-model="visitInfo.chatIds">
                         <Checkbox v-for="(item, index) in emnus.c_chat_content" :label="item.value" :key="index">
                           {{ item.name }}
                         </Checkbox>
                       </Checkbox-group>
                     </FormItem>
                  </Col>
                </Row>

                <Row>
                  <Col span="22">
                     <FormItem label="日志" prop="visitContent">
                       <Input
                          type="textarea"
                          v-model.trim="visitInfo.visitContent"
                          :autosize="{minRows: 3,maxRows: 5}"
                          placeholder="请输入内容">
                       </Input>
                     </FormItem>
                  </Col>
                </Row>

                <!-- 提醒谁看 -->
                <Row>
                  <Col span="22">
                    <Form-item label="提醒谁看" prop="remind_person" style="margin-top: 10px;">
                      <row>
                        <Col span="8" style="float:left">
                           <div :class="{chosenPeople:choosePeople}">
                             <div class="show_container" :class="{showMorePeople:showHeight}">
                               <p class="show-content" @click="showPeopleModal">
                                 <span v-if="selectedPeopleName.length">{{selectedPeopleName.join(', ')}}</span>
                                 <span v-else class="placeholder">单击选择收件人</span>
                               </p>
                               <div
                                  class="total"
                                  @click="showPeopleModal"
                                  title="选择需要分享的人"
                                  v-if="this.selectedPeopleName.length">
                                           共{{this.selectedPeopleId.length}}人
                              </div>
                               <div class="tool" @click="showMorePeople" v-if="selectedPeopleName.length">
                                 <span class="text">{{!showHeight?"更多":"收起"}}</span>
                                 <div class="icon-container" v-if="!showHeight">
                                   <Icon :size="18" color="#666" class="icon" type="ios-arrow-down"></Icon>
                                   <Icon :size="18" color="#666" class="icon second" type="ios-arrow-down"></Icon>
                                   <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-down"></Icon>
                                 </div>
                                 <div class="icon-container" v-else>
                                   <Icon :size="18" color="#666" class="icon" type="ios-arrow-up"></Icon>
                                   <Icon :size="18" color="#666" class="icon second" type="ios-arrow-up"></Icon>
                                   <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-up"></Icon>
                                 </div>
                               </div>
                             </div>
                           </div>
                           <p style="color:red;" v-show="choosePeople">请先选择接收人！</p>
                        </Col>
                        <Col span="15" offset="1" style="float:left">
                           <Input
                              type="textarea"
                              class="share-container"
                              v-model.trim="shareContent"
                              style="height:40px;"
                              :autosize="{minRows: 1,maxRows: 2}"
                              placeholder="请输入分享内容...">
                           </Input>
                        </Col>
                     </row>
                   </Form-item>
                  </Col>
                </Row>
                <!-- 提醒谁看end -->
              </Form>
    <!-- 拜访记录end -->
       </div>
     </div>

     <!-- 关联拜访记录 -->
     <div  class="fast-add-info org-visit-records">
          <div class="visit-record-title" style="position:fixed;z-index:999;background:white;">
            <h4 class="form-title" style="padding:7px;" >机构拜访记录</h4>
          </div>
          <div
             v-if="relatedVisitRecord.length==0"
             class="vsit-time-line"
             style="text-align:center;;margin:0 auto;padding-top:20px;margin-top:30px;">
                   {{relatedVisitText}}
          </div>
          <div class="vsit-time-line" v-else style="margin-top:50px">
            <div class="demo-spin-col" v-if="timeLineDataLoading">
              <Spin fix>
                <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
                <div>拼命加载中...</div>
              </Spin>
            </div>
            <Timeline pending v-else>
              <TimelineItem v-for="(item,index) in relatedVisitRecord" :key="index" :class="{itemColor:index%2==1}">
                <!-- 拜访时间 -->
                <p class="content visitTime">{{item.visit_time}}</p>
                <!-- 拜访人 -->
                <p class="content visitMember">
                  <span class="visit-people">拜访人：<span style="font-weight:900;color:#495060;">{{item.visit_member_name}}</span></span>

                </p>
                <!-- 拜访对象 -->
                <p class="content">
                  <span class="content-title" style="vertical-align:top;">拜访对象：</span>
                  <span class="content-box">
                     <span style="font-weight:900;margin-right: 5px;">{{item.contacts_name}}</span>
                     <span style="opacity: 0.85">({{getCompany(item).join(' ')}})</span>
                     <br>
                     <span v-if="item.is_cbo" style="color:red;">[已离职]</span>
                  </span>
                </p>
                <!-- 拜访类型 -->
                <P class="content">
                  <span class="content-title">拜访类型：</span>
                  <span class="content-box">
                      <Tag>{{getType(item.visit_type)}}</Tag>
                  </span>
                </P>
                <!-- 需求点 -->
                <p class="content" v-show="getDemands(item.demand_ids)">
                  <span class="content-title">需&nbsp;&nbsp;求&nbsp;&nbsp;点：</span>
                  <span class="content-box">
                    <Tag v-for="(item,index) in getDemands(item.demand_ids)" :key="index">{{item}}</Tag>
                  </span>
                </p>
                <!-- 意向 -->
                <p class="content">
                  <span class="content-title">意&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;向：</span>
                  <span class="content-box">
                    <Tag>{{getIntention(item.intention_type)}}</Tag>
                  </span>

                </p>
                <!-- 交谈内容 -->
                <p class="content" v-show="getChats(item.chat_ids)">
                  <span class="content-title">交谈内容：</span>
                  <span class="content-box">
                    <Tag v-for="(item,index) in getChats(item.chat_ids)" :key="index">{{item}}</Tag>
                  </span>
                </p>
                <!-- 日志 -->
                <div class="content" style="width:100%;">
                  <span style="vertical-align:top;" class="content-title">日&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;志：</span>
                  <span style="line-height:24px;font-weight:900;" class="content-box">{{item.visit_content||"无"}}</span>
                </div>
              </TimelineItem>
              <TimelineItem>
                <p>已经是最后一条了！</p>
              </TimelineItem>
            </Timeline>
          </div>
     </div>
   </div>

    <!-- 提醒人选择模态框组件 -->
    <people-tree ref="people" @getSelectedPeople="getSelectedPeople"></people-tree>
  </Modal>
</template>
<script>
import peopleTree from "../contact-manager/peopleTree.vue";
import moment from "moment";
import {
  fetchGrid,
  fullfillMessage,
  fastAddVisitRecord,
  getMessageCount,
  getRow
} from "@/service/getData";
import {
  cantactValidateRules,
  visitRecordValidateRules
} from "../organazition-fullfill/fullfillValidateRules.js";
import { mapGetters } from "vuex";
import $ from "jquery";
import { isEmpty } from "lodash";
export default {
  components: {
    peopleTree
  },

  data() {
    return {
      ifHasContacts: false,
      addDept: "",
      modalWidth: 1000,
      relatedVisitText: "选择机构后展示历史拜访记录",
      timeLineDataLoading: false,
      intention: [],
      demands: [],
      chats: [],
      typeList: [],
      // 当前机构关联的拜访记录
      relatedVisitRecord: [],
      contactTimerId: "",
      // 控制联系人信息是否可填写
      ifContactDisabled: false,
      // 机构验证规则
      orgValidateRules: {
        orgId: [{ required: true, message: "必选", trigger: "change, blur" }]
      },
      // 联系人验证规则
      cantactValidateRules: {},
      // 拜访记录验证规则
      visitRecordValidateRules: visitRecordValidateRules(),
      // 客户id
      userId: "",
      // 机构信息
      orgInfo: {
        orgId: "",
        deptId: ""
      },
      orgOptions: [],
      deptOptions: [],
      contactOptions: [],
      orgLoading: false,
      deptLoading: false,
      contactLoading: false,
      cantactTypeValidateRules: {
        isNewContact: [
          {
            required: true,
            message: "请先选择是否新建联系人",
            trigger: "change"
          }
        ]
      },
      contactType: {
        isNewContact: ""
      },
      // 联系人信息
      contactInfo: {
        contactId: "",
        name: "",
        post: "",
        telephone: "",
        email: "",
        sex: "",
        contacts_type: "",
        age: "",
        weichat: "",
        portrait: []
      },
      // 拜访内容
      visitInfo: {
        contactsName: "",
        chatIds: [],
        intentionType: "",
        visitMemberId: "",
        visitMemberName: "",
        visitContent: "",
        demandIds: [],
        visitType: "",
        visitTime: "",
        orderTime: ""
      },
      // 提醒的内容
      shareContent: "",
      // 选中提醒人的id
      selectedPeopleId: [],
      // 选中提醒人的名字
      selectedPeopleName: [],
      // 是否显示更多
      showHeight: false,
      //提醒的验证触发条件
      choosePeople: false,
      visitTime: "",
      orderTime: "",
      modal: false,
      modalLoading: false,
      buttonLoading: false
    };
  },

  watch: {
    "contactInfo.portrait": {
      handler(val) {
        this.setStyleOfSelectedPortrait(".fullfill-modal");
      },
      deep: true
    },

    "visitInfo.visitTime": {
      handler(val) {
        if (val) {
          this.visitTime = this.setTimeZone(val);
        }
      },
      deep: true
    },

    "visitInfo.orderTime": {
      handler(val) {
        if (val) {
          this.orderTime = this.setTimeZone(val);
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapGetters({
      emnus: "getEnums",
      sysUserInfo: "getUser"
    }),
    orgId() {
      return this.orgInfo.deptId || this.orgInfo.orgId;
    },

    visitTypeMapping() {
      return this.emnus.c_visit_type_mapping;
    }
  },
  mounted() {
    this.intention = this.emnus.c_intention;
    this.demands = this.emnus.c_demand;
    this.chats = this.emnus.c_chat_content;
    this.typeList = this.emnus.c_visit_type;

    // 验证联系人是否重复
    const validateRepeatPerson = (rule, value, callback) => {
      let params = {
        org_id: this.orgId,
        name: value
      };
      new Promise(resolve => {
        fetchGrid("/index/contactMatch", params).then(res => {
          let flag = res.data.some(item => {
            return item.name == value;
          });
          resolve(flag);
        });
      }).then(flag => {
        if (flag && this.contactType.isNewContact == "newPerson") {
          callback(new Error("联系人重复"));
        } else {
          callback();
        }
      });
    };
    // 验证新建时必须输入姓名
    const validateRequirePerson = (rule, value, callback) => {
      if (this.contactInfo.contactId) {
        callback();
      } else {
        if (!value) {
          callback(new Error("请输入姓名"));
        } else {
          callback();
        }
      }
    };

    // 验证选择时必选联系人
    const validateContactId = (rule, value, callback) => {
      if (this.contactType.isNewContact == "newPerson") {
        callback();
      } else {
        if (!value) {
          callback(new Error("请选择联系人"));
        } else {
          callback();
        }
      }
    };
    let cantactValidateRule = cantactValidateRules();
    cantactValidateRule.name.push(validateRepeatPerson);
    cantactValidateRule.name[0] = validateRequirePerson;
    cantactValidateRule.contactId = [validateContactId];
    this.cantactValidateRules = cantactValidateRule;
  },
  methods: {
    // 选择是否新建联系人
    onChooseContactType(type) {
      if (!this.orgId) {
        this.$refs.contactTypeForm.resetFields();
        this.$Message.warning("请先选择机构或部门!");
      }
      this.contactOptions = [];
      this.$refs.formContact.resetFields();
      this.$set(this.contactInfo, "name", "");
      this.clearContactData();
    },

    // 根据部门设置当前用户的默认拜访类别
    getVisitTypeOfCurrentUser() {
      let deptId = this.sysUserInfo.dept_id;
      let mapOfFilter = this.visitTypeMapping.filter(m => {
        return m.name === `${deptId}`;
      });
      let type = mapOfFilter.length ? mapOfFilter[0].value : "99";
      this.$set(this.visitInfo, "visitType", type + "");
    },

    // 设置模态框的宽度
    setModalWidth() {
      let bodyWidth = $("body").width();
      if (bodyWidth * 0.9 > 1000) {
        this.modalWidth = bodyWidth * 0.9;
      } else {
        this.modalWidth = 1000;
      }
      $("body")
        .find(".visit-record-title")
        .css("width", this.modalWidth - 660);
    },

    // 获取拜访类型
    getType(params) {
      let type = _.get(
        _.filter(this.typeList, data => {
          return data.value == params;
        })[0],
        "name"
      );
      return type;
    },

    // 获取意向真实字段
    getIntention(params) {
      let intention = _.get(
        _.filter(this.intention, data => {
          return data.value == params;
        })[0],
        "name"
      );
      return intention;
    },

    // 获取交谈内容真实字段
    getChats(params) {
      let param = [];
      if (params) {
        param = JSON.parse(params);
      } else {
        return;
      }
      let chat = [];
      let chats = [];
      chat = this.chats.filter(item => {
        return param.indexOf(item.value) != -1;
      });
      chats = chat.map(item => item.name);
      return chats;
    },

    // 获取需求点真实字段
    getDemands(params) {
      let param = [];
      if (params) {
        param = JSON.parse(params);
      } else {
        return;
      }
      let demand = [];
      let demands = [];
      demand = this.demands.filter(item => {
        return param.indexOf(item.value) != -1;
      });
      demands = demand.map(item => {
        return item.name;
      });
      return demands;
    },

    // 获取拜访记录的公司信息
    getCompany(item) {
      let componyNameList = item.bread
        .filter((data, index) => {
          return index != 0;
        })
        .map(data => {
          return data.title;
        });
      return componyNameList;
    },

    // 滚动条回到顶部事件
    scrollBackToTop() {
      $(this.$el)
        .find(".fast-add-info")
        .animate({ scrollTop: 0 });
    },

    // 机构
    remoteOrg(query) {
      this.$set(this.contactInfo, "name", "");
      this.$set(this.orgInfo, "deptId", "");
      this.clearContactData();
      this.deptOptions = [];
      if (!query) {
        this.orgOptions = [];
        return;
      }
      this.orgLoading = true;
      fetchGrid("/index/OrgMatch", {
        parent_org_id: 0,
        org_name: query,
        oc_id: 7
      }).then(resp => {
        this.orgLoading = false;
        if (resp.code === 20000) {
          this.orgOptions = resp.data || [];
        } else {
          this.orgOptions = [];
        }
      });
    },

    // 选定机构
    selectOrg(orgId) {
      this.getAllContactListByIdOrName();

      this.$set(this.contactInfo, "name", "");
      this.$set(this.orgInfo, "deptId", "");
      this.clearContactData();
      this.$refs.formContact.resetFields();
      this.$refs.contactTypeForm.resetFields();
      this.deptOptions = [];
      if (!orgId) {
        return;
      }

      this.getRelatedVisitRecord(orgId);
      this.deptLoading = false;
      fetchGrid("/index/OrgMatch", {
        parent_org_id: orgId
      })
        .then(resp => {
          this.deptLoading = false;
          if (resp.code === 20000) {
            this.deptOptions = resp.data || [];
          }
        })
        .then(() => {
          if (this.deptOptions.length) {
            this.addDept = "注:未选择部门,联系人将直接添加至该机构";
          } else {
            this.addDept = "注:无下级部门,联系人将直接添加至该机构";
          }
        });
    },

    // 选择机构下的部门时
    selectDept(deptId) {
      this.getAllContactListByIdOrName();
      this.$set(this.contactInfo, "name", "");
      this.clearContactData();
      this.$refs.formContact.resetFields();
      this.$refs.contactTypeForm.resetFields();
      if (!deptId) {
        this.addDept = "注:未选择部门,联系人将直接添加至该机构";
        this.getRelatedVisitRecord(this.orgInfo.orgId);
        return;
      }
      this.addDept = "注:已选择部门,联系人将直接添加至该部门";
      this.getRelatedVisitRecord(deptId);
    },

    // 获取所有联系人列表
    getAllContactListByIdOrName(orgName) {
      this.contactOptions = [];
      let params = {
        org_id: this.orgId,
        name: ""
      };
      fetchGrid("/index/contactMatch", params).then(res => {
        if (!res.data.length && this.orgId) {
          this.ifHasContacts = true;
        } else {
          this.ifHasContacts = false;
        }
      });
    },

    // 通过id或名称获取联系人列表
    getContactListByIdOrName(orgName) {
      this.contactOptions = [];
      let params = {
        org_id: this.orgId,
        name: orgName
      };
      this.contactLoading = true;
      return new Promise((resolve, reject) => {
        fetchGrid("/index/contactMatch", params).then(res => {
          this.contactLoading = false;
          this.contactOptions = this.contactOptions.concat(res.data);
          resolve();
        });
      });
    },

    //  第一次点击下拉，默认显示所有联系人
    onContactSelectFocus() {
      this.$refs.contactSelect.setQuery(" ");
    },

    // 模糊匹配联系人
    remoteContact(query) {
      clearTimeout(this.contactTimerId);
      this.contactTimerId = setTimeout(() => {
        this.getContactListByIdOrName(query);
      }, 500);
    },

    // 清空联系人数据
    clearContactData() {
      this.$set(this.contactInfo, "post", "");
      this.$set(this.contactInfo, "telephone", "");
      this.$set(this.contactInfo, "email", "");
      this.$set(this.contactInfo, "sex", "");
      this.$set(this.contactInfo, "contacts_type", "");
      this.$set(this.contactInfo, "age", "");
      this.$set(this.contactInfo, "weichat", "");
      this.$set(this.contactInfo, "portrait", []);
      this.ifContactDisabled = false;
    },

    // 选择联系人，展示该联系人对应的信息
    selectContact(val) {
      if (!isEmpty(val)) {
        if (val.label && val.value) {
          this.$set(this.contactInfo, "name", val.label.trim());
          this.ifContactDisabled = true;
        }
      }
    },

    //  根据id获取该联系人的信息
    getLinkedPeople(id) {
      getRow("/index/contact", id).then(res => {
        let baseData = res.data;
        baseData.portrait = baseData.portrait
          ? Array.isArray(baseData.portrait)
            ? baseData.portrait
            : JSON.parse(baseData.portrait).map(item => item + "")
          : [];
        this.$set(this.contactInfo, "post", baseData.post);
        this.$set(this.contactInfo, "telephone", baseData.telephone);
        this.$set(this.contactInfo, "email", baseData.email);
        this.$set(
          this.contactInfo,
          "sex",
          baseData.sex ? baseData.sex + "" : ""
        );
        this.$set(
          this.contactInfo,
          "contacts_type",
          baseData.contacts_type ? baseData.contacts_type + "" : ""
        );
        this.$set(
          this.contactInfo,
          "age",
          baseData.age ? baseData.age + "" : ""
        );
        this.$set(this.contactInfo, "weichat", baseData.weichat);
        this.$set(this.contactInfo, "portrait", baseData.portrait || []);
      });
    },

    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },

    //设置选中的画像的标签的样式
    setStyleOfSelectedPortrait(elClass) {
      setTimeout(() => {
        let el = $(elClass);
        let selectTags = $(el).find(".ivu-select-selection .ivu-tag");
        let selectTag = $(el).find(".ivu-select-selection .ivu-tag span");
        let tag = $(el).find(
          ".ivu-select-dropdown-list .ivu-select-item .ivu-tag span"
        );
        let tagContianer = $(el).find(
          ".ivu-select-dropdown-list .ivu-select-item .ivu-tag"
        );
        let tagStyle = [];
        for (let i = 0; i < tagContianer.length; i++) {
          for (let j = 0; j < selectTag.length; j++) {
            if (
              $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
            ) {
              $(selectTags.get(j))[0].setAttribute(
                "style",
                $(tagContianer.get(i))[0].getAttribute("style")
              );
            }
          }
        }
      }, 10);
    },

    // 是否显示更多人（提醒）
    showMorePeople() {
      if (!this.showHeight) {
        this.showHeight = true;
      } else {
        this.showHeight = false;
      }
    },

    // 获取选中的人（提醒）
    getSelectedPeople(selectedPerson) {
      this.selectedPeople = JSON.parse(JSON.stringify(selectedPerson));
      this.selectedPeopleName = selectedPerson.map(person => {
        return person.memberName;
      });
      this.selectedPeopleId = selectedPerson.map(person => {
        return person.id;
      });
    },

    // 显示选择提醒的人的modal
    showPeopleModal() {
      this.$refs.people.show(null, this.selectedPeopleId);
    },

    // 显示这个模态框
    show() {
      // this.getVisitTypeOfCurrentUser();
      this.setModalWidth();
      this.scrollBackToTop();
      this.modal = true;
    },

    // 点击确定
    ok() {
      let contactTypeFormValidate = new Promise((resolve, reject) => {
        this.$refs.contactTypeForm.validate(valid => {
          resolve(valid);
        });
      });
      let formOrgValidate = new Promise((resolve, reject) => {
        this.$refs.formOrg.validate(valid => {
          resolve(valid);
        });
      });
      let formContactValidate = new Promise((resolve, reject) => {
        this.$refs.formContact.validate(valid => {
          resolve(valid);
        });
      });
      let formVisitValidate = new Promise((resolve, reject) => {
        this.$refs.formVisit.validate(valid => {
          resolve(valid);
        });
      });

      //  快速新增
      Promise.all([
        contactTypeFormValidate,
        formOrgValidate,
        formContactValidate,
        formVisitValidate
      ]).then(([contactTypeValid, orgValid, contactValid, visitValid]) => {
        if (contactTypeValid && orgValid && contactValid && visitValid) {
          this.buttonLoading = true;
          fastAddVisitRecord(this.params()).then(res => {
            if (res.code === 20000) {
              if (this.params().msg) {
                this.$Message.info("已为您发送提醒消息！");
              }
              this.$Message.info("添加成功！");
              this.$emit("refreshTable");
              this.cancel();
              this.getMsgCount();
            } else {
              this.$Message.warning(res.msg);
            }
            this.buttonLoading = false;
          });
        } else {
          this.$Message.warning("请按红色字段填写内容！");
        }
      });
    },

    // 获取提醒消息数量
    getMsgCount() {
      getMessageCount().then(res => {
        let count = res.data.total;
        this.$store.dispatch("setMessageCount", {
          messageCount: count
        });
      });
    },

    // 提交的参数
    params() {
      let params = {};
      if (this.userId) {
        params.userid = this.userId;
      }
      // 如果选定了上级机构
      if (this.orgId) {
        params.parentOrgId = this.orgId;
      }
      // 联系人信息参数
      params.contactInfo = this.deleteUselessKey(this.contactInfo);
      if (this.contactInfo.contactId) {
        params.contactInfo.id = this.contactInfo.contactId;
      }
      // 拜访记录参数
      params.visit = {};
      params.visit = this.deleteUselessKey(this.visitInfo);
      params.visit.contactsName = this.contactInfo.name;
      params.visit.visitMemberId = this.sysUserInfo.id;
      params.visit.visitMemberName = this.sysUserInfo.trueName;
      params.visit.visitTime = this.visitTime;
      params.visit.orderTime = this.orderTime;
      // 选定了提醒的人时，就加上提醒的参数
      if (this.selectedPeopleId.length) {
        params.msg = {};
        params.msg["type"] = 4;
        params.msg["toIds"] = this.selectedPeopleId;
        params.msg.message =
          this.shareContent ||
          `${this.sysUserInfo.trueName}给$name分享了一条拜访记录[系统日志]`;
      }
      return params;
    },

    // 清除没有赋值的参数
    deleteUselessKey(paramObj) {
      let params = {};
      for (let key in paramObj) {
        if (paramObj[key] && paramObj[key].length) {
          params[key] = paramObj[key];
        } else if (paramObj[key] && typeof paramObj[key] === "object") {
          if (!Array.isArray(paramObj[key])) {
            params[key] = paramObj[key];
          }
        }
      }
      return params;
    },

    getRelatedVisitRecord(id) {
      let params = {
        page: -1,
        org_id: id,
        order: "visit_time desc"
      };
      this.timeLineDataLoading = true;
      fetchGrid("/index/visit", params).then(res => {
        if (res.code === 20000) {
          if (!res.data.data.length) {
            this.relatedVisitText = "该机构暂无历史记录";
          } else {
            res.data.data.forEach((item, index) => {
              if (item.is_cbo == "0") {
                item.is_cbo = true;
              } else {
                item.is_cbo = false;
              }
            });
          }
          this.relatedVisitRecord = res.data.data;
        } else {
          this.relatedVisitText = "该机构暂无历史记录";
          this.relatedVisitRecord = [];
        }
        this.timeLineDataLoading = false;
      });
    },
    // 清空提醒相关内容
    clearRemindRelated() {
      this.shareContent = "";
      this.selectedPeopleId = [];
      this.selectedPeopleName = [];
    },

    // 点击取消
    cancel() {
      this.ifHasContacts = false;
      this.relatedVisitText = "选择机构后展示历史拜访记录";
      // 将联系人的所有选项设置为可设置
      this.ifContactDisabled = false;
      // 清空拜访记录列表
      this.relatedVisitRecord = [];
      this.deptOptions = [];
      this.orgOptions = [];
      this.modal = false;
      // this.contactId = "";
      // 清空提醒的内容
      this.clearRemindRelated();
      this.$refs.formVisit.resetFields();
      this.$refs.formContact.resetFields();
      this.$refs.formOrg.resetFields();
      this.$refs.contactTypeForm.resetFields();
    }

    // 开关开启与关闭时验证规则发生变化，
    // 所以切换模态框状态时，重新清除
    // onVisibleChange() {
    //   this.$refs.formOrg.resetFields();
    //   // this.$refs.formVisit.resetFields();
    // }
  }
};
</script>
<style lang="less" scoped>
.outerUserList {
  background-color: #f1f1f1;
}

.form-title {
  background-color: #f1f1f1;
  margin: 5px;
  padding: 5px;
  border-radius: 5px;
}

.chosenPeople {
  border: 1px solid red;
  border-radius: 6px; // width: 500px;
}

.show_container {
  width: 100%;
  height: 40px;
  min-height: 40px;
  border: 1px solid #dddee1;
  border-radius: 5px;
  position: relative;
  padding-bottom: 10px;
  word-wrap: break-word;
  .show-content {
    width: 100%;
    height: 100%;
    overflow: hidden;
    padding: 5px;
    line-height: 22px;
  }
  .total {
    display: inline-block;
    position: absolute;
    bottom: -10px;
    right: 10px;
    padding: 0 10px;
    background-color: white;
    height: 20px;
    line-height: 20px;
  }
  .tool {
    cursor: pointer;
    width: 60px;
    height: 20px;
    margin: 0px 5px;
    padding: 0 10px;
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translate(-50%, 0);
    background-color: #fff;
    .icon-container {
      float: left;
      display: inline-block;
      position: relative;
      margin-left: 2px;
      .icon {
        display: block;
        position: absolute;
        top: -3px;
        &.second {
          top: 0px;
        }
        &.thrid {
          top: 3px;
        }
      }
    }
    .text {
      float: left;
      line-height: 20px;
      font-size: 12px;
      color: #666;
    }
  }
}

.showMorePeople.show_container {
  height: auto;
}

.vsit-time-line {
  margin-top: 10px;
  position: relative;
  overflow-y: auto;
  overflow-x: hidden;
  .content {
    padding: 5px;
    font-size: 13px;
  }
  .visitTime {
    position: absolute;
    left: -150px;
    font-weight: 900;
    width: 130px;
    text-align: right;
    right: 5px;
  }
  .visitMember {
    position: absolute;
    top: 30px;
    left: -150px;
    width: 130px;
    text-align: right;
    right: 5px;
  }
  .visit-people {
    color: #aab3ca;
  }
  .content-title {
    color: #aab3ca;
    display: inline-block;
    width: 67px;
    // margin-right: 5%;
    vertical-align: top;
  }
  .content-box {
    display: inline-block;
    width: 65%;
  }
}
.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}
@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}
.demo-spin-col {
  height: 100px;
  position: relative;
}
</style>
