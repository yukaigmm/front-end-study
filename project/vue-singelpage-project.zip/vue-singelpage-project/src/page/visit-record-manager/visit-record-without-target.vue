<template>
	<div>
		<Modal
			v-model="modal"
			:width="800"
			title="添加拜访记录"
			@on-cancel="cancel"
			class="record-without-target-modal add-contracts-modal"
			>
				<div slot="footer">
					<Button type="default" @click="cancel">取消</Button>
					<Button type="primary" @click="ok" :loading = "buttonLoading">确定</Button>
				</div>
				<visit-contact-add
					ref="visitContactAdd"
					:needTable="false"
					@closeModal="cancel"
					@addVisitSuccess="addVisitSuccess"
					@setButtonLoadingStatus="setButtonLoadingStatus"
				>
				</visit-contact-add>
			</Modal>
	</div>
</template>

<script>
import visitContactAdd from "../contact-manager/visit-contact-add";
import chooseTarget from "./choose-visit-target";
import { mapGetters } from "vuex";
export default {
  components: {
    visitContactAdd,
    chooseTarget
  },
  data() {
    return {
      buttonLoading: false,
      modal: false
    };
  },
  computed: {
    ...mapGetters({
      user: "getUser",
      enums: "getEnums"
    }),
    visitTypeMapping() {
      return this.enums.c_visit_type_mapping;
    }
  },
  methods: {
    show(data) {
      this.modal = true;
      this.$refs.visitContactAdd.initData({
        visit_member_name: this.user.trueName,
        visit_member_id: this.user.id,
        visit_type: this.getVisitTypeOfCurrentUser(),
        ...data
      });
    },
    hide() {
      this.modal = false;
    },
    setButtonLoadingStatus(val) {
      this.buttonLoading = val;
    },
    ok() {
      this.buttonLoading = true;
      this.$refs.visitContactAdd.submit("add").then(() => {
        this.$refs.visitContactAdd.clearShareParams();
        this.buttonLoading = false;
      });
    },
    cancel() {
      this.hide();
      this.$refs.visitContactAdd.resetForm();
    },
    openChooseTarget() {
      this.$refs.chooseTarget.show();
    },
    getVisitTypeOfCurrentUser() {
      let deptId = this.user.dept_id;
      let mapOfFilter = this.visitTypeMapping.filter(m => {
        return m.name === `${deptId}`;
      });
      return mapOfFilter.length ? mapOfFilter[0].value : "99";
    },
    addVisitSuccess() {
      this.$emit("addVisitSuccess");
      this.$emit("refreshTable");
    }
  }
};
</script>

<style>
</style>