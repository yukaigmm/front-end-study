<template>
  <Modal title="分享" v-model="modal" width="800" :mask-closable="false" class="share-visit-record-modal add-contracts-modal">
    <Row style="position: relative;">
      <Col span="14" style="border-right:dashed 1px #ccc;padding-right:10px;">
      <Form :label-width="80" disabled class="show-form">
        <Row>
          <Col span="7">
          <Form-item label="拜访人">
            <Label>{{formData.visit_member_name}}</Label>
          </Form-item>
          </Col>
          <Col span="16">
          <Form-item label="拜访对象" class="dialog-form-item-less">
            <Label>{{formData.contacts_name}}</Label>
            <span style="" class="object-bread" :title="formData.bread">{{formData.bread}}</span>
          </Form-item>
          </Col>
        </Row>
        <Row>
         
          <Col span="12" >
          <Form-item label="拜访类别" prop="visit_type">
            <Select v-model="formData.visit_type">
              <Option v-for="(item,index) in visitType" :key="index" :value="item.value">{{item.name}}</Option>
            </Select>
          </Form-item>
          </Col>
           <Col span="10" offset="1">
          <Form-item prop="contacts_ids" label="其他接待人" class="dialog-form-item-less">
            <template v-if="formData.contacts_ids.length == 0">
              <span>无</span>
            </template>
            <template v-else>
              <span v-for="id in formData.contacts_ids">{{getName(id) +','}}</span>
            </template>
          </Form-item>
          </Col>
        </Row>
        <Row>
          <Col span="12">
          <Form-item label="拜访日期" prop="visit_time" class="dialog-form-item-less">
            <Date-picker class="dialog-form-item-less" type="date" v-model="formData.visit_time" placeholder="拜访日期"></Date-picker>
          </Form-item>
          </Col>
          <Col span="12">
          <Form-item label="预设回访" prop="order_time" class="dialog-form-item-less">
            <Date-picker class="dialog-form-item-less" type="date" format="yyyy-MM-dd" placeholder="回访日期" v-model="formData.order_time"></Date-picker>
          </Form-item>
          </Col>
        </Row>
        <Row>
          <Col span="24">
          <Form-item label="意向" prop="intention_type">
            <radio-url :config="{cacheKey:'c_intention'}" v-model="formData.intention_type"></radio-url>
          </Form-item>
          </Col>
        </Row>
        <Row>
          <Col span="24">
          <Form-item label="需求点" prop="demand_id">
            <checkbox-url :config="{cacheKey:'c_demand'}" v-model="formData.demand_ids"></checkbox-url>
          </Form-item>
          </Col>
        </Row>
        <Row>
          <Col span="24">
          <Form-item label="交谈内容" prop="chat_ids">
            <checkbox-url :config="{cacheKey:'c_chat_content'}" v-model="formData.chat_ids"> </checkbox-url>
          </Form-item>
          </Col>
        </Row>
        <Row>
          <Col span="24">
          <Form-item label="日志" prop="visit_content">
            <Input v-model.trim="formData.visit_content" type="textarea" :autosize="{minRows: 2,maxRows: 2}" placeholder="请输入内容"></Input>
          </Form-item>
          </Col>
        </Row>
      </Form>
      </Col>
      <Col span="9" offset="1">
      <h3>请选择接收人</h3>
      <div :class="{chosen:choosePeople}">
        <div class="show_container" :class="{showMorePeople:showHeight}">
          <p class="show-content" title="单击选择接收人" @click="showPeopleModal">
            <span v-if="selectedPeopleName.length"> {{selectedPeopleName.join(', ')}}</span>
            <span v-else style="color:#ccc;">单击选择接收人</span>
          </p>
          <div class="total" @click="showPeopleModal" title="选择需要分享的人" v-if="this.selectedPeopleName.length">共{{this.selectedPeopleId.length}}人</div>
          <div class="tool" @click="showMorePeople" v-if="selectedPeopleName.length">
            <span class="text">{{!showHeight?"更多":"收起"}}</span>
            <div class="icon-container" v-if="!showHeight">
              <Icon :size="18" color="#666" class="icon" type="ios-arrow-down"></Icon>
              <Icon :size="18" color="#666" class="icon second" type="ios-arrow-down"></Icon>
              <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-down"></Icon>
            </div>
            <div class="icon-container" v-else>
              <Icon :size="18" color="#666" class="icon" type="ios-arrow-up"></Icon>
              <Icon :size="18" color="#666" class="icon second" type="ios-arrow-up"></Icon>
              <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-up"></Icon>
            </div>
          </div>
        </div>
      </div>
      <p style="color:red;" v-if="choosePeople">请先选择接收人！</p>
      <Input type="textarea" v-model.trim="shareContent" style="margin-top:20px;" :autosize="{minRows: 3,maxRows: 8}" placeholder="请输入分享内容..."></Input>
      </Col>
    </Row>
    <peopleTree ref="people" @getSelectedPeople="getSelectedPeople" :msgId="formData.id"></peopleTree>
    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>
    <div slot="footer">
      <Button type="primary" @click="ok" :loading="buttonLoading">分享</Button>
      <Button type="ghost" @click="cancel">取消</Button>
    </div>
  </Modal>
</template>
<script>
import { fetchSelect, postFormData, getMessageCount } from "@/service/getData";
import SelectUrl from "@/components/inputs/select-url";
import CheckboxUrl from "@/components/inputs/checkbox-url";
import RadioUrl from "@/components/inputs/Radio-url";
import peopleTree from "../contact-manager/peopleTree";
import { mapGetters } from "vuex";
export default {
  components: {
    SelectUrl,
    CheckboxUrl,
    RadioUrl,
    peopleTree
  },
  data() {
    return {
      buttonLoading: false,
      visitType: [],
      share: "",
      choosePeople: false,
      addOther: false,
      selectedPeople: [],
      selectedPeopleId: [],
      selectedPeopleName: [],
      modal: false,
      formData: {
        demand_ids: [],
        chat_ids: [],
        contacts_ids: []
      },
      showHeight: false,
      shareContent: "",
      othersData: []
    };
  },
  computed: {
    memberUrl() {
      let url = "contact/other/" + this.formData.org_id;
      return url;
    },
    ...mapGetters({
      trueName: "getTrueName",
      enums: "getEnums"
    })
  },
  watch: {
    selectedPeopleName: function(newVal, oldVal) {
      if (newVal.length !== 0) {
        this.choosePeople = false;
      }
    }
  },
  mounted() {
    // this.getType()
    this.visitType = this.enums.c_visit_type;
  },
  methods: {
    // 其他拜访人下拉
    showOther(val) {
      this.addOther = false;
      fetchSelect(this.memberUrl).then(resp => {
        if (resp.code == 20000) {
          if (this.formData.contacts_ids.length > 0) {
            this.addOther = true;
          } else if (val) {
            this.addOther = true;
          }
          this.othersData = resp.data.data;
        } else {
          this.othersData = {};
          this.$Message.error("无更多联系人，请添加后操作");
        }
      });
    },
    getSelectedPeople(selectedPerson) {
      this.selectedPeople = JSON.parse(JSON.stringify(selectedPerson));
      this.selectedPeopleName = selectedPerson.map(person => {
        return person.memberName;
      });
      this.selectedPeopleId = selectedPerson.map(person => {
        return person.id;
      });
    },
    // 显示模态框并给记录赋值
    show(visitData) {
      if(visitData.bread&&visitData.bread.length){
         visitData.bread.shift()
         visitData.bread  = `(${visitData.bread.map(item=>{
          return item.title
         }).join(",")})` ;
      }else{
        visitData.bread = '';
      }
     
      this.formData = visitData;
      this.formData.contacts_ids = this.formData.contacts_ids ?
        JSON.parse(this.formData.contacts_ids) :
        [];
      this.formData.demand_ids = this.formData.demand_ids ?
        JSON.parse(this.formData.demand_ids) :
        [];
      this.formData.chat_ids = this.formData.chat_ids ?
        JSON.parse(this.formData.chat_ids) :
        [];
      this.formData.visit_type = `${visitData.visit_type}`
      this.showOther(true);
      this.modal = true;
    },
    // 显示更多已选择的人
    showMorePeople() {
      if (!this.showHeight) {
        this.showHeight = true;
      } else {
        this.showHeight = false;
      }
    },
    // 显示选择人的模态框
    showPeopleModal() {
      this.$refs.people.show(this.formData.id, this.selectedPeopleId);
    },
    ok() {
      if (this.validate()) {
        return;
      }
      this.buttonLoading = true;
      let params = {
        type: 4,
        to_id: this.selectedPeopleId,
        message: this.share || this.shareContent,
        visit_id: this.formData.id
      };
      postFormData("msg/send", params).then(res => {
        if (res.code == 20000) {
          this.$Message.info("分享成功");
          this.buttonLoading = false;
          // 更新消息数量
          this.cancel();
          getMessageCount().then(res => {
            let count = res.data.total;
            this.$store.dispatch("setMessageCount", {
              messageCount: count
            });
          });
        } else {
          this.$Message.warning(res.msg);
          this.buttonLoading = false;
        }
      });
    },
    // 验证是否已选择了接收人
    validate() {
      if (this.selectedPeopleName.length == 0) {
        this.choosePeople = true;
        return true;
      } else if (
        this.selectedPeopleName.length !== 0 &&
        this.shareContent.trim() == ""
      ) {
        this.choosePeople = false;
        this.share = `${this.trueName}给$name分享了一条拜访记录[系统日志]`;
      }
    },
    cancel() {
      this.modal = false;
      this.selectedPeopleName = [];
      this.selectedPeopleId = [];
      this.shareContent = "";
      this.choosePeople = false;
    },
    getName(id) {
      let name = _.get(
        _.filter(this.othersData, data => {
          return data.id == id;
        })[0],
        "name"
      );
      return name;
      this.shareContent = "";
    }
  }
};

</script>
<style lang="less" scoped>
.show_container {
  width: 100%;
  height: 40px;
  border: 1px solid #dddee1;
  border-radius: 5px;
  position: relative;
  padding-bottom: 10px;
  word-wrap: break-word;
  .show-content {
    width: 100%;
    height: 100%;
    overflow: hidden;
    padding: 5px;
    line-height: 22px;
    min-height: 28px;
  }
  .total {
    display: inline-block;
    position: absolute;
    cursor: pointer;
    bottom: -10px;
    right: 10px;
    padding: 0 10px;
    background-color: white;
    height: 20px;
    line-height: 20px;
  }
  .tool {
    cursor: pointer;
    width: 60px;
    height: 20px;
    margin: 0px 5px;
    padding: 0 10px;
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translate(-50%, 0);
    background-color: #fff;
    .icon-container {
      float: left;
      display: inline-block;
      position: relative;
      margin-left: 2px;
      .icon {
        display: block;
        position: absolute;
        top: -3px;
        &.second {
          top: 0px;
        }
        &.thrid {
          top: 3px;
        }
      }
    }
    .text {
      float: left;
      line-height: 20px;
    }
  }
}
.object-bread{
  display: inline-block;
  max-width: 150px;
  vertical-align: top;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  opacity: .7;
  
}
.showMorePeople.show_container {
  height: auto;
}
</style>
