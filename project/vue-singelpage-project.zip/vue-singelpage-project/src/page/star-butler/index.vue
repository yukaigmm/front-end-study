<template>
   <div class="star-butler-wrap" v-loading="pageLoading" element-loading-text="拼命加载中"> 
       <iframe :src="starButlerSrc" id="starButler" frameborder="0" height="90%" width="100%"></iframe>
   </div>
</template>

<script>
import $ from "jquery";
export default {
  props: ["pid"],
  data() {
    return {
      pageLoading: false
    };
  },

  // created() {
  //   this.pageLoading = true;
  // },

  // mounted() {
  //   this.endLoading();
  // },

  computed: {
    starButlerSrc() {
      let url =
        process.env.NODE_ENV === "production"
          ? "http://qy.smppw.com"
          : "http://qy-test.smppw.com";
      // let url = "http://qy-pre.smppw.com";
      return `${url}/Recommender/addBinding.html?company_id=${this.pid}&edit=1`;
    }
  },

  methods: {
    // endLoading() {
    //   let frame = $(this.$el).find("iframe");

    //   frame.load(() => {
    //     console.log(111113);
    //     this.pageLoading = false;
    //   });
    // }
  }
};
</script>

<style lang="less" scoped>
.star-butler-wrap {
  width: 100%;
  overflow: auto;
  height: 100%;
}
</style>


