<template>
  <div>
    <div class="search-area">
      <search-area :show-expand="false" ref="searchArea" @onKeydownSearch="search">
        <div slot="default">
          <Row>
            <i-col span="8">
              <form-item label="审核状态">
                <i-select v-model="searchData.status" placeholder="请选择审核状态" clearable transfer>
                  <i-option
                    v-for="item in statusOptions"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>

            <i-col span="8">
              <form-item label="申请时间">
                <date-picker
                  v-model="searchData.time"
                  placeholder="请选择申请时间"
                  style="width:100%;"
                  type="daterange"
                  transfer
                />
              </form-item>
            </i-col>

            <i-col span="8" style="padding-left:15px;">
              <i-button type="primary" @click="search">搜索</i-button>
              <i-button @click="reset">重置</i-button>
            </i-col>
          </Row>
        </div>
      </search-area>
    </div>

    <div class="table-area">
      <Table
        :columns="columns"
        :data="tableData"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        border
      />
    </div>

    <div class="page-load">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      />
    </div>

    <audit-modal ref="auditModal" @refresh="reset"/>
  </div>
</template>

<script>
import SearchArea from "../../components/search-area.vue";
import AuditModal from "./components/audit-modal.vue";
import setMaxHeightOfFixedTable from "@/mixins/setMaxHeightToTable.js";
import moment from "moment";

export default {
  components: {
    SearchArea,
    AuditModal
  },

  mixins: [setMaxHeightOfFixedTable],

  data() {
    return {
      searchData: {},

      statusOptions: [
        {
          value: 1,
          label: "待审核"
        },
        {
          value: 2,
          label: "审核通过"
        },
        {
          value: 3,
          label: "审核不通过"
        }
      ],
      columns: [
        {
          key: "realname",
          title: "姓名",
          width: 100,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.realname
                }
              },
              row.realname || "--"
            );
          }
        },
        {
          key: "cellphone",
          title: "手机号",
          width: 120,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.cellphone
                }
              },
              row.cellphone || "--"
            );
          }
        },
        {
          key: "status",
          title: "审核状态",
          width: 100,
          ellipsis: true,
          render(h, { row }) {
            let mapping = {
              "1": "待审核",
              "2": "审核通过",
              "3": "审核不通过"
            };
            return h(
              "span",
              {
                attrs: {
                  title: mapping[row.status]
                }
              },
              mapping[row.status] || "--"
            );
          }
        },
        {
          key: "auditName",
          title: "审核人",
          width: 100,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.auditName
                }
              },
              row.auditName || "--"
            );
          }
        },
        {
          key: "updatetime",
          title: "审核时间",
          width: 120,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.updatetime
                }
              },
              row.updatetime || "--"
            );
          }
        },
        {
          key: "remark",
          title: "审核备注",
          width: 200,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.remark
                }
              },
              row.remark || "--"
            );
          }
        },
        {
          key: "cardType",
          title: "证件类型",
          width: 150,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.cardType
                }
              },
              row.cardType || "--"
            );
          }
        },
        {
          key: "cardId",
          title: "证件号码",
          width: 150,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.cardId
                }
              },
              row.cardId || "--"
            );
          }
        },
        {
          key: "firstField",
          title: "公司",
          width: 200,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.firstField
                }
              },
              row.firstField || "--"
            );
          }
        },
        {
          key: "secondField",
          title: "部门",
          width: 200,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.secondField
                }
              },
              row.secondField || "--"
            );
          }
        },
        {
          key: "thirdField",
          title: "职务",
          width: 120,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.thirdField
                }
              },
              row.thirdField || "--"
            );
          }
        },
        {
          key: "cardImage",
          title: "名片",
          width: 80,
          ellipsis: true,
          render(h, { row }) {
            if (row.cardImage) {
              return h(
                "a",
                {
                  on: {
                    click: () => {
                      window.open(row.cardImage);
                    }
                  }
                },
                "查看名片"
              );
            } else {
              return h("span", "--");
            }
          }
        },
        {
          key: "handheldCardImage",
          title: "手持证件照",
          width: 100,
          ellipsis: true,
          render(h, { row }) {
            if (row.handheldCardImage) {
              return h(
                "a",
                {
                  on: {
                    click: () => {
                      window.open(row.handheldCardImage);
                    }
                  }
                },
                "查看证件照"
              );
            } else {
              return h("span", "--");
            }
          }
        },
        {
          key: "createtime",
          title: "申请时间",
          width: 120,
          render(h, { row }) {
            return h(
              "div",
              {
                style: {
                  "max-width": "90px",
                  " word-break": "keep-all",
                  "white-space": "nowrap",
                  overflow: "hidden",
                  "text-overflow": "ellipsis"
                },
                attrs: {
                  title: row.createtime
                }
              },
              row.createtime || "--"
            );
          }
        },
        {
          key: "action",
          title: "操作",
          width: 100,
          fixed: "right",
          render: (h, { row }) => {
            return h(
              "div",
              {
                attrs: {
                  class: row.status == "1" ? "deleteBtn" : "disabledBtn"
                },

                on: {
                  click: () => {
                    if (row.status == "1") {
                      let params = {
                        id: row.id,
                        auditUserId: row.userId
                      };
                      this.$refs.auditModal.show(params);
                    } else {
                      return;
                    }
                  }
                }
              },
              row.status == "1" ? "审核" : "已审核"
            );
          }
        }
      ],
      tableData: [],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  created() {
    this.getTableList();
  },

  mounted() {
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".page-load"],
      ".table-area",
      120,
      true
    );
  },

  methods: {
    reset() {
      this.searchData = {};
      this.search();
    },

    search() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getTableList();
    },

    getParams() {
      let params = JSON.parse(JSON.stringify(this.searchData));
      if (params.time && params.time.length) {
        if (params.time[0]) {
          params.startDate = moment(params.time[0]).format("YYYY-MM-DD");
        }

        if (params.time[1]) {
          params.endDate = moment(params.time[1]).format("YYYY-MM-DD");
        }
      }

      delete params.time;

      return {
        pageNo: this.currentPage,
        pageSize: this.pageSize,
        ...params
      };
    },

    getTableList() {
      this.tableLoading = true;
      this.$http
        .get("/blueVip/getApplyList", this.getParams())
        .then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = ~~res.data.total;
          } else {
            this.$Message.error(`获取列表失败:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.tableLoading = false;
          this.$Message.error("获取列表失败：网络请求错误！");
        });
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getTableList();
    },

    onPageSizeChange(size) {
      this.pageSize = size;
      this.getTableList();
    }
  }
};
</script>

<style lang="less" scoped>
.table-area {
  margin: 15px 0;
}
.page-load {
  margin: 15px;
  text-align: right;
}
</style>

