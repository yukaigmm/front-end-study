<template>
  <Modal title="申请蓝V审批" v-model="modal" :mask-closable="false" width="800">
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button @click="refuse" type="error" :loading="refuseBtnLoading">拒绝</Button>

      <Tooltip :content="disabledReson" v-if="ifAdoptDisabled" placement="top-end">
        <Button type="success" :disabled="ifAdoptDisabled">通过</Button>
      </Tooltip>
      <Button @click="adopt" type="success" :loading="okBtnLoading" v-else>通过</Button>
    </div>

    <Collapse v-model="activePanel" v-loading="loading" element-loading-text="拼命加载中">
      <Panel name="certifyInfo">
        实名认证信息
        <Form ref="certifyForm" :label-width="150" :model="formData" slot="content">
          <Row>
            <i-col span="12">
              <form-item label="实名认证状态">
                <span
                  :class="{'ok':formData.certification=='1' ||formData.certification=='10','warning':formData.certification !='1' && formData.certification != '10' }"
                >{{configOptions.certificationMapping[formData.certification] || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="合格投资者认证状态">
                <span
                  :class="{'ok':formData.qualifiedInvestor=='1' ||formData.qualifiedInvestor=='10','warning':formData.qualifiedInvestor !='1' && formData.qualifiedInvestor != '10' }"
                >{{configOptions.qualifiedInvestorMapping[formData.qualifiedInvestor] || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="风险评测结果">
                <span
                  :class="{'ok':formData.evaluationResult !='-1','warning':formData.evaluationResult =='-1' }"
                >{{configOptions.evaluationResultMapping[formData.evaluationResult] || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="用户状态">
                <span>{{configOptions.userStatusMapping[formData.userStatus] || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="24">
              <form-item label="真实姓名">
                <span>{{formData.realname || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="证件类型">
                <span>{{formData.cardType || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="证件号码">
                <span>{{formData.cardId||"--"}}</span>
              </form-item>
            </i-col>

            <i-col span="12" class="custom-col-app">
              <form-item label="证件正面照">
                <div class="img-wrap">
                  <div
                    class="preview-wrapper"
                    title="查看大图"
                    @click="preview(formData.cardPhotoObverse)"
                  >
                    <Icon type="eye"></Icon>
                  </div>

                  <img :src="formData.cardPhotoObverse" alt="证件照正面" class="img-container">
                </div>
              </form-item>
            </i-col>

            <i-col span="12" class="custom-col-app">
              <form-item label="证件背面照">
                <div class="img-wrap">
                  <div
                    class="preview-wrapper"
                    title="查看大图"
                    @click="preview(formData.cardPhotoReverse)"
                  >
                    <Icon type="eye"></Icon>
                  </div>
                  <img :src="formData.cardPhotoReverse" alt="证件照背面" class="img-container">
                </div>
              </form-item>
            </i-col>
          </Row>
        </Form>
      </Panel>

      <Panel name="applyInfo">
        蓝V申请信息
        <Form
          :model="formData"
          :label-width="100"
          ref="applyForm"
          :rules="applyRules"
          slot="content"
        >
          <Row>
            <i-col span="12">
              <form-item label="姓名" prop="realname">
                <span>{{formData.realname || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="手机号码" prop="cellphone">
                <span>{{formData.cellphone || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="证件类型" prop="cardType">
                <span>{{formData.cardType || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="证件号码" prop="cardId">
                <span>{{formData.cardId || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="24">
              <form-item label="申请时间" prop="createtime">
                <span>{{formData.createtime || "--"}}</span>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="公司名称" prop="firstField">
                <i-input v-model.trim="formData.firstField" placeholder="请输入公司名称"/>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="部门名称" prop="secondField">
                <i-input v-model.trim="formData.secondField" placeholder="请输入部门名称"/>
              </form-item>
            </i-col>

            <i-col span="24">
              <Row>
                <i-col span="12">
                  <form-item label="职务" prop="thirdField">
                    <i-input v-model.trim="formData.thirdField" placeholder="请输入职务"/>
                  </form-item>
                </i-col>
              </Row>
            </i-col>

            <i-col span="12">
              <form-item label="名片" class="custom-col-app" prop="cardImage">
                <div class="img-wrap">
                  <div class="preview-wrapper" title="查看大图" @click="preview(formData.cardImage)">
                    <Icon type="eye"></Icon>
                  </div>
                  <img :src="formData.cardImage" alt="名片" class="img-container">
                </div>
              </form-item>
            </i-col>

            <i-col span="12">
              <form-item label="手持证件照" class="custom-col-app" prop="handheldCardImage">
                <div class="img-wrap">
                  <div
                    class="preview-wrapper"
                    title="查看大图"
                    @click="preview(formData.handheldCardImage)"
                  >
                    <Icon type="eye"></Icon>
                  </div>

                  <img :src="formData.handheldCardImage" alt="手持证件照" class="img-container">
                </div>
              </form-item>
            </i-col>
          </Row>
        </Form>
      </Panel>

      <Panel name="auditInfo">
        蓝V审批信息
        <Form
          slot="content"
          :model="formData"
          :rules="auditRules"
          :label-width="100"
          ref="auditForm"
        >
          <Row>
            <i-col span="12">
              <form-item label="账号" prop="cellphone">
                <span>{{formData.cellphone}}</span>
              </form-item>
            </i-col>
            <i-col span="12">
              <form-item label="初始密码" prop="initPsw">
                <i-input
                  v-model.trim="formData.initPsw"
                  :placeholder="passwordPlaceholder"
                  disabled
                />
              </form-item>
            </i-col>
            <i-col span="12">
              <form-item label="账号状态" prop="blueVipStatus">
                <i-select placeholder="请选择账号状态" v-model="formData.blueVipStatus" transfer clearable>
                  <i-option
                    v-for="item in configOptions.blueVipStatusOptions"
                    :value="item.value"
                    :key="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>
            <i-col span="12">
              <form-item label="短信通知" prop="sendMessage">
                <Checkbox v-model="formData.sendMessage" :true-value="1" :false-value="0">是</Checkbox>
              </form-item>
            </i-col>
            <i-col span="12">
              <form-item label="开始日期" prop="blueVipTime">
                <date-picker
                  v-model="formData.blueVipTime"
                  style="width:100%;"
                  placeholder="请选择开始日期"
                  transfer
                  clearable
                />
              </form-item>
            </i-col>
            <i-col span="12">
              <form-item label="结束日期" prop="bvExpireTime">
                <date-picker
                  v-model="formData.bvExpireTime"
                  style="width:100%;"
                  placeholder="请选择结束日期"
                  transfer
                  clearable
                />
              </form-item>
            </i-col>
            <i-col span="12">
              <form-item label="是否付费" prop="bvPayment">
                <i-select placeholder="请选择是否付费" v-model="formData.bvPayment" transfer clearable>
                  <i-option
                    v-for="item in configOptions.bvPaymentOptions"
                    :value="item.value"
                    :key="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>
            <i-col span="12">
              <form-item label="推荐人" prop="bvReferee">
                <i-select
                  v-model="formData.bvReferee"
                  placeholder="请输入关键词"
                  filterable
                  remote
                  transfer
                  :loading="recoLoading"
                  :label="formData.auditName"
                  clearable
                  :remote-method="remoteMethod"
                >
                  <i-option
                    v-for="item in recommenderList"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>
            <i-col span="12">
              <form-item label="蓝V等级" prop="bvLevel">
                <i-select placeholder="请选择蓝V等级" v-model="formData.bvLevel" transfer clearable>
                  <i-option
                    v-for="item in configOptions.bvLevelOptions"
                    :value="item.value"
                    :key="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>
            <i-col span="24">
              <form-item label="备注" prop="remark">
                <i-input
                  placeholder="请输入备注"
                  v-model.trim="formData.remark"
                  type="textarea"
                  :autosize="{minRows:2,maxRows:5}"
                />
              </form-item>
            </i-col>
          </Row>
        </Form>
      </Panel>
    </Collapse>
  </Modal>
</template>

<script>
import { config } from "./config.js";
import moment from "moment";
import { mapGetters } from "vuex";
import { uniq } from "lodash";

export default {
  data() {
    return {
      modal: false,
      activePanel: ["certifyInfo", "applyInfo", "auditInfo"],
      formData: {
        sendMessage: 1
      },
      applyRules: {
        firstField: {
          required: true,
          message: "公司名称不能为空"
        },
        secondField: {
          required: true,
          message: "公司名称不能为空"
        },
        thirdField: {
          required: true,
          message: "公司名称不能为空"
        }
      },
      auditRules: {
        blueVipStatus: {
          required: true,
          message: "蓝V状态不能为空"
        },
        blueVipTime: {
          required: true,
          message: "开始日期不能为空"
        },
        bvExpireTime: {
          required: true,
          message: "结束日期不能为空"
        },
        bvLevel: {
          required: true,
          message: "蓝V等级不能为空"
        }
      },
      configOptions: config(),
      auditId: "",
      loading: false,
      refuseBtnLoading: false,
      okBtnLoading: false,
      passwordPlaceholder: "初始密码",
      recoLoading: false,
      recommenderList: [],
      disabledReson: "",
      auditUserId: ""
    };
  },

  watch: {
    "formData.cellphone": {
      handler(val) {
        this.ifHasAccount(val);
      }
    }
  },

  computed: {
    // 当前用户id
    ...mapGetters({
      userId: "getUserId"
    }),

    // 是否满足通过条件
    ifAdoptDisabled() {
      let data = JSON.parse(JSON.stringify(this.formData));

      if (data.certification != "1" && data.certification != "10") {
        this.disabledReson = "实名认证未通过";
        return true;
      }

      if (data.qualifiedInvestor == "0") {
        this.disabledReson = "合格投资者认证未通过";
        return true;
      }

      if (data.evaluationResult == "-1") {
        this.disabledReson = "未进行风险评测";
        return true;
      }

      if (!!!data.firstField) {
        this.disabledReson = "公司为空";
        return true;
      }
      if (!!!data.secondField) {
        this.disabledReson = "部门为空";
        return true;
      }
      if (!!!data.thirdField) {
        this.disabledReson = "职位为空";
        return true;
      }

      this.disabledReson = "";

      return false;
    }
  },

  methods: {
    // 预览图片
    preview(src) {
      window.open(src);
    },

    // 推荐人搜索
    remoteMethod(query) {
      if (!query) {
        this.recommenderList = [];
        return;
      } else {
        this.recoLoading = true;
        let params = {
          name: query,
          ifCancelRequest: true
        };

        this.$http
          .get("accounts/getAccountByName", params)
          .then(res => {
            this.recoLoading = false;
            if (res.code === 20000) {
              if (res.data.length) {
                this.recommenderList = res.data.map(item => {
                  return {
                    label: item.linkman,
                    value: item.id
                  };
                });
              } else {
                this.recommenderList = [];
              }
            } else {
              this.recommenderList = [];
              this.$Message.error(`获取推荐人数据失败:${res.msg}`);
            }
          })
          .catch(err => {
            if (err !== "canceled") {
              this.recoLoading = false;
              this.recommenderList = [];
              this.$Message.error("获取推荐人数据失败：网络请求错误！");
            }
          });
      }
    },

    // 关闭模态框
    onCancel() {
      this.activePanel = ["certifyInfo", "applyInfo", "auditInfo"];
      this.formData = { sendMessage: 1 };
      this.auditId = "";
      this.passwordPlaceholder = "初始密码";
      this.recommenderList = [];
      this.disabledReson = "";
      this.auditUserId = "";
      this.$refs.certifyForm.resetFields();
      this.$refs.applyForm.resetFields();
      this.$refs.auditForm.resetFields();
      this.modal = false;
    },

    // 拒绝审批
    refuse() {
      // 拒绝时必须填写备注
      let data = JSON.parse(JSON.stringify(this.formData));

      if (!!!data.remark) {
        this.$Message.warning("请先填写备注！");
        return;
      }

      let params = this.getSubmitParams({ status: "3" });
      this.submitData(params, "refuseBtnLoading");
      // this.validate(params, "refuseBtnLoading");
    },

    // 通过审批
    adopt() {
      let params = this.getSubmitParams({ status: "2" });
      this.validate(params, "okBtnLoading");
    },

    /**
     * @param 额外参数
     * @type 审批类型
     */
    validate(param, type) {
      Promise.all([this.validateApplyInfo(), this.validateAuditInfo()])
        .then(() => {
          this.submitData(param, type);
        })
        .catch(err => {
          let comp = JSON.parse(JSON.stringify(this.activePanel));
          comp.push(err);
          this.activePanel = uniq(comp);
          this.$Message.warning("请按红色文字提示填写内容！");
        });
    },

    validateApplyInfo() {
      return new Promise((resolve, reject) => {
        this.$refs.applyForm.validate(valid => {
          if (valid) {
            resolve();
          } else {
            reject("applyInfo");
          }
        });
      });
    },

    validateAuditInfo() {
      return new Promise((resolve, reject) => {
        this.$refs.auditForm.validate(valid => {
          if (valid) {
            resolve();
          } else {
            reject("auditInfo");
          }
        });
      });
    },

    // 提交审批数据
    submitData(params = {}, lodingType) {
      this[lodingType] = true;

      const msg = {
        okBtnLoading: {
          success: "申请已通过",
          error: "处理申请失败"
        },
        refuseBtnLoading: {
          success: "申请已拒绝",
          error: "处理申请失败"
        }
      };

      this.$http
        .post("blueVIPAudit", params)
        .then(res => {
          this[lodingType] = false;
          if (res.code === 20000) {
            this.$Message.success(`${msg[lodingType]["success"]}`);
            this.onCancel();
            this.$emit("refresh");
          } else {
            this.$Message.error(`${msg[lodingType]["error"]}:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this[lodingType] = false;

          this.$Message.error("处理申请失败：网络请求错误！");
        });
    },

    //  获取提交数据
    getSubmitParams(additionParam = {}) {
      let keys = [
        "cellphone",
        "bvLevel",
        "remark",
        "bvPayment",
        "bvReferee",
        "blueVipTime",
        "bvExpireTime",
        "blueVipStatus",
        "sendMessage",
        "initPsw"
      ];
      let param = {};
      let data = JSON.parse(JSON.stringify(this.formData));
      keys.forEach(key => {
        if (data[key]) {
          param[key] = data[key];
        }
      });

      if (param.blueVipTime) {
        param.blueVipTime = moment(param.blueVipTime).format("YYYY-MM-DD");
      }

      if (param.bvExpireTime) {
        param.bvExpireTime = moment(param.bvExpireTime).format("YYYY-MM-DD");
      }

      //  公司、部门、职位字段
      param.bvCompanyName = data.firstField;
      param.bvDeptName = data.secondField;
      param.bvPositionName = data.thirdField;

      // 审核人即为当前系统用户
      param.auditId = this.userId;

      //  当前记录id
      param.id = this.auditId;
      //  申请用户id
      param.userId = this.auditUserId;
      return Object.assign(param, additionParam);
    },

    //  显示模态框
    show({ id, auditUserId }) {
      this.auditId = ~~id;
      this.auditUserId = auditUserId;
      this.modal = true;
      this.getAuditDetails();
    },

    // 获取审批详情
    getAuditDetails() {
      let params = {
        id: this.auditId
      };
      this.loading = true;
      this.$http
        .get("blueVip/getApplyInfo", params)
        .then(res => {
          this.loading = false;
          if (res.code === 20000) {
            this.formData = res.data;
            this.formData.sendMessage = 1;
            // 如果没有日期，默认开始日期是今天，结束日期是十天后；
            if (!!!res.data.blueVipTime && !!!res.data.bvExpireTime) {
              this.formData.blueVipTime = moment().format("YYYY-MM-DD");
              this.formData.bvExpireTime = moment(
                this.formData.blueVipTime
              ).add(10, "days");
            }
          } else {
            this.$Message.error(`获取申请详情失败：${res.msg}`);
          }
        })
        .catch(err => {
          this.loading = false;
          this.$Message.error("获取申请详情失败：网络请求错误！");
          console.error(err);
        });
    },

    // 判断官网是否有注册,并设置初始密码
    ifHasAccount(val) {
      if (!val) {
        return;
      }

      let params = {
        mobile: val
      };
      this.$http.get("FmAccount/status", params).then(res => {
        if (res.code === 20000) {
          if (res.data.accStatus == 1 || res.data.accStatus == 2) {
            this.passwordPlaceholder = "该手机号已绑定官网账号，无需设置密码";
            this.$set(this.formData, "initPsw", "");
          } else {
            this.$set(this.formData, "initPsw", this.randomPassword());
            this.passwordPlaceholder = "初始密码";
          }
        } else {
          this.passwordPlaceholder = "初始密码";
          this.$set(this.formData, "initPsw", this.randomPassword());
        }
      });
    },

    // 随机生成初始密码
    randomPassword() {
      let password = "smppw";
      for (let i = 0; i < 4; i++) {
        password += Math.floor(Math.random() * 10);
      }
      return password;
    }
  }
};
</script>


<style lang="less" scoped>
.ok {
  background: #2ab92a;
  padding: 3px 4px;
}

.warning {
  background: #ff2c2c;
  padding: 3px 4px;
}

.img-wrap {
  width: 300px;
  height: 160px;
  border: 1px solid #eeeeee;
  position: relative;
  overflow: hidden;
  text-align: center;
  border-radius: 10px;
  .preview-wrapper {
    font-size: 24px;
    position: absolute;
    width: 100%;
    height: 50px;
    bottom: -50px;
    text-align: center;
    line-height: 50px;
    background: rgba(0, 0, 0, 0.5);
    transition: all 0.5s ease;
  }
  &:hover {
    .preview-wrapper {
      bottom: 0;
    }
  }

  .img-container {
    max-width: 300px;
    max-height: 160px;
    cursor: pointer;
  }
}
</style>
