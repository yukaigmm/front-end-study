const config = () => {
  return {
    // 实名认证状态
    certificationMapping: {
      "0": "未审核",
      "1": "已审核",
      "2": "审核中",
      "3": "审核不通过",
      "10": "已审核" // 已审核的老用户
    },

    // 合格投资者认证状态
    qualifiedInvestorMapping: {
      "1": "已认证",
      "0": "未认证",
      "10": "已认证"
    },
    // 风险评测
    evaluationResultMapping: {
      "-1": "未评测",
      "1": "保守型投资人",
      "2": "稳健型投资人",
      "3": "平衡型投资人",
      "4": "成长型投资人",
      "5": "进取型投资人"
    },

    userStatusMapping: {
      "1": "正常",
      "0": "停用"
    },

    // 蓝V审核状态
    auditStatusOptions: [{
        value: "1",
        label: "待审核"
      },
      {
        value: "2",
        label: "审核通过"
      },
      {
        value: "3",
        label: "审核不通过"
      },
    ],

    // 是否付费
    bvPaymentOptions: [{
        value: "0",
        label: "未付费"
      },
      {
        value: "1",
        label: "已付费"
      }
    ],

    // 蓝V等级
    bvLevelOptions: [{
        value: "1",
        label: "蓝V1"
      },
      {
        value: "2",
        label: "蓝V2"
      },
      {
        value: "3",
        label: "蓝V3"
      },
    ],
    

    // 蓝V账号状态
    blueVipStatusOptions: [
      {
        value: "0",
        label: "异常"
      },
      {
        value: "1",
        label: "申请 "
      },
      {
        value: "2",
        label: "试用 "
      },
      {
        value: "3",
        label: "正式 "
      },
      {
        value: "4",
        label: "停用"
      }
    ]
  }
}

export {
  config,
}
