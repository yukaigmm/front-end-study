<template>
    <div>
        <div class="search-area keydown-box">
             <Form :model='formSearch' ref='form' :label-width='100' @keydown.enter.native.prevent="search">
                 <Row>
                     <Col span='8'>
                       <FormItem label='CRM公司名'>
                           <Input v-model.trim="formSearch.crmCompanyName" placeholder="请输入CRM公司名"></Input>
                       </FormItem>
                     </Col>

                     <Col span='8' offset='1'>
                       <FormItem label='申报系统公司名'>
                           <Input v-model.trim="formSearch.companyName" placeholder="请输入申报系统公司名"></Input>
                       </FormItem>
                     </Col>
                     <Col span='4' style="padding-left:15px;">
                           <Button type="primary" @click="search">搜索</Button>
                           <Button @click="onReset">重置</Button>
                     </Col>
                 </Row>
             </Form>
        </div>

        <div class="table-container">
           <div class="table-header">
             <ul>
               <li>CRM</li>
               <li>申报系统</li>
               <li> </li>
             </ul>
           </div>
            <Table
              :data='tableData'
              :columns='columns'
              v-loading='tableLoading'
              element-loading-text='拼命加载中'
              border
            >
            </Table>
        </div>

        <div class="page-load">
            <Page
             :total='total'
             placement='top'
             :current='currentPage'
             :page-size='pageSize'
             @on-change='onPageChange'
             @on-page-size-change='onPageSizeChange'
             show-elevator
             show-sizer
             show-total
            >
            </Page>
        </div>

        <editModal ref='editModal' @refreshTableDate='getTableData'></editModal>

    </div>
</template>

<script>
import editModal from "./components/edit-modal";
import $ from "jquery";
import { forEach } from "lodash";
import { mapGetters } from "vuex";
import getMinusNumber from "@/mixins/getMinusNumber.js";


export default {
  components: {
    editModal
  },

  mixins:[getMinusNumber],

  data() {
    return {
      total: 0,
      currentPage: 1,
      pageSize: 10,
      formSearch: {
        companyName: "",
        crmCompanyName: ""
      },
      tableLoading: false,
      tableData: [],
      columns: [
        {
          title: "公司名称",
          key: "crmCompanyName",
          render(h, { row }) {
            return row.crmCompanyName || "--";
          }
        },
        {
          title: "城市",
          key: "crmCityId",
          render: (h, { row }) => {
            return row.crmCityId
              ? this.enums.c_area_deep_2.filter(
                  item => item.value === row.crmCityId
                )[0]["name"]
              : "--";
          }
        },
        {
          title: "备案编码",
          key: "crmRegisterNumber",
          render(h, { row }) {
            return row.crmRegisterNumber || "--";
          }
        },

        {
          title: "公司名称",
          key: "companyName",
          render(h, { row }) {
            return row.companyName || "--";
          }
        },
        {
          title: "城市",
          key: "city",
          render(h, { row }) {
            return row.city || "--";
          }
        },
        {
          title: "备案编码",
          key: "registerNumber",
          render(h, { row }) {
            return row.registerNumber || "--";
          }
        },

        {
          title: "操作",
          render: (h, { row, column, index }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.$refs.editModal.show(row.orgId);
                    }
                  }
                },
                "编辑"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.syncData(row.orgId);
                    }
                  }
                },
                "同步数据"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.deleteReflection(row.orgId, row.companyId);
                    }
                  }
                },
                "删除映射"
              )
            ]);
          }
        }
      ]
    };
  },

  created() {
    this.getTableData();
  },

  computed: {
    ...mapGetters({
      enums: "getEnums"
    })
  },

  mounted() {
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".page-load"],
      ".table-container"
    );
  },

  methods: {
    // 同步数据
    syncData(orgId) {
      this.$http
        .putWithoutId(`orgAssociation/synchronization/${orgId}`)
        .then(res => {});
    },

    // 搜索
    search() {
      this.currentPage = 1;
      this.pageSize =10;
      this.getTableData();
    },

    // 重置
    onReset() {
        this.$set(this.formSearch, "companyName", "");
        this.$set(this.formSearch, "crmCompanyName", "");
        this.getTableData();
    },

    // 切换表格pageSize
    onPageSizeChange(pageSize) {
      this.currentPage = 1;
      this.pageSize = pageSize;
      this.getTableData();
    },

    //  切换页码
    onPageChange(page) {
      this.currentPage = page;
      this.getTableData();
    },

    // 获取列表
    getTableData() {
      this.tableLoading = true;
      this.$http.get("orgAssociation", this.getParams()).then(res => {
        this.tableLoading = false;
        if (res.code === 20000) {
          this.total = res.data.total;
          this.tableData = res.data.records;
        } else {
          this.$Message.error("获取列表失败！");
        }
      });
    },

    // 获取参数
    getParams() {
      let params = {};
      for (let key in this.formSearch) {
        if (!this.formSearch[key]) {
          delete this.formSearch[key];
        }
      }
      params = {
        ...this.formSearch,
        ...{
          pageNo: this.currentPage,
          pageSize: this.pageSize
        }
      };
      return params;
    },

    // 删除映射
    deleteReflection(crmId, sbId) {
      this.$Modal.confirm({
        title: "删除",
        content: "确定删除？",
        width: 300,
        loading: true,
        onOk: () => {
          let params = {
            orgId: crmId
          };
          this.$http.putWithoutId("orgAssociation", params).then(res => {
            if (res.code === 20000) {
              this.$Message.success("删除成功！");
              this.getTableData();
            } else {
              this.$Message.error(`删除失败：${res.msg}`);
            }
            this.$Modal.remove();
          });
        }
      });
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 200;
      let minusNumber = this.getMinusNumberOfFixedTable(); 

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    }
  }
};
</script>

<style lang="less" scoped>
.table-header {
  ul {
    height: 40px;
    // margin-bottom: -15px;
    &::after {
      content: ".";
      line-height: 0;
      visibility: hidden;
      clear: both;
    }
    li {
      font-weight: 900;
      line-height: 40px;
      height: 100%;
      float: left;
      border: 1px solid #dddee1;
      border-bottom: none;
      text-align: center;
      &:first-child {
        width: 42.8%;
      }
      &:nth-child(2) {
        width: 42.8%;
        border-left: none;
        border-right: none;
      }
      &:last-child {
        width: 14.4%;
      }
    }
  }
}
.table-container {
  margin-top: 15px;
}
.page-load {
  margin-top: 15px;
  text-align: right;
  margin-left: 15px;
}
</style>
