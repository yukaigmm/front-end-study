<template>
    <Modal
     :mask-closable='false'
     v-model="modal"
     title="编辑"
     width='500'
     class="edit-reflect-modal"
    >
      <div slot="close" @click="onCancel">
        <Icon type="ios-close-empty"></Icon>
      </div>

      <div slot="footer">
         <Button  @click='onCancel'>取消</Button>
         <Button type='primary'  @click='onOk'>确定</Button>
      </div>

      <!-- <Poptip
       placement='bottom'
       width='500'
      >
        <Input
         style="width:350px "
         v-model.trim='keywords'
         placeholder='请输入关键词'
         @input="getCompanyList"
        ></Input>

        <div slot='title'>

           <template style="padding:0 5px">
               <Table
                 v-loading='loading'
                 :key='tableKey'
                 highlight-row
                 :data='tableData'
                 :columns='columns'
                 border
                 height='200'
                 @on-row-click='onRowClick'
               >
               </Table>
           </template>

        </div>

        <div slot='content' style="text-align:right">
            <Button type="text" size='small' @click='onCancel'>取消</Button>
            <Button type='primary' size='small' @click='onOk'>确定</Button>
        </div>

      </Poptip> -->


      <div class="input-container">
        <span>申报系统公司名：</span>

        <Input
         style="width:200px "
         v-model.trim='keywords'
         placeholder='请输入关键词'
        ></Input>

        <Button style="margin-left:10px;" type="primary" size='small' @click="getCompanyList">搜索</Button>
      </div>

      <div class="table-container">
        <Table
          v-loading='loading'
          :key='tableKey'
          highlight-row
          :data='tableData'
          :columns='columns'
          border
          height='200'
          element-loading-text='拼命加载中'
          @on-row-click='onRowClick'
        >
        </Table>
      </div>

    </Modal>
</template>

<script>
import { debounce } from "underscore";

export default {
  data() {
    return {
      crmId: "",
      sbId: "",
      tableKey: "",
      modal: false,
      keywords: "",
      loading: false,
      currentIndex: "",
      tableData: [],
      columns: [
        {
          title: "选中",
          align: "center",
          width: 50,
          render: (h, { row, column, index }) => {
            let flag = this.currentIndex === index;
            return h("Radio", {
              props: {
                value: flag
              }
            });
          }
        },
        {
          title: "公司名称",
          key: "companyName",
          width: 210
        },
        {
          title: "城市",
          key: "city",
          width: 105
        },
        {
          title: "备案编码",
          key: "registerNumber",
          width: 100
        }
      ]
    };
  },

  methods: {
    // 提交
    onOk() {
      if (!this.sbId) {
        this.$Message.warning("请先选择机构！");
        return;
      }
      let params = {
        orgId: this.crmId,
        companyId: this.sbId
      };

      this.$http
        .post(`orgAssociation`, params)
        .then(res => {
          if (res.code === 20000) {
            this.$Message.success("关联成功！");
            this.$emit("refreshTableDate");
            this.onCancel();
          } else {
            this.$Message.error(`关联失败：${res.msg}`);
          }
        })
        .catch(e => {
          console.error(e);
        });
    },

    // 取消
    onCancel() {
      this.modal = false;
      this.crmId = "";
      this.sbId = "";
      this.currentIndex = "";
      this.keywords = "";
      this.tableData = [];
    },

    // 显示模态框
    show(id) {
      this.crmId = id;
      this.modal = true;
    },

    //  获取公司列表
    getCompanyList() {
      if (!this.keywords) {
        return;
      }
      this.currentIndex = "";
      this.loading = true;
      this.tableData = [];
      let params = {
        keyWord:this.keywords
      };

      this.$http.get(`orgAssociation/findCompanyList`, params).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          this.tableData = res.data;
          this.tableKey = Date.now();
        } else {
          this.$Message.error(`获取数据失败：${res.msg}`);
        }
      });
    },

    // 选中单行
    onRowClick(crow, index) {
      this.currentIndex = index;
      this.sbId = crow.companyId;
    }
  }
};
</script>

<style lang="less" scoped>
.input-container {
  margin-bottom: 15px;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  span {
    font-weight: 900;
  }
}
</style>
