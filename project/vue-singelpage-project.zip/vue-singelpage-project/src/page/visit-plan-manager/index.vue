<template>
  <div class="grid-content">
    <div class="help-icon">
      <Poptip placement="left-start" trigger="hover">
        <span style="font-size:12px;">
          帮助
          <Icon type="help-circled" style="font-size: 16px;vertical-align:text-bottom;"></Icon>
        </span>
        <div slot="content">
          <p>
            <Icon type="checkmark-circled" style="color:green;"></Icon>&nbsp;&nbsp;已完成
          </p>
          <p>
            <Icon type="clock" style="color:#b38418e0;"></Icon>&nbsp;&nbsp;待完成
          </p>
          <p>
            <Icon type="close-circled" style="color:red;"></Icon>&nbsp;&nbsp;超过缓冲期未完成
          </p>
          <p>
            <Icon type="alert-circled" style="color:#695f5f;opacity:.6;"></Icon>&nbsp;&nbsp;已取消
          </p>
        </div>
      </Poptip>
    </div>
    <!-- 搜索表单区域 -->
    <div class="searchArea keydown-box">
      <search-area ref="form" @changeSearchParam="changeSearchParam" @onKeydownSearch="search">
        <div slot="default">
          <Row>
            <Col span="8">
              <Form-item prop="contacts_name" label="关键词">
                <Row>
                  <Col span="12" style="padding-right: 3px">
                    <Input v-model="formSearch.org_name" placeholder="机构,如:总部 分部"></Input>
                  </Col>
                  <Col span="12" style="padding-left: 3px">
                    <Input v-model="formSearch.contacts_name" placeholder="拜访对象,如:张三"></Input>
                  </Col>
                </Row>
              </Form-item>
            </Col>
            <Col span="8">
              <Form-item prop="visit_time" label="拜访时间">
                <DatePicker
                  style="width: 100%;"
                  type="daterange"
                  v-model="formSearch.visit_date"
                  placeholder="请输入拜访时间"
                ></DatePicker>
              </Form-item>
            </Col>
            <Col span="4" offset="1">
              <Button type="primary" @click="search">搜索</Button>
              <Button @click="reset">重置</Button>
            </Col>
          </Row>
        </div>
        <div slot="extend">
          <Row>
            <Col span="8">
              <FormItem label="机构类型">
                <Row>
                  <Col span="11">
                    <Select v-model="formSearch.oc_id" clearable placeholder="请选择">
                      <Option
                        v-for="item in enums.c_org"
                        :value="item.value"
                        :key="item.value"
                      >{{item.name}}</Option>
                    </Select>
                  </Col>
                  <Col span="12" offset="1">
                    <Select
                      v-model="formSearch.depart_id"
                      not-found-text="无匹配数据"
                      clearable
                      placeholder="请选择机构"
                    >
                      <Option
                        v-for="item in enums.c_depart"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>
                </Row>
              </FormItem>
            </Col>
            <Col span="8">
              <FormItem label="拜访类型">
                <Select
                  v-model="formSearch.visit_type"
                  not-found-text="无匹配数据"
                  clearable
                  placeholder="请选择拜访类型"
                >
                  <Option
                    v-for="item in visitType"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value"
                  ></Option>
                </Select>
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span="8">
              <Form-item label="拜访人">
                <Col span="12" style="padding-right: 3px">
                  <Select v-model="formSearch.dept_id" clearable @on-change="onDeptChange">
                    <Option
                      v-for="item in department"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    ></Option>
                  </Select>
                </Col>
                <Col span="12" style="padding-left: 3px">
                  <Select
                    v-model="formSearch.visit_member"
                    not-found-text="无匹配数据"
                    :disabled="unChoosenDept"
                    clearable
                    placeholder="请选择拜访人"
                  >
                    <Option
                      v-for="item in workmate"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    ></Option>
                  </Select>
                </Col>
              </Form-item>
            </Col>
            <Col span="8">
              <Form-item label="意向">
                <Select v-model="formSearch.demand_ids" multiple clearable placeholder="意向">
                  <Option
                    v-for="item in demandType"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value"
                  ></Option>
                </Select>
              </Form-item>
            </Col>
          </Row>
        </div>
      </search-area>
    </div>
    <!-- 表格 -->
    <div class="tableContainer">
      <Table
        class="table-grid"
        ref="commontable"
        border
        :columns="columns"
        :data="tableData"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
      />
    </div>
    <!-- 分页器 -->
    <div class="page-load">
      <div class="float-right">
        <Page
          :total="total"
          placement="top"
          :current="currentPage"
          :page-size="pageSize"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizeChange"
          show-elevator
          show-sizer
          show-total
        />
      </div>
    </div>
    <plan-modal ref="planModal" @reload="search"></plan-modal>
  </div>
</template>
<script>
import searchArea from "../../components/search-area";
import SelectUrl from "@/components/inputs/select-url";
import planModal from "../visit-plan-personal/plan-modal";
import { getCache } from "@/plugin/cache";
import { extend, each } from "underscore";
import {
  fetchGrid,
  delPlan,
  fetchWorkmate,
  getReciver,
  cancelOrRecoveryPlan
} from "@/service/getData";
import { mapGetters } from "vuex";
import moment from "moment";
import $ from "jquery";
import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  components: {
    SelectUrl,
    searchArea,
    planModal
  },

  watch: {
    visitProjectStatus: {
      handler(val) {
        if (val.saleId) {
          this.$set(this.formSearch, "dept_id", 16);
          this.$set(this.formSearch, "visit_member", val.saleId);
          this.$set(this.formSearch, "visit_date", [
            val.startDate,
            val.endDate
          ]);
          this.showByAlysis = true;
          this.onDeptChange(this.formSearch.dept_id);
          setTimeout(() => {
            this.$refs.form.expandMore();
          }, 0);
          this.changeSearchParam(true);
          this.search();
        }
      },

      deep: true,

      immediate: true
    }
  },

  mixins: [getMinusNumber],

  data() {
    return {
      isShowMoreParams: false,
      tableLoading: false,
      loading: false,
      tableData: [],
      columns: [
        {
          title: "计划拜访时间",
          key: "visit_date",
          fixed: "left",
          width: 140,
          render: (h, params) => {
            return moment(`${params.row.visit_date}`).format(
              "YYYY-MM-DD HH:mm"
            );
          }
        },
        {
          title: "计划标题",
          key: "topic",
          fixed: "left",
          width: 150,
          render: (h, params) => {
            let status = params.row.status;
            let now = new Date().getTime();
            let planTime =
              new Date(params.row.visit_date).getTime() +
              this.maxCacheTime * 3600 * 1000;
            let tagType;
            if (!params.row.isvalid) {
              tagType = h("Icon", {
                props: {
                  type: "alert-circled"
                },
                style: {
                  color: "#695f5f",
                  marginRight: "5px",
                  fontSize: "14px",
                  opacity: ".6",
                  cursor: "pointer"
                },
                attrs: {
                  title: "已取消"
                }
              });
            } else {
              // 待完成
              if (planTime > now && status == 1) {
                tagType = h("Icon", {
                  props: {
                    type: "clock"
                  },
                  style: {
                    color: "#b38418e0",
                    marginRight: "5px",
                    fontSize: "14px",
                    fontWeight: "900",
                    cursor: "pointer"
                  },
                  attrs: {
                    title: "待完成"
                  }
                });
              } else if (planTime < now && status == 1) {
                // 未完成
                tagType = h("Icon", {
                  props: {
                    type: "close-circled"
                  },
                  style: {
                    color: "red",
                    marginRight: "5px",
                    fontSize: "14px",
                    // fontWeight:"900",
                    cursor: "pointer"
                  },
                  attrs: {
                    title: "超过缓冲期未完成"
                  }
                });
              } else {
                // 已完成
                tagType = h("Icon", {
                  props: {
                    type: "checkmark-circled"
                  },
                  style: {
                    color: "green",
                    marginRight: "5px",
                    fontSize: "14px",
                    // fontWeight:"900",
                    cursor: "pointer"
                  },
                  attrs: {
                    title: "已完成"
                  }
                });
              }
            }
            return h("div", [tagType, h("span", params.row.topic)]);
          }
        },
        {
          title: "拜访人",
          key: "visit_member_name",
          fixed: "left",
          width: 70
        },
        {
          title: "拜访对象",
          key: "contacts_name",
          fixed: "left",
          width: 70,
          render: (h, params) => {
            return params.row.contacts_id ? params.row.contacts_name : "无";
          }
        },
        {
          title: "机构名称",
          key: "org_name",
          width: 500,
          render: (h, params) => {
            if (params.row.bread.length >= 3) {
              return h(
                "div",
                params.row.bread
                  .map((bread, index, breads) => {
                    return h(
                      "a",
                      {
                        on: {
                          click: e => {
                            let tab = {
                              activeName: bread.title,
                              pid: bread.id,
                              name: `${bread.title}${bread.id}`,
                              component: "departmentDetails",
                              isShow: true
                            };
                            this.$store.dispatch("setTabs", tab);
                            // if (
                            //   this.tabs.some(item => {
                            //     return (
                            //       item.name === tab.name && item.pid === tab.pid
                            //     );
                            //   })
                            //   // (_.findIndex(this.tabs, tabItem => {
                            //   //      return tabItem.name == tab.name;
                            //   //    }) != -1)&& (_.findIndex(this.tabs, tabItem => {
                            //   //      return tabItem.pid == tab.pid;
                            //   //    }) != -1)
                            // ) {
                            //   let newtabs = this.tabs.map(item => {
                            //     if (item.name == tab.name) {
                            //       item.isShow = true;
                            //     }
                            //     return item;
                            //   });
                            //   this.$store.dispatch("setTabsAll", newtabs);
                            //   this.$store.dispatch("setActiveTab", {
                            //     activeTab: tab.name
                            //   });
                            // } else {
                            //   this.$store.dispatch("setTabs", tab);
                            //   this.$store.dispatch("setActiveTab", {
                            //     activeTab: tab.name
                            //   });
                            // }
                            e.stopPropagation();
                          }
                        }
                      },
                      index === breads.length - 1
                        ? `${bread.title}`
                        : `${bread.title}>`
                    );
                  })
                  .splice(1)
              );
            } else {
              return h(
                "a",
                {
                  on: {
                    click: e => {
                      let tab = {
                        activeName: params.row.org_name,
                        pid: params.row.org_id,
                        name: `${params.row.org_name}${params.row.org_id}`,
                        component: "departmentDetails",
                        isShow: true
                      };
                      this.$store.dispatch("setTabs", tab);
                      // if (
                      //   this.tabs.some(item => {
                      //     return item.name === tab.name && item.pid === tab.pid;
                      //   })
                      //   // (_.findIndex(this.tabs, tabItem => {
                      //   //           return tabItem.name == tab.name;
                      //   //         }) != -1)&& (_.findIndex(this.tabs, tabItem => {
                      //   //           return tabItem.pid == tab.pid;
                      //   //         }) != -1)
                      // ) {
                      //   let newtabs = this.tabs.map(item => {
                      //     if (item.name == tab.name) {
                      //       item.isShow = true;
                      //     }
                      //     return item;
                      //   });
                      //   this.$store.dispatch("setTabsAll", newtabs);
                      //   this.$store.dispatch("setActiveTab", {
                      //     activeTab: tab.name
                      //   });
                      // } else {
                      //   this.$store.dispatch("setTabs", tab);
                      //   this.$store.dispatch("setActiveTab", {
                      //     activeTab: tab.name
                      //   });
                      // }
                      e.stopPropagation();
                    }
                  }
                },
                params.row.org_name
              );
            }
          }
        },
        {
          title: "备注提醒",
          key: "plan_content",
          width: 280,
          render: (h, params) => {
            return params.row.plan_content || "--";
          }
        },
        {
          title: "部门类型",
          key: "depart_id",
          width: 80,
          render: (h, { row, column, index }) => {
            let type =
              _.find(this.orgType, type => {
                return type.value === `${row.depart_id}`;
              }) || {};
            return type.name || "--";
          }
        },
        {
          title: "拜访类型",
          key: "visit_type",
          width: 80,
          render: (h, { row, column, index }) => {
            let type =
              _.find(this.visitType, type => {
                return type.value === `${row.visit_type}`;
              }) || {};
            return type.name || "--";
          }
        },
        {
          title: "需求点",
          key: "demand_ids",
          width: 210,
          render: (h, { row, column, index }) => {
            let demands =
              typeof row.demand_ids == "string"
                ? JSON.parse(row.demand_ids)
                : [];
            demands = demands.map(id => {
              let type =
                _.find(this.demandType, type => {
                  return type.value === `${id}`;
                }) || {};
              return type.name;
            });
            return h(
              "div",
              {
                style: {
                  "max-width": "180px"
                }
              },
              demands.join(", ") || "--"
            );
          }
        },
        {
          title: "操作",
          key: "action",
          fixed: "right",
          width: 140,
          align: "center",
          render: (h, { row, column, index }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  style: {
                    backgroundColor: "none"
                  },
                  on: {
                    click: () => {
                      let cancelOrRecovery =
                        row.isvalid == 1 ? "cancel" : "recovery";
                      let isShowEdit;
                      let now = new Date().getTime();
                      let planTime = new Date(row.visit_date).getTime();
                      if (row.status === 1 && planTime > now) {
                        // 待完成
                        isShowEdit = true;
                      } else if (row.status === 1 && planTime < now) {
                        // 未完成
                        isShowEdit = false;
                      } else {
                        isShowEdit = false;
                      }
                      this.showDetail(
                        row.id,
                        row.visit_date,
                        isShowEdit,
                        cancelOrRecovery,
                        row.isvalid,
                        row.status
                      );
                    }
                  }
                },
                "查看"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  style: {
                    backgroundColor: "none"
                  },
                  on: {
                    click: () => {
                      this.delPlan(row);
                    }
                  }
                },
                "删除"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  style: {
                    backgroundColor: "none"
                  },
                  on: {
                    click: () => {
                      let status = row.isvalid == 1 ? 0 : 1;
                      this.setPlanStatus(row.id, status);
                    }
                  }
                },
                row.isvalid == 1 ? "取消" : "恢复"
              )
            ]);
          }
        }
      ],
      pageSize: 10,
      total: 0,
      currentPage: 1,
      initFormSearch: {
        demand_ids: [],
        visit_date: [],
        depart_id: [],
        oc_id: [],
        org_name: "",
        contacts_name: "",
        visit_type: "",
        dept_id: "",
        visit_member: ""
      },
      formSearch: {
        demand_ids: [],
        visit_date: [],
        depart_id: [],
        oc_id: [],
        org_name: "",
        contacts_name: "",
        visit_type: "",
        dept_id: "",
        visit_member: ""
      },
      listUrl: "plan/getList",
      unChoosenDept: true,
      department: [],
      workmate: [],
      showByAlysis: false
    };
  },
  computed: {
    ...mapGetters({
      user: "getUser",
      enums: "getEnums",
      tabs: "getTabs",
      visitProjectStatus: "getVisitProjectStatus"
    }),
    orgType() {
      return this.enums.c_org;
    },
    visitType() {
      return this.enums.c_visit_type;
    },
    maxCacheTime() {
      return this.enums.c_max_exec_time[0].value;
    },
    demandType() {
      return this.enums.c_demand;
    }
  },

  mounted() {
    this.getDepartment();
    if (!this.showByAlysis) {
      this.formSearch = JSON.parse(JSON.stringify(this.initFormSearch));
      this.updateGrid();
    }
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".searchArea", ".page-load"],
      ".tableContainer"
    );
  },

  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 110;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },
    setPlanStatus(id, status) {
      let contentText = status == 0 ? "确定取消？" : "确定恢复？";
      let confirmTitle = status == 0 ? "取消" : "恢复";
      this.$Modal.confirm({
        title: confirmTitle,
        content: contentText,
        loading: true,
        onOk: () => {
          this.changePlanStatus(id, status).then(() => {
            this.$Modal.remove();
          });
        }
      });
    },
    // 切换计划状态
    changePlanStatus(id, status) {
      return new Promise((resolve, reject) => {
        let params = {
          id: id,
          status: status
        };
        cancelOrRecoveryPlan(params).then(res => {
          if (res.code == 20000) {
            this.$Message.info("设置成功！");
            resolve();
            this.updateGrid();
          } else {
            this.$Message.info("设置失败！");
            reject();
          }
        });
      });
    },
    // 转换时差
    transferTimeZoneOffset(time) {
      return moment(time).format("YYYY-MM-DD");
    },
    search() {
      this.updateGrid();
    },
    reset() {
      this.formSearch = JSON.parse(JSON.stringify(this.initFormSearch));
      this.updateGrid();
    },
    onDeptChange(val) {
      if (val) {
        this.unChoosenDept = false;
        this.workmate = [];
        let data = {
          dept_id: val,
          type: 1
        };
        this.getWorkmate(data);
      } else {
        this.unChoosenDept = true;
        this.workmate = [];
      }
    },
    // 获取部门下拉
    getDepartment() {
      fetchWorkmate().then(res => {
        if (res.code == 20000) {
          this.department = res.data;
        }
      });
    },
    getWorkmate(data) {
      getReciver(data).then(res => {
        if (res.code == 20000) {
          this.workmate = res.data;
        } else {
          this.workmate = [];
        }
      });
    },
    onPersonChange() {},
    // 控制更多打开时传递的参数
    changeSearchParam(val) {
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".searchArea", ".page-load"],
          ".tableContainer"
        );
      });

      this.isShowMoreParams = val;
    },

    //更新表格
    updateGrid() {
      let formData = JSON.parse(JSON.stringify(this.formSearch));
      for (let key in formData) {
        if (key == "visit_date") {
          formData[key] = formData[key].map(item => {
            if (item) {
              return this.transferTimeZoneOffset(item);
            } else {
              return "";
            }
          });
        }
        if (key == "org_name") {
          formData[key] = JSON.parse(JSON.stringify(formData[key]))
            .trim()
            .split(/[ ]+/);
        }
      }
      let params = {};
      if (!this.isShowMoreParams) {
        params = {
          rows: this.pageSize,
          page: this.currentPage,
          visit_date: formData.visit_date,
          org_name: formData.org_name,
          contacts_name: formData.contacts_name,
          sortKey: "visit_date",
          sortOrder: "desc"
        };
      } else {
        params = {
          rows: this.pageSize,
          page: this.currentPage,
          sortKey: "visit_date",
          sortOrder: "desc",
          ...formData
        };
      }

      if (params.visit_date && !params.visit_date[0]) {
        delete params.visit_date;
      }
      this.tableLoading = true;
      fetchGrid(this.listUrl, params).then(
        resp => {
          this.loading = false;
          this.tableLoading = false;
          resp = resp.data;
          this.tableData = resp.data || [];
          this.total = resp.total || 0;
        },

        error => {
          this.tableData = [];
          this.total = 0;
          console.log(error);
        }
      );
    },

    //页码改变
    onPageChange(val) {
      this.currentPage = val;
      this.updateGrid();
    },

    //单页显示数量发生改变
    onPageSizeChange(val) {
      this.currentPage = 1;
      this.pageSize = val;
      this.updateGrid();
    },

    showDetail(
      id,
      date,
      isShowEdit,
      cancelOrRecovery,
      planStatus,
      visitPlanStatus
    ) {
      this.$refs.planModal.show(
        "edit",
        id,
        date,
        isShowEdit,
        cancelOrRecovery,
        planStatus,
        visitPlanStatus
      );
    },
    delPlan(row) {
      if (row.visit_member_id === this.user.id) {
        this.$Modal.confirm({
          title: "确认删除",
          content: "确认删除此条计划吗？",
          loading: true,
          onOk: () => {
            delPlan(row.id).then(resp => {
              if (resp.code === 20000) {
                this.$Message.success("删除成功");
              } else {
                this.$Message.success("删除失败 " + resp.msg);
              }
              this.updateGrid();
              this.$Modal.remove();
            });
          }
        });
      } else {
        this.$Modal.remove();
        this.$Message.warning("无法删除他人的计划");
      }
    }
  }
};
</script>
<style lang="less" scoped>
// 组件整体样式
.grid-content {
  // margin: 5px;
  // padding-top: 30px;
  position: relative;
}

//  搜索区域样式
.form.ivu-form.ivu-form-label-right {
  border-bottom: 1px solid rgb(233, 234, 236);
  padding: 30px 200px 20px 0px;
}

//搜索选项样式
.ivu-form-item {
  // width: 90%;
}

//  导出按钮样式
.pull-right.ivu-btn.ivu-btn-primary {
  float: right;

  margin: 8px 0px;
} //  表格样式
.table-grid {
  margin-top: 5px;
}

// 分页器样式
.page-load {
  margin: 10px;
  overflow: hidden;
  .float-right {
    float: right;
  }
}

.help-icon {
  position: absolute;
  right: 20px;
  top: 0px;
  color: #2d8cf0;
  font-size: 16px;
  z-index: 1;
}

.staus-line {
  border-bottom: 1px dashed #ccc;
  padding: 5px 0;
}
</style>
