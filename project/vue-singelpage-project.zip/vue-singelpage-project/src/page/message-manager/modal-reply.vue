<template>
  <div>
    <Modal v-model="selfModal"  width=500 >
      <div v-text="from+'：'+msg" class="msg-content"></div>
      <Form>
        <FormItem>
          <Input v-model="replyContent" type="textarea" :autosize="{minRows: 4,maxRows: 8}" placeholder="请输入..."></Input>
        </FormItem>
      </Form>
      <div slot="footer">
        <Button type="primary" @click="ok" :loading="buttonLoading">回复</Button>
        <Button type="ghost" @click="cancel">取消</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
import { postFormData } from "@/service/getData"
export default {
  data() {
    return {
        buttonLoading:false,
      replyContent: "",
      selfModal: false,
    }
  },
  watch: {
    modal(val) {
      this.selfModal = val;
    }
  },
  methods: {
    ok() {
      if (this.replyContent == "") {
        this.$emit("confirm")
        return;
      }
      this.buttonLoading = true;
      let ori = {
        type: this.type,
        to_id: this.id,
        message: this.replyContent,
        pid: this.pid,
        visit_id: this.visitId,
      }
      let params = {};
      for (let key in ori) {
        if (!(ori[key] === '' || ori[key] === null)) {
          params[key] = ori[key]
        }
      }
      postFormData("msg/send", params).then((res) => {
        this.replyContent = '';
        if (res.code === 20000) {
          this.$Message.info('发送成功')
          this.buttonLoading = false;
          this.$emit("confirm")
        }else{
            this.$Message.warning(res.msg)
            this.$emit("confirm")
            this.buttonLoading = false;
        }
        
      })

    },
    cancel() {
      this.$emit("cancel");
    }
  },
  props: ['modal', "id", "from", "msg", "pid", "type", "visitId"]
}

</script>
<style scoped>
.ivu-icon {
  vertical-align: middle;
  margin-right: 10px;
}

.ivu-modal-body {
  font-size: 10px;
}

.msg-content {
  padding-bottom: 20px;
}

</style>
