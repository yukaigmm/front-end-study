<template>
  <div class="msg-content">
    <div class="msg-searchOptions keydown-box">
      <search-area @changeSearchParam="changeSearchParam" @onKeydownSearch="search">
        <!-- <Form :label-width="80"> -->
        <!-- 第一行：消息日期和发送人 -->
        <div slot="default">
          <Row>
            <!-- 消息日期 -->
            <Col span="8">
            <FormItem label="消息日期">
              <DatePicker style="width:100%;" type="daterange" format="yyyy-MM-dd" placeholder="选择日期" v-model="dateRange"></DatePicker>
            </FormItem>
            </Col>
            <Col span="8">
            <FormItem label="消息状态">
              <Select v-model="is_read" clearable placeholder="请选择">
                <Option value=0>全部</Option>
                <Option value=2>已读</Option>
                <Option value=1>未读</Option>
              </Select>
            </FormItem>
            </Col>
            <Col span="4" style="padding-left:10px;">
            <Button type="primary" @click="search">搜索</Button>
            <!-- <Button type="default" @click="reset">重置</Button> -->
            </Col>
          </Row>
        </div>
        <div slot="extend">
          <Row>
            <!-- 发送人 -->
            <Row>
              <Col span="8">
              <FormItem label="发送人">
                <Row>
                  <Col span="16" class="msg-sender">
                   <Select v-model="from_dept" placeholder="请选择部门" clearable @on-change='onSendDeptChange'>
                    <Option v-for="item in selData" :key="item.value" :label="item.label" :value="item.value">
                    </Option>
                   </Select>
                  <!-- <Cascader :data="selData" v-model="from_dept" @on-change="onSendDeptChange" change-on-select></Cascader> -->
                  </Col>
                  <Col span="8">
                  <Select v-model="from_id" clearable placeholder="请选择">
                    <Option v-for="(item,index) in sendStuff" :key="index" :value="item.value">{{item.label}}</Option>
                  </Select>
                  </Col>
                </Row>
              </FormItem>
              </Col>
              <Col span="8">
              <FormItem label="收件人">
                <Row>
                  <Col span="16" class="msg-sender">
                  <Select v-model="to_dept" placeholder="请选择部门" clearable @on-change='onReceiveDeptChange'>
                    <Option v-for="item in selData" :key="item.value" :label="item.label" :value="item.value">
                    </Option>
                   </Select>
                  <!-- <Cascader :data="selData" v-model="to_dept" @on-change="onReceiveDeptChange" change-on-select></Cascader> -->
                  </Col>
                  <Col span="8">
                  <Select v-model="to_id" clearable placeholder="请选择">
                    <Option v-for="(item,index) in receiveStuff" :key="index" :value="item.value">{{item.label}}</Option>
                  </Select>
                  </Col>
                </Row>
              </FormItem>
              </Col>
              <!-- 第二行：消息类别和收件人 -->
            </Row>
            <!-- 收件人 -->
            <Row v-if="false">
              <Col span="8">
              <FormItem label="消息类别">
                <Select v-model="type" clearable placeholder="请选择">
                  <Option value=1>日志评论</Option>
                  <Option value=2>系统消息</Option>
                  <Option value=3>预设回访提醒</Option>
                </Select>
              </FormItem>
              </Col>
            </Row>
          </Row>
        </div>
      </search-area>
    </div>
    <div>
      <div class="mail-btns">
        <span @click="getAllMsg" :class='{chosen:boxStatus=="allMsg"?true:false}' class="mailBox all">全部消息</span>
        <Dropdown trigger="click">
          <div :class='{chosen:boxStatus=="recieve"?true:false}' class="mailBox">
            <span @click.stop="getRecieveMessage" style="back-ground:transparent;">
                  收件箱
                </span>
            <Icon type="arrow-down-b"></Icon>
          </div>
          <DropdownMenu slot="list">
            <DropdownItem>
              <div @click="getReadMsg">已读消息</div>
            </DropdownItem>
            <DropdownItem>
              <div @click="getUnReadMsg">未读消息</div>
            </DropdownItem>
            <DropdownItem>
              <div @click="markedMany(1)">批量设为已读</div>
            </DropdownItem>
            <DropdownItem>
              <div @click="markedMany(2)">批量设为未读</div>
            </DropdownItem>
          </DropdownMenu>
        </Dropdown>
        <Dropdown trigger="click">
          <div :class='{chosen:boxStatus=="send"?true:false}' class="mailBox">
            <span @click.stop="getSendMessage" style="back-ground:transparent;">
                  发件箱
                </span>
            <Icon type="arrow-down-b"></Icon>
          </div>
          <DropdownMenu slot="list">
            <DropdownItem>
              <div @click="getOtherReadMsg">对方已读消息</div>
            </DropdownItem>
            <DropdownItem>
              <div @click="getOtherUnReadMsg">对方未读消息</div>
            </DropdownItem>
          </DropdownMenu>
        </Dropdown>
      </div>
      <div class="tableContainer" v-loading="loading" element-loading-text="拼命加载中">
        <Table border :columns="columns" :data="tableData.data" @on-selection-change='onSelectionChange' @on-row-click="onRowClick" :row-class-name='rowClassName'></Table>
      </div>
    </div>
    <!-- 分页器 -->
    <div class="msg-page-load">
      <div class="msg-float-right">
        <Page :total="tableData.total" placement="top" :current="page" :page-size="rows" @on-change="onPageChange" @on-page-size-change="onPageSizeChange" show-elevator show-sizer show-total />
      </div>
    </div>
    <!-- 发送消息的模态框 -->
    <div>
      <modal-rep :from="from_name" :pid="pid" :msg="msg" :modal="reply" :id="from_id" :type="replyType" :visitId="visit_id" @confirm="confirm" @cancel="cancel"></modal-rep>
    </div>
    <div>
      <modal-more ref="visitContactDialog" :orgId="org_id"></modal-more>
    </div>
    <transmitModal ref="transmit"></transmitModal>
  </div>
</template>
<script>
import searchArea from "../../components/search-area";
import modalRep from "./modal-reply.vue";
import modalMore from "../contact-manager/visit-contact-dialog.vue";
import transmitModal from "../contact-manager/transmit-modal.vue";
import axios from "axios";
import { mapGetters } from "vuex";
import { actions } from "@/store/index.js";
import { ifVisitRecordExist } from "@/service/getData";
import getMinusNumber from "@/mixins/getMinusNumber.js";

import $ from "jquery";
import moment from "moment";
export default {
  mixins:[getMinusNumber],
  data() {
    return {
      isShowMoreParams: false,
      boxStatus: "allMsg",
      dotIndex: [],
      messageCount: 0,
      to: [],
      ids: [],
      msgFrom: [],
      loading: false, //加载动画状态
      selData: [], //部门级联菜单的数组
      type: 1, //消息的类型
      from_id: "", //绑定的发送人的id
      to_id: "",
      send_type: "",
      is_read: "",
      from_dept: "",
      to_dept: "",
      // create_time: [], //查询区域timePicker绑定值
      sendStuff: [],
      receiveStuff: [],
      dateRange: [],
      config: "",
      from: "",
      from_name: "",
      visit_id: "",
      msg: "",
      pid: "",
      replyType: "",
      reply: false, //控制模态框显示隐藏的参数
      page: 1,
      rows: 10,
      org_id: null,
      // 消息列表参数
      tableData: {},
      columns: [
        {
          type: "selection",
          width: 50,
          align: "center"
        },
        {
          title: "消息",
          key: "message",
          render: (h, params) => {
            if (params.row.to_member_id === this.userId) {
              return h(
                "div",
                {
                  style: {
                    position: "relative",
                    height: "40px",
                    lineHeight: "40px",
                    left: "-18px",
                    paddingLeft: "30px"
                  }
                },
                [
                  h("div", {
                    style: {
                      width: "10px",
                      height: "10px",
                      borderRadius: "50%",
                      display: "inline-block",
                      marginLeft: "10px",
                      position: "absolute",
                      top: "5px",
                      left: "6px",
                      cursor: "pointer"
                    },
                    on: {
                      click: e => {
                        e.stopPropagation();
                        this.changeMsgStatus(
                          [params.row.id],
                          params.row.is_read
                        );
                        return false;
                      }
                    },
                    attrs: {
                      class: `is-read`,
                      title: "点击切换消息状态"
                    }
                  }),
                  h("p", `${params.row.message}`)
                ]
              );
            } else {
              return h(
                "div",
                {
                  style: {
                    position: "relative",
                    height: "40px",
                    lineHeight: "40px",
                    left: "-18px",
                    paddingLeft: "30px"
                  }
                },
                [
                  h("div", {
                    style: {
                      width: "10px",
                      height: "10px",
                      borderRadius: "50%",
                      display: "inline-block",
                      marginLeft: "10px",
                      position: "absolute",
                      top: "5px",
                      left: "6px",
                      cursor: "pointer"
                    },
                    on: {
                      click: e => {
                        e.stopPropagation();
                        return false;
                      }
                    },
                    attrs: {
                      class: `other-is-read`,
                      title: `${
                        params.row.is_read == 1 ? "对方已读" : "对方未读"
                      }`
                    }
                  }),
                  h("p", `${params.row.message}`)
                ]
              );
            }
          }
        },
        {
          title: "消息时间",
          key: "create_time",
          align: "center",
          width: 110,
          render: (h, params) => {
            return h(
              "p",
              {
                attrs: {
                  title: `${params.row.create_time}`
                }
              },
              `${params.row.create_time.substring(0, 10)}`
            );
          }
        },
        {
          title: "发送人",
          key: "from_member_name",
          width: 90,
          align: "center"
        },
        {
          title: "收件人",
          key: "to_member_name",
          width: 90,
          align: "center"
        },
        {
          title: "消息类别",
          key: "type",
          width: 90,
          align: "center"
        },
        {
          title: "操作",
          key: "action",
          align: "center",
          width: 150,
          render: (h, params) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();
                      // 点击回复按钮，传递id和消息来源给模态框
                      this.getReply(
                        params.row.from_member_id,
                        params.row.msg_type,
                        params.row.from_member_name,
                        params.row.message,
                        params.row.id,
                        params.row.msg_ext.length
                          ? JSON.parse(params.row.msg_ext)["visit_id"]
                          : "",
                        params.row
                      );
                    }
                  }
                },
                "回复"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();

                      let data = params.row.msg_ext.length
                        ? JSON.parse(params.row.msg_ext)
                        : {};
                      let visit_id = data.visit_id;
                      ifVisitRecordExist(visit_id).then(res => {
                        if (res.data.isvalid) {
                          this.transmit(visit_id);
                        } else {
                          // 拜访记录不存在时显示提示
                          this.$Notice.warning({
                            title: "拜访记录已被删除或不存在！",
                            duration: 2
                          });
                          return;
                        }
                      });
                    }
                  }
                },
                "转发"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();
                      let data = params.row.msg_ext.length
                        ? JSON.parse(params.row.msg_ext)
                        : {};
                      let { contacts_id, visit_id, org_id } = data;
                      ifVisitRecordExist(visit_id).then(res => {
                        if (res.data.isvalid) {
                          this.showMore(contacts_id, visit_id, org_id);
                        } else {
                          // 拜访记录不存在时显示提示
                          this.$Notice.warning({
                            title: "拜访记录已被删除或不存在！",
                            duration: 2
                          });
                          return;
                        }
                      });
                    }
                  }
                },
                "详情"
              )
            ]);
          }
        }
      ]
    };
  },
  components: {
    modalRep,
    modalMore,
    searchArea,
    transmitModal
  },
  computed: {
    ...mapGetters({
      userId: "getUserId"
    })
  },

  mounted() {
    this.getMsgList();
    this.getAllSelect();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".msg-searchOptions", ".mail-btns", ".msg-page-load"],
      ".tableContainer"
    );
  },
  watch: {
    dateRange: {
      handler(val) {
        if (val.length && val[0]) {
          this.dateRange[0] = this.setTimeZone(val[0]);
          this.dateRange[1] = this.setTimeZone(val[1]);
        }
      },
      deep: true
    }
  },
  methods: {
    // 转发
    transmit(recordId) {
      this.$refs.transmit.show(recordId);
    },
    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 114;
      let minusNumber = this.getMinusNumberOfFixedTable(); 

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },
    //获取自己的已读消息
    getReadMsg() {
      this.boxStatus = "recieve";
      this.send_type = 2;
      this.is_read = 2;
      this.page = 1;
      this.getMsgList();
    },
    //获取自己的已读消息
    getUnReadMsg() {
      this.boxStatus = "recieve";
      this.send_type = 2;
      this.is_read = 1;
      this.page = 1;
      this.getMsgList();
    },
    //获取别人的已读消息
    getOtherReadMsg() {
      this.boxStatus = "send";
      this.send_type = 1;
      this.is_read = 2;
      this.page = 1;
      this.getMsgList();
    },
    //获取别人的未读消息
    getOtherUnReadMsg() {
      this.boxStatus = "send";
      this.send_type = 1;
      this.is_read = 1;
      this.page = 1;
      this.getMsgList();
    },
    // 控制更多打开时传递的参数
    changeSearchParam(val) {
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".msg-searchOptions", ".mail-btns", ".msg-page-load"],
          ".tableContainer"
        );
      });

      this.isShowMoreParams = val;
    },
    // 点击表格单行事件
    onRowClick(rowData) {
      if (rowData.is_read === 1) {
        return;
      }
      this.markedAsreaded(rowData.id, rowData.to_member_id, true, 1);
    },
    // 获取全部消息
    getAllMsg() {
      this.ids = [];
      this.send_type = 0;
      this.page = 1;
      this.is_read = 0;
      this.boxStatus = "allMsg";
      axios.get("api/msg/count?type=1").then(res => {
        this.$store.dispatch("setMessageCount", {
          messageCount: res.data.data.total
        });
      });
      this.getMsgList();
    },
    // 获取发件箱
    getSendMessage() {
      this.ids = [];
      this.boxStatus = "send";
      this.is_read = 0;
      this.send_type = 1;
      this.page = 1;
      this.getMsgList();
    },
    // 获取收件箱
    getRecieveMessage() {
      this.ids = [];
      this.boxStatus = "recieve";
      axios.get("api/msg/count?type=1").then(res => {
        this.$store.dispatch("setMessageCount", {
          messageCount: res.data.data.total
        });
      });
      this.send_type = 2;
      this.is_read = 0;
      this.page = 1;
      this.getMsgList();
    },
    // 改变消息状态(单行)
    changeMsgStatus(msgId, isRead) {
      if (isRead) {
        // 状态为已读时，切换状态为未读
        this.markedAsreaded(msgId, [this.userId], true, 2);
      } else {
        // 状态为未读时，切换状态为已读
        this.markedAsreaded(msgId, [this.userId], true, 1);
      }
    },
    // 设置未读行的样式
    rowClassName(row, index) {
      if (row.is_read === 0) {
        return "unreaded";
      } else {
        return "";
      }
    },
    //获取已选项
    onSelectionChange(selection) {
      let id = [];
      let to = [];
      let msgFrom = [];
      for (var i = 0; i < selection.length; i++) {
        for (var key in selection[i]) {
          if (key == "id") {
            id.push(selection[i][key]);
          }
          //获取接收人id，用于判断接收人是不是自己
          if (key == "to_member_id") {
            to.push(selection[i][key]);
          }
          if (key == "from_member_id") {
            msgFrom.push(selection[i][key]);
          }
        }
      }
      this.ids = id;
      this.to = to;
      this.msgFrom = msgFrom;
    },
    //批量状态设置
    markedMany(type) {
      if (this.ids.length == 1) {
        if (this.to[0] != this.userId) {
          this.$Message.warning({
            content: "只能选择接收人是自己的消息！"
          });
          return;
        }
      }
      // 判断是否有选中消息
      if (this.ids.length > 0) {
        for (let i = this.to.length - 1; i >= 0; i--) {
          if (this.to[i] != this.userId) {
            this.ids.splice(i, 1);
            this.to.splice(i, 1);
          }
        }
        this.markedAsreaded(this.ids, this.to, false, type);
      } else {
        this.$Message.warning({
          content: "请选择消息"
        });
      }
    },
    //将消息标记为已读
    /**
     * @param val array 选中的消息记录
     * @param to array  接收人id
     * @param tag boolean 控制是否显示提示消息
     * @param isRead number 设置状态
     */
    markedAsreaded(val, to, tag, isRead) {
      let id = [];
      let toId = [].concat(to);
      let params = id.concat(val);
      for (let i = 0; i < toId.length; i++) {
        //如果接收人不是自己不能标记
        if (toId[i] != this.userId) {
          if (!tag) {
            this.$Message.warning({
              content: "只能标记接收人是自己的消息"
            });
          }
          return;
        }
      }
      axios
        .put("api/msg/read", {
          ids: params,
          type: isRead
        })
        .then(res => {
          if (res.data.code == 20000) {
            axios.get("api/msg/count?type=1").then(res => {
              this.messageCount = res.data.data.total;
            });
            // 点击单行时不显示设置状态
            if (!tag) {
              this.$Message.info({
                content: "设置成功"
              });
            }
            this.ids = [];
            this.getMsgList();
            //标记完毕后重置表格状态，样式
            let self = this;
            setTimeout(() => {
              self.$store.dispatch("setMessageCount", {
                messageCount: self.messageCount
              });
            }, 500);
          }
        });
    },
    getMsgList() {
      let ori = {};
      let now = new Date();
      if (!this.isShowMoreParams) {
        // 判断选择时间的数组是否为空数组，如果是则踢掉，否则请求不到后台数据
        if (this.dateRange[0]) {
          ori = {
            // type: this.type,
            create_time: this.dateRange,
            rows: this.rows,
            page: this.page,
            is_read: this.is_read,
            send_type: this.send_type || 0
          };
        } else {
          ori = {
            // type: this.type,
            rows: this.rows,
            page: this.page,
            is_read: this.is_read,
            send_type: this.send_type || 0
          };
        }
      } else {
        // 判断选择时间的数组是否为空数组，如果是则踢掉，否则请求不到后台数据
        if (this.dateRange[0]) {
          ori = {
            // type: this.type,
            from_id: this.from_id,
            to_id: this.to_id,
            from_dept: this.from_dept,
            to_dept: this.to_dept,
            create_time: this.dateRange,
            rows: this.rows,
            page: this.page,
            is_read: this.is_read,
            send_type: this.send_type || 0
          };
        } else {
          ori = {
            // type: this.type,
            from_id: this.from_id,
            to_id: this.to_id,
            from_dept: this.from_dept,
            to_dept: this.to_dept,
            rows: this.rows,
            page: this.page,
            is_read: this.is_read,
            send_type: this.send_type || 0
          };
        }
      }
      let params = {};
      // 遍历对象，踢掉没有值的键
      for (let key in ori) {
        if (ori[key] || ori[key] === 0) {
          params[key] = ori[key];
        }
      }
      this.config = {
        params: params
      };
      this.loading = true;
      axios.get("/api/msg", this.config).then(res => {
        axios.get("api/msg/count?type=1").then(res => {
          this.$store.dispatch("setMessageCount", {
            messageCount: res.data.data.total
          });
        });
        this.loading = false;
        this.tableData = res.data.data;
        for (let item of this.tableData.data) {
          if (item.msg_type == 1) {
            item["type"] = "日志评论";
          } else if (item.msg_type == 2) {
            item["type"] = "系统消息";
          } else if (item.msg_type == 3) {
            item["type"] = "预设回访提醒";
          } else if (item.msg_type == 5) {
            item["type"] = "转发";
          } else {
            item["type"] = "分享";
          }
        }
      });
    },
    // 重置，暂时取消
    //  reset (){

    //   },
    // 点击查询按钮,根据获取到的数据配置部门id或是发送人的id
    search() {
      // 获取未读消息的数量
      axios.get("api/msg/count?type=1").then(res => {
        this.$store.dispatch("setMessageCount", {
          messageCount: res.data.data.total
        });
      });
      // this.send_type = 0;
      this.getMsgList();
    },
    // 获得请求回来的数据，转化成符合级联选择要求的所有数据
    getAllSelect() {
      axios.get("/api/dept/getAllSelect").then(res => {
        this.selData = res.data.data;
      });
    },
    // 在前面的发送部门级联菜单变化时，动态生成后面选项菜单的数组
    onSendDeptChange(val) {
      if (!val) {
        this.from_id = "";
      }
      let param = {
        dept_id: val,
        type: 1
      };
      axios
        .get("/api/dept/getUserByDept", {
          params: param
        })
        .then(res => {
          this.sendStuff = res.data.data;
        });
    },
    // 在前面的收件部门 级联菜单变化时，动态生成后面选项菜单的数组
    onReceiveDeptChange(val) {
      if (!val) {
        this.to_id = "";
      }
      let param = {
        dept_id: val,
        type: 1
      };
      axios
        .get("/api/dept/getUserByDept", {
          params: param
        })
        .then(res => {
          this.receiveStuff = res.data.data;
        });
    },
    // 点击回复按钮打开模态框
    getReply(val, type, from, msg, pid, visit_id, row) {
      if (row.to_member_id !== this.userId) {
        this.$Message.info("您无法回复他人收到的消息");
        return;
      }
      this.from_id = val;
      this.replyType = type;
      this.from_name = from;
      this.msg = msg;
      this.pid = pid;
      this.visit_id = visit_id;
      this.reply = true;
    },
    // 模态框子组件点击确定按钮触发的事件
    confirm() {
      this.reply = false;
      this.from_id = "";
      this.getMsgList();
    },
    // 模态框子组件点击取消按钮触发的事件
    cancel() {
      this.reply = false; 
    },
    // 点击更多按钮,弹出模态框,从contact-manager文件夹调用模态框
    showMore(contactId, visitId, orgId) {
      this.org_id = orgId;
      this.$refs.visitContactDialog.showVst(contactId, visitId, orgId);
    },
    // 分页器的方法
    onPageSizeChange(val) {
      this.page = 1;
      this.rows = val;
      this.getMsgList();
    },
    onPageChange(val) {
      this.page = val;
      this.getMsgList();
    }
  }
};
</script>
<style lang="less" scoped>
.msg-content {
  // padding-top: 30px;
  padding-bottom: 10px;
  position: relative;
}

.msg-searchOptions {
  // border-bottom: 1px solid #dddee1;
}

.msg-sender {
  padding-right: 8px;
}

.tableContainer {
  box-sizing: content-box;
}

.msg-page-load {
  padding-top: 10px;

  .msg-float-right {
    float: right;
  }
}

.msg-page-load:after {
  content: "";
  display: block;
  clear: both;
  height: 0;
  line-height: 0;
  visibility: hidden;
}

.mail-btns {
  margin-top: 10px;
  margin-bottom: 10px;
}

.mailBox {
  background-color: #f7f7f7;
  border: 1px solid #ccc;
  padding: 6px 10px;
  border-radius: 5px;
  cursor: pointer;
  margin-right: 8px;
}

.mailBox.all {
  padding: 8px 10px;
}

.mailBox.chosen {
  background: #3c8df5;
  color: white;
}
</style>
