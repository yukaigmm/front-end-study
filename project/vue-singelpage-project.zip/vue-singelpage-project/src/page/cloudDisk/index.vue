<template>
  <div class="cloud-disk-center">
    <div class="sys-container">
      <p>Wiki</p>
      <div>
         <a href="http://share.simuwang.com" target="_blank" title="Wiki">点击转到</a>
      </div>
    </div>
    <div class="sys-container">
      <p>分析系统</p>
      <div>
        <a href="https://fofanalysis.simuwang.com" target="_blank" title="分析系统">点击转到</a>
      </div>
    </div>

  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
  //  .cloud-disk-center{
  //    width: 350px;
  //    height: 200px;
  //    position: relative;
  //    left: 50%;
  //    top:50%;
  //    border: 2px solid #ccc;
  //    transform: translateX(-175px) translateY(-150px);
  //    text-align: center;
  //   cursor: pointer;
  //   padding: 10px 20px;
  //   display: flex;
  //   justify-content: center;
  //   align-items: center;
  //   flex-direction: column;
  //   transition:  all .5s ease;
  //   div{
  //     width: 100%;
  //     height: 50%;
  //     display: flex;
  //     flex-direction: row;
  //     align-items: center;
  //     justify-content: center;
  //     font-size: 18px ;
  //     font-weight: 900;
  //   }
  //   div:first-child{
  //     border-bottom: 1px dashed #ccc;
  //   }
    // &:hover{
    //   box-shadow: 5px 5px 15px #5d5959;
    // }
  //  }

  .sys-container{
    float: left;
    border: 2px solid #ccc;
    width: 200px;
    margin-right:15px;
    height: 100px;
    padding: 10px;
    transition:  all .5s ease;
    p{
      border-bottom: 1px dashed #ccc;
      font-size: 16px;
    }
    &:hover{
      box-shadow: 5px 5px 15px #5d5959;
    }
    div{
      padding-top:15px;
    }
  }
</style>
