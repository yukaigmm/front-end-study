<template>
  <div>
    <common-grid ref="grid" :config="config"></common-grid>

  </div>

</template>

<script>
  import commonGrid from './common-grid'
  import { getGridConfig } from './json-config'

  export default{
    data(){
      return {
        config: getGridConfig()
      }
    },

    components: {
      commonGrid
    },
    methods: {

    }
  }
</script>
