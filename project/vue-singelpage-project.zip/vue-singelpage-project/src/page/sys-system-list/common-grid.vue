<template>
  <div class="grid-content">
    <div v-loading="loading" element-loading-text="拼命加载中">
      <!-- 表格 -->
      <div class="table-container">
          <Table class="table-grid" ref="commontable" border :context="self" :columns="columns" :data="tableData"   />
      </div>

      <div class="page-load">
        <div class="float-right">
          <Page :total="total" placement="top" :current="currentPage" :page-size="pageSize" @on-change="onPageChange" @on-page-size-change="onPageSizeChange" show-elevator show-sizer show-total />
        </div>
      </div>
    </div>
 <!-- 模态框 -->
    <grid-dialog  ref="dialog" :edit-options="editOptions" :url="dialogUrl" :type="dialogType" :editkey="editKey" @ok="onDialogOk" />

  </div>
</template>

<script>
import TextArea from '@/components/inputs/textarea'
import InputJson from '@/components/inputs/input-json'
import {each, filter, extend } from 'underscore'
import { fetchGrid} from '@/service/getData'
import gridDialog from '@/components/grid-dialog'
import getMinusNumber from "@/mixins/getMinusNumber.js";

import $ from 'jquery'
export default {
  props: ['config'],
  mixins:[getMinusNumber],

  components: {
    gridDialog
  },

  data() {
    return {
      tableData: [],
      pageSize: 10,
      currentPage: 1,
      total: 0,
      dialogUrl: '',
      dialogType: '',
      formDialog: {},
      formSearch: {},
      loading: false,
      searching: false,
    }
  },
  mounted() {
    this.searching = true;
    this.formSearch['pid'] = this.pid;
    this.updateGrid()
    let searchKeys = this.searchKeys
    each(searchKeys, item => this.$set(this.formSearch, item))
     this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".page-load"],
      ".table-container"
    );
  },

  computed: {
    columns() {
      let result = []

      result =  [
     {
      title: '键',
      key: 'name',
      edit: false,

    },
    {
      title: '描述',
      key: 'description',
      edit: true,
      type: TextArea,
    },
    ]
      this.checkIfRenderAction(result)
      return result
    },
    editOptions() {
      return filter(this.config.fields, (item) => {
        item.type || (item.type = 'i-input')
        item.typeConfig || (item.typeConfig = {})
        item.typeConfig.validate || (item.typeConfig.validate = {})
        return item.edit;
      })
    },

    searchKeys() {
      let result = []
      each(this.config.fields, item => {
        if (item.search) {
          result.push(item.key)
        }
      })

      return result
    },

    self() {
      return this
    },


    editUrl() {
      return this.config.editable.url
    },
    // 编辑的主键 id 的映射键
    editKey() {
      return this.config.pk ? this.config.pk : 'id';
    },
    listUrl() {
      return this.config.url
    },
    editKeys() {
      let result = [this.editKey]
      for (let i = 0, options = this.editOptions, length = options.length; i < length; i++) {
        result.push(options[i].key)
      }
      return result
    }

  },
  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 180;
      let minusNumber = this.getMinusNumberOfFixedTable(); 

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");

    },

    // 是否渲染操作按钮，
    checkIfRenderAction(arr) {
      if (this.tableData.length === 0 ||
        (!this.config.editable && !this.config.deletable)
      ) {
        return
      }

      let self = this

      arr.push({
        title: '操作',
        key: 'action',
        width: 250,
        render: function(h, params) {
          return h('div',
            {
              attrs:{
               class:'deleteBtn',
              },
              on: {
                click: () => {
                  self.handleEdit(params.index);
                }
              }
            }, '编辑')
        }
      })

    },

    // 当分页发生改变的时候
    onPageChange(val) {
      this.currentPage = val
      this.updateGrid()
    },

    // 当分页的size发生改变的时候
    onPageSizeChange(val) {
      this.currentPage = 1;
      this.pageSize = val
      this.updateGrid();
      this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".page-load"],
      ".table-container"
    );
    },

    params() {
      // 当在搜索的时候和不搜索的时候给出的params是不一样的
      let searchParams = {}
      if (this.searching) {
        searchParams = JSON.parse(JSON.stringify(this.formSearch))
      }

      return extend({
        rows: this.pageSize,
        page: this.currentPage,
      }, this.config.extraParams, searchParams, this.sort)
    },
    // 更新列表
    updateGrid() {
      this.loading = true
      fetchGrid(this.listUrl, this.params()).then(resp => {
        resp = resp.data
        this.tableData = resp.data
        this.total = resp.total
        this.loading = false
      }, error => {
        this.loading = false
        console.log(error)

      })
    },
    cleanAndUpdateGrid: function() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.updateGrid();
    },
    // 编辑
    handleEdit(index) {
      this.dialogUrl = this.editUrl
      let rowData = this.tableData[index]
      let formDialog = this.formDialog = {}
      each(this.editKeys, key => formDialog[key] = rowData[key])
      if (!this.editUrl) {
        this.$emit('edit', rowData, formDialog)
        return
      }
      this.$emit('before-show-edit', formDialog, rowData)
      this.$refs.dialog.showByEdit(formDialog)
      this.$nextTick(() => {
        this.$emit('after-show-edit', formDialog, rowData)
      })
    },
    // 当编辑和添加成功时候的回调
    onDialogOk() {
      this.updateGrid()
    },
  }
}


</script>

<style scoped lang="less">

.grid-content {
  margin: 5px;
  position: relative;
}

.table-grid {
  margin-top: 5px;
}

.page-load {
  margin: 10px;
  overflow: hidden;
  .float-right {
    float: right;
  }
}

.spin-icon-load {
  animation: ani-spin 1s linear infinite;
}

.loading-text {
  margin: 5px;
  font-size: 16px;
}

@keyframes ani-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}
.pull-right {
  float: right;
  margin: 5px;
}

</style>

