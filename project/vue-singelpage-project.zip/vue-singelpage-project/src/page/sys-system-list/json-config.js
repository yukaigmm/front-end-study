import TextArea from '@/components/inputs/textarea'
import InputJson from '@/components/inputs/input-json'

const getGridConfig = () => {
  return {
    url: '/sys-config',
    
    editable: { // 如果是false或者为空就没有编辑功能
      url: '/sys-config'
    },
    creatable: false,
    fields: [
    {
      title: 'ID',
      key: 'id',
      edit: false,
      hidden: true,
      
    },
    {
      title: '键',
      key: 'name',
      edit: false,
      
    },
    {
      title: '值',
      key: 'value',
      edit: true,
      hidden:true,
      type: InputJson,
      typeConfig: {
        row: 'dialog-form-item-row'
      }
    },
    {
      title: '描述',
      key: 'description',
      edit: true,
      type: TextArea,
      typeConfig: {
        validate: {
          rules: [
            {required: true, message: '请输入登录密码', trigger: 'change, blur'}
          ]
        }
      }
    },
    
    ]
  }
}

export {
  getGridConfig
}
