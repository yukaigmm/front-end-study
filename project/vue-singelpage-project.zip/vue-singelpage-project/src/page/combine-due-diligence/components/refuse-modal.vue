<template>
  <y-modal
    :btnLoading="btnLoading"
    :modal="modal"
    title="请输入备注"
    width="400"
    @ok="ok"
    @cancel="cancel"
  >
    <Form :model="form" :label-width="70" ref="form" :rules="rules">
      <form-item label="备注" prop="remark">
        <i-input
          v-model="form.remark"
          type="textarea"
          placeholder="请输入备注"
          :autosize="{minRows:4,maxRows:7}"
        />
      </form-item>
    </Form>
  </y-modal>
</template>


<script>
import moment from "moment";
export default {
  data() {
    return {
      id: "",
      btnLoading: false,
      modal: false,
      form: {},
      rules: { remark: { required: true, message: "备注不能为空" } }
    };
  },

  methods: {
    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.btnLoading = true;
          let params = {
            remark:
              moment().format("YYYY-MM-DD HH:mm:ss") + " " + this.form.remark
          };
          this.$http
            .putWithoutId(`Schedule/booking/${this.id}`, params)
            .then(res => {
              this.btnLoading = false;
              if (res.code === 20000) {
                this.$emit("refresh");
                this.$Message.success("已拒绝该申请！");
                this.cancel();
              } else {
                this.$Message.error(`拒绝失败：${res.msg}`);
              }
            })
            .catch(err => {
              console.error(err);
              this.btnLoading = false;
              this.$Message.error("拒绝失败：网络请求错误！");
            });
        } else {
          this.$Message.error("请按红色文字提示填写内容！");
        }
      });
    },

    cancel() {
      this.modal = false;
      this.form = {};
      this.$refs.form.resetFields();
      this.id = "";
    },

    show(id) {
      this.id = id;
      this.modal = true;
    }
  }
};
</script>

<style lang="less" scoped>
</style>

