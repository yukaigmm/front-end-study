<template>
  <y-modal
    class="people-modal"
    :modal="modal"
    :loading="loading"
    :btnLoading="btnLoading"
    width="400"
    title="选择拜访对象"
    @ok="ok"
    @cancel="cancel"
  >
    <Form :model="form" ref="form" :rules="rules" :label-width="80">
      <form-item label="拜访对象" prop="obj">
        <i-select
          v-model="form.obj"
          filterable
          remote
          placeholder="请输入关键字"
          :loading="objLoading"
          :label="objName"
          :remote-method="remoteMethod"
          clearable
          transfer
        >
          <i-option v-for="item in objList" :key="item.value" :value="item.value">{{item.label}}</i-option>
        </i-select>
      </form-item>
    </Form>
  </y-modal>
</template>

<script>
export default {
  data() {
    return {
      rules: {
        obj: {
          required: true,
          message: "请先选择拜访对象"
        }
      },
      modal: false,
      btnLoading: false,
      form: {},
      objLoading: false,
      objName: "",
      objList: [],
      orgId: "",
      loading: false,
      initData: [],
      basicInfoData: []
    };
  },

  methods: {
    getDefaultList() {
      let params = {
        orgId: this.orgId
      };

      this.getCantacts(params);
    },

    getCantacts(params) {
      this.objLoading = true;

      this.$http
        .get("organization/contact", params)
        .then(res => {
          this.objLoading = false;
          if (res.code === 20000) {
            if (res.data.records.length) {
              this.basicInfoData = JSON.parse(JSON.stringify(res.data.records));
              this.objList = res.data.records.map(item => {
                let orgName = "";
                if (
                  item.bread &&
                  Array.isArray(item.bread) &&
                  item.bread.length
                ) {
                  item.bread.forEach(item => {
                    orgName = orgName + " " + item.title;
                  });
                }
                return {
                  label: item.name + " " + orgName,
                  value: item.id
                };
              });
              this.initData = JSON.parse(JSON.stringify(this.objList));
            } else {
              this.objList = [];
              this.initData = [];
              this.basicInfoData = [];
            }
          } else {
            this.objList = [];
            this.initData = [];
            this.basicInfoData = [];
            this.$Message.error(`获取推荐人数据失败:${res.msg}`);
          }
        })
        .catch(err => {
          this.objLoading = false;
          this.objList = [];
          this.$Message.error("获取推荐人数据失败：网络请求错误！");
        });
    },

    remoteMethod(query) {
      if (!query) {
        this.objList = JSON.parse(JSON.stringify(this.initData));
        return;
      } else {
        let keyword = query.split(" ")[0];
        let data = JSON.parse(JSON.stringify(this.initData));
        this.objList = data.filter(item => {
          return item.label.includes(keyword);
        });
      }
    },

    show({ orgId, objName, id }) {
      this.orgId = orgId;
      this.objName = objName;
      let objId = id || null;
      this.$set(this.form, "obj", objId);
      this.getDefaultList();
      this.modal = true;
    },

    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          let data = this.getSelectedData();
          this.$emit("getData", data);
          this.cancel();
        } else {
          this.$Message.warning("请按红色文字提示填写内容！");
        }
      });
    },

    getSelectedData() {
      let data = this.basicInfoData
        .filter(item => {
          return item.id == this.form.obj;
        })
        .map(item => {
          return {
            address: item.address,
            contactsId: item.id,
            name: this.objList[0]["label"],
            post: item.post,
            orgId: item.orgId
          };
        });

      return data || {};
    },

    cancel() {
      this.form = {};
      this.objName = "";
      this.objList = [];
      this.orgId = "";
      this.initData = [];
      this.basicInfoData = [];
      this.modal = false;
    }
  }
};
</script>

<style lang="less" scoped>
</style>


