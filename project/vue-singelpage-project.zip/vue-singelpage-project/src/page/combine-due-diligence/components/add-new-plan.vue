<template>
  <div>
    <y-modal
      :btnLoading="btnLoading"
      :modal="modal"
      :loading="loading"
      title="新增尽调计划"
      width="700"
      @ok="ok"
      @cancel="cancel"
    >
      <Form ref="form" :model="formData" :rules="validateRules" :label-width="90">
        <form-item label="计划标题">
          <span v-if="ifShowTitle">{{planTitle}}</span>
        </form-item>

        <form-item label="拜访人" prop="userId">
          <i-select
            v-model="formData.userId"
            placeholder="请输入关键词"
            filterable
            remote
            transfer
            :loading="visitorLoading"
            :label="visitorName"
            :remote-method="remoteMethod"
            clearable
          >
            <i-option
              v-for="item in visitorList"
              :key="item.value"
              :value="item.value"
            >{{item.label}}</i-option>
          </i-select>
        </form-item>

        <form-item label="拜访对象" prop="contactsId" class="ivu-form-item-required">
          <span>{{visitorObj}}</span>
          <i-button size="small" type="primary" @click="selectObj">选择</i-button>
        </form-item>

        <form-item label="拜访人职位">
          <i-input v-model="formData.position" placeholder="请输入拜访人职位"/>
        </form-item>

        <form-item label="拜访地址">
          <i-input v-model="formData.visitAddress" placeholder="请输入拜访地址"/>
        </form-item>

        <Row>
          <i-col span="12">
            <form-item label="拜访日期" prop="visitDate">
              <Row>
                <i-col span="14">
                  <date-picker
                    type="date"
                    v-model="formData.visitDate"
                    placeholder="日期"
                    transfer
                    clearable
                  />
                </i-col>
                <i-col span="9" :offset="1">
                  <time-picker
                    type="time"
                    v-model="formData.visitTime"
                    placeholder="时间"
                    format="HH:mm"
                    transfer
                    clearable
                  />
                </i-col>
              </Row>
            </form-item>
          </i-col>
          <i-col span="12">
            <form-item label="拜访类别">
              <i-select v-model="formData.visitType" disabled transfer clearable>
                <i-option
                  v-for="(item,index) in visitTypeOption"
                  :key="index"
                  :value="item.value"
                >{{item.name}}</i-option>
              </i-select>
            </form-item>
          </i-col>
        </Row>

        <Row>
          <i-col span="12">
            <form-item label="尽调形式">
              <i-select v-model="formData.visitChannel" transfer clearable>
                <Option
                  v-for="(item,index) in visitChannelOptions"
                  :key="index"
                  :value="item.value"
                >{{item.name}}</Option>
              </i-select>
            </form-item>
          </i-col>
          <i-col span="12">
            <form-item label="计划可见范围">
              <i-select v-model="formData.openLevel" transfer clearable>
                <Option
                  v-for="(item,index) in openLevelOptions"
                  :key="index"
                  :value="item.value"
                >{{item.name}}</Option>
              </i-select>
            </form-item>
          </i-col>
        </Row>

        <form-item label="备忘提醒">
          <i-input
            placeholder="请输入备忘提醒"
            v-model="formData.remark"
            type="textarea"
            :autosize="{minRows:2,maxRows:5}"
          />
        </form-item>
      </Form>
    </y-modal>
    <slecct-obj-modal ref="slecctObjModal" @getData="getData"/>

    <choose-visit title="选择拜访对象" ref="chooseVisit" @confirmVisitTarget="confirmVisitTarget"/>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import SlecctObjModal from "./select-obj-modal.vue";
import ChooseVisit from "../../visit-record-manager/choose-visit-target";

import moment from "moment";

export default {
  components: {
    SlecctObjModal,
    ChooseVisit
  },

  data() {
    const validateContactsId = (rules, value, cb) => {
      let errors = [];
      if (!this.formData.contactsId) {
        errors.push(new Error("拜访对象不能为空"));
      } else {
        errors = [];
      }

      cb(errors);
    };

    return {
      formData: {
        contactsId: "",
        orgId: "",
        position: "",
        visitTime: "",
        visitDate: "",
        visitType: "3",
        visitAddress: "",
        visitChannel: 2,
        openLevel: 1,
        userId: "",
        remark: ""
      },
      visitorObj: "",
      validateRules: {
        userId: [{ required: true, message: "必填" }],
        date: [
          {
            required: true,
            type: "date",
            message: "必选"
          }
        ],

        contactsId: {
          validator: validateContactsId
        }
      },
      modal: false,
      loading: false,
      btnLoading: false,
      visitorName: "",
      visitorLoading: false,
      visitorList: [],
      visitChannelOptions: [
        { name: "电话尽调", value: 1 },
        { name: "实地尽调", value: 2 },
        { name: "待定", value: -1 }
      ],
      openLevelOptions: [
        { name: "仅公司内部可见", value: 1 },
        { name: "公司内部+组合大师可见", value: 2 }
      ],
      initOrgId: ""
    };
  },

  computed: {
    ...mapGetters({
      userInfo: "getUser",
      enums: "getEnums"
    }),

    visitTypeOption() {
      return this.enums.c_visit_type;
    },

    ifShowTitle() {
      return this.formData.visitTime && this.visitorObj;
    },

    planTitle() {
      return (
        moment(this.formData.visitTime).format("HH:mm") + " " + this.visitorObj
      );
    }
  },

  methods: {
    selectObj() {
      if (this.initOrgId) {
        let data = {
          orgId: this.initOrgId,
          objName: this.visitorObj,
          id: this.formData.contactsId
        };
        this.$refs.slecctObjModal.show(data);
      } else {
        this.$refs.chooseVisit.show();
      }
    },

    // 拜访人搜索
    remoteMethod(query) {
      if (!query) {
        this.visitorList = [];
        return;
      } else {
        this.visitorLoading = true;
        let params = {
          name: query,
          ifCancelRequest: true
        };

        this.$http
          .get("accounts/getAccountByName", params)
          .then(res => {
            this.visitorLoading = false;
            if (res.code === 20000) {
              if (res.data.length) {
                this.visitorList = res.data.map(item => {
                  return {
                    label: item.linkman,
                    value: item.id
                  };
                });
              } else {
                this.visitorList = [];
              }
            } else {
              this.visitorList = [];
              this.$Message.error(`获取推荐人数据失败:${res.msg}`);
            }
          })
          .catch(err => {
            if (err !== "canceled") {
              this.visitorLoading = false;
              this.visitorList = [];
              this.$Message.error("获取推荐人数据失败：网络请求错误！");
            }
          });
      }
    },

    show({ bookingId, orgId, visitChannel, visitTime, visitDate }) {
      this.initOrgId = orgId;
      this.$set(this.formData, "userId", this.userInfo.id);
      this.visitorName = this.userInfo.trueName || this.userInfo.userName;
      this.$set(this.formData, "bookingId", bookingId);
      this.$set(this.formData, "orgId", orgId);
      this.$set(this.formData, "visitChannel", visitChannel);
      if (visitTime) {
        this.$set(this.formData, "visitTime", visitTime);
      } else {
        this.$set(this.formData, "visitTime", "08:00");
      }
      this.$set(this.formData, "visitDate", visitDate);
      this.modal = true;
    },

    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.submit();
        } else {
          this.$Message.warning("请按红色文字提示填写内容！");
        }
      });
    },

    submit() {
      this.btnLoading = true;

      let params = JSON.parse(JSON.stringify(this.formData));

      if (params.visitDate) {
        params.visitDate = moment(params.visitDate).format("YYYY-MM-DD");
      }

      if (params.visitTime) {
        params.visitTime = moment(params.visitTime).format("HH:mm");
      }

      params.remark = `${params.remark} ${moment().format(
        "YYYY-MM-DD HH:mm:ss"
      )} ${this.userInfo.trueName || this.userInfo.userName}同意该申请`;

      this.$http
        .post(`Schedule/booking/${this.formData.bookingId}`, params)
        .then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.$emit("refresh");
            this.$Message.success("审批已通过！");
            this.cancel();
          } else {
            this.$Message.error(`审批失败：${res.msg}`);
          }
        })
        .catch(err => {
          this.btnLoading = false;
          this.$Message.error("审批失败：网络请求错误！");
        });
    },

    cancel() {
      this.formData = {
        contactsId: "",
        orgId: "",
        position: "",
        visitTime: "",
        visitDate: "",
        visitType: "3",
        visitAddress: "",
        visitChannel: 2,
        openLevel: 1,
        userId: "",
        remark: ""
      };
      this.visitorObj = "";
      this.loading = false;
      this.btnLoading = false;
      this.visitArray = "";
      this.visitorList = [];
      this.initOrgId = "";
      this.visitorName = "";
      this.$refs.form.resetFields();
      this.modal = false;
    },

    getData(data) {
      let selectedData = data[0];
      this.$set(this.formData, "visitAddress", selectedData.address);
      this.visitorObj = selectedData.name;
      this.$set(this.formData, "position", selectedData.post);
      this.$set(this.formData, "contactsId", selectedData.contactsId);
      this.$set(this.formData, "orgId", selectedData.orgId);
      this.$refs.form.validateField("contactsId");
      this.loading = true;
      this.validateOrgRepeat(this.formData.orgId).then(repeatVisit => {
        this.loading = false;
        if (repeatVisit.length) {
          this.noticeRepeat(repeatVisit);
          return;
        }
      });
    },

    confirmVisitTarget(person) {
      this.loading = true;
      this.$set(this.formData, "position", person.position);
      this.$set(this.formData, "contactsId", person.id);
      this.$set(this.formData, "orgId", person.org_id);
      this.$refs.form.validateField("contactsId");
      this.getOrgInfo(person.org_id)
        .then(data => {
          let bread = data.bread || [];
          let info = data.info || {};
          let orgNameArr = bread.map(item => {
            return item.title;
          });
          this.visitorObj = person.title + " " + orgNameArr.join(" ");
          this.$set(
            this.formData,
            "visitAddress",
            info.address || info.areaInfo
          );
          this.validateOrgRepeat(this.formData.orgId).then(repeatVisit => {
            this.loading = false;
            if (repeatVisit.length) {
              this.noticeRepeat(repeatVisit);
              return;
            }
          });
        })
        .catch(err => {
          this.loading = false;
          this.$Message.error("获取人物信息失败！");
        });
    },

    // 根据拜访机构id获取机构的名称面包屑和其他信息
    getOrgInfo(orgId) {
      return new Promise((resolve, reject) => {
        let params = {
          showBread: 1,
          showContacts: 0
        };
        this.loading = true;
        this.$http
          .get(`orgDocument/orgOtherInfo/${orgId}`, params)
          .then(res => {
            this.loading = false;
            if (res.code === 20000) {
              resolve(res.data);
            } else {
              reject(res);
            }
          });
      });
    },

    // 验证尽调机构前后一个月是否有相同的机构，如果有的话，关闭用户添加的modal,并提示相关的尽调信息
    validateOrgRepeat(orgId) {
      return new Promise((resolve, reject) => {
        this.getSectionRecords().then(sectionRecords => {
          let repeatVisit = [];
          for (let record of sectionRecords) {
            record.visitArray.forEach(item => {
              if (item.orgId == orgId) {
                repeatVisit.push(item);
              }
            });
          }
          resolve(repeatVisit);
        });
      });
    },

    // 获取某个区间段里面的尽调记录
    getSectionRecords() {
      return new Promise((resolve, reject) => {
        let params = {
          dateSection: this.getDateSection()
        };
        this.$http.get(`Schedule/section`, params).then(res => {
          if (res.code === 20000) {
            resolve(res.data);
          } else {
            this.$Message.error(res.msg);
          }
        });
      });
    },

    // 获取前后一个月的时间区间
    getDateSection() {
      let startDay = moment()
        .subtract(1, "M")
        .format("YYYY-MM-DD");
      let endDay = moment()
        .add(1, "M")
        .format("YYYY-MM-DD");
      return [startDay, endDay];
    },

    // 提示用户有相同的尽调记录并关闭 modal
    noticeRepeat(repeatVisit) {
      let content;
      if (repeatVisit.length > 1) {
        let dateArr = [];
        for (let item of repeatVisit) {
          dateArr.push(item.visitDate);
        }
        content = `一个月内存在多条相同公司的尽调记录，日期为${dateArr.join(
          "，"
        )}`;
      } else {
        let record = repeatVisit[0];
        if (
          moment(record.visitDate).isAfter() ||
          moment(record.visitDate).isSame(moment())
          // new Date(this.formateIeDate(record.visitDate)).getTime() >= Date.now()
        ) {
          content = `${record.creatorName || "--"} 计划于 ${
            record.visitDate
          } 尽调该公司，可联系${record.creatorName ||
            "--"}参与，不可重复创建尽调计划`;
        } else {
          content = `${record.creatorName || "--"} 已经于 ${
            record.visitDate
          } 尽调了该公司，一个月内不可再重复尽调`;
        }
      }
      this.$Modal.warning({
        title: "提示",
        content: content,
        onOk: () => {
          this.cancel();
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
</style>

