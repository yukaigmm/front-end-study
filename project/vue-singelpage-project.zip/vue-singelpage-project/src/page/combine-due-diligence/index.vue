<template>
  <div>
    <common-index-page
      ref="commonIndexPage"
      :current-page="currentPage"
      :total="total"
      :page-size="pageSize"
      :table-loading="tableLoading"
      :table-data="tableData"
      :show-action="false"
      :table-config="tableConfig"
      @search="search"
      @onPageChange="onPageChange"
      @onPageSizeChange="onPageSizeChange"
    >
      <div slot="search-default">
        <Row>
          <i-col span="8">
            <form-item label="审批状态">
              <i-select v-model="searchData.bookingStatus" transfer clearable placeholder="请选择审批状态">
                <i-option
                  v-for="item in statusOptions"
                  :value="item.value"
                  :key="item.value"
                >{{item.label}}</i-option>
              </i-select>
            </form-item>
          </i-col>

          <i-col span="8">
            <form-item label="拜访日期">
              <date-picker
                style="width:100%;"
                transfer
                clearable
                placeholder="请选择拜访日期"
                v-model="searchData.visitDate"
              />
            </form-item>
          </i-col>

          <i-col span="8" style="padding-left:15px;">
            <i-button type="primary" @click="search">搜索</i-button>
            <i-button @click="reset">重置</i-button>
          </i-col>
        </Row>
        <Row>
          <i-col span="8">
            <form-item label="拜访公司">
              <i-input v-model.trim="searchData.keyword" placeholder="请输入拜访公司名称/id"/>
            </form-item>
          </i-col>
        </Row>
      </div>
    </common-index-page>

    <add-new-plan-modal ref="addNewPlanModal" @refresh="search"/>

    <refuse-modal ref="refuseModal" @refresh="search"/>

    <add-plan-modal ref="addPlanModal"/>
  </div>
</template>

<script>
import CommonIndexPage from "../../components/common-index-page.vue";
import AddNewPlanModal from "./components/add-new-plan.vue";
import RefuseModal from "./components/refuse-modal.vue";
import AddPlanModal from "../due-diligence/add-plan-modal.vue";
import moment from "moment";

export default {
  components: {
    CommonIndexPage,
    AddNewPlanModal,
    RefuseModal,
    AddPlanModal
  },

  data() {
    return {
      currentPage: 1,
      total: 0,
      pageSize: 10,
      tableLoading: false,
      tableData: [],
      statusOptions: [
        {
          label: "待审批",
          value: 1
        },
        {
          label: "已通过",
          value: 3
        },
        {
          label: "已拒绝",
          value: 2
        }
      ],
      searchData: {},
      tableConfig: {
        columns: [
          {
            title: "申请人",
            key: "realName",
            width: 90,
            ellipsis: true,
            render(h, { row }) {
              return h(
                "span",
                {
                  attrs: {
                    title: row.realName
                  }
                },
                row.realName || "--"
              );
            }
          },
          {
            title: "申请人公司",
            key: "orgName",
            width:180,
            ellipsis: true,
            render(h, { row }) {
              return h(
                "span",
                {
                  attrs: {
                    title: row.orgName
                  }
                },
                row.orgName || "--"
              );
            }
          },
          {
            title: "申请人电话",
            key: "accountNo",
            width: 120,
            ellipsis: true,
            render(h, { row }) {
              return h(
                "span",
                {
                  attrs: {
                    title: row.accountNo
                  }
                },
                row.accountNo || "--"
              );
            }
          },
          {
            title: "拟拜访日期",
            key: "visitDate",
            width: 160,
            ellipsis: true,
            render(h, { row }) {
              return h(
                "span",
                {
                  attrs: {
                    title: row.visitDate + " " + row.visitTime
                  }
                },
                row.visitDate + " " + row.visitTime || "--"
              );
            }
          },
          {
            title: "拟拜访公司",
            width:180,
            key: "companyName",
            ellipsis: true,
            render(h, { row }) {
              return h(
                "span",
                {
                  attrs: {
                    title: row.companyName
                  }
                },
                row.companyName || "--"
              );
            }
          },
          {
            title: "尽调形式",
            key: "visitChannel",
            width: 90,
            ellipsis: true,
            render(h, { row }) {
              let mapping = {
                "1": "电话尽调",
                "2": "实地尽调"
              };
              return h( 
                "span",
                {
                  attrs: {
                    title: mapping[row.visitChannel]
                  }
                },
                mapping[row.visitChannel] || "--"
              );
            }
          },
          {
            title: "申请状态",
            key: "bookingStatus",
            width: 90,
            ellipsis: true,
            render(h, { row }) {
              let mapping = {
                "1": "待审批",
                "2": "已拒绝",
                "3": "已通过"
              };
              return h(
                "span",
                {
                  attrs: {
                    title: mapping[row.bookingStatus]
                  }
                },
                mapping[row.bookingStatus] || "--"
              );
            }
          },
          {
            title: "审批人",
            key: "linkman",
            width: 90,
            ellipsis: true,
            render(h, { row }) {
              return h(
                "span",
                {
                  attrs: {
                    title: row.linkman
                  }
                },
                row.linkman || "--"
              );
            }
          },
          {
            title: "审批意见",
            key: "remark",
            width: 200,
            ellipsis: true,
            render(h, { row }) {
              return h(
                "span",
                {
                  attrs: {
                    title: row.remark
                  }
                },
                row.remark || "--"
              );
            }
          },
          {
            title: "操作",
            key: "action",
            width: 120,
            render: (h, { row }) => {
              if (row.bookingStatus == "1") {
                return h("div", [
                  h(
                    "div",
                    {
                      attrs: {
                        class: "deleteBtn"
                      },
                      on: {
                        click: () => {
                          let data = {
                            bookingId: row.bookingId,
                            orgId: row.orgId,
                            visitChannel: row.visitChannel,
                            visitTime: row.visitTime
                              ? row.visitTime.slice(0, 5)
                              : "",
                            visitDate: row.visitDate
                          };
                          this.$refs.addNewPlanModal.show(data);
                        }
                      }
                    },
                    "同意"
                  ),
                  h(
                    "div",
                    {
                      attrs: {
                        class: "deleteBtn"
                      },

                      on: {
                        click: () => {
                          this.refuse(row.bookingId);
                        }
                      }
                    },
                    "拒绝"
                  )
                ]);
              } else if (row.bookingStatus == "3") {
                return h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    on: {
                      click: () => {
                        this.$refs.addPlanModal.show(
                          "edit",
                          { visitor: row.linkman },
                          row.visitId
                        );
                      }
                    }
                  },
                  "查看"
                );
              } else {
                return h(
                  "span",
                  {
                    attrs: {
                      class: "disabledBtn"
                    }
                  },
                  "已拒绝"
                );
              }
            }
          }
        ]
      }
    };
  },

  mounted() {
    this.$refs.commonIndexPage.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".page-load"],
      ".table-area",
      120,
      false
    );
    this.getScheduleList();
  },

  methods: {
    search() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getScheduleList();
    },

    reset() {
      this.searchData = {};
      this.search();
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getScheduleList();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getScheduleList();
    },

    getScheduleList() {
      let params = {
        pageNo: this.currentPage,
        pageSize: this.pageSize,
        ...this.searchData
      };

      if (params.visitDate) {
        params.visitDate = moment(params.visitDate).format("YYYY-MM-DD");
      }
      this.tableLoading = true;
      this.$http
        .get("Schedule/booking", params)
        .then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
          } else {
            this.$Message.error(`获取列表数据失败：${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.tableLoading = false;
          this.$Message.error("获取列表数据失败：网络请求错误！");
        });
    },

    refuse(id) {
      this.$refs.refuseModal.show(id);
    }
  }
};
</script>


<style lang="less" scoped>
</style>
