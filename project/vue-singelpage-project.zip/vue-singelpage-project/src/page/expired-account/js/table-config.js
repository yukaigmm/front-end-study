const dataMapping = {
  visiting_card_url: "visitingCardUrl",
  name: "name",
  post: "post",
  telephone: "telephone",
  weichat: "weichat",
  contacts_type: "contactsType",
  email: "email",
  sex: "sex",
  age: "age",
  org_name: "topName",
  bread: "bread",
  portrait: "portrait",
  company_id: "companyId",
  org_id: "orgId",
  crm_user_id: "crmUserId"
}

const generateTableConfig = function () {
  return {
    columns: [{
        title: "姓名",
        key: "name",
        width: 90,
        render(h, {
          row
        }) {
          return h("span", row.name || "--")
        },
      },
      {
        title: "手机",
        key: "telephone",
        width: 100,
        render(h, {
          row
        }) {
          return h("span", row.telephone || "--")
        }
      },
      {
        title: "公司",
        key: "company",
        width: 300,
        render: (h, {
          row
        }) => {
          if (row.bread && row.bread.length) {
            let companyInfo = row.bread[1] || {};

            if (!companyInfo.id) {
              return h("span", "--");
            }

            let tab = {
              activeName: companyInfo.title,
              pid: companyInfo.id,
              name: `${companyInfo.title}${companyInfo.id}`,
              component: "departmentDetails",
              isShow: true
            };
            return h(
              "a", {
                attrs: {
                  title: "点击查看详情"
                },
                on: {
                  click: e => {
                    this.$store.dispatch("setTabs", tab);
                    e.stopPropagation();
                  }
                }
              },
              companyInfo.title || "--"
            );
          } else {
            let tab = {
              activeName: row.topName,
              pid: row.topId,
              name: `${row.topName}${row.topId}`,
              component: "departmentDetails",
              isShow: true
            };
            return h(
              "a", {
                attrs: {
                  title: "点击查看详情"
                },
                on: {
                  click: e => {
                    this.$store.dispatch("setTabs", tab);
                    e.stopPropagation();
                  }
                }
              },
              row.topName || "--"
            );
          }
        }
      },
      {
        title: "部门",
        key: "departmentName",
        width: 200,
        render: (h, {
          row
        }) => {
          if (row.bread && row.bread.length) {
            return h(
              "div",
              row.bread
              .map((bread, index, breads) => {
                return h(
                  "a", {
                    attrs: {
                      title: "点击查看详情"
                    },
                    on: {
                      click: e => {
                        let tab = {
                          activeName: bread.title,
                          pid: bread.id,
                          name: `${bread.title}${bread.id}`,
                          component: "departmentDetails",
                          isShow: true
                        };

                        this.$store.dispatch("setTabs", tab);
                        e.stopPropagation();
                      }
                    }
                  },
                  index === breads.length - 1 ?
                  `${bread.title}` :
                  `${bread.title}>`
                );
              })
              .splice(2)
            );
          } else {
            return h("span", "总部");
          }
        }
      },
      {
        title: "职务",
        key: "post",
        width: 120,
        render(h, {
          row
        }) {
          return h("span", row.post || "--");
        }
      },
      {
        title: "名片"
      },
      {
        title: "是否付费",
        key: "payingFlag",
        width: 80,
        render: (h, {
          row
        }) => {
          let matchItem = this.paymentOptions.filter(item => item.value === row.payingFlag);
          let text = matchItem.length ? matchItem[0]["label"] : "";
          return h("span", text || "--")
        }
      },
      {
        title: "账号开始日期",
        key: "startDate",
        width: 110,
        render(h, {
          row
        }) {
          return h("span", row.startDate ? row.startDate.substr(0, 11) : "" || "--");
        }
      },
      {
        title: "账号结束日期",
        key: "endDate",
        width: 110,
        render(h, {
          row
        }) {
          return h("span", row.endDate ? row.endDate.substr(0, 11) : "" || "--");
        }
      },
      {
        title: "推荐人",
        key: "recommenderName",
        width: 100,
        render(h, {
          row
        }) {
          return h("span", row.recommenderName || "--");
        }
      },
      {
        title: "总负责人",
        width: 120,
        key: "manager",
        render: (h, {
          row
        }) => {
          let companyToManagerMapping = {
            "1": "张朝晖/刘彬",
            "14": "林丽",
            "17": "林丽",
            "18": "林丽",
          }

          if (row.companyType) {
            return h("span", companyToManagerMapping[row.companyType] || "张一轩");
          } else {
            return h("span", "--")
          }
        }
      },
      {
        title: "操作",
        width: 120,
        fixed: "right",
        render: (h, {
          row
        }) => {
          return h("div", [
            h("div", {
              attrs: {
                class: "deleteBtn"
              },
              on: {
                click: () => {
                  let data = {};
                  for (let key in dataMapping) {
                    data[key] = row[dataMapping[key]];
                  }


                  this.disableAccount(data,row);
                }
              }
            }, "停用"),
            h("div", {
              attrs: {
                class: "deleteBtn"
              },
              on: {
                click: () => {
                  this.delayAccount(row.companyId);
                }
              }
            }, "延期"),
          ])
        }
      }
    ]
  }


}


export default generateTableConfig;
