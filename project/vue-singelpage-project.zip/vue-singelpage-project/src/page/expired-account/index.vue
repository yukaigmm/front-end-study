<template>
  <common-index-page
    @search="search"
    @onPageChange="onPageChange"
    @onPageSizeChange="onPageSizeChange"
    :searchConfig="searchConfig"
    ref="commonIndexPage"
    :tableData="tableData"
    :tableLoading="tableLoading"
    :tableConfig="tableConfig"
    :currentPage="currentPage"
    :total="total"
    :pageSize="pageSize"
  >
    <Row slot="search-default">
      <i-col span="8">
        <form-item label="联系人信息">
          <i-input placeholder="姓名/电话/职务/邮箱" v-model.trim="searchData.userKeyword"/>
        </form-item>
      </i-col>

      <i-col span="8" :offset="1">
        <form-item label="公司信息">
          <i-input v-model.trim="searchData.topName" placeholder="请输入公司名称"/>
        </form-item>
      </i-col>

      <i-col span="7" style="padding-left:15px;">
        <i-button type="primary" @click="search">搜索</i-button>
        <i-button @click="reset">重置</i-button>
      </i-col>

      <i-col span="8">
        <form-item label="开始日期">
          <date-picker
            transfer
            clearable
            style="width:100%;"
            v-model="searchData.startTime"
            placeholder="请选择开始日期"
          />
        </form-item>
      </i-col>

      <i-col span="8" :offset="1">
        <form-item label="结束日期">
          <date-picker
            transfer
            clearable
            style="width:100%;"
            v-model="searchData.endTime"
            placeholder="请选择结束日期"
          />
        </form-item>
      </i-col>

      <i-col span="8">
        <form-item label="推荐人">
          <i-input v-model.trim="searchData.recommenderName" placeholder="请输入推荐人姓名"/>
        </form-item>
      </i-col>
      <i-col span="8" :offset="1">
        <form-item label="是否付费">
          <i-select transfer clearable v-model="searchData.payingFlag" placeholder="请选择是否付费">
            <i-option
              v-for="item in paymentOptions "
              :key="item.value"
              :value="item.value"
            >{{item.label}}</i-option>
          </i-select>
        </form-item>
      </i-col>
      <i-col span="8">
        <form-item label="总负责人">
          <i-select transfer clearable v-model="searchData.topManager" placeholder="请选择是否付费">
            <i-option
              v-for="item in managerOptions "
              :key="item.value"
              :value="item.value"
            >{{item.label}}</i-option>
          </i-select>
        </form-item>
      </i-col>
    </Row>

    <fund-link-config-modal ref="fundLinkConfigModal" @refreshData="search"/>
    <add-account-modal ref="AddAccountModal" @refresh="search"/>
  </common-index-page>
</template>


<script>
import CommonIndexPage from "../../components/common-index-page.vue";
import generateTableConfig from "./js/table-config.js";
import FundLinkConfigModal from "./components/fund-link-config.vue";
import AddAccountModal from "../contact/components/account/add-account-modal.vue";
import moment from "moment";
import { mapGetters } from "vuex";
export default {
  components: {
    CommonIndexPage,
    FundLinkConfigModal,
    AddAccountModal
  },

  props: {
    isIndex: {
      type: Boolean,
      default: false
    }
  },

  computed: {
    ...mapGetters({
      userInfo: "getUser"
    }),

    tableConfig() {
      return generateTableConfig.call(this);
    },

    searchConfig() {
      return {
        showExpand: false,
        showSearch: !this.isIndex
      };
    }
  },

  data() {
    return {
      searchData: {
        startTime: moment().format("YYYY-MM-DD"),
        endTime: moment()
          .add("month", 1)
          .format("YYYY-MM-DD")
      },
      tableData: [],
      tableLoading: false,
      currentPage: 1,
      total: 0,
      pageSize: 10,
      paymentOptions: [
        {
          label: "是",
          value: 1
        },
        {
          label: "否",
          value: 0
        }
      ],

      managerOptions: [
        {
          label: "张朝晖/刘彬",
          value: 1
        },
        {
          label: "林丽",
          value: 2
        },
        {
          label: "张一轩",
          value: 3
        }
      ]
    };
  },

  mounted() {
    this.$refs.commonIndexPage.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".page-load"],
      ".table-area",
      120,
      true
    );
    this.getTableData();
  },

  methods: {
    search() {
      this.pageSize = 10;
      this.currentPage = 1;
      this.getTableData();
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getTableData();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getTableData();
    },

    reset() {
      this.searchData = {};
      this.search();
    },

    paramsFormIndex() {
      let trueName = this.userInfo.trueName;
      let data = {};
      if (trueName == "刘彬" || trueName == "张朝晖") {
        data.topManager = 1;
      } else if (trueName == "张一轩") {
        data.topManager = 3;
      } else if (trueName == "林丽") {
        data.topManager = 2;
      } else {
        data.recommender_id = this.userInfo.id;
      }

      return Object.assign(
        {
          pageSize: this.pageSize,
          pageNo: this.currentPage,
          ifCancelRequest: true
        },
        data
      );
    },

    getTableData() {
      this.tableLoading = true;
      let params = {};

      if (this.isIndex) {
        params = this.paramsFormIndex();
      } else {
        params = Object.assign(
          {
            pageSize: this.pageSize,
            pageNo: this.currentPage,
            ifCancelRequest: true
          },
          JSON.parse(JSON.stringify(this.searchData))
        );
      }

      if (params.endTime) {
        params.endTime = moment(params.endTime).format("YYYY-MM-DD");
      }
      if (params.startTime) {
        params.startTime = moment(params.startTime).format("YYYY-MM-DD");
      }

      this.$http
        .get("FlAccount/getFundLinkAccount", params)
        .then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.total = res.data.total;
            this.tableData = res.data.records;
          } else {
            this.$Message.error(`获取数据失败：${res.msg}`);
          }
        })
        .catch(err => {
          this.tableLoading = false;
          if (err == "canceled") {
            console.warn("请求已取消！");
          } else {
            this.$Message.error("获取数据失败：网络请求错误！");
          }
        });
    },

    disableAccount(data, row) {
      let peConfigData = {
        startDate: row.startDate,
        endDate: row.endDate,
        versionType: row.versionType + ""
      };
      this.$refs.AddAccountModal.show(
        data,
        "pe",
        false,
        row.linkId,
        row.recommenderName,
        row.crmUserId,
        peConfigData
      );
    },
    delayAccount(companyId) {
      this.$refs.fundLinkConfigModal.show(companyId);
    }
  }
};
</script>

<style lang="less" scoped>
</style>

