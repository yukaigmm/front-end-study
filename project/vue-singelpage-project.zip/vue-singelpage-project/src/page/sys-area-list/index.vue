<template>
  <div>
  
    <common-grid ref="grid" :pid="pid" :config="config" @click-detail="onClickDetail"></common-grid>
 

  </div>

</template>

<script>
  import commonGrid from './common-grid'
  import { getGridConfig } from './json-config'

  export default{
    data(){
      return {
        config: getGridConfig(),
        pid : 0,
      }
    },

    components: {
      commonGrid
    },
    methods: {
      onClickDetail (id) {
          this.pid = id;
        },
    }
  }
</script>
