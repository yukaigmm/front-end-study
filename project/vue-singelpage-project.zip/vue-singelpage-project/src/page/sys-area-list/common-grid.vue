<template>
  <div class="grid-content">
    <Button icon='ios-arrow-back' size='small' @click="back">返回</Button>

    <div v-loading="loading" element-loading-text="拼命加载中">
      <Table class="table-grid" ref="commontable" border :context="self" :columns="columns" :data="tableData" />

      <div class="page-load">
        <div class="float-right">
          <Page :total="total" placement="top" :current="currentPage" :page-size="pageSize" @on-change="onPageChange" @on-page-size-change="onPageSizeChange" show-elevator show-sizer show-total />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { map, each, filter, extend } from "underscore";
import { fetchGrid } from "@/service/getData";
import $ from "jquery";
import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  props: ["config", "pid"],

  mixins:[getMinusNumber],
  data() {
    return {
      areaCode:[],
      tableData: [],
      pageSize: 10,
      currentPage: 1,
      total: 0,
      formSearch: {},
      loading: false,
      searching: false,
      sort: {},
      p_id: 0
    };
  },
  watch: {
    pid: function(val, oldVal) {
      // 更新表单数据
      this.p_id = val ? val : oldVal;
      this.searching = true;
      this.currentPage = 1;
      this.pageSize = 10;
      this.formSearch["pid"] = val;
      this.updateGrid();
    }
  },
  mounted() {
    this.searching = true;
    this.formSearch["pid"] = this.pid;
    this.updateGrid();
    let searchKeys = this.searchKeys;
    each(searchKeys, item => this.$set(this.formSearch, item));
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".page-load"],
      ".table-grid"
    );
  },

  computed: {
    columns() {
      let result = [];
      result = [
        {
          title: "地区名称",
          key: "area_name",
          render: (h, params) => {
            return h(
              "a",
              {
                on: {
                  click: () => {
                    this.areaCode.push(params.row.area_code);
                    this.areaCode = [...new Set(this.areaCode)];
                    this.emit("click-detail", params.row.area_code);
                  }
                }
              },
              [
                h(
                  "span",
                  [
                    h("span", params.row.area_name),
                    h(
                      "Poptip",
                      {
                        props: {
                          trigger: "hover",
                          content: "点击查看"
                        }
                      },
                      [
                        h("Icon", {
                          props: {
                            type: "information-circled"
                          },
                          style: {
                            color: "#19be6b",
                            marginLeft: "1rem"
                          }
                        })
                      ]
                    )
                  ],
                  {
                    props: {
                      type: "primary",
                      size: "small"
                    }
                  }
                )
              ]
            );
          }
        },
        {
          title: "地区深度",
          key: "deep"
        },
        {
          title: "地区编码",
          key: "area_code"
        }
      ];
      return result;
    },
    searchKeys() {
      let result = [];
      each(this.config.fields, item => {
        if (item.search) {
          result.push(item.key);
        }
      });

      return result;
    },

    self() {
      return this;
    },
    listUrl() {
      return this.config.url;
    }
  },
  methods: {
    back(){
      this.areaCode.pop();
       this.emit("click-detail", this.areaCode.pop());
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 180;
      let minusNumber = this.getMinusNumberOfFixedTable(); 

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");

    },

    // 当分页发生改变的时候
    onPageChange(val) {
      this.currentPage = val;
      this.updateGrid();
    },

    // 当分页的size发生改变的时候
    onPageSizeChange(val) {
      this.currentPage = 1;
      this.pageSize = val;
      this.updateGrid();
      this.setMaxHeightOfFixedTable(
        ".content-body.ivu-col",
        [".page-load"],
        ".table-grid"
      );
    },

    params() {
      // 当在搜索的时候和不搜索的时候给出的params是不一样的
      let searchParams = {};
      if (this.searching) {
        searchParams = JSON.parse(JSON.stringify(this.formSearch));
      }

      return extend(
        {
          rows: this.pageSize,
          page: this.currentPage
        },
        this.config.extraParams,
        searchParams,
        this.sort
      );
    },
    // 更新列表
    updateGrid() {
      this.loading = true;
      fetchGrid(this.listUrl, this.params()).then(
        resp => {
          resp = resp.data;
          this.tableData = resp.data;
          this.total = resp.total;
          this.loading = false;
        },
        error => {
          this.loading = false;
          console.log(error);
        }
      );
    },
    cleanAndUpdateGrid: function() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.updateGrid();
    },

    emit() {
      this.$emit.apply(this, arguments);
    }
  }
};
</script>

<style scoped lang="less">
.grid-content {
  margin: 5px;
  position: relative;
}

.table-grid {
  margin-top: 5px;
}

.page-load {
  margin: 10px;
  overflow: hidden;
  .float-right {
    float: right;
  }
}

.spin-icon-load {
  animation: ani-spin 1s linear infinite;
}

.loading-text {
  margin: 5px;
  font-size: 16px;
}

@keyframes ani-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.search-form-item {
  display: inline-block;
  width: 48%;
}

.search-form-item-button {
  display: inline-block;
  width: 100%;
  text-align: left;
  margin: auto 0;
  margin-left: 0.5rem;
}

.pull-right {
  float: right;
  margin: 5px;
}

.line {
  margin-top: 16px;
  margin-bottom: 6px;
  border-top: 1px solid #e9eaec;
  width: 100%;
}
</style>

