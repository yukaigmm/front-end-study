import TextArea from '@/components/inputs/textarea'

const getGridConfig = () => {
  return {
    url: '/sys-area',
    creatable: false,
    editable: false,
    deletable: false,
    pk: 'area_code',
    fields: [
    {
      title: '地区ID',
      key: 'area_id',
      hidden: true,
    },
    {
      title: '地区名称',
      key: 'area_name',
      edit: true,
      render (row, column, index) {
         return `<a href="javascript:void(0)"><span type="primary" size="small" @click="emit('click-detail', '${row.area_code}')">${row.area_name}  <Poptip trigger="hover" title="提示标题" content="点击查看"><Icon type="information-circled" color="#19be6b" style="margin-left:1rem;"></Icon></Poptip></span><a href="javascript:void(0)">`
      },
      typeConfig: {
        validate: {
          rules: [
            {required: true, message: '请输入地区名称', trigger: 'change, blur'}
          ],

        },
        row: 'dialog-form-item-row'
      }
    },
    {
      title: '地区深度',
      key: 'deep',
    },
    {
      title: '地区编码',
      key: 'area_code',
      edit: true,
    },

    ]
  }
}

export {
  getGridConfig
}
