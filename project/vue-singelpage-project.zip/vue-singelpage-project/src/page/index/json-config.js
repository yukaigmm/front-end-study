const getMenuConfig = () => {
  return [{
      name: `index`,
      title: '首页',
      icon: 'ios-home',
    },
    {
      name: `organizationManager`,
      title: '机构',
      icon: "ios-world-outline",
    },
    // {
    //   name: `contactManager`,
    //   title: '联系人',
    //   icon: 'ios-contact',
    // },
    {
      name: `contactManager`,
      title: '联系人',
      icon: 'ios-contact',
    },
    {
      name: `system`,
      title: '销售管理',
      icon: 'ios-gear',
      children: [{
          name: `promoteBussiness`,
          title: '展业统计',
          icon: 'ios-location-outline',
        },
        {
          name: `orgFullfill`,
          title: '机构补全',
          icon: 'ios-location-outline',
        },
        {
          name: `accountJustify`,
          title: '账号调整',
          icon: 'ios-gear-outline',
        },
        {
          name: `customer`,
          title: '客户',
          icon: 'ios-gear-outline',
        },
        {
          name: `projectSetting`,
          title: '项目管理',
          icon: 'ios-location-outline',
        },
        {
          name: `accountApprove`,
          title: '账号审批',
          icon: 'ios-gear-outline',
        },
        {
          name: `accountGroup`,
          title: '账号分组',
          icon: 'ios-location-outline',
        },
        {
          name: `cloudDisk`,
          title: '云盘中心',
          icon: 'ios-gear-outline',
        }
      ]
    },
    {
      name: `system`,
      title: '尽调管理',
      icon: 'ios-gear',
      children: [{
          name: `dueDiligence`,
          title: '尽调计划',
          icon: 'calendar',
        },
        {
           name:"combineDueDiligence",
           title:"联合尽调审批",
           icon:"checkmark-circled"
        },
        {
          name: `peAssign`,
          title: '私募分配',
          icon: 'ios-location-outline',
        },
        {
          name: `peReassign`,
          title: '私募重新分配',
          icon: 'ios-location-outline',
          role: '尽调',
        },
        {
          name: `peManage`,
          title: '私募管理',
          icon: 'ios-location-outline',
        },
      ]
    },
    {
      name: `system`,
      title: '私募用户管理',
      icon: 'ios-gear',
      children: [{
          name: `fmaccountManager`,
          title: '基金大师账号管理',
          icon: 'ios-location-outline',
        },
        {
          name: `fmCallbackReply`,
          title: '反馈处理',
          icon: 'ios-location-outline',
        },
        {
          name: `probationManage`,
          title: '试用申请',
          icon: 'ios-location-outline',
        },
        {
          name: `chanceFollowUp`,
          title: '机会跟进',
          icon: 'ios-location-outline',
        },
      ]
    },
    {
      name: `shop-manager`,
      title: `直营店管理`,
      icon: `ios-gear`,
      children: [{
          name: 'blueVipApplyManager',
          title: `蓝V申请-组合大师`,
          icon: 'ios-location-outline'
        },
        {
          name: "blueVipAPPApply",
          title: "蓝V申请-APP",
          icon: 'ios-location-outline'
        },
        {
          name: "expiredAccount",
          title: "即将到期账号",
          icon: 'ios-location-outline'
        },
        {
          name: 'batchAddBlueVip',
          title: `批量导入蓝V`,
          icon: 'ios-location-outline'
        },
        // {
        //   name:"storeAssistant",
        //   title:"小助手--对话",
        //   icon:"android-contacts"
        // },
        {
          name: "storeAssistantManager",
          title: "小助手--管理",
          icon: "android-contacts"
        },
        {
          name: "packageConfig",
          title: "套餐配置",
          icon: "settings"
        }

      ]
    },
    {
      name: 'visit-manager',
      title: '拜访',
      icon: 'ios-paper',
      children: [{
          name: `visitRecordManager`,
          title: '拜访记录',
          icon: 'ios-keypad',
        },
        {
          name: `visitRecordView`,
          title: '拜访概览',
          icon: 'ios-color-filter',
        },
        {
          name: `visitPlanPersonal`,
          title: '个人计划',
          icon: 'calendar',
        },
        {
          name: `visitPlanManager`,
          title: '计划列表',
          icon: 'ios-keypad',
        },
        {
          name: `visitPlanView`,
          title: '计划概览',
          icon: 'ios-color-filter',
        },

      ]
    },
    {
      name: `messageManager`,
      title: '消息',
      icon: 'chatbubble-working',
      type: true
    },
    {
      name: `tagManager`,
      title: '标签',
      icon: 'ios-pricetags',
    },
    {
      name: `util`,
      title: '工具',
      icon: 'ios-gear',
      children: [{
          name: `organizationTransfer`,
          title: '机构变更',
          icon: 'ios-location-outline',
        },
        // {
        //   name: `accountRemind`,
        //   title: '账号提醒',
        //   icon: 'ios-location-outline',
        // },
      ]
    },
    {
      name: `system`,
      title: '系统设置',
      icon: 'ios-gear',
      children: [{
          name: `sysAreaList`,
          title: '区域管理',
          icon: 'ios-location-outline',
        },
        {
          name: `sysSystemList`,
          title: '系统设置',
          icon: 'ios-gear-outline',
        },
        {
          name: "rightManager",
          title: "权限管理",
          icon: 'ios-lightbulb-outline',
        }
      ]
    },

  ]
}
export {
  getMenuConfig
}
