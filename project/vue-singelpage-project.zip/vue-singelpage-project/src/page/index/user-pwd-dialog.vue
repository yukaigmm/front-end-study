<template>
  <div>
    <Modal
      width="300"
      v-model="model"
      title="用户密码修改"
      :loading="loading"
      :mask-closable="false"
      ok-text="确认修改"
      @on-ok="ok"
      @on-cancel="cancel"
    >
      <Form ref="formPwd" :model="formPwd" :rules="rulePwd" :label-width="80">
        <Form-item label="原密码" prop="oldpasswd">
          <Input type="password" v-model.trim="formPwd.oldpasswd"/>
        </Form-item>
        <Form-item label="新密码" prop="passwd">
          <Input type="password" v-model.trim="formPwd.passwd"/>
        </Form-item>
        <Form-item label="确认新密码" prop="passwdCheck">
          <Input type="password" v-model.trim="formPwd.passwdCheck"/>
        </Form-item>
      </Form>
    </Modal>
  </div>
</template>
<script>
import { postFormData } from "@/service/getData";

export default {
  props: ["showPwd"],
  data() {
    const validateOldPass = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入原密码"));
      } else {
        if (this.formPwd.passwdCheck !== "") {
          // 对第二个密码框单独验证
          this.$refs.formPwd.validateField("passwd");
        }
        callback();
      }
    };
    const validatePass = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入新密码"));
      } else if (value == this.formPwd.oldpasswd) {
        callback(new Error("原密码与新密码相同"));
      } else {
        if (this.formPwd.passwdCheck !== "") {
          // 对第二个密码框单独验证
          this.$refs.formPwd.validateField("passwdCheck");
        }
        callback();
      }
    };
    const validatePassCheck = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (value !== this.formPwd.passwd) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };

    return {
      loading: true,
      model: false,
      url: "user/changePwd",
      formPwd: {
        oldpasswd: "",
        passwd: "",
        passwdCheck: ""
      },
      rulePwd: {
        oldpasswd: [{ validator: validateOldPass, trigger: "blur" }],
        passwd: [{ validator: validatePass, trigger: "blur" }],
        passwdCheck: [{ validator: validatePassCheck, trigger: "blur" }]
      }
    };
  },
  components: {},
  watch: {
    showPwd(val) {
      this.model = val;
    }
  },
  computed: {},
  methods: {
    ok() {
      this.$refs["formPwd"].validate(valid => {
        if (valid) {
          postFormData(this.url, this.formPwd).then(resp => {
            if (resp.code === 20000) {
              this.$Message.success("修改成功");
              this.cancel();
            } else {
              this.loading = false;
              this.$Message.error(resp.msg);
            }
          });
        } else {
          this.$Message.error("表单验证失败!");
          this.loading = false;
        }
      });
    },
    cancel() {
      this.$refs["formPwd"].resetFields();
      this.$emit("on-change-pwd");
    }
  }
};
</script>
<style scoped lang="less">
.dialog-form-item {
  display: inline-block;
  width: 330px;
}

.dialog-form-item-row {
  display: inline-block;
  width: 660px;
}
</style>
