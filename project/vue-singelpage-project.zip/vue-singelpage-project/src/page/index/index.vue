<template>
  <div class="index">
    <header class="crm-header">
      <span class="logo">
        <img src="../../assets/logo_index_crm.png">
      </span>
      <Dropdown class="users">
        <span href="javascript:void(0)">
          <span>{{trueName || userName}}, 欢迎你</span>
          <Icon type="arrow-down-b"></Icon>
        </span>

        <Dropdown-menu slot="list">
          <Dropdown-item>
            <Button type="text" size="small" long @click.native="onLogout">注销</Button>
          </Dropdown-item>

          <Dropdown-item>
            <Button type="text" size="small" long @click="onChangeInfo">修改信息</Button>
          </Dropdown-item>

          <Dropdown-item>
            <Button type="text" size="small" long @click="onChangePwd">修改密码</Button>
          </Dropdown-item>
        </Dropdown-menu>
      </Dropdown>
    </header>

    <Row class="crm-container">
      <i-col span="3" class="menu">
        <Menu
          ref="menu"
          width="auto"
          class="el-menu"
          @on-select="onSelect"
          :active-name="activeMenu"
          accordion
        >
          <template v-for="menu in menus">
            <Submenu v-if="menu.children&&menu.ifShow" :name="menu.name" :key="menu.name">
              <template slot="title">
                <Icon :type="menu.icon" size="18"></Icon>
                {{ menu.title }}
              </template>

              <Menu-item
                v-for="item in menu.children"
                :name="item.name"
                :key="item.name"
                v-show="item.ifShow"
              >
                <Icon :type="item.icon" size="18"></Icon>
                {{ item.title }}
              </Menu-item>
            </Submenu>

            <!-- 如果没有子集 -->
            <template v-else>
              <Menu-item v-if="menu.ifShow" :name="menu.name" :key="menu.name">
                <Icon :type="menu.icon" size="18"></Icon>
                {{ menu.title }}
                <Badge :count="messageCount" v-if="menu.type" overflow-count="999"></Badge>
              </Menu-item>
            </template>
          </template>
        </Menu>
      </i-col>

      <i-col span="21" class="content-body">
        <Tabs
          class="tab content-tab"
          type="card"
          closable
          v-model="activeTabOfIndex"
          @on-tab-remove="handleTabRemove"
          @on-click="onTabChange"
          :animated="false"
        >
          <TabPane
            class="tab-pane"
            v-for="tab in tabs "
            :label="tab.activeName"
            :key="tab.name"
            :name="tab.name"
            :closable="tab.closable"
          >
            <component
              v-if="tab.isShow"
              :is="tab.component"
              :pid="tab.pid"
              :ref="tab.name"
              :orgType="tab.orgType"
            ></component>
          </TabPane>
        </Tabs>
      </i-col>
    </Row>

    <store-assistant v-if="isAssistant"/>

    <user-pwd :showPwd="showPwd" @on-change-pwd="onChangePwd"></user-pwd>
    <user-info :showInfo="showInfo" @on-change-info="onChangeInfo"></user-info>
  </div>
</template>
<script>
// 首页
import index from "../welcome-page/welcome.vue";
// 客户详情
import customerDetails from "../customers/components/index.vue";

import { getMenuConfig } from "./json-config";
import userPwd from "./user-pwd-dialog";
import userInfo from "./user-info-dialog";
import { each } from "underscore";
import {
  fetchUser,
  logout,
  fetchSelect,
  getMessageCount
} from "@/service/getData";
import store from "@/store";
import { mapGetters } from "vuex";
import $ from "jquery";
import _ from "lodash";

import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  data() {
    return {
      activeTabOfIndex: "",
      showRouterView: true,
      showPwd: false,
      showInfo: false,
      activeMenu: ""
    };
  },

  mixins: [getMinusNumber],

  mounted() {
    // 设置所有模态框的最大高度
    this.setModalInitMaxHeight();
    // 获取未读消息的数量
    this.$nextTick(() => {
      this.getMessageCount();
    });
    // 默认设置首页menu为选中状态
    this.$nextTick(() => {
      this.updateMenu("index");
    });
  },

  components: {
    userPwd,
    userInfo,
    organizationManager: () => import("../organization-manager/index"),
    // contactManager: () => import("../contact-manager/index"),
    visitRecordManager: () => import("../visit-record-manager/index"),
    visitRecordView: () => import("../visit-record-view/index"),
    visitPlanPersonal: () => import("../visit-plan-personal/index"),
    visitPlanManager: () => import("../visit-plan-manager/index"),
    visitPlanView: () => import("../visit-plan-view/index"),
    messageManager: () => import("../message-manager/index"),
    tagManager: () => import("../tag-manager/index"),
    sysAreaList: () => import("../sys-area-list/index"),
    sysSystemList: () => import("../sys-system-list/index"),
    index,
    departmentDetails: () => import("../department-details/index.vue"),
    orgFullfill: () => import("../organazition-fullfill/index.vue"),
    // customerAssign: () => import("../customers-assign/index"),
    // customerReassign: () => import("../customers-reassign/index"),
    peAssign: () => import("../PE-assign/index"),
    peReassign: () => import("../PE-reassign/index"),
    dueDiligence: () => import("../due-diligence/index.vue"),
    customer: () => import("../customers/index"),
    cloudDisk: () => import("../cloudDisk/index"),
    customerDetails,
    organizationTransfer: () => import("../organization-transfer/index"),
    accountJustify: () => import("../account-justify/index.vue"),
    peManage: () => import("../pe-manage/index.vue"),
    fmaccountManager: () => import("../fm-account-manager/index.vue"),
    projectSetting: () => import("../sale-project-manage/index.vue"),
    accountApprove: () => import("../account-approve/index.vue"),
    promoteBussiness: () => import("../promote-bussiness/index.vue"),
    chanceFollowUp: () => import("../chance-follow-up/index.vue"),
    starButlerMmanager: () => import("../star-butler/index.vue"),
    accountGroup: () => import("../account-group/index.vue"),
    rightManager: () => import("../right-manager/index.vue"),
    contactManager: () => import("../contact/index.vue"),
    fmCallbackReply: () => import("../fm-callback-reply/index.vue"),
    probationManage: () => import("../probation-aplication/index.vue"),
    blueVipApplyManager: () => import("../blueVip-apply-manager/index.vue"),
    batchAddBlueVip: () => import("../batch-add-blue-vip/index.vue"),
    storeAssistant: () => import("../store-assistant/index.vue"),
    packageConfig: () => import("../package-config/index.vue"),
    storeAssistantManager: () => import("../store-assistant-manager/index.vue"),
    blueVipAPPApply: () => import("../blue-vip-app-apply/index.vue"),
    // accountRemind:()=> import("../account-remind/index.vue"),
    combineDueDiligence: () => import("../combine-due-diligence/index.vue"),
    expiredAccount:()=>import("../expired-account/index.vue")
  },

  computed: {
    ...mapGetters({
      user: "getUser",
      trueName: "getTrueName",
      userName: "getUserName",
      messageCount: "getMessageCount",
      tabs: "getTabs",
      activeTab: "getActiveTab"
    }),

    isAssistant() {
      return this.user.auth.functional.includes("isAssistant");
    },

    menus() {
      let allMenu = JSON.parse(JSON.stringify(getMenuConfig()));
      let authMenu = this.user.auth.menu || [];
      let setFlagToMenu = menu => {
        menu.forEach(item => {
          if (authMenu.includes(item.name)) {
            item.ifShow = true;
          } else {
            item.ifShow = false;
          }

          if (item.children) {
            setFlagToMenu(item.children);
          }
        });
      };

      setFlagToMenu(allMenu);

      allMenu = allMenu.map(item => {
        if (item.children) {
          let flag = false;
          item.children.forEach(subItem => {
            if (subItem.ifShow) {
              flag = true;
            }
          });
          item.ifShow = flag;
        }
        return item;
      });

      return allMenu;
    }
  },

  watch: {
    activeTab: {
      handler(val, old) {
        this.activeTabOfIndex = this.activeTab;
      }
    },

    tabs(val) {
      // 获取当前激活的tab组件名称
      let activeComponent = val
        .filter(item => {
          if (item.name == this.activeTab) {
            return item;
          }
        })
        .map(item => {
          return {
            component: item.component,
            name: item.activeName
          };
        });
      let activeMenu = activeComponent[0].component;
      // 如果选中的tab不是menu栏里面的就不选中menu

      this.$nextTick(() => {
        this.updateMenu(activeMenu);
      });
    }
  },

  methods: {
    // 设置所有模态框的初始最大高度
    setModalInitMaxHeight() {
      let minusNumber = this.getMinusNumberOfFixedTable();
      let bodyHeight = $("body").height();
      let modalMaxHeight = bodyHeight * 0.7;
      let styleSheet = document.styleSheets;
      if (!this.isIE()) {
        styleSheet[0].insertRule(
          `.ivu-modal-body{max-height: ${modalMaxHeight}px;}`,
          0
        );
        styleSheet[0].insertRule(`.ivu-modal-body{overflow: auto;}`, 0);
        styleSheet[0].insertRule(
          `.ivu-modal{margin-top: -${bodyHeight * 0.2}px;}`,
          0
        );
        styleSheet[0].insertRule(
          `.ivu-table-body{width: calc(100% + ${minusNumber}px);}`,
          0
        );
      } else {
        styleSheet[0].addRule(
          ".ivu-table-body",
          { width: `calc(100% + ${minusNumber}px);` },
          0
        );
        styleSheet[0].addRule(".ivu-modal-body", { overflow: "auto" }, 0);
        styleSheet[0].addRule(
          ".ivu-modal-body",
          { "max-height": `${modalMaxHeight}px;` },
          0
        );
        styleSheet[0].addRule(
          ".ivu-modal",
          { "margin-top": `-${bodyHeight * 0.2}px;` },
          0
        );
      }
    },

    // tab发生改变时
    onTabChange(val) {
      let activeMenu = this.tabs.filter(item => {
        return item.name == val;
      });
      let activeMenuName = activeMenu[0].component;
      // 更新menu的打开与激活状态
      this.updateMenu(activeMenuName);
      // 设置当前激活的tab栏
      this.$store.dispatch("setActiveTab", { activeTab: val });
    },

    //获取未读消息的数量
    getMessageCount() {
      getMessageCount().then(res => {
        let count = res.data.total;
        this.$store.dispatch("setMessageCount", {
          messageCount: count
        });
      });
    },

    // 移除某个tab时
    handleTabRemove(name) {
      let tabsAfterRemove = this.tabs.filter(item => {
        if (item.name == name) {
          item.isShow = false;
        }
        return item.name == name;
      })[0];

      this.$store.dispatch("closeTab", tabsAfterRemove);
    },

    // 设置组件的name属性
    setTabName(value) {
      let componentChildrenList = [];
      let componentList = this.menus
        .map(item => {
          if (item.children && item.children.length) {
            item.children.forEach(item => {
              componentChildrenList.push({
                component: item.name,
                name: item.title
              });
            });
            return "";
          } else {
            return { component: item.name, name: item.title };
          }
        })
        .concat(componentChildrenList)
        .filter(item => {
          return item != "";
        });
      componentList.forEach(item => {
        if (value.component == item.component) {
          value.name = item.name;
        }
      });
    },

    // 选中某个菜单时，生成tab栏
    onSelect(val) {
      let tabAll = {};
      tabAll.component = val;
      // 返回的val不包含name信息，手动加上
      this.setTabName(tabAll);
      let tab = {
        activeName: tabAll.name,
        name: `${tabAll.name}0`,
        component: tabAll.component,
        isShow: true
      };
      this.$store.dispatch("setTabs", tab);
    },

    // 登出
    onLogout() {
      logout().then(res => {
        if (res.code === 20000) {
          this.$store.dispatch("setTabsAll", [
            {
              // 控制tab的开、关状态
              isShow: true,
              name: "首页0",
              activeName: "首页",
              component: "index",
              closable: false
            }
          ]);
          this.$router.push({ path: "/login" });
        } else {
          this.$Message.error("退出登录失败！");
        }
      });
    },

    // 修改密码
    onChangePwd() {
      this.showPwd = !this.showPwd;
    },

    // 修改个人信息
    onChangeInfo() {
      this.showInfo = !this.showInfo;
    },

    // 更新menu的打开与激活状态
    updateMenu(val) {
      this.$refs.menu.$children.forEach(subMenu => {
        if (subMenu.$options.name === "MenuItem") {
          if (subMenu.$options.propsData.name == val) {
            subMenu.active = true;
            subMenu.opened = true;
          } else {
            subMenu.active = false;
            subMenu.opened = false;
          }
        }
        if (subMenu.$options.name === "Submenu") {
          subMenu.opened = false;
          subMenu.$children.forEach(item => {
            if (item.$options.name === "MenuItem") {
              item.active = false;
              if (item.$options.propsData.name == val) {
                item.active = true;
                subMenu.opened = true;
              }
            }
          });
        }
      });
    }
  }
};
</script>
<style lang="less">
.index {
  height: 100%;
  .ivu-badge {
    position: absolute;
    top: 10px;
    right: 10px;
  }
  .demo-badge {
    width: 42px;
    height: 42px;
    background: transparent;
    border-radius: 6px;
    display: inline-block;
  }
  .users {
    color: #323f38;
    font-weight: bold;
    font-size: 16px;
    position: absolute;
    right: 20px;
    top: 25px;
  }
  .users:hover + .usersMenu {
    display: block;
  }
  .usersMenu:hover {
    display: block;
  }
  .usersMenu {
    color: white;
    background-color: white;
    font-weight: bold;
    font-size: 12px;
    position: absolute;
    right: 20px;
    top: 50px;
    min-width: 100px;
    display: none;
  }
  .usersMenu > .lineMenu {
    border-bottom: 1px solid #e9eaec;
  }
  .crm-header {
    background-color: #3ab2ff;
    height: 60px;
    position: absolute;
    width: 100%;
    z-index: 998;
    top: 0;
    left: 0;
    padding: 0 20px;
    box-sizing: border-box;
  }
  .logo {
    vertical-align: middle;
    text-align: center;
    margin: 0 auto;
  }
  .logo > img {
    vertical-align: middle;
    text-align: center;
    padding-top: 15px;
  }
  .crm-container {
    padding-top: 60px;
    height: 100%;

    .menu {
      height: 100%;
    }

    .content {
      height: 100%;
      overflow-y: auto;
    }

    .el-menu::-webkit-scrollbar {
      width: 0;
    }

    .el-menu {
      height: 100%;
      overflow-y: auto;
      background-color: #eee;

      .ivu-menu {
        background-color: white;
      }
    }

    .content-body {
      height: 100%;
      overflow-y: auto;
      padding-left: 15px;
      padding-right: 15px;
      padding-top: 15px;
      .tab {
        height: 100%;
        .tab-pane {
          height: 100%;
        }
      }
    }
  }
}
</style>
