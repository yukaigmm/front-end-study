<template>
  <div>
    <Modal
      width="300"
      v-model="model"
      title="用户信息修改"
      :loading="loading"
      :mask-closable="false"
      ok-text="确认修改"
      @on-ok="ok"
      @on-cancel="cancel"
    >
      <Form ref="formDatas" :model="formData" :rules="rules" :label-width="80">
        <Form-item label="用户名">
          <Input type="text" disabled :placeholder="this.userName"/>
        </Form-item>
        <Form-item label="昵称" prop="linkman">
          <Input type="text" v-model.trim="formData.linkman" :placeholder="this.userTrueName"/>
        </Form-item>
      </Form>
    </Modal>
  </div>
</template>
<script>
import { postFormData } from "@/service/getData";
import { mapGetters } from "vuex";

export default {
  props: ["showInfo"],
  data() {
    return {
      loading: true,
      model: false,
      url: "user/changeInfo",
      formData: {
        linkman: ""
      },
      rules: {
        linkman: [
          {
            required: false,
            min: 2,
            message: "昵称不得少于2个字",
            trigger: "blur"
          }
        ]
      }
    };
  },
  components: {},
  watch: {
    showInfo(val) {
      this.model = val;
    }
  },
  computed: {
    ...mapGetters({
      userName: "getUserName",
      userTrueName: "getTrueName"
    })
  },
  methods: {
    ok() {
      this.$refs["formDatas"].validate(valid => {
        if (valid) {
          this.loading = true;
          postFormData(this.url, this.formData).then(resp => {
            if (resp.code === 20000) {
              this.$store.dispatch("setTrueName", this.formData.linkman);
              this.$Message.success("修改成功");
              this.cancel();
            } else {
              this.loading = false;
              this.$Message.error(resp.msg);
            }
          });
        } else {
          this.$Message.error("表单验证失败!");
          this.loading = false;
        }
      });
    },
    cancel() {
      this.$refs["formDatas"].resetFields();
      this.$emit("on-change-info");
    }
  }
};
</script>
<style scoped lang="less">
.dialog-form-item {
  display: inline-block;
  width: 330px;
}

.dialog-form-item-row {
  display: inline-block;
  width: 660px;
}
</style>
