<template>
  <div>
    <common-index-page
      @search="search"
      @onPageChange="onPageChange"
      @onPageSizeChange="onPageSizeChange"
      ref="commonIndexPage"
      :tableData="tableData"
      :tableLoading="tableLoading"
      :tableConfig="tableConfig"
      :currentPage="currentPage"
      :total="total"
      :pageSize="pageSize"
    >
      <Row slot="search-default">
        <i-col span="8">
          <form-item label="账号类型">
            <i-select transfer clearable v-model="searchData.accountType" placeholder="请选择账号类型">
              <i-option
                v-for="item in accountTypeOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="8">
          <form-item label="是否有效">
            <i-select transfer clearable v-model="searchData.isValid" placeholder="请选择是否有效">
              <i-option
                v-for="item in isValidOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="8" style="padding-left:15px;">
          <i-button type="primary" @click="search">搜索</i-button>
          <i-button @click="reset">搜索</i-button>
        </i-col>
      </Row>

      <i-button slot="action-area" type="primary" @click="add">添加</i-button>
    </common-index-page>

    <add-remind-modal ref="addRemindModal" />
  </div>
</template>

<script>
import CommonIndexPage from "../../components/common-index-page.vue";
import AddRemindModal from "./components/add-remind-modal.vue";
export default {
  components: {
    CommonIndexPage,
    AddRemindModal
  },

  data() {
    return {
      searchData: {},
      tableConfig: {
        columns: [
          {
            title: "账号类型",
            key: "type"
          },
          {
            title: "操作入口",
            key: "access"
          },
          {
            title: "操作类型",
            key: "oType"
          },
          {
            title: "是否默认发送",
            key: "sendMsg"
          },
          {
            title: "是否有效",
            key: "isValid"
          },
          {
            title: "备注",
            key: "remark"
          },
          {
            title: "短信模板",
            key: "msgTemp"
          },
          {
            title: "操作",
            key: "action",
            render: (h, { row }) => {
              return h("div", [
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    }
                  },
                  "编辑"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    }
                  },
                  "删除"
                )
              ]);
            }
          }
        ]
      },
      tableLoading: false,
      tableData: [
        {
          type: 1
        }
      ],
      currentPage: 1,
      total: 0,
      pageSize: 10,
      accountTypeOptions: [
        {
          value: 1,
          label: "组合大师"
        },
        {
          value: 2,
          label: "基金大师"
        }
      ],
      isValidOptions: [
        {
          value: 1,
          label: "有效"
        },
        {
          value: 2,
          label: "无效"
        }
      ]
    };
  },

  methods: {
    search() {},

    reset() {},

    add() {
        this.$refs.addRemindModal.show();
    },

    onPageChange(page) {},

    onPageSizeChange(pageSize) {}
  }
};
</script>

<style lang="less" scoped>
</style>


