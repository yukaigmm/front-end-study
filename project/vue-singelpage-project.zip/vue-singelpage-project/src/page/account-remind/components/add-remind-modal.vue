<template>
  <y-modal
    :modal="modal"
    title="账号提醒设置"
    :btnLoading="btnLoading"
    :loading="loading"
    width="600"
    @ok="ok"
    @cancel="cancel"
  >
    <Form :model="formData" :rules="validateRules" ref="form" :label-width="90">
      <Row>
        <i-col span="12">
          <form-item label="账号类型">
            <i-select placeholder="请选择账号类型">
              <i-option></i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="12">
          <form-item label="操作场景">
            <i-input placeholder="请输入操作场景"/>
          </form-item>
        </i-col>

        <i-col span="12">
          <form-item label="操作类型">
            <i-input placeholder="请输入操作类型"/>
          </form-item>
        </i-col>

        <i-col span="12">
          <form-item label="是否发送短信">
            <i-select placeholder="请选择是否发送短信" clearable transfer>
              <i-option></i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="24">
          <form-item label="是否有效">
            <i-select placeholder="请选择是否有效" >
              <i-option></i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="24">
          <form-item label="短信模板">
            <i-input placeholder="请输入短信模板" type="textarea" :autosize="{minRows:2,maxRows:5}"/>
          </form-item>
        </i-col>

        <i-col span="24">
          <form-item label="备注">
            <i-input placeholder="请输入备注" type="textarea" :autosize="{minRows:2,maxRows:5}"/>
          </form-item>
        </i-col>
      </Row>
    </Form>
  </y-modal>
</template>

<script>
export default {
  data() {
    return {
      modal: false,
      btnLoading: false,
      loading: false,
      validateRules:{},
      formData:{},
    };
  },

  methods: {
    ok() {},

    cancel() {
      this.modal = false;
    },

    show() {
      this.modal = true;
    }
  }
};
</script>

<style lang="less" scoped>
</style>

