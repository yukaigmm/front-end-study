<template>
  <Modal v-model="modal" title="分配小助手服务人" :mask-closable="false" width="400">
    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button @click="cancel">取消</Button>
      <Button type="primary" @click="ok" :loading="btnLoading">确定</Button>
    </div>

    <Form
      :model="formData"
      :label-width="110"
      :rules="rules"
      ref="form"
      v-loading="loading"
      element-loading-text="拼命加载中"
    >
      <form-item label="小助手服务人员" prop="helperOffId">
        <i-select
          v-model="formData.helperOffId"
          placeholder="请选择小助手服务人员"
          transfer
          clearable
          not-found-text="暂无数据"
        >
          <i-option v-for="item in helperList" :key="item.value" :value="item.value">{{item.label}}</i-option>
        </i-select>
      </form-item>
    </Form>
  </Modal>
</template>


<script>
export default {
  data() {
    return {
      modal: false,
      formData: {},
      rules: {
        helperOffId: {
          required: true,
          message: "小助手服务人员不能为空"
        }
      },
      helperList: [],
      btnLoading: false,
      companyId: "",
      loading: false
    };
  },

  methods: {
    getCurrentAssitant() {
      let param = {
        companyId: this.companyId
      };

      return new Promise(resolve => {
        this.$http
          .get("LittleHelper/getHelperByCompany", param)
          .then(res => {
            resolve();
            if (res.code === 20000) {
              let data = res.data[0];
              if (data) {
                this.formData.helperOffId = data.officialUserId;
              }
            } else {
              this.$Message.error(`获取小助手失败：${res.msg}`);
            }
          })
          .catch(err => {
            console.error(err);
            resolve();
          });
      });
    },

    getHelperList() {
      return new Promise(resolve => {
        this.$http
          .get("LittleHelper/getLittleHelperList", { pageSize: "1000" })
          .then(res => {
            resolve();
            if (res.code === 20000) {
              if (
                res.data.records &&
                Array.isArray(res.data.records) &&
                res.data.records.length
              ) {
                this.helperList =
                  res.data.records.map(item => {
                    return {
                      label: item.crmName || item.crmAccount,
                      value: item.officialUserId
                    };
                  }) || [];
              } else {
                this.helperList = [];
              }
            } else {
              this.$Message.error(`获取小助手列表失败:${res.msg}`);
            }
          })
          .catch(err => {
            resolve();
            this.$Message.error(`获取小助手列表失败：网络请求错误！`);
            console.error(err);
          });
      });
    },

    show(id) {
      this.companyId = id;
      this.loading = true;
      Promise.all([this.getCurrentAssitant(), this.getHelperList()])
        .then(res => {
          this.loading = false;
        })
        .catch(err => {
          console.log(err);
          this.loading = false;
        });

      // this.getCurrentAssitant();
      // this.getHelperList();
      this.modal = true;
    },

    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.submit();
        } else {
          this.$Message.warning("请按红色文字提示填写内容！");
        }
      });
    },

    submit() {
      this.btnLoading = true;
      let params = {
        companyId: this.companyId,
        helperOffId: this.formData.helperOffId
      };

      this.$http
        .post("LittleHelper/allotLittleHelper", params)
        .then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.$Message.success("分配成功！");
            this.cancel();
          } else {
            this.$Message.error(`分配失败:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.$Message.error("分配失败：网络请求错误！");
          this.btnLoading = false;
        });
    },

    cancel() {
      this.modal = false;
      this.formData = {};
      this.btnLoading = false;
      this.$refs.form.resetFields();
    }
  }
};
</script>

<style lang="less" scoped>
</style>

