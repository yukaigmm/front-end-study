<template>
  <Modal v-model="modal" title="小助手账号管理" :mask-closable="false" width="500">
    <div slot="close" @click="close">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button type="primary" @click="close">关闭</Button>
    </div>

    <div class="table-area">
      <Table
        border
        :data="tableData"
        :columns="columns"
        height="240"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
      />
    </div>
  </Modal>
</template>

<script>
export default {
  data() {
    return {
      modal: false,
      tableData: [],
      columns: [
        {
          key: "crmAccount",
          title: "crm账号",
          width: 120
        },
        {
          key: "crmName",
          title: "crm用户名",
          width: 120
        },
          {
          key: "account",
          title: "官网账号",
          width: 120
        },
        {
          key: "action",
          title: "操作",
          width: 120,
          render: (h, { row }) => {
            return h(
              "div",
              {
                attrs: {
                  class: "deleteBtn"
                },
                on: {
                  click: () => {
                    this.$Modal.confirm({
                      title: "解绑小助手",
                      content: "确定解绑小助手？",
                      loading: true,
                      onOk: () => {
                        this.unBindAssistant(row.id);
                      },
                      onCancel: () => {}
                    });
                  }
                }
              },
              "解绑"
            );
          }
        }
      ],
      tableLoading: false
    };
  },

  methods: {
    close() {
      this.modal = false;
      this.tableData = [];
    },

    show() {
      this.modal = true;
      this.getAssitantList();
    },

    unBindAssistant(id) {
      let params = {
        id
      };

      this.$http
        .delByParams(`LittleHelper/cancelLeLittleHelper?id=${id}`)
        .then(res => {
          this.$Modal.remove();
          if (res.code === 20000) {
            this.$Message.success("解绑成功!");
            this.getAssitantList();
          } else {
            this.$Message.error(`解绑失败:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.$Modal.remove();
          this.$Message.error("解绑失败：网络请求错误！");
        });
    },

    getAssitantList() {
      this.tableLoading = true;
      this.$http
        .get("LittleHelper/getLittleHelperList", { pageSize: "1000" })
        .then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records || [];
          } else {
            this.$Message.error(`获取小助手列表失败:${res.msg}`);
          }
        })
        .catch(err => {
          this.tableLoading = false;
          this.$Message.error(`获取小助手列表失败:网络请求错误!`);
          console.error(err);
        });
    }
  }
};
</script>

<style lang="less" scoped>
</style>

