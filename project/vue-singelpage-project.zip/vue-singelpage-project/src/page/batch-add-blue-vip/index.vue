<template>
  <div>
    <search-area
      :show-expand="false"
      @onKeydownSearch="search"
      ref="searchArea"
      class="search-area"
    >
      <div slot="default">
        <Row>
          <i-col span="8">
            <form-item label="导入状态">
              <i-select v-model="searchData.status" clearable>
                <i-option
                  v-for="item in statusOptions"
                  :key="item.value"
                  :value="item.value"
                >{{item.label}}</i-option>
              </i-select>
            </form-item>
          </i-col>

          <i-col span="8">
            <form-item label="导入时间">
              <date-picker
                v-model="searchData.createtime"
                style="width:100%;"
                placeholder="请选择导入时间"
              ></date-picker>
            </form-item>
          </i-col>

          <i-col span="8" style="padding-left:20px;">
            <i-button type="primary" @click="search">搜索</i-button>
            <i-button @click="reset">重置</i-button>
          </i-col>
        </Row>

        <Row>
          <i-col span="8">
            <form-item label="操作人">
              <i-select
                v-model="searchData.creatorid"
                placeholder="请输入关键词"
                filterable
                remote
                transfer
                :loading="loading"
                :remote-method="remoteMethod"
                clearable
              >
                <i-option
                  v-for="item in operatorList"
                  :key="item.value"
                  :value="item.value"
                >{{item.label}}</i-option>
              </i-select>
            </form-item>
          </i-col>
        </Row>
      </div>
    </search-area>

    <div class="action-area">
      <Upload
        ref="upload"
        action="api/blueVip/BatchImportBlueV"
        :show-upload-list="false"
        :before-upload="beforeUpload"
        :on-success="onImportSuccess"
        :on-error="onImportError"
      >
        <i-button type="primary">导入文件</i-button>
      </Upload>

      <span class="template" @click="downloadTemplate" title="点击下载导入模板">(模板下载)</span>
    </div>

    <h3>历史导入结果：</h3>
    <div class="table-area">
      <Table
        :columns="columns"
        :data="tableData"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        border
      />
    </div>

    <div class="page-load">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      />
    </div>
  </div>
</template>

<script>
import SearchArea from "../../components/search-area";
import setMaxHeightToTable from "@/mixins/setMaxHeightToTable.js";
import moment from "moment";
export default {
  components: {
    SearchArea
  },

  mixins: [setMaxHeightToTable],

  data() {
    let commonCellStyle = {
      "text-overflow": "ellipsis",
      overflow: "hidden",
      "white-space": "nowrap"
    };
    return {
      operatorList: [],
      loading: false,
      statusOptions: [
        {
          label: "未处理",
          value: 1
        },
        {
          label: "导入成功",
          value: 2
        },
        {
          label: "导入失败",
          value: 3
        }
      ],
      searchData: {},
      columns: [
        {
          title: "id",
          key: "id",
          fixed: "left",
          width: 80,
          render(h, { row }) {
            return h, row.id || "--";
          }
        },
        {
          title: "姓名",
          key: "realname",
          fixed: "left",
          width: 100,
          render(h, { row }) {
            return h, row.realname || "--";
          }
        },
        {
          title: "电话号码",
          key: "telephone",
          fixed: "left",
          width: 120,
          render(h, { row }) {
            return h("span", row.telephone || "--");
          }
        },
        {
          title: "导入状态",
          key: "status",
          width: 100,
          fixed: "left",
          render(h, { row }) {
            let mapping = {
              "1": "未处理",
              "2": "导入成功",
              "3": "导入失败"
            };

            return h("span", mapping[row.status] || "--");
          }
        },
        {
          title: "导入备注",
          key: "blueVipRemark",
          width: 150,
          render(h, { row }) {
            return h(
              "div",
              {
                style: {
                  "max-width": "140px",
                  ...commonCellStyle
                },
                attrs: {
                  title: row.blueVipRemark
                }
              },
              row.blueVipRemark || "--"
            );
          }
        },
        {
          title: "公司名",
          key: "bvCompanyName",
          width: 200,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  "max-width": "190px",
                  ...commonCellStyle
                },
                attrs: {
                  title: row.bvCompanyName
                }
              },
              row.bvCompanyName || "--"
            );
          }
        },
        {
          title: "部门",
          key: "bvDeptName",
          width: 150,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  "max-width": "140px",
                  ...commonCellStyle
                },
                attrs: {
                  title: row.bvDeptName
                }
              },
              row.bvDeptName || "--"
            );
          }
        },
        {
          title: "职位",
          key: "bvPositionName",
          width: 120,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  "max-width": "110px",
                  ...commonCellStyle
                },
                attrs: {
                  title: row.bvPositionName
                }
              },
              row.bvPositionName || "--"
            );
          }
        },
        {
          title: "蓝V等级",
          key: "bvLevel",
          width: 100,
          render(h, { row }) {
            let statusMapping = {
              "1": "蓝V1",
              "2": "蓝V2",
              "3": "蓝V3"
            };

            return h("span", statusMapping[row.bvLevel] || "--");
          }
        },
        {
          title: "是否付费",
          key: "bvPayment",
          width: 120,
          render(h, { row }) {
            let mapping = {
              "1": "已付费",
              "0": "未付费"
            };
            return h("span", mapping[row.bvPayment] || "--");
          }
        },
        {
          title: "开始时间",
          key: "blueVipTime",
          width: 120,
          render(h, { row }) {
            let text = row.blueVipTime
              ? row.blueVipTime.substring(0, 11)
              : "--";
            return h("span", text);
          }
        },
        {
          title: "结束时间",
          key: "bvExpireTime",
          width: 120,
          render(h, { row }) {
            let text = row.bvExpireTime
              ? row.bvExpireTime.substring(0, 11)
              : "--";
            return h("span", text);
          }
        },

        {
          title: "导入时间",
          key: "createtime",
          width: 150,
          render(h, { row }) {
            let text = row.createtime ? row.createtime : "--";
            return h("span", text);
          }
        },
        {
          title: "推荐人",
          key: "refereeName",
          width: 120,
          render(h, { row }) {
            let text = row.refereeName ? row.refereeName : "--";
            return h("span", text);
          }
        }
      ],
      tableData: [],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  mounted() {
    this.getTableData();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".page-load", ".action-area"],
      ".table-area",
      120,
      true
    );
  },

  methods: {
    downloadTemplate() {
      let Tag = document.createElement("a");
      Tag.setAttribute(
        "href",
        `${window.location.origin}/download/import_blueV.xlsx`
      );
      Tag.setAttribute("target", "_blank");
      document.body.appendChild(Tag);
      Tag.click();
      document.body.removeChild(Tag);
    },

    beforeUpload() {
      this.$refs.upload.clearFiles();
      this.$Message.loading({
        content: "导入中，请稍候...",
        duration: 0
      });
    },

    onImportSuccess(response, file, fileList) {
      this.$Message.destroy();
      if (response.code === 20000) {
        this.$Message.success("导入成功！");
        this.search();
      } else {
        this.$Message.error(`导入失败:${response.msg}`);
      }
    },

    onImportError() {
      this.$Message.destroy();
      this.$Message.error("导入失败:网络请求错误！");
    },

    search() {
      this.pageSize = 10;
      this.currentPage = 1;
      this.getTableData();
    },

    reset() {
      this.searchData = {};
      this.operatorList = [];
      this.search();
    },

    getTableData() {
      let searchData = JSON.parse(JSON.stringify(this.searchData));
      let params = {
        pageSize: this.pageSize,
        pageNo: this.currentPage,
        ...searchData
      };

      if (params.createtime) {
        params.createtime = moment(params.createtime).format("YYYY-MM-DD");
      } else {
        delete params.createtime;
      }

      if (!params.creatorid) {
        delete params.creatorid;
      }

      if (!params.status) {
        delete params.status;
      }
      this.tableLoading = true;
      this.$http
        .get("blueVip/getBatchImportBlueVLog", params)
        .then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
          } else {
            this.$Message.error(`获取列表失败：${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.tableLoading = false;
          this.$Message.error("获取列表失败：网络请求错误！");
        });
    },

    onPageChange(val) {
      this.currentPage = val;
      this.getTableData();
    },

    onPageSizeChange(val) {
      this.pageSize = val;
      this.getTableData();
    },

    remoteMethod(query) {
      if (!query) {
        this.operatorList = [];
        return;
      } else {
        this.loading = true;
        let params = {
          name: query,
          ifCancelRequest: true
        };

        this.$http
          .get("accounts/getAccountByName", params)
          .then(res => {
            this.loading = false;
            if (res.code === 20000) {
              if (res.data.length) {
                this.operatorList = res.data.map(item => {
                  return {
                    label: item.linkman,
                    value: item.id
                  };
                });
              } else {
                this.operatorList = [];
              }
            } else {
              this.operatorList = [];
              this.$Message.error(`获取操作人数据失败:${res.msg}`);
            }
          })
          .catch(err => {
            if (err !== "canceled") {
              this.loading = false;
              this.operatorList = [];
              this.$Message.error("获取操作人数据失败：网络请求错误！");
            }
          });
      }
    }
  }
};
</script>


<style lang="less" scoped>
.action-area {
  margin: 15px 0;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  .template {
    color: rgb(40, 132, 224);
    cursor: pointer;
    margin-left: 5px;
    &:hover {
      text-decoration: underline;
    }
  }
}

.page-load {
  margin: 15px;
  text-align: right;
}
</style>
