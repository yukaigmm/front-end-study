<template>
     <div class="right-manager-wrap">
         <Tabs :animated="false" v-model="activedTab">
             <TabPane 
               v-for="(item,index) in tabs" 
               :key="index"
               :label="item.label"
               :name="item.name"
              >
                   <component :is="item.component"></component>
               </TabPane> 
         </Tabs>
     </div>
</template>

<script>
import userManager from "./components/user/user-manager.vue";
import roleManager from "./components/role/role-manager.vue";
import rightManager from "./components/right/rights-manger.vue";

export default {
  components: {
    userManager,
    roleManager,
    rightManager
  },

  data() {
    return {
      activedTab: "",
      tabs: [
        {
          name: "user",
          component: "userManager",
          label: "用户管理"
        },
        {
          name: "role",
          component: "roleManager",
          label: "角色管理"
        },
        {
          name: "right",
          component: "rightManager",
          label: "权限管理"
        }
      ]
    };
  }
};
</script>

<style lang="less" scoped>
</style>
