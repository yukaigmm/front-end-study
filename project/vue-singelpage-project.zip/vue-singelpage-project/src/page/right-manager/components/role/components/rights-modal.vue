<template>
  <Modal
    v-model="modal"
    title="查看/编辑权限"
    width="800"
    :mask-closable="false"
    class="choose-mutiple-targets"
  >
         <div slot="footer">
            <Button @click="onCancel">取消</Button>
            <Button type="primary" @click="onOk">确定</Button>
       </div>

       <div slot="close" @click="onCancel">
           <Icon type="ios-close-empty"></Icon>
       </div>
      
      <div class="title">
          <span class="label">角色名称:</span>
          <span class="content">{{roleName}}</span>
      </div>

      <transfer-box 
         v-loading="boxLoading"
         element-loading-text="拼命加载中"
         ref="transferBox"
         :orignData="orignData"
         labelKey="title"
         valueKey="value"
         showIcon
         :selectedKeys="rightsList"
      >
         <h5 slot="originTitle">所有权限列表</h5>
         <h5 slot="targetTitle">角色权限列表</h5>
      </transfer-box>

  </Modal>

</template>


<script>

import transferBox from "../../../../../components/transfer-box.vue"
export default {

   components:{
      transferBox
   },

    data(){
        return {
            modal:false,
            orignData:[],
            rightsList:[],
            roleName:"",
            boxLoading:false
        }
    },

    methods:{
        onCancel(){
            this.roleName = '';
            this.modal = false;
            this.$refs.transferBox.clearData();
        },

        onOk(){
            let rows = this.$refs.transferBox.getSelectedRows()|| [];
            this.$emit("getData",rows);
           this.onCancel();
        },

        show(rights,roleName){
            this.modal = true;
            this.roleName = roleName;
            this.rightsList = JSON.parse(JSON.stringify(rights))||[];

            if(!this.orignData.length){
              this.getAllRightList();
            }
        },

        getAllRightList(){
            this.boxLoading = true;
            try{
                this.$http.get("common/getAllGroupsAndRules",{pageSize:1000}).then(res=>{
                    this.boxLoading = false;
                    if(res.code === 20000){
                       this.orignData = 
                       res.data.records.map(item=>{
                           item.value = `${item.type};${item.id}`
                           return item;
                       })
                    }else{
                        this.$Message.error("获取权限列表失败")
                    }
                })
            }catch(e){
                this.boxLoading = false;
                console.error(e);
                 this.$Message.error("获取权限列表失败")
            }
        }
    }
}
</script>

<style lang="less" scoped>
   .title{
       padding:5px 20px;
       .content{
        font-weight: 900;
       }
   }
</style>

