 <template>
  <Modal
    v-model="modal"
    title="查看/编辑权限"
    width="800"
    :mask-closable="false"
    class="choose-mutiple-targets"
  >
         <div slot="footer">
            <Button @click="onCancel">取消</Button>
            <Button type="primary" @click="onOk">确定</Button>
       </div>

       <div slot="close" @click="onCancel">
           <Icon type="ios-close-empty"></Icon>
       </div>
      <div v-loading="modalLoading"  element-loading-text="拼命加载中">

      </div>
      <div class="title">
          <span class="label">角色名称:</span>
          <span class="content">{{roleName}}</span>
      </div>

      <transfer-box 
         v-loading="boxLoading"
         element-loading-text="拼命加载中"
         ref="transferBox"
         :orignData="orignData"
         labelKey="title"
         valueKey="value"
         showIcon
         :selectedKeys="selectedKeys"
      >
         <h5 slot="originTitle">所有权限列表</h5>
         <h5 slot="targetTitle">角色权限列表</h5>
      </transfer-box>

  </Modal>

</template>


<script>
import transferBox from "../../../../../components/transfer-box.vue";
export default {
  components: {
    transferBox
  },

  data() {
    return {
      modal: false,
      orignData: [],
      rightsList: [],
      roleName: "",
      boxLoading: false,
      rightGroupIds: [],
      rightRuleIds: [],
      rightList: [],
      roleId: "",
      modalLoading: false,
      btnLoading: false,
      selectedKeys:[]
    };
  },

  methods: {
    onCancel() {
      this.roleName = "";
      this.modal = false;
      this.roleId = "";
      this.orignData = [];
      this.rightsList = [];
      this.rightGroupIds = [];
      this.rightRuleIds =[];
      this.selectedKeys = [];
      this.$refs.transferBox.clearData();
    },

    onOk() {
      this.btnLoading = true;
      let params = this.getParams();
      this.$http.post("common/updateRole", params).then(res => {
        this.btnLoading = false;
        if (res.code === 20000) {
          this.$Message.success("修改成功！");
          this.onCancel();
          this.$emit("refreshTable")
        } else {
          this.$Message.error("修改失败！");
        }
      });
    },

    show(id, roleName) {
      this.modal = true;
      this.roleName = roleName;
      this.roleId = id;
      this.modalLoading = true;
      Promise.all([this.getRight(), this.getAllRightList()]).then(() => {
        this.modalLoading = false;
      });
    },

    getCheckedRightData() {
      let data = this.$refs.transferBox.getSelectedRows() || [];
      if (data && data.length) {
        this.rightList = data.map(item => ({
          label: item.title,
          value: item.value
        }));
      } else {
        this.rightList = [];
      }
      this.getRightIds();
    },

    getParams() {
      this.getCheckedRightData();
      let params = {};
      params.rules = this.rightRuleIds;
      params.groups = this.rightGroupIds;
      params.roleId = this.roleId;
      params.isRight = 1;
      return params;
    },

    getRightIds() {
      let allRightValue = this.rightList.map(item => item.value);
      let allRights = allRightValue.map(item => {
        let typeArr = item.split(";");
        return {
          type: typeArr[0],
          id: typeArr[1]
        };
      });

      this.rightGroupIds = allRights
        .filter(item => item.type === "group")
        .map(item => {
          return item.id;
        });

      this.rightRuleIds = allRights
        .filter(item => item.type !== "group")
        .map(item => {
          return item.id;
        });
    },

    getRight() {
      return new Promise((resolve, reject) => {
        try {
          let params = {
            roleId: this.roleId
          };
          this.$http.get("common/getRoleGroup", params).then(res => {
            resolve();
            if (res.code === 20000) {
              this.rightGroupIds = res.data.groups.map(item => item.id) || [];
              this.rightRuleIds = res.data.rules.map(item => item.id) || [];
              let groupsTitle =
                res.data.groups.map(item => ({
                  label: item.title,
                  value: `group;${item.id}`
                })) || [];
              let rulesTitle =
                res.data.rules.map(item => ({
                  label: item.title,
                  value: `${item.type};${item.id}`
                })) || [];
              this.rightList = groupsTitle.concat(rulesTitle);
              this.selectedKeys =  this.rightList.map(item=>item.value)
            } else {
              this.$Message.error(`获取权限列表失败:${res.msg}`);
            }
          });
        } catch (e) {
          resolve();
          this.$Message.error(`获取权限列表失败`);
        }
      });
    },

    getAllRightList() {
      return new Promise(resolve => {
        this.boxLoading = true;
        try {
          this.$http
            .get("common/getAllGroupsAndRules", { pageSize: 1000 })
            .then(res => {
              resolve();
              this.boxLoading = false;
              if (res.code === 20000) {
                this.orignData = res.data.records.map(item => {
                  item.value = `${item.type};${item.id}`;
                  return item;
                });
              } else {
                this.$Message.error("获取权限列表失败");
              }
            });
        } catch (e) {
          this.boxLoading = false;
          console.error(e);
          resolve();
          this.$Message.error("获取权限列表失败");
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.title {
  padding: 5px 20px;
  .content {
    font-weight: 900;
  }
}
</style>

