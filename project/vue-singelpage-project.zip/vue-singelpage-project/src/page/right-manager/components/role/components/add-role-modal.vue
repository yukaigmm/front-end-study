<template>
    <Modal
       v-model="modal"
       :title="modalTitle"
       width="600"
       :mask-closable="false"
    >
        <div slot="footer">
            <Button  @click="onCancel">取消</Button>
            <Button type="primary" @click="onOk" :loading="btnLoading">确定</Button>

        </div>
        <div slot="close" @click="onCancel">
            <Icon type="ios-close-empty"></Icon>
        </div>

        <Form 
          :model="formData" 
          ref="form" 
          :rules="validateRules" 
          :label-width="80"
          v-loading="modalLoading"
          element-loading-text="拼命加载中"
           >
            <Row>
                <Col span="12">
                    <FormItem label="角色名称" prop="name">
                        <Input
                           v-model.trim="formData.name"
                           placeholder="请输入角色名称"
                        />
                    </FormItem>
                </Col>

                <Col span="24">
                    <Collapse v-model="panel">
                       <Panel name="user">
                              <span>用户列表</span>
                              <span class="fr" @click.prevent.stop="viewUserList">查看/编辑用户列表</span>
                           
                           <div class="table-area"  slot="content">
                                <Table 
                                  height="200"
                                  :data="userTableData"
                                  :columns="columns"
                                  border
                                  v-loading="tableLoading"
                                  element-loading-text="拼命加载中"
                                />
                           </div>

                       </Panel>

                       <Panel name="right">
                              <span>权限列表</span>
                              <span  class="fr" @click.prevent.stop="viewRightList">查看/编辑权限列表</span>

                          <div class="right-wrap" slot="content">
                              <p class="single-right" v-for="(item,index) in rightList" :key="index">{{item.label}}</p>
                          </div>
                       </Panel>
                    </Collapse>
                </Col>

                <Col span="24" style="margin-top:15px;">
                    <FormItem label="备注" prop='remark' label-position="top">
                        <Input 
                           v-model.trim="formData.remark"
                           type="textarea" 
                           :autosize="{minRows: 4,maxRows: 8}" 
                           placeholder="请输入备注" />
                    </FormItem>
                </Col>
            </Row>
        </Form>
        

        <user-modal ref="userModal"  @getData="getCheckedUserData"></user-modal>
        <rights-modal ref="rightsModal" @getData="getCheckedRightData"></rights-modal>
    </Modal>
</template>


<script>
import userModal from "./user-modal";
import rightsModal from "./rights-modal";
let timer = null;
export default {
  components: {
    userModal,
    rightsModal
  },

  computed: {
    modalTitle() {
      return this.roleId ? "编辑角色" : "新增角色";
    },
    validateRules() {
      const validateRoleIfExist = (rules, value, callback) => {
        let errors = [];
        clearTimeout(timer);
        if (value) {
          let params = {
            id:this.roleId,
            roleName: value
          };
          timer = setTimeout(() => {
            this.$http
              .post("common/checkAuthName", params)
              .then(res => {
                if (res.data.status) {
                  errors.push(new Error("该角色名已被使用！"));
                }
              })
              .then(() => {
                callback(errors);
              });
          }, 400);
        } else {
          callback([]);
        }
      };

      return {
        name: [
          {
            required: true,
            message: "角色名称不能为空"
          },
          {
            validator:validateRoleIfExist,
             trigger:"blur"
          }
        ]
      };
    }
  },
  data() {
    return {
      roleId: "",
      rightGroupIds: [],
      rightRuleIds: [],
      modal: false,
      modalLoading: false,
      formData: {
        name: "",
        remark: "",
        rules: [],
        groups: [],
      },
      userTableData: [],
      columns: [
        {
          title: "账号ID",
          key: "id",
          width: 80,
          render(h,{row}){
            return h("span",row.id||"--")
          }
        },
        {
          title: "账号",
          key: "name",
          width: 110,
           render(h,{row}){
            return h("span",row.name||"--")
          }
        },
        {
          title: "姓名",
          key: "linkman",
          width: 90,
           render(h,{row}){
            return h("span",row.linkman||"--")
          }
        },
        {
          title: "手机",
          key: "mobile",
          width: 100,
           render(h,{row}){
            return h("span",row.mobile||"--")
          }
        },
        {
          title: "所在部门",
          ellipsis: true,
          width: 120,
          render(h, { row }) {
            if (row.detp && row.detp.length) {
              let depts = row.detp.map(item => item.text);
              return h("span", depts.join("/"));
            } else {
              return h("span", "--");
            }
          }
        }
      ],
      panel: "",
      tableLoading: false,
      rightList: [],
      btnLoading: false,
      deleteId: [],
      addId: []
    };
  },

  methods: {
    onOk() {
      this.$refs.form.validate(valid => {
        if (valid) {
          if (this.roleId) {
            this.editRole();
          } else {
            this.addRole();
          }
        } else {
          this.$Message.warning("请按红色字段填写内容！");
        }
      });
    },

    editRole() {
      let params = {
        roleId: this.roleId,
        ...this.getSubmitParams()
      };
      this.btnLoading = true;

      try {
        this.$http.post("common/updateRole", params).then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.$Message.success("编辑成功！");
            this.onCancel();
            this.$emit("refreshTable");
          } else {
            this.$Message.error(`编辑失败:${res.msg}`);
          }
        });
      } catch (e) {
        console.error(e);
        this.btnLoading = false;
        this.$Message.error(`添加失败`);
      }
    },

    getSubmitParams() {
      let formData = JSON.parse(JSON.stringify(this.formData));
      let userId = this.getUserIds();
      formData.rules = this.rightRuleIds;
      formData.groups = this.rightGroupIds;
      return {
        ...formData,
        ...userId
      };
    },

    addRole() {
      let params = {
        ...this.getSubmitParams()
      };
      this.btnLoading = true;
      try {
        this.$http.post("common/addRole", params).then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.$Message.success("添加成功！");
            this.onCancel();
            this.$emit("refreshTable");
          } else {
            this.$Message.error(`添加失败:${res.msg}`);
          }
        });
      } catch (e) {
        console.error(e);
        this.btnLoading = false;
        this.$Message.error(`添加失败`);
      }
    },

    onCancel() {
      this.modal = false;
      this.clearData();
    },

    clearData() {
      this.panel = "";
      this.rightGroupIds = [];
      this.rightRuleIds = [];
      this.userTableData = [];
      this.rightList = [];
      this.roleId = "";
      this.formData = {
        name: "",
        remark: "",
        rules: [],
        groups: [],
      };
      this.$refs.form.resetFields();
      this.deleteId = [];
      this.addId = [];
    },

    show(roleId, roleName, remark) {
      this.modal = true;
      this.$set(this.formData, "name", roleName);
      this.$set(this.formData, "remark", remark);
      this.roleId = roleId;
      if (this.roleId) {
        this.modalLoading = true;
        Promise.all([this.getUser(), this.getRight()]).then(res => {
          this.modalLoading = false;
        });
      }
    },

    getUser() {
      return new Promise((resolve, reject) => {
        resolve();
        try {
          let params = {
            roleId: [this.roleId + ""],
            pageSize: 1000,
            crm: 1
          };

          this.$http
            .post("accounts/getAccountByUserSource", params)
            .then(res => {
              if (res.code === 20000) {
                this.userTableData = res.data.records;
              } else {
                this.$Message.error(`获取用户失败:${res.msg}`);
              }
            });
        } catch (e) {
          console.error(e);
          this.$Message.error(`获取用户失败`);
        }
      });
    },

    getRight() {
      return new Promise((resolve, reject) => {
        try {
          let params = {
            roleId: this.roleId
          };
          this.$http.get("common/getRoleGroup", params).then(res => {
            resolve();
            if (res.code === 20000) {
              this.rightGroupIds = res.data.groups.map(item => item.id) || [];
              this.rightRuleIds = res.data.rules.map(item => item.id) || [];
              let groupsTitle =
                res.data.groups.map(item => ({
                  label: item.title,
                  value: `group;${item.id}`
                })) || [];
              let rulesTitle =
                res.data.rules.map(item => ({
                  label: item.title,
                  value: `${item.type};${item.id}`
                })) || [];
              this.rightList = groupsTitle.concat(rulesTitle);
            } else {
              this.$Message.error(`获取权限列表失败:${res.msg}`);
            }
          });
        } catch (e) {
          resolve();
          this.$Message.error(`获取权限列表失败`);
        }
      });
    },

    viewUserList() {
      this.$refs.userModal.show(this.userTableData);
    },

    getCheckedRightData(data) {
      if (data && data.length) {
        this.rightList = data.map(item => ({
          label: item.title,
          value: item.value
        }));
      } else {
        this.rightList = [];
      }
      this.getRightIds();
    },

    getCheckedUserData(data, addId, deleteId) {
      this.userTableData = JSON.parse(JSON.stringify(data));
      this.addId = addId;
      this.deleteId = deleteId;
    },

    getUserIds() {
      return {
        addId: this.addId,
        deleteId: this.deleteId
      };
    },

    getRightIds() {
      let allRightValue = this.rightList.map(item => item.value);
      let allRights = allRightValue.map(item => {
        let typeArr = item.split(";");
        return {
          type: typeArr[0],
          id: typeArr[1]
        };
      });

      this.rightGroupIds = allRights
        .filter(item => item.type === "group")
        .map(item => {
          return item.id;
        });

      this.rightRuleIds = allRights
        .filter(item => item.type !== "group")
        .map(item => {
          return item.id;
        });
    },

    viewRightList() {
      let rights = this.rightList.map(item => item.value) || [];
      this.$refs.rightsModal.show(rights, this.formData.name);
    }
  }
};
</script>

<style lang="less" scoped>
.fr {
  float: right;
  margin-right: 50px;
  color: #2d8cf0;
}

.right-wrap {
  max-height: 200px;
  overflow: auto;
  padding: 0 20px;
  .single-right {
    margin-bottom: 10px;
  }
}

.table-area {
  padding: 15px;
  overflow: hidden;
}
</style>

