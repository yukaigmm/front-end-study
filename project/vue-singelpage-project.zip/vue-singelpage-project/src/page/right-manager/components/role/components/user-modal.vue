<template>
    <Modal
      v-model="modal"
      title="查看/编辑用户列表"
      width="1250"
      :mask-closable="false"
      class="choose-mutiple-targets"
    >
       <div slot="footer">
            <Button @click="onCancel">取消</Button>
            <Button type="primary" @click="onOk">确定</Button>
       </div>

       <div slot="close" @click="onCancel">
           <Icon type="ios-close-empty"></Icon>
       </div>

       <Form :label-width="80" ref="form">
           <Row>
               <Col span="12">
                  <Row>
                     <Col span="16">
                         <FormItem label="用户信息" >
                             <Input 
                               v-model.trim="searchData.userKeyword"
                               placeholder="请输入用户名/联系人/手机号码"
                              />
                         </FormItem>
                     </Col>
                     <Col span="16">
                         <FormItem label="部门" >
                             <Select v-model="searchData.deptId" clearable>
                                 <Option v-for="(item,index) in departList" :value="item.value" :key="index">
                                   {{item.label}}
                                 </Option>
                             </Select>
                         </FormItem>
                     </Col>
                     <Col span="7" :offset="1">
                         <Button type="primary" @click="search"> 搜索</Button>
                     </Col>
                  </Row>
               </Col>
           </Row>
       </Form>

       <transfer-table 
         v-loading="tableLoading"
         element-loading-text="拼命加载中"
         :originTableData="originTableData"
         :target-table-data="targetTableData"
         :columns="columns"
         transferKey="id"
         :tableHeight="250"
         ref="transferTable">
            <h5 slot="orginTitle">CRM系统用户列表</h5>
            <h5 slot="targetTitle">角色用户列表</h5>
       </transfer-table>
    </Modal>    
</template>

<script>
import transferTable from "../../../../../components/transfer-table.vue";

export default {
  components: {
    transferTable
  },

  created() {
    this.getDepartmentList();
  },

  data() {
    return {
      tableLoading: false,
      modal: false,
      searchData: {},
      originTableData: [],
      targetTableData: [],
      columns: [
        {
          type: "selection",
          width: 50,
          align: "center"
        },
        {
          title: "账号ID",
          key: "id",
          width: 80,
          render(h, { row }) {
            return h("span", row.id || "--");
          }
        },
        {
          title: "账号",
          key: "name",
          width: 80,
          render(h, { row }) {
            return h("span", row.name || "--");
          }
        },
        {
          title: "姓名",
          key: "linkman",
          width: 90,
          render(h, { row }) {
            return h("span", row.linkman || "--");
          }
        },
        {
          title: "手机",
          key: "mobile",
          width: 100,
          render(h, { row }) {
            return h("span", row.mobile || "--");
          }
        },
        {
          title: "所在部门",
          key: "dept",
          width: 150,
          ellipsis: true,
          render(h, { row }) {
            if (row.detp && row.detp.length) {
              let depts = row.detp.map(item => item.text);
              return h("span", depts.join("/"));
            } else {
              return h("span", "--");
            }
          }
        }
      ],
      departList: [],
      addId: [],
      deleteId: []
    };
  },

  methods: {
    onOk() {
      this.getTargetTableData();
      this.$emit("getData", this.targetTableData, this.addId, this.deleteId);
      this.onCancel();
    },

    getDepartmentList() {
      try {
        this.$http.get("dept/getAllSelect").then(res => {
          if (res.code === 20000) {
            this.departList = res.data;
          } else {
            this.$Message.error(`获取部门列表失：${res.msg}！`);
          }
        });
      } catch (e) {
        console.error(e);
        this.$Message.error("获取部门列表失败！");
      }
    },

    getTargetTableData() {
      this.targetTableData = this.$refs.transferTable.getData().targetData;
      this.addId =
        this.$refs.transferTable.getData().addRows.map(item => item.id) || [];
      this.deleteId =
        this.$refs.transferTable.getData().deleteRows.map(item => item.id) ||
        [];
    },

    onCancel() {
      this.modal = false;
      this.targetTableData = [];
      this.searchData = {};
      this.$refs.transferTable.clearData();
    },

    show(selecteUser) {
      this.modal = true;
      this.targetTableData = selecteUser;
      this.getAlluser();
    },

    getAlluser() {
      this.tableLoading = true;
      let params = {
        crm: 1,
        pageSize: 1000,
        ...this.searchData
      };
      try {
        this.$http.post("accounts/getAccountByUserSource", params).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.originTableData = res.data.records;
          } else {
            this.$Message.error(`获取crm用户列表失败:${res.msg}`);
          }
        });
      } catch (e) {
        console.error(e);
        this.tableLoading = false;
        this.$Message.error(`获取crm用户列表失败`);
      }
    },

    search() {
      this.getAlluser();
    }
  }
};
</script>


<style lang="less" scoped>
</style>

