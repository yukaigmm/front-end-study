<template>
    <div>
        <div class="search-area">
           <Form :label-width="90" @keydown.enter.native.prevent="search">
             <Row>
                 <Col span="8">
                   <FormItem label="角色名称">
                       <Input
                          v-model.trim="formData.name"
                          placeholder="请输入角色名称"
                        />
                   </FormItem>
                 </Col>
  
                 <Col span="4" :offset="1">
                     <Button type="primary" @click="search">搜索</Button>
                 </Col>
             </Row>
           </Form>
        </div>
        

        <div class="action-btn-wrap">
            <Button type="primary" @click="addRole">添加角色</Button>
        </div>

        <div class="table-area">
            <Table
              :data="tableData"
              :columns="columns"
              border
              v-loading="tableLoading"
              element-loading-text="拼命加载中"
             />
        </div>

        <div class="page-load">
             <Page
              :total="total"
              placement="top"
              :current="currentPage"
              :page-size="pageSize"
              @on-change="onPageChange"
              @on-page-size-change="onPageSizeChange"
              show-elevator
              show-sizer
              show-total />
        </div>

        <add-role-modal ref="addRoleModal"  @refreshTable="search"></add-role-modal>
        <managerRightModal ref="managerRightModal" @refreshTable="search"></managerRightModal>
        <managerUserModal ref='managerUserModal'  @refreshTable="search"></managerUserModal>
    </div>
</template>

<script>
import addRoleModal from "./components/add-role-modal";
import managerRightModal from "./components/manager-rights-modal.vue";
import managerUserModal from "./components/manager-user-modal.vue";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import $ from "jquery";

export default {
  components: {
    addRoleModal,
    managerRightModal,
    managerUserModal
  },

  mixins: [getMinusNumber],

  data() {
    return {
      formData: {
        name: ""
      },
      tableData: [],
      columns: [
        {
          key: "name",
          title: "角色名称",
          render(h, { row }) {
            return h("span", row.name || "--");
          }
        },
        {
          key: "createtime",
          title: "创建时间",
          render(h, { row }) {
            return h("span", row.createtime || "--");
          }
        },
        {
          key: "createname",
          title: "创建人",
          render(h, { row }) {
            return h("span", row.createname || "--");
          }
        },
        {
          key: "remark",
          title: "备注",
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.remark || "--");
          }
        },
        {
          key: "user",
          title: "用户列表",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.managerUser(row.id);
                    }
                  }
                },
                "管理"
              )
            ]);
          }
        },
        {
          key: "right",
          title: "权限列表",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.managerRight(row.id, row.name);
                    }
                  }
                },
                "管理"
              )
            ]);
          }
        },
        {
          key: "action",
          title: "操作",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.editRole(row.id, row.name, row.remark);
                    }
                  }
                },
                "编辑"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.deleteRole(row.id);
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  mounted() {
    this.getRoleList();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".action-btn-wrap", ".page-load"],
      ".table-area"
    );
  },

  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 162;
      let minusNumber = this.getMinusNumberOfFixedTable();
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },
    managerUser(id) {
      this.$refs.managerUserModal.show(id);
    },

    managerRight(id, name) {
      this.$refs.managerRightModal.show(id, name);
    },

    addRole() {
      this.roleId = "";
      this.$refs.addRoleModal.show();
    },

    editRole(roleId, name, remark) {
      this.$refs.addRoleModal.show(roleId, name, remark);
    },

    deleteRole(id) {
      let params = {
        roleId: id
      };

      this.$Modal.confirm({
        title: "删除角色",
        content: "确认删除该角色吗？",
        loading: true,
        onOk: () => {
          this.$http.post("common/deleteRole", params).then(res => {
            this.$Modal.remove();
            if (res.code === 20000) {
              this.$Message.success("删除成功！");
              this.search();
            } else {
              this.$Message.error("删除失败！");
            }
          });
        }
      });
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getRoleList();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getRoleList();
    },

    search() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getRoleList();
    },

    getRoleList() {
      let params = {
        pageNo: this.currentPage,
        pageSize: this.pageSize,
        ...this.formData
      };
      this.tableLoading = true;
      try {
        this.$http.get("common/getRoles", params).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
          } else {
            this.$Message.error(`获取角色列表失败:${res.data.msg}`);
          }
        });
      } catch (e) {
        this.tableLoading = false;
        this.$Message.error(`获取角色列表失败`);
      }
    }
  }
};
</script>

<style lang="less" scoped>
.action-btn-wrap {
  margin: 15px 0;
}

.page-load {
  text-align: right;
  margin: 15px 0;
}
</style>

