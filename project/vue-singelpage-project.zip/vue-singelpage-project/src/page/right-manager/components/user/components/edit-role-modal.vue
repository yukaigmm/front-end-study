<template>
    <Modal
      v-model="modal"
      title="编辑用户所属角色"
      :mask-closable="false"
      width="800"
    >
       <div slot="close" @click="onCancel">
           <Icon type="ios-close-empty"></Icon>
       </div>

       <div slot="footer">
           <Button type="default" @click="onCancel">关闭</Button>
           <Button type="primary" @click="onOk" :loading="btnLoading">确定</Button>
       </div>
        
      <transfer-box 
         ref="transferBox"
         v-loading="boxLoading"
         element-loading-text="拼命加载中"
         :height="300"
         :orign-data="orignData"
         labelKey="name"
         valueKey="id"
         :allOriginData="allOriginData"
        :selectedKeys="roleList"
        >
        <div slot="originHeader" class="orign-header">
            <span class="label">角色名称</span>
            <Input 
              class="input-wrap"
              v-model.trim="searchData.name" 
              placeholder="请输入角色名称" />
            <Button type="primary" class='btn' @click="search">搜索</Button>
        </div>
       
       <div slot="targetHeader" class="target-header">
           <Row>
               <Col span="12">
                  <span>账号ID：</span>
                  <span>{{userInfo.id||"--"}}</span>
               </Col>
               <Col span="12">
                  <span>用户名：</span>
                  <span>{{userInfo.name||"--"}}</span>
                  
               </Col>
               <Col span="12">
                  <span>姓名：</span>
                  <span>{{userInfo.linkman||"--"}}</span>
               </Col>
               <Col span="12">
                  <span>手机：</span>
                  <span>{{userInfo.mobile||"--"}}</span>
               </Col>
           </Row>
       </div>

      </transfer-box>
    </Modal>    
</template>

<script>
import transferBox from "../../../../../components/transfer-box.vue";
export default {
  components: {
    transferBox
  },

  data() {
    return {
      modal: false,
      orignData: [],
      searchData: {
        name: ""
      },
      boxLoading: false,
      roleList: [],
      ifFirstLoad: true,
      allOriginData: [],
      btnLoading: false,
      userInfo: {}
    };
  },

  methods: {
    show(roles, userInfo) {
      this.roleList = roles;
      (this.userInfo = userInfo), (this.modal = true);
      this.getAllRights();
    },

    search() {
      this.getAllRights();
    },

    onCancel() {
      this.modal = false;
      this.clearData();
    },

    onOk() {
      this.submit();
    },

    clearData() {
      this.userInfo = {};
      this.searchData = {
        name: ""
      };
      this.ifFirstLoad = true;
      this.roleList = [];
      this.$refs.transferBox.clearData();
    },

    submit() {
      this.btnLoading = true;
      this.getSelectedData();
      let params = {
        userId: [this.userInfo.id],
        roleIds: this.roleList
      };
      this.$http.post("common/setUserRoles", params).then(res => {
        this.btnLoading = false;
        if (res.code === 20000) {
          this.$Message.success("编辑成功！");
          this.onCancel();
          this.$emit("refreshTable")
        } else {
          this.$Message.error("编辑失败！");
        }
      });
    },

    getSelectedData() {
      this.roleList = this.$refs.transferBox
        .getSelectedRows()
        .map(item => item.id);
    },

    getAllRights() {
      this.boxLoading = true;
      let params = {
        pageSize: 1000,
        ...this.searchData
      };
      try {
        this.$http.get("common/getRoles", params).then(res => {
          this.boxLoading = false;
          if (res.code === 20000) {
            this.orignData = res.data.records;
            if (this.ifFirstLoad) {
              this.allOriginData = JSON.parse(JSON.stringify(res.data.records));
              this.ifFirstLoad = !this.ifFirstLoad;
            }
          } else {
            this.$Message.error("获取权限列表失败");
          }
        });
      } catch (e) {
        this.boxLoading = false;
        console.error(e);
        this.$Message.error("获取权限列表失败");
      }
    }
  }
};
</script>

<style lang="less" scoped>
.orign-header {
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 10px;
  border: 1px solid #ccc;
  border-bottom: transparent;
  .label {
    flex: 2;
  }
  .input-wrap {
    flex: 5;
  }
  .btn {
    flex: 1;
    margin-left: 10px;
  }
}
.target-header {
  border: 1px solid #ccc;
  border-bottom: transparent;
  padding: 10px;
}
</style>


