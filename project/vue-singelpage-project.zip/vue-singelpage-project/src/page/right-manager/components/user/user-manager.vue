<template>
    <div>
         <div class="search-area">
             <search-area :showExpand="false" ref="form" @onKeydownSearch="search">
                   <div slot="default">
                       <Row>
                           <Col span="8">
                              <FormItem label="关键词">
                                  <Input
                                    v-model.trim="formData.userKeyword"
                                    placeholder="请输入关键词"
                                   />
                              </FormItem>
                           </Col>

                           <Col span="4" :offset="1">
                                <Button type="primary" @click="search">搜索</Button>
                           </Col>
                       </Row>
                   </div>
             </search-area>
         </div>

         <div class="action-btn-wrap">
             <Button type="primary" @click="managerUserList">管理用户列表</Button>
         </div>


         <div class="table-area">
             <Table
               :data="tableData"
               :columns="columns"
               border
               v-loading="tableLoading"
               element-loading-text="拼命加载中"
              />
         </div>

         <div class="page-load">
             <Page
              :total="total"
              placement="top"
              :current="currentPage"
              :page-size="pageSize"
              @on-change="onPageChange"
              @on-page-size-change="onPageSizeChange"
              show-elevator
              show-sizer
              show-total />
         </div>

         <user-list-manager ref="userListManager" @refreshTable="search"></user-list-manager>
         <edit-role-modal ref="editRoleModal"  @refreshTable="search"></edit-role-modal>
    </div>
</template>

<script>
import searchArea from "../../../../components/search-area.vue";
import userListManager from "./components/user-list-manager.vue";
import editRoleModal from "./components/edit-role-modal.vue";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import $ from "jquery"
export default {
  components: {
    searchArea,
    userListManager,
    editRoleModal
  },

  mixins: [getMinusNumber],

  data() {
    return {
      formData: {},
      tableData: [],
      tableLoading: false,
      columns: [
        {
          key: "id",
          title: "账号ID",
          render(h,{row}){
            return h("span",row.id||"--")
          }
        },
        {
          key: "name",
          title: "账号",
          render(h,{row}){
            return h("span",row.name||"--")
          }
        },
        {
          key: "linkman",
          title: "姓名",
          render(h,{row}){
            return h("span",row.linkman||"--")
          }
        },
        {
          key: "mobile",
          title: "手机",
          render(h,{row}){
            return h("span",row.mobile||"--")
          }
        },
        {
          key: "status",
          title: "账号状态",
          render: (h, { row }) => {
            let mapping = {
              "1": "正常",
              "2": "停用"
            };
            return h("span", mapping[row.status] || "--");
          }
        },
        {
          key: "dept",
          title: "所在部门",
          ellipsis: true,
          render(h, { row }) {
            if (row.detp && row.detp.length) {
              let depts = row.detp.map(item => item.text);
              return h(
                "span",
                {
                  attrs: {
                    title: depts.join("/")
                  }
                },
                depts.join("/")
              );
            } else {
              return h("span", "--");
            }
          }
        },
        {
          key: "role",
          title: "所属角色",
          ellipsis: true,
          render(h, { row }) {
            if (row.role && row.role.length) {
              let roles = row.role.map(item => item.name);
              return h(
                "span",
                {
                  attrs: {
                    title: roles.join("/")
                  }
                },
                roles.join("/")
              );
            } else {
              return h("span", "--");
            }
          }
        },
        {
          key: "action",
          title: "操作",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      let status = row.status == 1 ? "2" : "1";
                      this.changeAccountStatus(row.id, status);
                    }
                  }
                },
                row.status == 1 ? "停用" : "启用"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      let info = {
                        id: row.id,
                        name: row.name,
                        mobile: row.mobile,
                        linkman: row.linkman
                      };
                      let ids = row.role.map(item => item.id);
                      this.editRole(ids, info);
                    }
                  }
                },
                "编辑角色"
              )
            ]);
          }
        }
      ],
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  mounted() {
    this.getUserList();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".action-btn-wrap", ".page-load"],
      ".table-area"
    );
  },

  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 162;
      let minusNumber = this.getMinusNumberOfFixedTable();
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    search() {
      this.pageSize = 10;
      this.currentPage = 1;
      this.getUserList();
    },

    changeAccountStatus(id, status) {
      let params = {
        userId: [id],
        status
      };

      this.$Message.loading({
        duration: 0,
        content: "设置中..."
      });

      this.$http.post("common/setCrmUserStatus", params).then(res => {
        this.$Message.destroy();
        if (res.code === 20000) {
          this.$Message.success("设置成功");
          this.search();
        } else {
          this.$Message.error("设置失败");
        }
      });
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getUserList();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getUserList();
    },

    managerUserList() {
      this.$refs.userListManager.show();
    },

    editRole(roles, info) {
      this.$refs.editRoleModal.show(roles, info);
    },

    getUserList() {
      let params = {
        pageNo: this.currentPage,
        pageSize: this.pageSize,
        crm: 1,
        ...this.formData
      };
      this.tableLoading = true;

      try {
        this.$http.post("accounts/getAccountByUserSource", params).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
          } else {
            this.$Message.error(`获取用户列表失败:${res.msg}`);
          }
        });
      } catch (e) {
        console.error(e);
        this.tableLoading = false;
        this.$Message.error(`获取用户列表失败`);
      }
    }
  }
};
</script>

<style lang="less" scoped>
.action-btn-wrap {
  margin: 15px 0;
}

.page-load {
  text-align: right;
  margin: 15px 0;
}
</style>

