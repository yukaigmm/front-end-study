<template>
    <Modal
       v-model="modal"
       title="管理用户列表"
       :mask-closable="false"
       width="1200"
    >
        <div slot="close" @click="onCancel">
           <Icon type="ios-close-empty"></Icon>
       </div>

       <div slot="footer">
           <Button type="default" @click="onCancel">关闭</Button>
           <Button type="primary" @click="onOk" :loading="btnLoading">确定</Button>
       </div>

       <div class="search-area">
            <Form :label-width="90">
                <Row>
                    <Col span="12">
                       <Row>
                           <Col span="20">
                              <FormItem label="用户信息">
                                  <Input 
                                   placeholder="请输入用户信息"
                                   v-model.trim="searchData.userKeyword" />
                              </FormItem>
                           </Col>

                           <Col span="20">
                              <FormItem label="部门">
                                  <Select 
                                    v-model="searchData.deptId" 
                                    placeholder="请选择部门"
                                    clearable>
                                       <Option 
                                         v-for="(item,index) in departList"
                                         :value="item.value" 
                                         :key="index">
                                        {{item.label}}
                                         </Option>
                                 </Select>
                              </FormItem>
                           </Col>

                           <Col span="20" style="text-align:right">
                               <Button type="primary" @click="search">搜索</Button>
                           </Col>
                       </Row>
                    </Col>
                </Row>
            </Form>
       </div>

       <transfer-table
          v-loading="tableLoading"
          element-loading-text="拼命加载中"
          ref="transferTable"
          :columns="columns"
          :originTableLoading="originTableLoading"
          :originTableData="originTableData"
          :targetTableData="targetTableData"
          transferKey="id"
          tableHeight="250"
       >
           <h5 slot="orginTitle">申报系统账号列表</h5>
           <h5 slot="targetTitle">CRM账号列表</h5>
       </transfer-table>
    </Modal>

</template>

<script>
import transferTable from "../../../../../components/transfer-table";
export default {
  components: {
    transferTable
  },

  data() {
    return {
      departList: [],
      originTableLoading: false,
      btnLoading: false,
      tableLoading: false,
      modal: false,
      searchData: {},
      targetTableData: [],
      columns: [
        {
          type: "selection",
          width: 50,
          align: "center"
        },
        {
          title: "账号ID",
          key: "id",
          width: 80,
          render(h,{row}){
            return h("span",row.id||"--");
          }
        },
        {
          title: "账号",
          key: "name",
          width: 100,
           render(h,{row}){
            return h("span",row.name||"--");
          }
        },
        {
          title: "姓名",
          key: "linkman",
          width: 80,
           render(h,{row}){
            return h("span",row.linkman||"--");
          }
        },
        {
          title: "手机",
          key: "mobile",
          width: 100,
           render(h,{row}){
            return h("span",row.mobile||"--");
          }
        },
        {
          title: "所在部门",
          key: "dept",
          width: 100,
          ellipsis: true,
          render(h, { row }) {
            if (row.detp && row.detp.length) {
              let depts = row.detp.map(item => item.text);
              return h(
                "span",
                {
                  attrs: {
                    title: depts.join("/")
                  }
                },
                depts.join("/")
              );
            } else {
              return h("span", "--");
            }
          }
        }
      ],
      originTableData: [],
      selectedData: {
        addId: [],
        deleteId: []
      }
    };
  },

  created() {
    this.getDepartmentList();
  },

  methods: {
    getDepartmentList() {
      try {
        this.$http.get("dept/getAllSelect").then(res => {
          if (res.code === 20000) {
            this.departList = res.data;
          } else {
            this.$Message.error(`获取部门列表失：${res.msg}！`);
          }
        });
      } catch (e) {
        console.error(e);
        this.$Message.error("获取部门列表失败！");
      }
    },

    show() {
      this.modal = true;
      // this.getData();
      this.tableLoading = true;
      this.getAllCrmUser().then(res=>{
           this.tableLoading = false;
      }) 
    },

    onCancel() {
      this.modal = false;
      this.originTableData = [];
      this.targetTableData = [];
      this.selectedData = {
        addId: [],
        deleteId: []
      };
      this.$refs.transferTable.clearData();
      this.searchData = {};
    },

    submit() {
      this.getSelectedData();
      let params = {
        ...this.selectedData
      };
      this.btnLoading = true;
      this.$http.post("common/setCrmUser", params).then(res => {
        this.btnLoading = false;
        if (res.code === 20000) {
          this.$Message.success("设置成功！");
          this.$emit("refreshTable");
          this.onCancel();
        } else {
          this.$Message.error(`设置失败:${res.msg}`);
        }
      });
    },

    getSelectedData() {
      let data = this.$refs.transferTable.getData();
      this.selectedData.addId = data.addRows.map(item => item.id) || [];
      this.selectedData.deleteId = data.deleteRows.map(item => item.id) || [];
    },

    onOk() {
      this.submit();
    },

    getData() {
      this.tableLoading = true;
      Promise.all([this.getAllUser(), this.getAllCrmUser()])
        .then(() => {
          this.tableLoading = false;
        })
        .catch(err => {
          this.tableLoading = false;
          console.error(err);
          this.$Message.error(`获取用户列表失败`);
        });
    },

    search() {
      this.originTableLoading = true;
      this.getAllUser().then(res => {
        this.originTableLoading = false;
      });
    },

    getAllUser() {
      let params = {
        pageSize: -1,
        ...this.searchData
      };

      return new Promise(resolve => {
        try {
          this.$http
            .post("accounts/getAccountByUserSource", params)
            .then(res => {
              resolve();
              if (res.code === 20000) {
                this.originTableData = res.data.records;
              } else {
                this.$Message.error(`获取用户列表失败:${res.msg}`);
              }
            });
        } catch (e) {
          resolve();
          console.error(e);
          this.$Message.error(`获取用户列表失败`);
        }
      });
    },

    getAllCrmUser() {
      let params = {
        pageSize: -1,
        crm: 1
      };

      return new Promise(resolve => {
        try {
          this.$http
            .post("accounts/getAccountByUserSource", params)
            .then(res => {
              resolve();
              if (res.code === 20000) {
                this.targetTableData = res.data.records;
                // this.total = res.data.total;
              } else {
                this.$Message.error(`获取用户列表失败:${res.msg}`);
              }
            });
        } catch (e) {
          console.error(e);
          resolve();
          this.$Message.error(`获取用户列表失败`);
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
</style>


