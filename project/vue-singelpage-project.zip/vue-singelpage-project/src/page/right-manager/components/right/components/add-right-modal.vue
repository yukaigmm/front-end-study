<template>
    <Modal
       v-model="modal"
       :title="modalTitle"
       width="600"
       :mask-closable="false"
    >
        <div slot="footer">
            <Button @click="onCancel">取消</Button>
            <Button type="primary" @click="onOk" :loading="btnLoading">确定</Button>
        </div>

        <div slot="close" @click="onCancel">
           <Icon type="ios-close-empty"></Icon>
        </div>

        <Form ref="form" :rules="validateRules" :label-width="90" :model="formData">
            <Row>
                <Col span="12">
                   <FormItem label="权限名称" prop="title">
                       <Input 
                         v-model.trim="formData.title"
                         placeholder="请输入权限名称"
                       />
                   </FormItem>
                </Col>

                <Col span="12" >
                   <FormItem label="权限标识" prop="name">
                       <Input 
                          v-model.trim="formData.name" 
                          placeholder="请输入权限标识"/>
                   </FormItem>
                </Col>
                
                <Col span="12">
                   <FormItem label="类型" prop="type">
                       <Select v-model="formData.type" placeholder="请选择权限类型">
                            <Option 
                               v-for="(item,index) in typeList" 
                               :key="index" 
                               :value="item.value">
                                {{item.label}}
                            </Option>
                       </Select>
                   </FormItem>
                </Col>

                <Col span="12">
                   <FormItem label="路由" prop='route' >
                       <Input 
                          v-model.trim="formData.route" 
                          placeholder="请输入路由"/>
                   </FormItem>
                </Col>

                <Col span="24">
                   <FormItem label="备注" prop="remark" >
                       <Input 
                         v-model.trim="formData.remark" 
                         type="textarea" 
                         placeholder="请输入备注" 
                         :autosize="{ minRows: 4, maxRows: 6 }"/>
                   </FormItem>
                </Col>
            </Row>
        </Form>
    </Modal>    
</template>

<script>
let timer1 = null;
let timer2 = null;
export default {
  data() {
    return {
      typeList: [
        {
          value: 1,
          label: "菜单"
        },
        {
          value: 2,
          label: "功能"
        },
        {
          value:3,
          label:"数据"
        }
      ],
      rightId: "",
      modal: false,
      formData: {
        name: "",
        title: "",
        route: "",
        remark: "",
        type: ""
      },
      btnLoading: false
    };
  },

  computed: {
    modalTitle() {
      return this.rightId ? "编辑权限" : "新增权限";
    },

    validateRules() {
      const validateRuleNameIfExist = (rules, value, callback) => {
        let errors = [];
        clearTimeout(timer1);
        if (value) {
          let params = {
            ruleName: value,
            id: this.rightId
          };
          timer1 = setTimeout(() => {
            this.$http
              .post("common/checkAuthName", params)
              .then(res => {
                if (res.data.status) {
                  errors.push(new Error("该权限名已被使用！"));
                }
              })
              .then(() => {
                callback(errors);
              });
          }, 400);
        } else {
          callback([]);
        }
      };

      const validateRuleSignIfExist = (rules, value, callback) => {
        let errors = [];
        clearTimeout(timer2);
        if (value) {
          let params = {
            ruleSign: value,
            id: this.rightId
          };
          timer2 = setTimeout(() => {
            this.$http
              .post("common/checkAuthName", params)
              .then(res => {
                if (res.data.status) {
                  errors.push(new Error("该权限标识已被使用！"));
                }
              })
              .then(() => {
                callback(errors);
              });
          }, 400);
        } else {
          callback([]);
        }
      };

      return {
        name: [
          {
            required: true,
            message: "权限标识不能为空"
          },
          {
            validator: validateRuleSignIfExist,
            trigger: "blur"
          }
        ],
        title: [
          {
            required: true,
            message: "权限名称不能为空"
          },
          {
            validator: validateRuleNameIfExist,
            trigger: "blur"
          }
        ],
        // route: [
        //   {
        //     required: true,
        //     message: "路由不能为空"
        //   }
        // ],
        type: [
          {
            required: true,
            message: "权限类型必选"
          }
        ],
        remark: []
      };
    }
  },

  methods: {
    onCancel() {
      this.modal = false;
      this.clearData();
    },

    clearData() {
      this.formData = {
        name: "",
        title: "",
        route: "",
        remark: "",
        type: ""
      };
      this.rightId = "";
      this.$refs.form.resetFields();
    },

    onOk() {
      this.$refs.form.validate(valid => {
        if (valid) {
          if (this.rightId) {
            this.editRights();
          } else {
            this.addRights();
          }
        } else {
          this.$Message.warning("请按红色字段填写内容");
        }
      });
    },

    addRights() {
      let params = {
        ...this.formData
      };

      this.btnLoading = true;
      this.$http.post("common/addRule", params).then(res => {
        this.btnLoading = false;
        if (res.code === 20000) {
          this.$Message.success("添加成功");
          this.onCancel();
          this.$emit("refreshTable");
        } else {
          this.$Message.error("添加失败！");
        }
      });
    },

    editRights() {
      let params = {
        ruleId: this.rightId,
        ...this.formData
      };

      this.btnLoading = true;
      this.$http.post("common/updateRule", params).then(res => {
        this.btnLoading = false;
        if (res.code === 20000) {
          this.$Message.success("编辑成功");
          this.onCancel();
          this.$emit("refreshTable");
        } else {
          this.$Message.error("编辑失败！");
        }
      });
    },

    show(ruleData = {}) {
      this.modal = true;
      let keys = ["name", "title", "route", "remark", "type"];
      keys.forEach(key => {
        this.$set(this.formData, key, ruleData[key] || "");
      });
      this.rightId = ruleData.id || "";
    }
  }
};
</script>

<style lang="less" scoped>
</style>

