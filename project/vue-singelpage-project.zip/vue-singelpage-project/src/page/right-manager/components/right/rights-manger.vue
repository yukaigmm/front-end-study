<template>
    <div>
        <div class="search-area">
           <Form :label-width="90" @keydown.enter.native.prevent="search">
             <Row>
                 <Col span="8">
                   <FormItem label="权限/权限组名">
                       <Input
                          v-model.trim="formData.name"
                          placeholder="请输入权限/权限组名"
                        />
                   </FormItem>
                 </Col>
  
                 <Col span="4" :offset="1">
                     <Button type="primary" @click="search">搜索</Button>
                 </Col>
             </Row>
           </Form>
        </div>
        

        <div class="action-btn-wrap">
            <Button type="primary" @click="addRight">添加权限</Button>
            <Button type="primary" @click="addRightGroup">添加权限组</Button>
        </div>

        <div class="table-area">
            <Table
              :data="tableData"
              :columns="columns"
              border
              v-loading="tableLoading"
              element-loading-text="拼命加载中"
             />
        </div>

        <div class="page-load">
             <Page
              :total="total"
              placement="top"
              :current="currentPage"
              :page-size="pageSize"
              @on-change="onPageChange"
              @on-page-size-change="onPageSizeChange"
              show-elevator
              show-sizer
              show-total />
        </div>
        <addRightModal ref="addRightModal" @refreshTable="search" />
        <addRightGroupModal ref="addRightGroupModal" @refreshTable="search"></addRightGroupModal>
    </div>
</template>

<script>
import addRightModal from "./components/add-right-modal.vue";
import addRightGroupModal from "./components/add-right-group-modal.vue";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import $ from "jquery";

export default {
  components: {
    addRightModal,
    addRightGroupModal
  },
  mixins: [getMinusNumber],

  data() {
    return {
      formData: {},
      tableData: [],
      columns: [
        {
          title: "权限/权限组名称",
          key: "title",
          render(h, { row }) {
            return h("span", row.title || "--");
          }
        },
        {
          title: "权限标识",
          key: "name",
          render(h, { row }) {
            return h("span", row.name || "--");
          }
        },
        {
          title: "类型",
          key: "type",
          render(h, { row }) {
            let mapping = {
              "1": "菜单",
              "2": "功能",
              "3":"数据",
              group: "权限组"
            };

            return h("span", mapping[row.type] || "--");
          }
        },
        {
          title: "路由",
          key: "route",
          render(h, { row }) {
            return h("span", row.route || "--");
          }
        },
        {
          title: "备注",
          key: "remark",
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.remark || "--");
          }
        },
        {
          title: "操作",
          key: "action",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      if (row.type !== "group") {
                        this.editRight(JSON.parse(JSON.stringify(row)));
                      } else {
                        this.eidtRightGroup(JSON.parse(JSON.stringify(row)));
                      }
                    }
                  }
                },
                "编辑"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      if (row.type !== "group") {
                        this.deleteRight(row.id);
                      } else {
                        this.deleteRightGroup(row.id);
                      }
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  mounted() {
    this.getRightsList();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".action-btn-wrap", ".page-load"],
      ".table-area"
    );
  },

  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 162;
      let minusNumber = this.getMinusNumberOfFixedTable();
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },
    addRightGroup() {
      this.$refs.addRightGroupModal.show();
    },

    eidtRightGroup(groupData) {
      this.$refs.addRightGroupModal.show(groupData);
    },

    editRight(ruleData) {
      this.$refs.addRightModal.show(ruleData);
    },

    deleteRight(id) {
      let params = {
        ruleId: id
      };

      this.$Modal.confirm({
        title: "删除权限",
        content: "确定删除该权限吗？",
        loading: true,
        onOk: () => {
          this.$http.post("common/deleteRule", params).then(res => {
            this.$Modal.remove();
            if (res.code === 20000) {
              this.$Message.success("删除成功！");
              this.search();
            } else {
              this.$Message.error("删除失败！");
            }
          });
        }
      });
    },

    deleteRightGroup(id) {
      let params = {
        groupId: id
      };

      this.$Modal.confirm({
        title: "删除权限组",
        content: "确定删除该权限组吗？",
        loading: true,
        onOk: () => {
          this.$http.post("common/deleteGroup", params).then(res => {
            this.$Modal.remove();
            if (res.code === 20000) {
              this.$Message.success("删除成功！");
              this.search();
            } else {
              this.$Message.error("删除失败！");
            }
          });
        }
      });
    },

    addRight() {
      this.$refs.addRightModal.show();
    },

    search() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getRightsList();
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getRightsList();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getRightsList();
    },

    getRightsList() {
      let params = {
        pageNo: this.currentPage,
        pageSize: this.pageSize,
        ...this.formData
      };
      this.tableLoading = true;
      this.$http.get("common/getAllGroupsAndRules", params).then(res => {
        this.tableLoading = false;
        if (res.code === 20000) {
          this.tableData = res.data.records;
          this.total = res.data.total;
        } else {
          this.$Message.error(`获取权限列表失败:${res.msg}`);
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.action-btn-wrap {
  margin: 15px 0;
}

.page-load {
  text-align: right;
  margin: 15px 0;
}
</style>

