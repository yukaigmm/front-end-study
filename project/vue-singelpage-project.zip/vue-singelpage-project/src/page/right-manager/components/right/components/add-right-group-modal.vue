<template>
  <Modal v-model="modal" :mask-closable="false" :title="modalTitle" width="738">
    <div slot="footer">
      <Button @click="onCancel">取消</Button>
      <Button type="primary" @click="onOk" :loading="btnLoading">确定</Button>
    </div>
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <Form
      :model="formData"
      ref="form"
      :rules="validateRules"
      :label-width="90"
      v-loading="modalLoading"
      element-loading-text="拼命加载中"
    >
      <Row>
        <Col span="12">
          <FormItem label="权限组名称" prop="name">
            <Input v-model.trim="formData.name" placeholder="请输入权限组名称"/>
          </FormItem>
        </Col>

        <Col span="24">
          <Collapse v-model="panel">
            <Panel name="right">
              <span>权限列表</span>
              <span class="fr" @click.prevent.stop="viewRightList">管理权限列表</span>

              <div class="table-area" slot="content">
                <Table
                  height="158"
                  :data="rightTableData"
                  :columns="columns"
                  border
                  v-loading="tableLoading"
                  :key="tableKey"
                  element-loading-text="拼命加载中"
                />
              </div>
            </Panel>
          </Collapse>
        </Col>

        <Col span="24" style="margin-top:15px;">
          <FormItem label="备注" prop="remark">
            <Input
              v-model.trim="formData.remark"
              placeholder="请输入备注"
              type="textarea"
              :autosize="{ minRows: 4, maxRows: 6 }"
            />
          </FormItem>
        </Col>
      </Row>
    </Form>

    <manager-right-list ref="managerRightList" @getSelectedData="getSelectedData"></manager-right-list>
  </Modal>
</template>


<script>
import managerRightList from "./manager-right-list.vue";
let roleGroupTimer = null;
export default {
  components: {
    managerRightList
  },

  data() {
    return {
      tableKey: "",
      modal: false,
      groupId: "",
      btnLoading: false,
      formData: {},
      modalLoading: false,
      panel: "",
      rightTableData: [],
      columns: [
        {
          title: "权限/权限组名称",
          key: "title",
          width: 120,
          render(h, { row }) {
            return h("span", row.title || "--");
          }
        },
        {
          title: "权限标识",
          key: "name",
          width: 120,
          render(h, { row }) {
            return h("span", row.name || "--");
          }
        },
        {
          title: "类型",
          key: "type",
          width: 120,
          render(h, { row }) {
            let mapping = {
              "1": "菜单",
              "2": "功能",
              "3": "数据",
              group: "权限组"
            };

            return h("span", mapping[row.type] || "--");
          }
        },
        {
          title: "路由",
          key: "route",
          width: 120,
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.route || "--");
          }
        },
        {
          title: "备注",
          key: "remark",
          width: 150,
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.remark || "--");
          }
        }
      ],
      tableLoading: false
    };
  },

  computed: {
    modalTitle() {
      return this.groupId ? "编辑权限组" : "添加权限组";
    },

    validateRules() {
      const validateRuleGroupNameIfExist = (rules, value, callback) => {
        let errors = [];
        clearTimeout(roleGroupTimer);
        if (value) {
          let params = {
            id: this.groupId,
            groupName: value
          };
          roleGroupTimer = setTimeout(() => {
            this.$http
              .post("common/checkAuthName", params)
              .then(res => {
                if (res.data.status) {
                  errors.push(new Error("该权限组名已被使用！"));
                }
              })
              .then(() => {
                callback(errors);
              });
          }, 400);
        } else {
          callback([]);
        }
      };
      return {
        name: [
          {
            required: true,
            message: "权限（组）名不能为空"
          },
          {
            validator: validateRuleGroupNameIfExist,
            trigger: "blur,change"
          }
        ]
      };
    }
  },

  methods: {
    onOk() {
      this.$refs.form.validate(valid => {
        if (valid) {
          if (this.groupId) {
            this.editGroup();
          } else {
            this.addGroup();
          }
        } else {
          this.$Message.warning("请按红色字段填写内容！");
        }
      });
    },

    getSelectedData(data) {
      this.rightTableData = data;
      this.tableKey = Date.now();
    },

    getSubmitParams() {
      let params = {};
      let groups = this.rightTableData
        .filter(item => item.type == "group")
        .map(item => item.id);
      let rules = this.rightTableData
        .filter(item => item.type != "group")
        .map(item => item.id);
      if (this.groupId) {
        params = {
          rules,
          groups,
          groupId: this.groupId,
          ...this.formData
        };
      } else {
        params = {
          rules,
          groups,
          ...this.formData
        };
      }

      return params;
    },

    addGroup() {
      let params = this.getSubmitParams();
      this.btnLoading = true;
      this.$http.post("common/addGroup", params).then(res => {
        this.btnLoading = false;
        if (res.code === 20000) {
          this.$Message.success("添加成功！");
          this.onCancel();
          this.$emit("refreshTable");
        } else {
          this.$Message.error("添加失败！");
        }
      });
    },

    editGroup() {
      let params = this.getSubmitParams();
      this.btnLoading = true;
      this.$http.post("common/setGroupRules", params).then(res => {
        this.btnLoading = false;
        if (res.code === 20000) {
          this.$Message.success("编辑成功！");
          this.onCancel();
          this.$emit("refreshTable");
        } else {
          this.$Message.error("编辑失败！");
        }
      });
    },

    onCancel() {
      this.modal = false;
      this.clearData();
      this.$refs.form.resetFields();
    },

    clearData() {
      this.formData = {
        name: "",
        remark: ""
      };
      this.rightTableData = [];
      this.panel = "";
      this.groupId = "";
    },

    show(groupData = {}) {
      this.groupId = groupData.id;
      this.$set(this.formData, "name", groupData.title);
      this.$set(this.formData, "remark", groupData.remark);
      this.modal = true;
      if (this.groupId) {
        this.getRightList();
      }
    },

    viewRightList() {
      this.$refs.managerRightList.show(this.rightTableData);
    },

    getRightList() {
      let params = {
        groupIds: this.groupId
      };

      this.modalLoading = true;

      this.$http.get("common/getGroup", params).then(res => {
        this.modalLoading = false;
        if (res.code === 20000) {
          this.rightTableData = res.data.rules;
          this.tableKey = Date.now();
        } else {
          this.$Message.error("获取权限列表失败！");
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.fr {
  float: right;
  margin-right: 50px;
  color: #2d8cf0;
}
.table-area {
  padding: 15px;
  overflow: hidden;
}

.ivu-table-wrapper {
  height: 200px !important;
}
</style>

