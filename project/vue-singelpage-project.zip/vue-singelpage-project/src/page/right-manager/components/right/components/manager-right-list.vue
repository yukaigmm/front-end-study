<template>
    <Modal
      v-model="modal"
      title="管理权限列表"
      width="1300"
      :mask-closable="false"
      class="choose-mutiple-targets"
    >
       <div slot="footer">
            <Button @click="onCancel">取消</Button>
            <Button type="primary" @click="onOk">确定</Button>
       </div>

       <div slot="close" @click="onCancel">
           <Icon type="ios-close-empty"></Icon>
       </div>

       <Form ref="form" :label-width="100">
            <Row>
               <Col span="12">
                  <Row>
                      <Col span="16">
                         <FormItem
                          label="权限/权限组名称"
                         >
                            <Input 
                              v-model.trim="searchData.name"
                              placeholder="请输入权限/权限组名称"
                            />
                         </FormItem>
                      </Col>

                      <Col span="7" :offset="1">
                          <Button type="primary" @click="search">搜索</Button>
                      </Col>
                  </Row>
               
               </Col>

            </Row>

       </Form>

       <transfer-table 
         v-loading="tableLoading"
         element-loading-text="拼命加载中"
         :originTableData="originTableData"
         :target-table-data="targetTableData"
         :columns="columns"
         transferKey="id"
         :tableHeight="250"
         ref="transferTable"
        >
            <h5 slot="orginTitle">所有权限列表</h5>
            <h5 slot="targetTitle">已选权限列表</h5>
        </transfer-table>
    </Modal>
</template>

<script>
import transferTable from "../../../../../components/transfer-table.vue";
export default {
  components: {
    transferTable
  },

  data() {
    return {
      modal: false,
      searchData: {
        name: ""
      },
      tableLoading: false,
      originTableData: [],
      targetTableData: [],
      columns: [
        {
          type: "selection",
          algin: "center",
          width: 50
        },
        {
          title: "权限/权限组名称",
          key: "title",
          ellipsis: true,
          width: 120,
          render(h, { row }) {
            return h("span", row.title || "--");
          }
        },
        {
          title: "权限标识",
          key: "name",
          width: 110,
          render(h, { row }) {
            return h("span", row.name || "--");
          }
        },
        {
          title: "类型",
          key: "type",
          width: 80,
          render(h, { row }) {
            let mapping = {
              "1": "菜单",
              "2": "功能",
              "3":"数据",
              group: "权限组"
            };

            return h("span", mapping[row.type] || "--");
          }
        },
        {
          title: "路由",
          key: "route",
          width: 100,
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.route || "--");
          }
        },
        {
          title: "备注",
          key: "remark",
          width: 100,
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.remark || "--");
          }
        }
      ]
    };
  },

  methods: {
    onOk() {
      this.modal = false;
      this.$emit("getSelectedData", this.getSelectedTableData());
    },

    onCancel() {
      this.modal = false;
      this.clearData();
    },

    clearData() {
      this.searchData = {
        name: ""
      };

      this.originTableData = [];
      this.targetTableData = [];
      this.$refs.transferTable.clearData();
    },

    search() {
      this.getRightList();
    },

    getSelectedTableData() {
      return this.$refs.transferTable.getData().targetData || [];
    },

    show(targetData) {
      this.targetTableData = JSON.parse(JSON.stringify(targetData));
      this.getRightList();
      this.modal = true;
    },

    getRightList() {
      let params = {
        pageSize: -1,
        ...this.searchData
      };
      this.tableLoading = true;
      this.$http.get("common/getAllGroupsAndRules", params).then(res => {
        this.tableLoading = false;
        if (res.code === 20000) {
          this.originTableData = res.data.records;
        } else {
          this.$Message.error(`获取权限列表失败:${res.msg}`);
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
</style>

