<template>
  <div class="grid-content">
    <div class="help-icon">
      <Poptip placement="left-start" trigger="hover">
        <span style="font-size:12px;">帮助<Icon type="help-circled" style="font-size: 16px;vertical-align:text-bottom;"></Icon></span>
        <div slot="content">
          <p>
            <Icon type="checkmark-circled" style="color:green;"></Icon>&nbsp;&nbsp;已完成
          </p>
          <p>
            <Icon type="clock" style="color:#b38418e0;"></Icon>&nbsp;&nbsp;待完成
          </p>
          <p>
            <Icon type="close-circled" style="color:red;"></Icon>&nbsp;&nbsp;超过缓冲期未完成
          </p>
          <p>
            <Icon type="alert-circled" style="color:#695f5f;opacity:.6;"></Icon>&nbsp;&nbsp;已取消
          </p>
        </div>
      </Poptip>
    </div>
    <Tabs v-model="tabName" >
      <!-- 拜访人tab -->
      <TabPane name="visitor" label="拜访人">
        <!-- 搜索条件区域 -->
        <Form :model="formData" :label-width="80" @keydown.enter.native.prevent="visitorSearch">
          <div class="searchBox keydown-box">
            <Row type="flex" justify="center">
              <Col :xs="{ span: 7}" :lg="{ span: 6}">
              <FormItem label="拜访人">
                <div @click="showInnerModal" style="position:relative;" class="clearBox">
                  <Input v-model="innerMemberName" style="width:100%" placeholder="请选择拜访人" readonly clearable>
                  <div slot="append" @click="stopPropagation" style="width:100%;height:100%;">
                    <Dropdown trigger="click" @on-click="choseMyself">
                      <Icon type="arrow-down-b"></Icon>
                      <DropdownMenu slot="list">
                        <DropdownItem>自己</DropdownItem>
                      </DropdownMenu>
                    </Dropdown>
                  </div>
                  <!-- <Button  @click="choseMyself" slot="append">自己</Button> -->
                  </Input>
                  <div @click="stopPropagation" title="清除" v-show="innerMemberName">
                    <div class="clearAll" @click="clearAll">
                      <Icon type="ios-close-empty"></Icon>
                    </div>
                  </div>
                </div>
              </FormItem>
              </Col>
              <Col :xs="{ span: 9}" :lg="{ span: 6}">
              <FormItem label="拜访时间">
                <DatePicker type="daterange" :options="options" v-model="formData.visitTime" placeholder="请输入拜访时间" style="width:100%"></DatePicker>
              </FormItem>
              </Col>
              <Col :xs="{ span: 5}" :lg="{ span: 4}">
              <FormItem label="拜访类型">
                <Select v-model="visitTypeV" not-found-text='无匹配数据' clearable placeholder="请选择拜访类型" style="width:100%">
                  <Option v-for="item in typeList" :key="item.value" :label="item.name" :value="item.value">
                  </Option>
                </Select>
              </FormItem>
              </Col>
              <Col :xs="{ span: 3}" :lg="{ span: 4}">
              <Button type="primary" @click="visitorSearch()" style="height:30px;margin-left:20px;">搜索</Button>
              </Col>
            </Row>
          </div>
        </Form>
        <div v-loading="loading" element-loading-text="拼命加载中" style="border-top:1px solid #eeeeee;margin-top:-10px;">
          <div class="totalContainer">
            <span style="margin-right:20px;">当前拜访人:
                <Tooltip placement="bottom" >
                  <p  class="visitorObj">{{curretVisitor||"--"}}</p>
                  <span slot="content">{{curretVisitor||"--"}}</span>
            </Tooltip>
            </span>
            <span style="margin-right:20px;">拜访对象共<span style="font-weight:900;color:#f11;font-size:18px;">&nbsp;{{objTotal}}&nbsp;</span>人</span>
            <span>计划共<span style="font-weight:900;color:#f11;font-size:18px;">&nbsp;{{totalVisitor}}&nbsp;</span>条</span>
          </div>
          <div v-if="isEmpty(timeLineDataV)" class="time-line" style="text-align:center;height:300px;width:650px;margin:0 auto;">暂无数据</div>
          <div class="time-line" v-else>
            <Timeline pending>
              <TimelineItem v-for="(item,date) in timeLineDataV" :key="date">
                <!-- <Icon type="android-alarm-clock"></Icon> -->
                <Icon :type="item.iconType" slot="dot" :title="item.title" :style="item.iconColor"></Icon>
                <p class="content visitTime">{{item.visit_date.split(' ')[0]}}</p>
                <p class="content visitTimeHour">
                  {{item.visit_date.split(' ')[1]}}
                </p>
                <p class="content visitMember" style="">
                  <span class="content-title">拜访人：</span>
                  <span style="font-weight:900;">{{item.visit_member_name}}</span>
                </p>
                <!-- <div class="time-item-container" v-for="(item, index) in itemArr"> -->
                <p class="content">
                  <span class="content-title">计划标题：</span>
                  <span style="font-weight:900;">{{item.topic}}</span>
                </p>
                <Button class="shareButton" type="ghost" icon="eye" style="border:1px solid #2b85e4;color:#57a3f3;" @click="showPlan(item)">
                  查看
                </Button>
                <p class="content">
                  <span class="content-title">拜访对象：</span>
                  <template v-if="item.contacts_id">
                    <span style="font-weight:900;">{{item.contacts_name}}</span>
                    <span style="opacity: 0.85">({{getCompany(item).join(' ')}})</span>
                  </template>
                  <template v-else>
                    <span>无</span>
                  </template>
                  </span>
                </p>
                <P class="content">
                  <span class="content-title">拜访类型：</span>
                  <span>
                        <Tag>{{getType(item.visit_type)}}</Tag>
                    </span>
                </P>
                <p class="content" v-show="getDemands(item.demand_ids)">
                  <span class="content-title">需&nbsp;&nbsp;求&nbsp;&nbsp;点：</span>
                  <Tag v-for="(item,index) in getDemands(item.demand_ids)" :key="index">{{item}}</Tag>
                </p>
                <p class="content" v-show="getChats(item.chat_ids)">
                  <span class="content-title">交谈内容：</span>
                  <Tag v-for="(item,index) in getChats(item.chat_ids)" :key="index">{{item}}</Tag>
                </p>
                <div class="content" style="width:600px;">
                  <span style="width:20%;vertical-align:top;" class="content-title">备忘提醒：</span>
                  <p style="line-height:24px;display:inline-block;width:80%;font-weight:900;">{{item.plan_content||"无"}}</p>
                </div>
                <!--  <P class="content">
                  <span class="content-title">计划状态：</span>
                  <span>{{item.status === 2 ? '已完成' : '未完成'}}</span>
                </P> -->
                <!-- </div> -->
              </TimelineItem>
              <TimelineItem>
                <p>已经是最后一条了！</p>
              </TimelineItem>
            </Timeline>
          </div>
        </div>
      </TabPane>
      <!-- 拜访对象tab -->
      <TabPane name="obj" label="拜访对象">
        <!-- 搜索条件区域 -->
        <Form :model="formDataObj" :label-width="80" @keydown.enter.native.prevent="objSearch">
          <div class="searchBox keydown-box">
            <Row type="flex" justify="center">
              <Col :xs="{ span: 7}" :lg="{ span: 6}">
              <FormItem label="拜访对象">
                <Poptip placement="bottom-start" width="400" @on-ok="getChosenNode" confirm cancel-text="">
                  <Input v-model.trim="outerKeywords" :placeholder="searchType==2?'请输入关键字,如:总部 分部':'请输入关键字'" style="width:100%;" @input="getOuterList">
                  <div @click="stopPropagation" slot="append">
                    <Select v-model="searchType" style="width: 60px">
                      <Option value="2">机构</Option>
                      <Option value="3">人物</Option>
                    </Select>
                  </div>
                  </Input>
                  <div slot="title">
                    <Spin fix v-if="outerListLoading">
                      <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
                      <div>加载中...</div>
                    </Spin>
                    <div v-else>
                      <div v-if="!outerList.length" style="text-align:center;">暂无数据</div>
                      <div v-for="(item,index) in outerList" :key="index" :class="{outerUserList:index%2==0}" style="padding:8px;" v-else>
                        <!-- <Tree :data="[item]" multiple show-checkbox empty-text="暂无数据" :ref="`tree${index}`"></Tree> -->
                        <el-tree :data="[item]" show-checkbox node-key="id" :ref="`tree${index}`" :auto-expand-parent="true" :props="defaultProps">
                        </el-tree>
                      </div>
                    </div>
                  </div>
                </Poptip>
              </FormItem>
              </Col>
              <Col :xs="{ span: 9}" :lg="{ span: 6}">
              <FormItem label="拜访时间">
                <DatePicker type="daterange" :options="options" style="width:100%;" v-model="formDataObj.visitTime" placeholder="请输入拜访时间"></DatePicker>
              </FormItem>
              </Col>
              <Col :xs="{ span: 5}" :lg="{ span: 5}">
              <FormItem label="拜访类型">
                <Select v-model="visitTypeO" not-found-text='无匹配数据' clearable placeholder="请选择拜访类型" style="width:100%;">
                  <Option v-for="item in typeList" :key="item.value" :label="item.name" :value="item.value">
                  </Option>
                </Select>
              </FormItem>
              </Col>
              <Col :xs="{ span: 3}" :lg="{ span: 3}">
              <Button type="primary" @click="objSearch()" style="height:30px;margin-left:20px;">搜索</Button>
              </Col>
            </Row>
          </div>
        </Form>
        <div v-loading="loading" element-loading-text="拼命加载中" style="border-top:1px solid #eeeeee;margin-top:-10px;">
          <div class="totalContainer">
            <span style="margin-right:20px;">拜访对象：
                  <Tooltip placement="bottom" v-if="!outerList.length">
                     <p  class="visitorObj">{{chosenOuterName?chosenOuterName.join(","):"--"}}</p>
                     <p  slot="content">{{chosenOuterName?chosenOuterName.join(","):"--"}}</p>
                  </Tooltip>
                  <Tooltip  placement="bottom" v-else>
                    <p class="visitorObj" >
                        <span v-for="(item,index) in this.deptName" :key="index">
                          <span>{{item.depts||"- -"}}</span>
            <span>{{item.staffs?item.staffs.join(","):"- -"}}</span>
            </span>
            </p>
            <div slot="content">
              <p>
                <span v-for="(item,index) in this.deptName" :key="index" style="padding:10px 5px;display:block; border-bottom:1px dashed #ccc; " :class="{withoutDashed:index ==(deptName.length-1)}">
                          <span>部门：{{item.depts}}</span>
                <br>
                <p v-show="item.staffs.join(',')">员工：{{item.staffs?item.staffs.join(","):"- -"}}</p>
                </span>
              </p>
            </div>
            </Tooltip>
            </span>
            <span>计划共<span style="font-weight:900;color:#f11;font-size:18px;">&nbsp;{{totalObj}}&nbsp;</span>条</span>
          </div>
          <div v-if="isEmpty(timeLineDataO)" class="time-line" style="text-align:center;height:300px;width:650px;margin:0 auto;">暂无数据</div>
          <div class="time-line obj-time-line" v-loading="loading" v-else>
            <Timeline pending>
              <TimelineItem v-for="(item,date) in timeLineDataO" :key="date">
                <Icon :type="item.iconType" slot="dot" :title="item.title" :style="item.iconColor"></Icon>
                <p class="content visitTime">{{item.visit_date.split(' ')[0]}}</p>
                <p class="content visitTimeHour">
                  {{item.visit_date.split(' ')[1]}}
                </p>
                <p class="content visitMember"><span class="content-title">拜访人：</span><span style="font-weight:900;">{{item.visit_member_name}}</span></p>
                <p class="content">
                  <span class="content-title">计划标题：</span>
                  <span style="font-weight:900;">{{item.topic}}</span>
                </p>
                <p class="content">
                  <span class="content-title">拜访对象：</span>
                  <template v-if="item.contacts_id">
                    <span style="font-weight:900;">{{item.contacts_name}}</span>
                    <span style="opacity: 0.85">({{getCompany(item).join(' ')}})</span>
                  </template>
                  <template v-else>
                    <span>无</span>
                  </template>
                </p>
                <P class="content">
                  <span class="content-title">拜访类型：</span>
                  <span>
                        <Tag>{{getType(item.visit_type)}}</Tag>
                    </span>
                </P>
                <p class="content" v-show="getDemands(item.demand_ids)">
                  <span class="content-title">需&nbsp;&nbsp;求&nbsp;点：</span>
                  <Tag v-for="(item,index) in getDemands(item.demand_ids)" :key="index">{{item}}</Tag>
                </p>
                <p class="content">
                  <span class="content-title">意&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;向：</span>
                  <Tag>{{getIntention(item.intention_type)}}</Tag>
                </p>
                <p class="content" v-show="getChats(item.chat_ids)">
                  <span class="content-title">交谈内容：</span>
                  <Tag v-for="(item,index) in getChats(item.chat_ids)" :key="index">{{item}}</Tag>
                </p>
                <p class="content" style="max-width:600px;">
                  <span class="content-title">备忘提醒：</span>
                  <span style="line-height:30px;font-weight:900;">{{item.visit_content||"无"}}</span>
                </p>
                <!-- </div> -->
              </TimelineItem>
              <TimelineItem>
                <p>已经是最后一条了！</p>
              </TimelineItem>
            </Timeline>
          </div>
        </div>
      </TabPane>
    </Tabs>
    <innermodal ref="innerModal" @getInnerPeople="getInnerPeople"></innermodal>
    <plan-modal ref="planModal" @reload="reload"></plan-modal>
  </div>
</template>
<script>
import moment from "moment";
import { mapGetters } from "vuex";
import { fetchUser, fetchGrid } from "@/service/getData";
import _ from "lodash";
import $ from "jquery";
import innermodal from "../visit-record-view/chooseInnerPersonModal";
import planModal from "../visit-plan-personal/plan-modal";

export default {
  components: {
    innermodal,
    planModal
  },

  data() {
    return {
      defaultProps: {
        children: "children",
        label: "title"
      },
      visitTypeO: "",
      visitTypeV: "",
      typeList: [],
      deptName: "",
      id: "",
      chosenOuterName: [],
      outerListLoading: false,
      searchType: "",
      outerKeywords: "",
      innerMemberids: [], // **
      innerMemberName: "", // **
      outerMemberids: [], //选中的客户id
      outerMemberName: [], // 选中的客户姓名
      objTotal: "",
      curretObject: "",
      outerList: [],
      options: {
        shortcuts: [
          {
            text: "全部",
            value() {
              return [];
            }
          },
          {
            text: "最近一周",
            value() {
              let now = new Date();
              let nowAtZero = new Date(
                now.getTime() -
                  now.getHours() * 3600 * 1000 -
                  now.getMinutes() * 60 * 1000 -
                  now.getMilliseconds()
              );
              nowAtZero = new Date(nowAtZero.getTime() + 8 * 3600 * 1000);
              let timeBeforeAweek = new Date(
                nowAtZero.getTime() - 7 * 24 * 3600 * 1000
              );
              return [timeBeforeAweek, nowAtZero];
            }
          },
          {
            text: "最近一月",
            value() {
              let now = new Date();
              let nowAtZero = new Date(
                now.getTime() -
                  now.getHours() * 3600 * 1000 -
                  now.getMinutes() * 60 * 1000 -
                  now.getMilliseconds()
              );
              nowAtZero = new Date(nowAtZero.getTime() + 8 * 3600 * 1000);
              let timeBeforeAMonth = new Date(
                nowAtZero.getTime() - 31 * 24 * 3600 * 1000
              );
              return [timeBeforeAMonth, nowAtZero];
            }
          }
        ]
      },
      curretVisitor: "",
      customers: [],
      tabName: "visitor",
      totalVisitor: 0,
      totalObj: 0,
      loading: false,
      intention: [],
      demands: [],
      chats: [],
      // 拜访人数据
      timeLineDataV: [],
      // 拜访对象展示数据
      timeLineDataO: [],
      //   拜访人搜索数据
      formData: {
        visitor: [],
        visitTime: ""
      },
      //   拜访对象搜索数据
      formDataObj: {
        visitor: "",
        visitTime: ""
      },
      // 用户列表
      userList: []
    };
  },

  watch: {
    "formData.visitTime": {
      handler(val) {
        if (val && val[0]) {
          this.formData.visitTime[0] = this.setTimeZone(val[0]);
          this.formData.visitTime[1] = this.setTimeZone(val[1]);
        }
      },
      deep: true
    },
    "formDataObj.visitTime": {
      handler(val) {
        if (val && val[0]) {
          this.formDataObj.visitTime[0] = this.setTimeZone(val[0]);
          this.formDataObj.visitTime[1] = this.setTimeZone(val[1]);
        }
      },
      deep: true
    }
  },
  computed: {
    ...mapGetters({
      enums: "getEnums"
    }),
    maxCacheTime() {
      return this.enums.c_max_exec_time[0].value;
    }
  },

  mounted() {
    this.$nextTick(() => {
      this.searchType = "2";
    });
    this.setDefaultTime();
    // 获取真实字段
    // this.getTrueType();
    this.intention = this.enums.c_intention;
    this.demands = this.enums.c_demand;
    this.chats = this.enums.c_chat_content;
    this.typeList = this.enums.c_visit_type;
    this.$nextTick(() => {
      this.getCurrentUser().then(currentUser => {
        this.innerMemberids = [currentUser.id];
        this.innerMemberName = currentUser.name;
        this.curretVisitor = currentUser.name;
        this.formData.visitor = currentUser.id;
        this.visitorSearch();
      });
    });
    this.setMaxHeightOfFixedTable(
      ".content-body",
      [".ivu-tabs-nav-scroll", ".searchBox", ".totalContainer"],
      ".time-line"
    );
    this.setMaxHeightOfFixedTable(
      ".content-body",
      [".ivu-tabs-nav-scroll", ".searchBox", ".totalContainer"],
      ".time-line.obj-time-line"
    );
  },
  methods: {
    setKeyDownEvent() {
      if (this.tabName == "visitor") {
        this.visitorSearch();
      } else {
        this.objSearch();
      }
    },
    //重新加载页面
    reload() {
      this.visitorSearch();
    },
    // 变更时间为格林威治时区标准
    setTimeZone(time) {
        let localTime =  moment(time).format('YYYY-MM-DD')
      return localTime;
    },

    //获取机构名称和部门
    getDeptName() {
      let chosenObjs = [];
      let chosenObj = {
        bread: [],
        id: "",
        org_name_selected: "",
        name: "",
        org_id: ""
      };
      //   this.timeLineDataO.forEach(item => {
      //     if (item.contacts_id != chosenObj.id) {
      //       chosenObj.name = item.contacts_name;
      //       chosenObj.id = item.contacts_id;
      //       chosenObj.org_name_selected = item.org_name_selected;
      //       chosenObj.bread = item.bread;
      //       chosenObj.org_id = item.org_id;
      //       chosenObjs.push(JSON.parse(JSON.stringify(chosenObj)))
      //     }
      //   });
      // };
      this.timeLineDataO.forEach(item => {
        if (item.contacts_id != chosenObj.id) {
          chosenObj.name = item.contacts_name;
          chosenObj.id = item.contacts_id;
          chosenObj.org_name_selected = item.org_name_selected;
          chosenObj.bread = item.bread;
          chosenObj.org_id = item.org_id;
          chosenObjs.push(JSON.parse(JSON.stringify(chosenObj)));
        }
      });
      this.getFinalNames(chosenObjs);
    },

    getCompany(item) {
      let componyNameList = item.bread
        .filter((data, index) => {
          return index != 0;
        })
        .map(data => {
          return data.title;
        });
      return componyNameList;
    },

    // 将人按部门划分
    getFinalNames(data) {
      let deptsAndStaffsArr = [];
      let deptsArr = [];
      let deptsAndStaffs = {
        depts: "",
        staffs: ""
      };
      let depts = {
        depts: ""
      };
      data.forEach(item => {
        item.bread.shift();
        // 全选时只要部门
        if (item.org_name_selected) {
          depts.depts = item.bread
            .map(item => {
              return item.title;
            })
            .join(",");
          deptsArr.push(JSON.parse(JSON.stringify(depts)));
        } else {
          deptsAndStaffs.depts = item.bread
            .map(item => {
              return item.title;
            })
            .join(",");
          deptsAndStaffs.staffs = item.name;
          deptsAndStaffsArr.push(JSON.parse(JSON.stringify(deptsAndStaffs)));
        }
      });
      this.abandonSameDept(deptsArr, deptsAndStaffsArr);
    },

    abandonSameDept(depts, deptsAndStaffs) {
      let deptsAndNames = depts.concat(deptsAndStaffs);
      let deptNamesAll = deptsAndNames.map(item => item.depts);
      // 去重
      let deptNames = this.getUnrepeated(deptNamesAll);
      let finalDeptsAndNames = [];
      deptNames.forEach(item => {
        let singleObj = {
          depts: "",
          staffs: []
        };
        if (singleObj.depts != item) {
          singleObj.depts = item;
        }
        deptsAndNames.forEach(data => {
          if (data.depts == singleObj.depts) {
            singleObj.staffs.push(data.staffs);
          }
        });
        finalDeptsAndNames.push(JSON.parse(JSON.stringify(singleObj)));
      });
      finalDeptsAndNames.forEach(item => {
        item.staffs = this.getUnrepeated(item.staffs);
      });
      this.deptName = finalDeptsAndNames;
    },

    // 去重
    getUnrepeated(item) {
      let res = [];
      let json = {};
      for (let i = 0; i < item.length; i++) {
        if (!json[item[i]]) {
          res.push(item[i]);
          json[item[i]] = 1;
        }
      }
      return res;
    },

    // 阻止冒泡
    stopPropagation(e) {
      e.stopPropagation();
    },

    // 清除所有
    clearAll() {
      this.$nextTick(() => {
        this.innerMemberids = [];
        this.innerMemberName = "";
        this.curretVisitor = "";
        this.formData.visitor = [];
        this.timeLineDataV = [];
        this.objTotal = 0;
        this.totalVisitor = 0;
      });
    },

    // 选到自己
    choseMyself(e) {
      // e.stopPropagation();
      this.$nextTick(() => {
        this.getCurrentUser().then(currentUser => {
          this.innerMemberids = [currentUser.id];
          this.innerMemberName = currentUser.name;
          this.curretVisitor = currentUser.name;
          this.formData.visitor = currentUser.id;
          this.visitorSearch();
          // });
        });
      });
    },

    //设置最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 107;
      targetTable.css("maxHeight", maxHeight + "px");
    },

    // 显示分享模态框
    showShareModal(visitData) {
      let data = JSON.parse(JSON.stringify(visitData));
      this.$refs.share.show(data);
    },

    // 获取选定的节点
    getChosenNode() {
      this.outerMemberids = [];
      this.outerMemberName = [];
      let nodes = [];
      this.outerList.forEach((item, index) => {
        let tree = `tree${index}`;
        if (this.$refs[tree][0].getCheckedNodes().length) {
          nodes = nodes.concat(this.$refs[tree][0].getCheckedNodes());
        }
      });

      // 获取人的信息
      let people = nodes.filter(item => {
        return item.type == 2;
      });

      // 获取id和人名
      people.forEach(item => {
        this.outerMemberids.push(item.id);
        this.outerMemberName.push(item.title);
      });
    },

    // 获取外部部门列表
    getOuterList() {
      this.outerList = [];
      if (!this.outerKeywords) {
        return;
      }
      let outerKeywords = this.outerKeywords.trim().split(/[ ]+/);
      let params = {
        type: this.searchType,
        keywords: outerKeywords
      };
      this.outerListLoading = true;
      clearTimeout(this.id);
      this.id = setTimeout(() => {
        fetchGrid("visit/gettreebytype", params).then(res => {
          this.outerList = res.data;
          this.outerListLoading = false;
        });
      }, 800);
    },

    // 获取选定的内部员工**由子组件传递过来
    getInnerPeople(people) {
      let ids = [];
      let names = [];
      people.forEach(item => {
        ids.push(item.id);
        names.push(item.name);
      });
      this.innerMemberids = ids;
      this.innerMemberName = names.join(",");
    },

    // 显示选择内部员工的模态框**
    showInnerModal() {
      this.$refs.innerModal.modalShow(this.innerMemberids);
    },

    // 设置默认时间
    setDefaultTime() {
      let now = new Date();
      let nowAtZero = new Date(
        now.getTime() -
          now.getHours() * 3600 * 1000 -
          now.getMinutes() * 60 * 1000 -
          now.getMilliseconds()
      );
      nowAtZero = new Date(this.setTimeZone(nowAtZero));
      let timeBeforeAweek = new Date(
        nowAtZero.getTime() - 7 * 24 * 3600 * 1000
      );
      this.formData.visitTime = [timeBeforeAweek, nowAtZero];
      this.formDataObj.visitTime = [timeBeforeAweek, nowAtZero];
    },

    // 获取系统的当前用户
    getCurrentUser() {
      return new Promise(resolve => {
        fetchUser().then(resp => {
          let currentUser = {
            name: resp.data.trueName,
            id: resp.data.id
          };
          resolve(currentUser);
        });
      });
    },

    // 获取拜访类型
    getType(params) {
      let type = _.get(
        _.filter(this.typeList, data => {
          return data.value == params;
        })[0],
        "name"
      );
      return type;
    },

    // 获取意向真实字段
    getIntention(params) {
      let intention = _.get(
        _.filter(this.intention, data => {
          return data.value == params;
        })[0],
        "name"
      );
      return intention;
    },

    // 获取交谈内容真实字段
    getChats(params) {
      let param = [];
      if (params) {
        param = JSON.parse(params);
      } else {
        return;
      }
      let chat = [];
      let chats = [];
      chat = this.chats.filter(item => {
        return param.indexOf(item.value) != -1;
      });
      chats = chat.map(item => item.name);
      return chats;
    },

    // 获取需求点真实字段
    getDemands(params) {
      let param = [];
      if (params) {
        param = JSON.parse(params);
      } else {
        return;
      }
      let demand = [];
      let demands = [];
      demand = this.demands.filter(item => {
        return param.indexOf(item.value) != -1;
      });
      demands = demand.map(item => {
        return item.name;
      });
      return demands;
    },

    // 拜访人界面搜索事件
    visitorSearch() {
      // 没有选择时间时，置空时间参数
      if (!this.formData.visitTime[0]) {
        this.formData.visitTime = [];
      }
      this.curretVisitor = this.innerMemberName;
      let params = {
        visit_date: this.formData.visitTime,
        visit_member: this.innerMemberids,
        sortKey: "visit_date",
        sortOrder: "desc",
        visit_type: this.visitTypeV,
        rows: -1
      };
      this.getList(params, "visitor");
    },

    // 拜访对象界面搜索事件
    objSearch() {
      // 没有选择拜访对象，不能进行搜索
      if (!this.outerMemberids.length) {
        this.$Message.warning("请先选择拜访对象！");
        return;
      }
      this.chosenOuterName =
        JSON.parse(JSON.stringify(this.outerMemberName)) || [];
      // 没有选择时间，置空时间
      if (!this.formDataObj.visitTime[0]) {
        this.formDataObj.visitTime = [];
      }
      let params = (params = {
        visit_time: this.formDataObj.visitTime,
        contacts_id: this.outerMemberids,
        sortKey: "visit_date",
        sortOrder: "desc",
        visit_type: this.visitTypeO,
        rows: -1
      });
      this.getList(params, "Obj");
    },
    // 设置拜访计划的状态
    setPlanStatusIcon(time, status, isvalid) {
      let now = new Date().getTime();
      let planTime = new Date(time).getTime() + this.maxCacheTime * 3600 * 1000;
      if (!isvalid) {
        return {
          title: "已取消",
          iconType: "alert-circled",
          iconColor: "color:#695f5f;font-weight:900;opacity:.6;cursor:pointer;"
        };
      }
      // 待完成
      if (planTime > now && status == 1) {
        return {
          title: "待完成",
          iconType: "clock",
          iconColor: "color:#b38418e0;font-weight:900;cursor:pointer;"
        };
      } else if (planTime < now && status == 1) {
        // 未完成
        return {
          title: "未完成",
          iconType: "close-circled",
          iconColor: "color:red;cursor:pointer;"
        };
      } else {
        // 已完成
        return {
          title: "已完成",
          iconType: "checkmark-circled",
          iconColor: "color:green;cursor:pointer;"
        };
      }
    },
    // 获取拜访记录列表
    getList(params, type) {
      this.loading = true;
      fetchGrid("plan/getList", params).then(res => {
        if (type == "visitor") {
          // this.timeLineDataV = res.data.data;
          let data = res.data.data;
          data.forEach(item => {
            _.assign(
              item,
              this.setPlanStatusIcon(item.visit_date, item.status, item.isvalid)
            );
            item.visit_date = moment(`${item.visit_date}`).format(
              "YYYY-MM-DD HH:mm"
            );
          });
          this.timeLineDataV = JSON.parse(JSON.stringify(data));
          // console.log(this.timeLineDataV);
          // this.timeLineDataV = _.groupBy(data, item => {
          //   return item.visit_date.split(" ")[0];
          // });
          let timeData = JSON.parse(JSON.stringify(this.timeLineDataV));
          let contacts_ids = timeData.map(item => item.contacts_id);
          let unRepeatedArr = [];
          contacts_ids.forEach((item, index) => {
            if (unRepeatedArr.indexOf(item) == -1) {
              unRepeatedArr.push(item);
            }
          });
          this.objTotal = unRepeatedArr.length;
          this.totalVisitor = res.data.total;
        } else {
          let data = res.data.data;
          data.forEach(item => {
            _.assign(
              item,
              this.setPlanStatusIcon(item.visit_date, item.status, item.isvalid)
            );
            item.visit_date = moment(`${item.visit_date}`).format(
              "YYYY-MM-DD HH:mm"
            );
          });
          data;
          this.timeLineDataO = JSON.parse(JSON.stringify(data));
          // let data = res.data.data;
          // this.timeLineDataO = _.groupBy(data, item => {
          //   return item.visit_date.split(" ")[0];
          // });
          this.totalObj = res.data.total;
          this.getDeptName();
        }
        this.loading = false;
      });
    },
    showPlan(item) {
      let cancelOrRecovery = item.isvalid == 1 ? "cancel" : "recovery";
      let isShowEdit;
      let now = new Date().getTime();
      let planTime = new Date(item.visit_date).getTime();
      if (item.status === 1 && planTime > now) {
        // 待完成
        isShowEdit = true;
      } else if (item.status === 1 && planTime < now) {
        // 未完成
        isShowEdit = false;
      } else {
        isShowEdit = false;
      }
      this.$refs.planModal.show(
        "edit",
        item.id,
        item.visit_date,
        isShowEdit,
        cancelOrRecovery,
        item.isvalid,
        item.status
      );
    },
    isEmpty(data) {
      return _.isEmpty(data);
    }
  }
};
</script>
<style lang="less" scoped>
.grid-content {
  // padding-top: 15px;
  margin: 0 auto;
  position: relative;
  .searchBox {
    // width: 85%;
    // margin: 0 auto; // display: flex;
    // justify-content: center;
  }
}

.time-line {
  margin-top: 10px;
  position: relative;
  max-height: 500px;
  overflow-y: auto;
  overflow-x: hidden;
  .content {
    padding: 5px;
    font-size: 13px;
  }
  .visitTime {
    position: absolute;
    left: -150px;
    font-weight: 900;
    width: 130px;
    text-align: right;
    right: 5px;
  }
  .visitTimeHour {
    position: absolute;
    top: 30px;
    left: -150px;
    font-weight: 900;
    width: 130px;
    text-align: right;
    right: 5px;
  }
  .visitMember {
    position: absolute;
    top: 60px;
    left: -150px;
    width: 130px;
    text-align: right;
    right: 5px;
  }
  .content-title {
    color: #aab3ca;
  }
}

.ivu-cascader-menu {
  min-width: 100px;
}

.totalContainer {
  // margin:0 auto;
  height: 35px;
  line-height: 35px;
  padding: 2px;
  border-radius: 10px;
  background-color: #f5f5f5;
  width: 100%;
  text-align: center;
  margin-top: 15px;
}

.shareButton {
  position: absolute;
  top: 10px;
  right: 5px;
}

.itemColor {
  background-color: #f1f1f1;
}

.outerUserList {
  background-color: #f1f1f1;
}

.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}

@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.visitorObj {
  // display: inline-block;
  line-height: 18px;
  position: relative;
  top: 5px;

  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  max-width: 100px;
  cursor: pointer;
  font-weight: 900;
  font-size: 12px;
}

.clearAll {
  cursor: pointer;
  position: absolute;
  right: 30px;
  top: 35%;
  border-radius: 50%;
  width: 14px;
  height: 14px;
  line-height: 14px;
  text-align: center;
  color: #f0f4ff;
  background-color: #80848f;
  opacity: 0.85;
  z-index: 9999999;
  font-size: 14px;
  display: none;
}

.clearBox {
  &:hover {
    .clearAll {
      display: block;
    }
  }
}

.withoutDashed {
  border: none !important;
}

.ivu-timeline-item:nth-child(odd) {
  background-color: #f1f1f1;
}

.time-item-container {
  padding: 10px 0;
  position: relative;
  & + .time-item-container {
    position: relative;
    &:before {
      content: "";
      display: block;
      border-top: 1px dashed #666;
      width: 99%;
      position: absolute;
      top: -2px;
    }
  }
}

.help-icon {
  z-index: 999999999;
  position: absolute;
  right: 20px;
  top: 0px;
  color: #2d8cf0;
  z-index:1;
}

.staus-line {
  border-bottom: 1px dashed #ccc;
  padding: 5px 0;
}
</style>
