<template>
  <Modal class="transmit-modal" title="添加账号" v-model="modal" :mask-closable="false" width="1000">
    <div slot="footer">
      <Button type="default" @click="hide">关闭</Button>
      <Button type="primary" @click="ok" :loading="btnLoading">确定</Button>
    </div>

    <div slot="close" @click="hide">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <Form ref="form" :model="formData" :rules="validateRules" :label-width="90">
      <!-- <Row>
              <Col span="12">
                  <FormItem label="公司名称">
                      <span>{{companyInfo.companyName||"--"}}</span>
                  </FormItem>
              </Col>

              <Col span="12">
                  <FormItem label="公司简称">
                      <span>{{companyInfo.companyShortName||"--"}}</span>
                  </FormItem>
              </Col>

              <Col span="12">
                  <FormItem label="备案编码">
                      <span>{{companyInfo.registerNumber||"--"}}</span>
                  </FormItem>
              </Col>

              <Col span="12">
                  <FormItem label="成立日期">
                      <span>{{companyInfo.establishDate||"--"}}</span>
                  </FormItem>
              </Col>

              <Col span="12">
                  <FormItem label="所在地区">
                      <span>{{companyInfo.city||"--"}}</span>
                  </FormItem>
              </Col>

      </Row>-->
      <Row>
        <Col span="12" class="visit-card">
          <FormItem prop="visitingCardUrl" label="名片">
            <Upload
              v-loading="imgLoading"
              element-loading-text="上传中，请稍候"
              :show-upload-list="false"
              ref="upload"
              accept="image/*"
              action="api/common/uploadFile"
              :before-upload="beforeUpload"
              style="display: inline-block;width:362px;height:214px;border:1px dotted #ccc;"
              :data="{fileType:'visitingCard'}"
            >
              <div class="upload-list-img" v-if="imgUrl">
                <img :src="imgUrl" :alt="formData.linkMan+'名片'"  @click="onPreviewCard">
                <div class="upload-list-cover">
                  <div class="change-button" title="更换名片">
                    <Icon type="ios-cloud-upload"></Icon>
                  </div>
                  <div class="preview-button" @click="onPreviewCard" title="预览">
                    <Icon type="ios-eye-outline"></Icon>
                  </div>
                  <div class="delete-button" @click="onUploadsRemove" title="删除名片">
                    <Icon type="ios-trash-outline"></Icon>
                  </div>
                </div>
              </div>

              <div v-else class="upload-button-container" title="上传名片">
                <Icon type="camera" size="20"></Icon>
              </div>
            </Upload>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="姓名" prop="linkMan">
            <Input v-model="formData.linkMan" placeholder="请输入姓名"></Input>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="性别" prop="sex">
            <Select clearable v-model="formData.sex" placeholder="请选择性别">
              <Option
                v-for="item in genderOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="手机号码" prop="mobile">
            <Input @on-change="ifHasAccount" v-model="formData.mobile" placeholder="请输入手机号码"></Input>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="职务" prop="position">
            <Input v-model.trim="formData.position" placeholder="请输入职务"/>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="初始密码" prop="initPsw">
            <Input v-model="formData.initPsw" :placeholder="passwordPlaceholder" disabled></Input>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="账号状态" prop="status">
            <Select v-model="formData.status" transfer>
              <Option
                v-for="(item,index) in statusMapping"
                :key="index"
                :value="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <Row>
            <Col span="8">
              <FormItem label="管理员">
                <Checkbox :true-value="1" :false-value="0" v-model="formData.isAdmin">是</Checkbox>
              </FormItem>
            </Col>

            <Col span="8">
              <FormItem label="短信通知">
                <Checkbox :true-value="1" :false-value="0" v-model="formData.ifNotice">是</Checkbox>
              </FormItem>
            </Col>

            <Col span="8">
              <FormItem label="私募直连">
                <Checkbox :true-value="1" :false-value="0" v-model="formData.fundLink">开通</Checkbox>
              </FormItem>
            </Col>
          </Row>
        </Col>

        <Col span="12">
          <FormItem label="业务类型" prop="businessType">
            <Select v-model="formData.businessType" transfer clearable>
              <Option
                v-for="(item ,index ) in businessTypeOptions"
                :key="index"
                :value="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="推荐人">
            <Select v-model="formData.recommenderId" transfer clearable>
              <Option
                v-for="(item ,index ) in recommenderList"
                :key="index"
                :value="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>
      </Row>
    </Form>
  </Modal>
</template>

<script>
let timer = null;
import uglifyPic from "@/mixins/condensePic";
import clearData from "@/mixins/clearData.js";
export default {
  mixins: [clearData, uglifyPic],

  data() {
    return {
      genderOptions: [
        {
          label: "男",
          value: 1
        },
        {
          label: "女",
          value: 2
        },
        {
          label: "未知",
          value: -1
        }
      ],
      businessTypeOptions: [
        {
          label: "私募",
          value: 1
        },
        {
          label: "信托",
          value: 2
        },
        {
          label: "券商",
          value: 3
        },
        {
          label: "期货",
          value: 4
        },
        {
          label: "银行",
          value: 5
        }
      ],
      imgUrl: "",
      imgLoading: false,
      btnLoading: false,
      hasPassword: false,
      companyId: "",
      passwordPlaceholder: "初始密码",
      modal: false,
      companyInfo: {
        companyName: "",
        companyShortName: "",
        registerNumber: "",
        establishDate: "",
        city: ""
      },
      formData: {
        linkMan: "",
        mobile: "",
        initPsw: "",
        isAdmin: 0,
        ifNotice: 0,
        visitingCardUrl: "",
        recommenderId: "",
        status: 1,
        position: "",
        fundLink: 0,
        sex: ""
      },
      recommenderList: []
    };
  },

  computed: {
    validateRules() {
      return {
        linkMan: [{ required: true, message: "姓名不能为空" }],
        mobile: [
          { required: true, message: "手机号码不能为空" },
          {
            pattern: /^1(3|4|5|6|7|8|9)\d{9}$/,
            message: "格式不正确"
          }
        ],
        visitingCardUrl: {
          required: true,
          message: "名片不能为空"
        },
        status: {
          required: true,
          message: "账号状态不能为空"
        },
        position: {
          required: true,
          message: "职务不能为空"
        },
        sex: {
          required: true,
          message: "性别不能为空"
        },
        businessType: {
          required: true,
          message: "业务类型不能为空"
        }
      };
    },

    statusMapping() {
      return [
        {
          label: "正常",
          value: 1
        },
        {
          label: "禁用",
          value: 2
        },
        {
          label: "离职",
          value: 3
        },
        {
          label: "删除",
          value: 4
        }
      ];
    }
  },

  watch: {
    // hasPassword: {
    //   handler(val) {
    //     if (!val) {
    //       this.$set(this.formData, "initPsw", this.randomPassword());
    //     } else {
    //       this.passwordPlaceholder = "该手机号已绑定官网账号，无需设置密码";
    //       this.$set(this.formData, "initPsw", "");
    //     }
    //   },
    //   deep: true
    // }
  },

  created() {},

  methods: {
    // 获取推荐人列表

    getRecommenderList() {
      let params = {
        dept_id: 1,
        type: 1
      };

      this.$http.get("dept/getUserByDept", params).then(res => {
        if (res.code === 20000) {
          this.recommenderList = res.data;
        } else {
          this.$Message.error("获取推荐人列表失败！");
        }
      });
    },

    // 上传之前先清空,保证只能上传最后一条文件
    beforeUpload(file) {
      this.$refs.upload.clearFiles();
      this.imgLoading = true;
      this.uglifyPic(file, "form", "formData", "visitingCardUrl");
      return false;
    },

    // 点击文件 预览
    onPreviewCard(e) {
      e.stopPropagation();
      e.preventDefault();
      window.open(`${this.imgUrl}`);
      return false;
    },

    //  移除上传附件
    onUploadsRemove(e) {
      e.stopPropagation();
      e.preventDefault();
      this.formData.visitingCardUrl = "";
      this.$refs.upload.clearFiles();
      this.imgUrl = "";
      this.$refs.form.validateField("visitingCardUrl");
      return false;
    },

    getImgUrl(path) {
      let url;
      let picUrl = path;
      if (path.includes("/Onstage/")) {
        url =
          process.env.NODE_ENV === "production" ||
          process.env.NODE_ENV === "test"
            ? "https://fof.simuwang.com/"
            : "https://master-test.simuwang.com/";
      } else {
        url =
          process.env.NODE_ENV === "production"
            ? " http://static.simuwang.com/"
            : "https://static-test-ali.simuwang.com/";
        picUrl = `Uploads/crm/${path}`;
      }
      this.imgUrl = `${url}${picUrl}`;
    },

    show(companyInfo = {}, companyId, contactInfo = {}) {
      this.companyId = companyId;
      this.companyInfo = JSON.parse(JSON.stringify(companyInfo));
      let keys = ["linkMan", "mobile", "position", "visitingCardUrl", "sex"];
      keys.forEach(key => {
        if (contactInfo[key]) {
          this.$set(this.formData, key, contactInfo[key]);
        }
      });
      if (this.formData.sex && this.formData.sex == 3) {
        this.formData.sex = -1;
      }
      this.getImgUrl(this.formData.visitingCardUrl);
      let data = {
        target: {
          value: this.formData.mobile
        }
      };
      this.ifHasAccount(data);
      this.modal = true;
      this.getRecommenderList();
    },

    hide() {
      this.modal = false;
      this.reset();
    },

    ifHasAccount(e) {
      let val = e.target.value;
      this.$refs.form.validateField("mobile", valid => {
        if (!valid) {
          clearTimeout(timer);
          timer = setTimeout(() => {
            let params = {
              mobile: val
            };
            this.$http
              .get("FmAccount/status", params)
              .then(res => {
                if (res.code === 20000) {
                  if (res.data.accStatus == 1 || res.data.accStatus == 2) {
                    this.passwordPlaceholder =
                      "该手机号已绑定官网账号，无需设置密码";
                    this.$set(this.formData, "initPsw", "");
                  } else {
                    this.$set(this.formData, "initPsw", this.randomPassword());
                    this.passwordPlaceholder = "初始密码";
                    this.hasPassword = false;
                  }
                } else {
                  this.passwordPlaceholder = "初始密码";
                  this.$set(this.formData, "initPsw", this.randomPassword());
                  this.hasPassword = false;
                }
              });
          }, 500);
        }
      });
    },

    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.addAccount();
        } else {
          this.$Message.warning("请按红色字段填写内容！");
        }
      });
    },

    addAccount() {
      this.btnLoading = true;
      let params = {
        companyId: this.companyId,
        ...this.formData
      };
      this.$http.post("FmAccount/account", params).then(res => {
        this.btnLoading = false;
        if (res.code === 20000) {
          this.$Message.success("添加成功！");
          this.$emit("refreshTable", true);
          this.hide();
        } else {
          this.$Message.error("添加失败！");
        }
      });
    },

    reset() {
      this.companyId = "";
      this.formData = {
        linkMan: "",
        mobile: "",
        initPsw: "",
        isAdmin: 0,
        ifNotice: 0,
        visitingCardUrl: "",
        recommenderId: "",
        status: 1,
        position: "",
        fundLink: 0,
        sex: ""
      };
      this.imgUrl = "";
      this.clear("companyInfo");
      this.passwordPlaceholder = "初始密码";
      this.hasPassword = false;
      this.$refs.form.resetFields();
    },

    // 随机生成初始密码
    randomPassword() {
      let password = "jjds";
      for (let i = 0; i < 4; i++) {
        password += Math.floor(Math.random() * 10);
      }
      return password;
    }
  }
};
</script>

<style lang="less" scoped>
.upload-list-img {
  cursor: pointer;
  vertical-align: top;
  display: inline-block;
  width: 360px;
  height: 212px;
  text-align: center;
  line-height: 212px;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  margin-right: 4px;
  img {
    width: 100%;
    height: 100%;
  }
}

.upload-button-container {
  width: 360px;
  height: 212px;
  line-height: 212px;
  text-align: center;
  overflow: hidden;
}

.upload-list-cover {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  position: absolute;
  height: 60px;
  bottom: -60px;
  left: 0;
  right: 0;
  line-height: 60px;
  background: rgba(0, 0, 0, 0.6);
  transition: all 0.5s ease;
  div {
    flex: 1;
  }
}

.upload-list-img:hover .upload-list-cover {
  bottom: 0;
}

.upload-list-cover i {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 5px;
}
</style>


