<template>
  <Modal
    class="account-manager-modal"
    title="账号管理"
    :mask-closable="false"
    v-model="modal"
    @on-cancel="hide"
    :width="modalWidth"
  >
    <div slot="footer">
      <div class="page-load fr">
        <Page
          :total="total"
          placement="top"
          :current="currentPage"
          :page-size="pageSize"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizeChange"
          show-elevator
          show-sizer
          show-total
        />
      </div>
    </div>

    <h4>{{companyName}}</h4>

    <Form ref="form" :label-width="90">
      <Row>
        <Col span="12">
          <Row>
            <Col span="16">
              <FormItem label="关键词">
                <Input v-model.trim="searchData.user_keyword" placeholder="请输入姓名/用户名/手机号"/>
              </FormItem>
            </Col>

            <Col :offset="1" span="7">
              <Button type="primary" @click="onSearch">搜索</Button>
            </Col>
          </Row>
        </Col>
      </Row>
    </Form>

    <div class="fr">
      <Button @click="addAccount" type="primary" :disabled="!canAdd">添加账号</Button>
    </div>

    <div class="table-area">
      <Table
        ref="table"
        :data="tableData"
        :columns="columns"
        border
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
      ></Table>
    </div>

    <addAccountModal ref="addAccountModal" @refreshTable="getAccoutnList"></addAccountModal>
    <edit-account-modal ref="editAccountModal" @refreshTable="getAccoutnList"></edit-account-modal>
    <reset-password-modal ref="resetPasswordModal"></reset-password-modal>
  </Modal>
</template>

<script>
import $ from "jquery";
import addAccountModal from "./add-account";
import editAccountModal from "./edit-account";
import clearData from "@/mixins/clearData";
import resetPasswordModal from "../../account-justify/components/reset-password-modal";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import { mapGetters } from "vuex";
export default {
  components: {
    addAccountModal,
    resetPasswordModal,
    editAccountModal
  },

  mixins: [clearData, getMinusNumber],

  computed: {
    modalWidth() {
      return 1060;
    },

    ...mapGetters({
      userInfo: "getUser"
    }),

    canEdit() {
      return this.userInfo.auth.functional.includes("editFmAccount");
    },

    canDelete() {
      return this.userInfo.auth.functional.includes("deleteFmAccount");
    },

    canReset() {
      return this.userInfo.auth.functional.includes("resetFmPsw");
    },
    canAdd() {
      return this.userInfo.auth.functional.includes("addFmAccount");
    },

    columns() {
      let basicColumn = [
        {
          width: 90,
          title: "姓名",
          key: "linkman",
          render(h, { row }) {
            return h("span", row.linkman || "--");
          }
        },
        {
          width: 100,
          title: "用户名",
          key: "name",
          render(h, { row }) {
            return h("span", row.name || "--");
          }
        },
        {
          width: 120,
          title: "手机号",
          key: "mobile",
          render(h, { row }) {
            return h("span", row.mobile || "--");
          }
        },
        {
          width: 90,
          title: "职位",
          key: "position",
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.position || "--");
          }
        },
        {
          width: 107,
          title: "账号状态",
          key: "status",
          render: (h, { row }) => {
            let mapping = [
              {
                label: "正常",
                value: 1
              },
              {
                label: "禁用",
                value: 2
              },
              {
                label: "离职",
                value: 3
              },
              {
                label: "删除",
                value: 4
              }
            ];

            let text =
              mapping.filter(item => row.status == item.value)[0]["label"] ||
              "--";

            return h("span", text);
          }
        },
        {
          title: "使用情况",
          key: "useStage",
          width: 100,
          render: (h, { row }) => {
            return h(
              "span",
              `${row.activate ? "激活" : "未激活"}/${
                row.active ? "活跃" : "不活跃"
              }`
            );
          }
        },
        {
          title: "私募直连",
          key: "fundLink",
          width: 80,
          render(h, { row }) {
            return h("span", row.fundLink ? "已开通" : "未开通");
          }
        },
        {
          width: 80,
          title: "管理员",
          key: "isAdmin",
          render(h, { row }) {
            if (row.isAdmin === 0) {
              return h("span", "否");
            } else if (row.isAdmin === 1) {
              return h("span", "是");
            } else {
              return h("span", "--");
            }
          }
        },
        {
          width: 80,
          title: "业务类型",
          key: "businessType",
          render(h, { row }) {
            let mapping = {
              "1": "私募",
              "2": "信托",
              "3": "券商",
              "4": "期货",
              "5": "银行"
            };
            return h("span", mapping[row.businessType] || "--");
          }
        },
        {
          width: 80,
          title: "推荐人",
          key: "recommenderName",
          render(h, { row }) {
            return h("span", row.recommenderName || "--");
          }
        },
        {
          key: "visitingCardUrl",
          title: "名片",
          width: 80,
          render(h, { row }) {
            let url;
            if (row.visitingCardUrl) {
              let picUrl = JSON.parse(JSON.stringify(row.visitingCardUrl));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? " http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";

                let picPath = row.visitingCardUrl.replace(/Uploads\/crm/g, "/");
                picUrl = `Uploads/crm/${picPath}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        },
        {
          width: 180,
          title: "操作",
          fixed: "right",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: this.canEdit ? "deleteBtn" : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (!this.canEdit) {
                        return;
                      }
                      this.$refs.editAccountModal.show(this.companyInfo, row);
                    }
                  }
                },
                "编辑"
              ),

              h(
                "div",
                {
                  attrs: {
                    class: this.canDelete ? "deleteBtn" : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (!this.canDelete) {
                        return;
                      }
                      this.deleteAccount(row.id);
                    }
                  }
                },
                "删除"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: this.canReset ? "deleteBtn" : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (!this.canReset) {
                        return;
                      }
                      this.resetPassword({
                        phoneNumber: row.mobile,
                        name: row.linkman,
                        officialUserId: row.officialUserId,
                        productId: 2
                      });
                    }
                  }
                },
                "重置密码"
              )
            ]);
          }
        }
      ];

      return basicColumn;
    }
  },

  data() {
    return {
      searchData: {
        user_keyword: ""
      },
      modal: false,
      companyName: "",
      tableData: [],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10,
      companyId: "",
      companyInfo: {}
    };
  },

  mounted() {
    this.setMaxheightToTable();
  },

  methods: {
    onSearch() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getAccoutnList();
    },

    //  重置密码
    resetPassword(accountInfo = {}) {
      this.$refs.resetPasswordModal.show(accountInfo);
    },
    setMaxheightToTable() {
      let modalMaxheight = document.body.offsetHeight * 0.7;
      let minusNumber = this.getMinusNumberOfFixedTable();
      let tableHeight = modalMaxheight - 200;
      $(this.$el)
        .find(".ivu-table-body")
        .css("maxHeight", `${tableHeight}px`);
      $(this.$el)
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", `${tableHeight - minusNumber}px`);
      $(this.$el)
        .find(".ivu-table-fixed-body")
        .css("maxHeight", `${tableHeight - minusNumber}px`);
    },

    show(id, companyName, companyInfo = {}) {
      this.companyInfo = companyInfo;
      this.companyName = companyName;
      this.companyId = id;
      this.modal = true;
      this.getAccoutnList();
    },

    cleatData() {
      this.companyName = "";
      this.companyId = "";
      this.tableData = [];
      this.pageSize = 10;
      this.currentPage = 1;
      this.clear("companyInfo");
      this.searchData = {
        user_keyword: ""
      };
    },

    hide() {
      this.modal = false;
      this.cleatData();
    },

    addAccount() {
      this.$refs.addAccountModal.show(this.companyInfo, this.companyId);
    },

    getAccoutnList() {
      this.tableLoading = true;
      let params = Object.assign(
        {
          company_keyword: this.companyId,
          ...this.searchData
        },
        {
          pageNo: this.currentPage,
          pageSize: this.pageSize
        }
      );
      this.$http.get(`FmAccount/account`, params).then(res => {
        this.tableLoading = false;
        if (res.code === 20000) {
          this.tableData = res.data.records;
          this.total = res.data.total;
        } else {
          this.$Message.error(`获取账号列表失败：${res.msg}`);
        }
      });
    },

    deleteAccount(id) {
      this.$Modal.confirm({
        title: "删除账号",
        content: "确定删除这条账号吗？",
        onOk: () => {
          this.setAccountStatus(4, id);
        }
      });
    },

    setAccountStatus(status, id) {
      let params = {
        userId: id,
        companyId: this.companyId,
        status: status
      };
      this.$http
        .putWithoutId(`FmAccount/account/accSetStatus`, params)
        .then(res => {
          if (res.code === 20000) {
            this.$Message.success("设置成功！");
            this.getAccoutnList();
          } else {
            this.$Message.error("设置失败！");
          }
        });
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getAccoutnList();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getAccoutnList();
    }
  }
};
</script>

<style lang="less" scoped>
.fr {
  text-align: right;
  margin: 0 10px 10px 10px;
}
</style>


