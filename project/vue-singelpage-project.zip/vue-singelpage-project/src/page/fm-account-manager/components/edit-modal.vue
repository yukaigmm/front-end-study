<template>
  <Modal v-model="modal" title="编辑" :mask-closable="false" width="400" @on-cancel="hide">
    <div slot="footer">
      <Button type="default" @click="hide">关闭</Button>
      <Button type="primary" @click="ok" :loading="btnLoading">确定</Button>
    </div>

    <div slot="close" @click="hide">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div v-loading="modalLoading" element-loading-text="拼命加载中">
      <h3>{{companyName}}</h3>
      <Form ref="form" :rules="validateRules" :model="formData" :label-width="90">
        <Row type="flex" justify="space-around">
          <Col span="24">
            <FormItem label="开通状态" prop="userCompanyStatus">
              <Select v-model="formData.userCompanyStatus" clearable transfer>
                <Option
                  v-for="(item,index) in statusList"
                  :key="index"
                  :value="item.value"
                >{{item.label}}</Option>
              </Select>
            </FormItem>
          </Col>

          <Col span="24">
            <FormItem label="商务状态" prop="businessStatus">
              <Select v-model="formData.userCompanyLevel" clearable transfer>
                <Option
                  v-for="(item,index) in businessStatusList"
                  :key="index"
                  :value="item.value"
                >{{item.label}}</Option>
              </Select>
            </FormItem>
          </Col>

          <Col span="24">
            <FormItem label="有效期" prop="userCompanyStartDate">
              <DatePicker
                v-model="formData.userCompanyStartDate"
                placeholder="请选择开始日期"
                style="width:100%"
                transfer
              ></DatePicker>
            </FormItem>
          </Col>

          <Col span="24">
            <FormItem prop="userCompanyEndDate">
              <DatePicker
                v-model="formData.userCompanyEndDate"
                placeholder="请选择结束日期"
                style="width:100%"
                transfer
              ></DatePicker>
            </FormItem>
          </Col>

          <Col span="24">
            <FormItem label="开通模块" prop="userCompanyApplicationIds">
              <CheckboxGroup v-model="formData.userCompanyApplicationIds">
                <Checkbox v-for="(item,index) in moduleList" :key="index" :label="item.id">
                  <span>{{item.label}}</span>
                </Checkbox>
              </CheckboxGroup>
            </FormItem>
          </Col>

          <Col span="24">
            <FormItem></FormItem>
          </Col>
        </Row>
      </Form>
    </div>
  </Modal>
</template>


<script>
import moment from "moment";
import clearData from "@/mixins/clearData.js";
export default {
  mixins: [clearData],
  data() {
    return {
      companyId: "",
      orgId: "",
      moduleList: [
        {
          label: "星管家",
          id: 1
        },
        // 私募直连开通功能已单独移除，无需在此设置
        // {
        //   label:"私募直连",
        //   id:2
        // },

        // 如需打开私募指数、宏观市场功能，只需取消下面的注释
        {
          label: "私募指数",
          id: 3
        },
        {
          label: "宏观市场",
          id: 4
        }
      ],
      businessStatusList: [
        {
          label: "已收费",
          value: 2
        },
        {
          label: "未收费",
          value: 1
        }
      ],
      statusList: [
        {
          label: "已开通",
          value: 3
        },
        {
          label: "未开通",
          value: 2
        },
        {
          label: "禁用",
          value: 1
        }
      ],
      modal: false,
      companyName: "",
      formData: {
        userCompanyStatus: "",
        userCompanyLevel: "", //字段待定
        userCompanyStartDate: "",
        userCompanyEndDate: "",
        userCompanyApplicationIds: []
      },

      btnLoading: false,
      modalLoading: false
    };
  },

  watch: {
    "formData.userCompanyEndDate": {
      handler(val) {
        if (this.formData.userCompanyStartDate && val) {
          this.$refs.form.validateField("userCompanyStartDate");
        }
      },
      deep: true
    },

    "formData.userCompanyStartDate": {
      handler(val) {
        if (this.formData.userCompanyEndDate && val) {
          this.$refs.form.validateField("userCompanyEndDate");
        }
      },
      deep: true
    }
  },

  computed: {
    validateRules() {
      let validateStartDate = (rules, value, callback) => {
        let errors = [];
        if (this.formData.userCompanyEndDate && value) {
          let endDate = new Date(this.formData.userCompanyEndDate).getTime();
          let startDate = new Date(value).getTime();
          if (startDate > endDate) {
            errors.push(new Error("开始时间应该小于结束时间！"));
          }
        }
        callback(errors);
      };

      let validateEndDate = (rules, value, callback) => {
        let errors = [];
        if (this.formData.userCompanyStartDate && value) {
          let startDate = new Date(
            this.formData.userCompanyStartDate
          ).getTime();
          let endDate = new Date(value).getTime();
          if (startDate > endDate) {
            errors.push(new Error("结束时间应该大于开始时间！"));
          }
        }
        callback(errors);
      };

      return {
        userCompanyStartDate: [{ validator: validateStartDate }],
        userCompanyEndDate: [{ validator: validateEndDate }]
      };
    }
  },

  methods: {
    ok() {
      this.btnLoading = true;
      this.submit();
    },

    show(companyId, orgId) {
      this.companyId = companyId;
      this.orgId = orgId;
      this.modal = true;
      this.getDetails();
    },

    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },

    hide() {
      this.modal = false;
      this.reset();
    },

    submit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          let params = {
            ...this.formData,
            companyId: this.companyId
          };

          if (params.userCompanyStartDate) {
            params.userCompanyStartDate = this.setTimeZone(
              params.userCompanyStartDate
            );
          }

          if (params.userCompanyEndDate) {
            params.userCompanyEndDate = this.setTimeZone(
              params.userCompanyEndDate
            );
          }
          this.$http
            .putWithoutId(
              `company/checkCompanyStatus/${this.orgId}`,
              params
            )
            .then(res => {
              this.btnLoading = false;
              if (res.code === 20000) {
                this.$Message.success("修改成功！");
                this.hide();
                this.$emit("refreshTable");
              } else {
                this.$Message.error(`修改失败：${res.msg}`);
              }
            });
        } else {
          this.btnLoading = false;
          this.$Message.warning("请按红色提示修改内容！");
        }
      });
    },

    getDetails() {
      this.modalLoading = true;
      this.$http.get(`company/${this.orgId}`).then(res => {
        this.modalLoading = false;
        if (res.code === 20000) {
          this.companyName = res.data.companyName;
          let keys = Object.keys(this.formData);
          keys.forEach(key => {
            if (!Array.isArray(this.formData[key])) {
              this.$set(this.formData, key, res.data[key]);
            } else {
              if (res.data[key]) {
                this.$set(
                  this.formData,
                  key,
                  JSON.parse(res.data[key]).map(item => item - 0)
                );
              } else {
                this.$set(this.formData, key, []);
              }
            }
          });
          if (this.formData.userCompanyStartDate == "0000-00-00") {
            this.formData.userCompanyStartDate = "";
          }
          if (this.formData.userCompanyEndDate == "0000-00-00") {
            this.formData.userCompanyEndDate = "";
          }
          // 和卅林约定，如果数据库中公司开通记录没有id的，前端自己给开通模块设置开通 3 和 4
          // if(res.data.id == null){
          //   this.$set(this.formData, "userCompanyApplicationIds", [3, 4]);
          // }
          
        } else {
          this.$Message.error("获取数据失败！");
        }
      });
    },

    reset() {
      this.clear("formData");
      this.companyId = "";
      this.companyName = "";
      this.orgId = "";
    }
  }
};
</script>

<style lang="less" scoped>
</style>

