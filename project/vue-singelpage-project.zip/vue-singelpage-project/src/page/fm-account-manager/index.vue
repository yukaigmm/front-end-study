<template>
  <div class="fm-manager">
    <searchArea :showExpand="false" class="search-area keydown-box" @onKeydownSearch="search">
      <div slot="default">
        <Row>
          <Col span="8">
            <FormItem label="关键字">
              <Input v-model.trim="formData.keyWord" placeholder="请输入公司ID/简称/备案编码"></Input>
            </FormItem>
          </Col>

          <Col span="8" :offset="1">
            <FormItem label="激活状态">
              <Select v-model="formData.activate" clearable>
                <Option
                  v-for="(item,index) in activitedStatusList"
                  :key="index"
                  :value="item.value"
                >{{item.label}}</Option>
              </Select>
            </FormItem>
          </Col>

          <!-- <Col span="8" :offset='1'>
                       <FormItem label="开通状态">
                           <Select v-model="formData.userCompanyStatus" clearable>
                               <Option v-for="(item,index) in statusList" :key="index" :value="item.value">
                                   {{item.label}}
                               </Option>
                           </Select>
                       </FormItem>
                     
          </Col>-->
          <Col span="4" style="margin-left:20px;">
            <Button type="primary" @click="search">搜索</Button>
            <Button type="default" @click="onReset">重置</Button>
          </Col>

          <Col span="8">
            <FormItem label="活跃状态">
              <Select v-model="formData.active" clearable>
                <Option
                  v-for="(item,index) in activeStatusList"
                  :key="index"
                  :value="item.value"
                >{{item.label}}</Option>
              </Select>
            </FormItem>
          </Col>

          <Col span="8" :offset="1">
            <FormItem label="直连状态">
              <Select v-model="formData.fundLink" clearable>
                <Option
                  v-for="(item,index) in fundLinkStatus"
                  :key="index"
                  :value="item.value"
                >{{item.label}}</Option>
              </Select>
            </FormItem>
          </Col>

          <Col span="8">
            <FormItem label="账号信息">
              <Input v-model.trim="formData.user_key_word" placeholder="请输入姓名/用户名/手机号"></Input>
            </FormItem>
          </Col>

          <Col span="8" :offset="1">
            <FormItem label="机构类型">
              <Select v-model="formData.oc_id" clearable>
                <Option
                  v-for="(item,index) in orgType"
                  :key="index"
                  :value="item.value"
                >{{item.name}}</Option>
              </Select>
            </FormItem>
          </Col>
        </Row>
      </div>
    </searchArea>

    <div class="btn-wrap">
      <Button type="primary" @click="syncData">同步数据</Button>
    </div>

    <div class="table-area fm-table">
      <Table
        :data="tableData"
        :columns="columns"
        border
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        ref="table"
      ></Table>
    </div>

    <div class="page-load fr">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      />
    </div>

    <editModal ref="editModal" @refreshTable="search"></editModal>
    <manageModal ref="manageModal"></manageModal>
  </div>
</template>

<script>
import clearData from "@/mixins/clearData.js";
import searchArea from "@/components/search-area.vue";
import editModal from "./components/edit-modal";
import manageModal from "./components/account-manager";
import $ from "jquery";
import { mapGetters } from "vuex";
import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  components: {
    searchArea,
    editModal,
    manageModal
  },

  mixins: [clearData, getMinusNumber],
  data() {
    return {
      total: 0,
      currentPage: 1,
      pageSize: 10,
      fundLinkStatus: [
        {
          label: "已开通",
          value: 1
        },
        {
          label: "未开通",
          value: 0
        }
      ],
      businessStatusList: [
        {
          label: "已收费",
          value: 2
        },
        {
          label: "未收费",
          value: 1
        }
      ],
      statusList: [
        {
          label: "已开通",
          value: 3
        },
        {
          label: "未开通",
          value: 2
        },
        {
          label: "禁用",
          value: 1
        }
      ],
      activitedStatusList: [
        {
          value: 1,
          label: "已激活"
        },
        {
          value: 0,
          label: "未激活"
        }
      ],
      activeStatusList: [
        {
          value: 1,
          label: "活跃"
        },
        {
          value: 0,
          label: "不活跃"
        }
      ],
      formData: {
        keyWord: "",
        activate: "",
        active: "",
        fundLink: "",
        user_key_word: "",
        oc_id: "7"
      },
      tableData: [],
      tableLoading: false,
      columns: [
        {
          fixed: "left",
          title: "公司ID",
          key: "companyId",
          width: 95,
          render(h, { row }) {
            return h("span", row.companyId || "--");
          }
        },
        {
          fixed: "left",
          title: "公司名称",
          key: "companyName",
          width: 180,
          render: (h, { row }) => {
            return h(
              "a",
              {
                attrs: {
                  title: row.companyName
                },
                on: {
                  click: e => {
                    e.preventDefault();
                    e.stopPropagation();
                    let tab = {
                      activeName: `[客户]${row.companyName}`,
                      pid: row.orgId,
                      name: `[客户]${row.companyName}${row.orgId}`,
                      component: "customerDetails",
                      isShow: true,
                      orgType: row.ocId
                    };
                    this.$store.dispatch("setTabs", tab);
                  }
                }
              },
              row.companyName || "--"
            );
          },
          ellipsis: true
        },

        {
          fixed: "left",
          title: "使用情况",
          key: "useStage",
          width: 100,
          render: (h, { row }) => {
            return h(
              "span",
              `${row.activate ? "激活" : "未激活"}/${
                row.active ? "活跃" : "不活跃"
              }`
            );
          }
        },
        {
          title: "机构类型",
          width: 120,
          render: (h, { row }) => {
            let text = this.orgType.filter(item => item.value == row.ocId)[0]
              ? this.orgType.filter(item => item.value == row.ocId)[0][
                  "name"
                ] || "--"
              : "--";
            return h("span", text);
          }
        },
        {
          width: 150,
          title: "开通模块",
          key: "userCompanyApplicationIds",
          render(h, { row }) {
            let mapping = {
              "1": "星管家",
              "2": "私募直连",
              "3":"私募指数",
              "4":"宏观市场"
            };
            if (
              row.userCompanyApplicationIds &&
              row.userCompanyApplicationIds.length
            ) {
              return h(
                "span",
                row.userCompanyApplicationIds
                  .map(item => mapping[item])
                  .join("、") || "--"
              );
            } else {
              return h("span", "--");
            }
          }
        },
        {
          width: 70,
          title: "直连状态",
          key: "fundLink",
          render(h, { row }) {
            let mapping = {
              "0": "未开通",
              "1": "已开通"
            };

            return h("span", mapping[row.fundLink] || "--");
          }
        },
        {
          width: 80,
          title: "账号数",
          key: "orgAccount"
        },
        {
          width: 80,
          title: "开通人员",
          key: "userCompanyOpenUser",
          render(h, { row }) {
            return h("span", row.userCompanyOpenUser || "--");
          }
        },
        {
          title: "公司简称",
          key: "companyShortName",
          width: 150,
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.companyShortName || "--");
          }
        },
        {
          width: 80,
          title: "所在地区",
          key: "city",
          render: (h, { row }) => {
            return h("span", row.city || "--");
          }
        },
        {
          width: 80,
          title: "备案编码",
          key: "registerNumber",
          render(h, { row }) {
            return h("span", row.registerNumber || "--");
          }
        },
        {
          width: 80,
          title: "成立日期",
          key: "establishDate",
          render(h, { row }) {
            let emptyDate = [null, "", "0000-00-00"];
            return h(
              "span",
              emptyDate.includes(row.establishDate) ? "--" : row.establishDate
            );
          }
        },
        {
          width: 80,
          title: "客户经理",
          key: "userCompanyFollowUser",
          render(h, { row }) {
            return h("span", row.userCompanyFollowUser || "--");
          }
        },
        {
          width: 70,
          title: "商务状态",
          key: "userCompanyLevel ",
          render(h, { row }) {
            let mapping = {
              "1": "未收费",
              "2": "已收费"
            };
            return h("span", mapping[row.userCompanyLevel] || "--");
          }
        },

        {
          width: 160,
          title: "有效期",
          key: "expire",
          render(h, { row }) {
            let empty = [null, "", "0000-00-00"];
            return h(
              "span",
              `${
                empty.includes(row.userCompanyStartDate)
                  ? "--"
                  : row.userCompanyStartDate
              }～${
                empty.includes(row.userCompanyEndDate)
                  ? "--"
                  : row.userCompanyEndDate
              }`
            );
          }
        },
        {
          fixed: "right",
          width: 100,
          title: "操作",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: this.canEdit ? "deleteBtn" : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (!this.canEdit) {
                        return;
                      }
                      this.editAccount(row.companyId, row.orgId);
                    }
                  }
                },
                "编辑"
              ),
              // h(
              //   "div",
              //   {
              //     attrs: {
              //       class: "deleteBtn"
              //     },
              //     on: {
              //       click: () => {
              //         this.managerAccount(
              //           row.companyId,
              //           row.companyShortName || row.companyName,
              //           {
              //             companyName: row.companyName,
              //             companyShortName: row.companyShortName,
              //             registerNumber: row.registerNumber,
              //             establishDate: row.establishDate,
              //             city: row.city
              //           }
              //         );
              //       }
              //     }
              //   },
              //   "账号管理"
              // ),
              h(
                "div",
                {
                  attrs: {
                    class: this.showStarButler ? "deleteBtn" : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (!this.showStarButler) {
                        return;
                      }
                      this.starButlerAccount(row.companyId, row.companyName);
                    }
                  }
                },
                "星管家"
              )
            ]);
          }
        }
      ]
    };
  },

  created() {
    this.getTableData();
  },

  computed: {
    ...mapGetters({
      tabs: "getTabs",
      userInfo: "getUser",
      enums: "getEnums"
    }),
    canEdit() {
      return this.userInfo.auth.functional.includes("editFmCompany");
    },

    showStarButler() {
      return this.userInfo.auth.functional.includes("starButler");
    },

    orgType() {
      return this.enums.c_org;
    }
  },

  mounted() {
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".page-load"],
      ".table-area"
    );
  },

  methods: {
    syncData() {
      this.$Message.loading("同步中，请稍候...");
      this.$http.get("companyDataSynTask").then(res => {
        this.$Message.destroy();
        if (res.code === 20000) {
          this.$Message.success("同步成功！");
        } else {
          this.$Message.error(`同步失败：${res.msg}`);
        }
      });
    },

    starButlerAccount(companyId, companyName) {
      let tab = {
        activeName: `[星管家]${companyName}`,
        pid: companyId,
        name: `[星管家]${companyName}${companyId}`,
        component: "starButlerMmanager",
        isShow: true
      };
      this.$store.dispatch("setTabs", tab);
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 140;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    search() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getTableData();
    },

    onReset() {
      this.clear("formData");
      this.currentPage = 1;
      this.pageSize = 10;
      this.getTableData();
    },

    editAccount(companyId, orgId) {
      this.$refs.editModal.show(companyId, orgId);
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getTableData();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getTableData();
    },

    getParams() {
      let formData = JSON.parse(JSON.stringify(this.formData));

      for (let key in formData) {
        if (formData[key] === "") {
          delete formData[key];
        }
      }

      return Object.assign(
        {
          pageNo: this.currentPage,
          pageSize: this.pageSize
        },
        formData
      );
    },

    getTableData() {
      this.tableLoading = true;
      let params = this.getParams();
      this.$http.get("/company", this.getParams()).then(res => {
        this.tableLoading = false;
        if (res.code === 20000) {
          this.tableData = res.data.records;
          this.total = res.data.total;
        } else {
          this.$Message.error(`获取表格数据失败：${res.msg}`);
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.fr {
  text-align: right;
  margin: 10px;
}

.btn-wrap {
  margin: 10px;
}
</style>


