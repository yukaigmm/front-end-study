<template>
  <div v-loading="modalLoading" element-loading-text="loading..." class="visit-record-detail">
    <Row>
      <Col span="8" v-if="needTable">
        <Table
          :data="tableData"
          :columns="columns"
          :loading="tableLoading"
          border
          height="480"
          :row-class-name="choosenRowClass"
          @on-row-click="tableRowClick"
        ></Table>
      </Col>

      <Col :span="needTable ? 16 : 23" style="position: relative;">
        <Form ref="form" :model="form" :rules="rules" :label-width="80">
          <Row>
            <Col span="8">
              <FormItem label="拜访人" prop="visit_member_name">
                <span>{{form.visit_member_name}}</span>
              </FormItem>
            </Col>

            <Col span="15" offset="1">
              <FormItem label="拜访对象" prop="contacts_id">
                <Input v-model.trim="form.contacts_id" style="display: none;"></Input>

                <span>{{form.contacts_name}}</span>
                
                <span class="object-bread" :title="form.bread">{{form.bread}}</span>

                <Button
                  size="small"
                  type="primary"
                  v-if="!needTable"
                  @click="chooseTarget"
                >{{buttonText}}</Button>
              </FormItem>
            </Col>
          </Row>

          <Row style="margin-top:4px;">
            <Col span="8">
              <FormItem label="拜访类别" prop="visit_type">
                <Select v-model="form.visit_type" :disabled="formDisable">
                  <Option
                    v-for="(item, index) in visitTypes"
                    :key="index"
                    :value="item.value"
                  >{{item.name}}</Option>
                </Select>
              </FormItem>
            </Col>

            <Col span="15" offset="1">
              <FormItem label="其他接待人" prop="contacts_ids">
                <span
                  class="others"
                  :title="otherCantactsName.join(',')"
                >{{this.otherCantactsName.join(",")}}</span>
                <Button
                  type="primary"
                  size="small"
                  :disabled="formDisable"
                  @click="showOtherTargetsModal"
                >{{!this.otherCantactsName.length?"添加":'更换'}}</Button>

                <!--<Select-->
                <!--v-if="showOthers"-->
                <!--v-model="form.contacts_ids"-->
                <!--:loading="otherLoading"-->
                <!--multiple>-->
                <!--<Option-->
                <!--v-for="(item, index) in others"-->
                <!--:key="index"-->
                <!--:value="item.id +''">-->
                <!--{{item.name}}-->
                <!--</Option>-->
                <!--</Select>-->
                <!--<Button v-else @click="showOthersSelect">-->
                <!--<Icon type="plus"></Icon>-->
                <!--</Button>-->
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="8">
              <FormItem label="拜访日期" prop="visit_time">
                <Date-picker type="date" v-model="form.visit_time" :disabled="formDisable" placeholder="拜访日期"></Date-picker>
              </FormItem>
            </Col>

            <Col span="8" offset="1">
              <FormItem label="预约回访" prop="order_time">
                <Date-picker type="date" v-model="form.order_time" :disabled="formDisable" placeholder="预约回访"></Date-picker>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="24">
              <FormItem label="意向" prop="intention_type">
                <RadioGroup v-model="form.intention_type">
                  <Radio
                    v-for="(item, index) in intentions"
                    :key="index"
                    :label="item.value"
                    :disabled="formDisable"
                  >{{item.name}}</Radio>
                </RadioGroup>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="24">
              <FormItem label="需求点" prop="demand_ids">
                <Checkbox-group v-model="form.demand_ids">
                  <Checkbox
                    v-for="(item, index) in demands"
                    :label="item.value"
                    :key="index"
                    :disabled="formDisable"
                  >{{ item.name }}</Checkbox>
                </Checkbox-group>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="24">
              <FormItem label="交谈内容" prop="chat_ids">
                <Checkbox-group v-model="form.chat_ids">
                  <Checkbox
                    v-for="(item, index) in chatContents"
                    :label="item.value"
                    :key="index"
                    :disabled="formDisable"
                  >{{ item.name }}</Checkbox>
                </Checkbox-group>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="24">
              <FormItem label="日志" prop="visit_content">
                <Input
                  type="textarea"
                  v-model="form.visit_content"
                  :autosize="{minRows: 3,maxRows: 5}"
                  :disabled="formDisable"
                  placeholder="请输入内容"
                ></Input>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="24">
              <Form-item label="提醒谁看" prop="remind_person" style="margin-top: 10px;">
                <row>
                  <Col span="8" style="float:left">
                    <div :class="{chosenPeople:choosePeople}">
                      <div class="show_container" :class="{showMorePeople:showHeight}">
                        <p class="show-content" @click="showPeopleModal">
                          <span v-if="selectedPeopleName.length">{{selectedPeopleName.join(', ')}}</span>
                          
                          <span v-else class="placeholder">单击选择收件人</span>
                        </p>

                        <div
                          class="total"
                          @click="showPeopleModal"
                          title="选择需要分享的人"
                          v-if="this.selectedPeopleName.length"
                        >共{{this.selectedPeopleId.length}}人</div>

                        <div class="tool" @click="showMorePeople" v-if="selectedPeopleName.length">
                          <span class="text">{{!showHeight?"更多":"收起"}}</span>

                          <div class="icon-container" v-if="!showHeight">
                            <Icon :size="18" color="#666" class="icon" type="ios-arrow-down"></Icon>
                            <Icon :size="18" color="#666" class="icon second" type="ios-arrow-down"></Icon>
                            <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-down"></Icon>
                          </div>

                          <div class="icon-container" v-else>
                            <Icon :size="18" color="#666" class="icon" type="ios-arrow-up"></Icon>
                            <Icon :size="18" color="#666" class="icon second" type="ios-arrow-up"></Icon>
                            <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-up"></Icon>
                          </div>
                        </div>
                      </div>
                    </div>

                    <p style="color:red;" v-show="choosePeople">请先选择接收人！</p>
                  </Col>

                  <Col span="12" offset="1" style="float:left">
                    <Input
                      type="textarea"
                      class="share-container"
                      v-model.trim="shareContent"
                      style="height:40px;"
                      :autosize="{minRows: 1,maxRows: 2}"
                      placeholder="请输入分享内容..."
                    ></Input>
                  </Col>

                  <i-col span="3"  v-show="showRemind" style="text-align:right;">
                    <Button type="primary" size="small" @click="remind">提醒</Button>
                  </i-col>
                </row>
              </Form-item>
            </Col>
          </Row>
        </Form>
      </Col>
    </Row>

    <choose-target ref="chooseTarget" @confirmVisitTarget="confirmVisitTarget"></choose-target>

    <people-tree ref="people" @getSelectedPeople="getSelectedPeople"></people-tree>

    <transmirModal ref="transmit"></transmirModal>

    <chooseMutipleTargetsModal
      ref="chooseMutipleTargetsModal"
      @getCheckedTargets="getOtherCantacts"
    ></chooseMutipleTargetsModal>
  </div>
</template>
<script>
import {
  fetchSelect,
  postFormData,
  fetchGrid,
  fetchWorkmate,
  getReciver,
  putFormData,
  getMessageCount,
  fetchUser
} from "@/service/getData";
import saleProjectManageService from "@/service/sale-project-manage/sale-project-manage-service.js";
import peopleTree from "./peopleTree";
import chooseTarget from "../visit-record-manager/choose-visit-target";
import transmirModal from "./transmit-modal.vue";
import chooseMutipleTargetsModal from "./components/choose-mutiple-targets";
import _ from "lodash";
import { mapGetters } from "vuex";
import eventBus from "@/components/common-components/customer/eventBus.js";
import moment from "moment";
export default {
  components: {
    peopleTree,
    chooseTarget,
    transmirModal,
    chooseMutipleTargetsModal
  },
  props: {
    needTable: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      currentVisitRecordId:"",
      projectId: "",
      otherCantactsName: [],
      firstRow: {},
      modalLoading: true,
      tableLoading: false,
      otherLoading: false,
      tableData: [],
      columns: [
        {
          title: "拜访人",
          key: "visit_member_name",
          width: 80
        },
        {
          title: "拜访日期",
          key: "visit_time",
          render(h, { row }) {
            return row.visit_time || "--";
          }
        },
        {
          title: "预约回访",
          key: "order_time",
          render(h, { row }) {
            return row.order_time || "--";
          }
        },
        {
          title: "转发",
          align: "center",
          render: (h, params) => {
            // <Icon type="arrow-return-right"></Icon>
            if (params.row._index) {
              return h(
                "div",
                {
                  on: {
                    click: e => {
                      e.stopPropagation();
                      e.preventDefault();
                      this.transmit(params.row.id);
                    }
                  },
                  style: {
                    fontSize: "16px",
                    color: "#3ab2ff",
                    cursor: "pointer"
                  },
                  attrs: {
                    title: "转发"
                  }
                },
                [
                  h(
                    "Icon",
                    {
                      props: {
                        type: "share"
                      }
                    },
                    "转发"
                  )
                ]
              );
            } else {
              return "--";
            }
          }
        }
      ],
      initForm: {
        visit_member_id: "", //拜访人id
        visit_member_name: "", //拜访人姓名
        contacts_id: "", //拜访对象id
        contacts_name: "", //拜访对象姓名
        contacts_ids: [], //其他接待人
        visit_time: "", //拜访时间
        order_time: "", // 预设拜访时间
        demand_ids: [], //需求点
        chat_ids: [], //交谈内容
        intention_type: "", //意向
        visit_type: "", //拜访类别
        visit_content: "", //日志
        org_id: "" //拜访对象所属机构id
      },
      form: {},
      rules: {
        visit_member_name: [
          {
            required: true,
            message: "必填",
            trigger: "blur, change"
          }
        ],
        contacts_id: [
          {
            required: true,
            message: "必填",
            trigger: "blur, change"
          }
        ],
        visit_time: [
          {
            required: true,
            type: "date",
            message: "必选",
            trigger: "blur, change"
          }
        ],
        intention_type: [
          {
            required: true,
            message: "必选",
            trigger: "blur, change"
          }
        ],
        visit_content: [
          {
            required: true,
            min: 5,
            max: 1000,
            message: "不少于5个字或者不超过1000个字",
            trigger: "blur, change"
          }
        ]
      },
      currentTableRowIndex: 0,
      others: [],
      initPersonId: -1, //联系人id
      initPersonName: "", //联系人名称
      initPersonDepart: "", // 联系人部门
      initOrgId: "", //联系人上级机构id
      showRemind: false,
      choosePeople: false,
      showHeight: false,
      selectedPeopleName: [],
      selectedPeopleId: [],
      shareContent: "",
      showOthers: false,
      // 该机构是否分配给当前拜访人
      ifAssigned: false,
      // 当前拜访人管理的项目
      projects: [],
      // 当前机构是否已经分配至项目中
      ifAssignedToProject: false,
      // 当前拜访人
      currentVisitorId: "",
      // 表单编辑开关
      formDisable: false,
    };
  },
  computed: {
    ...mapGetters({
      enums: "getEnums",
      user: "getUser"
    }),
    intentions() {
      return this.enums.c_intention;
    },
    demands() {
      return this.enums.c_demand;
    },
    chatContents() {
      return this.enums.c_chat_content;
    },
    visitTypes() {
      return this.enums.c_visit_type;
    },
    visitTypeMapping() {
      return this.enums.c_visit_type_mapping;
    },
    buttonText() {
      return this.form.contacts_id ? "更换" : "添加";
    }
  },
  watch: {
    selectedPeopleName: {
      handler(val) {
        if (val.length > 0) {
          this.$nextTick(() => {
            this.choosePeople = false;
          });
        }
      },
      deep: true
    },
    currentVisitorId: {
      handler(val){
        if(val == this.user.id){
          this.formDisable = false;
        }else{
          this.formDisable = true;
        }
      },
      deep: true,
    }
  },

  created() {},

  destroyed() {},

  mounted() {
    this.resetForm();
  },
  methods: {
    remind() {
      let selectedPeopleId = JSON.parse(JSON.stringify(this.selectedPeopleId));
      let shareContent = this.shareContent;
      //已经选中提醒的人
      let content =
        shareContent ||
        `${this.user.trueName}给$name分享了一条拜访记录[系统日志]`;
      // let visit_id = resp.data.id;
      let params = {
        type: 4,
        to_id: selectedPeopleId,
        message: content,
        visit_id: this.currentVisitRecordId
      };
      postFormData("msg/send", params).then(resp => {
        if (resp.code === 20000) {
          this.$Message.success("已为您发送提醒");
        } else {
          this.$Message.error("发送提醒失败 " + resp.msg);
        }

        //获取消息数
        getMessageCount().then(res => {
          let count = res.data.total;
          this.$store.dispatch("setMessageCount", {
            messageCount: count
          });
        });
      });
    },

    showOtherTargetsModal() {
      let orgId = this.form.org_id || this.initOrgId;
      if (orgId) {
        this.$refs.chooseMutipleTargetsModal.show(
          orgId,
          this.form.contacts_ids
        );
      } else {
        this.$Message.warning("请先确定拜访对象！");
      }
    },

    getOtherCantacts(otherContacts) {
      this.otherCantactsName = otherContacts.map(item => item.name);
      this.form.contacts_ids = otherContacts.map(item => item.id);
    },

    // 消息转发
    transmit(recordId) {
      this.$refs.transmit.show(recordId);
    },

    show({personId, personName, orgId, visitId, visitorId}) {
      this.initPersonId = personId;
      this.initPersonName = personName;

      //  获取当前机构id和名称
      eventBus.$on("getOrgIdAndOrgNameStr", val => {
        this.initOrgId = val.orgId;
        this.initPersonDepart = val.orgNameStr
          ? `(${val.orgNameStr.split(">").join(",")})`
          : "";
        this.$http
          .get("salesProject/getOrgManager", { orgId: this.initOrgId })
          .then(res => {
            let ids = res.data.map(item => item.memberId);
            if (ids.includes(this.user.id)) {
              this.ifAssigned = true;
            } else {
              this.ifAssigned = false;
            }
          });

        this.getProjects();
        this.getIfAssignedToProject();
        this.getVisitRecordList(visitId);
        this.currentVisitorId = visitorId;
      });
    },

    // 获取该机构是否已经分配至机构
    getIfAssignedToProject() {
      saleProjectManageService.getSalesProject(this.initOrgId).then(res => {
        if (res.data.length) {
          this.ifAssignedToProject = true;
        } else {
          this.ifAssignedToProject = false;
        }
      });
    },

    // 获取当前拜访人管理的项目
    getProjects() {
      saleProjectManageService.mySalesProject().then(res => {
        this.projects = res.data;
      });
    },

    initData(data) {
      this.form = {
        ...this.initForm,
        ...data
      };
      this.modalLoading = false;
    },
    resetForm() {
      this.form = JSON.parse(JSON.stringify(this.initForm));
      this.otherCantactsName = [];
      this.showOthers = false;
      this.$refs.form.resetFields();
      this.clearShareParams();
      this.choosePeople = false;
      eventBus.$off("getOrgIdAndOrgNameStr");
    },
    getVisitTypeOfCurrentUser() {
      let deptId = this.user.dept_id;
      let mapOfFilter = this.visitTypeMapping.filter(m => {
        return m.name === `${deptId}`;
      });
      return mapOfFilter.length ? mapOfFilter[0].value : "99";
    },
    getVisitRecordList(visitId) {
      let params = {
        row: 100,
        page: 1,
        contacts_id: this.initPersonId + "",
        order: "visit_time desc"
      };
      this.modalLoading = true;
      this.tableLoading = true;
      fetchGrid("/index/visit", params)
        .then(resp => {
          this.modalLoading = false;
          this.tableLoading = false;
          if (resp.code === 20000) {
            resp.data.data.forEach(item => {
              item.bread.shift();
              let depart = item.bread.map(item => {
                return item.title;
              });
              item.bread = `(${depart.join(",")})`;
            });
            this.tableData = resp.data.data;
          } else {
            this.tableData = [];
          }
          if (!this.initPersonName) {
            this.initPersonName = this.tableData.length
              ? this.tableData[0].contacts_name
              : "";
          }
          // this.initPersonDepart = this.tableData.length
          //   ? this.tableData[0].bread
          //   : " ";
          this.firstRow = {
            ...this.initForm,
            bread: this.initPersonDepart,
            visit_member_id: this.user.id,
            visit_member_name: this.user.trueName,
            contacts_name: this.initPersonName,
            contacts_id: this.initPersonId + "",
            org_id: this.initOrgId,
            visit_type: this.getVisitTypeOfCurrentUser()
          };
          this.tableData.unshift(this.firstRow);
        })
        .then(() => {
          //如果有visitId，则表示需要跳转到对应的拜访记录上去
          if (visitId) {
            let index = _.findIndex(this.tableData, data => {
              return data.id == visitId;
            });
            this.tableRowClick(this.tableData[index], index);
          } else {
            // 没有，默认显示第一行缺省数据
            this.tableRowClick(this.firstRow, 0);
          }
        });
    },
    transfer(val) {
      if (typeof val == "string") {
        if (val.length) {
          return JSON.parse(val);
        } else {
          return [];
        }
      } else if (typeof val == "object" && val instanceof Array) {
        return val;
      } else {
        return [];
      }
    },
    tableRowClick(row, index) {
      let rowData = JSON.parse(JSON.stringify(row))
      this.showRemind = row ? !!row.id : true;

      this.resetForm();
      this.currentVisitRecordId = rowData.id;
      this.currentTableRowIndex = index;
      this.currentVisitorId = rowData.visit_member_id;
      let data = JSON.parse(JSON.stringify(row));

      this.form = {
        ...data,
        contacts_id: data.contacts_id + "",
        contacts_ids: this.transfer(data.contacts_ids),
        demand_ids: this.transfer(data.demand_ids),
        chat_ids: this.transfer(data.chat_ids),
        visit_type: data.visit_type + "",
        intention_type: data.intention_type + ""
      };
      if (row.other_contacts_name && row.other_contacts_name.length) {
        this.otherCantactsName = row.other_contacts_name.map(item => item.name);
      }

      // if (this.form.contacts_ids.length) {
      //   //有其他接待人
      //   this.showOthers = true;
      //   this.showOthersSelect();
      // } else {
      //   this.showOthers = false;
      // }

      if (!row.id) {
        //新增
        this.$emit("changeVisitType", "self");
        this.$emit("changeSelfType", "add");
      } else {
        if (this.user.id === row.visit_member_id) {
          //自己的编辑
          this.$emit("changeVisitType", "self");
          this.$emit("changeSelfType", "edit");
        } else {
          this.$emit("changeVisitType", "other");
          this.$emit("changeSelfType", "");
        }
      }
    },
    jumpToTableRow(visitId) {
      // let index = _.findIndex(this.tableData, (data) => {
      //   return data.id = visitId
      // });
    },
    choosenRowClass(row, index) {
      if (index === this.currentTableRowIndex) {
        return "choosen";
      } else {
        return "";
      }
    },
    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },
    submit() {
      return new Promise((resolve, reject) => {
        this.$refs.form.validate(valid => {
          if (valid) {
            if (this.ifAssigned && !this.form.id) {
              //  已经分配给项目直接添加
              if (this.ifAssignedToProject) {
                // 新增
                this.addVisitRecord(resolve, reject);
              } else {
                // 如果此人名下有项目
                if (this.projects.length) {
                  // this.$Modal.confirm({
                  //   title: "提示",
                  //   render: h => {
                  //     return h("div", [
                  //       h("div", [
                  //         h("p", "您负责的项目名称如下:"),
                  //         h(
                  //           "p",
                  //           "如需将此机构分配至某一项目下，选中该项目，点击确定即可;"
                  //         ),
                  //         h("p", "如不需要分配，直接点击确定即可；"),
                  //         h("p", "点击取消回到填写拜访记录界面。")
                  //       ]),
                  //       h(
                  //         "RadioGroup",
                  //         {
                  //           props: {
                  //             value: this.projectId
                  //           },
                  //           style: {
                  //             marginTop: "15px",
                  //             marginLeft: "15px"
                  //           },
                  //           on: {
                  //             "on-change": val => {
                  //               this.projectId = val;
                  //             }
                  //           }
                  //         },
                  //         [
                  //           ...this.projects.map(function(item) {
                  //             return h(
                  //               "Radio",
                  //               {
                  //                 style: {
                  //                   display: "block"
                  //                 },
                  //                 props: {
                  //                   label: item.projectId
                  //                 }
                  //               },
                  //               item.projectName
                  //             );
                  //           })
                  //         ]
                  //       )
                  //     ]);
                  //   },
                  //   onOk: () => {
                  //     if (this.projectId) {
                  //       // 加入项目后新增
                  //       this.addOrgToProject(
                  //         this.initOrgId,
                  //         this.projectId,
                  //         resolve,
                  //         reject
                  //       );
                  //     } else {
                  //       // 新增
                  //       this.addVisitRecord(resolve, reject);
                  //     }
                  //   },
                  //   onCancel: () => {
                  //     this.projectId = "";
                  //   }
                  // });
                  this.addVisitRecord(resolve, reject);
                } else {
                  // 加入项目后新增
                  this.addVisitRecord(resolve, reject);
                  this.$Message.info(
                    "该机构目前不在单个项目中，若有销售项目管理需要，请在项目管理中进行项目设置."
                  );
                }
              }
            } else {
              // 新增
              this.addVisitRecord(resolve, reject);
            }
          } else {
            this.$emit("setButtonLoadingStatus", false);
            this.$Message.error("请按要求填充");
          }
        });
      });
    },
    //添加销售项目管理前的提交方式
    submit1() {
      return new Promise((resolve, reject) => {
        let selectedPeopleId = JSON.parse(
          JSON.stringify(this.selectedPeopleId)
        );
        let shareContent = this.shareContent;
        this.$refs.form.validate(valid => {
          if (valid) {
            let data = JSON.parse(JSON.stringify(this.form));
            if (data.visit_time) {
              data.visit_time = this.setTimeZone(data.visit_time);
            }

            if (data.order_time) {
              data.order_time = this.setTimeZone(data.order_time);
            }

            if (data.id) {
              //修改记录
              putFormData("index/visit", data.id, data).then(resp => {
                if (resp.code === 20000) {
                  this.$Message.success("修改拜访记录成功");
                  resolve();
                } else {
                  this.$Message.error("修改拜访记录失败 " + resp.msg);
                  reject();
                }
              });
            } else {
              if (!this.selectedPeopleName.length && shareContent.trim()) {
                this.choosePeople = true;
                this.$emit("setButtonLoadingStatus", false);
                reject();
                return;
              } else {
                this.choosePeople = false;
              }
              //新增记录
              postFormData("index/visit", data).then(resp => {
                if (resp.code === 20000) {
                  resolve();
                  this.$Message.success("新增拜访记录成功");
                  this.$emit("addVisitSuccess");
                  //判断是否需要发送提醒消息
                  if (selectedPeopleId.length) {
                    //已经选中提醒的人
                    let content =
                      shareContent ||
                      `${
                        this.user.trueName
                      }给$name分享了一条拜访记录[系统日志]`;
                    let visit_id = resp.data.id;
                    let params = {
                      type: 4,
                      to_id: selectedPeopleId,
                      message: content,
                      visit_id: visit_id
                    };
                    postFormData("msg/send", params)
                      .then(resp => {
                        if (resp.code === 20000) {
                          this.$Message.success("已为您发送提醒");
                        } else {
                          this.$Message.error("发送提醒失败 " + resp.msg);
                        }

                        //获取消息数
                        getMessageCount().then(res => {
                          let count = res.data.total;
                          this.$store.dispatch("setMessageCount", {
                            messageCount: count
                          });
                        });
                      })
                      .then(() => {
                        this.clearShareParams();
                      });
                  }
                } else {
                  this.$Message.error("新增拜访记录失败 " + resp.msg);
                  reject();
                }
              });
            }
            this.resetForm();
            this.$emit("closeModal");
          } else {
            this.$emit("setButtonLoadingStatus", false);
            this.$Message.error("请按要求填充");
          }
        });
      });
    },

    addVisitRecord(resolve, reject) {
      let selectedPeopleId = JSON.parse(JSON.stringify(this.selectedPeopleId));
      let shareContent = this.shareContent;
      let data = JSON.parse(JSON.stringify(this.form));

      if (data.visit_time) {
        data.visit_time = this.setTimeZone(data.visit_time);
      }

      if (data.order_time) {
        data.order_time = this.setTimeZone(data.order_time);
      }

      if (data.id) {
        //修改记录
        putFormData("index/visit", data.id, data).then(resp => {
          if (resp.code === 20000) {
            this.$Message.success("修改拜访记录成功");
            resolve();
          } else {
            this.$Message.error("修改拜访记录失败 " + resp.msg);
            reject();
          }
        });
      } else {
        if (!this.selectedPeopleName.length && shareContent.trim()) {
          this.choosePeople = true;
          this.$emit("setButtonLoadingStatus", false);
          reject();
          return;
        } else {
          this.choosePeople = false;
        }
        //新增记录
        postFormData("index/visit", data).then(resp => {
          if (resp.code === 20000) {
            this.$Message.success("新增拜访记录成功");
            this.$emit("addVisitSuccess");
            resolve();
            //判断是否需要发送提醒消息
            if (selectedPeopleId.length) {
              //已经选中提醒的人
              let content =
                shareContent ||
                `${this.user.trueName}给$name分享了一条拜访记录[系统日志]`;
              let visit_id = resp.data.id;
              let params = {
                type: 4,
                to_id: selectedPeopleId,
                message: content,
                visit_id: visit_id
              };
              postFormData("msg/send", params)
                .then(resp => {
                  if (resp.code === 20000) {
                    this.$Message.success("已为您发送提醒");
                  } else {
                    this.$Message.error("发送提醒失败 " + resp.msg);
                  }

                  //获取消息数
                  getMessageCount().then(res => {
                    let count = res.data.total;
                    this.$store.dispatch("setMessageCount", {
                      messageCount: count
                    });
                  });
                })
                .then(() => {
                  this.clearShareParams();
                });
            }
          } else {
            this.$Message.error("新增拜访记录失败 " + resp.msg);
            reject();
          }
        });
      }
      this.resetForm();
      this.$emit("closeModal");
    },
    addOrgToProject(orgId, projectId, resolve, reject) {
      let data = { orgId, projectId };
      saleProjectManageService.addOrgToProject(data).then(res => {
        if (res.code === 20000) {
          this.addVisitRecord(resolve, reject);
        }
      });
    },
    showPeopleModal() {
      this.$refs.people.show(null, this.selectedPeopleId);
    },
    showMorePeople() {
      if (!this.showHeight) {
        this.showHeight = true;
      } else {
        this.showHeight = false;
      }
    },
    getSelectedPeople(selectedPerson) {
      this.selectedPeople = JSON.parse(JSON.stringify(selectedPerson));
      this.selectedPeopleName = selectedPerson.map(person => {
        return person.memberName;
      });
      this.selectedPeopleId = selectedPerson.map(person => {
        return person.id;
      });
    },
    //获取其他接待人下拉框选项
    showOthersSelect() {
      let orgId = this.form.org_id;
      if (orgId) {
        this.showOthers = true;
        this.otherLoading = true;
        fetchSelect("contact/other/" + orgId).then(resp => {
          this.otherLoading = false;
          if (resp.code === 20000) {
            this.others = resp.data.data;
          }
        });
      } else {
        this.$Message.warning("请先确定拜访对象");
      }
    },
    chooseTarget() {
      this.$refs.chooseTarget.show();
    },
    confirmVisitTarget(person) {
      this.form = {
        ...this.form,
        contacts_id: person.id ? person.id + "" : this.form.contacts_id,
        contacts_name: person.title ? person.title : this.form.contacts_name,
        org_id: person.org_id ? person.org_id : this.form.org_id,
        contacts_ids: person.id ? [] : this.form.contacts_ids
      };
      // this.showOthersSelect();
    },
    clearShareParams() {
      this.selectedPeople = [];
      this.selectedPeopleId = [];
      this.selectedPeopleName = [];
      this.shareContent = "";
      this.projectId = "";
      this.currentVisitRecordId = "";
    }
  }
};
</script>
<style lang="less" rel="styleSheet/less">
.show_container {
  width: 100%;
  height: 40px;
  min-height: 40px;
  border: 1px solid #dddee1;
  border-radius: 5px;
  position: relative;
  padding-bottom: 10px;
  word-wrap: break-word;
  .show-content {
    width: 100%;
    height: 100%;
    overflow: hidden;
    padding: 5px;
    line-height: 22px;
  }
  .total {
    display: inline-block;
    position: absolute;
    bottom: -10px;
    right: 10px;
    padding: 0 10px;
    background-color: white;
    height: 20px;
    line-height: 20px;
  }
  .tool {
    cursor: pointer;
    width: 60px;
    height: 20px;
    margin: 0px 5px;
    padding: 0 10px;
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translate(-50%, 0);
    background-color: #fff;
    .icon-container {
      float: left;
      display: inline-block;
      position: relative;
      margin-left: 2px;
      .icon {
        display: block;
        position: absolute;
        top: -3px;
        &.second {
          top: 0px;
        }
        &.thrid {
          top: 3px;
        }
      }
    }
    .text {
      float: left;
      line-height: 20px;
      font-size: 12px;
      color: #666;
    }
  }
}

.showMorePeople.show_container {
  height: auto;
}

.chosenPeople {
  border: 1px solid red;
  border-radius: 6px; // width: 500px;
}
.object-bread {
  display: inline-block;
  max-width: 280px;
  vertical-align: top;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  opacity: 0.7;
}

.others {
  vertical-align: top;
  display: inline-block;
  max-width: 250px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
