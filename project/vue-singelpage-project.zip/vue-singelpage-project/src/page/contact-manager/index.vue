<template>
  <div class="grid-content">
    <!-- 搜索表单区域 -->
    <div class="searchArea keydown-box">
      <search-area ref="form" @changeSearchParam="changeSearchParam" @onKeydownSearch="search">
        <div slot="default">
          <Row>
            <Col span="8">
              <Form-item label="姓名职务">
                <Row>
                  <Col span="11">
                    <Input v-model.trim="formSearch.name" placeholder="姓名"></Input>
                  </Col>

                  <Col span="12" offset="1">
                    <Input v-model.trim="formSearch.post" placeholder="职务"></Input>
                  </Col>
                </Row>
              </Form-item>
            </Col>

            <Col span="8" offset="1">
              <Form-item label="联系方式">
                <Row>
                  <Col span="11">
                    <Input v-model.trim="formSearch.telephone" placeholder="电话"></Input>
                  </Col>

                  <Col span="12" offset="1">
                    <Input v-model.trim="formSearch.email" placeholder="邮箱"></Input>
                  </Col>
                </Row>
              </Form-item>
            </Col>

            <Col span="4">
              <div class="button-search">
                <Button type="primary" @click="search">搜索</Button>
                <Button @click="onReset" style="margin-right:0;">重置</Button>
              </div>
            </Col>
          </Row>
        </div>

        <div slot="extend">
          <Row>
            <Col span="8">
              <FormItem label="更新人">
                <Row>
                  <Col span="11">
                    <Select
                      v-model="chosenDepartment"
                      placeholder="请选择部门"
                      clearable
                      @on-change="onCascaderChange"
                    >
                      <Option
                        v-for="item in department"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>

                  <Col span="12" offset="1">
                    <Select
                      v-model="person"
                      not-found-text="无匹配数据"
                      :disabled="choose"
                      clearable
                      placeholder="更新人"
                      style="width:100%;"
                      @on-change="onPersonChange"
                    >
                      <Option
                        v-for="item in select_update"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>
                </Row>
              </FormItem>
            </Col>

            <Col span="8" offset="1">
              <FormItem label="更新时间">
                <DatePicker
                  style="width:100%;"
                  type="daterange"
                  format="yyyy-MM-dd"
                  placeholder="选择日期"
                  v-model="formSearch.update_time"
                ></DatePicker>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="8">
              <FormItem label="机构">
                <Row>
                  <Col span="11">
                    <Select v-model="formSearch.oc_id" clearable placeholder="请选择">
                      <Option
                        v-for="item in emnus.c_org"
                        :value="item.value"
                        :key="item.value"
                      >{{item.name}}</Option>
                    </Select>
                  </Col>

                  <Col span="12" offset="1">
                    <Select
                      v-model="formSearch.depart_id"
                      not-found-text="无匹配数据"
                      clearable
                      placeholder="请选择机构"
                      style="width:100%;"
                    >
                      <Option
                        v-for="item in orgList"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>
                </Row>
              </FormItem>
            </Col>

            <Col span="8" offset="1">
              <FormItem label="客户类型">
                <Select
                  v-model="formSearch.contacts_type"
                  not-found-text="无匹配数据"
                  clearable
                  placeholder="请选择客户类型"
                  style="width:100%;"
                >
                  <Option
                    v-for="item in contactsType"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value"
                  ></Option>
                </Select>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="8">
              <FormItem label="画像">
                <Select v-model="formSearch.portrait" clearable placeholder="请选择画像" multiple>
                  <Option v-for="item in portraits" :value="item.value" :key="item.id">
                    <Tag :style="item.style">{{item.name}}</Tag>
                  </Option>
                </Select>
              </FormItem>
            </Col>
          </Row>
        </div>
      </search-area>
    </div>

    <!--导出按钮-->
    <div class="clear">
      <Button type="primary" class="pull-right" @click="onExport(3)">导出</Button>
    </div>

    <!-- 表格 -->
    <div class="tableContainer">
      <Table
        class="table-grid"
        border
        :columns="columns"
        :data="tableData"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
      />
    </div>
    <!-- 分页器 -->
    <div class="page-load">
      <div class="float-right">
        <Page
          :total="total"
          placement="top"
          :current="currentPage"
          :page-size="pageSize"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizeChange"
          show-elevator
          show-sizer
          show-total
        />
      </div>
    </div>

    <!-- 子组件，显示编辑界面 -->
    <visit-contact-dialog
      ref="visitContactDialog"
      @refreshTable="refreshTable"
      :orgId="visitProps.orgId"
      :memberData="visitProps.memberData"
      :showType="showType"
    ></visit-contact-dialog>

    <addAccountModal ref="addAccountModal" @refreshTable="search"></addAccountModal>
    <unactiveFofModal ref="unactiveFofModal" @refreshTable="search"></unactiveFofModal>
    <unactiveFmModal ref="unactiveFmModal" @refreshTable="search"></unactiveFmModal>
    <addFmAccountModal ref="addFmAccountModal" @refreshTable="search"/>
  </div>
</template>
<script>
import searchArea from "../../components/search-area";
import { extend, each } from "underscore";
import { getCache } from "@/plugin/cache";
import {
  fetchGrid,
  delRow,
  fetchWorkmate,
} from "@/service/getData";
import visitContactDialog from "./visit-contact-dialog";
import { mapGetters } from "vuex";
import SelectUrl from "@/components/inputs/select-url";
import { getReciver } from "@/service/getData";
import addAccountModal from "@/page/account-justify/components/add-account-modal";
import $ from "jquery";
import moment from "moment";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import unactiveFofModal from "./components/unactive-fof-account-modal.vue";
import unactiveFmModal from "./components/unactive-fm-accounts-modal.vue";
import addFmAccountModal from "../fm-account-manager/components/add-account";
export default {
  mixins: [getMinusNumber],
  components: {
    visitContactDialog,
    SelectUrl,
    searchArea,
    addAccountModal,
    unactiveFofModal,
    unactiveFmModal,
    addFmAccountModal
  },
  data() {
    return {
      addMsgLogo: require("../../assets/addMsg.png"),
      portraits: [],
      paramsOfDownload: {},
      isShowMoreParams: false,
      person: [],
      contactsType: [],
      orgList: [],
      choose: true,
      //人员下拉数据
      select_update: [],
      tableLoading: false,
      //加载动画
      loading: false,
      //表格数据
      tableData: [],
      //每页数量
      pageSize: 10,
      //总数量
      total: 0,
      //当前页面
      currentPage: 1,
      //判断是否是搜索，便于加载不同的表格
      isSearch: false,
      //传递给服务器的参数
      formSearch: {
        update_time: [],
        portrait: [],
        dept_id: [],
        name: "",
        post: "",
        update_member_id: [],
        depart_id: [],
        contacts_type: [],
        telephone: "",
        email: "",
        oc_id: []
      },
      chosenDepartment: "",
      listUrl: "/index/contact",
      export: "/index/contactexport",
      dialogShow: false,
      visitProps: { 
        memberData: {}
      },
      showType: "user",
      department: [],
      date: [],
      columns: [
        {
          title: "姓名",
          key: "name",
          width: 90,
          fixed: "left",
          render: (h, { row }) => {
            if (!row.telephone || !row.visiting_card_url || !row.email) {
              return h(
                "div",
                {
                  style: {
                    display: "flex",
                    "justify-content": "flex-satrt",
                    "align-items": "center"
                  }
                },
                [
                  h("div", {
                    attrs: {
                      title: "请补充联系人信息"
                    },
                    style: {
                      cursor: "pointer",
                      backgroundImage: `url(${this.addMsgLogo})`,
                      backgroundSize: "100%",
                      backgroundRepeat: "no-repeat",
                      width: "20px",
                      height: "20px",
                      "margin-right": "10px"
                    }
                  }),
                  h(
                    "div",
                    {
                      style: {
                        flex: 1
                      }
                    },
                    row.name || "--"
                  )
                ]
              );
            } else {
              return h("span", row.name || "--");
            }
          }
        },
        {
          title: "电话",
          key: "telephone",
          width: 100,
          fixed: "left",
          render(h, { row }) {
            return row.telephone || "--";
          }
        },
        {
          title: "机构名称",
          key: "org_name",
          width: 350,
          fixed: "left",
          render: (h, params) => {
            if (params.row.bread && params.row.bread.length) {
              return h(
                "div",
                params.row.bread
                  .map((bread, index, breads) => {
                    return h(
                      "a",
                      {
                        on: {
                          click: e => {
                            let tab = {
                              activeName: bread.title,
                              pid: bread.id,
                              name: `${bread.title}${bread.id}`,
                              component: "departmentDetails",
                              isShow: true
                            };
                           
                            this.$store.dispatch("setTabs", tab);
                            e.stopPropagation();
                          }
                        }
                      },
                      index === breads.length - 1
                        ? `${bread.title}`
                        : `${bread.title}>`
                    );
                  })
                  .splice(1)
              );
            } else {
              return h(
                "a",
                {
                  on: {
                    click: e => {
                      let tab = {
                        activeName: params.row.org_name,
                        pid: params.row.org_id,
                        name: `${params.row.org_name}${params.row.org_id}`,
                        component: "departmentDetails",
                        isShow: true
                      };
                      this.$store.dispatch("setTabs", tab);
                      e.stopPropagation();
                    }
                  }
                },
                params.row.org_name
              );
            }
          }
        },
        {
          title: "职务",
          key: "post",
          width: 110,
          render(h, { row }) {
            return row.post || "--";
          }
        },
        {
          title: "名片",
          key: "visiting_card_url",
          width: 80,
          render(h, { row }) {
            let url;
            if (row.visiting_card_url) {
              let picUrl = JSON.parse(JSON.stringify(row.visiting_card_url));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? "http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";
                picUrl = `Uploads/crm/${row.visiting_card_url}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        },
        {
          title: "客户类型",
          key: "contacts_type",
          width: 110,
          render: (h, params) => {
            let userType = [];
            let contact = params.row.contacts_type + "";
            this.contactsType.forEach(item => {
              if (params.row.contacts_type) {
                if (contact.indexOf(item.value) != -1) {
                  userType.push(item.name);
                }
              } else {
                userType = ["未知"];
              }
            });
            return h("p", userType.join(","));
          }
        },
        {
          title: "客户部门",
          key: "depart_id",
          width: 110,
          render: (h, params) => {
            let cDepart = getCache("c_depart", params.row.depart_id);
            return h("p", cDepart);
          }
        },
        {
          title: "邮箱",
          key: "email",
          width: 210,
          align: "center",
          render: (h, params) => {
            return h("p", params.row.email ? params.row.email : " --");
          }
        },
        {
          title: "更新时间",
          key: "update_time",
          width: 100,
          render: (h, params) => {
            return h(
              "p",
              {
                attrs: {
                  title: `${params.row.update_time}`
                }
              },
              `${params.row.update_time.substring(0, 10)}`
            );
          }
        },
        {
          title: "更新人",
          key: "update_member_id",
          width: 90,
          render: (h, params) => {
            return h("p", `${params.row.update_member_name}` || "--");
          }
        },
        {
          title: "账号开通",
          key: "createAccount",
          width: 160,
          align: "center",
          fixed: "right",
          render: (h, { row }) => {
            let fofTitle = "";
            let fmTitle = "";
            let fofFlag = false;
            let fmFlag = false;
            //  账号信息补全、有正常状态的账号时组合大师账号不可操作
            // fof_accounts 1:有账号 2：没有账号 3：有账号状态不正常 (基金大师账号保持一致)
            fofFlag =
              fofFlag ||
              (!row.telephone || !row.visiting_card_url || !row.email) ||
              row.fof_accounts == 1;

            fmFlag =
              fmFlag ||
              !this.canAdd ||
              (!row.telephone || !row.visiting_card_url) ||
              row.fm_accounts == 1 ||
              !row.company_id;

            if (fofFlag) {
              fofTitle =
                !row.telephone || !row.visiting_card_url || !row.email
                  ? "联系人信息缺失"
                  : "已有账号";
            }

            if (fmFlag) {
              if (!this.canAdd) {
                fmTitle = "没有权限";
              } else if (!row.telephone || !row.visiting_card_url) {
                fmTitle = "联系人信息缺失";
              } else if (row.fm_accounts == 1) {
                fmTitle = "已有账号";
              } else if (!row.company_id) {
                fmTitle = "联系人公司id缺失";
              }
            }

            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: fofFlag ? "disabledBtn" : "deleteBtn",
                    title: fofTitle
                  },
                  on: {
                    click: e => {
                      if (fofFlag) {
                        return;
                      }
                      e.stopPropagation();

                      if (row.fof_accounts == 3) {
                        this.$refs.unactiveFofModal.show(row);
                      } else {
                        this.$refs.addAccountModal.show(row);
                      }
                    }
                  }
                },
                "组合大师"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: fmFlag ? "disabledBtn" : "deleteBtn",
                    title: fmTitle
                  },

                  on: {
                    click: e => {
                      if (fmFlag) {
                        return;
                      }
                      e.stopPropagation();

                      if (row.fm_accounts == 3) {
                        this.$refs.unactiveFmModal.show(row);
                      } else {
                        let info = {
                          linkMan: "",
                          mobile: "",
                          position: "",
                          visitingCardUrl: ""
                        };

                        info.linkMan = row.name;
                        info.mobile = row.telephone;
                        info.position = row.post;
                        info.visitingCardUrl = row.visiting_card_url;
                        info.sex = +row.sex;
                        this.$refs.addFmAccountModal.show(
                          {},
                          row.company_id,
                          info
                        );
                      }
                    }
                  }
                },
                "基金大师"
              )
            ]);
          }
        },
        {
          title: "操作",
          fixed: "right",
          align: "center",
          width: 140,
          render: (h, params) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();
                      this.onRowDblclick(params.row);
                    }
                  }
                },
                "编辑"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: e => {
                      e.stopPropagation();
                      this.visitContact(params.row);
                    }
                  }
                },
                "拜访"
              ),
              h(
                "div",
                {
                  attrs: {
                    class:
                      params.row.create_member_id === this.userId || this.canDelete
                        ? "deleteBtn"
                        : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (params.row.create_member_id !== this.userId && !this.canDelete) {
                        return;
                      }
                      this.deleteContact(params.row.id);
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ]
    };
  },
  watch: {
    "formSearch.portrait": {
      handler(val) {
        setTimeout(() => {
          let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(this.$el).find(
            ".ivu-select-selection .ivu-tag span"
          );
          let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
          let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    },
    chosenDepartment: {
      handler(val) {
        if (val) {
          this.choose = true;
        }
      },
      deep: true
    },
    "formSearch.update_time": {
      handler(val) {
        if (val.length && val[0]) {
          this.formSearch.update_time[0] = this.setTimeZone(val[0]);
          this.formSearch.update_time[1] = this.setTimeZone(val[1]);
        }
      },
      deep: true
    }
  },

  mounted() {
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".searchArea", ".clear", ".page-load"],
      ".tableContainer"
    );
    this.loading = true;
    this.updateGrid();
    this.getDepartment();
    // this.getOrgList();
    this.orgList = this.emnus.c_depart;
    this.contactsType = this.emnus.c_usertype;
    this.portraits = this.emnus.c_port_all;
  },
  computed: {
    ...mapGetters({
      emnus: "getEnums",
      tabs: "getTabs",
      userInfo: "getUser",
      userId: "getUserId" 
    }),
    canAdd() {
      return this.userInfo.auth.functional.includes("addFmAccount");
    },

    canDelete(){
      return this.userInfo.auth.functional.includes("deleteContact");
    }
  },
  methods: {
    // 删除联系人
    deleteContact(id) {
      this.$Modal.confirm({
        title: "删除",
        content: "删除当前联系人？",
        okText: "确定",
        cancelText: "取消",
        loading: true,
        onOk: () => {
          this.$http.del("/index/contact", id).then(res => {
            if (res.code === 20000) {
              this.$Message.info("删除成功");
              this.refreshTable();
            } else {
              this.$Message.error(`${res.msg}`);
            }
            this.$Modal.remove();
          });
        }
      });
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 102;
      let minusNumber = this.getMinusNumberOfFixedTable();
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },

    //编辑后刷新表格
    refreshTable() {
      this.updateGrid();
    },

    // 控制更多打开时传递的参数
    changeSearchParam(val) {
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".searchArea", ".clear", ".page-load"],
          ".tableContainer"
        );
      });

      this.isShowMoreParams = val;
    },

    // 选择不同的人时的事件
    onPersonChange(val) {
      this.formSearch.update_member_id = val;
    },

    //获取部门下拉
    getDepartment() {
      fetchWorkmate().then(res => {
        if (res.code == 20000) {
          this.department = res.data;
        }
      });
    },

    // 部门选择发生变化
    onCascaderChange(val) {
      this.choose = true;
      this.select_update = [];
      this.formSearch.dept_id = val;
      let data = {
        dept_id: this.formSearch.dept_id,
        type: 1
      };
      if (!val) {
        return;
      }
      this.getWorkmate(data);
    },

    //根据部门级联选择更新人
    getWorkmate(data) {
      if (this.formSearch.dept_id.length == 0) {
        this.choose = true;
      }
      getReciver(data).then(res => {
        if (res.code == 20000) {
          this.select_update = res.data;
          this.choose = false;
        }
      });
    },

    //用于管理传递的参数
    params(val) {
      let searchParams = {};
      let searchKeys = {};
      if (this.searching) {
        if (!this.isShowMoreParams) {
          for (let key in this.formSearch) {
            if (
              key == "name" ||
              key == "post" ||
              key == "telephone" ||
              key == "email"
            ) {
              searchKeys[key] = this.formSearch[key];
            }
          }
        } else {
          if (
            !this.formSearch.update_time[0] &&
            !this.formSearch.update_time[1]
          ) {
            for (var key in this.formSearch) {
              if (key != "update_time") {
                searchKeys[key] = this.formSearch[key];
              }
            }
          } else {
            searchKeys = this.formSearch;
          }
        }

        searchParams = JSON.parse(JSON.stringify(searchKeys));
      } else if (val) {
        //重置时的参数
        this.handleReset("form");
        searchKeys = this.formSearch;
        searchParams = JSON.parse(JSON.stringify(searchKeys));
      }
      this.paramsOfDownload = searchParams;
      return extend(
        {
          rows: this.pageSize,
          page: this.currentPage
        },
        searchParams
      );
    },

    //导出参数
    paramsDown(val) {
      return extend(
        {
          rows: this.total > 1000 ? 1000 : this.total,
          page: this.currentPage
        },
        this.paramsOfDownload
      );
    },

    //更新表格
    updateGrid(val) {
      this.tableLoading = true;
      fetchGrid(this.listUrl, this.params(val)).then(
        resp => {
          resp = resp.data;
          this.tableData = resp.data;
          this.total = resp.total;
          this.loading = false;
          this.tableLoading = false;
        },
        error => {
          this.loading = false;
          console.log(error);
        }
      );
    },

    //搜索
    search() {
      this.searching = true;
      this.cleanAndUpdateGrid();
    },

    //回到第一页并更新表格
    cleanAndUpdateGrid(val) {
      this.currentPage = 1;
      this.pageSize = 10;
      this.updateGrid(val);
    },

    //页码改变
    onPageChange(val) {
      this.currentPage = val;
      this.updateGrid();
    },

    //单页显示数量发生改变
    onPageSizeChange(val) {
      this.currentPage = 1;
      this.pageSize = val;
      this.updateGrid();
    },

    //重置
    onReset() {
      this.searching = false;
      this.select_update = [];
      this.choose = true;
      this.formSearch.update_time = [];
      this.chosenDepartment = "";
      this.formSearch.dept_id = [];
      this.formSearch.name = "";
      this.formSearch.post = "";
      this.formSearch.update_member_id = [];
      this.formSearch.depart_id = [];
      this.formSearch.contacts_type = [];
      this.formSearch.telephone = "";
      this.formSearch.email = "";
      this.formSearch.portrait = [];
      this.formSearch.oc_id = [];
      this.cleanAndUpdateGrid(true);
    },

    //导出
    onExport(type) {
      if (this.total === 0) {
        this.$Message.warning({
          content: "无可导出数据"
        });
        return;
      }
      this.$Message.loading({
        content: "正在导出中，请稍候...",
        duration: 0
      });
      fetchGrid(this.export, this.paramsDown()).then(
        resp => {
          if (resp.code == 20000) {
            resp = resp.data;
            const link = document.createElement("a");
            link.href = resp.url;
            link.target = "_blank";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }
          this.$Message.destroy();
          this.$Message.info("导出成功！");
        },
        error => {
          this.$Message.destroy();
          this.$Message.warning("导出失败！");
          console.log(error);
        }
      );
    },

    //   编辑显示模态框
    onRowDblclick(row) {
      let params = {
        tabShow: "user",
        personId: row.id,
        personName: row.name,
        orgId: row.org_id
      }
      this.$refs.visitContactDialog.show(params);
    },

    visitContact(row) {
      let params = {
        tabShow: "visit",
        personId: row.id,
        personName: row.name,
        orgId: row.org_id
      }
      this.$refs.visitContactDialog.show(params);
    },

    // 重置表单内容
    handleReset(name) {
      this.$refs[name].$refs[name].resetFields();
    }
  }
};
</script>
<style lang="less" scoped>
.grid-content {
  // margin: 5px;
  position: relative;
}

.form.ivu-form.ivu-form-label-right {
  border-bottom: 1px solid rgb(233, 234, 236);
  padding: 30px 200px 20px 0px;
}

.ivu-col.ivu-col-span-4 .button-search {
  margin-left: 10px;
}

.pull-right.ivu-btn.ivu-btn-primary {
  float: right;
  margin: 8px 0px;
}

.page-load {
  margin: 10px;
  overflow: hidden;
  .float-right {
    float: right;
  }
}

.ivu-form-item {
  // width: 80%;
}

.table-grid {
  // margin-top: 5px;
}
</style>
