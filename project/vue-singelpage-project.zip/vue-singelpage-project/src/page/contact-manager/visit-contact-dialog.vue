<template>
  <Modal
    width="1000"
    v-model="modal"
    :title="modalTitle"
    :scrollable="true"
    :loading="loading"
    :mask-closable="false"
    @on-cancel="cancel"
    class="visitRecordModal add-contracts-modal"
  >
    <Tabs :animated="false" v-model="tabShow" @on-click="handelTabChange">
      <Tab-pane label="画像" name="user" class="tabs-tab-active">
        <customer-info ref="user" v-show="tabShow == 'user' " :personId="personId"></customer-info>
      </Tab-pane>

      <Tab-pane label="记录" name="visit">
        <visit-contact-add
          ref="visit"
          v-show="tabShow == 'visit'"
          :personId="personId"
          :personName="personName"
          :orgId="orgId"
          @setButtonLoadingStatus="setButtonLoadingStatus"
          @changeVisitType="changeVisitType"
          @changeSelfType="changeSelfType"
          @closeModal="closeModal"
          @addVisitSuccess="addVisitSuccess"
        ></visit-contact-add>
      </Tab-pane>
      <!-- 记录页面 -->
      <!--  -->
    </Tabs>
    <div slot="footer">
      <template v-if="tabShow == 'user'">
        <!-- 需手动识别名片，取消注释即可 -->
        <Button @click="identifyVisitCard">识别名片</Button>
        <Button type="default" @click="cancel">取消</Button>
        <Button type="primary" @click="submitUser" :loading="buttonLoading">确定</Button>
      </template>

      <template v-else>
        <template v-if="visitTabType == 'self'">
          <Button type="default" @click="cancel">取消</Button>
          <Button type="primary" @click="submitRecord" :loading="buttonLoading">{{buttonText}}</Button>
        </template>

        <template v-else>
          <Button @click="cancel">关闭</Button>
        </template>
      </template>
    </div>
  </Modal>
</template>

<script>
// import visitContactIndex from "./visit-contact-index";
import customerInfo from "@/components/common-components/customer/customer-info.vue";
import visitContactAdd from "./visit-contact-add";
import { getRow, putFormData } from "@/service/getData";

export default {
  components: {
    customerInfo,
    visitContactAdd
  },
  data() {
    return {
      modalTitle: "",
      buttonLoading: false,
      modal: false,
      loading: "",
      personId: -1, //联系人id
      personName: "", //联系人名称
      orgId: "", //联系人上级机构id
      tabShow: "visit",
      visitTabType: "self",
      selfType: "add"
    };
  },
  computed: {
    buttonText() {
      return this.selfType == "add" ? "新增记录" : "修改记录";
    }
  },

  watch: {
    tabShow: {
      handler(val) {
        if (val === "visit") {
          this.modalTitle = "用户拜访记录";
        } else {
          this.modalTitle = "编辑联系人";
        }
      },
      immediate: true
    }
  },
  methods: {
    identifyVisitCard(){
      // user组件目录 ：../../components/common-components/customer/customer-info.vue
      this.$refs.user.identifyVisitCard();
    },


    show({ tabShow, personId, personName, orgId, visitId, visitorId }) {
      this.tabShow = tabShow;
      this.personId = personId;
      this.personName = personName;
      this.orgId = orgId;
      this.modal = true;
      this.$refs.user.show(orgId, personId);
      this.$refs.visit.show({
        personId,
        personName,
        orgId,
        visitId,
        visitorId
      });
    },

    hide() {
      this.modal = false;
    },
    ok() {},
    cancel() {
      this.hide();
      this.$refs.user.resetForm();
      this.$refs.visit.resetForm();
      this.$refs.visit.clearShareParams();
      this.buttonLoading = false;
    },
    handelTabChange(val) {
      this.tabShow = val;
    },
    changeVisitType(val) {
      this.visitTabType = val;
    },
    changeSelfType(val) {
      this.selfType = val;
    },
    submitRecord() {
      this.buttonLoading = true;
      this.$refs.visit.submit().then(() => {
        this.$refs.visit.clearShareParams();
        this.$emit("refreshTable");
        this.buttonLoading = false;
      });
      setTimeout(() => {
        this.buttonLoading = false;
      }, 800);
    },
    setButtonLoadingStatus(val) {
      this.buttonLoading = val;
    },
    submitUser() {
      this.buttonLoading = true;
      this.$refs.user.getSubmitFormData().then(submitData => {
        if (submitData) {
          putFormData("/index/contact", this.personId, submitData).then(
            resp => {
              this.buttonLoading = false;
              if (resp.code === 20000) {
                this.$Message.success("修改成功");
                this.cancel();
                this.$emit("refreshTable");
              } else {
                this.$Message.error("修改失败 " + resp.msg);
              }
            }
          );
        } else {
          this.buttonLoading = false;
        }
      });

      // this.$refs.user.submit().then(() => {
      //   this.buttonLoading = false;
      //   this.$emit("refreshTable");
      //   this.cancel();
      // });
      // setTimeout(() => {
      //   this.buttonLoading = false;
      // }, 800);
    },
    closeModal() {
      this.cancel();
    },
    showVst(contactId, visitId, orgId) {
      let params = {
        tabShow: "visit",
        personId: contactId,
        personName: "",
        orgId,
        visitId
      };

      this.show(params);
    },
    addVisitSuccess() {
      this.$emit("refreshTable");
    }
  }
};
</script>

<style scoped lang="less">
.dialog-form-item {
  display: inline-block;
  width: 330px;
}

.dialog-form-item-row {
  display: inline-block;
  width: 660px;
}
</style>
