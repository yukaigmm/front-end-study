<template>
  <Modal v-model="modal" title="请选择" class="people-modal" :mask-closable="false" width="300">
    <Spin fix v-if="loading">
      <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
      <div>Loading</div>
    </Spin>

    <div v-else>
      <span style="color: #ed3f14" v-show="isShare">注：已分享、转发过的人无法再次分享、转发</span>
      <Row type='flex' justify='start'>
        <Col>
        <!-- <Tree :data="treeData" multiple show-checkbox empty-text="暂无数据" ref="tree"></Tree> -->
           <el-tree
             :data="treeData"
             show-checkbox
             node-key="id"
             ref="tree"
             :default-checked-keys="selectedPeopleId"
             :auto-expand-parent="true"
             :default-expanded-keys="defaultExpandedKeys"
             :props="defaultProps"
             @node-click="nodeClick">
           </el-tree>
        </Col>
      </Row>
    </div>

    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button type="primary" @click="ok">确定</Button>
      <Button type="ghost" @click="cancel">取消</Button>
    </div>
  </Modal>
</template>
<script>
import { mapGetters } from "vuex";
import _ from "lodash";
import { fetchGrid } from "@/service/getData";
export default {
  data() {
    return {
      msgType:"",
      isShare: true,
      defaultExpandedKeys: [0],
      modal: false,
      treeData: [],
      visitRecordId: 0,
      loading: false,
      disabledIds: [],
      selectedPeopleId: [],
      defaultProps: {
        children: 'children',
        label: 'title'
      }
    };
  },
  methods: {
    /*
      id:当前记录的id
      selectedPeopleId:已选中的人的id
      type:入口是哪个
    */
    show(id, selectedPeopleId, type,msgType) {
      this.msgType = msgType;
      this.modal = true;
      this.visitRecordId = id;
      this.loading = true;
      // 不需要禁用按钮时
      if (type == "allActive") {
        this.isShare = false;
        this.getTreeData().then(treeData => {
          this.setExpandDepartments(treeData[0], selectedPeopleId);
          let defaultExpandedKeys = JSON.parse(JSON.stringify(this.defaultExpandedKeys))
          this.defaultExpandedKeys = this.getUnrepeated(defaultExpandedKeys)
          this.$nextTick(() => {
            this.selectedPeopleId =
              selectedPeopleId instanceof Array ? selectedPeopleId : [];
          })

          this.treeData = treeData;
          this.loading = false;
        })
      } else {
        this.getTreeData().then(treeData => {
          this.getDisabledPersonIds().then(disabledIds => {
            this.setDisabledPersons(treeData[0], disabledIds);
            this.setExpandDepartments(treeData[0], selectedPeopleId);
            let defaultExpandedKeys = JSON.parse(JSON.stringify(this.defaultExpandedKeys))
            this.defaultExpandedKeys = this.getUnrepeated(defaultExpandedKeys)
            this.$nextTick(() => {
              this.selectedPeopleId =
                selectedPeopleId instanceof Array ? selectedPeopleId : [];
            })

            this.treeData = treeData;
            this.loading = false;
          });
        });
      }

    },
    setExpandDepartments(data, ids, fatherData) {
      if (data.children && data.children.length) {
        _.forEach(data.children, per => {
          if (per.children && per.children.length) {
            _.forEach(per.children, c => {
              this.setExpandDepartments(c, ids, per);
            });
          } else {
            if (ids.indexOf(per.id) !== -1) {
              if (per.type !== 2) {
                this.defaultExpandedKeys.push(per.id);
              }
              this.defaultExpandedKeys.push(data.id);
            }
          }
        });
      } else {
        if (ids.indexOf(data.id) !== -1) {
          if (data.type !== 2) {
            this.defaultExpandedKeys.push(data.id);
          }
          this.defaultExpandedKeys.push(fatherData.id);
        }
      }
    },
    getUnrepeated(item) {
      let res = [];
      let json = {};
      for (let i = 0; i < item.length; i++) {
        if (!json[item[i]]) {
          res.push(item[i]);
          json[item[i]] = 1;
        }
      }
      return res;
    },
    hide() {
      this.defaultExpandedKeys = [0];
      this.modal = false;
      this.isShare = true;
    },
    nodeClick(data, node, comp) {
      let checkedIds = this.$refs.tree.getCheckedNodes(true).map((node) => { return node.id });
      if (data.type === 2) {
        if (checkedIds.indexOf(data.id) !== -1) {
          this.$refs.tree.setChecked(data,false);
        } else {
          this.$refs.tree.setChecked(data,true);
        }
      }
    },
    ok() {
      // 获取选中的节点
      let selectedTreeNodes = this.$refs.tree.getCheckedNodes().filter(node => {
        return !node.children;
      });
      // 处理选中的节点
      let selectedPerson = selectedTreeNodes.map(node => {
        return {
          id: node.id,
          memberName: node.title,
          deptName: node.dept_name
        };
      });
      selectedPerson = selectedPerson.filter(person => {
        return this.disabledIds.indexOf(person.id) == -1;
      });
      this.$emit(
        "getSelectedPeople",
        JSON.parse(JSON.stringify(selectedPerson))
      );
      this.hide();
    },
    cancel() {
      this.msgType = '';
      this.hide();
    },
    getTreeData() {
      return new Promise((resolve, reject) => {
        fetchGrid("dept/getAllTree").then(res => {
          let initTreeData = JSON.parse(JSON.stringify(res.data));
          resolve(initTreeData);
        });
      });
    },
    getDisabledPersonIds() {
      return new Promise((resolve, reject) => {
        if (this.visitRecordId) {
          fetchGrid("msg/getShareToId", {
            from_id: this.userId,
            visit_id: this.visitRecordId,
            msg_type:this.msgType
          }).then(res => {
            let disabledIds = JSON.parse(JSON.stringify(res.data));
            this.disabledIds = JSON.parse(JSON.stringify(disabledIds));
            resolve(disabledIds);
          });
        } else {
          resolve([]);
        }
      });
    },
    setDisabledPersons(data, ids) {
      if (data.children && data.children.length) {
        _.forEach(data.children, per => {
          if (per.children && per.children.length) {
            _.forEach(per.children, c => {
              this.setDisabledPersons(c, ids);
            });
          } else {
            if (ids.indexOf(per.id) !== -1) {
              per.disabled = true;
            }
          }
        });
      } else {
        if (ids.indexOf(data.id) !== -1) {
          data.disabled = true;
        }
      }
    },
    setSelectedPersons(data, ids) {
      if (data.children && data.children.length) {
        _.forEach(data.children, per => {
          if (per.children && per.children.length) {
            _.forEach(per.children, c => {
              this.setSelectedPersons(c, ids);
            });
          } else {
            if (ids.indexOf(per.id) !== -1) {
              per.checked = true;
            }
          }
        });
      } else {
        if (ids.indexOf(data.id) !== -1) {
          data.checked = true;
        }
      }
    }
  },
  computed: {
    ...mapGetters({
      userId: "getUserId"
    })
  },
  mounted() {}
};

</script>
<style lang="less" scoped>
.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}

@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}

</style>
