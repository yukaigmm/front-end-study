<template>
      <Modal
      v-model="modal"
      title="状态不正常账号列表"
      :mask-closable="false"
      width="1000"
    >
      <div slot="footer">
          <Button @click="onCancel">取消</Button>
          <Button @click="onCancel" type="primary">确定</Button>
      </div>

      <div slot="close" @click="onCancel">
          <Icon type="ios-close-empty"></Icon>
      </div>


      <div class="tips-wrap">
          <p><Icon type="information-circled" color="#0c7beb"></Icon>小提示：</p>
          <p>1.该联系人存在状态不正常的账号，如需启用，可在以下列表编辑账号状态;</p>
          <p>2.如需为该联系人开通新账号，点击<span class="create-account-wrap" @click="addAccount">账号开通</span></p>
      </div>

      <div class="table-area">
          <Table
             v-loading='tableLoading'
             element-loading-text='拼命加载中'
             :columns='columns'
             :data='tableData'
             border
             :height="240"
            >
            </Table>
      </div>
      
      <div class="page-load" v-if="total>10">
           <Page
             :total='total'
             placement='top'
             :current='currentPage'
             :page-size='pageSize'
             @on-change='onPageChange'
             @on-page-size-change='onPageSizeChange'
             show-elevator
             show-sizer
             show-total
            >
            </Page>
      </div>

        <addAccountModal  ref="addAccountModal" @refreshTable="refreshTable"></addAccountModal>
        <edit-account-modal ref="editAccountModal" @refreshTable="refreshTable"></edit-account-modal>
        <!-- <reset-password-modal ref="resetPasswordModal"></reset-password-modal> -->
    </Modal> 
</template>

<script>
import addAccountModal from "../../fm-account-manager/components/add-account";
import editAccountModal from "../../fm-account-manager/components/edit-account";
import { mapGetters } from "vuex";
export default {
  components: {
    addAccountModal,
    editAccountModal
  },

  computed: {
    ...mapGetters({
      userInfo: "getUser"
    }),

    canEdit() {
      return this.userInfo.auth.functional.includes("editFmAccount");
    },

    // canDelete() {
    //   return this.userInfo.auth.functional.includes("deleteFmAccount");
    // },

    // canReset() {
    //   return this.userInfo.auth.functional.includes("resetFmPsw");
    // },

    columns() {
      let basicColumn = [
        {
          width: 90,
          title: "姓名",
          key: "linkman",
          render(h, { row }) {
            return h("span", row.linkman || "--");
          }
        },
        {
          width: 200,
          title: "机构名称",
          key: "companyName",
          ellipsis: true,
          render: (h, { row }) => {
            return h(
              "span",
              {
                attrs: {
                  title: row.companyName
                }
              },
              row.companyName || "--"
            );
          }
        },
        {
          width: 100,
          title: "用户名",
          key: "name",
          render(h, { row }) {
            return h("span", row.name || "--");
          }
        },
        {
          width: 120,
          title: "手机号",
          key: "mobile",
          render(h, { row }) {
            return h("span", row.mobile || "--");
          }
        },
        {
          width: 90,
          title: "职位",
          key: "position",
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.position || "--");
          }
        },
        {
          width: 107,
          title: "账号状态",
          key: "status",
          render: (h, { row }) => {
            let mapping = [
              {
                label: "正常",
                value: 1
              },
              {
                label: "禁用",
                value: 2
              },
              {
                label: "离职",
                value: 3
              },
              {
                label: "删除",
                value: 4
              }
            ];

            let text =
              mapping.filter(item => row.status == item.value)[0]["label"] ||
              "--";

            return h("span", text);
          }
        },
        {
          title: "使用情况",
          key: "useStage",
          width: 100,
          render: (h, { row }) => {
            return h(
              "span",
              `${row.activate ? "激活" : "未激活"}/${
                row.active ? "活跃" : "不活跃"
              }`
            );
          }
        },
        {
          title: "私募直连",
          key: "fundLink",
          width: 80,
          render(h, { row }) {
            return h("span", row.fundLink ? "已开通" : "未开通");
          }
        },
        {
          width: 80,
          title: "管理员",
          key: "isAdmin",
          render(h, { row }) {
            if (row.isAdmin === 0) {
              return h("span", "否");
            } else if (row.isAdmin === 1) {
              return h("span", "是");
            } else {
              return h("span", "--");
            }
          }
        },
        {
          width: 80,
          title: "推荐人",
          key: "recommenderName",
          render(h, { row }) {
            return h("span", row.recommenderName || "--");
          }
        },
        {
          key: "visitingCardUrl",
          title: "名片",
          width: 80,
          render(h, { row }) {
            let url;
            if (row.visitingCardUrl) {
              let picUrl = JSON.parse(JSON.stringify(row.visitingCardUrl));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? " http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";

                let picPath = row.visitingCardUrl.replace(/Uploads\/crm/g, "/");
                picUrl = `Uploads/crm/${picPath}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        },
        {
          width: 80,
          title: "操作",
          fixed: "right",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: this.canEdit ? "deleteBtn" : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (!this.canEdit) {
                        return;
                      }
                      this.$refs.editAccountModal.show({}, row);
                    }
                  }
                },
                "编辑"
              )

              // h(
              //   "div",
              //   {
              //     attrs: {
              //       class: this.canDelete ? "deleteBtn" : "disabledBtn"
              //     },
              //     on: {
              //       click: () => {
              //         if (!this.canDelete) {
              //           return;
              //         }
              //         this.deleteAccount(row.id);
              //       }
              //     }
              //   },
              //   "删除"
              // ),
              // h(
              //   "div",
              //   {
              //     attrs: {
              //       class: this.canReset ? "deleteBtn" : "disabledBtn"
              //     },
              //     on: {
              //       click: () => {
              //         if (!this.canReset) {
              //           return;
              //         }
              //         this.resetPassword({
              //           phoneNumber: row.mobile,
              //           name: row.linkman,
              //           officialUserId: row.officialUserId,
              //           productId: 2
              //         });
              //       }
              //     }
              //   },
              //   "重置密码"
              // )
            ]);
          }
        }
      ];

      return basicColumn;
    }
  },

  data() {
    return {
      ifRefreshMainTable: false,
      modal: false,
      total: 0,
      currentPage: 1,
      pageSize: 10,
      tableData: [{ linkman: "zhngsan", status: 1, fundLink: 1 }],
      tableLoading: false,
      contactInfo: {}
    };
  },

  methods: {
    onCancel() {
      this.modal = false;
      this.total = 0;
      this.currentPage = 1;
      this.pageSize = 10;
      this.tableData = [];
      this.contactInfo = {};
      if (this.ifRefreshMainTable) {
        this.ifRefreshMainTable = false;
        this.$emit("refreshTable");
      }
    },

    refreshTable(val) {
      this.ifRefreshMainTable = val;
      this.pageSize = 10;
      this.currentPage = 1;
      this.getAccoutnList();
    },

    addAccount() {
      let info = {
        linkMan: "",
        mobile: "",
        position: "",
        visitingCardUrl: ""
      };

      info.linkMan = this.contactInfo.name;
      info.mobile = this.contactInfo.telephone;
      info.position = this.contactInfo.post;
      info.visitingCardUrl = this.contactInfo.visiting_card_url;
      info.sex = this.contactInfo.sex;
      this.$refs.addAccountModal.show({}, this.contactInfo.company_id, info);
    },

    show(contactInfo = {}) {
      this.modal = true;
      this.contactInfo = JSON.parse(JSON.stringify(contactInfo));
      this.getAccoutnList();
    },

    getAccoutnList() {
      let params = {
        pageSize: this.pageSize,
        pageNo: this.currentPage,
        user_keyword: this.contactInfo.telephone
      };
      this.tableLoading = true;
      this.$http.get(`FmAccount/account`, params).then(res => {
        this.tableLoading = false;
        if (res.code === 20000) {
          this.tableData = res.data.records;
          this.total = res.data.total;
        } else {
          this.$Message.error(`获取账号列表失败：${res.msg}`);
        }
      });
    }

    //  重置密码
    // resetPassword(accountInfo = {}) {
    //   this.$refs.resetPasswordModal.show(accountInfo);
    // },

    // deleteAccount(id) {
    //   this.$Modal.confirm({
    //     title: "删除账号",
    //     content: "确定删除这条账号吗？",
    //     onOk: () => {
    //       this.setAccountStatus(4, id);
    //     }
    //   });
    // }
  }
};
</script>

<style lang="less" scoped>
.create-account-wrap {
  color: #0c7beb;
  cursor: pointer;
  &:hover {
    text-decoration: underline;
  }
}
</style>

