<template>
   <Modal
    class="choose-mutiple-targets"
    v-model="modal"
    title="请选择其他接待人"
    :mask-closable="false"
    width='300'
   >
      <div slot="close" @click="onCancel">
         <Icon type="ios-close-empty"></Icon>
      </div>

      <div slot="footer">
        <Button @click="onCancel">取消</Button>
        <Button @click="onOk" type="primary">确定</Button>
      </div>

      <div class="search-area">

         <Input v-model="keywords" placeholder="请输入关键词" clearable>
           <Select slot="append" v-model="searchType" style="width:70px;" transfer>
             <Option :value="1">按机构</Option>
             <Option :value="2">按人名</Option>
           </Select>
         </Input>
         <span class="clear-icon" @click="clearKeyword">×</span>

         <Button type="primary" size='small' @click="getTargetList">搜索</Button>
      </div>

      <div
        v-loading='loading'
        element-loading-text="拼命加载中..." >
          <el-tree
            :data="targetList"
            show-checkbox
            node-key="id"
            ref='targetTree'
            :auto-expand-parent="true"
            :props="defaultProps"
            :default-expanded-keys="defaultCheckedIds"
            :default-checked-keys='defaultCheckedIds'
            :check-on-click-node="true"
            expand-on-click-node
            check-strictly
            @check='onChecked'
          >
          </el-tree>
      </div>

   </Modal>
</template>

<script>
import { uniqBy, dropWhile } from "lodash";
export default {
  data() {
    return {
      unCheckedNodes: [],
      keywords: "",
      searchType: 1,
      orgId: "",
      modal: false,
      targetList: [],
      loading: false,
      defaultCheckedIds: [],
      defaultProps: {
        children: "children",
        label: "title"
      },
      checkedTargets: []
    };
  },

  methods: {
    clearKeyword() {
      // if (!this.keywords) {
      //   return;
      // }
      this.keywords = "";

      // this.getTargetList();
    },

    onCancel() {
      this.modal = false;
      this.orgId = "";
      this.targetList = [];
      this.checkedTargets = [];
      this.defaultCheckedIds = [];
      this.keywords = "";
      this.searchType = 1;
      this.unCheckedNodes = [];
    },

    onOk() {
      let checkedTargets = this.getFinalCheckedTargets();
      this.$emit("getCheckedTargets", checkedTargets);
      this.onCancel();
    },

    getFinalCheckedTargets() {
      let checkedTargets = uniqBy(this.checkedTargets, "id");
      let unCheckedNodes = uniqBy(this.unCheckedNodes);
      return checkedTargets.filter(checkedItem => {
        return !unCheckedNodes.some(item => checkedItem.id == item);
      });
    },

    show(orgId, targetIds) {
      this.modal = true;
      this.orgId = orgId;
      this.getTargetList().then(() => {
        // 有选中的默认选中和打开这个节点
        new Promise(resolve => {
          this.defaultCheckedIds = targetIds.map(id => id - 0);
          this.defaultCheckedIds.push(this.targetList[0].id);
          resolve();
        }).then(() => {
          this.getDefaultCheckedTargets();
        });
      });
    },

    // 获取组织架构树
    getTargetList() {
      let params = {};
      if (this.searchType === 1) {
        params = {
          orgParent: "1",
          orgName: this.keywords
        };
      } else {
        params = {
          orgParent: "1",
          contactName: this.keywords
        };
      }
      return new Promise(resolve => {
        this.loading = true;
        this.$http
          .get(`visit/getTreeByOrgId/${this.orgId}`, params)
          .then(res => {
            resolve();
            this.loading = false;
            if (res.code === 20000) {
              this.setOrgCheckboxDisabled(res.data);
              this.targetList = res.data;
            } else {
              this.$Message.error(`获取数据失败:${res.msg}`);
            }
          })
          .catch(e => {
            console.error(e);
          });
      });
    },

    // 将机构设置为不可选取
    setOrgCheckboxDisabled(data) {
      for (let i = 0, len = data.length; i < len; i++) {
        if (data[i].type == 1) {
          data[i].disabled = true;
        }
        if (data[i].children && data[i].children.length) {
          this.setOrgCheckboxDisabled(data[i].children);
        } else {
          continue;
        }
      }
    },

    // 获取初始选中的节点
    getDefaultCheckedTargets() {
      const nodes = this.$refs.targetTree.getCheckedNodes();
      this.checkedTargets = nodes
        .filter(node => node.type === 2)
        .map(item => ({ id: item.id, name: item.title }));
    },

    //  选中
    onChecked(data, currentCheckedNodes) {
      const nodes = this.$refs.targetTree.getCheckedNodes();
      let currentCheckedTargets = nodes
        .filter(node => node.type === 2)
        .map(item => ({ id: item.id, name: item.title }));
      // 如果是更改为未选中，添加至未选中列表
      let flag = currentCheckedTargets.some(node => data.id === node.id);

      if (!flag) {
        this.unCheckedNodes.push(data.id);
      }
      this.checkedTargets = this.checkedTargets.concat(currentCheckedTargets);

      let finalCheckTargets = this.getFinalCheckedTargets();
      this.defaultCheckedIds = finalCheckTargets.map(item => item.id);
    }
  }
};
</script>

<style lang="less" scoped>
.search-area {
  position: relative;
  margin-bottom: 10px;
  display: flex;
  justify-content: flex-start;
  .ivu-input-wrapper.ivu-input-type{
    width: 210px;
  }
  button {
    margin-left: 10px;
  }
  .clear-icon {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    text-align: center;
    line-height: 16px;
    background-color: #ccc;
    display: inline-block;
    position: absolute;
    z-index: 999;
    top: 9px;
    right: 134px;
    opacity: 0;
    cursor: pointer;
    &:hover {
      opacity: 1;
    }
  }
  .ivu-input-wrapper.ivu-input-type:hover + .clear-icon {
    opacity: 1;
  }
}
</style>


