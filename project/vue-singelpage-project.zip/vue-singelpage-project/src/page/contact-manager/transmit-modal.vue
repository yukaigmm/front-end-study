<template>
   <Modal
     title="转发"
     v-model="modal"
     width="500"
     :mask-closable = "false"
     class="transmit-modal"
   >
    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button type="primary" @click="ok" :loading="buttonLoading">确定</Button>
      <Button type="ghost" @click="cancel">取消</Button>
    </div>

    <Row>
       <Col span="22" offset="1">
           <h3>请选择接收人</h3>

           <div :class="{chosen:choosePeople}">

             <div class="show_container" :class="{showMorePeople:showHeight}">
               <p class="show-content" title="单击选择接收人" @click="showPeopleModal">
                 <span v-if="selectedPeopleName.length"> {{selectedPeopleName.join(', ')}}</span>
                 <span v-else style="color:#ccc;">单击选择接收人</span>
               </p>

               <div
                  class="total"
                  @click="showPeopleModal"
                  title="选择需要转发的人"
                  v-if="this.selectedPeopleName.length">
                   共{{this.selectedPeopleId.length}}人
               </div>

               <div class="tool" @click="showMorePeople" v-if="selectedPeopleName.length">
                 <span class="text">{{!showHeight?"更多":"收起"}}</span>

                 <div class="icon-container" v-if="!showHeight">
                   <Icon :size="18" color="#666" class="icon" type="ios-arrow-down"></Icon>
                   <Icon :size="18" color="#666" class="icon second" type="ios-arrow-down"></Icon>
                   <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-down"></Icon>

                 </div>

                 <div class="icon-container" v-else>
                   <Icon :size="18" color="#666" class="icon" type="ios-arrow-up"></Icon>
                   <Icon :size="18" color="#666" class="icon second" type="ios-arrow-up"></Icon>
                   <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-up"></Icon>
                 </div>

               </div>
             </div>
           </div>

           <p style="color:red;" v-if="choosePeople">请先选择接收人！</p>

           <Input
             type="textarea"
             v-model.trim="transmitContent"
             style="margin-top:20px;"
             :autosize="{minRows: 3,maxRows: 8}"
             placeholder="请输入内容..."></Input>
      </Col>
    </Row>

    <peopleTree ref="people" @getSelectedPeople="getSelectedPeople"></peopleTree>
   </Modal>
</template>
<script>
import peopleTree from "./peopleTree.vue";
import { postFormData, getMessageCount } from "@/service/getData";
import { mapGetters } from "vuex";
export default {
  components: {
    peopleTree
  },
  data() {
    return {
      buttonLoading: false,
      recordId: "",
      modal: false,
      choosePeople: false,
      transmitContent: "",
      showHeight: false,
      selectedPeopleName: [],
      selectedPeopleId: [],
      choosePeople: false
    };
  },

  watch: {
    selectedPeopleName: function(newVal, oldVal) {
      if (newVal.length !== 0) {
        this.choosePeople = false;
      }
    }
  },

  computed: {
    ...mapGetters({
      user: "getUser"
    })
  },

  methods: {
    getSelectedPeople(selectedPerson) {
      this.selectedPeople = JSON.parse(JSON.stringify(selectedPerson));
      this.selectedPeopleName = selectedPerson.map(person => {
        return person.memberName;
      });
      this.selectedPeopleId = selectedPerson.map(person => {
        return person.id;
      });
    },

    show(recordId) {
      this.recordId = recordId;
      this.modal = true;
    },

    showPeopleModal() {
      this.$refs.people.show(this.recordId, this.selectedPeopleId, "", 5);
    },

    showMorePeople() {
      if (!this.showHeight) {
        this.showHeight = true;
      } else {
        this.showHeight = false;
      }
    },

    ok() {
      if (!this.selectedPeopleId.length) {
        this.choosePeople = true;
        this.$Message.warning("请先选择接收人");
        return;
      }
      this.buttonLoading = true;
      let content =
        this.transmitContent ||
        `${this.user.trueName}给$name转发了一条拜访记录[系统日志]`;
      let params = {
        type: 5,
        to_id: this.selectedPeopleId,
        message: content,
        visit_id: this.recordId
      };
      postFormData("msg/send", params).then(res => {
        if (res.code == 20000) {
          this.$Message.info("转发成功");
          this.buttonLoading = false;
          // 更新消息数量
          this.cancel();
          getMessageCount().then(res => {
            let count = res.data.total;
            this.$store.dispatch("setMessageCount", {
              messageCount: count
            });
          });
        } else {
          this.$Message.warning(res.msg);
          this.buttonLoading = false;
        }
      });
    },

    cancel() {
      this.selectedPeopleName = [];
      this.selectedPeopleId = [];
      this.transmitContent = "";
      this.choosePeople = false;
      this.modal = false;
    }
  }
};
</script>
<style lang="less" scoped>
</style>
