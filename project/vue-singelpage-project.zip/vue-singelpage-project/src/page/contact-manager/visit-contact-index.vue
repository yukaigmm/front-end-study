<template>
  <div v-loading="modalLoading" element-loading-text="loading...">
    <!-- <Spin v-show="loading">
      <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
      <div>Loading</div>
    </Spin>-->
    <Form ref="formData" :model="formData" :rules="ruleValidate" :label-width="80">
      <Row>
        <Col span="11" offset="1" class="visit-card">
          <FormItem
            prop="visiting_card_url"
            label="名片"
            :class="[{ 'ivu-form-item-required': isOrgNameOrVisitCardRequired }]"
          >
            <Upload
              v-loading="imgLoading"
              element-loading-text="上传中，请稍候"
              :show-upload-list="false"
              :default-file-list="defaultFileList"
              ref="upload"
              accept="image/*"
              action="api/common/uploadFile"
              :on-error="onUploadError"
              :on-success="onUploadSuccess"
              :before-upload="beforeUpload"
              style="display: inline-block;width:362px;height:214px;border:1px dotted #ccc;"
              :data="{fileType:'visitingCard'}"
            >
              <!-- <Button type="ghost" icon="ios-cloud-upload-outline">上传名片</Button> -->
              <div class="upload-list-img" v-if="imgUrl">
                <img :src="imgUrl" :alt="formData.name+'名片'" @click="onPreviewCard">
                <div class="upload-list-cover">
                  <div class="change-button" title="更换名片">
                    <Icon type="ios-cloud-upload"></Icon>
                  </div>
                  <div class="preview-button" @click="onPreviewCard" title="预览">
                    <Icon type="ios-eye-outline"></Icon>
                  </div>
                  <div class="delete-button" @click="onUploadsRemove" title="删除名片">
                    <Icon type="ios-trash-outline"></Icon>
                  </div>
                </div>
              </div>

              <div v-else class="upload-button-container" title="上传名片">
                <Icon type="camera" size="20"></Icon>
              </div>
            </Upload>
          </FormItem>
        </Col>
        <Col span="11" offset="1">
          <Form-item label="姓名" prop="name">
            <Input v-model.trim="formData.name" placeholder="请输入姓名"></Input>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="职务" prop="post">
            <Input v-model.trim="formData.post" placeholder="请输入职务"></Input>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="手机" prop="telephone">
            <Input v-model.trim="formData.telephone" :disabled="ifTelephoneDisabled" placeholder="请输入手机"></Input>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="微信" prop="weichat">
            <Input v-model.trim="formData.weichat" placeholder="请输入微信"></Input>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="用户" prop="contacts_type">
            <select-url :config="{cacheKey:'c_usertype'}" v-model="formData.contacts_type"></select-url>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="邮箱" prop="email">
            <Input v-model.trim="formData.email" placeholder="请输入邮箱"></Input>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="性别" prop="sex">
            <select-url :config="{cacheKey:'c_sex'}" v-model="formData.sex"></select-url>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="年龄" prop="age">
            <select-url :config="{cacheKey:'c_age'}" v-model="formData.age"></select-url>
          </Form-item>
        </Col>

        <Col span="23" offset="1">
          <!-- 用户标签 -->
          <Form-item label="画像" prop="portrait" class="dialog-form-item-row">
            <!-- 用户标签 -->
            <Tag
              v-if="portraitData"
              v-for="(item, index) in portraitData"
              :key="index"
              :style="getStyle(item.style)"
              :name="item.value"
              closable
              @on-close="delPort"
            >{{item.name}}</Tag>

            <!-- tag 添加按钮 -->
            <Select
              v-if="addTags"
              transfer
              v-model="modelPort"
              filterable
              remote
              style="width:100px"
              @on-change="selectPort"
              :remote-method="remoteMethodPort"
              :loading="loadingPort"
              placeholder="添加标签"
            >
              <Option v-for="(option,index) in optionsPort" :value="option.value" :key="index">
                <Tag :style="option.style">{{option.name}}</Tag>
              </Option>
            </Select>

            <div style="display:inline-block;">
              <Tag @click.native="addMore">
                <span v-if="!addTags">
                  <Icon type="plus"></Icon>
                </span>
                
                <span v-else>
                  <Icon type="minus"></Icon>
                </span>
              </Tag>
            </div>
          </Form-item>
        </Col>
      </Row>
    </Form>
    <!--  -->
  </div>
</template>
<script>
import SelectUrl from "@/components/inputs/select-url";
import SelectUrlBox from "@/components/inputs/select-url-box";
import { putFormData, fetchAllPullList, getRow } from "@/service/getData";
import { getCache } from "@/plugin/cache";
import uglifyPic from "@/mixins/condensePic";
import _ from "lodash";
export default {
  mixins: [uglifyPic],
  components: {
    SelectUrl,
    SelectUrlBox
  },
  data() {
    return {
      imgLoading: false,
      loading: false,
      personId: 0,
      formData: {},
      ruleValidate: {
        post: [
          {
            required: true,
            message: "请输入职务信息",
            trigger: "change, blur"
          }
        ],
        name: [
          {
            required: true,
            message: "请输入姓名",
            trigger: "change, blur"
          }
        ],
        telephone: [
          {
            pattern: /^1(3|4|5|6|7|8|9)\d{9}$/,
            message: "请输入正确的电话",
            trigger: "change, blur"
          }
        ],
        email: [
          {
            pattern: /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/,
            message: "请输入正确的邮箱",
            trigger: "change, blur"
          }
        ],
        sex: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        contacts_type: [
          {
            required: true,
            message: "请选择用户类型",
            trigger: "change"
          }
        ]
      },
      modalLoading: false,
      loadingPort: false,
      optionsPort: [],
      portraitData: [],
      modelPort: "",
      addTags: false,
      isOrgNameOrVisitCardRequired: false,
      defaultFileList: [],
      imgUrl: "",
      ifTelephoneDisabled:false
    };
  },
  computed: {
    cacheData() {
      let cacheDatas = getCache("c_port_all");
      return cacheDatas;
    }
  },

  mounted() {
    this.optionsPort = JSON.parse(JSON.stringify(this.cacheData));
  },

  methods: {
    getStyle(styleObj) {
      return {
        ...styleObj,
        fontSize: `${styleObj.fontSize}px`
      };
    },
    show(personId) {
      this.personId = personId;
      if (personId != -1) {
        //获取用户信息，填充到表单,其中包括标签
        this.modalLoading = true;
        getRow("index/contact", personId).then(resp => {
          this.modalLoading = false;
          // 没有时默认为0，不应该显示
          resp.data.age = resp.data.age ? resp.data.age : "";
          resp.data.sex = resp.data.sex ? resp.data.sex : "";
          resp.data.contacts_type = resp.data.contacts_type
            ? resp.data.contacts_type
            : "";
          if (resp.data.visiting_card_url) {
            this.getImgUrl(resp.data.visiting_card_url);
          }
          this.formData = JSON.parse(JSON.stringify(resp.data));
          if(!!this.formData.telephone){
            this.ifTelephoneDisabled = true;
          }else{
            this.ifTelephoneDisabled = false;
          }
          if (resp.data.portrait && resp.data.portrait.length) {
            this.portraitData = this.cacheData.filter(item => {
              return resp.data.portrait.indexOf(item.value) != -1;
            });
          } else {
            this.portraitData = [];
          }
        });
      }
    },
    addMore() {
      this.addTags = !this.addTags;
    },
    selectPort(val) {
      let port = _.filter(this.cacheData, item => {
        return item.value === val;
      })[0];
      let isRepeat = _.some(this.portraitData, item => {
        return item.value === port.value;
      });
      if (!isRepeat) {
        this.portraitData.push(port);
      }
      this.addTags = false;
      this.modelPort = "";
      this.optionsPort = JSON.parse(JSON.stringify(this.cacheData));
    },
    remoteMethodPort(query) {
      if (query !== "") {
        this.loadingPort = true;
        setTimeout(() => {
          this.loadingPort = false;

          let optionsPort = _.filter(this.cacheData, item => {
            return item.name.indexOf(query) !== -1;
          });
          if (_.isEmpty(optionsPort)) {
            optionsPort = JSON.parse(JSON.stringify(this.cacheData));
          }
          this.optionsPort = optionsPort;
        }, 100);
      } else {
        this.optionsPort = JSON.parse(JSON.stringify(this.cacheData));
      }
    },
    delPort(e, val) {
      let portData = JSON.parse(JSON.stringify(this.portraitData));
      _.remove(portData, item => {
        return item.value === val;
      });
      this.portraitData = portData;
    },
    submit() {
      return new Promise((resolved, reject) => {
        this.$refs.formData.validate(valid => {
          if (valid) {
            new Promise((resolve, inject) => {
              if (this.formData.telephone) {
                let _this = this;
                this.$http
                  .get(`contact/getUserByPhone/${this.formData.telephone}`)
                  .then(res => {
                    if (res.code === 20000) {
                      if (res.data.id && res.data.id != this.formData.id) {
                        this.$Message.info({
                          // title: "",
                          content: `手机号重复,<br>该手机号联系人为<span style="margin:0 3px;color: #2d8cf0;font-weight: bold">${
                            res.data.name
                          }</span><br>
                        所在机构为：<span style="margin:0 3px;color: #2d8cf0;font-weight: bold">${res.data.bread
                          .map(bread => bread.title)
                          .join(" - ")}</span><br>
                        
                      `,

                          duration: 3
                          // onOk: () => {
                          //   resolve();
                          // },
                          // onCancel: () => {
                          //   _this.$emit("cancelButtonLoading");
                          // }
                        });

                        resolve();
                      } else {
                        resolve();
                      }
                    } else {
                      resolve();
                    }
                  });
              } else {
                resolve();
              }
            }).then(() => {
              //获取用户信息,包括标签
              let portIds = this.portraitData.length
                ? this.portraitData.map(item => {
                    return item.value;
                  })
                : [];
              let data = {
                ...this.formData,
                portrait: portIds
              };
              let id = this.personId;
              putFormData("/index/contact", id, data).then(resp => {
                if (resp.code === 20000) {
                  this.$Message.success("修改成功");
                  resolved();
                } else {
                  reject();
                  this.$Message.error("修改失败 " + resp.msg);
                }
              });
            });
          } else {
            reject();
            this.$Message.error("请按要求填充");
          }
        });
      });
    },
    resetForm() {
      this.formData = {};
      this.imgUrl = "";
      this.ifTelephoneDisabled = false;
      this.$refs.formData.resetFields();
    },
    // 上传成功的回调
    onUploadSuccess(response, file, fileList) {
      let res = response;
      this.imgLoading = false;
      if (res.code === 20000) {
        this.$Message.success("上传成功！");
        this.formData.visiting_card_url = res.data.filePath;
        // this.$refs.editAccountForm.validateField("visiting_card_url");
        this.getImgUrl(res.data.filePath);
      } else {
        this.$Message.error(`上传失败：${res.msg}`);
      }
    },
    // 上传之前先清空,保证只能上传最后一条文件
    beforeUpload(file) {
      this.$refs.upload.clearFiles();
      this.imgLoading = true;
      this.uglifyPic(file, "formData", "formData", "visiting_card_url");
      return false;
    },
    // 上传失败的回调
    onUploadError(error, file, fileList) {
      this.imgLoading = false;
      this.$Message.error("上传失败！");
    },
    getImgUrl(path) {
      let url;
      let picUrl = path;
      if (path.includes("/Onstage/")) {
        url =
          process.env.NODE_ENV === "production" ||
          process.env.NODE_ENV === "test"
            ? "https://fof.simuwang.com/"
            : "https://master-test.simuwang.com/";
      } else {
        url =
          process.env.NODE_ENV === "production"
            ? " http://static.simuwang.com/"
            : "https://static-test-ali.simuwang.com/";
        picUrl = `Uploads/crm/${path}`;
      }
      this.imgUrl = `${url}${picUrl}`;
    },
    // 点击文件 预览
    onPreviewCard(e) {
      e.stopPropagation();
      e.preventDefault();
      window.open(`${this.imgUrl}`);
      return false;
    },
    onUploadsRemove(e) {
      e.stopPropagation();
      e.preventDefault();
      this.formData.visiting_card_url = "";
      this.$refs.upload.clearFiles();
      this.imgUrl = "";
      return false;
      // this.$refs.editAccountForm.validateField("visiting_card_url");
    }
  }
};
</script>
<style scoped lang="less">
.dialog-form-item {
  display: inline-block;
  width: 330px;
}

.dialog-form-item-row {
  display: inline-block;
  width: 660px;
}

.pull-right {
  float: right;
  margin-right: 10px;
}

.upload-list-img {
  cursor: pointer;
  vertical-align: top;
  display: inline-block;
  width: 360px;
  height: 212px;
  text-align: center;
  line-height: 212px;
  // border: 1px solid transparent;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  // box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
  margin-right: 4px;
  img {
    width: 100%;
    height: 100%;
  }
}

.upload-button-container {
  width: 360px;
  height: 212px;
  line-height: 212px;
  text-align: center;
  overflow: hidden;
}

.upload-list-cover {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  position: absolute;
  height: 60px;
  bottom: -60px;
  left: 0;
  right: 0;
  line-height: 60px;
  background: rgba(0, 0, 0, 0.6);
  transition: all 0.5s ease;
  div {
    flex: 1;
  }
}

.upload-list-img:hover .upload-list-cover {
  // display: block;
  bottom: 0;
}

.upload-list-cover i {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 5px;
}
</style>
