<template>
  <Modal title="机构拜访记录" :mask-closable="false" v-model="modal" width="700">
    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>
    <div slot="footer">
      <Button size="large" style="width:70px;" @click="cancel">关闭</Button>
    </div>
    <div class="table-container">
      <Table class="table-grid" border :columns="columns" :data="visitData" v-loading="tableLoading" element-loading-text="拼命加载中">
      </Table>
    </div>
    <div class="page-load">
      <div class="float-right">
        <Page :total="total" placement="top" :current="currentPage" :page-size="pageSize" @on-change="onPageChange" @on-page-size-change="onPageSizeChange" show-elevator show-sizer show-total />
      </div>
    </div>
  </Modal>
</template>
<script>
import {fetchGrid} from '@/service/getData'
export default {
  data() {
    return {
      modal: false,
      columns:[
         {
         	title:"日期",
         	key:"visit_time",
         },
          {
         	title:"拜访对象",
         	key:"contacts_name",
         },
          {
         	title:"拜访人",
         	key:"visit_member_name",
         },
      ],
      visitData:[],
      total:0,
      pageSize:10,
      currentPage:1,
      tableLoading:false,
      orgId:'',
    }
  },

  methods: {
    // 显示模态框
    show(orgId) {
    	this.orgId = orgId;
      this.modal = true;
      this.getTableData();
    },

    // 关闭模态框
    cancel() {
    	this.visitData = [];
      this.modal = false;
    },
    
    // 获取表格数据
    getTableData(id){
    	this.tableLoading = true;
    	let params = {
    		rows:this.pageSize,
    		page:this.currentPage,
    		org_id:this.orgId
    	};
    	fetchGrid('index/visit',params).then(res=>{
    		if(res.code === 20000){
    			this.visitData = res.data.data;
    			this.total = res.data.total;
    		}
    		this.tableLoading = false;
    	})

    },
     
    // 页码变化
    onPageChange(val){
       this.currentPage = val;
       this.getTableData();
    },
    
    // 一页展示数量发生变化
    onPageSizeChange(val){
      this.pageSize = val;
      this.getTableData();
    },

  }
}

</script>
<style lang="less" scoped>
.page-load {
  margin: 10px;
  overflow: hidden;
  .float-right {
    float: right;
  }
}

</style>
