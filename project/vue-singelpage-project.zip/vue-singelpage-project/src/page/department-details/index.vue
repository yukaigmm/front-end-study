<template>
  <div class="details-container">
    <!-- 面包屑 -->
    <div class="bread-container">
      <div class="bread-content">
        <Row>
          <i-col span="24">
            <Breadcrumb separator="<b class='demo-breadcrumb-separator'>></b>">
              <Breadcrumb-item v-for="item in breadList" :key="item.id">
                <span @click="getclicks(item)">{{ item.title }}</span>
              </Breadcrumb-item>
            </Breadcrumb>
          </i-col>
        </Row>
      </div>
    </div>
    <!-- tab区域 -->
    <div class="tabs-container">
      <Tabs class="tabs" :animated="false">
        <Tab-pane label="部门">
          <!-- 搜索区域 -->
          <Row class="search-area">
            <Form class="form" ref="form" v-model="searchData" :label-width="60">
              <i-col offset="1" span="8">
                <FormItem label="类别">
                  <Select
                    v-model="searchData.depart_id"
                    not-found-text="无匹配数据"
                    clearable
                    placeholder="请选择类别"
                    style="width:100%;"
                    @on-change="changeSearchParam"
                  >
                    <Option
                      v-for="item in departmentTypeList"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></Option>
                  </Select>
                </FormItem>
              </i-col>
              <i-col span="10" offset="1">
                <FormItem label="地域">
                  <component
                    :is="'SelectLinkage'"
                    v-model="searchData.area_ids"
                    :config="{
                  useForSearch: true,
                  cacheKey: 'c_area_all',
                  row: 'dialog-form-item-row',
                  }"
                    @on-change="changeSearchParam"
                  ></component>
                  <!-- <selectLink></selectLink> -->
                </FormItem>
              </i-col>
              <i-col span="2" offset="2" style="text-align:right">
                <Button type="primary" @click="addDepartment">添加</Button>
              </i-col>
            </Form>
          </Row>
          <div class="table-container">
            <Table
              class="table-grid"
              border
              :columns="departmentColumns"
              :data="departmentData"
              v-loading="departmentTableLoading"
              element-loading-text="拼命加载中"
            ></Table>
          </div>
          <div class="page-load">
            <div class="float-right">
              <Page
                :total="departmentTotal"
                placement="top"
                :current="departmentCurrentPage"
                :page-size="departMentpageSize"
                @on-change="onDepartmentPageChange"
                @on-page-size-change="onDepartmentPageSizeChange"
                show-elevator
                show-sizer
                show-total
              />
            </div>
          </div>
        </Tab-pane>
        <Tab-pane label="联系人">
          <div class="add-contact-btn">
            <Button type="primary" @click="addContact">添加</Button>
            <div class="tip-content">请完善客户的手机号和名片信息，无此两项则无法开通账号。</div>
          </div>
          <div class="table-container fm-table">
            <Table
              class="table-grid"
              border
              :columns="contactColumns"
              :data="contactData"
              v-loading="contactTableLoading"
              element-loading-text="拼命加载中"
            ></Table>
          </div>
          <div class="page-load">
            <div class="float-right">
              <Page
                :total="contactTotal"
                placement="top"
                :current="contactCurrentPage"
                :page-size="contactpageSize"
                @on-change="onContactPageChange"
                @on-page-size-change="onContactPageSizeChange"
                show-elevator
                show-sizer
                show-total
              />
            </div>
          </div>
        </Tab-pane>

        <Tab-pane label="附件文档">
          <attachment ref="attachTable" :orgId="pid" class="table-container"></attachment>
        </Tab-pane>
      </Tabs>
    </div>
    <editModal ref="editModal" @refreshTable="refreshTable"></editModal>
    <visitRecordDialog ref="visitRecordDialog"></visitRecordDialog>
    <contactEditModal
      ref="contactEditModal"
      :orgNameString="orgNameString"
      @refreshContactTable="refreshContactsTable"
    ></contactEditModal>
    <visitContactDialog ref="visitContactDialog"></visitContactDialog>
    <account-condition-modal ref="accountConditionModal"/>
    <!-- <addAccountModal ref="addAccountModal" @refreshTable="refreshContactsTable"></addAccountModal> -->
    <!-- <unactiveFofModal ref="unactiveFofModal" @refreshTable="refreshContactsTable"></unactiveFofModal> -->
    <!-- <unactiveFmModal ref="unactiveFmModal" @refreshTable="refreshContactsTable"></unactiveFmModal> -->
    <!-- <addFmAccountModal ref="addFmAccountModal" @refreshTable="refreshContactsTable"/> -->
  </div>
</template>
<script>
import $ from "jquery";
import { getRow, fetchGrid, delRow } from "@/service/getData";
import { mapGetters } from "vuex";
import SelectLinkage from "../../components/inputs/select-linkage.vue";
import editModal from "./edit-modal.vue";
import visitRecordDialog from "./visit-record-dialog.vue";
import contactEditModal from "@/components/common-components/customer/customer-add-edit-modal.vue";
import visitContactDialog from "../contact-manager/visit-contact-dialog.vue";
import getMinusNumber from "@/mixins/getMinusNumber.js";

// import addAccountModal from "@/page/account-justify/components/add-account-modal";

import attachment from "../../components/common-components/attachment/attachment-table";
// import unactiveFofModal from "../contact-manager/components/unactive-fof-account-modal.vue";
// import unactiveFmModal from "../contact-manager/components/unactive-fm-accounts-modal.vue";
// import addFmAccountModal from "../fm-account-manager/components/add-account";
import AccountConditionModal from "../contact/components/account/account-condition-modal.vue";
export default {
  props: ["pid"],

  mixins: [getMinusNumber],

  components: {
    SelectLinkage,
    editModal,
    visitRecordDialog,
    contactEditModal,
    visitContactDialog,
    // addAccountModal,
    attachment,
    // unactiveFofModal,
    // unactiveFmModal,
    // addFmAccountModal,
    AccountConditionModal
  },

  data() {
    return {
      addMsgLogo: require("../../assets/addMsg.png"),
      fullfillLogo: require("../../assets/addMsg.png"),
      customerType: [],
      departmentTableLoading: false,
      departmentTotal: 0,
      departmentCurrentPage: 1,
      departMentpageSize: 10,
      breadList: [],
      orgNameString: "",
      departmentTypeList: [],
      searchData: {},
      departmentData: [],
      departmentColumns: [
        {
          title: "部门",
          key: "org_name",
          render: (h, params) => {
            if (params.row.bread && params.row.bread.length) {
              return h(
                "div",
                params.row.bread
                  .map((bread, index, breads) => {
                    return h(
                      "a",
                      {
                        on: {
                          click: e => {
                            let tab = {
                              activeName: bread.title,
                              pid: bread.id,
                              name: `${bread.title}${bread.id}`,
                              component: "departmentDetails",
                              isShow: true
                            };
                            this.$store.dispatch("setTabs", tab);
                            // if (
                            //   this.tabs.some(item => {
                            //     return (
                            //       item.name === tab.name && item.pid === tab.pid
                            //     );
                            //   })
                            // ) {
                            //   let newtabs = this.tabs.map(item => {
                            //     if (item.name == tab.name) {
                            //       item.isShow = true;
                            //     }
                            //     return item;
                            //   });
                            //   this.$store.dispatch("setTabsAll", newtabs);
                            //   this.$store.dispatch("setActiveTab", {
                            //     activeTab: tab.name
                            //   });
                            // } else {
                            //   this.$store.dispatch("setTabs", tab);
                            //   this.$store.dispatch("setActiveTab", {
                            //     activeTab: tab.name
                            //   });
                            // }
                            e.stopPropagation();
                          }
                        }
                      },
                      index === breads.length - 1
                        ? `${bread.title}`
                        : `${bread.title}>`
                    );
                  })
                  .splice(1)
              );
            } else {
              return h(
                "a",
                {
                  on: {
                    click: e => {
                      let tab = {
                        activeName: params.row.org_name,
                        pid: params.row.org_id,
                        name: `${params.row.org_name}${params.row.org_id}`,
                        component: "departmentDetails",
                        isShow: true
                      };
                      this.$store.dispatch("setTabs", tab);
                      // if (
                      //   this.tabs.some(item => {
                      //     return item.name === tab.name && item.pid === tab.pid;
                      //   })
                      // ) {
                      //   let newtabs = this.tabs.map(item => {
                      //     if (item.name == tab.name) {
                      //       item.isShow = true;
                      //     }
                      //     return item;
                      //   });
                      //   this.$store.dispatch("setTabsAll", newtabs);
                      //   this.$store.dispatch("setActiveTab", {
                      //     activeTab: tab.name
                      //   });
                      // } else {
                      //   this.$store.dispatch("setTabs", tab);
                      //   this.$store.dispatch("setActiveTab", {
                      //     activeTab: tab.name
                      //   });
                      // }
                      e.stopPropagation();
                    }
                  }
                },
                params.row.org_name
              );
            }
          }
        },
        {
          title: "类别",
          key: "depart_id",
          render: (h, params) => {
            let departType = this.departmentTypeList.map(item => {
              if (params.row.depart_id == item.value) {
                return item.name;
              }
            });
            return departType.length ? departType.join("") : "未知";
          }
        },
        {
          title: "客户类型",
          key: "cust_type_ids",
          width: 110,
          render: (h, params) => {
            let cust_type_ids = params.row.cust_type_ids.length
              ? params.row.cust_type_ids
              : [];
            if (cust_type_ids && cust_type_ids.length) {
              let cusType = [];
              cust_type_ids.forEach(item => {
                this.customerType.forEach(itemCus => {
                  if (item == itemCus.value) {
                    cusType.push({
                      name: itemCus.name,
                      style: itemCus.style
                    });
                  }
                });
              });
              return h(
                "div",
                cusType.map(item => {
                  return h(
                    "Tag",
                    {
                      style: { ...item.style }
                    },
                    `${item.name}`
                  );
                })
              );
            } else {
              return "--";
            }
          }
        },
        {
          title: "更新时间",
          key: "update_time"
        },
        {
          title: "更新人",
          key: "create_member_name"
        },
        {
          title: "操作",
          width: 140,
          render: (h, params) => {
            if (
              params.row.create_member_id === this.userId ||
              this.canDeleteDepartment
            ) {
              return h("div", [
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    on: {
                      click: () => {
                        this.editDepartment(params.row);
                      }
                    }
                  },
                  "编辑"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    on: {
                      click: () => {
                        this.visitDepartment(params.row.id);
                      }
                    }
                  },
                  "拜访"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    on: {
                      click: () => {
                        this.removeDepartment(params.row.id);
                      }
                    }
                  },
                  "删除"
                )
              ]);
            } else {
              return h("div", [
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    on: {
                      click: () => {
                        this.editDepartment(params.row);
                      }
                    }
                  },
                  "编辑"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    on: {
                      click: () => {
                        this.visitDepartment(params.row.id);
                      }
                    }
                  },
                  "拜访"
                )
              ]);
            }
          }
        }
      ],
      contactpageSize: 10,
      contactTotal: 0,
      contactCurrentPage: 1,
      contactTableLoading: false,
      contactData: []
    };
  },

  mounted() {
    this.customerType = this.emnus.c_port_all_cust;
    this.departmentTypeList = this.emnus.c_depart;
    this.getBreadData();
    this.getDepartmentTableData();
    this.getContactsTableData();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".bread-container", ".search-area", ".page-load"],
      ".table-container"
    );
  },

  computed: {
    ...mapGetters({
      tabs: "getTabs",
      activeTab: "getActiveTab",
      emnus: "getEnums",
      userInfo: "getUser"
    }),
    sexOptions() {
      return this.emnus.c_sex;
    },
    ageOptions() {
      return this.emnus.c_age;
    },
    canAdd() {
      return this.userInfo.auth.functional.includes("addFmAccount");
    },

    userId() {
      return this.userInfo.id;
    },

    canDeleteDepartment() {
      return this.userInfo.auth.functional.includes("deleteOrg");
    },

    canDeleteContact() {
      return this.userInfo.auth.functional.includes("deleteContact");
    },

    portraitList() {
      return this.emnus.c_port_all;
    },

    contactColumns() {
      let commonCellStyle = {
        "text-overflow": "ellipsis",
        overflow: "hidden",
        "white-space": "nowrap",
        cursor: "pointer"
      };

      return [
        {
          title: "姓名",
          key: "name",
          width: 100,
          fixed: "left",
          render: (h, { row }) => {
            let ifMissInfo =
              !row.telephone || !row.visiting_card_url || !row.email;

            if (ifMissInfo) {
              return h(
                "div",
                {
                  style: {
                    display: "flex",
                    "justify-content": "flex-satrt",
                    "align-items": "center"
                  }
                },
                [
                  h("div", {
                    attrs: {
                      title: "请补充联系人信息"
                    },
                    style: {
                      cursor: "pointer",
                      "background-image": `url(${this.fullfillLogo})`,
                      "background-size": "100%",
                      "background-repeat": "no-repeat",
                      width: "20px",
                      height: "20px",
                      "margin-right": "10px"
                    }
                  }),
                  h(
                    "div",
                    {
                      style: {
                        flex: 1
                      }
                    },
                    row.name || "--"
                  )
                ]
              );
            } else {
              return h("span", row.name || "--");
            }
          }
        },
        {
          title: "手机",
          key: "telephone",
          width: 100,
          fixed: "left",
          render: (h, { row }) => {
            return h("span", row.telephone || "--");
          }
        },
        {
          title: "公司",
          key: "org_name",
          width: 300,
          render: (h, { row }) => {
            if (row.bread && row.bread.length) {
              let companyInfo = row.bread[1] || {};

              if (!companyInfo.id) {
                return h("span", "--");
              }

              let tab = {
                activeName: companyInfo.title,
                pid: companyInfo.id,
                name: `${companyInfo.title}${companyInfo.id}`,
                component: "departmentDetails",
                isShow: true
              };
              return h(
                "a",
                {
                  attrs: {
                    title: "点击查看详情"
                  },
                  on: {
                    click: e => {
                      this.$store.dispatch("setTabs", tab);
                      e.stopPropagation();
                    }
                  }
                },
                companyInfo.title || "--"
              );
            } else {
              let tab = {
                activeName: row.org_name,
                pid: row.org_id,
                name: `${row.org_name}${row.org_id}`,
                component: "departmentDetails",
                isShow: true
              };
              return h(
                "a",
                {
                  attrs: {
                    title: "点击查看详情"
                  },
                  on: {
                    click: e => {
                      this.$store.dispatch("setTabs", tab);
                      e.stopPropagation();
                    }
                  }
                },
                row.org_name || "--"
              );
            }
          }
        },
        {
          title: "部门",
          key: "departmentName",
          width: 200,
          render: (h, { row }) => {
            if (row.bread && row.bread.length) {
              return h(
                "div",
                row.bread
                  .map((bread, index, breads) => {
                    return h(
                      "a",
                      {
                        attrs: {
                          title: "点击查看详情"
                        },
                        on: {
                          click: e => {
                            let tab = {
                              activeName: bread.title,
                              pid: bread.id,
                              name: `${bread.title}${bread.id}`,
                              component: "departmentDetails",
                              isShow: true
                            };

                            this.$store.dispatch("setTabs", tab);
                            e.stopPropagation();
                          }
                        }
                      },
                      index === breads.length - 1
                        ? `${bread.title}`
                        : `${bread.title}>`
                    );
                  })
                  .splice(2)
              );
            } else {
              return h("span", "总部");
            }
          }
        },
        {
          title: "职务",
          key: "post",
          width: 100,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "90px"
                },
                attrs: {
                  title: row.post
                }
              },
              row.post || "--"
            );
          }
        },
        {
          title: "名片",
          key: "visiting_card_url",
          width: 80,
          render(h, { row }) {
            let url;
            if (row.visiting_card_url) {
              let picUrl = JSON.parse(JSON.stringify(row.visiting_card_url));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? "http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";
                picUrl = `Uploads/crm/${row.visiting_card_url}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        },
        {
          title: "画像",
          key: "portrait",
          width: 100,
          render: (h, { row }) => {
            let portrait = [];
            if (row.portrait) {
              portrait = JSON.parse(row.portrait);
            }

            if (portrait.length) {
              return h(
                "div",
                portrait.map(item => {
                  let text = "";
                  let style = null;
                  let matchOne = this.portraitList.filter(
                    c => c.value == item
                  )[0];
                  text = matchOne.name;
                  style = matchOne.style;
                  return h(
                    "span",
                    {
                      style: {
                        "border-radius": "10%",
                        "max-width": "80px",
                        "min-width": "40px",
                        display: "inline-block",
                        "text-align": "center",
                        padding: "3px 5px",
                        cursor: "pointer",
                        ...style
                      }
                    },
                    text
                  );
                })
              );
            } else {
              return h("span", "--");
            }
          }
        },
        {
          title: "邮箱",
          key: "email",
          width: 120,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "100px"
                },
                attrs: {
                  title: row.email
                }
              },
              row.email || "--"
            );
          }
        },
        {
          title: "性别",
          key: "sex",
          width: 80,
          render: (h, { row }) => {
            let matchItem = this.sexOptions.filter(
              item => item.value == row.sex
            )[0];
            let text = matchItem ? matchItem.name : "--";
            return h("span", text);
          }
        },
        {
          title: "年龄",
          key: "age",
          width: 80,
          render: (h, { row }) => {
            let matchItem = this.ageOptions.filter(
              item => item.value == row.age
            )[0];
            let text = matchItem ? matchItem.name : "--";
            return h("span", text);
          }
        },
        {
          title: "微信",
          key: "wechat",
          width: 120,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "110px"
                },
                attrs: {
                  title: row.wechat
                }
              },
              row.wechat || "--"
            );
          }
        },
        {
          title: "更新时间",
          key: "update_time",
          width: 100,
          render: (h, { row }) => {
            return h(
              "p",
              {
                attrs: {
                  title: `${row.update_time}`
                }
              },
              `${row.update_time.substring(0, 10)}`
            );
          }
        },
        {
          title: "更新人",
          key: "update_member_id",
          width: 90,
          render: (h, { row }) => {
            return h("p", row.update_member_name || "--");
          }
        },
        {
          title: "操作",
          width: 200,
          fixed: "right",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.editContact(row);
                    }
                  }
                },
                "编辑"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.visitContact(row);
                    }
                  }
                },
                "拜访"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.$refs.accountConditionModal.show(row);
                    }
                  }
                },
                "开通账号"
              ),
              h(
                "div",
                {
                  attrs: {
                    class:
                      row.create_member_id === this.userId ||
                      this.canDeleteContact
                        ? "deleteBtn"
                        : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (
                        row.create_member_id !== this.userId &&
                        !this.canDeleteContact
                      ) {
                        return;
                      }
                      this.removeContact(row.id);
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ];
    }
  },

  watch: {
    pid(val) {
      // pid发生变化重新获取数据

      this.getDepartmentTableData();
      this.getBreadData();
    }
  },

  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 250;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    // 刷新表格数据
    refreshTable() {
      this.getDepartmentTableData();
    },

    // 获取面包屑数据
    getBreadData() {
      getRow("/index/organization", this.pid).then(resp => {
        this.breadList = resp.data.breadcrumb;

        let arr = [];
        this.breadList.forEach((item, index) => {
          if (index > 0) {
            arr.push(item.title);
          }
        });
        this.orgNameString = arr.join(">");
      });
    },

    // 点击面包屑发生跳转
    getclicks(item) {
      let tab = {
        activeName: item.title,
        pid: item.id,
        name: `${item.title}${item.id}`,
        component: "departmentDetails",
        isShow: true
      };
      // 点击首页时跳转到机构页面
      if (item.id === 0) {
        tab = {
          activeName: "机构",
          name: "机构0",
          component: "organizationManager",
          isShow: true
        };
      }

      this.$store.dispatch("setTabs", tab);
      // // 如果有跳到该tab，并激活
      // if (
      //   _.findIndex(this.tabs, tabItem => {
      //     return tabItem.name == tab.name;
      //   }) != -1 &&
      //   _.findIndex(this.tabs, tabItem => {
      //     return tabItem.pid == tab.pid;
      //   }) != -1
      // ) {
      //   let newtabs = this.tabs.map(item => {
      //     if (item.name == tab.name) {
      //       item.isShow = true;
      //     }
      //     return item;
      //   });
      //   this.$store.dispatch("setTabsAll", newtabs);
      //   this.$store.dispatch("setActiveTab", {
      //     activeTab: tab.name
      //   });
      // } else {
      //   // 如果没有新建并激活
      //   this.$store.dispatch("setTabs", tab);
      //   this.$store.dispatch("setActiveTab", {
      //     activeTab: tab.name
      //   });
      // }
    },

    // 获取部门表格数据
    getDepartmentTableData() {
      this.departmentTableLoading = true;
      let params = {
        rows: this.departMentpageSize,
        page: this.departmentCurrentPage,
        pid: this.pid,
        ...this.searchData
      };
      fetchGrid("/index/organization", params).then(res => {
        if (res.code === 20000) {
          this.departmentData = res.data.data;
          this.departmentTotal = res.data.total;
        }
        this.departmentTableLoading = false;
      });
    },

    // 添加部门
    addDepartment() {
      this.$refs.editModal.show("add", this.pid);
    },

    // 搜索条件发生变化时的事件
    changeSearchParam(val) {
      this.getDepartmentTableData();
    },

    // 拜访部门
    visitDepartment(id) {
      this.$refs.visitRecordDialog.show(id);
    },

    // 编辑部门
    editDepartment(rowData) {
      this.$refs.editModal.show("edit", this.pid, rowData);
    },

    // 删除部门
    removeDepartment(id) {
      this.$Modal.confirm({
        title: "删除",
        content: "确定删除？",
        width: 300,
        loading: true,
        onOk: () => {
          delRow("/index/organization", id).then(res => {
            if (res.code === 20000) {
              this.$Message.info("删除成功");
              // 如果删除的部门，已经在tab中重新更新tab去掉删除的tab
              let tabsArr = this.tabs.filter(item => {
                return item.pid != id;
              });
              this.$store.dispatch("setTabsAll", tabsArr);
              this.refreshTable();
            } else {
              this.$Message.warning(res.msg);
            }
            this.$Modal.remove();
          });
        }
      });
    },

    // 部门分页器页码发生变化
    onDepartmentPageChange(val) {
      this.departmentCurrentPage = val;
      this.getDepartmentTableData();
    },

    // 部门分页器一页显示数据发生变化
    onDepartmentPageSizeChange(val) {
      this.departMentpageSize = val;
      this.getDepartmentTableData();
    },

    // 获取联系人列表
    getContactsTableData() {
      this.contactTableLoading = true;
      let params = {
        rows: this.contactpageSize,
        page: this.contactCurrentPage,
        pid: this.pid
      };
      fetchGrid("/index/contact", params).then(res => {
        this.contactTableLoading = false;
        if (res.code === 20000) {
          this.contactData = res.data.data;
          this.contactTotal = res.data.total;
        }
      });
    },
    // 刷新联系人列表
    refreshContactsTable() {
      this.getContactsTableData();
    },

    // 添加当前部门下的联系人
    addContact() {
      this.$refs.contactEditModal.show("add", this.pid);
    },

    //联系人页码发生变化
    onContactPageChange(val) {
      this.contactCurrentPage = val;
      this.getContactsTableData();
    },

    // 联系人一页展示数量发生变化
    onContactPageSizeChange(val) {
      this.contactpageSize = val;
      this.getContactsTableData();
    },

    // 拜访联系人
    visitContact(row) {
      let params = {
        tabShow: "visit",
        personId: row.id,
        personName: row.name,
        orgId: row.org_id
      }
      this.$refs.visitContactDialog.show(params);
    },

    //  编辑联系人
    editContact(row) {
      let personId = row.id;
      let psersonName = row.name;
      let orgId = row.org_id;
      this.$refs.contactEditModal.show("edit", orgId, personId);
    },

    // 删除联系人
    removeContact(id) {
      this.$Modal.confirm({
        title: "删除",
        content: "确认删除此联系人？",
        loading: true,
        width: 300,
        onOk: () => {
          delRow("index/contact/", id).then(res => {
            if (res.code === 20000) {
              this.$Message.info("删除成功");
              this.refreshContactsTable();
            } else {
              this.$Message.warning(res.msg);
            }
            this.$Modal.remove();
          });
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.demo-breadcrumb-separator {
  color: #ff5500;
  padding: 0 5px;
}

.bread-container {
  z-index: 10;
  .bread-content {
    line-height: 50px;
    padding: 0 5px 0 5px;
  }
}

.page-load {
  margin: 10px;
  overflow: hidden;
  .float-right {
    float: right;
  }
}

.add-contact-btn {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  // text-align: right;
  margin: 8px 0;
}
.tip-content {
  color: #2d8cf0;
}
</style>
