<template>
  <Modal width="1000" v-model="modal" :title="title" :loading="loading" :mask-closable="false">
    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button size="large" style="width:70px;" @click="cancel">取消</Button>
      <Button
        type="primary"
        size="large"
        style="width:70px;"
        :loading="buttonLoading"
        @click="ok"
      >提交</Button>
    </div>

    <Form ref="form" :model="contactsData" :label-width="90" :rules="ruleValidate">
      <Row>
        <Col span="11" class="visit-card">
          <FormItem
            prop="visiting_card_url"
            label="名片"
            :class="[{ 'ivu-form-item-required': isOrgNameOrVisitCardRequired }]"
          >
            <Upload
              v-loading="imgLoading"
              element-loading-text="上传中，请稍候"
              :show-upload-list="false"
              accept="image/*"
              :default-file-list="defaultFileList"
              ref="upload"
              action="api/common/uploadFile"
              :on-error="onUploadError"
              :on-success="onUploadSuccess"
              :before-upload="beforeUpload"
              style="display: inline-block;width:362px;height:214px;border:1px dotted #ccc;"
              :data="{fileType:'visitingCard'}"
            >
              <!-- <Button type="ghost" icon="ios-cloud-upload-outline">上传名片</Button> -->
              <div class="upload-list-img" v-if="imgUrl">
                <img :src="imgUrl" :alt="contactsData.name+'名片'" @click="onPreviewCard" width="200" height="120">
                <div class="upload-list-cover">
                  <div class="change-button" title="更换名片">
                    <Icon type="ios-cloud-upload"></Icon>
                  </div>
                  <div class="preview-button" @click="onPreviewCard" title="预览">
                    <Icon type="ios-eye-outline"></Icon>
                  </div>
                  <div class="delete-button" @click="onUploadsRemove" title="删除名片">
                    <Icon type="ios-trash-outline"></Icon>
                  </div>
                </div>
              </div>

              <div v-else class="upload-button-container" title="上传名片">
                <Icon type="camera" size="20"></Icon>
              </div>
            </Upload>
          </FormItem>
        </Col>
        <Col span="11">
          <FormItem label="姓名" prop="name">
            <Input v-model.trim="contactsData.name" placeholder="请输入姓名"></Input>
          </FormItem>
        </Col>

        <Col span="11">
          <FormItem label="职务" prop="post">
            <Input v-model.trim="contactsData.post" placeholder="请输入职务"></Input>
          </FormItem>
        </Col>

        <Col span="11">
          <FormItem label="电话" prop="telephone">
            <Input v-model.trim="contactsData.telephone" placeholder="请输入电话"></Input>
          </FormItem>
        </Col>

        <Col span="11">
          <FormItem label="微信" prop="weichat">
            <Input v-model.trim="contactsData.weichat" placeholder="请输入微信"></Input>
          </FormItem>
        </Col>

        <Col span="11">
          <FormItem label="邮箱" prop="email">
            <Input v-model.trim="contactsData.email" placeholder="请输入邮箱"></Input>
          </FormItem>
        </Col>

        <Col span="11">
          <FormItem label="年龄" prop="age">
            <Select v-model="contactsData.age" clearable placeholder="请选择年龄" style="width:100%;">
              <Option
                v-for="(item,index) in ageList"
                :key="index"
                :value="item.value"
                :label="item.name"
              ></Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="11">
          <FormItem label="性别" prop="sex">
            <Select v-model="contactsData.sex" clearable placeholder="请选择性别" style="width:100%;">
              <Option
                v-for="(item,index) in genderList"
                :key="index"
                :value="item.value"
                :label="item.name"
              ></Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="11">
          <FormItem label="用户类型" prop="contacts_type">
            <Select
              v-model="contactsData.contacts_type"
              clearable
              placeholder="请选择用户类型"
              style="width:100%;"
            >
              <Option
                v-for="(item,index) in contactsTypeList"
                :key="index"
                :value="item.value"
                :label="item.name"
              ></Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="24">
          <FormItem label="画像" prop="portrait">
            <Tag
              v-if="portraitData.length"
              v-for="(item, index) in portraitData"
              :key="index"
              :style="getStyle(item.style)"
              :name="item.value"
              closable
              @on-close="delPort"
            >{{item.name}}</Tag>

            <Select
              v-if="addTags"
              transfer
              v-model="modelPort"
              filterable
              remote
              style="width:100px"
              @on-change="selectPort"
              :remote-method="remoteMethodPort"
              placeholder="添加标签"
            >
              <Option v-for="(option,index) in optionsPort" :value="option.value" :key="index">
                <Tag :style="option.style">{{option.name}}</Tag>
              </Option>
            </Select>

            <div style="display:inline-block;">
              <Tag @click.native="addMore">
                <span v-if="!addTags">
                  <Icon type="plus"></Icon>
                </span>
                
                <span v-else>
                  <Icon type="minus"></Icon>
                </span>
              </Tag>
            </div>
          </FormItem>
        </Col>
      </Row>
    </Form>
  </Modal>
</template>
<script>
import { postFormData, putFormData } from "@/service/getData";
import uglifyPic from "@/mixins/condensePic";

import { mapGetters } from "vuex";
export default {
  mixins: [uglifyPic],

  data() {
    return {
      tagList: [],
      optionsPort: [],
      modelPort: "",
      addTags: false,
      portraitData: [],
      imgLoading: false,
      orgId: "",
      modal: false,
      title: "",
      loading: false,
      buttonLoading: false,
      contactsData: {},
      ageList: [],
      genderList: [],
      contactsTypeList: [],
      showType: "",
      ruleValidate: {
        post: [
          {
            required: true,
            message: "请输入职务信息",
            trigger: "change, blur"
          }
        ],
        name: [
          {
            required: true,
            message: "请输入姓名",
            trigger: "change, blur"
          }
        ],
        telephone: [
          {
            pattern: /^1(3|4|5|6|7|8|9)\d{9}$/,
            message: "请输入正确的手机号码",
            trigger: "change, blur"
          }
        ],
        email: [
          {
            pattern: /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/,
            message: "请输入正确的邮箱",
            trigger: "change, blur"
          }
        ],
        sex: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        contacts_type: [
          {
            required: true,
            message: "请选择用户类型",
            trigger: "change"
          }
        ]
      },
      isOrgNameOrVisitCardRequired: false,
      defaultFileList: [],
      imgUrl: ""
    };
  },

  computed: {
    ...mapGetters({
      emnus: "getEnums"
    })
  },

  mounted() {
    this.ageList = this.emnus.c_age;
    this.contactsTypeList = this.emnus.c_usertype;
    this.genderList = this.emnus.c_sex;
    this.tagList = this.emnus.c_port_all;
    this.optionsPort = this.emnus.c_port_all;
  },

  methods: {
    remoteMethodPort(query) {
      if (query) {
        this.optionsPort = this.tagList.filter(
          item => item.name.indexOf(query) !== -1
        );
      } else {
        this.optionsPort = JSON.parse(JSON.stringify(this.tagList));
      }
    },
    addMore() {
      this.addTags = !this.addTags;
    },
    selectPort(val) {
      let port = this.tagList.filter(item => item.value === val)[0];

      let isRepeat = this.portraitData.some(item => item.value == port.value);
      if (!isRepeat) {
        this.portraitData.push(port);
      }
      this.addTags = false;
      this.modelPort = "";
      this.optionsPort = JSON.parse(JSON.stringify(this.tagList));
    },
    delPort(e, val) {
      let portData = JSON.parse(JSON.stringify(this.portraitData));
      let index = portData.findIndex(item => item.value == val);
      this.portraitData.splice(index, 1);
    },
    getStyle(styleObj) {
      return {
        ...styleObj,
        fontSize: `${styleObj.fontSize}px`
      };
    },
    // 提交
    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          new Promise((resolve, reject) => {
            this.buttonLoading = true;

            if (this.contactsData.telephone) {
              this.$http
                .get(`contact/getUserByPhone/${this.contactsData.telephone}`)
                .then(res => {
                  if (res.code === 20000) {
                    if (res.data.id && res.data.id != this.contactsData.id) {
                      this.$Modal.confirm({
                        title: "手机号重复",
                        content: `该手机号联系人为<span style="margin:0 3px;color: #2d8cf0;font-weight: bold">${
                          res.data.name
                        }</span><br>
                      所在机构为：<span style="margin:0 3px;color: #2d8cf0;font-weight: bold">${res.data.bread
                        .map(bread => bread.title)
                        .join(" - ")}</span><br>
                     
                    `,
                        // onOk: () => {
                        //   resolve();
                        // },
                        // onCancel: () => {
                        //   this.buttonLoading = false;
                        // }
                      });
                    } else {
                      resolve();
                    }
                  }else{
                    resolve();
                  }
                });
            } else {
              resolve();
            }
          }).then(() => {
            let portrait = JSON.parse(JSON.stringify(this.portraitData)).map(
              item => item.value + ""
            );
            if (this.showType === "add") {
              let params = {
                pid: this.orgId,
                isvalid: 1,
                portrait,
                ...this.contactsData
              };
              postFormData("index/contact", params).then(res => {
                this.buttonLoading = false;
                if (res.code === 20000) {
                  this.$Message.info("添加成功");
                  this.$emit("refreshContactTable");
                  this.cancel();
                } else {
                  this.$Message.warning(res.msg);
                }
              });
            } else {
              let params = {
                pid: this.orgId,
                age: this.contactsData.age,
                contacts_type: this.contactsData.contacts_type,
                email: this.contactsData.email,
                id: this.contactsData.id,
                name: this.contactsData.name,
                post: this.contactsData.post,
                sex: this.contactsData.sex,
                telephone: this.contactsData.telephone,
                weichat: this.contactsData.weichat,
                visiting_card_url: this.contactsData.visiting_card_url,
                portrait
              };
              putFormData("index/contact", this.contactsData.id, params).then(
                res => {
                  this.buttonLoading = false;
                  if (res.code === 20000) {
                    this.$Message.info("编辑成功");
                    this.$emit("refreshContactTable");
                    this.cancel();
                  } else {
                    this.$Message.warning(res.msg);
                  }
                }
              );
            }
          });
        }
      });
    },

    // 取消
    cancel() {
      this.modal = false;
      this.contactsData = {};
      this.imgUrl = "";
      this.portraitData = [];
      this.$refs.form.resetFields();
    },

    // 显示
    /*
     * @param type {string} 显示类型
     * @param orgId {int} 机构id
     * @param rowData {object} 某条具体的联系人信息
     */
    show(type, orgId, rowData) {
      this.showType = type;
      if (rowData) {
        let singleContactData = JSON.parse(JSON.stringify(rowData));
        singleContactData.age = singleContactData.age
          ? singleContactData.age + ""
          : "";
        singleContactData.sex = singleContactData.sex
          ? singleContactData.sex + ""
          : "";
        singleContactData.contacts_type = singleContactData.contacts_type
          ? singleContactData.contacts_type + ""
          : "";
        if (singleContactData.visiting_card_url) {
          this.getImgUrl(singleContactData.visiting_card_url);
        }
        if (singleContactData.portrait && singleContactData.portrait.length) {
          this.tagList.forEach(item => {
            if (singleContactData.portrait.includes(item.value)) {
              this.portraitData.push(item);
            }
          });
        }

        this.$nextTick(() => {
          this.contactsData = singleContactData;
        });
      }
      this.orgId = orgId;
      if (type === "add") {
        this.title = "新增联系人";
        // 缺省为非用户
        this.$set(this.contactsData, "contacts_type", "99");
      } else {
        this.title = "编辑联系人";
      }
      this.modal = true;
    },

    // 上传成功的回调
    onUploadSuccess(response, file, fileList) {
      let res = response;
      this.imgLoading = false;
      if (res.code === 20000) {
        this.$Message.success("上传成功！");
        this.contactsData.visiting_card_url = res.data.filePath;
        // this.$refs.editAccountForm.validateField("visiting_card_url");
        this.getImgUrl(res.data.filePath);
      } else {
        this.$Message.error(`上传失败：${res.msg}`);
      }
    },
    // 上传之前先清空,保证只能上传最后一条文件
    beforeUpload(file) {
      this.$refs.upload.clearFiles();
      this.imgLoading = true;
      this.uglifyPic(file, "form", "contactsData", "visiting_card_url");
      return false;
    },
    // 上传失败的回调
    onUploadError(error, file, fileList) {
      this.$Message.error("上传失败！");
      this.imgLoading = false;
    },
    getImgUrl(path) {
      let url;
      let picUrl = path;
      if (path.includes("/Onstage/")) {
        url =
          process.env.NODE_ENV === "production" ||
          process.env.NODE_ENV === "test"
            ? "https://fof.simuwang.com/"
            : "https://master-test.simuwang.com/";
      } else {
        url =
          process.env.NODE_ENV === "production"
            ? " http://static.simuwang.com/"
            : "https://static-test-ali.simuwang.com/";
        picUrl = `Uploads/crm/${path}`;
      }
      this.imgUrl = `${url}${picUrl}`;
    },
    // 点击文件 预览
    onPreviewCard(e) {
      e.stopPropagation();
      e.preventDefault();
      window.open(`${this.imgUrl}`);
      return false;
    },
    onUploadsRemove(e) {
      e.stopPropagation();
      e.preventDefault();
      this.contactsData.visiting_card_url = "";
      this.$refs.upload.clearFiles();
      this.imgUrl = "";
      return false;
      // this.$refs.editAccountForm.validateField("visiting_card_url");
    }
  }
};
</script>
<style lang="less" scoped>
.upload-list-img {
  cursor: pointer;
  vertical-align: top;
  display: inline-block;
  width: 360px;
  height: 212px;
  text-align: center;
  line-height: 212px;
  // border: 1px solid transparent;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  // box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
  margin-right: 4px;
  img {
    width: 100%;
    height: 100%;
  }
}

.upload-button-container {
  width: 360px;
  height: 212px;
  line-height: 212px;
  text-align: center;
  overflow: hidden;
}

.upload-list-cover {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  position: absolute;
  height: 60px;
  bottom: -60px;
  left: 0;
  right: 0;
  line-height: 60px;
  background: rgba(0, 0, 0, 0.6);
  transition: all 0.5s ease;
  div {
    flex: 1;
  }
}

.upload-list-img:hover .upload-list-cover {
  // display: block;
  bottom: 0;
}

.upload-list-cover i {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 5px;
}

// .visit-card {
//   height: 220px !important;
//   width: 464px !important;
// }
</style>
