<template>
  <Modal
    width="700"
    v-model="modal"
    :title="title"
    :loading="loading"
    :mask-closable="false"
    class="edit-modal"
  >
    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>
    <div slot="footer">
      <Button size="large" style="width:70px;" @click="cancel">取消</Button>
      <Button
        type="primary"
        size="large"
        style="width:70px;"
        :loading="buttonLoading"
        @click="ok"
      >提交</Button>
    </div>
    <Form ref="form" :model="departmentData" :label-width="100" :rules="ruleValidate">
      <Row>
        <Col span="11">
          <FormItem label="部门" prop="org_name">
            <Input v-model.trim="departmentData.org_name" placeholder="请输入部门名称"></Input>
          </FormItem>
        </Col>
        <Col span="11">
          <FormItem label="类别" prop="depart_id">
            <template v-if="showType==='add'">
              <Select
                v-model="departmentData.depart_id"
                not-found-text="无匹配数据"
                clearable
                placeholder="请选择类别"
                style="width:100%;"
              >
                <Option
                  v-for="item in departmentTypeList"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></Option>
              </Select>
            </template>
            <template v-else>
              <Row>
                <Col span="11">
                  <Select v-model="departmentData.oc_id" clearable placeholder="请选择">
                    <Option
                      v-for="item in companyTypeList"
                      :value="item.value"
                      :key="item.value"
                    >{{item.name}}</Option>
                  </Select>
                </Col>
                <Col span="12" offset="1">
                  <Select
                    v-model="departmentData.depart_id"
                    not-found-text="无匹配数据"
                    clearable
                    placeholder="请选择类别"
                    style="width:100%;"
                  >
                    <Option
                      v-for="item in departmentTypeList"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></Option>
                  </Select>
                </Col>
              </Row>
            </template>
          </FormItem>
        </Col>
      </Row>
      <Row>
        <Col span="11">
          <FormItem label="电话" prop="phone_num">
            <Input placeholder="请输入电话" v-model.trim="departmentData.phone_num" style="width:100%;"></Input>
          </FormItem>
        </Col>
        <Col span="11">
          <FormItem label="机构网址" prop="website">
            <Input placeholder="请输入机构网址" v-model.trim="departmentData.website" style="width:100%;"></Input>
          </FormItem>
        </Col>
      </Row>
      <Row>
        <Col span="22">
          <FormItem label="画像" style="width:100%;" prop="portrait">
            <Select v-model="departmentData.portrait" multiple placeholder="请选择">
              <Option v-for="item in portraitList" :value="item.value" :key="item.value">
                <Tag :style="item.style">{{item.name}}</Tag>
              </Option>
            </Select>
          </FormItem>
        </Col>
      </Row>
      <Row>
        <Col span="22">
          <FormItem label="客户类型" prop="cust_type_ids" style="padding-right:8px;">
            <Select v-model="departmentData.cust_type_ids" multiple placeholder="请选择">
              <Option v-for="item in customerType" :value="item.value" :key="item.value">
                <Tag :style="item.style">{{item.name}}</Tag>
              </Option>
            </Select>
          </FormItem>
        </Col>
      </Row>
      <Row>
        <Col span="22">
          <FormItem label="地域" prop="area_ids">
            <component
              :is="'SelectLinkage'"
              v-model="departmentData.area_ids"
              :config="{
          useForSearch: true,
          cacheKey: 'c_area_all',
          row: 'dialog-form-item-row',}"
              style="width:100%;"
            ></component>
          </FormItem>
        </Col>
      </Row>
      <Row>
        <Col span="22">
          <FormItem label="详细街道" prop="area_info">
            <Input
              placeholder="请输入详细街道"
              v-model.trim="departmentData.area_info"
              style="width:100%;"
            ></Input>
          </FormItem>
        </Col>
      </Row>
      <Row>
        <Col span="22">
          <FormItem label="备案编码" prop="register_num" style="padding-right:8px;">
            <Input v-model.trim="departmentData.register_num" placeholder="请输入"></Input>
          </FormItem>
        </Col>
      </Row>
    </Form>
  </Modal>
</template>
<script>
import { postFormData, putFormData } from "@/service/getData";
import { mapGetters } from "vuex";
import SelectLinkage from "../../components/inputs/select-linkage.vue";
import $ from "jquery";
export default {
  data() {
    return {
      companyTypeList: [],
      pid: "",
      showType: "",
      portraitList: [],
      customerType: "",
      departmentData: {
        org_name: "",
        depart_id: "",
        portrait: [],
        cust_type_ids: [],
        phone_num: "",
        website: "",
        area_ids: "",
        area_info: ""
      },
      departmentTypeList: [],
      modal: false,
      title: "添加",
      loading: false,
      buttonLoading: false,
      ruleValidate: {
        org_name: [
          {
            required: true,
            message: "请输入部门名称",
            trigger: "change, blur"
          }
        ],
        depart_id: [
          {
            required: true,
            message: "请选择机构类型",
            trigger: "change"
          }
        ],
        phone_num: [
          {
            pattern: /(^1(3|4|5|6|7|8|9)\d{9}$)|(^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$)/,
            message: "请输入正确电话 如:400-6802928",
            trigger: "change, blur"
          }
        ],
        website: [
          {
            pattern: /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/,
            message: "参照 http://www.smppw.com",
            trigger: "change, blur"
          }
        ]
      }
    };
  },

  components: {
    SelectLinkage
  },
  watch: {
    "departmentData.portrait": {
      handler(val) {
        setTimeout(() => {
          let el = $(".edit-modal");
          let selectTags = $(el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(el).find(".ivu-select-selection .ivu-tag span");
          let tag = $(el).find(
            ".ivu-select-dropdown-list .ivu-select-item .ivu-tag span"
          );
          let tagContianer = $(el).find(
            ".ivu-select-dropdown-list .ivu-select-item .ivu-tag"
          );
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    },
    "departmentData.cust_type_ids": {
      handler(val) {
        setTimeout(() => {
          let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(this.$el).find(
            ".ivu-select-selection .ivu-tag span"
          );
          let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
          let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    }
  },

  mounted() {
    this.companyTypeList = this.emnus.c_org;
    this.portraitList = this.emnus.c_port_all_org;
    this.departmentTypeList = this.emnus.c_depart;
    this.customerType = this.emnus.c_port_all_cust;
  },

  computed: {
    ...mapGetters({
      emnus: "getEnums"
    })
  },

  methods: {
    // 点击确定
    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.buttonLoading = true;
          // 新增
          if (this.showType === "add") {
            let params = {
              pid: this.pid,
              ...this.departmentData
            };
            postFormData("/index/organization", params).then(res => {
              this.buttonLoading = false;
              if (res.code === 20000) {
                this.$Message.info("添加成功");
                this.cancel();
                this.$emit("refreshTable");
              } else {
                this.$Message.warning(res.msg);
              }
            });
          } else {
            // 编辑
            let params = {
              ...this.departmentData
            };
            putFormData(
              "/index/organization",
              this.departmentData.id,
              params
            ).then(res => {
              this.buttonLoading = false;
              if (res.code === 20000) {
                this.$Message.info("编辑成功");
                this.cancel();
                this.$emit("refreshTable");
              } else {
                this.$Message.warning(res.msg);
              }
            });
          }
        }
      });
    },

    // 显示
    /*
     * @param type {string} 显示类型
     * @param pid {int} 父级机构id
     * @param rowData {object} 某条具体的部门信息
     */
    show(type, pid, rowData) {
      if (rowData) {
        let singleDepartmentData = JSON.parse(JSON.stringify(rowData));
        singleDepartmentData.depart_id = singleDepartmentData.depart_id
          ? singleDepartmentData.depart_id + ""
          : "";
        singleDepartmentData.oc_id = singleDepartmentData.oc_id
          ? singleDepartmentData.oc_id + ""
          : "";
        singleDepartmentData.portrait = singleDepartmentData.portrait
          ? JSON.parse(singleDepartmentData.portrait)
          : [];
        singleDepartmentData.cust_type_ids = singleDepartmentData.cust_type_ids
          ? singleDepartmentData.cust_type_ids
          : [];
        this.$nextTick(() => {
          this.departmentData = singleDepartmentData;
          singleDepartmentData.portrait.forEach((item, index) => {
            this.$set(this.departmentData.portrait, index, item);
          });
        });
      }
      this.pid = pid;
      this.showType = type;
      if (type === "add") {
        this.title = "新增";
        this.$refs.form.resetFields();
      } else {
        this.title = "编辑";
      }
      this.modal = true;
    },

    // 取消
    cancel() {
      this.modal = false;
      this.departmentData = {
        portrait: [],
        cust_type_ids: []
      };
      this.$refs.form.resetFields();
    }
  }
};
</script>
<style scoped lang="less">
</style>
