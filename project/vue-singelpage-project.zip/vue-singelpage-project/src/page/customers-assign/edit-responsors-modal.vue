<template>
   <Modal
    v-model="modal"
    title="分配责任人"
    :mask-closable='false'
    width='500'>
      <div slot="footer">
         <Button  @click="onCancel">取消</Button>
         <Button type="primary" @click="onOk" :loading="btnLoading">确定</Button>
      </div>

      <div slot="close" @click="onCancel">
          <Icon type='ios-close-empty'></Icon>
      </div>

      <Select v-model="managerIds"  placeholder="请选择责任人" :key='selectKey' clearable>
          <Option
            v-for="(item,index) in managersList"
            :key="index" :value="item.value">
              {{item.label}}
            </Option>
      </Select>
   </Modal>
</template>

<script>
import { map } from "lodash";
export default {
  data() {
    return {
      btnLoading: false,
      selectKey: null,
      orgId: [],
      modal: false,
      managerIds: "",
      managersList: [],
      initManagersList: [],
      initManagerId: []
    };
  },

  created() {},

  methods: {
    show(ids, orgId, managerNames) {
      this.getManagersList();
      this.orgId = orgId;
      this.initManagerId = ids;
      ids.forEach((item, index) => {
        if (!this.managersList.some(mItem => mItem.value == item - 0)) {
          this.managersList.push({
            label: managerNames[index],
            value: item - 0
          });
        }
      });
      this.$nextTick(() => {
        this.managerIds = JSON.parse(
          JSON.stringify(ids.map(item => item - 0))
        ).shift();
      });
      this.selectKey = Date.now();
      this.modal = true;
    },

    onOk() {
      if (!this.initManagerId[0] && !this.managerIds) {
        this.onCancel();
        return;
      }
      this.btnLoading = true;
      let params = this.managerIds
        ? this.getReassignParams()
        : this.getClearResponsorParams();

      try {
        this.$http.post("custManagerRela", params).then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.$Message.success("分配成功！");
            if(this.managerIds){
              this.$emit("refreshTable",params.memberIds);
            }else{
              this.$emit("refreshTable")
            }
            this.onCancel();
          } else {
            this.$Message.error("分配失败！");
          } 
        });
      } catch (e) {
        this.btnLoading = false;
        this.$Message.error("分配失败！");
      }
    },

    getClearResponsorParams() {
      let params = {
        memberId: this.initManagerId[0] ? this.initManagerId[0] : "",
        orgIds: this.orgId,
        resourceType: 1,
        opType: 2
      };
      return params;
    },

    getReassignParams() {
      let params = {
        memberIds: [this.managerIds],
        orgIds: this.orgId,
        resourceType: 1,
        opType: 1
      };

      return params;
    },

    onCancel() {
      this.initManagerId = [];
      this.orgId = [];
      this.managerIds = "";
      this.managersList = JSON.parse(JSON.stringify(this.initManagersList));
      this.modal = false;
    },

    getManagersList() {
      this.$http
        .get("dept/getUserByDept", {
          dept_id: 16,
          type: 1
        })
        .then(res => {
          if (res.code === 20000) {
            this.managersList = map(res.data, person => person).filter(
              item => item.status
            );
            this.initManagersList = map(res.data, person => person).filter(
              item => item.status
            );
          }
        })
        .catch(e => {
          console.error("获取人员列表失败");
        });
    }
  }
};
</script>

<style lang="less" scoped>
</style>

