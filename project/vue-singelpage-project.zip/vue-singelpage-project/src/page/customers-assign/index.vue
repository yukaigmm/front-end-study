<template>
  <div>
    <div class="search-area keydown-box">
      <search-area @changeSearchParam="changeSearchParam" @onKeydownSearch="search">
        <div slot="default">
          <Row>
            <Col span="8">
              <FormItem label="机构名">
                <Input v-model.trim="basicSearchForm.orgName" placeholder="请输入关键字,如：总部 分部"></Input>
              </FormItem>
            </Col>

            <Col span="8">
              <FormItem label="责任人">
                <Select v-model="basicSearchForm.managerIds" multiple>
                  <Option
                    v-for="option in managerList"
                    :value="option.value"
                    :key="option.value"
                  >{{option.label}}</Option>
                </Select>
              </FormItem>
            </Col>

            <Col span="4">
              <!-- 提交按钮 -->
              <Button type="primary" @click="search" style="margin-left:8px;">搜索</Button>
              <Button type="ghost" style="margin-left: -7px" @click="reset">重置</Button>
            </Col>
          </Row>
        </div>

        <div slot="extend">
          <Row>
            <Col span="8">
              <FormItem label="机构类型">
                <Row>
                  <Col span="11">
                    <Select v-model="extendSearchForm.ocId" clearable placeholder="请选择">
                      <Option
                        v-for="item in enums.c_org"
                        :value="item.value"
                        :key="item.value"
                      >{{item.name}}</Option>
                    </Select>
                  </Col>

                  <Col span="12" offset="1">
                    <Select v-model="extendSearchForm.departId" clearable placeholder="请选择">
                      <Option
                        v-for="item in enums.c_depart"
                        :value="item.value"
                        :key="item.value"
                      >{{item.name}}</Option>
                    </Select>
                  </Col>
                </Row>
              </FormItem>
            </Col>

            <Col span="8">
              <FormItem label="地域">
                <component
                  is="SelectLinkage"
                  v-model="extendSearchForm.area_ids"
                  :config="{
                        useForSearch: true,
                        cacheKey: 'c_area_all',
                        row: 'dialog-form-item-row',}"
                  style="width:100%;"
                ></component>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="8">
              <FormItem label="状态">
                <Select v-model="extendSearchForm.status" :clearable="true">
                  <Option
                    v-for="option in statusOptions"
                    :value="option.value"
                    :key="option.value"
                  >{{option.label}}</Option>
                </Select>
              </FormItem>
            </Col>
          </Row>
        </div>
      </search-area>
    </div>

    <div class="clear customer-assign-btn">
      <Button type="primary" class="left" @click="batchAdd">批量分配</Button>
    </div>

    <div class="tableContainer">
      <Table
        ref="table"
        :data="tableData"
        :columns="columns"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        border
        @on-selection-change="onTableSelectionChange"
      ></Table>
    </div>

    <div class="clear page-load">
      <Page
        class="right"
        :total="total"
        placement="top"
        :current="pageNo"
        :page-size="pageSize"
        @on-change="onPageNoChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      />
    </div>

    <manager-modal ref="managerModal" @selectManager="selectManager"></manager-modal>

    <edit-responsors-modal ref="editResponsorsModal" @refreshTable="search"></edit-responsors-modal>
  </div>
</template>
<script>
import $ from "jquery";
import searchArea from "../../components/search-area";
import managerModal from "./select-dept-manager-modal";
import SelectLinkage from "../../components/inputs/select-linkage";
import editResponsorsModal from "./edit-responsors-modal";
import _ from "lodash";
import { mapGetters } from "vuex";
import getMinusNumber from "@/mixins/getMinusNumber.js";
export default {
  components: {
    searchArea,
    managerModal,
    SelectLinkage,
    editResponsorsModal
  },

  mixins: [getMinusNumber],
  data() {
    return {
      statusOptions: [
        {
          value: 0,
          label: "未分配"
        },
        {
          value: 1,
          label: "已分配"
        }
      ],
      useExtendParams: false,
      initBasicSearchForm: {
        orgName: "",
        managerIds: []
      },
      basicSearchForm: {
        orgName: "",
        managerIds: []
      },
      initExtendSearchForm: {
        status: "",
        area_ids: "",
        custTypeIds: []
      },
      extendSearchForm: {
        status: "",
        area_ids: "",
        custTypeIds: []
      },
      pageSize: 10,
      pageNo: 1,
      total: 0,
      managerList: [],
      tableLoading: false,
      tableSelectedRow: [],
      tableData: [],
      columns: [
        {
          type: "selection",
          width: 60,
          key: "selection",
          align: "center"
        },
        {
          title: "机构名",
          key: "orgName",
          width: 340,
          render: (h, params) => {
            let bread = params.row.bread.filter((item, index) => index !== 0);
            return h(
              "span",
              bread.map((item, index) => {
                if (index === bread.length - 1) {
                  return h("span", `${item.title}`);
                } else {
                  return h("span", `${item.title} > `);
                }
              })
            );
          }
        },
        {
          title: "机构类型",
          key: "ocId",
          width: 140,
          render: (h, { row }) => {
            return this.orgTypeMap[row.ocId];
          }
        },
        {
          title: "客户类型",
          key: "custTypeIds",
          width: 140,
          render: (h, params) => {
            if (params.row.custTypeIds && params.row.custTypeIds.length) {
              let cusType = [];
              params.row.custTypeIds.forEach(item => {
                this.enums.c_port_all_cust.forEach(itemCus => {
                  if (item == itemCus.value) {
                    cusType.push({
                      name: itemCus.name,
                      style: itemCus.style
                    });
                  }
                });
              });
              return h(
                "div",
                cusType.map(item => {
                  return h(
                    "Tag",
                    {
                      style: { ...item.style }
                    },
                    `${item.name}`
                  );
                })
              );
            } else {
              return "--";
            }
          }
        },
        {
          title: "城市",
          key: "cityId",
          width: 160,
          render: (h, { row }) => {
            return this.cityMap[row.cityId];
          }
        },
        {
          title: "是否分配",
          key: "status",
          width: 160,
          render: (h, { row }) => {
            return row.status == 1 ? "是" : "否";
          }
        },
        {
          title: "责任人",
          key: "manager",
          width: 160,
          render: (h, { row }) => {
            // let managerIds =
            //   row.managerIds instanceof Array
            //     ? row.managerIds
            //     : JSON.parse(row.managerIds);
            // return h(
            //   "div",
            //   managerIds
            //     .map(id => {
            //       let person =
            //         _.find(this.managerList, person => {
            //           return `${person.value}` == `${id}`;
            //         }) || {};
            //       return person.label || "无";
            //     })
            //     .join("/") || "--"
            // );
            return row.manager && row.manager.length
              ? row.manager.join("/")
              : "--";
          }
        },
        {
          title: "操作",
          key: "action",
          fixed: "right",
          width: 160,
          render: (h, { row, column, index }) => {
            return h(
              "div",
              {
                attrs: {
                  class: "deleteBtn",
                  title: "分配责任人"
                },
                on: {
                  click: () => {
                    if (!this.hasRight) {
                      return;
                    }
                    let managerIds = [];
                    if (row.managerIds) {
                      managerIds = row.managerIds.split(",");
                      managerIds = managerIds.filter(item => item);
                    }
                    this.$refs.editResponsorsModal.show(managerIds, [
                      row.orgId
                    ]);
                  }
                }
              },
              "分配"
            );
          }
        }
      ]
    };
  },
  watch: {
    "extendSearchForm.custTypeIds": {
      handler(val) {
        setTimeout(() => {
          let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(this.$el).find(
            ".ivu-select-selection .ivu-tag span"
          );
          let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
          let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    }
  },
  computed: {
    ...mapGetters({
      enums: "getEnums",
      userInfo: "getUser"
    }),
    orgTypeMap() {
      let obj = {};
      this.enums.c_org.forEach(item => {
        obj[item.value] = item.name;
      });
      return obj;
    },
    cityMap() {
      let obj = {};
      this.enums.c_area_deep_2.forEach(item => {
        obj[item.value] = item.name;
      });
      return obj;
    },
    hasRight() {
      return this.userInfo.auth.functional.includes("assignCustomer");
    }
  },

  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 130;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    changeSearchParam(val) {
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".search-area", ".customer-assign-btn", ".page-load"],
          ".tableContainer"
        );
      });

      this.useExtendParams = val;
    },
    getManagerList() {
      this.$http
        .get("dept/getUserByDept", {
          dept_id: 16, //机构销售部
          type: 1
        })
        .then(resp => {
          if (resp.code === 20000) {
            this.managerList = _.map(resp.data, person => person).filter(
              item => item.status
            );
          }
        });
    },
    search() {
      this.tableSelectedRow = [];
      this.pageNo = 1;
      this.pageSize = 10;
      this.getData();
    },
    reset() {
      this.basicSearchForm = JSON.parse(
        JSON.stringify(this.initBasicSearchForm)
      );
      this.extendSearchForm = JSON.parse(
        JSON.stringify(this.initExtendSearchForm)
      );
      this.search();
    },
    getData() {
      let basicSearchForm = JSON.parse(JSON.stringify(this.basicSearchForm));
      if (basicSearchForm.orgName) {
        basicSearchForm.orgName = basicSearchForm.orgName.trim().split(/[ ]+/);
      }
      let searchForm = {
        ...basicSearchForm,
        ...(this.useExtendParams ? this.extendSearchForm : {})
      };
      let params = {
        ...searchForm,
        pageSize: this.pageSize,
        pageNo: this.pageNo
      };
      this.tableLoading = true;
      this.$http.get("CustomerAllocated", params).then(resp => {
        this.tableLoading = false;
        if (resp.code === 20000) {
          this.tableData = resp.data.records;
          this.total = resp.data.total;
        } else {
          this.tableData = [];
          this.total = 0;
        }
      });
    },
    onPageNoChange(val) {
      this.pageNo = val;
      this.getData();
    },
    onPageSizeChange(val) {
      this.pageNo = 1;
      this.pageSize = val;
      this.getData();
    },
    batchAdd() {
      if (!this.hasRight) {
        return;
      }
      if (this.tableSelectedRow.length) {
        let hasDistRow = this.tableSelectedRow.some(row => {
          return row.status === 1;
        });
        if (hasDistRow) {
          this.$Message.error("选择数据中存在已负责的机构");
        } else {
          //16为机构销售部的部门id， true表示多选
          this.$refs.managerModal.show(16, true, "customer");
        }
      } else {
        this.$Message.warning("请先选择机构");
      }
    },
    onTableSelectionChange(selection) {
      this.tableSelectedRow = selection;
    },
    selectManager(managerIds) {
      if (this.tableSelectedRow.length && managerIds) {
        //批量分配api
        this.tableLoading = true;
        this.$http
          .post("custManagerRela", {
            memberIds: managerIds,
            orgIds: this.tableSelectedRow.map(row => row.orgId),
            resourceType: 1,
            opType: 1
          })
          .then(resp => {
            this.tableSelectedRow = [];
            this.tableLoading = false;
            if (resp.code === 20000) {
              this.$Message.success("设置成功");
              this.getData();
            }
          });
      }
    }
  },
  mounted() {
    this.getManagerList();
    this.getData();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".customer-assign-btn", ".page-load"],
      ".tableContainer"
    );
  }
};
</script>
<style lang="less" rel="styleSheet/less">
.clear {
  padding: 8px 0;
  .left {
    float: left;
  }
  .right {
    float: right;
  }
  &:after {
    clear: both;
    display: block;
    content: "";
    line-height: 0;
    visibility: hidden;
  }
}
</style>
