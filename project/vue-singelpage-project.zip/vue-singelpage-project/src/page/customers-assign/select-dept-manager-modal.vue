<template>
  <Modal
    v-model="modal"
    title="选择负责人"
    :mask-closable="false"
    width="500"
  >

    <div slot="footer">
      <Button type="primary" @click="ok">确定</Button>
      <Button @click="cancel">取消</Button>
    </div>
    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

     <div class="assign-pop" v-if="currentCompanyName">
        <span>当前公司：<b>{{currentCompanyName}}</b></span>
      </div>

    <Select v-model="managerIds" :multiple="isMultiple" clearable>
      <Option
         v-if="showType=='customer'"
         v-for="option in managerList"
         :value="option.value"
         :key="option.value">
         {{option.label}}
      </Option>

      <OptionGroup
         v-if="showType=='pe'"
         v-for = "(item,index) in managerList"
         :label="item.label"
         :key="index">
          <Option
             v-for="child in item.children"
             :value="child.value"
             :key="child.value">
             {{ child.label }}
          </Option>
      </OptionGroup>
    </Select>
  </Modal>
</template>

<script>
export default {
  props: ["companyName"],
  data() {
    return {
      // defaultManagerNames: [],
      showType: "",
      modal: false,
      managerIds: [],
      managerList: [],
      deptId: 0,
      isMultiple: false
    };
  },

  computed: {
    currentCompanyName: {
      set() {
        return this.companyName;
      },

      get() {
        return this.companyName;
      }
    }
  },
  methods: {
    /**
     * @param departId type[number,string] 部门id 下拉列表根据这个变化
     * @param isMultiple type[boolean] 是否多选
     * @param type type[string] 分配类型，分为私募分配和客户分配
     */
    show(deptId, isMultiple, type, ids) {
      this.showType = type;
      this.deptId = deptId;
      this.modal = true;
      this.isMultiple = !!isMultiple;
      this.getmanagerList().then(() => {
        if (ids&&ids.length) {
          ids.forEach((item, index) => {
            this.$set(this.managerIds, index, item - 0);
          });
          if (!this.isMultiple) {
            this.managerIds = JSON.parse(
              JSON.stringify(this.managerIds)
            ).shift();
          }
        }
      });
    },

    hide() {
      this.managerIds = [];
      this.modal = false;
      this.currentCompanyName = "";
      this.isMultiple = false;
    },

    ok() {
     
      if (!this.managerIds) {
        this.$Message.warning("请先选择负责人！");
        return;
      }

      this.$emit("selectManager", this.managerIds);
      this.hide();
    },

    cancel() {
      this.hide();
    },

    getmanagerList() {
      return new Promise(resolve => {
        if (this.showType == "customer") {
          this.$http
            .get("dept/getUserByDept", {
              dept_id: this.deptId, //机构销售部
              type: 1
            })
            .then(resp => {
              if (resp.code === 20000) {
                this.managerList = _.map(resp.data, person => person).filter(
                  item => item.status
                );
              }
            });
        } else {
          this.$http
            .get("dept/getAllWithUser", {
              dept_id: "1,15"
            })
            .then(res => {
              if (res.code === 20000) {
                this.managerList = res.data;
              }
            });
        }
        resolve();
      });
    }
  },
  mounted() {}
};
</script>

<style>
.assign-pop {
  color: rgb(237, 63, 20);
  font-size: 14px;
}
</style>
