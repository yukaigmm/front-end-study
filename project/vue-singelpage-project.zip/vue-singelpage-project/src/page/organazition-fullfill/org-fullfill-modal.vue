<template>
  <Modal 
     width="750" 
     v-model="modal" 
     title="补全机构" 
     :mask-closable="false" 
     class="fullfill-modal" 
     @on-visible-change="onVisibleChange">

    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button size="large" style="width:70px;" @click="cancel">取消</Button>
      <Button type="primary" size="large" style="width:70px;" :loading="buttonLoading" @click="ok">提交</Button>
    </div>

   <!-- 联系人 -->
    <div >
        <Form ref="formContact" :model="contactInfo" :label-width="100" :rules='cantactValidateRules' >
          <Row class="content-title">
            <Col span="24">
              <h3>联系人</h3>
            </Col>
          </Row>

          <Row>
            <Col span="11">
              <FormItem label="姓名" prop="name">
                <Input placeholder="请输入姓名" v-model.trim="contactInfo.name" style="width:100%;"></Input>
              </FormItem>
            </Col>
            <Col span="11">
              <FormItem label="职务" prop="post">
                <Input placeholder="请输入职务" v-model.trim="contactInfo.post" style="width:100%;"></Input>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="11">
              <FormItem label="电话" prop="telephone">
                <Input placeholder="请输入电话" v-model.trim="contactInfo.telephone" style="width:100%;"></Input>
              </FormItem>
            </Col>
            <Col span="11">
              <FormItem label="微信" prop="weichat">
                <Input placeholder="请输入微信" v-model.trim="contactInfo.weichat" style="width:100%;"></Input>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="11">
              <FormItem label="用户" prop="contacts_type">
                <Select v-model="contactInfo.contacts_type" placeholder="请选择">
                  <Option v-for="item in emnus.c_usertype" :value="item.value" :key="item.value">
                    {{item.name}}
                  </Option>
                </Select>
              </FormItem>
            </Col>
            <Col span="11">
              <FormItem label="邮箱" prop="email">
                <Input placeholder="请输入邮箱" v-model.trim="contactInfo.email" style="width:100%;"></Input>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="11">
              <FormItem label="性别" prop="sex">
                <Select v-model="contactInfo.sex" placeholder="请选择">
                  <Option v-for="item in emnus.c_sex" :value="item.value" :key="item.value">
                    {{item.name}}
                  </Option>
                </Select>
              </FormItem>
            </Col>
            <Col span="11">
              <FormItem label="年龄" prop="age">
                <Select v-model="contactInfo.age" placeholder="请选择">
                  <Option v-for="item in emnus.c_age" :value="item.value" :key="item.value">
                    {{item.name}}
                  </Option>
                </Select>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="11">
              <FormItem label="画像" prop="portrait">
                <Select v-model="contactInfo.portrait" multiple placeholder="请选择">
                  <Option v-for="item in emnus.c_port_all" :value="item.value" :key="item.value">
                    <Tag :style="item.style">{{item.name}}</Tag>
                  </Option>
                </Select>
              </FormItem>
            </Col>
          </Row>
        </Form>
    </div>
    <!-- 联系人end -->

    <!-- 补全类型 -->
    <Form ref="fullfillTypeForm" :label-width="100" :model= "fullfillTypeFormData" :rules="fullfillTypeValidateRules">
       <Row class="content-title">
         <Col span="24">
          <h3>补全方式</h3>
         </Col>
       </Row>

       <Row>
         <FormItem label="补全方式" :label-width="0" prop="isNewOrg">
           <RadioGroup v-model="fullfillTypeFormData.isNewOrg" @on-change="onfullfillTypeChange" >
             <Radio label="oldOrg">
               <span>选择已有机构进行补全</span>
             </Radio>
             <Radio label="newOrg">
               <span>新建机构进行补全</span>
             </Radio>
           </RadioGroup>
         </FormItem>
       </Row>
    </Form>

    <!-- 上级机构 -->
    <Form ref="topOrgForm" :label-width="100" :model= "topOrgFormData" :rules="topOrgValidateRules" v-show="isOld">
       <Row class="content-title">
         <Col span="24">
          <h3>机构<span class="subtitle" v-show="topOrgUp">(上级)</span> <span class="subtitle" v-show="addContactToChosenOrg">(联系人将直接添加至该机构)</span></h3>
         </Col>
       </Row>

       <Row>
        <Col span="22">
          <FormItem label="机构" prop="parentOrg">
            <Row>
              <Col span="24">
                <span style="margin-right:20px;">{{parentOrgName}}</span>
                <Button @click="chooseParentOrg" type="primary" size="small">选择</Button>
                <Button @click="clearParentOrg" type="ghost" size="small">清空</Button>
              </Col>
            </Row>
          </FormItem>
        </Col>
      </Row>
      
      <div>
           <Row class="is-top-org">
             <FormItem label="是否将联系人直接添加至该机构" :label-width="240" prop="isTopOrg">
               <RadioGroup v-model="topOrgFormData.isTopOrg" @on-change="onTopOrgTypeChange" >
                 <Radio label="followedDept">
                   <span>是</span>
                 </Radio>
                 <Radio label="topOrg">
                   <span>否</span>
                 </Radio>
               </RadioGroup>
             </FormItem>
           </Row>
           <Row style="margin-top:-15px;">
            <span style="color:#ed3f14;margin-left:50px">注:</span>
             <span style="color:#ed3f14;">若选择是，联系人将直接添加至【{{this.parentOrgName||"所选机构"}}】</span>
             <br>
             <span style="color:#ed3f14;margin-left:68px;">若选择否，您可以在【{{this.parentOrgName||"所选机构"}}】下新建部门，联系人将添加至新建部门</span>
           </Row>
      </div>
    </Form>
    <!-- 上级机构end -->

    <!-- 机构 -->
    <div v-show="isOrgFormShow">
       <Form ref="formOrg" :model="orgInfo" :label-width="100" :rules='orgValidateRules'>
         <Row class="content-title">
           <Col span="24">
            <h3>机构<span v-show="ifTopOrg" class="subtitle">(上级)</span> <span class="subtitle" v-show="!ifTopOrg">(未填写部门,联系人将直接添加至该机构)</span></h3>
           </Col>
         </Row>
         <Row>
           <Col span="11">
              <FormItem label="机构名称" prop="orgName" class="ivu-form-item-required">
                <Input v-model.trim="orgInfo.orgName" placeholder="请输入机构名称" class="org-name-input">
                </Input>
              </FormItem>
           </Col>
          <Col span="11">
              <FormItem label="类别" prop="ocId" class="ivu-form-item-required">
                <Select v-model="orgInfo.ocId" clearable placeholder="请选择">
                  <Option v-for="item in emnus.c_org" :value="item.value" :key="item.value">{{item.name}}</Option>
                </Select>
              </FormItem>
          </Col>
        </Row>

        <Row>
          <Col span="11">
             <FormItem label="电话" prop="phoneNum">
                <Input placeholder="请输入电话" v-model.trim="orgInfo.phoneNum" style="width:100%;"></Input>
            </FormItem>
          </Col>
          <Col span="11">
             <FormItem label="机构网址" prop="webSite">
               <Input placeholder="请输入机构网址" v-model.trim="orgInfo.webSite" style="width:100%;"></Input>
             </FormItem>
          </Col>
        </Row>

        <Row>
          <Col span="22">
             <FormItem label="画像" style="width:100%;" prop="portrait">
               <Select v-model="orgInfo.portrait" multiple placeholder="请选择">
                 <Option v-for="item in emnus.c_port_all_org" :value="item.value" :key="item.value">
                   <Tag :style="item.style">{{item.name}}</Tag>
                 </Option>
               </Select>
             </FormItem>
          </Col>
        </Row>

        <Row>
          <Col span="22">
              <FormItem label="客户类型" style="width:100%;" prop="custTypeIds">
                <Select v-model="orgInfo.custTypeIds" multiple placeholder="请选择">
                  <Option v-for="item in emnus.c_port_all_cust" :value="item.value" :key="item.value">
                    <Tag :style="item.style">{{item.name}}</Tag>
                  </Option>
                </Select>
              </FormItem>
          </Col>
        </Row>

        <Row>
          <Col span="22">
             <FormItem label="地域" prop="areaIds">
               <component is="SelectLinkage" 
                          v-model="orgInfo.areaIds" 
                          :config="{
                             useForSearch: true,
                             cacheKey: 'c_area_all',
                             row: 'dialog-form-item-row',
                             isFullfill:false
                             }" 
                          :isFullfill="true" 
                          style="width:100%;">
               </component>
             </FormItem>
          </Col>
        </Row>

        <Row>
          <Col span="22">
             <FormItem label="详细街道" prop="areaInfo">
               <Input placeholder="请输入详细街道" v-model.trim="orgInfo.areaInfo" style="width:100%;"></Input>
             </FormItem>
          </Col>
        </Row>

        <Row>
         <Col span="22">
            <FormItem label="备案编码" prop="registerNum">
              <Input placeholder="请输入备案编码" v-model.trim="orgInfo.registerNum" style="width:100%;"></Input>
            </FormItem>
         </Col>
        </Row>
     </Form>
    </div>
    <!-- 机构end -->

    <!-- 部门 -->
    <Row class="content-title" v-show="isDeptTitleShow">
      <Col span="24">
        <h3>
          部门
          <!-- <span style="font-size:12px;" v-show="!isOld">是否新建部门</span> -->
          <i-switch style="margin-left:20px;" v-show="!isOld" v-model="ifAddDept" class="add-dept" @on-change="onAddDeptSwitchChange" :disabled="!orgInfo.orgName">
             <span slot="open"><Icon type="checkmark" style="color:white"></Icon></span>
             <span slot="close"><Icon type="close-round" style="color:white"></Icon></span>
          </i-switch>
          <span style="margin-left:10px;" v-show="ifDeptFormShow" class="subtitle">(该部门将添加至上级机构下,联系人将添加至该部门)</span>
        </h3>
      </Col>
    </Row>

    <div v-show="ifDeptFormShow">
       <Form ref="formDept" :model="deptInfo" :label-width="100" :rules='deptValidateRules'>
           <Row>
             <Col span="11">
                <FormItem label="部门名称" prop="orgName" class="ivu-form-item-required">
                  <Input 
                     v-model.trim="deptInfo.orgName" 
                     placeholder="请输入部门名称"  
                     @input="inputDept" 
                     @on-focus="onDeptFocus" 
                     class="org-name-input" 
                     @on-blur="onDeptBlur">
                  </Input>
                  <Select
                    :class="{orgInput:isDeptSelectionShow,orgSelector:true}"
                    v-model="selectDeptName"
                    label-in-value
                    @on-change="onDeptOptionChange"
                    :loading="deptSelectLoading"
                    filterable
                    remote
                    :remote-method="getDept"
                    ref="searchDept">
                    <Option v-for="item in deptListOptions" :value="item.value" :key="item.value">
                      {{item.name}}
                    </Option>
                  </Select>
                </FormItem>
             </Col>
             <Col span="11">
                <FormItem label="类别" prop="depart_id" class="ivu-form-item-required">
                  <Select 
                    v-model="deptInfo.depart_id" 
                    not-found-text='无匹配数据' 
                    clearable 
                    placeholder="请选择类别" 
                    style="width:100%;">
                    <Option v-for="item in emnus.c_depart" :key="item.value" :label="item.name" :value="item.value">
                    </Option>
                  </Select>
                </FormItem>
             </Col>
           </Row>

           <Row>
             <Col span="11">
                <FormItem label="电话" prop="phoneNum">
                  <Input placeholder="请输入电话" v-model.trim="deptInfo.phoneNum" style="width:100%;"></Input>
                </FormItem>
             </Col>
             <Col span="11">
                <FormItem label="机构网址" prop="webSite">
                  <Input placeholder="请输入机构网址" v-model.trim="deptInfo.webSite" style="width:100%;"></Input>
                </FormItem>
             </Col>
           </Row>

           <Row>
             <Col span="22">
                <FormItem label="画像" style="width:100%;" prop="portrait">
                  <Select v-model="deptInfo.portrait" multiple placeholder="请选择">
                    <Option v-for="item in emnus.c_port_all_org" :value="item.value" :key="item.value">
                      <Tag :style="item.style">{{item.name}}</Tag>
                    </Option>
                  </Select>
                </FormItem>
             </Col>
           </Row>

           <Row>
            <Col span="22">
                <FormItem label="客户类型" style="width:100%;" prop="custTypeIds">
                  <Select v-model="deptInfo.custTypeIds" multiple placeholder="请选择">
                    <Option v-for="item in emnus.c_port_all_cust" :value="item.value" :key="item.value">
                      <Tag :style="item.style">{{item.name}}</Tag>
                    </Option>
                  </Select>
                </FormItem>
            </Col>
           </Row>

           <Row>
            <Col span="22">
                <FormItem label="地域" prop="areaIds">
                  <component 
                     is="SelectLinkage" 
                     v-model="deptInfo.areaIds" 
                     :config="{
                        useForSearch: true,
                        cacheKey: 'c_area_all',
                        row: 'dialog-form-item-row',
                        isFullfill:false
                        }" 
                     style="width:100%;">
                  </component>
                </FormItem>
            </Col>
           </Row>

           <Row>
            <Col span="22">
               <FormItem label="详细街道" prop="areaInfo">
                 <Input placeholder="请输入详细街道" v-model.trim="deptInfo.areaInfo" style="width:100%;"></Input>
               </FormItem>
            </Col>
          </Row>

           <Row v-if="false">
            <Col span="22">
               <FormItem label="备案编码" prop="register_num">
                 <Input placeholder="请输入备案编码" v-model.trim="deptInfo.register_num" style="width:100%;"></Input>
               </FormItem>
            </Col>
          </Row>
       </Form>
     </div>
     <!-- 部门end -->

     <chooseOrgModal ref="chooseOrgModal" @getChosenOrg="getChosenOrg"></chooseOrgModal>
  </Modal>
</template>
<script>
import SelectLinkage from "../../components/inputs/select-linkage.vue";
import chooseOrgModal from "./choose-org-modal.vue";
import {
  fetchGrid,
  fullfillMessage,
  fastAddVisitRecord,
  getMessageCount,
  getRow
} from "@/service/getData";
import {
  orgValidateRules,
  cantactValidateRules,
  deptValidateRules,
  orgValidateRulesWithParentOrg,
  deptValidateRulesWithParentOrg,
} from "./fullfillValidateRules.js";
import { mapGetters } from "vuex";
import $ from "jquery";
import { isEmpty } from "lodash";
export default {
  components: {
    SelectLinkage,
    chooseOrgModal
  },

  data() {
    return {
      fullfillText:'',
      topOrgUp: false,
      addContactToChosenOrg: false,
      ifTopOrg: false,
      isDeptTitleShow: false,
      isOld: true,
      fullfillTypeFormData: {
        isNewOrg: "oldOrg"
      },
      fullfillTypeValidateRules: {
        isNewOrg: [
          {
            required: true,
            message: "请先选择补全方式"
          }
        ]
      },
      topOrgFormData: {},
      topOrgValidateRules: {
        isTopOrg: [
          {
            required: true,
            message: "请选择"
          }
        ]
      },
      // 部门表单是否显示
      ifDeptFormShow: false,
      // 机构表单是否显示
      isOrgFormShow: false,
      // 是否添加部门
      ifAddDept: false,
      // 当前选中的部门id
      chosenDeptId: "",
      // 部门定时器id
      deptTimerId: "",
      // 筛选后的部门列表
      deptListOptions: [],
      // 选中的部门
      selectDeptName: "",
      // 控制部门下拉的显示
      isDeptSelectionShow: false,
      // 上级机构名称
      parentOrgName: "",
      // 机构验证规则
      orgValidateRules: orgValidateRulesWithParentOrg(),
      // 联系人验证规则
      cantactValidateRules: cantactValidateRules(),
      // 部门验证规则
      deptValidateRules: deptValidateRulesWithParentOrg(),
      // 客户id
      userId: "",
      // 上级机构id
      orgId: "",
      // 机构信息
      orgInfo: {
        orgName: "",
        ocId: "",
        phoneNum: "",
        webSite: "",
        portrait: [],
        areaIds: "86",
        areaInfo: "",
        custTypeIds: [],
        registerNum: ""
      },
      // 部门信息
      deptInfo: {
        orgName: "",
        ocId: "",
        phoneNum: "",
        webSite: "",
        portrait: [],
        areaIds: "",
        areaInfo: "",
        custTypeIds: [],
        registerNum: ""
      },
      // 联系人信息
      contactInfo: {
        name: "",
        post: "",
        telephone: "",
        email: "",
        sex: "",
        contacts_type: "",
        age: "",
        weichat: "",
        portrait: []
      },
      modal: false,
      buttonLoading: false,
      orgSelectLoading: false,
      deptSelectLoading: false
    };
  },

  watch: {
    // 有上级机构时，验证规则不一样
    isOrgFormShow: function(val) {
      new Promise(resolve => {
        if (val) {
          this.orgValidateRules = orgValidateRules();
          resolve();
        } else {
          this.orgValidateRules = orgValidateRulesWithParentOrg();
          resolve();
        }
      }).then(() => {
        this.$nextTick(() => {
          this.$refs.formOrg.resetFields();
        });
      });
    },

    isOld: function(val) {
      if (!val) {
        this.topOrgValidateRules = {
          isTopOrg: [
            {
              required: false,
              message: "请选择"
            }
          ]
        };
      }
    },

    ifDeptFormShow: function(val) {
      new Promise(resolve => {
        if (val) {
          this.deptValidateRules = deptValidateRules();
          resolve();
        } else {
          this.deptValidateRules = deptValidateRulesWithParentOrg();
          resolve();
        }
      }).then(() => {
        this.$nextTick(() => {
          this.$refs.formDept.resetFields();
        });
      });
    },

    "orgInfo.portrait": {
      handler(val) {
        this.setStyleOfSelectedPortrait(".fullfill-modal");
      },
      deep: true
    },

    "deptInfo.portrait": {
      handler(val) {
        this.setStyleOfSelectedPortrait(".fullfill-modal");
      },
      deep: true
    },

    "contactInfo.portrait": {
      handler(val) {
        this.setStyleOfSelectedPortrait(".fullfill-modal");
      },
      deep: true
    },

    "deptInfo.custTypeIds": {
      handler(val) {
        this.setStyleOfSelectedPortrait(".fullfill-modal");
      },
      deep: true
    },

    "orgInfo.custTypeIds": {
      handler(val) {
        this.setStyleOfSelectedPortrait(".fullfill-modal");
      },
      deep: true
    },

    deptListOptions: {
      handler(val) {
        if (val && val.length) {
          this.isDeptSelectionShow = true;
        } else {
          this.isDeptSelectionShow = false;
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapGetters({
      emnus: "getEnums",
      sysUserInfo: "getUser"
    })
  },

  mounted() {},

  methods: {
    onfullfillTypeChange(val) {
      this.clearParentOrg();
      if (val === "oldOrg") {
        // 编辑
        this.topOrgUp = false;
        this.addContactToChosenOrg = false;
        this.isOld = true;
        this.isOrgFormShow = false;
        this.ifDeptFormShow = false;
        this.isDeptTitleShow = false;
      } else {
        // 新增
        this.ifTopOrg = false;
        this.isOld = false;
        this.isDeptTitleShow = true;
        this.isOrgFormShow = true;
        this.ifDeptFormShow = false;
      }
    },
    // 添加部门的开关状态发生改变时
    onAddDeptSwitchChange(val) {
      this.$set(this.deptInfo, "orgName", "");
      this.clearDeptData();
      if (val && this.orgInfo.orgName) {
        // 选择是
        this.ifTopOrg = true;
        this.ifDeptFormShow = true;
      } else {
        // 选择否
        this.ifTopOrg = false;
        this.ifDeptFormShow = false;
      }
    },

    // 选定的上级机构的类型发生改变时
    onTopOrgTypeChange(val) {
      if (!this.orgId) {
        this.$refs.topOrgForm.resetFields();
        this.$Message.warning("请先选择机构");
        return;
      }
      this.$set(this.deptInfo, "orgName", "");
      this.$set(this.orgInfo, "orgName", "");
      this.clearOrgData();
      this.clearDeptData();
      if (val === "followedDept") {
        // 选择是  隐藏部门相关表单
        // this.fullfillText = `联系人将直接添加至${this.parentOrgName}`;
        this.addContactToChosenOrg = true;
        this.topOrgUp = false;
        this.isDeptTitleShow = false;
        this.ifDeptFormShow = false;
      } else {
        // this.fullfillText = `您可以新建部门，新建部门将添加至${this.parentOrgName}下,联系人将添加至新建部门`;
        // 选择否 显示部门相关表单
        this.isDeptTitleShow = true;
        this.ifDeptFormShow = true;
        this.addContactToChosenOrg = false;
        this.topOrgUp = true;
      }
    },

    // 清空上级机构，同时状态恢复初始值
    clearParentOrg() {
      this.topOrgUp = false;
      this.addContactToChosenOrg = false;
      this.ifTopOrg = false;
      this.orgId = "";
      this.parentOrgName = "";
      this.isDeptTitleShow = false;
      this.isOrgFormShow = false;
      this.ifAddDept = false;
      this.ifDeptFormShow = false;
      this.$set(this.topOrgFormData, "isTopOrg", "");
      this.deptListOptions = [];
      this.$set(this.orgInfo, "orgName", "");
      this.$set(this.deptInfo, "orgName", "");
      this.clearDeptData();
      this.clearOrgData();
      this.$refs.formOrg.resetFields();
      this.$refs.formDept.resetFields();
    },

    // 滚动条回到顶部事件
    scrollBackToTop() {
      $(this.$el)
        .find(".ivu-modal-body")
        .animate({ scrollTop: 0 });
    },

    onDeptFocus() {
      if (this.deptListOptions.length) {
        this.isDeptSelectionShow = true;
      } else {
        this.isDeptSelectionShow = false;
      }
    },

    // 通过id或名称获取部门列表
    getDeptListByIdOrName(orgName) {
      this.deptListOptions = [];
      if (!this.orgId) {
        return;
      }
      let params = {
        parent_org_id: this.orgId,
        org_name: orgName
      };
      this.deptSelectLoading = true;
      return new Promise((resolve, reject) => {
        fetchGrid("index/OrgMatch", params).then(res => {
          this.deptSelectLoading = false;
          this.deptListOptions = this.deptListOptions.concat(res.data);
          resolve();
        });
      });
    },

    //  获取部门模糊匹配列表
    getDept(query) {
      if (!query) {
        this.deptListOptions = [];
        clearTimeout(this.deptTimerId);
        return;
      }
      clearTimeout(this.deptTimerId);
      this.deptTimerId = setTimeout(() => {
        this.getDeptListByIdOrName(query);
      }, 500);
    },

    // 部门输入框输入事件
    inputDept(val) {
      this.selectDeptName = "";
      this.clearDeptData();
      this.chosenDeptId = "";
      this.$refs.searchDept.setQuery(val);
    },

    // 选定部门之后
    onDeptOptionChange(val) {
      if (!isEmpty(val)) {
        if (val.label && val.value) {
          this.$set(this.deptInfo, "orgName", val.label.trim());
          this.getChosenDeptData(val.value);
          this.chosenDeptId = val.value;
        }
      }
      this.isDeptSelectionShow = false;
    },

    // 清空部门数据
    clearDeptData() {
      this.$set(this.deptInfo, "depart_id", "");
      this.$set(this.deptInfo, "phoneNum", "");
      this.$set(this.deptInfo, "webSite", "");
      this.$set(this.deptInfo, "portrait", []);
      this.$set(this.deptInfo, "areaIds", "");
      this.$set(this.deptInfo, "areaInfo", "");
      this.$set(this.deptInfo, "custTypeIds", []);
      this.$set(this.deptInfo, "registerNum", "");
    },

    // 获取选定的部门的数据
    getChosenDeptData(id) {
      getRow("/index/organization", id).then(res => {
        let baseData = res.data;
        baseData.portrait = baseData.portrait
          ? JSON.parse(baseData.portrait).map(item => item + "")
          : [];
        baseData.cust_type_ids = baseData.cust_type_ids.length
          ? baseData.cust_type_ids.map(item => item + "")
          : [];

        if (baseData.depart_id) {
          baseData.depart_id += "";
        }
        this.$set(this.deptInfo, "depart_id", baseData.depart_id);
        this.$set(this.deptInfo, "phoneNum", baseData.phone_num);
        this.$set(this.deptInfo, "webSite", baseData.web_site);
        this.$set(this.deptInfo, "portrait", baseData.portrait);
        this.$set(this.deptInfo, "areaIds", baseData.area_ids);
        this.$set(this.deptInfo, "areaInfo", baseData.area_info);
        this.$set(this.deptInfo, "custTypeIds", baseData.cust_type_ids);
        this.$set(this.deptInfo, "registerNum", baseData.register_num);
      });
    },

    // ----------------------------------------------------------------------------------------------------
    // 部门input失去焦点时，隐藏下拉选项
    onDeptBlur() {
      setTimeout(() => {
        this.isDeptSelectionShow = false;
      }, 500);
    },

    // 清空机构数据
    clearOrgData() {
      this.$set(this.orgInfo, "ocId", "");
      this.$set(this.orgInfo, "phoneNum", "");
      this.$set(this.orgInfo, "webSite", "");
      this.$set(this.orgInfo, "portrait", []);
      this.$set(this.orgInfo, "areaIds", "");
      this.$set(this.orgInfo, "areaInfo", "");
      this.$set(this.orgInfo, "custTypeIds", []);
      this.$set(this.orgInfo, "registerNum", "");
    },

    //设置选中的画像的标签的样式
    setStyleOfSelectedPortrait(elClass) {
      setTimeout(() => {
        let el = $(elClass);
        let selectTags = $(el).find(".ivu-select-selection .ivu-tag");
        let selectTag = $(el).find(".ivu-select-selection .ivu-tag span");
        let tag = $(el).find(
          ".ivu-select-dropdown-list .ivu-select-item .ivu-tag span"
        );
        let tagContianer = $(el).find(
          ".ivu-select-dropdown-list .ivu-select-item .ivu-tag"
        );
        for (let i = 0; i < tagContianer.length; i++) {
          for (let j = 0; j < selectTag.length; j++) {
            if (
              $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
            ) {
              $(selectTags.get(j))[0].setAttribute(
                "style",
                $(tagContianer.get(i))[0].getAttribute("style")
              );
            }
          }
        }
      }, 10);
    },

    // 显示选择上级机构的模态框
    chooseParentOrg() {
      this.$refs.chooseOrgModal.show();
    },

    // 获取选定的机构节点
    getChosenOrg(val) {
      this.isDeptTitleShow = false;
      this.$set(this.topOrgFormData, "isTopOrg", "");
      this.orgId = val.id;
      this.parentOrgName = val.title;
      if (this.orgId) {
        // 如果选择了顶级机构，那么必须选择机构类别
        if (
          this.topOrgFormData.isTopOrg !== "followedDept" ||
          this.topOrgFormData.isTopOrg !== "topOrg"
        ) {
          this.isOrgFormShow = false;
          this.ifAddDept = false;
          this.ifDeptFormShow = false;
        }
        this.$set(this.deptInfo, "orgName", "");
        this.$set(this.orgInfo, "orgName", "");
        this.$nextTick(() => {
          this.ifAddDept = false;
          this.ifDeptFormShow = false;
          this.clearOrgData();
          this.clearDeptData();
        });
      }
    },

    // 显示这个模态框
    show(userInfo) {
      this.scrollBackToTop();
      // 联系人默认值
      this.contactInfo.name = userInfo.contactName;
      this.contactInfo.telephone = userInfo.telephone;
      this.contactInfo.email = userInfo.email;
      this.contactInfo.portrait = userInfo.portrait ? userInfo.portrait : [];
      this.userId = userInfo.userid;
      this.modal = true;
    },

    // 点击确定
    ok() {
      // 上级机构验证
      let topOrgValidate = new Promise(resolve => {
        this.$refs.topOrgForm.validate(valid => {
          resolve(valid);
        });
      });
      // 机构验证
      let formOrgValidate = new Promise((resolve, reject) => {
        this.$refs.formOrg.validate(valid => {
          resolve(valid);
        });
      });
      // 部门验证
      let formDeptValidate = new Promise((resolve, reject) => {
        this.$refs.formDept.validate(valid => {
          resolve(valid);
        });
      });
      // 联系人验证
      let formContactValidate = new Promise((resolve, reject) => {
        this.$refs.formContact.validate(valid => {
          resolve(valid);
        });
      });
      // 补全机构
      Promise.all([
        formOrgValidate,
        formDeptValidate,
        formContactValidate,
        topOrgValidate
      ]).then(([orgValid, deptValid, contactValid, topOrgValid]) => {
        if (orgValid && deptValid && contactValid && topOrgValid) {
          this.buttonLoading = true;
          fullfillMessage(this.params()).then(res => {
            if (res.code === 20000) {
              this.$Message.info("补全成功！");
              this.$emit("refreshTable");
              this.cancel();
            } else {
              this.$Message.warning(res.msg);
            }
            this.buttonLoading = false;
          });
        } else {
          this.$Message.warning("请按红色字段填写内容！");
        }
      });
    },

    // 提交的参数
    params() {
      let params = {};
      if (this.userId) {
        params.userid = this.userId;
      }
      // 如果选定了上级机构
      if (this.orgId) {
        params.parentOrgId = this.orgId;
      }

      // 机构信息参数
      params.orgInfo = this.deleteUselessKey(this.orgInfo);

      if (!params.orgInfo.orgName && !params.orgInfo.ocId) {
        params.orgInfo = {};
      }
      // 部门信息参数
      params.deptInfo = this.deleteUselessKey(this.deptInfo);
      if (this.chosenDeptId) {
        params.deptInfo.orgId = this.chosenDeptId;
      }
      if (!params.deptInfo.orgName || !params.deptInfo.depart_id) {
        params.deptInfo = {};
      }
      // 联系人信息参数
      params.contactInfo = this.deleteUselessKey(this.contactInfo);
      return params;
    },

    // 清除没有赋值的参数
    deleteUselessKey(paramObj) {
      let params = {};
      for (let key in paramObj) {
        if (paramObj[key] && paramObj[key].length) {
          params[key] = paramObj[key];
        } else if (paramObj[key] && typeof paramObj[key] === "object") {
          if (!Array.isArray(paramObj[key])) {
            params[key] = paramObj[key];
          }
        }
      }

      return params;
    },
    // 点击取消
    cancel() {
      this.clearParentOrg();
      this.$set(this.fullfillTypeFormData, "isNewOrg", "oldOrg");
      this.isOld = true;
      this.modal = false;
      this.$refs.formContact.resetFields();
      this.$refs.formOrg.resetFields();
      this.$refs.formDept.resetFields();
      this.$refs.topOrgForm.resetFields();
      this.$nextTick(() => {
        this.$set(this.orgInfo, "areaIds", "");
        this.$set(this.deptInfo, "areaIds", "");
      });
    },

    // 开关开启与关闭时验证规则发生变化，
    // 所以切换模态框状态时，重新清除
    onVisibleChange() {
      this.$refs.topOrgForm.resetFields();
      this.$refs.formOrg.resetFields();
      this.$refs.formDept.resetFields();
    }
  }
};
</script>
<style lang="less" scoped>
.outerUserList {
  background-color: #f1f1f1;
}

.content-title {
  background-color: #f1f1f1;
  margin: 5px;
  padding: 5px;
  border-radius: 5px;
}

.chosenPeople {
  border: 1px solid red;
  border-radius: 6px; // width: 500px;
}

.show_container {
  width: 100%;
  height: 40px;
  min-height: 40px;
  border: 1px solid #dddee1;
  border-radius: 5px;
  position: relative;
  padding-bottom: 10px;
  word-wrap: break-word;
  .show-content {
    width: 100%;
    height: 100%;
    overflow: hidden;
    padding: 5px;
    line-height: 22px;
  }
  .total {
    display: inline-block;
    position: absolute;
    bottom: -10px;
    right: 10px;
    padding: 0 10px;
    background-color: white;
    height: 20px;
    line-height: 20px;
  }
  .tool {
    cursor: pointer;
    width: 60px;
    height: 20px;
    margin: 0px 5px;
    padding: 0 10px;
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translate(-50%, 0);
    background-color: #fff;
    .icon-container {
      float: left;
      display: inline-block;
      position: relative;
      margin-left: 2px;
      .icon {
        display: block;
        position: absolute;
        top: -3px;
        &.second {
          top: 0px;
        }
        &.thrid {
          top: 3px;
        }
      }
    }
    .text {
      float: left;
      line-height: 20px;
      font-size: 12px;
      color: #666;
    }
  }
}
.subtitle {
  margin-left: 10px;
  font-size: 12px;
  font-weight: normal;
}

.showMorePeople.show_container {
  height: auto;
}
</style>
