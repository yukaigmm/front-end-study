<template>
  <Modal width="400" v-model="modal" title="请选择上级机构" :loading="modalLoading" :mask-closable="false" class="fullfill-choose-org-modal" @on-cancel="cancel">
    <div slot="footer"></div>
    <Row type="flex" justify="center">
      <Col span="24">
      <Poptip placement="bottom-start" width="300" @on-ok="getChosenNode" confirm cancel-text="">
        <Input v-model.trim="outerKeywords" placeholder="请输入关键字,如：总部 分部" style="width:300px;margin-left:15px;" @input="getOuterList">
        </Input>
        <div slot="title">
          <Spin fix v-if="outerListLoading">
            <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
            <div>加载中...</div>
          </Spin>
          <div v-else>
            <el-tree :data="outerList" check-strictly class="org-tree" show-checkbox node-key="id" ref="tree" :auto-expand-parent="true" :props="defaultProps" @check-change="currentChange" :default-expanded-keys="expandIdArr">
            </el-tree>
          </div>
        </div>
      </Poptip>
      </Col>
    </Row>
  </Modal>
</template>
<script>
import { fetchGrid } from "@/service/getData";
export default {
  data() {
    return {
      modal: false,
      modalLoading: false,
      outerKeywords: "",
      outerListLoading: false,
      outerList: [],
      // 默认树节点信息
      defaultProps: {
        children: "children",
        label: "title"
      },
      // 最后选中的上级机构
      lastOrg: {},
      // 展开的树结构
      expandIdArr: [],
      clearId: ""
    };
  },

  methods: {
    show() {
      this.modal = true;
    },
    cancel() {
      this.outerList = [];
      this.outerKeywords = "";
      this.modal = false;
    },

    getChosenNode() {
      this.$emit("getChosenOrg", this.lastOrg);
      this.cancel();
    },

    // 获取上级机构列表
    getOuterList() {
      this.outerList = [];
      if (!this.outerKeywords) {
        return;
      }
      let outerKeywords = this.outerKeywords.trim().split(/[ ]+/);
      let params = {
        // 是否显示部门下的人
        showPerson: false,
        // 搜索类型是机构
        type: 2,
        keywords: outerKeywords,
        disabled: false,
        disabledKey: "disabled"
      };
      this.outerListLoading = true;
      clearTimeout(this.clearId);
      this.clearId = setTimeout(() => {
        fetchGrid("visit/gettreebytype", params).then(res => {
          this.outerList = [
            {
              id: -1,
              checked: false,
              disabled: true,
              expand: true,
              title: "所有",
              children: [].concat(res.data)
            }
          ];
          this.expandIdArr.unshift(-1);
          this.lastTreeData = [];
          this.outerListLoading = false;
        });
      }, 500);
    },

    // 手动设置选中状态，确保只能选中一个
    currentChange(data, isChecked) {
      if (isChecked) {
        this.$refs.tree.setCheckedNodes([data]);
        this.lastOrg = {
          id: data.id,
          title: data.title
        };
        this.outerKeywords = data.title;
      } 
    }
  }
};
</script>
<style lang='less' scoped>
.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}
@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
