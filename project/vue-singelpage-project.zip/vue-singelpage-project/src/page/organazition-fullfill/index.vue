<template>
  <div class="sale-manage">
    <div class="search-area keydown-box">
      <search-area @changeSearchParam="changeSearchParam" @onKeydownSearch="search">
        <div slot="default">
          <Row>
            <Col span="8">
              <FormItem label="客户姓名">
                <Input v-model.trim="defaultSearchData.contactName" placeholder="请输入客户姓名"></Input>
              </FormItem>
            </Col>
            <Col span="8">
              <FormItem label="客户手机号">
                <Input v-model.trim="defaultSearchData.telephone" placeholder="请输入客户手机号"></Input>
              </FormItem>
            </Col>
            <Col span="4">
              <!-- 提交按钮 -->
              <Button type="primary" @click="search" style="margin-left:8px;">搜索</Button>
              <Button type="ghost" style="margin-left: -7px" @click="reset">重置</Button>
            </Col>
          </Row>
        </div>
        <div slot="extend">
          <Row>
            <Col span="8">
              <FormItem label="邀请码">
                <Input v-model.trim="extendSearchData.inviteCode" placeholder="请输入邀请码"></Input>
              </FormItem>
            </Col>
            <Col span="8">
              <FormItem label="被邀请码">
                <Input v-model.trim="extendSearchData.invitedCode" placeholder="请输入被邀请码"></Input>
              </FormItem>
            </Col>
          </Row>
        </div>
      </search-area>
    </div>

    <!-- <Button
      type="primary"
      @click="updateData"
      style="margin:10px 0"
      v-if="ifShowUpdate"
      :loading="updateLoading"
    >更新数据</Button>-->

    <div class="tableContainer">
      <Table
        class="table-grid"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        :columns="columns"
        :data="tableData"
        border
      ></Table>
    </div>
    <div class="page-load">
      <div class="float-right">
        <Page
          :total="total"
          placement="top"
          :current="currentPage"
          :page-size="pageSize"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizeChange"
          show-elevator
          show-sizer
          show-total
        />
      </div>
    </div>

    <accountEditModal ref="accountEditModal" @refreshTable="refreshTable"/>

    <!-- <orgFullfillModal ref="orgFullfillModal" @refreshTable="refreshTable"></orgFullfillModal> -->
  </div>
</template>
<script>
import orgFullfillModal from "./org-fullfill-modal.vue";
import AccountEditModal from "../account-justify/components/account-edit-modal.vue";
import { getCustomersList } from "@/service/getData";
import searchArea from "../../components/search-area";
import $ from "jquery";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import { mapGetters } from "vuex";

export default {
  components: {
    orgFullfillModal,
    searchArea,
    AccountEditModal
  },

  mixins: [getMinusNumber],

  data() {
    return {
      // updateLoading: false,
      isShowMoreParams: false,
      defaultSearchData: {
        contactName: "",
        telephone: ""
      },
      extendSearchData: {
        inviteCode: "",
        invitedCode: ""
      },
      tableLoading: false,
      tableData: [],
      columns: [
        {
          title: "姓名",
          key: "contactName",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.contactName
                }
              },
              row.contactName || "--"
            );
          }
        },
        {
          title: "电话",
          key: "telephone",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.telephone
                }
              },
              row.telephone || "--"
            );
          }
        },
        {
          title: "邮箱",
          key: "email",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.email
                }
              },
              row.email || "--"
            );
          }
        },
        {
          title: "公司名称",
          key: "companyName",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.companyName
                }
              },
              row.companyName || "--"
            );
          }
        },
        {
          title: "邀请码",
          key: "inviteCode",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.inviteCode
                }
              },
              row.inviteCode || "--"
            );
          }
        },
        {
          title: "被邀请码",
          key: "invitedCode",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.invitedCode
                }
              },
              row.invitedCode || "--"
            );
          }
        },
        {
          title: "创建时间",
          key: "createtime",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.createtime ? row.createtime.substr(0, 11) : ""
                }
              },
              row.createtime ? row.createtime.substr(0, 11) : "--"
            );
          }
        },
        // {
        //   title: "处理情况",
        //   key: "handleStatus",
        //   render:(h,params)=>{
        //     return ( params.row.handleStatus === 0 ? "未处理" :  (params.row.handleStatus === 1? "已处理" : "未知"))
        //   }
        // },
        //  {
        //   title: "处理人",
        //   key: "handler",
        // },
        //  {
        //   title: "处理时间",
        //   key: "handletime",
        // },
        {
          title: "操作",
          render: (h, params) => {
            return h(
              "div",
              {
                attrs: {
                  class: "deleteBtn"
                },
                on: {
                  click: () => {
                    this.showOrgFullfillModal(params.row);
                  }
                }
              },
              "补全"
            );
          }
        }
      ],
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  computed: {
    ...mapGetters({
      userId: "getUserId",
      userInfo: "getUser"
    })

    // ifShowUpdate() {
    //   return this.userInfo.auth.functional.includes("updateFullfillData");
    // }
  },

  mounted() {
    this.getContactsList();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".page-load"],
      ".tableContainer"
    );
  },

  methods: {
    // 更新数据
    // updateData() {
    //   this.updateLoading = true;
    //   try {
    //     this.$http.putWithoutId("updateMissingData").then(res => {
    //       if (res.code === 20000) {
    //         Promise.resolve()
    //           .then(() => {
    //             this.search();
    //           })
    //           .then(() => {
    //             this.updateLoading = false;
    //             this.$Message.success("更新成功！");
    //           });
    //       } else {
    //         this.updateLoading = false;
    //         this.$Message.error(`更新失败：${res.msg}!`);
    //       }
    //     });
    //   } catch (err) {
    //     this.updateLoading = false;
    //     this.$Message.error(`更新失败!`);
    //   }
    // },

    reset() {
      this.$set(this.defaultSearchData, "contactName", "");
      this.$set(this.defaultSearchData, "telephone", "");
      this.$set(this.extendSearchData, "inviteCode", "");
      this.$set(this.extendSearchData, "invitedCode", "");
      this.search();
    },
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 170;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    // 搜索
    search() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getContactsList();
    },

    changeSearchParam(val) {
      this.isShowMoreParams = val;
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".search-area", ".page-load"],
          ".tableContainer"
        );
      });
    },
    // 重新更新表格
    refreshTable() {
      this.getContactsList();
    },
    // 获取待处理客户列表
    getContactsList() {
      let searchData = {
        ...this.defaultSearchData,
        ...(this.isShowMoreParams ? this.extendSearchData : {})
      };
      let params = {
        pageSize: this.pageSize,
        pageNo: this.currentPage,
        handleStatus: 0,
        ...searchData
      };
      this.tableLoading = true;
      getCustomersList(params).then(res => {
        if (res.code === 20000) {
          this.total = res.data.total;
          this.tableData = res.data.records;
        } else {
          this.$Message.warning(res.msg);
        }
        this.tableLoading = false;
      });
    },

    // 展示补全模态框
    showOrgFullfillModal(row) {
      this.$refs.accountEditModal.show(
        row.accId,
        row.telephone,
        1,
        row.contractsId
      );
    },

    // 页码变化
    onPageChange(val) {
      this.currentPage = val;
      this.getContactsList();
    },

    // 一页数量发生变化
    onPageSizeChange(val) {
      this.currentPage = 1;
      this.pageSize = val;
      this.getContactsList();
    }
  }
};
</script>
<style lang="less" scoped>
.page-load {
  margin: 10px;
  overflow: hidden;
  .float-right {
    float: right;
  }
}
.tableContainer {
  margin-top: 15px;
}
</style>
