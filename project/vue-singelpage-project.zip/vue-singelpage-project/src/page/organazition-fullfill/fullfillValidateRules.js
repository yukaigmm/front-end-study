const orgValidateRules = () => {
  return {
    orgName: [{
      required: true,
      message: '请输入机构名称',
      trigger: 'blur,change'
    }],
    ocId: [{
      required: true,
      message: '请选择机构类别',
      trigger: 'blur,change'
    }],
    phoneNum: [{
      pattern: /(^1(3|4|5|6|7|8|9)\d{9}$)|(^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$)/,
      message: '请输入正确电话 如:400-6802928',
      trigger: 'blur,change'
    }],
    webSite: [{
      pattern: /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/,
      message: '参照 http://www.smppw.com',
      trigger: 'change, blur'
    }],


  }
}

const orgValidateRulesWithParentOrg = () => {
  return {
    orgName: [{
      required: false,
      message: '请输入机构名称',
      trigger: 'blur,change'
    }],
    ocId: [{
      required: false,
      message: '请选择机构类别',
      trigger: 'blur,change'
    }],
    phoneNum: [{
      pattern: /(^1(3|4|5|6|7|8|9)\d{9}$)|(^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$)/,
      message: '请输入正确电话 如:400-6802928',
      trigger: 'blur,change'
    }],
    webSite: [{
      pattern: /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/,
      message: '参照 http://www.smppw.com',
      trigger: 'change, blur'
    }],


  }
}

const deptValidateRules = () => {
  return {
    orgName: [{
      required: true,
      message: '请输入部门名称',
      trigger: 'blur,change'
    }],
    depart_id: [{
      required: true,
      message: '请选择部门类别',
      trigger: 'blur,change'
    }],
    phoneNum: [{
      pattern: /(^1(3|4|5|6|7|8|9)\d{9}$)|(^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$)/,
      message: '请输入正确电话 如:400-6802928',
      trigger: 'blur,change'
    }],
    webSite: [{
      pattern: /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/,
      message: '参照 http://www.smppw.com',
      trigger: 'change, blur'
    }],
  }
}

const deptValidateRulesWithParentOrg = () => {
  return {
    orgName: [{
      required: false,
      message: '请输入部门名称',
      trigger: 'blur,change'
    }],
    depart_id: [{
      required: false,
      message: '请选择部门类别',
      trigger: 'blur,change'
    }],
    phoneNum: [{
      pattern: /(^1(3|4|5|6|7|8|9)\d{9}$)|(^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$)/,
      message: '请输入正确电话 如:400-6802928',
      trigger: 'blur,change'
    }],
    webSite: [{
      pattern: /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/,
      message: '参照 http://www.smppw.com',
      trigger: 'change, blur'
    }],
  }
}

const cantactValidateRules = () => {
  return {
    name: [{
      required: true,
      message: '请输入姓名',
      trigger: 'change, blur'
    }],
    post: [{
      required: true,
      message: '请输入职务信息',
      trigger: 'change, blur'
    }],

    telephone: [{
      pattern: /^1(3|4|5|6|7|8|9)\d{9}$/,
      message: '请输入正确的电话',
      trigger: 'change, blur'
    }],
    email: [{
      pattern: /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/,
      message: '请输入正确的邮箱',
      trigger: 'change, blur'
    }],
    sex: [{
      required: true,
      message: '请选择性别',
      trigger: 'change'
    }],
    contacts_type: [{
      required: true,
      message: '请选择用户类型',
      trigger: 'change'
    }]
  }
}

const visitRecordValidateRules = () => {
  return {
    visitTime: [{
      required: true,
      type: 'date',
      message: '必选',
      trigger: 'blur, change'
    }],
    intentionType: [{
      required: true,
      message: '必选',
      trigger: 'blur, change'
    }],
    visitContent: [{
      required: true,
      min: 5,
      max: 1000,
      message: '不少于5个字',
      trigger: 'blur, change'
    }],
    visitType: {
      required: true,
      message: "必选",
      trigger: "change, blur"
    }
  }
}

export {
  orgValidateRules,
  orgValidateRulesWithParentOrg,
  cantactValidateRules,
  deptValidateRules,
  deptValidateRulesWithParentOrg,
  visitRecordValidateRules
}
