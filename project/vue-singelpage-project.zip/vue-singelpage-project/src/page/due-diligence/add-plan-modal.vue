<template>
  <div style="position:relative">
    <Modal
      v-model="modal"
      :width="780"
      :title="status =='add' ? '新增尽调计划' : '编辑尽调计划'"
      :mask-closable="false"
      @on-cancel="cancel"
      :animate="false"
      :transfer="true"
      :fullscreen="true"
    >
      <div slot="footer">
        <Button type="primary" @click="ok">确定</Button>
        <Button @click="cancel">取消</Button>
      </div>
      <div>
        <Spin fix v-show="loading">
          <Icon type="load-c" size="18" class="demo-spin-icon-load"></Icon>
          <div>Loading</div>
        </Spin>
        <Form ref="form" :model="form" :label-width="100" :rules="rules" :inline="true">
          <FormItem label="计划标题" style="width:700px">
            <div v-if="form.visitTime && orgName && form.contactsName">
              <span>{{form.visitTime ? form.visitTime.slice(0,5) : "--"}}</span>
              <span style="margin-left: 5px">{{orgName}}</span>
              <span style="margin-left: 5px">{{form.contactsName}}</span>
            </div>
          </FormItem>
          <FormItem label="拜访人" style="width:420px">
            <span>{{visitor || userInfo.trueName}}</span>
          </FormItem>
          <FormItem label="拜访对象" prop="contactsId" style="width:100%">
            <Input v-model="form.contactsId" style="display: none"></Input>
            <span>{{form.contactsName}}</span>
            <span style="margin-left: 5px">{{orgName}}</span>
            <Button
              type="primary"
              size="small"
              @click="chooseTarget"
            >{{form.contactsName ? '更换' : '选择'}}</Button>
          </FormItem>
          <FormItem label="拜访人职位" prop="position" style="width:600px">
            <Input type="text" v-model="form.position"></Input>
          </FormItem>
          <FormItem label="拜访地址" prop="visitAddress" style="width:600px">
            <Input type="text" v-model="form.visitAddress"></Input>
          </FormItem>
          <FormItem label="拜访日期" prop="date" style="width:320px">
            <DatePicker
              type="date"
              v-model="form.date"
              placeholder="日期"
              style="width: 120px"
              @on-change="dateChange"
            ></DatePicker>
            <TimePicker
              type="time"
              format="HH:mm"
              v-model="form.time"
              placeholder="时间"
              style="width: 90px"
              @on-change="timeChange"
            ></TimePicker>
          </FormItem>
          <FormItem label="拜访类别" prop="visitType" style="width:300px">
            <Select v-model="form.visitType" clearable disabled>
              <Option
                v-for="(item,index) in visitTypeOption"
                :key="index"
                :value="item.value"
              >{{item.name}}</Option>
            </Select>
          </FormItem>

          <FormItem label="尽调形式" prop="visitChannel" style="width:320px">
            <Select v-model="form.visitChannel" clearable>
              <Option
                v-for="(item,index) in visitChannelOptions"
                :key="index"
                :value="item.value"
              >{{item.name}}</Option>
            </Select>
          </FormItem>
          <FormItem label="计划可见范围" prop="openLevel" style="width:300px">
            <Select v-model="form.openLevel" clearable>
              <Option
                v-for="(item,index) in openLevelOptions"
                :key="index"
                :value="item.value"
              >{{item.name}}</Option>
            </Select>
          </FormItem>
          <FormItem label="备忘提醒" prop="remark" style="width:700px">
            <Input type="textarea" v-model="form.remark" :rows="3"></Input>
          </FormItem>
        </Form>
      </div>

      <div class="table-area" v-if="status == 'edit'">
        <h4>联合尽调人</h4>
        <Table :data="combineVisitor" :columns="columns" height="150" border/>
      </div>
    </Modal>
    <choose-visit :title="'选择尽调联系人'" ref="chooseVisit" @confirmVisitTarget="confirmVisitTarget"></choose-visit>
  </div>
</template>
<script>
import chooseVisit from "../visit-record-manager/choose-visit-target";
import moment from "moment";
import { mapGetters } from "vuex";
export default {
  components: {
    chooseVisit
  },
  computed: {
    ...mapGetters({
      userInfo: "getUser",
      enums: "getEnums"
    })
  },
  data() {
    return {
      combineVisitor: [],
      columns: [
        {
          key: "realName",
          title: "姓名",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.realName
                }
              },
              row.realName || "--"
            );
          }
        },
        {
          key: "accountNo",
          title: "电话",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.accountNo
                }
              },
              row.accountNo || "--"
            );
          }
        },
        {
          key: "orgName",
          title: "公司",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.orgName
                }
              },
              row.orgName || "--"
            );
          }
        },
        {
          key: "visitingCardUrl",
          title: "名片",
          ellipsis: true,
          render(h, { row }) {
            let url;
            if (row.visitingCardUrl) {
              let picUrl = JSON.parse(JSON.stringify(row.visitingCardUrl));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? "http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";
                picUrl = `Uploads/crm/${row.visitingCardUrl}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        }
      ],
      modal: false,
      loading: false,
      status: "add",
      planId: "",
      orgName: "",
      visitor: "",
      visitTypeOption: [],
      currentDueDiligenceId: "",
      form: {
        contactsId: "",
        contactsName: "",
        orgId: "",
        position: "",
        visitTime: "",
        visitDate: "",
        visitType: "3",
        visitAddress: "",
        visitChannel: 2,
        openLevel: 1,
        remark: ""
      },
      rules: {
        contactsId: [
          { required: true, message: "必填", trigger: "blur, change" }
        ],
        date: [
          {
            required: true,
            type: "date",
            message: "必选",
            trigger: "blur, change"
          }
        ]
      },
      visitChannelOptions: [
        { name: "电话尽调", value: 1 },
        { name: "实地尽调", value: 2 },
        { name: "待定", value: -1 }
      ],
      openLevelOptions: [
        { name: "仅公司内部可见", value: 1 },
        { name: "公司内部+组合大师可见", value: 2 }
      ]
    };
  },
  methods: {
    show(status, options, id) {
      this.status = status;
      this.modal = true;
      if (status == "add") {
        this.form = Object.assign({}, this.form, options);
        this.form.visitDate = options.date;
        this.form.visitTime = options.time;
      } else {
        this.visitor = options.visitor;
        this.currentDueDiligenceId = id;
        this.loading = true;
        Promise.all([this.getPlanData(id), this.getCombineVisitor(id)]).then(
          res => {
            this.loading = false;
          }
        );
        // this.getPlanData(id);
      }
    },

    getCombineVisitor(id) {
      return new Promise((resolve, reject) => {
        this.$http.get(`Schedule/booking/${id}`).then(res => {
          resolve();
          if (res.code === 20000) {
            this.combineVisitor = res.data || [];
          } else {
            this.$Message.error(res.msg);
          }
        });
      });
    },

    // 获取编辑计划数据
    getPlanData(id) {
      this.loading = true;

      this.planId = id;
      return new Promise((resolve, reject) => {
        this.$http.get("Schedule/" + id).then(res => {
          resolve();
          if (res.code == 20000) {
            this.form = Object.assign({}, this.form, res.data);
            this.form.date = res.data.visitDate;
            this.form.time = res.data.visitTime;
            this.form.contactsId = this.form.contactsId + "";
            this.form.openLevel = this.form.openLevel || "";
            this.form.visitChannel = this.form.visitChannel || "";
            // 获取拜访机构全称
            this.getOrgInfo(res.data.orgId).then(
              data => {
                let bread = data.bread || [];
                let orgNameArr = bread.map(item => {
                  return item.title;
                });
                this.orgName = orgNameArr.join(" ");
              },
              res => {
                this.$Message.error(res.msg);
              }
            );
          } else {
            resolve();
            this.$Message.error(res.msg);
          }
        });
      });
    },
    ok() {
      this.loading = true;
      this.$refs.form.validate(valid => {
        if (valid) {
          let formData = this.getSubmitData(this.form);
          if (this.status == "add") {
            this.addPlan(formData);
          } else {
            this.editPlan(formData);
          }
        } else {
          this.loading = false;
        }
      });
    },
    // 新增计划
    addPlan(formData) {
      this.$http.post("Schedule", formData).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          this.$Message.success("新增成功");
          this.$emit("getCalendarData", formData.visitDate);
          this.cancel();
        } else {
          this.$Message.error(res.msg);
        }
      });
    },
    // 修改计划
    editPlan(formData) {
      this.$http.put(`Schedule`, formData).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          this.$Message.success("修改成功");
          this.$emit("getCalendarData", formData.visitDate);
          this.cancel();
        } else {
          this.$Message.error(res.msg);
        }
      });
    },
    getSubmitData(form) {
      let formData = JSON.parse(JSON.stringify(form));
      delete formData.time;
      delete formData.date;
      delete formData.contactsName;
      return formData;
    },
    // 重置表单
    resetForm() {
      this.form = {
        contactsId: "",
        contactsName: "",
        orgId: "",
        visitTime: "",
        visitDate: "",
        visitType: "3",
        position: "",
        date: "",
        time: "",
        visitAddress: "",
        visitChannel: 2,
        openLevel: 1,
        remark: ""
      };
      this.combineVisitor = [];
      this.orgName = "";
      this.visitor = "";
      (this.currentDueDiligenceId = ""), this.$refs.form.resetFields();
    },
    cancel() {
      this.modal = false;
      this.resetForm();
    },
    // 联系人选择
    chooseTarget() {
      this.$refs.chooseVisit.show();
    },
    confirmVisitTarget(person) {
      this.form.contactsId = person.id + "";
      this.form.contactsName = person.title;
      this.form.orgId = person.org_id;
      this.form.position = person.position;
      this.validateOrgRepeat(person.org_id).then(repeatVisit => {
        if (repeatVisit.length) {
          this.noticeRepeat(repeatVisit);
          return;
        }
        this.getOrgInfo(person.org_id).then(
          data => {
            let bread = data.bread || [];
            let info = data.info || {};
            let orgNameArr = bread.map(item => {
              return item.title;
            });
            this.orgName = orgNameArr.join(" ");
            this.form.visitAddress = info.address || info.areaInfo;
          },
          res => {
            this.$Message.error(res.msg);
          }
        );
      });
    },
    // 根据拜访机构id获取机构的名称面包屑和其他信息
    getOrgInfo(orgId) {
      return new Promise((resolve, reject) => {
        let params = {
          showBread: 1,
          showContacts: 0
        };
        this.loading = true;
        this.$http
          .get(`orgDocument/orgOtherInfo/${orgId}`, params)
          .then(res => {
            this.loading = false;
            if (res.code === 20000) {
              resolve(res.data);
            } else {
              reject(res);
            }
          });
      });
    },
    // 验证尽调机构前后一个月是否有相同的机构，如果有的话，关闭用户添加的modal,并提示相关的尽调信息
    validateOrgRepeat(orgId) {
      return new Promise((resolve, reject) => {
        this.getSectionRecords(30).then(sectionRecords => {
          let repeatVisit = [];
          for (let record of sectionRecords) {
            record.visitArray.forEach(item => {
              if (
                item.orgId == orgId &&
                item.id != this.currentDueDiligenceId
              ) {
                repeatVisit.push(item);
              }
            });
          }
          console.log(repeatVisit);
          resolve(repeatVisit);
        });
      });
    },
    // 提示用户有相同的尽调记录并关闭 modal
    noticeRepeat(repeatVisit) {
      let content;
      if (repeatVisit.length > 1) {
        let dateArr = [];
        for (let item of repeatVisit) {
          dateArr.push(item.visitDate);
        }
        content = `一个月内存在多条相同公司的尽调记录，日期为${dateArr.join(
          "，"
        )}`;
      } else {
        let record = repeatVisit[0];
        if (
          moment(record.visitDate).isAfter(moment()) ||
          moment(record.visitDate).isSame(moment())
        ) {
          content = `${record.creatorName} 计划于 ${
            record.visitDate
          } 尽调该公司，可联系${record.creatorName}参与，不可重复创建尽调计划`;
        } else {
          content = `${record.creatorName} 已经于 ${
            record.visitDate
          } 尽调了该公司，一个月内不可再重复尽调`;
        }
      }
      this.$Modal.warning({
        title: "提示",
        content: content,
        onOk: () => {
          this.cancel();
        }
      });
    },
    // 获取某个区间段里面的尽调记录
    getSectionRecords(num) {
      return new Promise((resolve, reject) => {
        let params = {
          dateSection: this.getDateSection(num)
        };
        this.$http.get(`Schedule/section`, params).then(res => {
          if (res.code === 20000) {
            resolve(res.data);
          } else {
            this.$Message.error(res.msg);
          }
        });
      });
    },
    // 获取前后一个月的时间区间
    getDateSection(num) {
      let startDay = moment()
        .subtract(1, "M")
        .format("YYYY-MM-DD");
      let endDay = moment()
        .add(1, "M")
        .format("YYYY-MM-DD");
      return [startDay, endDay];
    },
    formateDate(date) {
      return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
    },
    // 尽调日期
    dateChange(date) {
      this.form.visitDate = date;
    },
    timeChange(time) {
      this.form.visitTime = time;
    },
    // ie 兼容的日期格式
    formateIeDate(date) {
      return date.replace(/-/g, "/");
    }
  },
  watch: {},
  mounted() {
    this.visitTypeOption = this.enums.c_visit_type;
  }
};
</script>
<style lang="less" ref="styleSheet/less">
// .due-diligence-plan-modal {
//   // .ivu-modal {
//     // top: 150px !important;
//   // }
//   // .ivu-modal-body {
//   //   position: relative;
//   // }
// }
</style>
