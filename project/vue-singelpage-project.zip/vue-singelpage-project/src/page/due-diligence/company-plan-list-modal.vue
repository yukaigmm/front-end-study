<template>
  <div style="position:relative">
    <Modal
      class="due-diligence-plan-modal"
      v-model="modal"
      :width="600"
      title="尽调列表"
      :mask-closable="false"
      @on-cancel="cancel"
      :animate="false"
      :transfer="true"
      :fullscreen="true"
    >
      <div slot="footer">
        <Button type="primary" @click="ok">确定</Button>
      </div>
      <div class="company-plan-list-table">
        <Spin fix v-show="loading">
            <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
            <div>Loading</div>
        </Spin>
        <Table border :columns="columns" :maxHeight="500" :data="tableData"></Table>
        </div>
        <div class="company-plan-list-table-pagination">
        <Page
            style="float: right"
            :current="currentPage"
            :page-size="pageSize"
            :total="total"
            placement="top"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizeChange"
            show-elevator
            show-sizer
            show-total
        ></Page>
        </div>
    </Modal>
  </div>
</template>
<script>
export default {
  computed: {
  },
  data() {
    return {
        modal: false,
        loading: false,
        currentPage: 1,
        pageSize: 10,
        total: 0,
        tableData: [],
        columns: [
            {
                title: "公司名称",
                key: "orgName",
            },
            {
                title: "尽调人",
                key: "creatorName",
                width: 80,
            },
            {
                title: "尽调时间",
                key: "visitDate",
                width: 100,
            },
            {
                title: "尽调对象",
                key: "contactsName",
                width: 80,
            },
        ],
        orgId: "",
    }
  },
  methods: {
    show(orgId) {
      this.modal = true;
      this.orgId = orgId;
      this.getOrgInfo(orgId).then((data) => {
        //   this.orgName = res
        let bread = data.bread || [];
        let orgNameArr = bread.map((item) => {
            return item.title
        });
        this.orgName = orgNameArr.join(" ");
        this.getPlanData();
      })
    },
    // 获取编辑计划数据
    getPlanData() {
      this.loading = true;
      this.$http.get("Schedule", {orgId: this.orgId, pageSize: this.pageSize, pageNo: this.currentPage}).then((res) => {
        this.loading = false;
        if(res.code === 20000 && res.data.records instanceof Array){
        //   this.tableData = JSON.parse(JSON.stringify(res.data.records));
        this.tableData = res.data.records.map((item) => {
            return Object.assign({}, item, {orgName: this.orgName})
        })
        this.total = res.data.total;

        }
      })
    },
    ok() {
        this.cancel();
    },
    cancel(){
        this.tableData = [];
        this.orgName = "";
        this.modal = false;
    },
    onPageChange(val){
        this.currentPage = val;
        this.getPlanData();
    },
    onPageSizeChange(val){
        this.pageSize = val;
        this.getPlanData();
    },
     // 根据拜访机构id获取机构的名称面包屑和其他信息
    getOrgInfo(orgId){
        return new Promise((resolve, reject) => {
            let params = {
                showBread: 1,
                showContacts: 0
            }
            this.loading = true;
            this.$http.get(`orgDocument/orgOtherInfo/${orgId}`,params).then((res) => {
                this.loading = false;
                if(res.code === 20000){
                    resolve(res.data);
                }else{
                    reject(res)
                }
            })
        })
    },
  },
  watch: {},
  mounted() {
  }
};
</script>
<style lang="less" ref="styleSheet/less">
.due-diligence-plan-modal {
  .ivu-modal {
    top: 150px !important;
  }
  .ivu-modal-body {
    position: relative;
  }
  .company-plan-list-table{
      margin-bottom: 10px;
  }
}
</style>
