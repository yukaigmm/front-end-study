<template>
  <div class="due-diligence-plan" v-loading="loading" element-loading-text="拼命加载中">
    <div class="due-dili-options-container">
      <div class="due-dili-person">
        <span>拜访人</span>
        <Select
          class="due-dili-person-selector"
          v-model="duePerson"
          clearable
          multiple
          @on-change="duePersonChange"
        >
          <Option v-for="(item, index) in dueDiligenceGroup" :value="item.value" :key="index">
            {{item.label }}
            <span
              class="user-color-preview"
              :style="{backgroundColor: getColorById(item.value)}"
            ></span>
          </Option>
        </Select>
      </div>
      <div class="due-dili-type">
        <span>尽调方式</span>
        <Select
          class="due-dili-type-selector"
          v-model="visitChannel"
          clearable
          style="width:180px; margin-right: 10px"
          @on-change="visitChannelChange"
        >
          <Option
            v-for="(item, index) in visitChannelGroup"
            :value="item.value"
            :key="index"
          >{{item.label}}</Option>
        </Select>
      </div>

      <!-- modified by yangqi start v1.15-->
      <div class="due-company-name">
        <span>公司名称</span>
        <i-input v-model.trim="companyName" placeholder="请输入公司名称"/>
      </div>

      <div class="due-btn">
        <i-button type="primary" @click="search">搜索</i-button>
        <i-button @click="reset">重置</i-button>
      </div>
      <!-- modified by yangqi end v1.15-->

      <div class="show-all">
        <span class="show-all-label">显示全部</span>
        <i-switch v-model="showAll" @on-change="showAllChange"/>
      </div>
      <div class="show-weekend">
        <span class="show-weekend-label">显示周末</span>
        <i-switch v-model="showWeekend" @on-change="showWeekendChange"/>
      </div>
    </div>
    <div class="due-diligence-calendar-container" id="dueDiligenceCalendar"></div>
    <plan-modal ref="planModal" @getCalendarData="getCalendarData"></plan-modal>
    <company-plan-list-modal ref="companyPlanListModal"></company-plan-list-modal>
    <!-- tooltip -->
    <div class="event-detail-tooltip" ref="eventToolTip">
      <div class="detail-row">
        <span>计划标题：</span>
        <span>{{event.visitTime ? event.visitTime.slice(0, -3) : "--"}} {{event.orgName}} {{event.contactsName}}</span>
      </div>
      <div class="detail-row">
        <span>拜访时间：</span>
        <span>{{event.visitDate || "--"}} {{event.visitTime ? event.visitTime.slice(0, -3) : "--"}}</span>
      </div>
      <div class="detail-row">
        <span>拜访人：</span>
        <span>{{event.creatorName}}</span>
      </div>
      <div class="detail-row">
        <span>职位：</span>
        <span>{{event.position || "--"}}</span>
      </div>
      <div class="detail-row">
        <span>拜访对象：</span>
        <span>{{event.orgName || "--"}} {{event.contactsName || "--"}}</span>
      </div>
      <div class="detail-row">
        <span>拜访地址：</span>
        <span>{{event.visitAddress || "--"}}</span>
      </div>
      <div class="detail-row">
        <span>尽调形式：</span>
        <span>{{visitChannelMap[event.visitChannel]}}</span>
      </div>
      <div class="detail-row">
        <span>备忘提醒：</span>
        <span>{{event.remark || "--"}}</span>
      </div>
      <i class="arrow"></i>
    </div>
  </div>
</template>
<script>
import $ from "jquery";
import "fullcalendar";
import moment from "moment";
import planModal from "./add-plan-modal.vue";
import companyPlanListModal from "./company-plan-list-modal.vue";
import { mapGetters } from "vuex";

export default {
  components: {
    planModal,
    companyPlanListModal
  },
  data() {
    return {
      calendar: "",
      loading: false,
      eventData: [],
      eventCount: 0,
      event: {},
      companyName: "",
      // 默认视图
      defaultView: "listMonth",
      // 默认当前日期
      defaultDate: "",
      // 是否显示周末
      showWeekend: false,
      // 是否显示全部（默认显示今天以后的尽调计划）
      showAll: false,
      // 是否有编辑权限
      editAdmin: false,
      addDueDiligence: false,
      editDueDiligence: false,
      delDueDiligence: false,
      openLevelMap: {
        1: "内部",
        2: "公开"
      },
      visitChannelMap: {
        1: "电话尽调",
        2: "实地尽调",
        "-1": "待定"
      },
      duePerson: [],
      dueDiligenceGroup: [],
      visitChannelGroup: [
        {
          label: "电话尽调",
          value: 1
        },
        {
          label: "实地尽调",
          value: 2
        },
        {
          label: "待定",
          value: -1
        }
      ],
      visitChannel: ""
    };
  },
  watch: {},
  computed: {
    ...mapGetters({
      userInfo: "getUser"
    })
  },

  methods: {
    //added by yangqi start v1.15
    search() {
      this.getCalendarData(this.calendar.fullCalendar("getDate"));
    },

    reset() {
      this.duePerson =[];
      this.visitChannel = "";
      this.companyName = "";
      this.getCalendarData(this.calendar.fullCalendar("getDate"));
    },
      //added by yangqi end v1.15

    getCalendar() {
      this.calendar = $(this.$el)
        .find("#dueDiligenceCalendar")
        .fullCalendar({
          // 日期头部版式设置
          header: {
            left: "today prevYear,prev,next,nextYear",
            center: "title",
            right: "month,agendaWeek,agendaDay,listMonth"
          },
          // 标题格式设置
          titleFormat: `YYYY年MM月`,
          // 按钮文字设置
          buttonText: {
            today: "今天",
            month: "月",
            agendaWeek: "周",
            agendaDay: "日",
            listMonth: "列表"
          },
          // 本地化
          locale: "zh-cn",
          // 视图主体高度
          contentHeight: 600,
          // 默认视图
          defaultView: this.defaultView,
          // 默认当前日期
          defaultDate: this.defaultDate,
          // 是否显示周末列
          weekends: this.showWeekend,
          // 月视图中显示非本月的日期
          showNonCurrentDates: false,
          // 月视图中，固定给6行周的视图
          fixedWeekCount: false,
          // 日期单元格render钩子
          dayRender: this.dayCellRender,
          // 事件太多时折叠
          eventLimit: true,
          eventLimitText: num => {
            return `+${num} 更多`;
          },
          // 事件渲染回调
          eventRender: this.eventRender,
          // 点击每个日期的event标签的回调
          eventClick: this.getDueDiligenceDetail,
          // 鼠标悬浮event标签回调
          eventMouseover: this.showEventDetail,
          eventMouseout: this.hideEventDetail,
          events: this.eventData,
          // 视图render钩子，在dayRender之后
          viewRender: (view, element) => {
            if (this.addDueDiligence) {
              this.setAddButtonDisplayAttr();
            }
            this.defaultDate = moment(new Date());
            // this.defaultView = this.calendar.fullCalendar("getView").type;
            this.defaultView = view.type;
            if (["agendaWeek", "agendaDay"].includes(this.defaultView)) {
              this.setOverlayView();
            }
            if (["month", "listMonth"].includes(this.defaultView)) {
              let title = $(this.$el).find(
                ".fc-toolbar.fc-header-toolbar .fc-center h2"
              );
              title.text(title.text() + `（共${this.eventCount}条）`);
            }
            this.eventCount = 0;
          },
          // window resize回调
          windowResize: this.windowResize,
          views: {
            day: {
              columnHeaderFormat: "MM月DD日 ddd"
            }
          }
        });
    },
    // 获取视图数据
    getCalendarData(date) {
      this.loading = true;
      this.defaultDate = date;
      this.eventCount = 0;
      this.$http
        .get("Schedule", {
          pageSize: -1,
          userId: this.duePerson,
          visitChannel: this.visitChannel,
          orgName: this.companyName
        })
        .then(
          res => {
            this.loading = false;
            if (res.code === 20000 && res.data.records instanceof Array) {
              let resData;
              // 默认显示今天及以后的日程
              let currentTime = moment(new Date()).format("YYYY-MM-DD");
              if (this.showAll) {
                resData = JSON.parse(JSON.stringify(res.data.records));
              } else {
                // ie 中有兼容性问题
                // resData = res.data.records.filter(item => {
                //    return (new Date(item.visitDate)).getTime() >= (new Date(`${currentTime.getFullYear()}-${currentTime.getMonth() + 1}-${currentTime.getDate()}`)).getTime();
                //   );
                // });

                resData = _.filter(res.data.records, item => {
                  return (
                    !moment(item.visitDate).isBefore(moment(currentTime)) ||
                    moment(item.visitDate).isSame(moment(currentTime))
                  );
                });
              }
              // 获取尽调分组的过滤选项
              if (this.duePerson.length === 0) {
                this.dueDiligenceGroup = this.getDueDiligenceGroup(resData);
              }
              this.eventData = this.getEventObj(resData);
              // 如果已经有视图了，则销毁视图并重新渲染，并保留已有的配置
            }
            if (this.calendar) {
              this.calendar.fullCalendar("destroy");
            }
            this.getCalendar();
          },
          () => {
            this.loading = false;
            this.getCalendar();
          }
        );
    },
    // 获取事件对象
    getEventObj(data) {
      return data.map(item => {
        let orgName = this.getOrgName(item.bread);
        // 将结束时间设置为半小时之后，这样在周视图和日视图中，任务只会占一行，比较清晰
        let endTime = new Date(
          new Date(`${item.visitDate} ${item.visitTime}`).getTime() + 1800000
        );
        endTime = moment(endTime).format("HH:mm");
        return {
          start: `${item.visitDate} ${item.visitTime}`,
          end: `${item.visitDate} ${endTime}`,
          title: `${item.visitTime ? item.visitTime.slice(0, -3) : ""}`,
          backgroundColor: this.getColorById(item.creatorId) || "#ccc",
          borderColor: "transparent",
          color: "#fff",
          textColor: "#fff",
          id: item.id,
          contactsName: item.contactsName,
          visitDate: item.visitDate,
          visitTime: item.visitTime,
          openLevel: item.openLevel,
          visitChannel: item.visitChannel,
          visitAddress: item.visitAddress,
          orgName: orgName,
          orgId: item.orgId,
          remark: item.remark,
          creatorName: item.creatorName,
          creatorId: item.creatorId,
          position: item.position
        };
      });
    },
    // 获取尽调筛选的对象
    getDueDiligenceGroup(data) {
      let personIdArr = [];
      let eventArr = data.filter(item => {
        if (!personIdArr.includes(item.creatorId)) {
          personIdArr.push(item.creatorId);
          return true;
        } else {
          return false;
        }
      });
      return eventArr.map(item => {
        return {
          value: item.creatorId,
          label: item.creatorName
        };
      });
    },
    // 切换尽调人
    duePersonChange(val) {
      // $(".due-dili-person-selector .ivu-select-selected-value .user-color-preview").remove();
      $(".due-dili-person-selector .ivu-select-selected-value").append(
        `<span class="user-color-preview" style="background-color: ${this.getColorById(
          val
        )};margin-top: 8px"></span>`
      );

      // this.duePerson = val;
      this.getCalendarData(this.calendar.fullCalendar("getDate"));
    },
    visitChannelChange(val) {
      this.visitChannel = val;
      // this.defaultDate = this.calendar.fullCalendar("getDate");
      this.getCalendarData(this.calendar.fullCalendar("getDate"));
    },
    // 是否显示周末
    showWeekendChange(val) {
      this.showWeekend = val;
      this.getCalendarData();
    },
    // 是否显示所有的尽调日程（默认显示今天以后的）
    showAllChange(val) {
      this.showAll = val;
      this.getCalendarData();
    },
    // 日期单元格render钩子  添加按钮
    dayCellRender(date, cell) {
      if (this.addDueDiligence) {
        let markup = `<div class="add-button">
            <span>+</span>
          </div>`;
        $(this.$el)
          .find(`.fc-day-top[data-date=${date.format("YYYY-MM-DD")}]`)
          .append(
            $(markup).mousedown(e => {
              e.preventDefault();
              e.stopPropagation();
              this.$refs.planModal.show("add", {
                date: date.format("YYYY-MM-DD"),
                time: "08:30"
              });
              return false;
            })
          );
      }
    },
    // ------------------------------------日期格子显示相关---------------------------------------------
    // 鼠标移到每个单元格，添加按钮的显示和隐藏
    setAddButtonDisplayAttr() {
      let date;
      $(this.$el)
        .find(".due-diligence-calendar-container .fc-bg td.fc-day")
        .on("mouseover", function() {
          date = $(this).attr("data-date");
          $(".due-diligence-calendar-container")
            .find(`.fc-day-top[data-date=${date}]`)
            .find(".add-button")
            .css({
              display: "block"
            });
        })
        .on("mouseout", function() {
          $(".due-diligence-calendar-container")
            .find(`.fc-day-top[data-date=${date}]`)
            .find(".add-button")
            .css({
              display: "none"
            });
        });
      // 鼠标放在事件标签上，添加按钮的显示隐藏
      $(this.$el)
        .find(
          ".due-diligence-calendar-container .fc-content-skeleton tbody tr td"
        )
        .on("mouseover", function(e) {
          let index = $(this).index();
          $(this)
            .parent()
            .parent()
            .prev()
            .find(`td:eq(${index})`)
            .find(".add-button")
            .css({
              display: "block"
            });
        })
        .on("mouseout", function(e) {
          let index = $(this).index();
          $(this)
            .parent()
            .parent()
            .prev()
            .find(`td:eq(${index})`)
            .find(".add-button")
            .css({
              display: "none"
            });
        });
    },
    // event标签的render钩子
    eventRender(event, element, view) {
      if (["month", "listMonth"].includes(view.type)) {
        this.eventCount++;
      }
      let personName;
      let orgName = $(
        `<a href="javascript:void(0)" class="plan-org-name">${
          event.orgName
        }</a>`
      );
      // console.log(view)
      if (view.type === "listMonth") {
        personName = $(
          `<span class="plan-person">${event.contactsName}${
            event.position ? "(" + event.position + ")" : ""
          }</span>`
        );
        let visitAddress = $(
          `<span class="event-visit-address">${event.visitAddress || ""}</span>`
        );
        personName.appendTo($(element).find(".fc-list-item-title")).css({
          fontWeight: "bold"
        });
        visitAddress.appendTo($(element).find(".fc-list-item-title")).css({
          display: "block"
        });
        orgName.insertAfter($(element).find("a")).on("click", e => {
          this.$refs.companyPlanListModal.show(event.orgId);
          e.stopPropagation();
          return false;
        });
      } else {
        // orgName.insertAfter($(element).find(".fc-title"));
        personName = $(
          `<span class="plan-person">${event.contactsName}</span>`
        );
        $(element)
          .find(".fc-title")
          .text(
            $(element)
              .find(".fc-title")
              .text() + ` ${event.orgName}`
          );
        personName.appendTo($(element).find(".fc-content"));
      }
      // 绑定删除按钮---------------------------------删除相关----------------------------------
      if (
        (this.userInfo.id == event.creatorId && this.delDueDiligence) ||
        this.editAdmin
      ) {
        let delButton = $(`<span class="delete-event-button">+</span>`);
        let _this = this;
        delButton.appendTo($(element).find(".fc-content")).on("click", e => {
          this.$Modal.confirm({
            title: "删除尽调计划",
            content: "<p>确定删除该条尽调计划吗</p>",
            onOk: () => {
              this.$http.del(`Schedule`, event.id).then(res => {
                if (res.code == 20000) {
                  this.$Message.success("删除尽调成功");
                  this.getCalendarData();
                } else {
                  this.$Message.error(res.msg);
                }
              });
            },
            onCancel: () => {}
          });
          e.stopPropagation();
        });
      }
    },
    // ----------------------------------------------修改和详情相关-----------------------------------------------
    // 点击日期event的回调
    getDueDiligenceDetail(data) {
      console.log(data);
      if (
        (this.userInfo.id == data.creatorId && this.editDueDiligence) ||
        this.editAdmin
      ) {
        this.$refs.planModal.show(
          "edit",
          { visitor: data.creatorName },
          data.id
        );
      }
    },
    // 鼠标hover 隐藏显示
    showEventDetail(data, e, element) {
      e.stopPropagation();
      e.preventDefault();
      this.event = data;
      let tooltip = $(this.$refs.eventToolTip);
      tooltip.css({
        display: "block",
        visibility: "hidden",
        left: e.pageX - e.offsetX
      });
      // 先隐藏tooltip，设置一个延时，让浏览器有计算tooltip高度的时间，然后再显示tooltip
      setTimeout(() => {
        tooltip.css({
          top: e.pageY - e.offsetY - tooltip.height() - 24,
          visibility: "visible"
        });
      }, 100);
    },
    hideEventDetail(data, e, element) {
      $(this.$refs.eventToolTip).css({ display: "none" });
    },
    // 解决同一时间点有多个任务的重叠情况
    setOverlayView() {
      let eventTargets = $(".fc-event-container > a.fc-time-grid-event");
      eventTargets.each(function(index, el) {
        if ($(this).next()) {
          // 如果后面的那个任务在半小时内，就设置前面这个任务的right值；否则是半小时外，这个任务的right设置为0即可
          let thisTime = $(this)
            .find(".fc-time")
            .attr("data-full")
            ? new Date(
                `2018-01-01 ${$(this)
                  .find(".fc-time")
                  .attr("data-full")
                  .slice(0, 5)}`
              ).getTime()
            : "";
          let nextTime = $(this)
            .next()
            .find(".fc-time")
            .attr("data-full")
            ? new Date(
                `2018-01-01 ${$(this)
                  .next()
                  .find(".fc-time")
                  .attr("data-full")
                  .slice(0, 5)}`
              ).getTime()
            : "";
          if (thisTime && nextTime && thisTime + 1000 * 60 * 30 > nextTime) {
            $(this).css({
              right:
                $(this)
                  .parent()
                  .width() -
                parseFloat(
                  $(this)
                    .next()
                    .css("left")
                ),
              marginRight: 0
            });
          } else {
            $(this).css({
              right: 0,
              marginRight: 0
            });
          }
        }
      });
    },
    // 窗口大小变动时，重新设置重叠情况的样式
    windowResize(view) {
      if (["agendaWeek", "agendaDay"].includes(this.defaultView)) {
        this.setOverlayView();
      }
    },
    // --------------------------------------------工具函数--------------------------------------
    // 根据用户id生成对应的拜访日程的背景颜色
    getColorById(id) {
      let longId = "1000000".slice(0, -("" + id).length) + id;
      let colorArr = [];
      let item;
      for (let i = 1; i < 4; i++) {
        item = Math.log(+longId).toFixed(10 + i);
        item = +item.toString().slice(-7);
        item = Math.abs(item % 255);
        colorArr.push(item);
      }
      return `rgba(${colorArr[0]},${colorArr[1]},${colorArr[2]})`;
    },
    // 根据部门数组拼接部门
    getOrgName(bread = []) {
      let orgNameArr = bread.map(item => {
        return item.title;
      });
      return orgNameArr.join(" ");
    }
  },
  mounted() {
    this.defaultDate = moment(new Date());
    // this.getCalendar();
    this.addDueDiligence = this.userInfo.auth.functional.includes(
      "addDueDiligence"
    );
    this.editDueDiligence = this.userInfo.auth.functional.includes(
      "editDueDiligence"
    );
    this.delDueDiligence = this.userInfo.auth.functional.includes(
      "delDueDiligence"
    );
    this.editAdmin = this.userInfo.auth.functional.includes(
      "dueDiligenceAdmin"
    );
    // 不是在首页的折叠面板的话，就自动请求加载数据；首页会在打开折叠面板的时候加载数据。
    if (this.$parent.name !== "dueDiligence") {
      this.getCalendarData();
    }
  }
};
</script>
<style lang="less" rel="styleSheet/less">
.due-diligence-plan {
  position: relative;
  min-height: 300px;
  // padding-top: 40px;
  height: 100%;
  #dueDiligenceCalendar {
    height: 100%;
  }
  .fc-view-container {
    // max-height: 600px;
    height: calc(~"100% - 45px");
    overflow-y: auto;
  }
  .fc-toolbar .fc-state-active {
    z-index: 0;
  }
  .due-diligence-calendar-container {
    .fc-row.fc-week.fc-widget-content {
      // 每个单元格的上半部分--日期和按钮
      .fc-content-skeleton {
        .fc-day-top {
          position: relative;
          // 日期样式
          .fc-day-number {
            font-size: 24px;
            color: #2d8cf0;
            float: left !important;
          }
          // 按钮样式
          .add-button {
            width: 20px;
            height: 20px;
            text-align: center;
            line-height: 20px;
            background-color: #ccc;
            color: #666;
            font-size: 24px;
            border-radius: 50%;
            position: absolute;
            top: 1px;
            right: 1px;
            display: none;
            &:hover {
              color: #d02109;
              cursor: pointer;
            }
          }
          &:hover {
            .add-button {
              display: block !important;
            }
          }
        }
      }
    }
    // 每个单元格下半部分---事件
    .fc-event-container {
      position: relative;
      a.fc-time-grid-event {
        height: 18px;
      }
      .fc-content {
        position: relative;
        display: flex;
        padding-right: 12px;
        line-height: 18px;
        font-size: 12px;
        .fc-time {
          display: none;
        }
        .fc-title {
          max-width: calc(~"100% - 36px");
          padding-right: 3px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .plan-person {
          width: 3em;
        }
        .delete-event-button {
          transform: rotate(45deg);
          position: absolute;
          right: 0;
          top: -6px;
          font-size: 20px;
          color: #666;
          font-weight: 100;
          line-height: 30px;
        }
      }
    }
    .fc-scroller.fc-day-grid-container {
      height: auto !important;
    }
  }
  .due-dili-person-selector {
    // position: absolute;
    // top: 2px;
    // left: 200px;
    // z-index: 100;
    margin-right: 10px;
    .ivu-select-item-selected {
      background-color: #fff;
      color: #495060;
    }
    .user-color-preview {
      // display: inline-block;
      vertical-align: -2px;
      width: 80px;
      height: 14px;
      margin-left: 5px;
      float: right;
    }
  }
  .due-dili-options-container {
    position: relative;
    margin-bottom: 10px;
    display: flex;
    .due-dili-person {
      display: flex;
      width: calc(~"100% - 100px");
      & > span {
        width: 60px;
        line-height: 33px;
      }
      .due-dili-person-selector {
        width: auto;
        min-width: 180px;
      }
    }
    .due-dili-type {
      position: absolute;
      left: 300px;
      display: flex;
      & > span {
        // display: inline;
        width: 54px;
        // vertical-align: middle;
        line-height: 30px;
      }
    }
    //modified by yangqi start v1.15
    .due-btn {
      position: absolute;
      left: 850px;
      display: flex;
    }
    .due-company-name {
      position: absolute;
      left: 580px;
      display: flex;
      & > span {
        // display: inline;
        width: 70px;
        // vertical-align: middle;
        line-height: 30px;
      }
    }
    //modified by yangqi end v1.15
    .show-weekend {
      position: absolute;
      top: 46px;
      right: 136px;
    }
    .show-all {
      // position: absolute;
      // top: 46px;
      // right: 227px;
    }
  }
  // 列表视图样式
  .fc-list-table {
    .fc-list-item-time.fc-widget-content {
      display: none;
    }
    .fc-list-item-marker.fc-widget-content {
      // line-height: 35px;
      position: relative;
      span.fc-event-dot {
        position: absolute;
        top: 50%;
        left: 10px;
        transform: translate(0, -50%);
      }
    }
    .plan-org-name {
      margin: 0 5px;
      color: #2992ff;
    }
  }
  // tooltip 样式
  .event-detail-tooltip {
    position: fixed;
    display: none;
    border: 1px solid #ccc;
    background-color: #666;
    color: #fff;
    opacity: 1;
    z-index: 10000;
    width: auto;
    max-width: 350px;
    padding: 5px 10px;
    line-height: 1.5;
    word-break: break-all;
    cursor: text;
    user-select: text;
    .detail-row {
      line-height: 1.5;
      user-select: text;
    }
    .arrow {
      width: 0;
      height: 0;
      border: 10px solid #666;
      position: absolute;
      bottom: -20px;
      border-left-color: transparent;
      border-right-color: transparent;
      border-bottom-color: transparent;
    }
    &:hover {
      display: block !important;
    }
    &.arrow-right-side {
      .arrow {
        right: 10px;
      }
    }
  }
}
</style>
