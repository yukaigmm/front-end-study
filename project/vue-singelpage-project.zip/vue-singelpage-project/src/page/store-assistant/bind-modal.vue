<template>
  <Modal title="绑定官网账号" :mask-closable="false" v-model="modal" width="350">
    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button @click="cancel">取消</Button>
      <Button type="primary" :loading="buttonLoading" @click="ok">提交</Button>
    </div>
    <h3>需要先绑定官网账号，才能使用小助手功能</h3>
    <Form :model="formData" ref="form" :rules="validateRules" :label-width="110">
      <form-item label="排排网官网账号" prop="account">
        <i-input v-model.trim="formData.account" placeholder="请输入官网账号"/>
      </form-item>

      <form-item label="排排网官网密码" prop="password">
        <i-input v-model.trim="formData.password" type="password" placeholder="请输入官网密码"/>
      </form-item>
    </Form>
  </Modal>
</template>

<script>
export default {
  data() {
    return {
      formData: {},
      validateRules: {
        account: {
          required: true,
          message: "账号不能为空"
        },
        password: {
          required: true,
          message: "密码不能为空"
        }
      },
      modal: false,
      buttonLoading: false
    };
  },

  methods: {
    show() {
      this.modal = true;
    },

    cancel() {
      this.clear();
      this.$Message.warning("取消绑定，将无法使用小助手功能！");
    },

    clear() {
      this.modal = false;
      this.formData = {};
      this.$refs.form.resetFields();
    },

    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.submit();
        } else {
          this.$Message.warning("请按红色文字提示填写内容！");
        }
      });
    },

    submit() {
      this.buttonLoading = true;
      this.$http
        .post("LittleHelper/BingDingLeLittleHelper", this.formData)
        .then(res => {
          this.buttonLoading = false;
          if (res.code === 20000) {
            this.$Message.success("绑定成功！");
            this.clear();
            this.$emit("bindSuccessfully");
          } else {
            this.$Message.error(`绑定失败：${res.msg}`);
          }
        })
        .catch(err => {
          this.$Message.error("绑定失败：网络请求失败！");
          this.buttonLoading = false;
        });
    }
  }
};
</script>


<style lang="less" scoped>
</style>
