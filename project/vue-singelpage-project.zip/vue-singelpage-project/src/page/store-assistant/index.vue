<template>
  <div>
    <div id="chat" v-show="showChat" style="position:fixed;bottom:10px;right:0;z-index:99999999;"></div>

    <div
      class="chat-icon"
      v-show="!showChat"
      :style="style"
      @mousedown="onMouseDown"
      @dblclick="showChatComp"
      title="按住拖动，双击打开小助手"
    >
      <Badge :count="msgCount">
        <Icon type="chatbox-working"></Icon>
      </Badge>
    </div>

    <bind-modal ref="bindModal" @bindSuccessfully="bindSuccessfully"/>
  </div>
</template>

<script>
window.chatComp = null;
import { mapGetters } from "vuex";
import BindModal from "./bind-modal.vue";
import { log } from "fullcalendar";
export default {
  data() {
    return {
      msgCount: 0,
      style: {
        position: "fixed",
        bottom: "10px",
        right: 0,
        "z-index": 9999999999999
      }
    };
  },

  components: {
    BindModal
  },

  computed: {
    ...mapGetters({
      user: "getUser",
      showChat: "getIfAssistantOpen"
    })
  },

  mounted() {
    this.bindSuccessfully();
  },

  methods: {
    onMouseDown(e) {
      // 处于缩小状态可以拖动
      // if (!this.showChat) {
      this.onMouseMove();
      this.onMouseUp();
      // }
    },

    onMouseMove() {
      document.onmousemove = e => {
        let x = e.clientX;
        let y = e.clientY;
        this.style = {
          position: "fixed",
          top: y - 20 + "px",
          left: x - 20 + "px",
          "z-index": 9999999999999
        };
      };
    },

    onMouseUp() {
      document.onmouseup = e => {
        let x = e.clientX;
        let y = e.clientY;
        this.style = {
          position: "fixed",
          top: y - 20 + "px",
          left: x - 20 + "px",
          "z-index": 9999999999999
        };

        document.onmousemove = null;
        document.onmouseup = null;
      };
    },

    showChatComp() {
      this.$store.dispatch("setIfAssistantOpen", {
        ifAssistantOpen: true
      });

    },

    bindSuccessfully() {
      this.loginAssisant()
        .then(res => {
          if (res === "ok") {
            this.initPPWChat();
          } else {
            this.judgeIfBinded()
              .then(resp => {
                if (resp === "ok") {
                  this.initPPWChat();
                } else {
                  this.showBindModal();
                }
              })
              .catch(err => {
                this.$Message.error(
                  "获取小助手绑定信息失败，请刷新页面后重试！"
                );
              });
          }
        })
        .catch(err => {
          this.$Message.error("登陆小助手失败，请刷新页面后重试！");
        });
    },

    initPPWChat() {
      let env = process.env.NODE_ENV;
      let _this = this;
      var logined = false;
      var container = document.getElementById("chat");
      window["ppw-chat"].bindTo(
        container,
        function(vueInst) {
          vueInst.$on("statechange", function(state, data) {
            if ("login" == state) {
              //组件触发登录成功事件，在这之后才可以调用vueInst的方法
              logined = true;
            }
            if ("minimize" == state) {
              let el = document.getElementById("chat");
              //组件触发最小化的事件，此处调用者自行处理组件是否隐藏
              _this.$store.dispatch("setIfAssistantOpen", {
                ifAssistantOpen: false
              });
            }
            if ("unread" == state) {
              //组件触发登录用户的未读消息数更新，data为Number类型的数值
              _this.msgCount = data;
              document.getElementById("unread-count").innerHTML = data;
            }
          });
          //vueInst是vue组件的实例，调用者需要保存它的一个引用，以方便调用实例的方法
          window.chatComp = vueInst;
        },
        {
          system: "crm",
          getEnv: () => {
            // let chatEnv = env === "production" ? "" : "test";
            let chatEnv = "test";
            switch (env) {
              case "pre":
                chatEnv = "pre";
                break;
              case "production":
                chatEnv = "";
                break;
              case "development":
              case "test":
                chatEnv = "test";
                break;
            }
            return chatEnv;
          }
        }
      );
    },

    judgeIfBinded() {
      return new Promise((resolve, reject) => {
        this.$http
          .get("LittleHelper/getLittleHelperList", { user_id: 105665 })
          .then(res => {
            if (res.code === 20000) {
              if (res.data.records.length) {
                resolve("ok");
              } else {
                resolve("notBinded");
              }
            } else {
              reject("error");
            }
          })
          .catch(err => {
            console.error(err);
            reject("error");
          });
      });
    },

    showBindModal() {
      this.$refs.bindModal.show();
    },

    loginAssisant() {
      return new Promise((resolve, reject) => {
        this.$http
          .post("LittleHelper/LoginLittleHelper")
          .then(res => {
            if (res.code === 20000) {
              resolve("ok");
            } else {
              resolve(res.msg);
            }
          })
          .catch(err => {
            reject("err");
          });
      });
    }
  }
};
</script>

<style lang="less" scoped>
.chat-icon {
  color: #ffffff;
  position: fixed;
  bottom: 0px;
  right: 15px;
  line-height: 40px;
  text-align: center;
  font-size: 24px;
  cursor: pointer;
  z-index: 9999999999999;
  height: 40px;
  width: 40px;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.8);
}
</style>
