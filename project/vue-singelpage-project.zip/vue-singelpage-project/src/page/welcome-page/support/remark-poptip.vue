<template>
   <Poptip 
     placement="top-end"
     trigger="click"
     transfer
     width="400"
     @on-popper-show="onPopperShow"
     @on-popper-hide="onPopperHide"
   >
     <span class="reamrk-wrap" title="点击查看历史备注">{{remark||"--"}}</span>
     <span slot="title" class="title-wrap">历史备注</span>

     <div v-loading="remarkLoading" class="remark-container" element-loading-text="拼命加载中" slot="content">
         <p v-for="(item,index) in records" 
            :key="index"
         >
            <span >[{{item.createtime}}]:&nbsp;&nbsp;<span style="font-weight:900">{{item.matterRemark}}</span></span>
         </p>
     </div>
   </Poptip> 
</template>

<script>
export default {
  name: "remarkPoptip",
  props: ["matterId", "remark"],
  data() {
    return {
      records: [],
      remarkLoading: false
    };
  },

  methods: {
    onPopperShow() {
      this.remarkLoading = true;
      try {
        this.$http
          .get(`waitingMatter/remark/${this.matterId}`, {
            pageSize: -1
          })
          .then(res => {
            this.remarkLoading = false;
            if (res.code === 20000) {
              this.records = res.data.records;
            } else {
              this.$Message.error(`获取备注失败：${res.msg}`);
            }
          });
      } catch (e) {
        this.remarkLoading = false;
        this.$Message.error(`获取备注失败`);
      }
    },
    onPopperHide() {
      this.records = [];
    }
  }
};
</script>

<style lang="less" scoped>
.reamrk-wrap {
  color: #0c7beb;
  cursor: pointer;
  display: inline-block;
  max-width: 220px;
  max-height: 40px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  height: 20px;
}
.title-wrap {
  font-size: 14px;
  font-weight: 900;
}
.remark-container {
  height: 100px;

  p {
    max-width: 360px;
    margin-bottom: 5px;
    word-wrap: break-word;
    word-break: break-all;
    overflow: hidden;
    white-space: pre-wrap;
    border-bottom: 1px dashed #ccc;
  }
}
</style>


