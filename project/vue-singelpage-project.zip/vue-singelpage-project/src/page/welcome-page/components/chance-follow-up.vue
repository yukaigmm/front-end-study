<template>
  <div class="chance-wrapper">
    <search-area :showExpand="false" v-if="!isIndex" @onKeydownSearch="search">
      <div slot="default">
        <Row>
          <Col span="8">
            <FormItem label="机会主题">
              <Input v-model="formData.topic" placeholder="请输入机会主题"/>
            </FormItem>
          </Col>

          <Col span="8">
            <FormItem label="业务负责人">
              <Row>
                <Col span="12">
                  <Select
                    v-model="dept"
                    @on-change="onDeptChange"
                    placeholder="请选择部门"
                    clearable
                    transfer
                  >
                    <Option
                      v-for="(item,index ) in deptOptions"
                      :key="index"
                      :value="item.value"
                    >{{item.label}}</Option>
                  </Select>
                </Col>
                <Col span="11" :offset="1">
                  <Select
                    v-model="formData.chanceManagerId"
                    placeholder="请选择负责人"
                    :disabled="!hasManger"
                    clearable
                    :loading="managerLoading"
                    loading-text="加载中..."
                    transfer
                  >
                    <Option
                      v-for="(item,index ) in managerOptions"
                      :key="index"
                      :value="item.value"
                    >{{item.label}}</Option>
                  </Select>
                </Col>
              </Row>
            </FormItem>
          </Col>

          <Col span="3" :offset="1">
            <Button type="primary" @click="search">搜索</Button>
            <Button @click="onReset">重置</Button>
          </Col>
        </Row>

        <Row>
          <Col span="8">
            <FormItem label="留言时间">
              <DatePicker
                type="daterange"
                placeholder="请选择留言起始时间"
                style="width:100%;"
                transfer
                v-model="formData.timeRange"
              ></DatePicker>
            </FormItem>
          </Col>

          <Col span="8">
            <FormItem label="跟进状态">
              <Select v-model="formData.matterStatus" clearable transfer>
                <Option
                  v-for="(item,index ) in matterStatusOptions"
                  :key="index"
                  :value="item.value"
                >{{item.label}}</Option>
              </Select>
            </FormItem>
          </Col>
        </Row>
      </div>
    </search-area>

    <div class="table-area">
      <Table
        v-loading="tableLoading"
        :data="tableData"
        :columns="columns"
        element-loading-text="拼命加载中"
        border
      />
    </div>

    <div class="page-load">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      />
    </div>

    <add-remark-modal ref="addRemarkModal" @refrenshTable="search"></add-remark-modal>
  </div>
</template>

<script>
import searchArea from "../../../components/search-area";
import { fetchWorkmate, getReciver } from "@/service/getData";
import { mapGetters } from "vuex";
import moment from "moment";
import addRemarkModal from "./add-remark-modal";

export default {
  components: {
    searchArea,
    addRemarkModal
  },

  props: {
    isIndex: {
      type: [Boolean],
      default: false
    }
  },

  data() {
    return {
      tagPic: require("../../../assets/sprite-chance.png"),
      total: 0,
      currentPage: 1,
      pageSize: 10,
      formData: {},
      dept: "",
      hasManger: false,
      deptOptions: [],
      managerOptions: [],
      managerLoading: false,
      tableLoading: false,
      tableData: [],
      remarkContent: ""
    };
  },

  computed: {
    ...mapGetters({
      userInfo: "getUser"
    }),
    matterStatusOptions() {
      return [
        {
          label: "未处理",
          value: 1
        },
        {
          label: "处理中",
          value: 2
        },
        {
          label: "已完成",
          value: 3
        }
      ];
    },
    columns() {
      return [
        {
          key: "topic",
          title: "机会主题",
          width: 300,
          fixed: "left",
          render: (h, { row }) => {
            //   mapping  -->  {
            //               1: "资金",
            //               2: "人才",
            //               3: "系统",
            //               4: "投研"
            // };
            let uniqStyle = {};
            switch (row.chanceType) {
              case 1:
                uniqStyle["background-position"] = "-32px 0";
                break;

              case 2:
                uniqStyle["background-position"] = "0 0";
                break;
              case 3:
                uniqStyle["background-position"] = "-64px 0";
                break;
              case 4:
                uniqStyle["background-position"] = "-96px 0";
                break;
              default:
                break;
            }
            let commonStyle = {
              display: "inline-block",
              width: "32px",
              height: "22px",
              "background-image": `url(${this.tagPic})`,
              "background-repeat": "no-repeat",
              ...uniqStyle
            };

            return h(
              "div",
              {
                style: {
                  display: "flex",
                  "justify-content": "flex-start",
                  "align-items": "flex-start"
                }
              },
              [
                h("span", {
                  style: {
                    ...commonStyle
                  }
                }),

                h(
                  "Tooltip",
                  {
                    props: {
                      placement: "top",
                      transfer: true
                    },
                    style: {
                      flex: 1
                    }
                  },

                  [
                    h("div", {
                      style: {
                        "max-width": "200px",
                        "white-space": "nowrap",
                        overflow: "hidden",
                        "text-overflow": "ellipsis",
                        "margin-left": "10px",
                        "max-height": "40px"
                      },
                      domProps: {
                        innerHTML: row.topic
                      }
                    }),
                    h("div", {
                      slot: "content",
                      style: {
                        "max-width": "500px",
                        "word-wrap": "break-word",
                        "word-break": "break-all",
                        overflow: "hidden",
                        "white-space": "pre-wrap"
                      },
                      domProps: {
                        innerHTML: row.topic
                      }
                    })
                  ]
                )
              ]
            );
          }
        },
        {
          key: "createtime",
          title: "发布时间",
          width: 90,
          render: (h, { row }) => {
            if (row.createtime) {
              return h("span", row.createtime.slice(0, 11));
            } else {
              return h("span", "--");
            }
          }
        },
        {
          key: "chanceManagerName",
          title: "业务负责人",
          width: 80,
          render: (h, { row }) => {
            return h("span", row.chanceManagerName || "--");
          }
        },
        {
          key: "msgContent",
          title: "留言内容",
          width: 200,
          render: (h, { row }) => {
            if (row.msgContent) {
              return h(
                "Tooltip",
                {
                  props: {
                    placement: "top",
                    content: `${row.msgContent}`,
                    transfer: true
                  }
                },
                [
                  h(
                    "span",
                    {
                      style: {
                        display: "inline-block",
                        "max-width": "160px",
                        "white-space": "nowrap",
                        overflow: "hidden",
                        "text-overflow": "ellipsis"
                      }
                    },
                    row.msgContent
                  ),
                  h(
                    "div",
                    {
                      slot: "content",
                      style: {
                        "max-width": "400px",
                        height: "auto",
                        "word-wrap": "break-word",
                        "word-break": "break-all",
                        overflow: "hidden",
                        "white-space": "pre-wrap"
                      }
                    },
                    `${row.msgContent}`
                  )
                ]
              );
            } else {
              return h("span", "--");
            }
          }
        },
        {
          key: "msgCompanyName",
          title: "留言机构",
          width: 280,
          render(h, { row }) {
            if (row.bread && row.bread.length) {
              let titles = row.bread.map(item => item.title);
              let titleStr = titles.length ? titles.join(" > ") : "";
              return h(
                "div",
                {
                  attrs: {
                    title: titleStr
                  },
                  style: {
                    "max-width": "270px",
                    "text-overflow": "ellipsis",
                    overflow: "hidden",
                    "white-space": "nowrap"
                  }
                },
                titleStr
              );
            } else {
              return h("span", "--");
            }
          }
        },
        {
          key: "msgUserName",
          title: "留言用户",
          width: 80,
          render(h, { row }) {
            return h("span", row.msgUserName || "--");
          }
        },
        {
          key: "msgMobile",
          title: "联系电话",
          width: 100,
          render(h, { row }) {
            return h("span", row.msgMobile || "--");
          }
        },
        {
          key: "msgCreateTime",
          title: "留言时间",
          width: 90,
          render(h, { row }) {
            return h(
              "span",
              row.msgCreateTime ? row.msgCreateTime.slice(0, 11) : "--"
            );
          }
        },
        {
          key: "matterRemark",
          title: "处理备注",
          width: 300,
          render: (h, { row }) => {
            if (row.matterRemark) {
              // return h(
              //   "Tooltip",
              //   {
              //     props: {
              //       placement: "top",
              //       transfer: true
              //     }
              //   },
              //   [
              //     h(
              //       "span",
              //       {
              //         style: {
              //           "max-width": "250px",
              //           "white-space": "nowrap",
              //           overflow: "hidden",
              //           "text-overflow": "ellipsis"
              //         }
              //       },
              //       row.matterRemark
              //     ),
              //     h(
              //       "div",
              //       {
              //         slot: "content",
              //         style: {
              //           "max-width": "400px",
              //           height: "auto",
              //           "word-wrap": "break-word",
              //           "word-break": "break-all",
              //           overflow: "hidden"
              //         }
              //       },
              //       `${row.matterRemark}`
              //     )
              //   ]
              // );
              return h("remarkPoptip", {
                props: {
                  matterId: row.matterId,
                  remark: row.matterRemark
                }
              });
            } else {
              return h("span", "--");
            }
          }
        },
        {
          key: "matterStatus",
          title: "跟进状态",
          width: 90,
          render: (h, { row }) => {
            let statusMap = this.matterStatusOptions.filter(
              item => row.matterStatus == item.value
            );
            let text = statusMap.length ? statusMap[0]["label"] : "--";
            return h("span", text);
          }
        },
        {
          key: "action",
          title: "操作",
          fixed: "right",
          width: 150,
          render: (h, { row }) => {
            let isSelf = this.userInfo.id == row.chanceManagerId;
            let actionArr = [
              h(
                "span",
                {
                  class: isSelf ? "deleteBtn" : "disabledBtn",
                  on: {
                    click: () => {
                      if (!isSelf) {
                        return;
                      }
                      this.addRemark(row.matterId, row.matterStatus);
                    }
                  }
                },
                "填写备注"
              )
            ];
            if (row.matterStatus == 1) {
              actionArr.unshift(
                h(
                  "span",
                  {
                    class: isSelf ? "deleteBtn" : "disabledBtn",
                    on: {
                      click: () => {
                        if (!isSelf) {
                          return;
                        }
                        this.startDeal(row.matterId);
                      }
                    }
                  },
                  "开始处理"
                )
              );
            }

            if (row.matterStatus == 2) {
              actionArr.unshift(
                h(
                  "span",
                  {
                    class: isSelf ? "deleteBtn" : "disabledBtn",
                    on: {
                      click: () => {
                        if (!isSelf) {
                          return;
                        }
                        this.finishDeal(row.matterId);
                      }
                    }
                  },
                  "完成"
                )
              );
            }

            return h(
              "div",
              {
                style: {
                  display: "flex",
                  "justify-content": "space-between",
                  "align-items": "center"
                }
              },
              actionArr
            );
          }
        }
      ];
    }
  },

  created() {
    if (this.isIndex) {
      let deptId = this.userInfo.dept_id;
      let personId = this.userInfo.id;
      this.getDeptOptions().then(() => {
        this.onDeptChange(deptId);
        this.$set(this.formData, "chanceManagerId", personId);
      });
      this.dept = deptId;
      this.$set(this.formData, "chanceManagerId", personId);
    } else {
      this.getDeptOptions();
    }
    this.getChancesList();
  },

  methods: {
    search() {
      this.pageSize = 10;
      this.currentPage = 1;
      this.getChancesList();
    },

    onReset() {
      this.formData = {};
      this.dept = "";
      this.search();
    },

    getChancesList() {
      let form = {
        ...this.formData
      };

      if (form.timeRange && form.timeRange.length) {
        form.timeRange = form.timeRange
          .map(item => {
            if (item) {
              return moment(item).format("YYYY-MM-DD");
            } else {
              return "";
            }
          })
          .filter(item => item);
      }
      let params = {
        pageNo: this.currentPage,
        pageSize: this.pageSize,
        ...form
      };
      try {
        this.tableLoading = true;
        this.$http.get("waitingMatter/chance", params).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
          } else {
            this.$Message.error(`获取机会列表失败:${res.msg}`);
          }
        });
      } catch (e) {
        console.error(e);
        this.$Message.error(`获取机会列表失败`);
      }
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getChancesList();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getChancesList();
    },

    onDeptChange(val) {
      this.managerOptions = [];
      this.$set(this.formData, "chanceManagerId", "");
      if (!val) {
        this.hasManger = false;
        return;
      }

      let params = {
        dept_id: val,
        type: 1
      };
      this.hasManger = true;
      this.getManagerOptions(params);
    },

    getDeptOptions() {
      return new Promise((resolve, reject) => {
        fetchWorkmate().then(res => {
          resolve();
          if (res.code === 20000) {
            this.deptOptions = res.data;
          } else {
            this.$Message.error("获取部门失败！");
          }
        });
      });
    },

    getManagerOptions(params) {
      this.managerLoading = true;
      getReciver(params).then(res => {
        this.managerLoading = false;
        if (res.code == 20000) {
          this.managerOptions = res.data;
        }
      });
    },

    addRemark(matterId, matterStatus) {
      this.$refs.addRemarkModal.show(matterId, matterStatus);
    },

    startDeal(matterId) {
      let params = {
        matterStatus: "2"
      };
      this.dealChance(params, matterId);
    },

    finishDeal(matterId) {
      let params = {
        matterStatus: "3"
      };
      this.dealChance(params, matterId);
    },

    dealChance(params, matterId) {
      this.$Message.loading("处理中...");
      try {
        this.$http
          .post(`waitingMatter/handle/${matterId}`, params)
          .then(res => {
            this.$Message.destroy();
            if (res.code === 20000) {
              this.$Message.success("处理成功！");
              this.search();
            } else {
              this.$Message.error(`处理失败：${res.msg}`);
            }
          });
      } catch (e) {
        console.error(e);
        this.$Message.destroy();
        this.$Message.error("处理失败！");
      }
    }
  }
};
</script>

<style lang="less" scoped>
.page-load {
  text-align: right;
  padding: 15px;
}

.chance-wrapper {
  height: 100%;
  overflow-y: hidden;
}
</style>


