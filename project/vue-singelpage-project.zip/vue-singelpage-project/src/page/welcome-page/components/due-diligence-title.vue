<template>
    <span>尽调计划</span>
</template>


<script>
export default {
    data(){
        return {

        }
    }
}
</script>

<style lang="less" scoped>
</style>

