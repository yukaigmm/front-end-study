<template>
    <span>直营店即将到期账号</span>
</template>


<script>
export default {
    
}
</script>

<style>
    
</style>