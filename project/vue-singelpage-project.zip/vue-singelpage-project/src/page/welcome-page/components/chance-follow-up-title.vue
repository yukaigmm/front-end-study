<template>
    <span>机会跟进(<span class="info-wrap" >{{info}}</span>)</span>
</template>


<script>
export default {
    props:["info"],
    data(){
        return {

        }
    }
}
</script>

<style lang="less" scoped>
   .info-wrap{
       font-weight: 900;
       color: red;
   }
</style>

