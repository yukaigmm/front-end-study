<template>
 <Modal
  v-model="modal"
  title="填写备注"
  width="500"
  :mask-closable="false"
 >
      <div slot="footer">
          <Button @click="onCancel">取消</Button>
          <Button @click="onOk" type="primary" :loading="btnLoading">确定</Button>
      </div>

      <div slot="close" @click="onCancel">
          <Icon type="ios-close-empty"></Icon>
      </div>

      <Form
         ref="form"
         :model="formData"
         :label-width="0"
         :rules="validateRules"
      >
         <FormItem
            prop="remarkContent"
         >
            <Input 
              v-model="formData.remarkContent"
              type="textarea"
              :autosize="{minRows: 4,maxRows: 8}"
              placeholder="请填写备注(最多一百字)"
               />
         </FormItem>
      </Form>
 </Modal>
</template>

<script>
export default {
  data() {
    return {
      modal: false,
      btnLoading: false,
      formData: {
        remarkContent: ""
      },
      matterId: "",
      matterStatus: "",
      validateRules: {
        remarkContent: [
          { required: true, message: "备注不能为空" },
          { type: "string", max: 100, message: "字数不能超过一百个字！" }
        ]
      }
    };
  },

  methods: {
    show(matterId, matterStatus) {
      this.modal = true;
      this.matterId = matterId;
      this.matterStatus = matterStatus;
    },

    onOk() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.addRemark();
        } else {
          this.$Message.warning("请按红色字段填写内容！");
        }
      });
    },

    addRemark() {
      let params = {
        matterStatus: this.matterStatus,
        matterRemark: this.formData.remarkContent
      };

      try {
        this.btnLoading = true;
        this.$http
          .post(`waitingMatter/handle/${this.matterId}`, params)
          .then(res => {
            this.btnLoading = false;
            if (res.code === 20000) {
              this.$Message.success("添加备注成功！");
              this.$emit("refrenshTable");
              this.onCancel();
            } else {
              this.$Message.error(`添加备注失败:${res.msg}`);
            }
          });
      } catch (e) {
        this.btnLoading = false;
        console.error(e);
        this.$Message.error(`添加备注失败`);
      }
    },

    onCancel() {
      this.modal = false;
      this.reset();
    },

    reset() {
      this.formData = {
        remarkContent: ""
      };
      this.matterId = "";
      this.$refs.form.resetFields();
    }
  }
};
</script>

