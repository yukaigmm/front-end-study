<template>
  <div>
    <!-- <p class="welcome">欢迎使用 ONESYSTEM-CRM!</p> -->
    <Collapse v-model="activePanel" accordion @on-change="onCollapseChange">
      <Panel v-for="(item,index ) in panels" :key="index" :name="item.name">
        <component :is="item.titleComponent" :info="panelsInfo[item.name]"></component>
        <div slot="content">
          <component :is="item.component" :isIndex="true" :ref="item.name"></component>
        </div>
      </Panel>
    </Collapse>
  </div>
</template>
<script>
import $ from "jquery";
import _ from "lodash";
import chanceFollowUp from "./components/chance-follow-up";
import chanceFollowUpTitle from "./components/chance-follow-up-title";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import dueDiligence from "@/page/due-diligence/index.vue";
import dueDiligenceTitle from "./components/due-diligence-title.vue";
import expireAccount from "../expired-account/index.vue";
import expireAccountTitle from "./components/expireAccountTitle.vue";
export default {
  mixins: [getMinusNumber],
  components: {
    chanceFollowUp,
    chanceFollowUpTitle,
    dueDiligence,
    dueDiligenceTitle,
    expireAccount,
    expireAccountTitle
  },

  data() {
    return {
      panels: [
        {
          titleComponent: "chance-follow-up-title",
          component: "chance-follow-up",
          name: "chance"
        },
        {
          titleComponent: "due-diligence-title",
          component: "due-diligence",
          name: "dueDiligence"
        },
        {
          titleComponent: "expireAccountTitle",
          component: "expireAccount",
          name: "expireAccount"
        }
      ],
      activePanel: "",
      panelsInfo: {},
      ifGetDueDiligenceData: true
    };
  },
  mounted() {
    this.setHeightOfModal();
    this.getToDosInfo();
    this.setPanelHeight();
    this.setMaxHeightOfTable();
    this.setOpenPanel();
  },
  methods: {
    setOpenPanel() {
      let windowParams = JSON.parse(JSON.stringify(window.location));
      let queryString = windowParams.search.slice(1);
      let queryStringArr = queryString.split("&");
      let params = {};
      queryStringArr
        .filter(item => {
          return item.indexOf("=") !== -1;
        })
        .forEach(item => {
          let [key, value] = item.split("=");
          params[key] = value;
        });
      if (params.from == "email") {
        this.activePanel = "expireAccount";
      } else {
        this.activePanel = "chance";
      }
    },

    onCollapseChange(key) {
      this.$nextTick(() => {
        this.setMaxHeightOfTable();
      });
      if (key[0] == "dueDiligence") {
        this.getDueDiligence();
      }
    },

    // 设置模态框的最大高度
    setHeightOfModal() {
      let bodyHeight = $("body").height();
      let modalHeight = bodyHeight * 0.6;
      $("body")
        .find(".ivu-modal-body")
        .css("max-height", modalHeight);

      // 窗体变化时，模态框的大小跟着变化
      window.onresize = _.debounce(() => {
        let bodyHeight = $("body").height();
        let modalHeight = bodyHeight * 0.6;
        $("body")
          .find(".ivu-modal-body")
          .css("max-height", modalHeight);
      }, 3);
    },

    //  设置每个panel的最大高度
    setPanelHeight() {
      let wholeHeight = $(".content-body.ivu-col").height();
      let targetWrap = $(this.$el).find(".ivu-collapse");

      targetWrap.css("maxHeight", wholeHeight - 80 + "px");
      targetWrap.css("overflow", "auto");

      let singlePanel = targetWrap.find(".ivu-collapse-item");

      singlePanel.css("maxHeight", wholeHeight - 100 + "px");
    },

    //  设置表格的最大高度
    setMaxHeightOfTable() {
      let wrapperHeight = $(this.$el)
        .find(".ivu-collapse")
        .css("maxHeight");
      let targetTable = $(this.$el).find(".table-area");
      let maxHeight = wrapperHeight.slice(0, -2) - 180;
      let minusNumber = this.getMinusNumberOfFixedTable();
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    // 获取待办事项的相关信息
    getToDosInfo() {
      try {
        this.$http.get("waitingMatter/info").then(res => {
          if (res.code === 20000) {
            this.panelsInfo = res.data;
          } else {
            this.$Message.error("获取信息失败！");
          }
        });
      } catch (e) {
        console.error(e);
        this.$Message.error("获取信息失败！");
      }
    },

    // 获取尽调计划的相关信息
    getDueDiligence() {
      if (this.ifGetDueDiligenceData) {
        this.$refs.dueDiligence[0].getCalendarData();
        this.ifGetDueDiligenceData = false;
      }
    }
  }
};
</script>
<style lang="less">
.welcome {
  margin-top: 150px;
  text-align: center;
  font-size: 40px;
  font-weight: 900;
  text-shadow: 8px 10px 5px grey;
  color: #3ab2ff;
}
</style>
