<template>
  <div>
    <div v-loading="loading" loading-element-text="拼命加载中">
      <Form :model="configData" :label-width="150" ref="form" :rules="validateRules">
        <Row>
          <i-col span="11">
            <form-item label="公司套餐类型" prop="versionType">
              <i-select
                v-model="configData.versionType"
                :title="tipsTitle"
                :disabled="ifDisabled"
                placeholder="请选择套餐类型"
                @on-change="onVersionChange"
                clearable
              >
                <i-option
                  v-for="item in versionOptions"
                  :value="item.value"
                  :key="item.value"
                >{{item.label}}</i-option>
              </i-select>
            </form-item>
          </i-col>

          <i-col span="12" :offset="1">
            <form-item label="禁用聊天">
              <i-switch
                :title="tipsTitle"
                v-model="ifChatDisabled"
                true-value="1"
                false-value="0"
                :disabled="ifDisabled || !haveFlAccount"
              >
                <span slot="open">是</span>
                <span slot="close">否</span>
              </i-switch>
            </form-item>
          </i-col>
        </Row>
        <Row>
          <i-col span="11">
            <form-item label="开始日期" prop="startDate">
              <date-picker
                :title="tipsTitle"
                style="width:100%;"
                placeholder="请选择开始日期"
                v-model="configData.startDate"
                @on-change="onStartDateChange"
                :disabled="ifDisabled "
                clearable
              ></date-picker>
            </form-item>
          </i-col>
          <i-col span="12" :offset="1">
            <form-item label="结束日期" prop="endDate">
              <date-picker
                :title="tipsTitle"
                style="width:100%;"
                placeholder="请选择结束日期"
                v-model="configData.endDate"
                :disabled="ifDisabled"
                clearable
              ></date-picker>
            </form-item>
          </i-col>
        </Row>
      </Form>

      <div class="btn-wrapper">
        <Button
          :loading="btnLoading"
          type="primary"
          :title="tipsTitle"
          @click="submit"
          :disabled="ifDisabled"
        >提交</Button>
      </div>
    </div>
  </div>
</template>

<script>
import moment from "moment";
export default {
  data() {
    return {
      haveFlAccount: false,
      ifChatDisabled: "0",
      ifFirstChange: true,
      loading: false,
      btnLoading: false,
      companyId: "",
      configData: {},
      validateRules: {
        versionType: {
          required: true,
          message: "不能为空"
        },
        startDate: {
          required: true,
          message: "不能为空"
        },
        endDate: {
          required: true,
          message: "不能为空"
        }
      },
      versionOptions: [
        {
          value: "1",
          label: "私募-试用版"
        },
        {
          value: "2",
          label: "私募-基础版"
        },
        {
          value: "6",
          label: "机构-试用版"
        },
        {
          value: "3",
          label: "机构-基础版"
        },
        {
          value: "4",
          label: "机构-加强版"
        },
        {
          value: "5",
          label: "机构-豪华版"
        },
        {
          value: "0",
          label: "关闭"
        }
      ]
    };
  },

  computed: {
    ifDisabled() {
      return !!!this.companyId;
    },

    tipsTitle() {
      return this.ifDisabled ? "公司ID缺失,不能操作" : "";
    }
  },

  methods: {
    onVersionChange() {
      this.ifFirstChange = true;
    },

    onStartDateChange(date) {
      if (this.ifFirstChange && !this.configData.endDate) {
        this.ifFirstChange = !this.ifFirstChange;
        let oneMonthIds = ["1", "6"];
        let oneYearIds = ["2", "3", "4", "5"];
        if (oneMonthIds.includes(this.configData.versionType)) {
          let endDate = moment(date).add(1, "M");
          this.$set(this.configData, "endDate", endDate);
        } else if (oneYearIds.includes(this.configData.versionType)) {
          let endDate = moment(date).add(1, "y");
          this.$set(this.configData, "endDate", endDate);
        }
      }
    },

    getData(orgId, orgName, orgNameString, companyId, orgType) {
      this.companyId = companyId;
      if (this.companyId) {
        this.loading = true;
        Promise.all([this.getConfigInfo(), this.getIfChatDisabled(companyId)])
          .then(() => {
            this.loading = false;
          })
          .catch(err => {
            this.loading = false;
          });
      } else {
        this.$Message.warning("公司ID缺失！");
        return Promise.resolve();
      }
    },

    getConfigInfo(companyId) {
      return new Promise(resolve => {
        this.$http
          .get("FundLink/getCompanyFundLinkVersion", {
            companyId: this.companyId
          })
          .then(res => {
            if (res.code === 20000) {
              this.transferData(res.data || {});
              resolve();
            } else {
              reject();
              this.$Message.error(`获取配置信息失败：${res.msg}`);
            }
          })
          .catch(err => {
            console.error(err);

            reject();
            this.$Message.error("获取配置信息失败：网络请求错误！");
          });
      });
    },

    getIfChatDisabled(companyId) {
      let params = {
        companyId
      };
      return new Promise((resolve, reject) => {
        this.$http
          .get("FundLink/getCompanyChat", params)
          .then(res => {
            if (res.code === 20000) {
              this.ifChatDisabled = res.data.disable;
              this.haveFlAccount = !!res.data.flAccount;
              resolve();
            } else {
              this.$Message.error(`获取配置信息失败：${res.msg}`);
              reject();
            }
          })
          .catch(err => {
            console.error(err);
            reject();
            this.$Message.error("获取配置信息失败：网络请求错误！");
          });
      });
    },

    transferData(data = {}) {
      if (!data.startDate || data.startDate == "0000-00-00 00:00:00") {
        data.startDate = "";
      }

      if (!data.endDate || data.endDate == "0000-00-00 00:00:00") {
        data.endDate = "";
      }

      this.configData = data;
    },

    submit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.btnLoading = true;
          if (this.haveFlAccount) {
            Promise.all([this.submitConfig(), this.submitIfChatDisabled()])
              .then(res => {
                this.btnLoading = false;
                this.$Message.success("配置成功！");
              })
              .catch(err => {
                this.btnLoading = false;
                this.$Message.error("配置失败!");
              });
          } else {
            this.submitConfig()
              .then(res => {
                this.btnLoading = false;
                this.$Message.success("配置成功！");
              })
              .catch(err => {
                this.btnLoading = false;
                this.$Message.error("配置失败!");
              });
          }
        } else {
          this.$Message.warning("请按红色文字提示填写内容！");
        }
      });
    },

    submitConfig() {
      let data = JSON.parse(JSON.stringify(this.configData));
      if (data.startDate) {
        data.startDate = moment(data.startDate).format("YYYY-MM-DD");
      }
      if (data.endDate) {
        data.endDate = moment(data.endDate).format("YYYY-MM-DD");
      }

      let params = {
        companyId: this.companyId,
        ...data
      };
      return new Promise((resolve, reject) => {
        this.$http
          .post("FundLink/setCompanyFundLinkVersion", params)
          .then(res => {
            if (res.code === 20000) {
              resolve();
            } else {
              reject();
            }
          })
          .catch(err => {
            console.error(err);
            reject();

            this.$Message.error("配置失败:网络请求错误！");
          });
      });
    },

    submitIfChatDisabled() {
      let params = {
        companyId: this.companyId,
        disable: this.ifChatDisabled || "0"
      };

      return new Promise((resolve, reject) => {
        this.$http.post("FundLink/setCompanyChat", params).then(res => {
          if (res.code === 20000) {
            resolve();
          } else {
            reject(res.msg);
          }
        });
      });
    },

    onClickTree(orgId, orgName, companyId, orgType, orgNameString) {
      return new Promise(resolve => {
        this.getData(orgId, orgName, orgNameString, companyId, orgType);
      });
    }
  }
};
</script>

<style lang="less" scoped>
.btn-wrapper {
  text-align: right;
}
</style>

