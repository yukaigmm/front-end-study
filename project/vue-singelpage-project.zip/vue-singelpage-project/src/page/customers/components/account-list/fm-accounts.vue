<template>
  <div>
    <Form
      ref="form"
      :label-width="90"
      class="search-area"
      @keydown.enter.native.prevent="onSearchClick"
    >
      <Row>
        <i-col span="8">
          <FormItem label="关键词">
            <Input v-model.trim="searchData.keyword" placeholder="请输入姓名/用户名/手机号"/>
          </FormItem>
        </i-col>

        <i-col span="8">
          <FormItem label="推荐人">
            <Select v-model="searchData.recommenderId" transfer clearable>
              <Option
                v-for="(item ,index ) in recommenderList"
                :key="index"
                :value="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </i-col>

        <i-col :offset="1" span="6">
          <Button type="primary" @click="onSearchClick">搜索</Button>
        </i-col>
      </Row>
    </Form>

    <div class="table-area customer-contact-list">
      <Table
        class="table-container"
        ref="table"
        :data="tableData"
        :columns="columns"
        border
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
      ></Table>
    </div>

    <div class="page-load fr">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      />
    </div>

    <edit-account-modal ref="editAccountModal" @refreshTable="getData"></edit-account-modal>
    <reset-password-modal ref="resetPasswordModal"></reset-password-modal>
  </div>
</template>

<script>
import $ from "jquery";
import { mapGetters } from "vuex";
import editAccountModal from "../../../fm-account-manager/components/edit-account";
import resetPasswordModal from "../../../account-justify/components/reset-password-modal";
import getMinusNumber from "@/mixins/getMinusNumber.js";
export default {
  components: {
    resetPasswordModal,
    editAccountModal
  },

  mixins: [getMinusNumber],

  data() {
    return {
      // currentOrgIdAndSubOrgIds: [],
      orgId: "",
      companyInfo: {},
      companyId: "",
      searchData: {
        fundLink: "",
        user_keyword: ""
      },

      fundLinkOptions: [
        {
          value: 1,
          label: "已开通"
        },
        {
          value: 0,
          label: "未开通"
        }
      ],

      tableData: [],

      recommenderList: [],

      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  computed: {
    ...mapGetters({
      userInfo: "getUser"
    }),

    canEdit() {
      return this.userInfo.auth.functional.includes("editFmAccount");
    },

    canDelete() {
      return this.userInfo.auth.functional.includes("deleteFmAccount");
    },

    canReset() {
      return this.userInfo.auth.functional.includes("resetFmPsw");
    },
    canAdd() {
      return this.userInfo.auth.functional.includes("addFmAccount");
    },

    isAssistant() {
      return this.userInfo.auth.functional.includes("isAssistant");
    },

    columns() {
      let basicColumn = [
        {
          width: 90,
          title: "姓名",
          key: "realName",
          render(h, { row }) {
            return h("span", row.realName || "--");
          }
        },
        // {
        //   width: 100,
        //   title: "用户名",
        //   key: "name",
        //   render(h, { row }) {
        //     return h("span", row.name || "--");
        //   }
        // },
        {
          width: 120,
          title: "手机号",
          key: "cellphone",
          render(h, { row }) {
            return h("span", row.cellphone || "--");
          }
        },
        {
          width: 90,
          title: "职位",
          key: "position",
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.position || "--");
          }
        },
        {
          width: 107,
          title: "账号状态",
          key: "userStatus",
          render: (h, { row }) => {
            let mapping = [
              {
                label: "正常",
                value: 1
              },
              {
                label: "禁用",
                value: 2
              },
              {
                label: "离职",
                value: 3
              },
              {
                label: "删除",
                value: 4
              }
            ];

            let text =
              mapping.filter(item => row.userStatus == item.value)[0][
                "label"
              ] || "--";

            return h("span", text);
          }
        },
        {
          title: "使用情况",
          key: "useStage",
          width: 100,
          render: (h, { row }) => {
            return h(
              "span",
              `${row.activate ? "激活" : "未激活"}/${
                row.active ? "活跃" : "不活跃"
              }`
            );
          }
        },
        {
          title: "私募直连",
          key: "fundLink",
          width: 80,
          render(h, { row }) {
            return h("span", row.fundLink ? "已开通" : "未开通");
          }
        },
        {
          width: 80,
          title: "管理员",
          key: "isAdmin",
          render(h, { row }) {
            if (row.isAdmin === 0) {
              return h("span", "否");
            } else if (row.isAdmin === 1) {
              return h("span", "是");
            } else {
              return h("span", "--");
            }
          }
        },
        {
          width: 80,
          title: "业务类型",
          key: "businessType",
          render(h, { row }) {
            let mapping = {
              "1": "私募",
              "2": "信托",
              "3": "券商",
              "4": "期货",
              "5": "银行"
            };
            return h("span", mapping[row.businessType] || "--");
          }
        },
        {
          width: 80,
          title: "推荐人",
          key: "recommenderName",
          render(h, { row }) {
            return h("span", row.recommenderName || "--");
          }
        },
        {
          key: "visitingCardUrl",
          title: "名片",
          width: 100,
          render(h, { row }) {
            let url;
            if (row.visitingCardUrl) {
              let picUrl = JSON.parse(JSON.stringify(row.visitingCardUrl));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? " http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";

                let picPath = row.visitingCardUrl.replace(/Uploads\/crm/g, "/");
                picUrl = `Uploads/crm/${picPath}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        },
        {
          width: 170,
          title: "操作",
          fixed: "right",
          render: (h, { row }) => {
            return h("div", [
              // h(
              //   "div",
              //   {
              //     attrs: {
              //       class: this.canEdit ? "deleteBtn" : "disabledBtn"
              //     },
              //     on: {
              //       click: () => {
              //         if (!this.canEdit) {
              //           return;
              //         }
              //         this.$refs.editAccountModal.show(this.companyInfo, row);
              //       }
              //     }
              //   },
              //   "编辑"
              // ),

              h(
                "div",
                {
                  attrs: {
                    class: this.canDelete ? "deleteBtn" : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (!this.canDelete) {
                        return;
                      }
                      this.deleteAccount(row.masterId);
                    }
                  }
                },
                "删除"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: this.canReset ? "deleteBtn" : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (!this.canReset) {
                        return;
                      }
                      this.resetPassword({
                        phoneNumber: row.cellphone,
                        name: row.realName,
                        officialUserId: row.officialUserId,
                        productId: 2
                      });
                    }
                  }
                },
                "重置密码"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  style: {
                    display:
                      this.isAssistant && row.isServed ? "inline-block" : "none"
                  },
                  on: {
                    click: () => {
                      if (this.isAssistant && row.isServed) {
                        this.chatWith(row.officialUserId);
                      } else {
                        return;
                      }
                    }
                  }
                },
                "小助手"
              )
            ]);
          }
        }
      ];

      return basicColumn;
    }
  },

  mounted() {
    if (this) {
      this.setMaxHeightOfFixedTable(
        ".content-body.ivu-col",
        [".search-area", ".page-load"],
        ".table-area"
      );
    }
    this.getRecommenderList();
  },

  methods: {
    chatWith(id) {
      let params = {
        officialUserId: id,
        type: 2
      };

      this.$http.get("LittleHelper/getHelperService", params).then(res => {
        if (res.code === 20000) {
          // 用户类型 1-C端客户 2-B端客户  3-理财师 4-小助手

          window.chatComp.chatWith(2, res.data.userKey, res.data.platformName);
          this.$store.dispatch("setIfAssistantOpen", {
            ifAssistantOpen: true
          });
        } else {
          this.$Message.error("获取用户信息失败！");
        }
      });
    },

    getRecommenderList() {
      let params = {
        dept_id: 1,
        type: 1
      };

      this.$http.get("dept/getUserByDept", params).then(res => {
        if (res.code === 20000) {
          this.recommenderList = res.data;
        } else {
          this.$Message.error("获取推荐人列表失败！");
        }
      });
    },

    //  重置密码
    resetPassword(accountInfo = {}) {
      this.$refs.resetPasswordModal.show(accountInfo);
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getData( this.orgId, this.companyId);
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getData(this.orgId, this.companyId);
    },

    onSearchClick() {
      this.pageSize = 10;
      this.currentPage = 1;
      this.getData( this.orgId, this.companyId);
    },

    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 250;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    getData(
      orgId = this.orgId,
      companyId = this.companyId
    ) {
      this.companyId = companyId;
      this.orgId = orgId;
      let searchParams = JSON.parse(JSON.stringify(this.searchData));
      // if (!searchParams.fundLink && searchParams !== 0) {
      //   delete searchParams.fundLink;
      // }
      // modified by yukai -- start
      if (searchParams.fundLink === "") {
        delete searchParams.fundLink;
      }
      // modified by yukai -- end

      let params = Object.assign(
        {
          orgId: orgId,
          ...searchParams
        },
        {
          pageNo: this.currentPage,
          pageSize: this.pageSize
        }
      );

      return new Promise(resolve => {
        this.tableLoading = true;
        this.$http.get(`FmAccount`, params).then(res => {
          this.tableLoading = false;
          resolve();
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
          } else {
            this.$Message.error(`获取账号列表失败：${res.msg}`);
          }
        });
      });
    },

    onClickTree(
      orgId = this.orgId,
      companyId
    ) {
      this.companyId = companyId;
      this.orgId = orgId;
      return new Promise(resolve => {
        this.searchData = {
          recommenderId: "",
          keyword: ""
        };
        this.pageSize = 10;
        this.currentPage = 1;
        this.getData(
          (orgId = this.orgId),
          companyId
        ).then(() => {
          resolve();
        });
      });
    },

    deleteAccount(id) {
      this.$Modal.confirm({
        title: "删除账号",
        content: "确定删除这条账号吗？",
        onOk: () => {
          this.setAccountStatus(4, id);
        }
      });
    },

    setAccountStatus(status, id) {
      let params = {
        userStatus: status
      };
      this.$http.putWithoutId(`FmAccount/status/${id}`, params).then(res => {
        if (res.code === 20000) {
          this.$Message.success("设置成功！");
          this.getData(
            this.orgId,
            this.companyId
          );
        } else {
          this.$Message.error("设置失败！");
        }
      });
    }
  }
};
</script>


<style lang="less" scoped>
.fr {
  text-align: right;
  margin: 10px;
}
</style>


