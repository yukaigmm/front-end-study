<template>
  <div>
    <RadioGroup v-model="accountComp" @on-change="onRadioChange" class="switch-wrap">
      <Radio label="fofAccountList">
        <span>组合大师账号</span>
      </Radio>
      <Radio label="fmAccountList">
        <span>基金大师账号</span>
      </Radio>
    </RadioGroup>

    <component :is="accountComp" :salerList="salerList" ref="accountComp"></component>
  </div>
</template>

<script>
import fofAccountList from "./fof-accounts.vue";
import fmAccountList from "./fm-accounts.vue";

export default {
  components: {
    fmAccountList,
    fofAccountList,
    orgId: "",
    companyId: ""
  },

  props: {
    salerList: {
      type: [Array, Object],
      default: () => []
    }
  },

  data() {
    return {
      accountComp: "",
      orgType: ""
    };
  },

  watch: {
    orgType: {
      handler(val) {
        if (val == 7) {
          this.accountComp = "fmAccountList";
        } else {
          this.accountComp = "fofAccountList";
        }
      },

      immediate: true
    }
  },

  methods: {
    onRadioChange(val) {
      this.$nextTick(() => {
        this.getData(
          this.orgId,
          1,
          2,
          this.companyId
        );
      });
    },

    getData(
      orgId = this.orgId,
      name,
      nameString,
      companyId,
      orgType = this.orgType
    ) {
      this.orgId = orgId;
      this.orgType = orgType;

      this.companyId = companyId;
      return new Promise(resolve => {
        this.$nextTick(() => {
          this.$refs.accountComp
            .getData(orgId, companyId)
            .then(() => {
              resolve();
            });
        });
      });
    },

    onClickTree(
      orgId = this.orgId,
      orgName,
      companyId,
      orgType = this.orgType
    ) {
      this.orgType = orgType;
      this.orgId = orgId;
      this.companyId = companyId;
      return new Promise(resolve => {
        this.$nextTick(() => {
          this.$refs.accountComp
            .onClickTree( orgId, this.companyId)
            .then(() => {
              resolve();
            });
        });
      });
    },

    onSearchClick() {
      this.$refs.accountComp.onSearchClick();
    }
  }
};
</script>

<style lang="less" scoped>
.switch-wrap {
  margin: 10px;
}
</style>

