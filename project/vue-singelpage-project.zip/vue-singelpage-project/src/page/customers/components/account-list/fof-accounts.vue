<template>
  <div>
    <div class="searchArea keydown-box">
      <search-area
        ref="form"
        @changeSearchParam="changeSearchParam"
        @onKeydownSearch="onSearchClick"
      >
        <div slot="default">
          <Row>
            <i-col span="8">
              <FormItem prop="realName" label="用户名">
                <i-input v-model.trim="form.realName" placeholder="请输入用户名"/>
              </FormItem>
            </i-col>

            <i-col span="8">
              <FormItem prop="accountNo" label="账号(手机号)">
                <i-input v-model.trim="form.accountNo" placeholder="请输入账号(手机号)"/>
              </FormItem>
            </i-col>
            <i-col span="8">
              <Button type="primary" @click="onSearchClick" style="margin-left:20px">搜索</Button>
              <Button @click="onReset">重置</Button>
            </i-col>
          </Row>
          <Row>
            <i-col span="8">
              <FormItem prop="accountStatus" label="账号状态">
                <Select v-model="form.accountStatus" clearable>
                  <Option
                    v-for="item in accountStatusMapping"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</Option>
                </Select>
              </FormItem>
            </i-col>

            <i-col span="8">
              <FormItem prop="productId" label="责任人">
                <Select v-model="form.managerId" placeholder="请选择责任人" clearable>
                  <Option
                    v-for="item in managerList"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</Option>
                </Select>
              </FormItem>
            </i-col>
          </Row>
        </div>

        <div slot="extend">
          <Row>
            <i-col span="8">
              <FormItem prop="orgName" label="机构名称">
                <i-input v-model.trim="form.orgName" placeholder="请输入机构名称"/>
              </FormItem>
            </i-col>

            <i-col span="8">
              <FormItem prop="productId" label="产品类型">
                <Select v-model="form.productId" placeholder="请选择产品类型">
                  <Option
                    v-for="item in productIdMapping"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</Option>
                </Select>
              </FormItem>
            </i-col>
          </Row>

          <Row>
            <i-col span="8">
              <FormItem prop="groupId" label="用户组">
                <Select v-model="form.groupId" placeholder="请选择用户组" clearable>
                  <Option
                    v-for="item in groupIdMapping"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</Option>
                </Select>
              </FormItem>
            </i-col>

            <i-col span="8">
              <FormItem prop="payingFlag" label="是否付费">
                <Select v-model="form.payingFlag" placeholder="请选择是否付费" clearable>
                  <Option
                    v-for="item in payingFlagMapping"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</Option>
                </Select>
              </FormItem>
            </i-col>
          </Row>
        </div>
      </search-area>
    </div>
    <Button type="primary" @click="assign" style="margin-top:10px;" v-if="canAssign ">批量分配</Button>
    <Button type="primary" @click="batchEdit" style="margin-top:10px;">批量编辑</Button>
    <div class="table-container">
      <Table
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        :columns="columns"
        :data="tableData"
        @on-selection-change="onTableSelectionChange"
        border
      ></Table>
    </div>

    <div class="page-load">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      ></Page>
    </div>
    <accountEditModal ref="accountEditModal" @refreshTable="onSearchClick"></accountEditModal>
    <assignModal ref="assignModal" @refreshTable="refreshTable" @clearSelection="clearSelection"></assignModal>
    <reset-password-modal ref="resetPasswordModal"></reset-password-modal>
    <batch-edit-modal
      ref="batchEditModal"
      :tableData="slectionRoWData"
      @refreshTable="onSearchClick"
      @clearSelection="clearSelection"
    ></batch-edit-modal>
  </div>
</template>

<script>
import searchArea from "@/components/search-area";
import $ from "jquery";
import api from "@/service/api.js";
import accountEditModal from "../../../account-justify/components/account-edit-modal";
import assignModal from "../../../account-justify/components/assign-account-modal";
import { mapGetters } from "vuex";
import { map } from "lodash";
import resetPasswordModal from "../../../account-justify/components/reset-password-modal";
import resetFOFPassword from "@/mixins/resetFOFPassword";
import batchEditModal from "../../../account-justify/components/batch-edit-modal";
import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  components: {
    searchArea,
    accountEditModal,
    assignModal,
    resetPasswordModal,
    batchEditModal
  },

  props: {
    salerList: {
      type: [Array, Object],
      default: () => []
    }
  },

  mixins: [resetFOFPassword, getMinusNumber],

  data() {
    return {
      fofLogo: require("../../../../assets/fof-logo.png"),
      fmLogo: require("../../../../assets/fm-logo.png"),
      slectionRoWData: [],
      tableSelectedRow: [],
      orgId: "",
      accountStatusMapping: [
        {
          label: "异常",
          value: "0"
        },
        {
          label: "申请",
          value: "1"
        },
        {
          label: "试用",
          value: "2"
        },
        {
          label: "正式",
          value: "3"
        },
        {
          label: "停用",
          value: "4"
        }
      ],
      productIdMapping: [
        {
          label: "组合大师",
          value: "1"
        },
        {
          label: "基金大师",
          value: "2"
        }
      ],
      userLevelMapping: [
        {
          label: "正常",
          value: "1"
        },
        {
          label: "异常",
          value: "0"
        }
      ],
      groupIdMapping: [
        // {
        //   label: "组合大师管理员",
        //   value: "1"
        // },
        {
          label: "VIP会员",
          value: "2"
        },
        {
          label: "普通用户",
          value: "3"
        }
      ],
      payingFlagMapping: [
        {
          label: "已付费",
          value: "1"
        },
        {
          label: "未付费",
          value: "0"
        }
      ],
      form: {
        orgName: "",
        accountNo: "",
        realName: "",
        accountStatus: "",
        productId: "1",
        userLevel: "",
        groupId: "",
        payingFlag: ""
      },
      hasMoreParam: false,
      tableData: [],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  created() {
  },

  computed: {
    ...mapGetters({
      tabs: "getTabs"
    }),

    managerList() {
      return this.salerList;
    },

    columns() {
      let actionWidth;
      if (this.ifAdmin && this.canAssign) {
        actionWidth = 180;
      } else if (!this.ifAdmin && !this.canAssign) {
        actionWidth = 60;
      } else {
        actionWidth = 140;
      }
      return [
        {
          type: "selection",
          width: 60,
          align: "center",
          fixed: "left"
        },
        {
          key: "realName",
          title: "用户名",
          width: 100,
          fixed: "left",
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  display: "flex",
                  justifyContent: "flex-start",
                  alignItems: "center"
                }
              },
              [
                h("span", {
                  attrs: {
                    title: row.productId == 1 ? "组合大师账号" : "基金大师账号"
                  },
                  style: {
                    backgroundImage:
                      row.productId == 1
                        ? `url(${this.fofLogo})`
                        : `url(${this.fmLogo})`,
                    display: "inline-block",
                    backgroundSize: "100%",
                    backgroundRepeat: "no-repeat",
                    width: "20px",
                    height: "20px",
                    borderRadius: "4px",
                    marginRight: "5px"
                  }
                }),
                h("span", row.realName || "--")
              ]
            );
          }
        },
        {
          key: "accountNo",
          title: "账号(手机号)",
          width: 100,
          fixed: "left",
          render(h, { row }) {
            if (row.accountStatus == "3" || row.accountStatus == "2") {
              let path =
                process.env.NODE_ENV === "production"
                  ? `https://fofanalysis.simuwang.com?accountNo=${
                      row.accountNo
                    }`
                  : `http://fofanalysis-test.simuwang.com?accountNo=${
                      row.accountNo
                    }`;
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: path,
                    title: "账号分析"
                  }
                },
                row.accountNo || "--"
              );
            } else {
              return row.accountNo || "--";
            }
          }
        },
        {
          key: "accountStatus",
          title: "账号状态",
          width: 80,
          render(h, { row }) {
            let mapping = {
              "4": "停用",
              "3": "正式",
              "2": "试用",
              "1": "申请",
              "0": "异常"
            };
            return mapping[row.accountStatus] || "--";
          }
        },
        {
          key: "endDate",
          title: "结束日期",
          width: 100,
          render(h, { row }) {
            return row.endDate ? row.endDate.substr(0, 11) : "--";
          }
        },
        {
          key: "managerName",
          title: "责任人",
          width: 80,
          render: (h, { row }) => {
            if (row.isChange) {
              return h("managerPoptip", {
                props: {
                  row
                }
              });
            } else {
              return h("span", row.managerName || "--");
            }
          }
        },
        {
          key: "orgName",
          title: "机构名称",
          width: 200,
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.orgName
                }
              },
              row.orgName || "--"
            );
          }
        },
        {
          key: "visitingCardUrl",
          title: "名片",
          width: 80,
          render(h, { row }) {
            let url;
            if (row.visitingCardUrl) {
              let picUrl = JSON.parse(JSON.stringify(row.visitingCardUrl));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? " http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";
                picUrl = `Uploads/crm/${row.visitingCardUrl}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        },
        {
          key: "isHide", // 字段待定，新需求
          title: "隐藏数据",
          width: 80,
          render(h, { row }) {
            let mapping = {
              "1": "是",
              "0": "否"
            };
            return mapping[row.isHide] || "--";
          }
        },
        {
          key: "groupId",
          title: "用户组",
          width: 120,
          render(h, { row }) {
            let mapping = {
              "1": "组合大师管理员",
              "2": "VIP会员",
              "3": "普通用户"
            };
            return mapping[row.groupId] || "--";
          }
        },
        {
          key: "payingFlag",
          title: "是否付费",
          width: 80,
          render(h, { row }) {
            let mapping = {
              "0": "未付费",
              "1": "已付费"
            };
            return mapping[row.payingFlag] || "--";
          }
        },
        {
          key: "orgManagerName",
          title: "公司责任人",
          width: 120,
          render(h, { row }) {
            return row.orgManagerName || "--";
          }
        },
        {
          key: "userSource",
          title: "用户来源",
          width: 100,
          render(h, { row }) {
            let mapping = {
              "1": "PC端",
              "2": "移动端（扫码）",
              "3": "banner申请",
              "4": "批量导入",
              "5": "CRM单条新增"
            };
            return mapping[row.userSource] || "--";
          }
        },
        {
          key: "remarks",
          title: "备注",
          width: 135,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  maxWidth: "130px",
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  cursor: "pointer"
                },
                attrs: {
                  title: row.remark || ""
                }
              },
              row.remark || "--"
            );
          }
        },

        {
          key: "isForeigner",
          title: "是否海外用户",
          width: 100,
          render(h, { row }) {
            let mapping = {
              "1": "海外用户",
              "0": "国内用户"
            };
            return mapping[row.isForeigner] || "--";
          }
        },

        {
          key: "beginDate",
          title: "开始日期",
          width: 100,
          render(h, { row }) {
            return row.beginDate ? row.beginDate.substr(0, 11) : "--";
          }
        },

        {
          key: "creater",
          title: "创建人",
          width: 80,
          render(h, { row }) {
            return row.creater || "--";
          }
        },
        {
          key: "updater",
          title: "更新人",
          width: 80,
          render(h, { row }) {
            return row.updater || "--";
          }
        },
        {
          key: "updateTime",
          title: "更新时间",
          width: 100,
          render(h, { row }) {
            return row.updateTime ? row.updateTime.substr(0, 11) : "--";
          }
        },

        {
          key: "apply_source",
          title: "申请来源",
          width: 100,
          render(h, { row }) {
            const applySourceMapping = {
              1: "主站",
              7: "扫码注册",
              8: "其他"
            };
            return applySourceMapping[row.applySource] || "--";
          }
        },

        {
          title: "操作",
          width: actionWidth,
          fixed: "right",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: row.productId == 2 ? "disabledBtn" : "deleteBtn"
                  },
                  on: {
                    click: () => {
                      if (row.productId == 2) {
                        return;
                      }
                      let hasRelated = !!row.contractsId;
                      this.$refs.accountEditModal.show(
                        row.id,
                        row.accountNo,
                        row.productId,
                        hasRelated
                      );
                    }
                  }
                },
                "编辑"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: row.productId == 2 ? "disabledBtn" : "deleteBtn"
                  },
                  style: {
                    display: this.canAssign ? "inline-block" : "none"
                  },
                  on: {
                    click: () => {
                      // 基金大师账号先不能编辑
                      if (row.productId == 2) {
                        return;
                      }
                      this.$refs.assignModal.show(
                        row.managerId,
                        [row.accId],
                        this.form.productId
                      );
                    }
                  }
                },
                "分配"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  style: {
                    display: this.ifAdmin ? "inline-block" : "none"
                  },
                  on: {
                    click: () => {
                      this.resetPassword({
                        phoneNumber: row.accountNo,
                        name: row.realName,
                        officialUserId: row.officialUserId,
                        productId: row.productId
                      });
                    }
                  }
                },
                "重置密码"
              )
            ]);
          }
        }
      ];
    }
  },

  mounted() {
    if (this) {
      this.setMaxHeightOfFixedTable(
        ".content-body.ivu-col",
        [".searchArea", ".page-load"],
        ".table-container"
      );
    }
  },

  methods: {
    //批量编辑
    batchEdit() {
      if (!this.slectionRoWData.length) {
        this.$Message.warning("请先选择账号！");
        return;
      }
      this.$refs.batchEditModal.show();
    },
    //  获取机构销售部人员列表
    getManagerList() {
      this.$http
        .get("dept/getUserByDept", {
          dept_id: 16,
          type: 1
        })
        .then(res => {
          if (res.code === 20000) {
            this.managerList = map(res.data, person => person).filter(
              item => item.status
            );
          }
        })
        .catch(e => {
          console.error("获取人员列表失败");
        });
    },

    clearSelection() {
      this.slectionRoWData = [];
      this.tableSelectedRow = [];
    },
    // 获取选定的数据的id
    onTableSelectionChange(selection) {
      this.slectionRoWData = JSON.parse(JSON.stringify(selection));
      this.tableSelectedRow = selection.map(item => item.id);
    },

    //  显示分配模态框
    assign() {
      if (!this.tableSelectedRow.length) {
        this.$Message.warning("请先选择账号！");
        return;
      }
      this.$refs.assignModal.show(
        "",
        this.tableSelectedRow,
        this.form.productId
      );
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getData(this.ordId);
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      if (this.currentPage == 1) {
        this.getData(this.ordId);
      } else {
        this.currentPage = 1;
      }
    },

    changeSearchParam() {
      this.hasMoreParam = !this.hasMoreParam;
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".searchArea", ".page-load"],
          ".table-container"
        );
      });
    },

    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      if (!this) {
        return;
      }
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 250;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    onSearchClick() {
      this.tableSelectedRow = [];
      this.currentPage = 1;
      this.pageSize = 10;
      this.getData(this.ordId);
    },

    refreshTable() {
      this.tableSelectedRow = [];
      this.getData(this.ordId);
    },

    onClickTree(ordId) {
      return new Promise((resolve, reject) => {
        this.form = {
          orgName: "",
          accountNo: "",
          realName: "",
          accountStatus: "",
          productId: "1",
          userLevel: "",
          groupId: "",
          payingFlag: ""
        };
        this.pageSize = 10;
        this.currentPage = 1;
        this.getData(ordId).then(() => {
          resolve();
        });
      });
    },

    onReset() {
      this.form = {
        orgName: "",
        accountNo: "",
        realName: "",
        accountStatus: "",
        productId: "1",
        managerId: "",
        userLevel: "",
        groupId: "",
        payingFlag: ""
      };
      this.pageSize = 10;
      this.currentPage = 1;
      this.getData(this.ordId);
    },

    //  获取搜索或者获取数据的参数
    getParams() {
      let form = JSON.parse(JSON.stringify(this.form));
      let param = {};
      if (this.hasMoreParam) {
        param = { ...form };
      } else {
        for (let key in form) {
          if (
            key === "accountNo" ||
            key === "realName" ||
            key === "accountStatus" ||
            key === "productId" ||
            key === "managerId"
          ) {
            param[key] = form[key];
          }
        }
      }
      if (param.orgName) {
        param.orgName = JSON.parse(JSON.stringify(param.orgName))
          .trim()
          .split(/[ ]+/);
      } else {
        delete param.orgName;
      }
      return Object.assign(
        {
          pageSize: this.pageSize,
          pageNo: this.currentPage
        },
        param
      );
    },

    // 获取列表数据
    getData(orgId = this.orgId) {
      this.orgId = orgId;
      let params = Object.assign(
        {
          org_pid: this.orgId
        },
        this.getParams()
      );

      return new Promise((resolve, reject) => {
        this.tableLoading = true;
        this.$http.get("/accounts/findAccount", params).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
            this.pageNo = res.data.pageNo;
            resolve();
          } else {
            this.$message.error("获取账号列表失败");
            reject();
          }
        });
      });
    }
  }
};
</script>

<style scoped>
.table-container {
  margin-top: 15px;
}

.page-load {
  text-align: right;
  margin-right: 15px;
  margin-top: 15px;
}
</style>


