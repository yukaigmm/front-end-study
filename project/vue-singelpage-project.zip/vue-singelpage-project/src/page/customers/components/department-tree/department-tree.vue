<template>
  <div class="department-tree">
    <div class="tree-search">
      <span class="tree-search-label">公司/部门名称：</span>
      <i-input
        class="tree-input"
        @on-change="onKeywordChange"
        v-model="keywords"
        placeholder="请输入公司/部门名称"
      />
    </div>
    <el-tree
      v-loading="treeLoading"
      element-loading-text="拼命加载中"
      class="customer-department-tree"
      :props="defaultProps"
      :data="treeData"
      accordion
      node-key="orgId"
      :render-content="renderContent"
      :highlight-current="true"
      :default-expanded-keys="defaultKey"
      :expand-on-click-node="false"
      ref="departmentTree"
      @node-click="handleNodeClick"
    ></el-tree>

    <selectManagerModal ref="selectManagerModal" @refreshTable="selectManager"></selectManagerModal>
  </div>
</template>

<script>
import selectManagerModal from "../../../customers-assign/edit-responsors-modal";
import { mapGetters } from "vuex";
import { map } from "lodash";
let timer = null;
export default {
  components: {
    selectManagerModal
  },

  data() {
    return {
      keywords: "",
      managerIdsStr: "",
      currentTreeData: {},
      companyName: "",
      defaultManagerIds: [],
      defaultProps: {
        children: "children",
        label: "orgName"
      },
      treeData: [],
      defaultKey: [],
      orgNameArr: [],
      currentOrgId: "",
      orgId: "",
      treeLoading: false
    };
  },

  computed: {
    ...mapGetters({
      userInfo: "getUser"
    }),

    hasRight() {
      return this.userInfo.auth.functional.includes("assignCustomer");
    }
  },

  watch: {},

  destroyed() {
    this.currentOrgId = "";
  },

  methods: {
    // 自定义渲染树形结构
    renderContent(h, { node, data, store }) {
      return (
        <span class={"customNodeTree"}>
          <div>
            <span>{node.label}</span>
            <span>{`(A:${data.accountNum || 0}/C:${data.contactNum ||
              0})`}</span>
          </div>

          <span
            class={
              this.hasRight
                ? "assign-part-container"
                : "assign-part-container-nonright"
            }
            on-click={e => {
              e.stopPropagation();
              e.preventDefault();
              this.assignResponsor(data);
            }}
          >
            分配
          </span>
        </span>
      );
    },

    // 分配责任人
    selectManager(managerIds) {
      this.managerIdsStr = [managerIds].join(",");
      // 分配成功后手动更改当前责任人（不刷新列表）

      this.setCurrentTreeDataManagerIds(
        this.currentTreeData,
        this.managerIdsStr
      );
    },

    // 分配成功后手动更改当前责任人（不刷新列表）
    setCurrentTreeDataManagerIds(data, id) {
      if (data.managerIds == this.defaultManagerIds.join(",")) {
        data.managerIds = id;
      }
      if (data.children && data.children.length) {
        for (let i = 0, len = data.children.length; i < len; i++) {
          this.setCurrentTreeDataManagerIds(
            data.children[i],
            this.managerIdsStr
          );
        }
      } else {
        return;
      }
    },

    // 显示责任人选择框
    assignResponsor(data) {
      if (!this.hasRight) {
        return;
      }

      this.currentTreeData = data;
      this.currentOrgId = [data.orgId];
      this.companyName = data.orgName;
      if (data.managerIds) {
        this.defaultManagerIds = data.managerIds.split(",");
      } else {
        this.defaultManagerIds = [];
      }

      this.$refs.selectManagerModal.show(
        this.defaultManagerIds,
        this.currentOrgId,
        ""
      );
    },

    onKeywordChange(e) {
      if (timer) {
        clearTimeout(timer);
      }
      timer = setTimeout(() => {
        let params = {
          keyword: this.keywords,
          ifCancelRequest: true
        };
        this.treeLoading = true;

        this.$http.get(`organization/tree/${this.orgId}`, params).then(res => {
          this.treeLoading = false;
          if (res.code === 20000) {
            if (res.data) {
              this.treeData = [res.data];
            } else {
              this.treeData = [];
            }
            this.$nextTick(() => {
              this.$refs.departmentTree.setCurrentKey(this.currentOrgId - 0);
            });
          } else {
          }
        });
      }, 400);
    },

    getTreeData(orgId) {
      this.defaultKey = [orgId];
      this.orgId = orgId;
      let params = {
        keyword: this.keywords,
        ifCancelRequest: true
      };
      return new Promise((resolve, reject) => {
        this.$http.get(`organization/tree/${orgId}`, params).then(res => {
          if (res.code === 20000) {
            this.getOrgNameString(res);
            let orgNameString = this.orgNameArr.join(">");
            this.$emit(
              "changeDepartMent",
              orgId,
              res.data.orgName,
              orgNameString,
              res.data.companyId
            );
            this.treeData = [res.data];
            this.$nextTick(() => {
              this.$refs.departmentTree.setCurrentKey(orgId - 0);
            });

            resolve();
          } else {
            reject();
          }
        });
      });
    },

    //  获取当前部门及其子部门的id
    // getDepartmentsIds(departmentData) {
    //   this.ids.push(departmentData.orgId);
    //   if (departmentData.children && departmentData.children.length) {
    //     for (let i = 0, len = departmentData.children.length; i < len; i++) {
    //       if (
    //         !departmentData.children[i].children ||
    //         !departmentData.children[i].children.length
    //       ) {
    //         this.ids.push(departmentData.children[i].orgId);
    //         continue;
    //       } else {
    //         this.getDepartmentsIds(departmentData.children[i]);
    //       }
    //     }
    //   } else {
    //     return;
    //   }
    // },

    // 点击子树
    handleNodeClick(data, node, el) {
      this.orgNameArr = [];
      this.getOrgNameString(node);
      let orgNameString = this.orgNameArr.join(">");
      this.currentOrgId = data.orgId;
      this.$emit(
        "changeDepartMent",
        data.orgId,
        data.orgName,
        orgNameString,
        data.companyId
      );
    },

    getOrgNameString(node) {
      this.orgNameArr.unshift(node.data.orgName);
      if (node.parent && node.parent.data && node.parent.data.orgName) {
        this.getOrgNameString(node.parent);
      }
    }
  }
};
</script>

<style lang="less" scoped>
.department-tree {
  .assign-container {
    .pop-content {
      color: #495060;
      max-width: 150px;
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
    }
    .assign-pop {
      color: #19be6b;
      font-size: 18px;
    }
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  position: relative;
  .choose-father-department {
    position: absolute;
    top: 35px;
    left: -15px;
  }
}

.tree-search {
  display: flex;
  justify-content: space-between;
  margin-bottom: 15px;
  align-items: center;
  .tree-input {
    flex: 1;
  }
  .tree-search-label {
    width: 90px;
  }
}
</style>
