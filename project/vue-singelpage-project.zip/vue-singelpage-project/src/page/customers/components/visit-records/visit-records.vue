<template>
  <div>
    <div class="searchArea keydown-box">
      <search-area
        ref="form"
        @changeSearchParam="changeSearchParam"
        @onKeydownSearch="onSearchClick"
      >
        <div slot="default">
          <Row>
            <Col span="10">
              <Form-item prop="contacts_name" label="关键词">
                <Row>
                  <Col span="12" style="padding-right: 3px">
                    <Input
                      style="width:100%;"
                      v-model.trim="formSearch['org_name']"
                      placeholder="机构,如:总部 分部"
                    ></Input>
                  </Col>
                  <Col span="12" style="padding-left: 3px">
                    <Input
                      style="width:100%;"
                      v-model.trim="formSearch['contacts_name']"
                      placeholder="拜访对象或其他接待人"
                    ></Input>
                  </Col>
                </Row>
              </Form-item>
            </Col>

            <Col span="10">
              <Form-item prop="visit_time" label="拜访时间">
                <DatePicker
                  transfer
                  style="width:100%;"
                  type="daterange"
                  v-model="formSearch['visit_time']"
                  placeholder="请输入拜访时间"
                ></DatePicker>
              </Form-item>
            </Col>

            <Col span="4" offset style="text-align:right;">
              <Button type="primary" @click="onSearchClick">搜索</Button>
              <Button @click="onReset">重置</Button>
            </Col>
          </Row>
        </div>

        <div slot="extend">
          <Row>
            <Col span="10">
              <Form-item prop="order_time" label="预设回访时间">
                <DatePicker
                  transfer
                  style="width:100%;"
                  type="daterange"
                  v-model="formSearch['order_time']"
                  placeholder="请输入回访时间"
                ></DatePicker>
              </Form-item>
            </Col>

            <Col span="10">
              <FormItem label="机构类型">
                <Row>
                  <Col span="12" style="padding-right:3px;">
                    <Select v-model="formSearch.oc_id" clearable placeholder="请选择">
                      <Option
                        v-for="item in enums.c_org"
                        :value="item.value"
                        :key="item.value"
                      >{{item.name}}</Option>
                    </Select>
                  </Col>

                  <Col span="12" style="padding-left:3px;">
                    <Select
                      v-model="formSearch.depart_id"
                      not-found-text="无匹配数据"
                      clearable
                      placeholder="请选择机构"
                      style="width:100%;"
                    >
                      <Option
                        v-for="item in enums.c_depart"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>
                </Row>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="10">
              <Form-item label="拜访人">
                <Row>
                  <Col span="12" style="padding-right: 3px">
                    <Select
                      v-model="chosenDepartment"
                      placeholder="请选择部门"
                      clearable
                      @on-change="onCascaderChange"
                    >
                      <Option
                        v-for="item in department"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>

                  <Col span="12" style="padding-left: 3px">
                    <Select
                      v-model="person"
                      not-found-text="无匹配数据"
                      :disabled="choose"
                      clearable
                      placeholder="请选择拜访人"
                      style="width:100%;"
                      @on-change="onPersonChange"
                    >
                      <Option
                        v-for="item in workmate"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>
                </Row>
              </Form-item>
            </Col>

            <Col span="10">
              <Form-item label="意向">
                <Col span="12" style="padding-right:3px;">
                  <Select
                    v-model="formSearch.demand_ids"
                    not-found-text="无匹配数据"
                    multiple
                    clearable
                    placeholder="请选择需求点"
                    style="width:100%;"
                  >
                    <Option
                      v-for="item in enums.c_demand"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></Option>
                  </Select>

                  <!-- <component
                             style="width:100%;"
                             :is='"SelectUrl"'
                             v-model="formSearch['demand_ids']"
                             placeholder='请选择需求点'
                             :transfer='false'
                             :config="{
                                url: '/common/getSelect/c_demand',
                                placeholder: '请选择需求点',
                                name: 'name',
                                value: 'value',
                                multiple: true }">
                  </component>-->
                </Col>
                <Col span="12" style="padding-left:3px;">
                  <Select
                    v-model="formSearch.intention_type"
                    not-found-text="无匹配数据"
                    clearable
                    placeholder="请选择意向"
                    style="width:100%;"
                  >
                    <Option
                      v-for="item in enums.c_intention"
                      :key="item.value"
                      :label="item.name"
                      :value="item.value"
                    ></Option>
                  </Select>

                  <!-- <component
                             style="width:100%;"
                             :is='"SelectUrl"'
                             v-model="formSearch['intention_type']"
                             placeholder='请选择意向'
                             :transfer='false'
                             :config="{
                               cacheKey: 'c_intention',
                               placeholder: '请选择意向' }">
                  </component>-->
                </Col>
              </Form-item>
            </Col>
          </Row>
          <Row>
            <Col span="10">
              <FormItem label="拜访类型">
                <Select
                  v-model="formSearch.visit_type"
                  not-found-text="无匹配数据"
                  clearable
                  placeholder="请选择拜访类型"
                  style="width:100%;"
                >
                  <Option
                    v-for="item in enums.c_visit_type"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value"
                  ></Option>
                </Select>
              </FormItem>
            </Col>
          </Row>
        </div>
      </search-area>
    </div>

    <div class="operator-button-container">
      <Button
        type="primary"
        class="pull-right"
        style="margin-right: 5px;"
        @click="fastAddRecord"
      >快速新增私募拜访记录</Button>

      <Button type="primary" class="pull-right" style="margin-right: 5px;" @click="showModal">新增拜访记录</Button>

      <Button type="primary" class="pull-right" @click="onExport(3)">导出</Button>

      <!-- <Button
         type="primary"
         class="pull-right"
      @click="showModal">show</Button>-->
    </div>

    <div class="table-container">
      <Table
        class="table-grid"
        ref="commontable"
        border
        :columns="columns"
        :data="tableData"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
      />
    </div>
    <!-- 分页器 -->
    <div class="page-load">
      <div class="float-right">
        <Page
          :total="total"
          placement="top"
          :current="currentPage"
          :page-size="pageSize"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizeChange"
          show-elevator
          show-sizer
          show-total
        />
      </div>
    </div>

    <visit-contact-dialog
      ref="visitContactDialog"
      :showType="'visit'"
      @refreshTable="onSearchClick"
    ></visit-contact-dialog>
    <share ref="share"></share>
    <visit-record-without-target ref="visitRocordWithoutTarget"></visit-record-without-target>
    <fastAddModal ref="fastAddModal"></fastAddModal>
    <addNewVisitRecordModal ref="addNewVisitRecordModal" @refreshTable="onSearchClick"></addNewVisitRecordModal>
  </div>
</template>

<script>
import addNewVisitRecordModal from "./add-new-visit-record-modal";
import searchArea from "../../../../components/search-area";
import SelectUrl from "@/components/inputs/select-url";
import fastAddModal from "../../../visit-record-manager/fast-add-modal";
import visitRecordWithoutTarget from "../../../visit-record-manager/visit-record-without-target";
import visitContactDialog from "../../../contact-manager/visit-contact-dialog";
import share from "../../../visit-record-manager/share";
import { mapGetters } from "vuex";
import { fetchWorkmate, getReciver } from "@/service/getData";
import { getCache } from "@/plugin/cache";
import $ from "jquery";
import getMinusNumber from "@/mixins/getMinusNumber.js";

import moment from "moment";
export default {
  components: {
    searchArea,
    SelectUrl,
    visitRecordWithoutTarget,
    fastAddModal,
    visitContactDialog,
    share,
    addNewVisitRecordModal
  },

  mixins: [getMinusNumber],

  props: {
    innerDepartmentList: {
      type: [Array, Object],
      default: () => []
    }
  },

  data() {
    return {
      // currentOrgIdAndSubOrgIds: [],
      formSearch: {
        contacts_name: "",
        org_name: "",
        visit_time: [],
        order_time: [],
        oc_id: "",
        visit_type: "",
        dept_id: "",
        update_member_id: "",
        depart_id: "",
        intention_type: "",
        demand_ids: []
      },
      choose: true,
      // department: [],
      chosenDepartment: "",
      person: "",
      workmate: [],
      tableData: [],
      tableLoading: false,
      currentPage: 1,
      total: 0,
      pageSize: 10,
      hasMoreParam: false,
      orgId: "",
      downloadParams: {}
    };
  },

  computed: {
    ...mapGetters({
      enums: "getEnums",
      userId: "getUserId"
    }),

    department() {
      return this.innerDepartmentList;
    },
    columns() {
      return [
        {
          title: "拜访时间",
          key: "visit_time",
          width: 90,
          fixed: "left",
          render(h, params) {
            return h(
              "p",
              params.row.visit_time ? params.row.visit_time : "未设"
            );
          }
        },
        {
          title: "拜访人",
          width: 80,
          key: "update_member_id",
          fixed: "left",
          render(h, params) {
            return h("p", params.row.visit_member_name || "--");
          }
        },
        {
          title: "拜访对象",
          key: "contacts_name",
          width: 80,
          fixed: "left",
          render(h, { row }) {
            return row.contacts_name || "--";
          }
        },
        {
          title: "其他接待人",
          key: "other_contacts_name",
          width: 80,
          fixed: "left",
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  maxWidth: "80px",
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  cursor: "pointer"
                },
                attrs: {
                  title:
                    row.other_contacts_name.map(item => item.name).join(",") ||
                    ""
                }
              },
              row.other_contacts_name.map(item => item.name).join(",") || "--"
            );
          }
        },
        // {
        //   title: "机构名称",
        //   key: "org_name",
        //   width: 500,
        //   render: (h, params) => {
        //     if (params.row.bread.length >= 3) {
        //       return h(
        //         "div",
        //         params.row.bread
        //           .map((bread, index, breads) => {
        //             return h(
        //               "a",
        //               index === breads.length - 1
        //                 ? `${bread.title}`
        //                 : `${bread.title}>`
        //             );
        //           })
        //           .splice(1)
        //       );
        //     } else {
        //       return h("a", params.row.org_name);
        //     }
        //   }
        // },
        {
          key: "org_name",
          title: "机构名称",
          width: 200,
          render(h, { row }) {
            return row.org_name || "--";
          }
        },
        {
          title: "部门类型",
          key: "depart_id",
          width: 100,
          render: (h, params) => {
            let cDepart = getCache("c_depart", params.row.depart_id);
            return h("p", cDepart);
          }
        },
        {
          title: "意向",
          width: 100,
          key: "intention_type",
          render: (h, params) => {
            let cDepart = getCache("c_intention", params.row.intention_type);
            return h("p", cDepart);
          }
        },
        {
          title: "需求点",
          width: 200,
          key: "demand_ids",
          render: (h, params) => {
            let demand_ids = params.row.demand_ids
              ? JSON.parse(params.row.demand_ids)
              : [];
            let demandsAll = getCache("c_demand");
            let demands = [];
            for (let i = 0; i < demand_ids.length; i++) {
              for (let j = 0; j < demandsAll.length; j++) {
                if (demandsAll[j].value == demand_ids[i]) {
                  demands.push(demandsAll[j].name);
                }
              }
            }
            if (demands.length == 0) {
              demands.push("未知");
            }
            return h("p", demands ? demands.join(",") : "未知");
          }
        },
        {
          title: "拜访类型",
          key: "visit_type",
          width: 80,
          render: (h, { row }) => {
            let visitType = getCache("c_visit_type");
            let map = {};
            visitType.forEach(v => {
              map[v.value] = v.name;
            });
            return h("span", map[row.visit_type]);
          }
        },
        {
          title: "预设回访时间",
          key: "order_time",
          width: 100,
          render(h, params) {
            return h(
              "p",
              params.row.order_time ? params.row.order_time : "未设"
            );
          }
        },
        {
          title: "更新时间",
          key: "update_time",
          width: 100,
          render: (h, row) => {
            let date = row.row.update_time;
            return h("span", date.split(" ")[0]);
          }
        },
        {
          title: "操作",
          key: "action",
          align: "left",
          width: 140,
          fixed: "right",
          render: (h, params) => {
            return h(
              "div",
              {
                on: {
                  click: e => {
                    e.stopPropagation();
                    return false;
                  }
                }
              },
              [
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    style: {
                      backgroundColor: "none"
                    },
                    on: {
                      click: () => {
                        this.onRowDblclick(params.row);
                      }
                    }
                  },
                  "拜访"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    style: {
                      backgroundColor: "none"
                    },
                    on: {
                      click: () => {
                        this.$refs.share.show(
                          JSON.parse(JSON.stringify(params.row))
                        );
                      }
                    }
                  },
                  "分享"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    style: {
                      backgroundColor: "none"
                    },
                    on: {
                      click: () => {
                        this.deleteVisitRow(
                          params.row.update_member_id,
                          params.row.id
                        );
                      }
                    }
                  },
                  "删除"
                )
              ]
            );
          }
        }
      ];
    }
  },

  watch: {
    chosenDepartment: {
      handler(val) {
        if (val) {
          this.choose = true;
        }
      },
      deep: true
    },

    "formSearch.visit_time": {
      handler(val) {
        if (val && val[0]) {
          this.formSearch.visit_time[0] = this.setTimeZone(val[0]);
          this.formSearch.visit_time[1] = this.setTimeZone(val[1]);
        }
      },
      deep: true
    },

    "formSearch.order_time": {
      handler(val) {
        if (val && val[0]) {
          this.formSearch.order_time[0] = this.setTimeZone(val[0]);
          this.formSearch.order_time[1] = this.setTimeZone(val[1]);
        }
      },
      deep: true
    }
  },

  mounted() {
    // this.getDepartment();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".searchArea", ".operator-button-container", ".page-load"],
      ".table-container"
    );
  },

  methods: {
    showModal() {
      this.$refs.addNewVisitRecordModal.show(
        // this.currentOrgIdAndSubOrgIds,
        this.orgId
      );
    },

    clear() {
      this.workmate = [];
      this.choose = true;
      this.person = "";
      this.formSearch.visit_time = [];
      this.chosenDepartment = "";
      this.formSearch.org_name = "";
      this.formSearch.contacts_name = "";
      this.formSearch.order_time = [];
      this.formSearch.oc_id = "";
      this.formSearch.visit_type = "";
      this.formSearch.dept_id = "";
      this.formSearch.update_member_id = "";
      this.formSearch.depart_id = "";
      this.formSearch.intention_type = "";
      this.formSearch.demand_ids = [];
      this.tableData = [];
      this.hasMoreParam = false;
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 212;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    // 切换页码
    onPageChange(val) {
      this.currentPage = val;
      this.getData();
    },

    // 切换pagesize
    onPageSizeChange(val) {
      this.pageSize = val;
      if (this.currentPage == 1) {
        this.getData();
      } else {
        this.currentPage = 1;
      }
    },

    // 获取部门下拉
    // getDepartment() {
    //   fetchWorkmate().then(res => {
    //     if (res.code == 20000) {
    //       this.department = res.data;
    //     }
    //   });
    // },

    // 拜访人部门变化
    onCascaderChange(val) {
      this.choose = true;
      this.workmate = [];
      this.formSearch.dept_id = val;
      let data = {
        dept_id: this.formSearch.dept_id,
        type: 1
      };
      if (!val) {
        return;
      }
      this.getWorkmate(data);
    },

    // 拜访人变化
    onPersonChange(val) {
      this.formSearch.update_member_id = val;
    },

    // 人员下拉
    getWorkmate(data) {
      if (this.formSearch.dept_id.length == 0) {
        this.choose = true;
      }
      getReciver(data).then(res => {
        if (res.code == 20000) {
          this.workmate = res.data;

          this.choose = false;
        }
      });
    },

    // 切换搜索条件
    changeSearchParam() {
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".searchArea", ".operator-button-container", ".page-load"],
          ".table-container"
        );
      });

      this.hasMoreParam = !this.hasMoreParam;
    },

    // 搜素
    onSearchClick() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getData();
    },

    // 重置搜索条件
    onReset() {
      this.workmate = [];
      this.choose = true;
      this.person = "";
      this.formSearch.visit_time = [];
      this.chosenDepartment = "";
      this.formSearch.org_name = "";
      this.formSearch.contacts_name = "";
      this.formSearch.order_time = [];
      this.formSearch.oc_id = "";
      this.formSearch.visit_type = "";
      this.formSearch.dept_id = "";
      this.formSearch.update_member_id = "";
      this.formSearch.depart_id = "";
      this.formSearch.intention_type = "";
      this.formSearch.demand_ids = [];
      this.onSearchClick();
    },

    onClickTree( orgId, orgName) {
      return new Promise((resolve, reject) => {
        this.workmate = [];
        this.choose = true;
        this.person = "";
        this.formSearch.visit_time = [];
        this.chosenDepartment = "";
        this.formSearch.org_name = "";
        this.formSearch.contacts_name = "";
        this.formSearch.order_time = [];
        this.formSearch.oc_id = "";
        this.formSearch.visit_type = "";
        this.formSearch.dept_id = "";
        this.formSearch.update_member_id = "";
        this.formSearch.depart_id = "";
        this.formSearch.intention_type = "";
        this.formSearch.demand_ids = [];
        this.currentPage = 1;
        this.pageSize = 10;
        this.getData( orgId).then(() => {
          resolve();
        });
      });
    },

    // 获取记录列表
    /**
     * @param currentOrgIdAndSubOrgIds type[array] 当前机构及其子机构的id
     * @param currentOrgId type[string,number]  当前机构的id
     */
    getData( currentOrgId = this.orgId) {
      this.orgId = currentOrgId;
      // this.currentOrgIdAndSubOrgIds = currentOrgIdAndSubOrgIds;
      let params = Object.assign(
        {
          // orgId: currentOrgIdAndSubOrgIds
          org_pid:this.orgId
        },
        this.getSearchParams()
      );
      return new Promise((resolve, reject) => {
        this.tableLoading = true;
        this.$http.get("index/visit", params).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.data;
            this.total = res.data.total;
            resolve();
          } else {
            reject();
          }
        });
      });
    },

    //  搜索参数
    getSearchParams() {
      let params = {};
      let initParam = this.abandonUselessParams(this.formSearch);
      if (initParam.org_name) {
        initParam.org_name = JSON.parse(JSON.stringify(initParam.org_name))
          .trim()
          .split(/[ ]+/);
      } else {
        params.org_name = [];
      }
      if (this.hasMoreParam) {
        params = initParam;
      } else {
        if (initParam.visit_time) {
          for (let key in initParam) {
            if (
              key === "org_name" ||
              key === "contacts_name" ||
              key === "visit_time"
            ) {
              params[key] = initParam[key];
            }
          }
        } else {
          for (let key in initParam) {
            if (key === "org_name" || key === "contacts_name") {
              params[key] = initParam[key];
            }
          }
        }
      }
      this.downloadParams = params;
      return Object.assign(
        {
          rows: this.pageSize,
          page: this.currentPage
        },
        params
      );
    },

    // 清除没有值的参数
    abandonUselessParams(params) {
      let param = {};
      for (let key in params) {
        if (Array.isArray(params[key])) {
          if (params[key].length && params[key][0]) {
            param[key] = params[key];
          }
        } else {
          if (params[key]) {
            param[key] = params[key];
          }
        }
      }
      return param;
    },

    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },

    //  导出参数
    getDownloadParams() {
      return Object.assign(
        {
          rows: this.total > 1000 ? 1000 : this.total,
          page: this.currentPage
        },
        this.downloadParams
      );
    },

    // 导出
    onExport(type) {
      if (this.total === 0) {
        this.$Message.warning("无可导出数据");
        return;
      }

      this.$Message.loading({
        content: "正在导出中，请稍后...",
        duration: 0
      });

      this.$http
        .get("/index/visitexport", this.getDownloadParams())
        .then(res => {
          if (res.code === 20000) {
            const link = document.createElement("a");
            link.href = res.data.url;
            link.target = "_blank";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            this.$Message.destroy();
            this.$Message.info("导出成功！");
          }
        })
        .catch(e => {
          this.$Message.destroy();
          this.$Message.warning("导出失败！");
        });
    },

    // 新增拜访记录
    addVisitWithNoTarget() {
      this.$refs.visitRocordWithoutTarget.show();
    },

    // 快速添加私募拜访记录
    fastAddRecord() {
      this.$refs.fastAddModal.show("fastAdd");
    },

    //   编辑显示模态框
    onRowDblclick(row) {
      let params = {
        tabShow: "visit",
        personId: row.contacts_id,
        personName: row.contacts_name,
        orgId: row.org_id
      };
      this.$refs.visitContactDialog.show(params);
    },

    // 删除
    deleteVisitRow(id, contactId) {
      let that = this;
      if (id == that.userId) {
        that.$Modal.confirm({
          title: "删除",
          content: "删除当前拜访记录？",
          okText: "确定",
          cancelText: "取消",
          loading: true,
          onOk: id => {
            that.$http.del("index/visit/", contactId).then(res => {
              if (res.code === 20000) {
                that.$Message.info("删除成功");
                that.getData();
              } else {
                that.$Message.warning(`${res.msg}`);
              }
              that.$Modal.remove();
            });
          }
        });
      } else {
        this.$Modal.remove();
        this.$Message.warning("只能删除自己的拜访信息");
      }
    }
  }
};
</script>

<style lang="less" scoped>
.table-container {
  margin-top: 15px;
}
.page-load {
  margin: 10px;
  overflow: hidden;
  .float-right {
    float: right;
  }
}
.operator-button-container {
  padding-top: 10px;
  text-align: right;
}
</style>
