<template>
   <Modal
    transfer
    v-model='modal'
    :mask-closable='false'
    width='800'
    >
     <div slot="header">
          <span class="modal-title">{{modalTitle}}</span>
      </div>
       <div slot="close" @click="onCancel">
         <Icon type="ios-close-empty"></Icon>
       </div>
       <div slot="footer">
            <Button
              type="default"
              @click="onCancel">
              取消
            </Button>
            <Button
              type="primary"
              @click="onOk"
              :loading='buttonLoading'>
              确定
            </Button>
       </div>

       <Form
        ref='form'
        :model='form'
        :rules='rules'
        :label-width='80'>
          <Row>
              <Col span="8">
                 <FormItem label="拜访人" prop="visit_member_name">
                   <span>{{form.visit_member_name}}</span>
                 </FormItem>
              </Col>

              <Col span="8" offset='1'>
                 <FormItem label="拜访对象" prop="contacts_id">
                     <Select v-model="form.contacts_id">
                        <Option v-for="(item,index) in visitObjList"
                        :key='index'
                        :value='item.value+""'
                        >
                          {{item.name}}
                        </Option>
                     </Select>
                 </FormItem>
              </Col>
          </Row>

          <Row>
              <Col span="8">
                  <FormItem label="拜访类别" prop="visit_type">
                    <Select  v-model="form.visit_type">
                      <Option v-for="(item, index) in visitTypes" :key="index" :value="item.value">
                        {{item.name}}
                      </Option>
                    </Select>
                  </FormItem>
              </Col>

              <Col span="15" offset='1'>
                  <FormItem label="其他接待人" prop="contacts_ids" >
                    <!--<Select   v-model="form.contacts_ids"  multiple>-->
                      <!--<Option v-for="(item, index) in visitObjList" :key="index" :value="item.value+''">-->
                        <!--{{item.name}}-->
                      <!--</Option>-->
                    <!--</Select>-->
                    <span class="others" :title='otherCantactsName.join(",")'>{{this.otherCantactsName.join(",")}}</span>
                    <Button type="primary" size='small' @click="showOtherTargetsModal">添加</Button>
                  </FormItem>
              </Col>
          </Row>

          <Row>
            <Col span="8">
               <FormItem label="拜访日期" prop="visit_time">
                 <Date-picker type="date" v-model="form.visit_time" placeholder="拜访日期" >
                 </Date-picker>
               </FormItem>
            </Col>

            <Col span="8" offset="1">
               <FormItem label="预设拜访" prop="order_time" >
                 <Date-picker type="date" v-model="form.order_time" placeholder="预设拜访">
                 </Date-picker>
               </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="24">
               <FormItem label="意向" prop="intention_type">
                 <RadioGroup v-model="form.intention_type">
                   <Radio v-for="(item, index) in intentions" :key="index" :label="item.value">
                     {{item.name}}
                   </Radio>
                 </RadioGroup>
               </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="24">
               <FormItem label="需求点" prop="demand_ids">
                 <Checkbox-group v-model="form.demand_ids">
                   <Checkbox v-for="(item, index) in demands" :label="item.value" :key="index">
                     {{ item.name }}
                   </Checkbox>
                 </Checkbox-group>
               </FormItem>
            </Col>
          </Row>

          <Row >
            <Col span="24">
               <FormItem label="交谈内容" prop="chat_ids">
                 <Checkbox-group v-model="form.chat_ids">
                   <Checkbox v-for="(item, index) in chatContents" :label="item.value" :key="index">
                     {{ item.name }}
                   </Checkbox>
                 </Checkbox-group>
               </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="24">
               <FormItem label="日志" prop="visit_content">
                 <Input
                     type="textarea"
                     v-model.trim="form.visit_content"
                     :autosize="{minRows: 3,maxRows: 5}"
                     placeholder="请输入内容">
                 </Input>
               </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="24">
            <Form-item label="提醒谁看" prop="remind_person" style="margin-top: 10px;">
              <Row>
                <Col span="8" style="float:left">
                  <div :class="{chosenPeople:choosePeople}">
                    <div class="show_container" :class="{showMorePeople:showHeight}">

                      <p class="show-content" @click="showPeopleModal">
                        <span
                           v-if="selectedPeopleName.length">
                           {{selectedPeopleName.join(', ')}}
                        </span>

                        <span v-else class="placeholder">单击选择收件人</span>
                      </p>

                      <div
                          class="total"
                          @click="showPeopleModal"
                          title="选择需要分享的人"
                          v-if="this.selectedPeopleName.length">
                          共{{this.selectedPeopleId.length}}人
                      </div>

                      <div class="tool" @click="showMorePeople" v-if="selectedPeopleName.length">
                        <span class="text">{{!showHeight?"更多":"收起"}}</span>

                        <div class="icon-container" v-if="!showHeight">
                          <Icon :size="18" color="#666" class="icon" type="ios-arrow-down"></Icon>
                          <Icon :size="18" color="#666" class="icon second" type="ios-arrow-down"></Icon>
                          <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-down"></Icon>
                        </div>

                        <div class="icon-container" v-else>
                          <Icon :size="18" color="#666" class="icon" type="ios-arrow-up"></Icon>
                          <Icon :size="18" color="#666" class="icon second" type="ios-arrow-up"></Icon>
                          <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-up"></Icon>
                        </div>
                      </div>
                    </div> 
                  </div>

                  <p style="color:red;" v-show="choosePeople">请先选择接收人！</p>
                </Col>

                <Col span="15" offset="1" style="float:left">
                  <Input
                    type="textarea"
                    class="share-container"
                    v-model.trim="shareContent"
                    style="height:40px;"
                    :autosize="{minRows: 1,maxRows: 2}"
                    placeholder="请输入分享内容...">
                  </Input>
                </Col>
              </Row>
          </Form-item>
          </Col>
        </Row>

       </Form>
       <people-tree
          ref="people"
          @getSelectedPeople="getSelectedPeople">
        </people-tree>
     <chooseMutipleTargetsModal
       ref="chooseMutipleTargetsModal"
       @getCheckedTargets='getOtherCantacts'></chooseMutipleTargetsModal>
   </Modal>
</template>

<script>
import { mapGetters } from "vuex";
import {
  fetchSelect,
  putFormData,
  postFormData,
  getMessageCount
} from "@/service/getData";
import peopleTree from "../../../contact-manager/peopleTree";
import chooseMutipleTargetsModal from "@/page/contact-manager/components/choose-mutiple-targets.vue";
import moment from 'moment'
export default {
  components: {
    peopleTree,
    chooseMutipleTargetsModal
  },
  data() {
    return {
      otherCantactsName: [],
      modalTitle: "添加拜访记录",
      modal: false,
      buttonLoading: false,
      initForm: {
        org_id: "",
        visit_member_id: "",
        visit_member_name: "",
        contacts_id: "",
        contacts_name: "",
        visit_type: "",
        contacts_ids: [],
        visit_time: "",
        order_time: "",
        intention_type: "",
        demand_ids: [],
        chat_ids: [],
        visit_content: ""
      },
      form: {
        org_id: "",
        visit_member_id: "",
        visit_member_name: "",
        contacts_name: "",
        contacts_id: "",
        visit_type: "",
        contacts_ids: [],
        visit_time: "",
        order_time: "",
        intention_type: "",
        demand_ids: [],
        chat_ids: [],
        visit_content: ""
      },
      visitObjList: [],
      choosePeople: false,
      showHeight: false,
      selectedPeopleName: [],
      selectedPeople: [],
      selectedPeopleId: [],
      shareContent: "",
      rules: {
        contacts_id: [
          {
            required: true,
            message: "必选",
            trigger: "blur, change"
          }
        ],
        visit_time: [
          {
            required: true,
            type: "date",
            message: "必选",
            trigger: "blur, change"
          }
        ],
        intention_type: [
          {
            required: true,
            message: "必选",
            trigger: "blur, change"
          }
        ],
        visit_content: [
          {
            required: true,
            min: 5,
            max: 1000,
            message: "不少于5个字",
            trigger: "blur, change"
          }
        ]
      }
    };
  },

  watch: {
    selectedPeopleName: {
      handler(val) {
        if (val.length > 0) {
          this.$nextTick(() => {
            this.choosePeople = false;
          });
        }
      },
      deep: true
    }
  },

  computed: {
    ...mapGetters({
      enums: "getEnums",
      user: "getUser"
    }),
    intentions() {
      return this.enums.c_intention;
    },
    demands() {
      return this.enums.c_demand;
    },
    chatContents() {
      return this.enums.c_chat_content;
    },
    visitTypes() {
      return this.enums.c_visit_type;
    },
    visitTypeMapping() {
      return this.enums.c_visit_type_mapping;
    }
  },

  methods: {
    showOtherTargetsModal() {
      let orgId = this.form.org_id;
      if (this.form.contacts_id) {
        this.$refs.chooseMutipleTargetsModal.show(
          orgId,
          this.form.contacts_ids
        );
      } else {
        this.$Message.warning("请先确定拜访对象！");
      }
    },
    getOtherCantacts(otherContacts) {
      this.otherCantactsName = otherContacts.map(item => item.name);
      this.form.contacts_ids = otherContacts.map(item => item.id);
    },
    // 获取需要提醒的人
    getSelectedPeople(selectedPerson) {
      this.selectedPeople = JSON.parse(JSON.stringify(selectedPerson));
      this.selectedPeopleName = selectedPerson.map(person => {
        return person.memberName;
      });
      this.selectedPeopleId = selectedPerson.map(person => {
        return person.id;
      });
    },

    //  显示模态框
    show( orgId) {
      this.choosePeople = false;
      this.getOtherVisitObjList(orgId);
      this.$set(this.form, "visit_member_name", this.user.trueName);
      this.$set(this.form, "visit_member_id", this.user.id);
      this.$set(this.form, "visit_type", this.getVisitTypeOfCurrentUser());
      this.$set(this.form, "org_id", orgId);
      this.modal = true;
    },

    // 获取拜访对象和其他拜访人列表
    getOtherVisitObjList(orgId) {
      let params = {
        // org_id: orgId
        org_pid:orgId
      };
      fetchSelect("index/contactMatch", params).then(resp => {
        this.otherLoading = false;
        if (resp.code === 20000) {
          this.visitObjList = resp.data.map(item => {
            return {
              name: item.name,
              value: item.value + ""
            };
          });
        }
      });
    },

    // 变更时间为格林威治时区标准
    setTimeZone(time) {
        let localTime =  moment(time).format('YYYY-MM-DD')
      return localTime;
    },

    // 设置当前用户的拜访类型
    getVisitTypeOfCurrentUser() {
      let deptId = this.user.dept_id;
      let mapOfFilter = this.visitTypeMapping.filter(m => {
        return m.name === `${deptId}`;
      });
      return mapOfFilter.length ? mapOfFilter[0].value : "99";
    },

    // 提交
    onOk() {
      let selectedPeopleId = JSON.parse(JSON.stringify(this.selectedPeopleId));
      let shareContent = this.shareContent;
      new Promise((resolve, reject) => {
        this.$refs.form.validate(valid => {
          if (valid) {
            let data = JSON.parse(JSON.stringify(this.form));
            if (!selectedPeopleId.length && shareContent.trim()) {
              this.choosePeople = true;
              return;
            } else {
              this.choosePeople = false;
            }

            postFormData("index/visit", data).then(resp => {
              if (resp.code === 20000) {
                this.$Message.success("新增拜访记录成功！");
                resolve(resp);
              } else {
                this.$Message.error("新增拜访记录失败！");
                reject();
              }
            });
          } else {
            reject();
            this.$Message.error("请按要求填充表单");
          }
        });
      }).then(resp => {
        //判断是否需要发送提醒消息
        if (selectedPeopleId.length) {
          //已经选中提醒的人
          let content =
            shareContent ||
            `${this.user.trueName}给$name分享了一条拜访记录[系统日志]`;
          let visit_id = resp.data.id;
          let params = {
            type: 4,
            to_id: selectedPeopleId,
            message: content,
            visit_id: visit_id
          };
          postFormData("msg/send", params)
            .then(resp => {
              if (resp.code === 20000) {
                this.$Message.success("已为您发送提醒");
                this.$emit("refreshTable");
                this.onCancel();
              } else {
                this.$Message.error("发送提醒失败 " + resp.msg);
              }

              //获取消息数
              getMessageCount().then(res => {
                let count = res.data.total;
                this.$store.dispatch("setMessageCount", {
                  messageCount: count
                });
              });
            })
            .then(() => {
              this.clearShareParams();
            });
        } else {
          this.$emit("refreshTable");
          this.onCancel();
          this.clearShareParams();
        }
      });
    },

    // 清空分享内容
    clearShareParams() {
      this.selectedPeople = [];
      this.selectedPeopleId = [];
      this.selectedPeopleName = [];
      this.shareContent = "";
    },

    // 重置表单
    resetForm() {
      this.form = JSON.parse(JSON.stringify(this.initForm));
      this.otherCantactsName = [];
      this.$refs.form.resetFields();
      this.clearShareParams();
    },

    // 点击取消
    onCancel() {
      this.resetForm();
      this.modal = false;
    },

    // 显示内部人员选择模态框
    showPeopleModal() {
      this.$refs.people.show(null, this.selectedPeopleId);
    },

    // 显示、隐藏更多分享人员
    showMorePeople() {
      if (!this.showHeight) {
        this.showHeight = true;
      } else {
        this.showHeight = false;
      }
    }
  }
};
</script>

<style lang="less" scoped>
.modal-title {
  color: #1c2438;
  font-size: 14px;
  font-weight: bold;
}
.show_container {
  width: 100%;
  height: 40px;
  min-height: 40px;
  border: 1px solid #dddee1;
  border-radius: 5px;
  position: relative;
  padding-bottom: 10px;
  word-wrap: break-word;
  .show-content {
    width: 100%;
    height: 100%;
    overflow: hidden;
    padding: 5px;
    line-height: 22px;
  }
  .total {
    display: inline-block;
    position: absolute;
    bottom: -10px;
    right: 10px;
    padding: 0 10px;
    background-color: white;
    height: 20px;
    line-height: 20px;
  }
  .tool {
    cursor: pointer;
    width: 60px;
    height: 20px;
    margin: 0px 5px;
    padding: 0 10px;
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translate(-50%, 0);
    background-color: #fff;
    .icon-container {
      float: left;
      display: inline-block;
      position: relative;
      margin-left: 2px;
      .icon {
        display: block;
        position: absolute;
        top: -3px;
        &.second {
          top: 0px;
        }
        &.thrid {
          top: 3px;
        }
      }
    }
    .text {
      float: left;
      line-height: 20px;
      font-size: 12px;
      color: #666;
    }
  }
}

.showMorePeople.show_container {
  height: auto;
}
.chosenPeople {
  border: 1px solid red;
  border-radius: 6px; // width: 500px;
}
// .others {
//   vertical-align: top;
//   display: inline-block;
//   max-width: 250px;
//   white-space: nowrap;
//   overflow: hidden;
//   text-overflow: ellipsis;
// }
</style>
