<template>
    <attachmentTable ref="attachTable" :orgId="orgId" class="table-container"></attachmentTable>
</template>

<script>
import attachmentTable from "../../../../components/common-components/attachment/attachment-table";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import $ from "jquery";
export default {
  components: {
    attachmentTable
  },

  mixins: [getMinusNumber],
  data() {
    return {
      orgId: "",
    };
  },

  mounted() {
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".operator-button", ".page-load"],
      ".table-area"
    );
  },

  methods: {
    getData( currentOrgId = this.orgId) {
      this.orgId = currentOrgId;
      setTimeout(() => {
        this.$refs.attachTable.getAttachMent();
      }, 0);
    },

    onClickTree( currentOrgId = this.orgId) {
      this.orgId = currentOrgId;
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          this.$refs.attachTable.getAttachMent();
          resolve();
        }, 0);
      });
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);

        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 212;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    }
  }
};
</script>

<style lang="less" scoped>
</style>

