<template>
  <div class="customer-details-container">
    <!-- <div class="line" v-show="!loading&&!contentLoading"></div> -->

    <div class="demo-spin-col" span="8" v-if="loading">
      <Spin fix>
        <Icon type="load-c" size="18" class="demo-spin-icon-load"></Icon>
        <div>拼命加载中</div>
      </Spin>
    </div>

    <div class="content-container" v-show="!loading">
      <div class="department-container" :class="{'department-tree-fold':this.foldStatus}">
        <department-tree @changeDepartMent="changeDepartMent" ref="departmentTree"></department-tree>
      </div>
      <div class="fold-container" @click="changeFoldStatus" :title="foldTitle">
        <Icon :type="iconType" :size="20"></Icon>
      </div>
      <div class="tab-container">
        <Tabs type="card" :animated="false" v-model="tabName" @on-click="onClickTab">
          <TabPane
            v-for="(item,index) in tabList"
            :key="index"
            :label="item.label"
            :name="item.component"
          >
            <div class="demo-spin-col" span="8" v-if="contentLoading">
              <Spin fix>
                <Icon type="load-c" size="18" class="demo-spin-icon-load"></Icon>
                <div>拼命加载中</div>
              </Spin>
            </div>

            <div class="tab-pane-container" v-show="!contentLoading">
              <component
                :is="item.component"
                :ref="item.component"
                :innerDepartmentList="innerDepartmentList"
                :salerList="salerList"
                @refreshData="show"
                @getOrgNameString="getOrgNameString"
                :orgNameString="orgNameString"
              ></component>
            </div>
          </TabPane>
        </Tabs>
      </div>
    </div>
  </div>
</template>

<script>
import departmentTree from "./department-tree/department-tree";
import orgDetails from "./org-details/org-details";
import contactsList from "./contact-list/contact";
import accountsList from "./account-list/accounts-list";
import visitRecords from "./visit-records/visit-records";
import contractsSituation from "./constracts-situation/contracts-situation";
import attachment from "../components/attachment/index";
import fundLink from "./fund-link-config/index.vue";
import { mapGetters } from "vuex";
import { map } from "lodash";
export default {
  props: ["pid", "orgType"],
  components: {
    departmentTree,
    orgDetails,
    contactsList,
    accountsList,
    visitRecords,
    contractsSituation,
    attachment,
    fundLink
  },
  data() {
    return {
      foldStatus: false,
      tabName: "contactsList",
      orgId: "",
      contentLoading: false,
      loading: false,
      tabData: {},
      orgNameString: "",
      companyId: "",
      innerDepartmentList: [],
      salerList: []
    };
  },

  computed: {
    tabList() {
      let baseList = [
        {
          label: "详细信息",
          component: "orgDetails"
        },
        {
          label: "联系人列表",
          component: "contactsList"
        },
        {
          label: "账号列表",
          component: "accountsList"
        },
        {
          label: "拜访记录",
          component: "visitRecords"
        },
        {
          label: "合同情况",
          component: "contractsSituation"
        },
        {
          label: "附件文档",
          component: "attachment"
        },
        {
          label: "直营店套餐",
          component: "fundLink"
        }
      ];

      if (this.ifShowContractsSituation) {
        return baseList;
      } else {
        return baseList.filter(item => {
          return item.component !== "contractsSituation";
        });
      }
    },

    iconType() {
      return this.foldStatus ? "chevron-right" : "chevron-left";
    },

    foldTitle() {
      return this.foldStatus ? "展开" : "收起";
    },

    ...mapGetters({
      userInfo: "getUser"
    }),

    //  是否有合同模块权限
    ifShowContractsSituation() {
      return this.userInfo.auth.functional.includes("constractsModule");
    }
  },

  destroyed() {
    this.foldStatus = false;
  },

  mounted() {
    this.show();
  },

  methods: {
    // 切换机构树的折叠状态
    changeFoldStatus() {
      this.foldStatus = !this.foldStatus;
    },

    // 点击tab标签栏才刷新页面
    /**
     * @orgId {当前机构的id}
     * @orgName {当前机构名称}
     * @orgNameString {当前机构全称}
     * @companyId {公司id（C0）}
     * @orgType {机构类型}
     */
    onClickTab(ref) {
      this.$refs[ref][0].getData(
        this.orgId,
        this.orgName,
        this.orgNameString,
        this.companyId,
        this.orgType
      );
    },

  
    // 点击树形图，切换机构
    changeDepartMent( orgId, orgName, orgNameString, companyId) {
      this.orgId = orgId;
      this.orgName = orgName;
      this.orgNameString = orgNameString;
      this.companyId = companyId;
      this.$nextTick(() => {
        this.$refs[this.tabName][0]
          .onClickTree(
            this.orgId,
            this.orgName,
            this.companyId,
            this.orgType,
            this.orgNameString
          )
          .then(() => {
            this.loading = false;
          });
      });
    },

    // 显示机构
    show(orgId = this.pid) {
      this.orgId = this.pid;
      this.loading = true;
      // 请求完树的数据后会emit到本组件的changeDepartMent方法请求具体的其他数据
      this.$refs.departmentTree.getTreeData(this.orgId).catch(e => {
        this.loading = false;
      });
      this.getInnerDepartment();
      this.getInnerSaler();
    },

    getOrgNameString(orgNameString) {
      this.orgNameString = orgNameString;
    },

    getInnerDepartment() {
      this.$http
        .get("dept/getAllSelect")
        .then(res => {
          if (res.code === 20000) {
            this.innerDepartmentList = res.data;
          } else {
            this.$Message.error(`获取内部部门列表失败:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.$Message.error("获取内部部门失败：网络请求错误！");
        });
    },

    getInnerSaler() {
      let params = {
        dept_id: 16,
        type: 1
      };
      this.$http
        .get("dept/getUserByDept", params)
        .then(res => {
          if (res.code === 20000) {
            this.salerList = map(res.data, person => person).filter(
              item => item.status
            );
          } else {
            this.$Message.error(`获取内部部门列表失败:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.$Message.error("获取内部部门失败：网络请求错误！");
        });
    }
  }
};
</script>

<style lang="less" scoped>
.department-container {
  transition: width 2s ease;

  height: 100%;
  padding: 0 15px;
  overflow: auto;
  float: left;
  // min-width: 200px;
  // margin-right: 10px;
}

.fold-container {
  float: left;
  position: relative;
  width: 30px;
  height: 40px;
  cursor: pointer;
  line-height: 40px;
  text-align: center;
  top: 40%;
  transform: translateY(-20px);
  border: 1px solid #cccccc;
}

.department-tree-fold {
  width: 0;
  padding: 0;
  overflow: hidden;
}
.tab-container {
  .ivu-tabs.ivu-tabs-card.ivu-tabs-no-animation {
    height: -webkit-fill-available;
    border-left: 1px solid #cccccc;
    padding-left: 15px;
  }
}

.customer-details-container {
  height: 100%;
  .content-container {
    height: 100%;
    &::after {
      content: " ";
      height: 0;
      line-height: 0;
      clear: both;
      display: block;
      visibility: hidden;
    }
  }
}
.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}
@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}
.demo-spin-col {
  height: 100px;
  position: relative;
  border: 1px solid #eee;
}
</style>
