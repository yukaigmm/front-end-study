<template>
  <div class="contact-wrap">
    <div class="search-area">
      <search-area
        showExpand
        ref="searchArea"
        @onKeydownSearch="onSearchClick"
        @changeSearchParam="changeSearchParam"
      >
        <div slot="default">
          <Row>
            <i-col span="8">
              <form-item label="联系人信息">
                <i-input v-model.trim="searchData.keywords" placeholder="姓名/电话/职务/邮箱"/>
              </form-item>
            </i-col>

            <i-col span="8" :offset="1">
              <form-item label="最近拜访时间">
                <date-picker
                  v-model="searchData.visit_time"
                  style="width:100%"
                  placeholder="请输入最近拜访时间"
                />
              </form-item>
            </i-col>

            <i-col span="7">
              <div class="search-btn">
                <i-button type="primary" @click="onSearchClick">搜索</i-button>
                <i-button @click="reset">重置</i-button>
              </div>
            </i-col>

            <i-col span="8">
              <form-item label="账号类型">
                <i-select
                  v-model="searchData.account_type"
                  transfer
                  clearable
                  placeholder="请选择账号类型"
                >
                  <i-option
                    v-for="item in accountTypeOptions"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>

            <i-col span="8" :offset="1">
              <form-item label="账号开通状态">
                <i-select
                  v-model="searchData.account_status"
                  transfer
                  clearable
                  placeholder="请选择账号开通状态"
                >
                  <i-option
                    v-for="item in statusOptions"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>
          </Row>
        </div>

        <div slot="extend">
          <Row>
            <i-col span="8">
              <form-item label="账号付费情况">
                <i-select
                  v-model="searchData.account_pay"
                  transfer
                  clearable
                  placeholder="请选择账号付费情况"
                >
                  <i-option
                    v-for="item in payStatusOptions"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>
            <i-col span="8" :offset="1">
              <form-item label="更新人">
                <i-col span="11">
                  <i-select
                    v-model="searchData.dept_id"
                    placeholder="请选择部门"
                    @on-change="onDepartmentChange"
                    clearable
                  >
                    <i-option
                      v-for="item in innerDepartmentList"
                      :key="item.value"
                      :value="item.value"
                    >{{item.label}}</i-option>
                  </i-select>
                </i-col>

                <i-col span="12" :offset="1">
                  <i-select
                    v-model="searchData.update_member_id"
                    placeholder="请选择更新人"
                    clearable
                    :disabled="ifUpdateDisable"
                  >
                    <i-option
                      v-for="item in updateMemberList"
                      :key="item.value"
                      :value="item.value"
                    >{{item.label}}</i-option>
                  </i-select>
                </i-col>
              </form-item>
            </i-col>

            <i-col span="8">
              <form-item label="更新时间">
                <date-picker
                  style="width:100%;"
                  type="daterange"
                  placeholder="请选择日期"
                  v-model="searchData.update_time"
                ></date-picker>
              </form-item>
            </i-col>
          </Row>
        </div>
      </search-area>
    </div>

    <div class="action-area">
      <!-- <Button type="primary" @click="exportTable">导出</Button> -->
      <Button type="primary" @click="addContacts">添加</Button>
      <div class="tip-content">请完善客户的手机号和名片信息，无此两项则无法开通账号。</div>
    </div>

    <div class="table-area">
      <Table
        :columns="columns"
        :data="tableData"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        border
      />
    </div>

    <div class="page-load">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      />
    </div>
    <add-contact-modal
      ref="addContactModal"
      :orgNameString="orgNameString"
      @refreshContactTable="onSearchClick"
    ></add-contact-modal>
    <account-condition-modal ref="accountConditionModal"/>
    <visit-contact-dialog ref="visitContactDialog" @refreshTable="onSearchClick"/>
  </div>
</template>


<script>
import SearchArea from "@/components/search-area.vue";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import $ from "jquery";
import moment from "moment";
import AccountConditionModal from "../../../contact/components/account/account-condition-modal.vue";
import { mapGetters } from "vuex";
import VisitContactDialog from "../../../contact-manager/visit-contact-dialog.vue";
import addContactModal from "@/components/common-components/customer/customer-add-edit-modal.vue";

export default {
  components: {
    SearchArea,
    AccountConditionModal,
    VisitContactDialog,
    addContactModal
  },

  mixins: [getMinusNumber],

  props: {
    innerDepartmentList: {
      type: [Array, Object],
      default: () => []
    },
    orgNameString: {
      type: String,
      default: ""
    }
  },

  data() {
    return {
      updateMemberList: [],
      searchData: {},
      tableData: [],
      tableLoading: false,
      orgId: "",
      total: 0,
      currentPage: 1,
      pageSize: 10,
      fullfillLogo: require("@/assets/addMsg.png"),
      accountTypeOptions: [
        {
          value: 1,
          label: "组合大师"
        },
        {
          value: 2,
          label: "基金大师"
        },
        {
          value: 3,
          label: "私募直连"
        },
        {
          value: 4,
          label: "蓝V"
        }
      ],
      statusOptions: [
        {
          value: 1,
          label: "已开通"
        },
        {
          value: 2,
          label: "未开通"
        }
      ],
      payStatusOptions: [
        {
          value: 1,
          label: "已付费"
        },
        {
          value: 2,
          label: "未付费"
        }
      ],
      hasSearchExpaned: false
    };
  },

  computed: {
    ...mapGetters({
      emnus: "getEnums",
      userInfo: "getUser",
      userId: "getUserId"
    }),

    portraitList() {
      return this.emnus.c_port_all;
    },

    sexOptions() {
      return this.emnus.c_sex;
    },
    ageOptions() {
      return this.emnus.c_age;
    },
    columns() {
      let commonCellStyle = {
        "text-overflow": "ellipsis",
        overflow: "hidden",
        "white-space": "nowrap",
        cursor: "pointer"
      };

      return [
        {
          title: "姓名",
          key: "name",
          width: 100,
          fixed: "left",
          render: (h, { row }) => {
            let ifMissInfo =
              !row.telephone || !row.visiting_card_url || !row.email;

            if (ifMissInfo) {
              return h(
                "div",
                {
                  style: {
                    display: "flex",
                    "justify-content": "flex-satrt",
                    "align-items": "center"
                  }
                },
                [
                  h("div", {
                    attrs: {
                      title: "请补充联系人信息"
                    },
                    style: {
                      cursor: "pointer",
                      "background-image": `url(${this.fullfillLogo})`,
                      "background-size": "100%",
                      "background-repeat": "no-repeat",
                      width: "20px",
                      height: "20px",
                      "margin-right": "10px"
                    }
                  }),
                  h(
                    "div",
                    {
                      style: {
                        flex: 1
                      }
                    },
                    row.name || "--"
                  )
                ]
              );
            } else {
              return h("span", row.name || "--");
            }
          }
        },
        {
          title: "手机",
          key: "telephone",
          width: 100,
          fixed: "left",
          render: (h, { row }) => {
            return h("span", row.telephone || "--");
          }
        },
        {
          title: "公司",
          key: "org_name",
          width: 300,
          render: (h, { row }) => {
            if (row.bread && row.bread.length) {
              let companyInfo = row.bread[1] || {};

              if (!companyInfo.id) {
                return h("span", "--");
              }

              let tab = {
                activeName: companyInfo.title,
                pid: companyInfo.id,
                name: `${companyInfo.title}${companyInfo.id}`,
                component: "departmentDetails",
                isShow: true
              };
              return h(
                "a",
                {
                  attrs: {
                    title: "点击查看详情"
                  },
                  on: {
                    click: e => {
                      this.$store.dispatch("setTabs", tab);
                      e.stopPropagation();
                    }
                  }
                },
                companyInfo.title || "--"
              );
            } else {
              let tab = {
                activeName: row.org_name,
                pid: row.org_id,
                name: `${row.org_name}${row.org_id}`,
                component: "departmentDetails",
                isShow: true
              };
              return h(
                "a",
                {
                  attrs: {
                    title: "点击查看详情"
                  },
                  on: {
                    click: e => {
                      this.$store.dispatch("setTabs", tab);
                      e.stopPropagation();
                    }
                  }
                },
                row.org_name || "--"
              );
            }
          }
        },
        {
          title: "部门",
          key: "departmentName",
          width: 200,
          render: (h, { row }) => {
            if (row.bread && row.bread.length) {
              return h(
                "div",
                row.bread
                  .map((bread, index, breads) => {
                    return h(
                      "a",
                      {
                        attrs: {
                          title: "点击查看详情"
                        },
                        on: {
                          click: e => {
                            let tab = {
                              activeName: bread.title,
                              pid: bread.id,
                              name: `${bread.title}${bread.id}`,
                              component: "departmentDetails",
                              isShow: true
                            };

                            this.$store.dispatch("setTabs", tab);
                            e.stopPropagation();
                          }
                        }
                      },
                      index === breads.length - 1
                        ? `${bread.title}`
                        : `${bread.title}>`
                    );
                  })
                  .splice(2)
              );
            } else {
              return h("span", "总部");
            }
          }
        },
        {
          title: "职务",
          key: "post",
          width: 100,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "90px"
                },
                attrs: {
                  title: row.post
                }
              },
              row.post || "--"
            );
          }
        },
        {
          title: "名片",
          key: "visiting_card_url",
          width: 80,
          render(h, { row }) {
            let url;
            if (row.visiting_card_url) {
              let picUrl = JSON.parse(JSON.stringify(row.visiting_card_url));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? "http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";
                picUrl = `Uploads/crm/${row.visiting_card_url}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        },
        {
          title: "画像",
          key: "portrait",
          width: 100,
          render: (h, { row }) => {
            let portrait = [];
            if (row.portrait) {
              portrait = JSON.parse(row.portrait);
            }

            if (portrait.length) {
              return h(
                "div",
                portrait.map(item => {
                  let text = "";
                  let style = null;
                  let matchOne = this.portraitList.filter(
                    c => c.value == item
                  )[0];
                  text = matchOne.name;
                  style = matchOne.style;
                  return h(
                    "span",
                    {
                      style: {
                        "border-radius": "10%",
                        "max-width": "80px",
                        "min-width": "40px",
                        display: "inline-block",
                        "text-align": "center",
                        padding: "3px 5px",
                        cursor: "pointer",
                        ...style
                      }
                    },
                    text
                  );
                })
              );
            } else {
              return h("span", "--");
            }
          }
        },
        {
          title: "邮箱",
          key: "email",
          width: 120,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "100px"
                },
                attrs: {
                  title: row.email
                }
              },
              row.email || "--"
            );
          }
        },
        {
          title: "性别",
          key: "sex",
          width: 80,
          render: (h, { row }) => {
            let matchItem = this.sexOptions.filter(
              item => item.value == row.sex
            )[0];
            let text = matchItem ? matchItem.name : "--";
            return h("span", text);
          }
        },
        {
          title: "年龄",
          key: "age",
          width: 80,
          render: (h, { row }) => {
            let matchItem = this.ageOptions.filter(
              item => item.value == row.age
            )[0];
            let text = matchItem ? matchItem.name : "--";
            return h("span", text);
          }
        },
        {
          title: "微信",
          key: "wechat",
          width: 120,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "110px"
                },
                attrs: {
                  title: row.wechat
                }
              },
              row.wechat || "--"
            );
          }
        },
        {
          title: "更新时间",
          key: "update_time",
          width: 100,
          render: (h, { row }) => {
            return h(
              "p",
              {
                attrs: {
                  title: `${row.update_time}`
                }
              },
              `${row.update_time.substring(0, 10)}`
            );
          }
        },
        {
          title: "更新人",
          key: "update_member_id",
          width: 90,
          render: (h, { row }) => {
            return h("p", `${row.update_member_name || "--"}`);
          }
        },
        {
          title: "操作",
          width: 200,
          fixed: "right",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.editContact(row);
                    }
                  }
                },
                "编辑"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.visitContact(row);
                    }
                  }
                },
                "拜访"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.$refs.accountConditionModal.show(row);
                    }
                  }
                },
                "开通账号"
              ),
              h(
                "div",
                {
                  attrs: {
                    class:
                      row.create_member_id === this.userId || this.canDelete
                        ? "deleteBtn"
                        : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (
                        row.create_member_id !== this.userId &&
                        !this.canDelete
                      ) {
                        return;
                      }
                      this.deleteContact(row.id);
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ];
    },

    canDelete() {
      return this.userInfo.auth.functional.includes("deleteContact");
    },

    // 更新人联动
    ifUpdateDisable() {
      return !this.searchData.dept_id;
    }
  },

  mounted() {
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".action-area", ".page-load"],
      ".table-area",
      150
    );
  },

  methods: {
    // 获取内部部门列表
    getInnerDepartmentList() {
      this.$http
        .get("dept/getAllSelect")
        .then(res => {
          if (res.code === 20000) {
            this.innerDepartmentList = res.data;
          } else {
            this.$Message.error(`获取内部部门列表失败:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.$Message.error("获取内部部门失败：网络请求错误！");
        });
    },

    //  获取更新人列表
    getUpdateMemberList() {
      let params = {
        dept_id: this.searchData.dept_id,
        type: 1
      };

      this.$http
        .get("dept/getUserByDept", params)
        .then(res => {
          if (res.code === 20000) {
            this.updateMemberList = res.data;
          } else {
            this.$Message.error(`获取更新人列表失败:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.$Message.error("获取更新人列表失败：网络请求错误！");
        });
    },

    // 内部部门变化联动更新人列表
    onDepartmentChange(val) {
      this.updateMemberList = [];
      this.$set(this.searchData, "update_member_id", "");
      if (!val) {
        return;
      }

      this.getUpdateMemberList();
    },

    //  新增联系人
    addContacts() {
      this.$refs.addContactModal.show("add", this.orgId);
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass,
      constant = 100
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight =
        wholeContainer.height() - cutElementHeightTotle - constant;
      let minusNumber = this.getMinusNumberOfFixedTable();
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    onClickTree(orgId, orgName) {
      return new Promise((resolve, reject) => {
        this.$set(this.searchData, "name", "");
        this.$set(this.searchData, "post", "");
        this.$set(this.searchData, "telephone", "");
        this.$set(this.searchData, "email", "");
        this.$set(this.searchData, "dept_id", "");
        this.$set(this.searchData, "update_member_id", "");
        this.$set(this.searchData, "update_time", "");
        this.currentPage = 1;
        this.pageSize = 10;
        this.getData(orgId).then(() => {
          resolve();
        });
      });
    },

    getParams() {
      let form = JSON.parse(JSON.stringify(this.searchData));
      let params = {};

      let hideKeys = [
        "keywords",
        "visit_time",
        "account_type",
        "account_status"
      ];

      if (!this.hasSearchExpaned) {
        hideKeys.forEach(key => {
          if (form[key]) {
            params[key] = form[key];
          }
        });
      } else {
        params = {
          ...form
        };
      }

      if (params.visit_time) {
        params.visit_time = moment(params.visit_time).format("YYYY-MM-DD");
      } else {
        delete params.visit_time;
      }

      if (
        params.update_time &&
        params.update_time.length &&
        params.update_time[0] &&
        params.update_time[1]
      ) {
        params.update_time[0] = moment(params.update_time[0]).format(
          "YYYY-MM-DD"
        );
        params.update_time[1] = moment(params.update_time[0]).format(
          "YYYY-MM-DD"
        );
      } else {
        delete params.update_time;
      }

      return params;
    },

    getData(orgId = this.orgId, orgName, orgNameString) {
      this.tableLoading = true;
      this.orgId = orgId;
      let form = this.getParams();
      let params = {
        rows: this.pageSize,
        page: this.currentPage,
        org_pid: this.orgId,
        ...form
      };

     
      return new Promise((resolve, reject) => {
        this.$http
          .get("/index/contact", params)
          .then(res => {
            this.tableLoading = false;
            if (res.code === 20000) {
              this.tableData = res.data.data;
              this.total = res.data.total;
              resolve();
            } else {
              reject();
              this.$Message.error(`获取表格数据失败:${res.msg}`);
            }
          })
          .catch(err => {
            reject();
            console.error(err);
            this.$Message.error("获取表格数据失败:网络请求错误!");
          });
      });
    },

    changeSearchParam(val) {
      this.hasSearchExpaned = val;
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".search-area", ".action-area", ".page-load"],
          ".table-area",
          150
        );
      });
    },

    onPageChange(val) {
      this.currentPage = val;
      this.getData();
    },

    onPageSizeChange(val) {
      this.pageSize = val;
      this.getData();
    },

    // 删除联系人
    deleteContact(id) {
      this.$Modal.confirm({
        title: "删除",
        content: "删除当前联系人？",
        okText: "确定",
        cancelText: "取消",
        loading: true,
        onOk: () => {
          this.$http
            .del("/index/contact", id)
            .then(res => {
              if (res.code === 20000) {
                this.$Message.success("删除成功");
                this.onSearchClick();
              } else {
                this.$Message.error(`删除失败：${res.msg}`);
              }
              this.$Modal.remove();
            })
            .catch(err => {
              console.error(err);
              this.$Modal.remove();
              this.$Message.error(`删除失败：网络请求错误！`);
            });
        }
      });
    },

    //  编辑联系人
    editContact(row) {
      let params = {
        tabShow: "user",
        personId: row.id,
        personName: row.name,
        orgId: row.org_id
      };
      this.$refs.visitContactDialog.show(params);
    },

    // 拜访联系人
    visitContact(row) {
      let params = {
        tabShow: "visit",
        personId: row.id,
        personName: row.name,
        orgId: row.org_id
      };
      this.$refs.visitContactDialog.show(params);
    },

    //  导出数据
    exportTable() {
      if (this.total == 0) {
        this.$Message.info("无可导出数据！");
        return;
      }

      let form = JSON.parse(JSON.stringify(this.searchData));
      let params = {
        rows: this.total > 1000 ? 1000 : this.total,
        page: this.currentPage,
        org_pid: this.orgId,
        ...form
      };

      if (
        params.update_time &&
        params.update_time.length &&
        params.update_time[0] &&
        params.update_time[1]
      ) {
        params.update_time[0] = moment(params.update_time[0]).format(
          "YYYY-MM-DD"
        );
        params.update_time[1] = moment(params.update_time[0]).format(
          "YYYY-MM-DD"
        );
      } else {
        delete params.update_time;
      }

      this.$Message.loading({
        content: "正在导出中，请稍候...",
        duration: 0
      });
      this.$http
        .get("/index/contactexport", params)
        .then(res => {
          this.$Message.destroy();
          if (res.code === 20000) {
            window.open(`${window.location.origin}/${res.data.url}`);

            this.$Message.success("导出成功！");
          } else {
            this.$Message.error(`导出失败：${res.msg}`);
          }
        })
        .catch(err => {
          this.$Message.destroy();
          console.error(err);
          this.$Message.error("导出失败:网络请求错误！");
        });
    },

    onSearchClick() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getData();
    },

    reset() {
      this.searchData = {};
      this.onSearchClick();
    }
  }
};
</script>

<style lang="less" scoped>
@import "../../../contact/css/index.less";
.action-area {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  //   padding: 10px 0;
  .tip-content {
    color: #2d8cf0;
  }
}
</style>
