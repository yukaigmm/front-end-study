<template>
  <div class="content-container customer-contact-list">
    <div class="search-area keydown-box">
      <search-area
        ref="form"
        @changeSearchParam="changeSearchParam"
        @onKeydownSearch="onSearchClick"
      >
        <div slot="default">
          <Row>
            <Col span="10">
              <Form-item label="关键词">
                <Input
                  key="orgName"
                  style="width:100%;"
                  v-model.trim="formSearch.org_name"
                  placeholder="机构名称"
                ></Input>
              </Form-item>
            </Col>
            <Col span="10">
              <Form-item label="姓名职务">
                <Row>
                  <Col span="11">
                    <Input v-model.trim="formSearch.name" placeholder="姓名"></Input>
                  </Col>

                  <Col span="12" offset="1">
                    <Input v-model.trim="formSearch.post" placeholder="职务"></Input>
                  </Col>
                </Row>
              </Form-item>
            </Col>

            <Col span="4" style="text-align: right;">
              <div class="button-search">
                <Button type="primary" @click="onSearchClick">搜索</Button>
                <Button @click="onReset" style="margin-right:0;">重置</Button>
              </div>
            </Col>
          </Row>
          <Row>
            <Col span="10" offset>
              <Form-item label="联系方式">
                <Row>
                  <Col span="11">
                    <Input v-model.trim="formSearch.telephone" placeholder="电话"></Input>
                  </Col>

                  <Col span="12" offset="1">
                    <Input v-model.trim="formSearch.email" placeholder="邮箱"></Input>
                  </Col>
                </Row>
              </Form-item>
            </Col>
            <Col span="10" v-if="hasMoreParam">
              <FormItem label="标签">
                <Select v-model="formSearch.portrait" clearable placeholder="请选择标签" multiple>
                  <Option v-for="item in emnus.c_port_all" :value="item.value" :key="item.id">
                    <Tag :style="item.style">{{item.name}}</Tag>
                  </Option>
                </Select>
              </FormItem>
            </Col>
          </Row>
        </div>

        <div slot="extend">
          <Row>
            <Col span="10">
              <FormItem label="更新人">
                <Row>
                  <Col span="11">
                    <Select
                      v-model="chosenDepartment"
                      placeholder="请选择部门"
                      clearable
                      @on-change="onCascaderChange"
                    >
                      <Option
                        v-for="item in department"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>

                  <Col span="12" offset="1">
                    <Select
                      v-model="person"
                      not-found-text="无匹配数据"
                      :disabled="choose"
                      clearable
                      placeholder="更新人"
                      style="width:100%;"
                      @on-change="onPersonChange"
                    >
                      <Option
                        v-for="item in select_update"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>
                </Row>
              </FormItem>
            </Col>

            <Col span="10" offset>
              <FormItem label="更新时间">
                <DatePicker
                  style="width:100%;"
                  type="daterange"
                  format="yyyy-MM-dd"
                  placeholder="选择日期"
                  v-model="formSearch.update_time"
                ></DatePicker>
              </FormItem>
            </Col>
          </Row>

          <Row>
            <Col span="10">
              <FormItem label="机构">
                <Row>
                  <Col span="11">
                    <Select v-model="formSearch.oc_id" clearable placeholder="请选择">
                      <Option
                        v-for="item in emnus.c_org"
                        :value="item.value"
                        :key="item.value"
                      >{{item.name}}</Option>
                    </Select>
                  </Col>

                  <Col span="12" offset="1">
                    <Select
                      v-model="formSearch.depart_id"
                      not-found-text="无匹配数据"
                      clearable
                      placeholder="请选择机构"
                      style="width:100%;"
                    >
                      <Option
                        v-for="item in emnus.c_depart"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>
                </Row>
              </FormItem>
            </Col>

            <Col span="10" offset>
              <FormItem label="客户类型">
                <Select
                  v-model="formSearch.contacts_type"
                  not-found-text="无匹配数据"
                  clearable
                  placeholder="请选择客户类型"
                  style="width:100%;"
                >
                  <Option
                    v-for="item in emnus.c_usertype"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value"
                  ></Option>
                </Select>
              </FormItem>
            </Col>
          </Row>
        </div>
      </search-area>
    </div>

    <div class="operator-button-container">
      <Button type="primary" @click="addContacts">添加</Button>
      <div class="tip-content">请完善客户的手机号和名片信息，无此两项则无法开通账号。</div>
    </div>

    <div class="table-container">
      <Table
        :columns="tableColumns"
        :data="tableData"
        border
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
      ></Table>
    </div>

    <div class="page-load">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      ></Page>
    </div>
    <add-contact-modal
      ref="addContactModal"
      :orgNameString="orgNameString"
      @refreshContactTable="onSearchClick"
    ></add-contact-modal>

    <!-- 子组件，显示拜访界面 -->
    <visit-contact-dialog ref="visitContactDialog" @refreshTable="onSearchClick"></visit-contact-dialog>

    <addAccountModal ref="addAccountModal" @refreshTable="onSearchClick"></addAccountModal>
    <unactiveFofModal ref="unactiveFofModal" @refreshTable="onSearchClick"></unactiveFofModal>
    <unactiveFmModal ref="unactiveFmModal" @refreshTable="onSearchClick"></unactiveFmModal>
    <addFmAccountModal ref="addFmAccountModal" @refreshTable="onSearchClick"/>
  </div>
</template>

<script>
import $ from "jquery";
import searchArea from "../../../../components/search-area";
import addContactModal from "@/components/common-components/customer/customer-add-edit-modal.vue";
import { mapGetters } from "vuex";
import { fetchWorkmate, getReciver } from "@/service/getData";
import visitContactDialog from "../../../contact-manager/visit-contact-dialog";
import addAccountModal from "@/page/account-justify/components/add-account-modal";
import moment from "moment";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import unactiveFofModal from "../../../contact-manager/components/unactive-fof-account-modal.vue";
import unactiveFmModal from "../../../contact-manager/components/unactive-fm-accounts-modal.vue";
import addFmAccountModal from "../../../fm-account-manager/components/add-account";

export default {
  mixins: [getMinusNumber],
  props: ["orgNameString"],
  components: {
    addContactModal,
    searchArea,
    visitContactDialog,
    addAccountModal,
    unactiveFofModal,
    unactiveFmModal,
    addFmAccountModal
  },
  data() {
    return {
      addMsgLogo: require("../../../../assets/addMsg.png"),
      currentOrgIdAndSubOrgIds: [],
      total: 0,
      currentPage: 1,
      pageSize: 10,
      hasMoreParam: false,
      orgId: "",
      person: "",
      choose: true,
      chosenDepartment: "",
      department: [],
      select_update: [],
      formSearch: {
        portrait: [],
        update_time: [],
        org_name: "",
        dept_id: [],
        name: "",
        post: "",
        update_member_id: "",
        depart_id: "",
        contacts_type: "",
        oc_id: "",
        telephone: "",
        email: ""
      },
      tableColumns: [
        {
          key: "name",
          title: "姓名",
          width: 100,
          fixed: "left",
          render: (h, { row }) => {
            if (!row.telephone || !row.visiting_card_url || !row.email) {
              return h(
                "div",
                {
                  style: {
                    display: "flex",
                    "justify-content": "flex-satrt",
                    "align-items": "center"
                  }
                },
                [
                  h("div", {
                    attrs: {
                      title: "请补充联系人信息"
                    },
                    style: {
                      cursor: "pointer",
                      backgroundImage: `url(${this.addMsgLogo})`,
                      backgroundSize: "100%",
                      backgroundRepeat: "no-repeat",
                      width: "20px",
                      height: "20px",
                      "margin-right": "10px"
                    }
                  }),
                  h("div", row.name || "--")
                ]
              );
            } else {
              return h("span", row.name || "--");
            }
          }
        },
        {
          key: "telephone",
          title: "联系电话",
          width: 100,
          fixed: "left",
          render(h, { row }) {
            return row.telephone || "--";
          }
        },
        {
          key: "org_name",
          title: "机构名称",
          width: 200,
          render(h, { row }) {
            return row.org_name || "--";
          }
        },
        {
          key: "post",
          title: "职务",
          width: 100,
          render(h, { row }) {
            return row.post || "--";
          }
        },
        {
          key: "email",
          title: "邮箱",
          width: 220,
          render(h, { row }) {
            return row.email || "--";
          }
        },
        {
          title: "名片",
          key: "visiting_card_url",
          width: 80,
          render(h, { row }) {
            let url;
            if (row.visiting_card_url) {
              let picUrl = JSON.parse(JSON.stringify(row.visiting_card_url));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? "http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";
                picUrl = `Uploads/crm/${row.visiting_card_url}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        },
        {
          key: "create_member_name",
          title: "责任人",
          width: 100,
          render(h, { row }) {
            return row.create_member_name || "--";
          }
        },
        {
          title: "账号开通",
          key: "createAccount",
          width: 160,
          align: "center",
          fixed: "right",
          render: (h, { row }) => {
            let fofFlag = false;
            let fmFlag = false;
            let fmTitle = "";
            let fofTitle = "";
            //  账号信息补全、有正常状态的账号时组合大师账号不可操作
            // fof_accounts 1:有账号 2：没有账号 3：有账号状态不正常 (基金大师账号保持一致)
            fofFlag =
              fofFlag ||
              (!row.telephone || !row.visiting_card_url || !row.email) ||
              row.fof_accounts == 1;

            fmFlag =
              fmFlag ||
              !this.canAdd ||
              (!row.telephone || !row.visiting_card_url) ||
              row.fm_accounts == 1 ||
              !row.company_id;

            if (fofFlag) {
              fofTitle =
                !row.telephone || !row.visiting_card_url || !row.email
                  ? "联系人信息缺失"
                  : "已有账号";
            }

            if (fmFlag) {
              if (!this.canAdd) {
                fmTitle = "没有权限";
              } else if (!row.telephone || !row.visiting_card_url) {
                fmTitle = "联系人信息缺失";
              } else if (row.fm_accounts == 1) {
                fmTitle = "已有账号";
              } else if (!row.company_id) {
                fmTitle = "联系人公司id缺失";
              }
            }

            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: fofFlag ? "disabledBtn" : "deleteBtn",
                    title: fofTitle
                  },
                  on: {
                    click: e => {
                      if (fofFlag) {
                        return;
                      }
                      e.stopPropagation();

                      if (row.fof_accounts == 3) {
                        this.$refs.unactiveFofModal.show(row);
                      } else {
                        this.$refs.addAccountModal.show(row);
                      }
                    }
                  }
                },
                "组合大师"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: fmFlag ? "disabledBtn" : "deleteBtn",
                    title: fmTitle
                  },

                  on: {
                    click: e => {
                      if (fmFlag) {
                        return;
                      }
                      e.stopPropagation();

                      if (row.fm_accounts == 3) {
                        this.$refs.unactiveFmModal.show(row);
                      } else {
                        let info = {
                          linkMan: "",
                          mobile: "",
                          position: "",
                          visitingCardUrl: ""
                        };

                        info.linkMan = row.name;
                        info.mobile = row.telephone;
                        info.position = row.post;
                        info.visitingCardUrl = row.visiting_card_url;
                        info.sex = +row.sex;
                        this.$refs.addFmAccountModal.show(
                          {},
                          row.company_id,
                          info
                        );
                      }
                    }
                  }
                },
                "基金大师"
              )
            ]);
          }
        },
        {
          title: "操作",
          fixed: "right",
          width: 200,
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.editContact(row.org_id, row.id);
                    }
                  }
                },
                "编辑"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.onVisit(row);
                    }
                  }
                },
                "拜访"
              ),
              h(
                "div",
                {
                  attrs: {
                    class:
                      row.create_member_id === this.userId || this.canDelete
                        ? "deleteBtn"
                        : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (
                        row.create_member_id !== this.userId &&
                        !this.canDelete
                      ) {
                        return;
                      }
                      this.deleteContact(row.id);
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ],
      tableData: [],
      tableLoading: false
    };
  },

  computed: {
    ...mapGetters({
      emnus: "getEnums",
      userInfo: "getUser",
      userId: "getUserId"
    }),
    canAdd() {
      return this.userInfo.auth.functional.includes("addFmAccount");
    },

    canDelete() {
      return this.userInfo.auth.functional.includes("deleteContact");
    }
  },

  watch: {
    chosenDepartment: {
      handler(val) {
        if (val) {
          this.choose = true;
        }
      },
      deep: true
    },
    "formSearch.update_time": {
      handler(val) {
        if (val.length && val[0]) {
          this.formSearch.update_time[0] = this.setTimeZone(val[0]);
          this.formSearch.update_time[1] = this.setTimeZone(val[1]);
        }
      },
      deep: true
    }
  },

  mounted() {
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".operator-button-container", ".page-load"],
      ".table-container"
    );
    this.getDepartment();
  },

  methods: {
    //   显示拜访模态框
    onVisit(row) {
      let params = {
        tabShow: "visit",
        personId: row.id,
        personName: row.name,
        orgId: row.org_id
      }
      this.$refs.visitContactDialog.show(params);
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 212;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getData(this.currentOrgIdAndSubOrgIds);
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      if (this.currentPage == 1) {
        this.getData(this.currentOrgIdAndSubOrgIds);
      } else {
        this.currentPage = 1;
      }
    },

    // 选择不同的人时的事件
    onPersonChange(val) {
      this.formSearch.update_member_id = val;
    },

    //获取部门下拉
    getDepartment() {
      fetchWorkmate().then(res => {
        if (res.code == 20000) {
          this.department = res.data;
        }
      });
    },

    // 部门选择发生变化
    onCascaderChange(val) {
      this.choose = true;
      this.select_update = [];
      this.formSearch.dept_id = val;
      let data = {
        dept_id: this.formSearch.dept_id,
        type: 1
      };
      if (!val) {
        return;
      }
      this.getWorkmate(data);
    },

    //根据部门级联选择更新人
    getWorkmate(data) {
      if (this.formSearch.dept_id.length == 0) {
        this.choose = true;
      }
      getReciver(data).then(res => {
        if (res.code == 20000) {
          this.select_update = res.data;
          this.choose = false;
        }
      });
    },

    //  新增联系人
    addContacts() {
      this.$refs.addContactModal.show("add", this.orgId);
    },

    onClickTree(currentOrgIdAndSubOrgIds, orgId, orgName) {
      return new Promise((resolve, reject) => {
        this.select_update = [];
        this.choose = true;
        this.$set(this.formSearch, "update_time", []);
        this.$set(this.formSearch, "dept_id", "");
        this.$set(this.formSearch, "name", "");
        this.$set(this.formSearch, "post", "");
        this.$set(this.formSearch, "update_member_id", "");
        this.$set(this.formSearch, "depart_id", "");
        this.$set(this.formSearch, "contacts_type", "");
        this.$set(this.formSearch, "portrait", []);
        this.$set(this.formSearch, "oc_id", "");
        this.$set(this.formSearch, "telephone", "");
        this.$set(this.formSearch, "email", "");
        this.$set(this.formSearch, "org_name", "");
        this.chosenDepartment = "";
        this.currentPage = 1;
        this.pageSize = 10;
        this.getData(currentOrgIdAndSubOrgIds, orgId).then(() => {
          resolve();
        });
      });
    },

    // 获取联系人列表
    getData(
      currentOrgIdAndSubOrgIds,
      orgId = this.orgId,
      orgName,
      orgNameString
    ) {
      this.currentOrgIdAndSubOrgIds = currentOrgIdAndSubOrgIds;
      this.orgId = orgId;
      let params = Object.assign(
        {
          pid: this.currentOrgIdAndSubOrgIds
        },
        this.getSearchParam()
      );
      return new Promise((resolve, reject) => {
        this.tableLoading = true;
        this.$http.get("index/contact", params).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.data;
            this.total = res.data.total;
            // this.setMaxHeightOfFixedTable(
            //   ".org-infomation-modal .ivu-modal-body",
            //   [".search-area", ".operator-button-container", ".page-load"],
            //   ".table-area"
            // );
            resolve();
          } else {
            reject();
          }
        });
      });
    },

    editContact(orgId, personId) {
      this.$refs.addContactModal.show("edit", orgId, personId);
    },

    // 删除联系人
    deleteContact(id) {
      this.$Modal.confirm({
        title: "删除",
        content: "删除当前联系人？",
        okText: "确定",
        cancelText: "取消",
        loading: true,
        onOk: () => {
          this.$http.del("/index/contact", id).then(res => {
            if (res.code === 20000) {
              this.$Message.info("删除成功");
              this.getData(this.currentOrgIdAndSubOrgIds);
            } else {
              this.$Message.error(`${res.msg}`);
            }
            this.$Modal.remove();
          });
        }
      });
    },

    // 搜索
    onSearchClick() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getData(this.currentOrgIdAndSubOrgIds);
    },

    // 重置搜索
    onReset() {
      this.select_update = [];
      this.choose = true;
      (this.chosenDepartment = ""),
        this.$set(this.formSearch, "update_time", []);
      this.$set(this.formSearch, "org_name", "");
      this.$set(this.formSearch, "dept_id", "");
      this.$set(this.formSearch, "name", "");
      this.$set(this.formSearch, "post", "");
      this.$set(this.formSearch, "update_member_id", "");
      this.$set(this.formSearch, "depart_id", "");
      this.$set(this.formSearch, "contacts_type", "");
      this.$set(this.formSearch, "portrait", []);
      this.$set(this.formSearch, "oc_id", "");
      this.$set(this.formSearch, "telephone", "");
      this.$set(this.formSearch, "email", "");
      // this.person = "";
      if (this.pageSize == 10 && this.currentPage == 1) {
        this.getData(this.currentOrgIdAndSubOrgIds);
      } else {
        this.pageSize = 10;
        this.currentPage = 1;
      }
    },

    // 搜索条件展开关闭事件
    changeSearchParam() {
      this.hasMoreParam = !this.hasMoreParam;
      // this.setMaxHeightOfFixedTable(
      //   ".org-infomation-modal .ivu-modal-body",
      //   [".search-area", ".operator-button-container", ".page-load"],
      //   ".table-area"
      // );

      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".search-area", ".operator-button-container", ".page-load"],
          ".table-container"
        );
      });
    },

    // 搜索参数
    getSearchParam() {
      let params = {};
      if (this.hasMoreParam) {
        if (
          !this.formSearch.update_time[0] &&
          !this.formSearch.update_time[1]
        ) {
          for (var key in this.formSearch) {
            if (key != "update_time") {
              params[key] = this.formSearch[key];
            }
          }
        } else {
          params = this.formSearch;
        }
        if (params.org_name) {
          params.org_name = params.org_name.trim().split(/\s+/);
        }
      } else {
        for (let key in this.formSearch) {
          if (
            key == "name" ||
            key == "post" ||
            key == "telephone" ||
            key == "email"
          ) {
            params[key] = this.formSearch[key];
          } else if (key == "org_name") {
            let words = this.formSearch[key];
            params[key] = words.trim().split(/\s+/);
          }
        }
      }
      return Object.assign(
        {
          rows: this.pageSize,
          page: this.currentPage
        },
        params
      );
    },

    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    }
    // 获得从顶级机构开始计算的当前机构位置
  }
};
</script>

<style lang="less" scoped>
.operator-button-container {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  padding: 10px 0;
  .tip-content {
    color: #2d8cf0;
  }
}
.page-load {
  text-align: right;
  padding-top: 10px;
}
</style>
