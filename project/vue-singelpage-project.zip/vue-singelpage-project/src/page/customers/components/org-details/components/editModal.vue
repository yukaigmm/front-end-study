<template>
   <Modal
     v-model="modal"
     :title="modalTitle"
     :mask-closable="false"
     width='700'
   >
     <div slot="close" @click="cancel">
       <Icon type="ios-close-empty"></Icon>
     </div>

     <div slot="footer">
      <Button  @click="cancel">取消</Button>
      <Button type="primary"  @click="ok" :loading="btnLoading">提交</Button>
    </div>
    <div class="tips" v-if="fatherCompany">
      注：该机构将直接加入<b>{{fatherCompany}}</b>下。
    </div>
    <Form
       v-loading='loading'
     element-loading-text='拼命加载中...'
      ref='form'
      :model='departmentData'
      :label-width='90'
      :rules='validateRules' >
        <Row>
          <Col span="12">
            <FormItem label='部门' prop='org_name'>
              <Input
                v-model.trim="departmentData.org_name"
                placeholder="请输入部门名称"></Input>
            </FormItem>
          </Col>

          <Col span="12">
            <FormItem label='类别' prop='depart_id'>
               <template v-if="showType==='add'">
                 <Select
                    v-model="departmentData.depart_id"
                    not-found-text='无匹配数据'
                    clearable
                    placeholder="请选择类别"
                    style="width:100%;">
                      <Option
                        v-for="item in departmentTypeList"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value-0">
                      </Option>
                 </Select>
               </template>

               <template v-else>
                 <Row>
                   <Col span="11">
                      <Select
                         v-model="departmentData.oc_id"
                         clearable
                         placeholder="请选择"
                         :disabled="departmentData.oc_id==2&&!ifAdmin">
                         <Option
                            v-for="item in companyTypeList"
                            :value="item.value-0"
                            :key="item.value">
                             {{item.name}}
                         </Option>
                      </Select>
                   </Col>
                   <Col span="12" offset="1">
                      <Select
                         v-model="departmentData.depart_id"
                         not-found-text='无匹配数据'
                         clearable
                         placeholder="请选择类别"
                         style="width:100%;">
                           <Option
                             v-for="item in departmentTypeList"
                             :key="item.value"
                             :label="item.name"
                             :value="item.value-0">
                           </Option>
                      </Select>
                   </Col>
                 </Row>
               </template>
            </FormItem>
          </Col>

          <Col span="12">
            <FormItem label='电话' prop='phone_num'>
               <Input
                 placeholder="请输入电话"
                 v-model.trim="departmentData.phone_num"
                 style="width:100%;"></Input>
            </FormItem>
          </Col>


          <Col span="12">
            <FormItem label='机构网址' prop='website'>
                <Input
                  placeholder="请输入机构网址"
                  v-model.trim="departmentData.website"
                  style="width:100%;"></Input>
            </FormItem>
          </Col>


          <Col span="12">
            <FormItem label='画像' prop='portrait'>
                <Select
                   v-model="departmentData.portrait"
                   multiple
                   placeholder="请选择">
                   <Option
                     v-for="item in portraitList"
                     :value="item.value"
                     :key="item.value">
                     <Tag :style="item.style">{{item.name}}</Tag>
                   </Option>
                </Select>
            </FormItem>
          </Col>


          <Col span="12">
            <FormItem label='销售标签' prop='sales_portrait'>
                 <Select
                    v-model="departmentData.sales_portrait"
                    multiple
                    placeholder="请选择">
                    <Option
                      v-for="item in salesPortraitList"
                      :value="item.value"
                      :key="item.value">
                      <Tag :style="item.style">{{item.name}}</Tag>
                   </Option>
                </Select>
            </FormItem>
          </Col>


          <Col span="12">
            <FormItem label='客户类型' prop='cust_type_ids'>
                <Select
                   v-model="departmentData.cust_type_ids"
                   multiple
                   placeholder="请选择">
                  <Option
                     v-for="item in customerType"
                     :value="item.value"
                     :key="item.value">
                     <Tag :style="item.style">{{item.name}}</Tag>
                  </Option>
                </Select>
            </FormItem>
          </Col>

           <Col span="12">
            <FormItem label='备案编码' prop='register_num'>
                <Input
                   v-model.trim="departmentData.register_num"
                   placeholder="请输入"></Input>
            </FormItem>
          </Col>

          <Col span="24">
            <FormItem label='地域' prop='area_ids'>
                 <component
                   is="SelectLinkage"
                   v-model="departmentData.area_ids"
                   :config="{
                       useForSearch: true,
                       cacheKey: 'c_area_all',
                       row: 'dialog-form-item-row'}"
                    style="width:100%;">
                 </component>
            </FormItem>
          </Col>

          <Col span="24">
            <FormItem label='详细街道' prop='area_info'>
             <Input
                placeholder="请输入详细街道"
                v-model.trim="departmentData.area_info"
                style="width:100%;"></Input>
            </FormItem>
          </Col>



           <Col span="24">
            <FormItem label='备注' prop='remark'>
                 <Input
                   type="textarea"
                   v-model.trim='departmentData.remark'
                   placeholder="请输入备注"
                   :autosize='{minRows:3,maxRows:5}'></Input>
            </FormItem>
          </Col>
        </Row>
    </Form>
   </Modal>
</template>

<script>
import { mapGetters } from "vuex";
import SelectLinkage from "@/components/inputs/select-linkage.vue";
import $ from "jquery";

export default {
  components: {
    SelectLinkage
  },
  data() {
    return {
      btnLoading:false,
      modal: false,
      modalTitle: "新增机构",
      departmentData: {
        org_name: "",
        depart_id: "",
        oc_id: "",
        phone_num: "",
        website: "",
        portrait: [],
        sales_portrait: [],
        cust_type_ids: [],
        area_ids: "",
        area_info: "",
        register_num: "",
        remark: ""
      },
      fatherCompany:'',
      showType: "",
      validateRules: {
        org_name: [
          {
            required: true,
            message: "请输入部门名称",
            trigger: "change, blur"
          }
        ],
        depart_id: [
          {
            required: true,
            message: "请选择机构类型",
            type: "number",
            trigger: "change"
          }
        ],
        phone_num: [
          {
            pattern: /(^1(3|4|5|6|7|8|9)\d{9}$)|(^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$)/,
            message: "请输入正确电话 如:400-6802928",
            trigger: "change, blur"
          }
        ],
        website: [
          {
            pattern: /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/,
            message: "参照 http://www.smppw.com",
            trigger: "change, blur"
          }
        ]
      },
      orgId: "",
      loading: false
    };
  },

  watch: {
    "departmentData.portrait": {
      handler(val) {
        this.setTagStyle();
      },
      deep: true
    },
    "departmentData.cust_type_ids": {
      handler(val) {
        this.setTagStyle();
      },
      deep: true
    },
    "departmentData.sales_portrait": {
      handler(val) {
        this.setTagStyle();
      },
      deep: true
    }
  },

  computed: {
    ...mapGetters({
      enums: "getEnums",
      userId: "getUserId"
    }),

    companyTypeList() {
      return this.enums.c_org;
    },

    portraitList() {
      return this.enums.c_port_all_org;
    },

    departmentTypeList() {
      return this.enums.c_depart;
    },

    customerType() {
      return this.enums.c_port_all_cust;
    },

    salesPortraitList() {
      return this.enums.c_port_all_sale;
    },

    ifAdmin() {
      return this.enums.c_admin_acc
        .filter(item => item.name === "机构销售")
        .map(item => item.value)
        .includes(this.userId + "");
    }
  },

  methods: {
    // 设置标签样式
    setTagStyle() {
      setTimeout(() => {
        let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");
        let selectTag = $(this.$el).find(".ivu-select-selection .ivu-tag span");
        let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
        let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
        let tagStyle = [];
        for (let i = 0; i < tagContianer.length; i++) {
          for (let j = 0; j < selectTag.length; j++) {
            if (
              $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
            ) {
              $(selectTags.get(j))[0].setAttribute(
                "style",
                $(tagContianer.get(i))[0].getAttribute("style")
              );
            }
          }
        }
      }, 10);
    },

    cancel() {
      this.orgId = "";
      this.modal = false;
      this.departmentData = {
        org_name: "",
        depart_id: "",
        oc_id: "",
        phone_num: "",
        website: "",
        portrait: [],
        sales_portrait: [],
        cust_type_ids: [],
        area_ids: "",
        area_info: "",
        register_num: "",
        remark: ""
      };
      this.fatherCompany = '';
       this.btnLoading = false;
      this.$refs.form.resetFields();
    },

    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.btnLoading = true;
          if (this.showType === "add") {
            this.addOrg();
          } else {
            this.editOrg();
          }
        } else {
          this.$Message.warning("请按红色提示填写表单！");
        }
      });
    },

    /**
     * @param showType [string] 显示类型 可选值 add/edit
     */
    show(showType, orgId,orgName) {
      this.fatherCompany = orgName;
      this.showType = showType;
      this.orgId = orgId;
      this.modal = true;
      if (this.showType === "edit") {
        this.modalTitle = "编辑机构";
        this.getDetails();
      } else {
        this.modalTitle = "新增机构";
        this.$refs.form.resetFields();
      }
    },

    //  编辑时获取机构详情
    getDetails() {
      this.loading = true;
      this.$http.get(`/index/organization/${this.orgId}`).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          let data = JSON.parse(JSON.stringify(res.data));
          for (let key in this.departmentData) {
            if (data[key]) {
              this.departmentData[key] = data[key];
            }
          }
          if (!Array.isArray(this.departmentData.portrait)) {
            this.departmentData.portrait = this.departmentData.portrait
              ? Array.isArray(JSON.parse(this.departmentData.portrait))
                ? JSON.parse(this.departmentData.portrait)
                : []
              : [];
          }
          this.departmentData.sales_portrait = this.departmentData
            .sales_portrait
            ? JSON.parse(this.departmentData.sales_portrait)
            : [];
          this.departmentData.cust_type_ids = this.departmentData.cust_type_ids
            ? this.departmentData.cust_type_ids
            : [];
        } else {
          this.$Message.error("获取数据失败");
        }
      });
    },

    // 编辑机构
    editOrg() {
      let params = {
        ...this.departmentData
      };

      this.$http
        .putWithoutId(`/index/organization/${this.orgId}`, params)
        .then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.$Message.success("编辑成功");
            this.cancel();
            this.$emit("refreshCurrentData");
          } else {
            this.$Message.error(res.msg);
          }
        });
    },

    // 添加机构
    addOrg() {
      let params = {
        pid: this.orgId,
        ...this.departmentData
      };

      this.$http.post("/index/organization", params).then(res => {
         this.btnLoading = false;
        if (res.code === 20000) {
          this.$Message.success("添加成功");
          this.cancel();
          this.$emit("refreshData");
        } else {
          this.$Message.error(res.msg);
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.tips{
  color:rgb(237, 63, 20);
  padding-left: 43px;
  padding-bottom:15px;
  b{
    font-size: 14px;
  }
}
</style>


