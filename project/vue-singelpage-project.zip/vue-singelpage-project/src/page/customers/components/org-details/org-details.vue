<template>
  <div class="org-detail-container"
  v-loading='tableLoading'
  element-loading-text='拼命加载中'>
     <div class="btn-area">
       <Button type="primary" title="添加子机构" @click="addSubOrganazition">添加</Button>
       <Button type="primary" title="编辑" @click="editCurrentOrganazition">编辑</Button>
     </div>

     <p v-for="(item,index) in basicInfomationList" :key="index" class="detail-container">
       <span class="label-container">{{item.label}}:</span>
       <span class="value-container">{{orgDetails[item.valueKey]||'--'}}</span>
    </p>

    <p class="detail-container">
      <span class="label-container">销售标签:</span>
      <span class="value-container">
            <Tag
              v-for="(item,index) in orgDetails.sales_portrait"
              :style="item.style"
              :key="index"
               >
                {{item.name}}
             </Tag>
             <template  v-if='orgDetails.sales_portrait&&!orgDetails.sales_portrait.length'> -- </template>
      </span>
    </p>

    <p class="detail-container">
      <span class="label-container">画像:</span>
      <span class="value-container">
            <Tag
              v-for="(item,index) in orgDetails.portrait"
              :style="item.style"
              :key="index"
               >
                {{item.name}}
             </Tag>
             <template v-if='orgDetails.portrait&&!orgDetails.portrait.length'> -- </template>
      </span>
    </p>

   

    <div class="remark-container">
      <span class="remark-label-container">备注:</span>

      <div class="remark-input value-container">
        {{orgDetails.remark||'--'}}
      </div>
    </div>

    <editModal ref='editModal' @refreshData='refreshData' @refreshCurrentData='getData'></editModal>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import { flatten } from "lodash";
import editModal from "./components/editModal";

export default {
  components: {
    editModal
  },

  data() {
    return {
      tableLoading:false,
      areas: [],
      inputKey: "",
      orgType: "",
      orgId: "",
      tagSelectContainer: "tag-select-container",
      addTagContainer: "add-tag-container",
      tag: "",
      tagOptions: [],
      orgDetails: {},
      basicInfomationList: [
        {
          label: "机构名称",
          valueKey: "org_name"
        },
        {
          label: "机构类型",
          valueKey: "orgType"
        },
        {
          label: "客户类型",
          valueKey: "customerType"
        },
        {
          label: "机构电话",
          valueKey: "phone_num"
        },
        {
          label: "机构网址",
          valueKey: "website"
        },
        {
          label: "备案编码",
          valueKey: "register_num"
        },
        {
          label: "地区",
          valueKey: "areas"
        },
        {
          label: "办公地址",
          valueKey: "address"
        }
      ]
    };
  },

  computed: {
    ...mapGetters({
      emnus: "getEnums"
    })
  },

  created() {
    this.tagOptions = this.emnus.c_port_all_sale;
  },

  methods: {
    // 添加机构
    addSubOrganazition() {
      this.$refs.editModal.show("add", this.orgId,this.orgDetails.org_name);
    },

    //  编辑机构
    editCurrentOrganazition() {
      this.$refs.editModal.show("edit", this.orgId);
    },

    refreshData() {
      this.$emit("refreshData");
    },

   

    onClickTree(orgId){
       return new Promise(resolve=>{
         this.getData(orgId).then(()=>{
           resolve();
         })
       })
    },

    //  获取机构详情
    getData(orgId=this.orgId) {
      this.orgId = orgId;
      return new Promise((resolve, reject) => {
        this.tableLoading = true;
        this.$http.get(`/index/organization/${orgId}`).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            res.data.sales_portrait = res.data.sales_portrait
              ? JSON.parse(res.data.sales_portrait)
              : [];
            res.data.portrait = res.data.portrait
              ? JSON.parse(res.data.portrait)||[]
              : [];
            this.orgDetails = res.data;
            if (this.orgDetails.oc_id) {
              this.orgDetails.orgType = this.emnus.c_org.filter(item => {
                return item.value == this.orgDetails.oc_id;
              })[0]["name"];
            }

            if (
              this.orgDetails.cust_type_ids &&
              this.orgDetails.cust_type_ids.length
            ) {
              let cusArr = [];
              this.orgDetails.cust_type_ids.forEach(idItem => {
                this.emnus.c_port_all_cust.forEach(item => {
                  if (item.value == idItem) {
                    cusArr.push(item.name);
                  }
                });
              });
              this.orgDetails.customerType = cusArr.join("/");
            }
            this.orgDetails.sales_portrait = flatten(
              this.orgDetails.sales_portrait.map(item => {
                return this.emnus.c_port_all_sale.filter(
                  tagItem => item == tagItem.value
                );
              })
            );

            this.orgDetails.portrait = flatten(
              this.orgDetails.portrait.map(item => {
                return this.emnus.c_port_all_org.filter(
                  tagItem => item == tagItem.value
                );
              })
            );

            this.areas = [];
            if (this.orgDetails.area_ids) {
              let ids = this.orgDetails.area_ids;
              let idsArr = ids.split(",");
              this.getAreas(idsArr, this.emnus.c_area_all);
              this.orgDetails.areas = this.areas.join(",");
            }

            this.inputKey = Date.now();

            this.getOrgNameString(res.data);
            resolve();
          } else {
            reject();
          }
        });
      });
    },

    // 获取地区
    getAreas(ids, areas) {
      let idArr = ids;
      let id = idArr.shift();
      areas.forEach(item => {
        if (id && id == item.value) {
          this.areas.push(item.name);
          if (item.children && item.children.length) {
            this.getAreas(idArr, item.children);
          } else {
            return;
          }
        } else {
          return;
        }
      });
    },

    clear() {
      this.$nextTick(() => {
        this.orgDetails = {
          org_name: "",
          org_short_name: "",
          oc_id: "",
          website: "",
          register_num: "",
          address: "",
          remark: ""
        };
      });
    },
    // 获取breadList
    getOrgNameString(data){
      let breadList = [];
      data.breadcrumb.forEach((breadItem, index) => {
        if(index > 0){
          breadList.push(breadItem.title);
        }
      });
      let orgNameString = breadList.join(">")
      this.$emit("getOrgNameString",orgNameString)
    }
  }
};
</script>

<style lang="less" scoped>
.add-tag-container {
  display: inline-block;
  width: 22px;
  height: 22px;
}
.tag-select-container {
  display: inline-block;
  width: 0;
  transition: width 0.2s ease;
}
.tag-select-container-show {
  display: inline-block;
  width: 200px;
  transition: all 0.2s ease;
}
.tag-inner-conainer {
  width: auto;
  margin-right: 200px;
}
.tag-content-container {
  padding-top: 10px;
  &::after {
    content: ".";
    display: block;
    height: 0;
    width: 0;
    line-height: 0;
    clear: both;
  }
}
.selector-container {
  width: 200px;
  // float: right;
  position: absolute;
  top: -2px;
  left: 30px;
}
.value-container {
  padding-left: 5px;
  font-size: 14px;
  font-weight: 600;
}
.label-container {
  display: inline-block;
  width: 60px;
  text-align: right;
}
.tags-container {
  position: relative;
}
.detail-container {
  line-height: 22px;
}

.org-detail-container {
  position: relative;
  .btn-area {
    position: absolute;
    right: 0;
  }
}
.remark-container {
  &::after {
    content: ",";
    display: block;
    clear: both;
    line-height: 0;
    visibility: hidden;
  }
  .remark-label-container {
    display: inline-block;
    float: left;
    width: 60px;
    text-align: right;
  }
  .remark-input {
    float: left;
    margin-left: 3px;
    width: calc(~"100% - 70px");
    max-height: 150px;
    overflow-y: auto;
  }
}
</style>
