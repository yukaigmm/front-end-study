<template>
  <div>
    <Form :label-width="90" class="search-area" @keydown.enter.native.prevent="onSearchClick">
      <Row>
        <i-col span="8">
          <form-item label="合同">
            <i-select v-model="searchData.status" placeholder="请选择合同状态" transfer clearable>
              <i-option
                v-for="item in statusOptions"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>
        <i-col :offset="1" span="6">
          <i-button type="primary" @click="onSearchClick">搜索</i-button>
        </i-col>
      </Row>
    </Form>

    <div class="operator-button-container">
      <Button type="primary" @click="addContracts">添加</Button>
    </div>

    <div class="table-container">
      <Table
        :columns="tableColumns"
        :data="tableData"
        border
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
      ></Table>
    </div>

    <div class="page-load">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      ></Page>
    </div>
    <add-contract-modal :salerList="salerList" ref="addContractModal" @refreshTable="refreshTable"></add-contract-modal>
    <related-accounts @refresh="refreshTable" ref="relatedAccounts"/>
  </div>
</template>

<script>
import addContractModal from "./add-contract-modal";
import $ from "jquery";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import RelatedAccounts from "./related-accounts.vue";

export default {
  mixins: [getMinusNumber],
  components: {
    addContractModal,
    RelatedAccounts
  },

  props: {
    salerList: {
      type: [Array, Object],
      default: () => []
    }
  },

  data() {
    return {
      statusOptions: [
        {
          label: "正常",
          value: 1
        },
        {
          label: "作废",
          value: 2
        },
        {
          label: "到期",
          value: 3
        }
      ],
      searchData: {},
      orgName: "",
      total: 0,
      currentPage: 1,
      pageSize: 10,
      searchFormValue: {},
      tableColumns: [
        // {
        //   type: "selection",
        //   width: 60,
        //   align: "center",
        //   fixed: "left"
        // },
        {
          key: "contractNumber",
          title: "合同编号",
          width: 100,
          render(h, { row }) {
            return row.contractNumber || "--";
          }
        },
        {
          key: "status",
          title: "合同状态",
          width: 100,
          render(h, { row }) {
            let mapping = {
              "1": "正常",
              "2": "作废",
              "3": "到期"
            };

            return h("span", mapping[row.status]);
          }
        },
        {
          key: "orgName",
          title: "客户",
          width: 200,
          render(h, { row }) {
            return row.orgName || "--";
          }
        },
        {
          key: "amount",
          title: "金额",
          width: 100,
          render(h, { row }) {
            return row.amount || "--";
          }
        },
        {
          key: "payedAmount",
          title: "已到款金额",
          width: 100,
          render(h, { row }) {
            return row.payedAmount || "--";
          }
        },
        {
          key: "managerName",
          title: "合同负责人",
          width: 100,
          render(h, { row }) {
            return row.managerName || "--";
          }
        },
        {
          key: "startTime",
          title: "合同开始时间",
          width: 120,
          render(h, { row }) {
            return row.startTime ? row.startTime.slice(0, 11) : "--";
          }
        },
        {
          key: "endTime",
          title: "合同结束时间",
          width: 120,
          render(h, { row }) {
            return row.endTime ? row.endTime.slice(0, 11) : "--";
          }
        },
        {
          key: "expectPayDate",
          title: "预计到款日期",
          width: 120,
          render: (h, { row, column, index }) => {
            return !row.expectPayDate || row.expectPayDate == "0000-00-00"
              ? "--"
              : row.expectPayDate;
          }
        },
        {
          key: "lastPayDate",
          title: "最近到款日期",
          width: 100,
          render: (h, { row, column, index }) => {
            return !row.lastPayDate || row.lastPayDate == "0000-00-00"
              ? "--"
              : row.lastPayDate;
          }
        },
        {
          key: "lastPayMoney",
          title: "最近到款金额",
          width: 100,
          render(h, { row }) {
            return row.lastPayMoney || "--";
          }
        },
        {
          key: "hasInvoice",
          title: "是否已开发票",
          width: 100,
          render: (h, { row, column, index }) => {
            return row.hasInvoice ? "是" : "否";
          }
        },
        {
          key: "invoiceCode",
          title: "发票编号",
          width: 120,
          render(h, { row }) {
            return row.invoiceCode || "--";
          }
        },
        {
          key: "module",
          title: "合同模块",
          width: 130,
          render(h, { row }) {
            let mapping = {
              "1": "数据库",
              "2": "组合大师"
            };

            let text = "";
            let data = row.contractModel ? JSON.parse(row.contractModel) : [];

            if (data && data.length) {
              data.forEach(item => (text += `${mapping[item]} `));
            }

            return text || "--";
          }
        },
        {
          key: "action",
          title: "操作",
          width: 180,
          fixed: "right",
          render: (h, { row, column, index }) => {
            let modules = row.contractModel
              ? JSON.parse(row.contractModel)
              : [];
            let hasFof = modules.includes("2");
            let canAbolish = row.status == "1";

            let canRelateAccount =
              row.payedAmount && hasFof && row.assembleAccountNum;

            let cantRelateReason = "";

            if (!!!row.payedAmount) {
              cantRelateReason = "该合同还未到款";
            } else if (!!!hasFof) {
              cantRelateReason = "该合同不包含组合大师模块";
            } else if (!!!row.assembleAccountNum) {
              cantRelateReason = "该合同未设置关联账号数目";
            }

            let hasRelatedAccount = !!~~row.accountLinkNum;

            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  style: {
                    backgroundColor: "none"
                  },
                  on: {
                    click: () => {
                      let canEdit = row.status == "1";
                      this.editContract(row.id, hasRelatedAccount, canEdit);
                    }
                  }
                },
                row.status == "1" ? "编辑" : "查看"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: canAbolish ? "deleteBtn" : "disabledBtn",
                    title: canAbolish ? "作废合同" : "合同状态为正常才可作废"
                  },
                  on: {
                    click: () => {
                      if (!canAbolish) {
                        return;
                      }
                      this.abolishContract(row.id);
                    }
                  }
                },
                "作废"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: canRelateAccount ? "deleteBtn" : "disabledBtn",
                    title: cantRelateReason
                  },
                  on: {
                    click: () => {
                      if (!canRelateAccount) {
                        return;
                      }
                      let params = {
                        orgId: this.orgId,
                        contractId: row.id,
                        totalAccount: row.assembleAccountNum,
                        canRelate: row.status == "1"
                      };
                      this.$refs.relatedAccounts.show(params);
                    }
                  }
                },
                row.status == "1" ? "关联账号" : "查看关联"
              )
            ]);
          }
        }
      ],
      tableData: [],
      tableLoading: false,
      orgId: "",
      orgNameString: ""
    };
  },

  created() {
  },

  mounted() {
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".operator-button-container", ".page-load"],
      ".table-container"
    );
  },

  methods: {
    abolishContract(id) {
      this.$Modal.confirm({
        title: "作废合同",
        content: "合同作废后将不可恢复，确定作废此合同？",
        loading: true,
        onOk: () => {
          let params = {
            id
          };
          this.$http
            .post("contracts/cancelContracts", params)
            .then(res => {
              this.$Modal.remove();
              if (res.code === 20000) {
                this.$Message.success("合同已作废！");
                this.onSearchClick();
              } else {
                this.$Message.error(res.msg);
              }
            })
            .catch(err => {
              this.$Modal.remove();
              console.error(err);
              this.$Message.error("操作失败：网络请求错误！");
            });
        },
        onCancel: () => {}
      });
    },

    onSearchClick() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getData();
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 212;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    // 之前是模态框版本，现在实质上没用
    clear() {
      this.tableData = [];
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getData();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      if (this.currentPage == 1) {
        this.getData();
      } else {
        this.currentPage = 1;
      }
      this.setMaxHeightOfFixedTable(
        ".content-body.ivu-col",
        [".operator-button-container", ".page-load"],
        ".table-container"
      );
    },

    //  添加合同
    addContracts() {
      let params = {
        showType: "add",
        orgId: this.orgId,
        orgName: this.orgName,
        orgNameString: this.orgNameString
      };
      this.$refs.addContractModal.show(params);
    },

    // 编辑合同
    editContract(contractId, hasRelatedAccount, canEdit) {
      let params = {
        showType: "edit",
        orgId: this.orgId,
        contractId: contractId,
        hasRelatedAccount,
        canEdit
      };
      this.$refs.addContractModal.show(params);
    },

    // 重刷表格
    refreshTable() {
      this.getData();
    },

    onClickTree(
      orgId,
      orgName,
      companyId,
      orgType,
      orgNameString
    ) {
      return new Promise((resolve, reject) => {
        this.pageSize = 10;
        this.currentPage = 1;
        this.getData(
          orgId,
          orgName,
          orgNameString,
          companyId,
          orgType
        ).then(() => {
          resolve();
        });
      });
    },

    // 获取数据
    getData(
      orgId = this.orgId,
      orgName,
      orgNameString = this.orgNameString,
      companyId,
      orgType
    ) {
      if (orgId) {
        this.orgId = orgId;
      }
      if (orgName) {
        this.orgName = orgName;
      }
      this.orgNameString = orgNameString;
      let params = {
        status: this.searchData.status,
        pageSize: this.pageSize,
        pageNo: this.currentPage,
        org_pid:this.orgId
      };

      return new Promise((resolve, reject) => {
        this.tableLoading = true;
        this.$http.get("contracts", params).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
            resolve();
          } else {
            this.$Message.error(`${res.msg}`);
            reject();
          }
        });
      });
    }
  }
};
</script>

<style lang="less" scoped>
.operator-button-container {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
}
.page-load {
  text-align: right;
  padding-top: 10px;
}
</style>
