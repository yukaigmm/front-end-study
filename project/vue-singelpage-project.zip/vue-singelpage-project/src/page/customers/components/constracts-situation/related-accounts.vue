<template>
  <Modal v-model="modal" width="800" :mask-closable="false">
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <!-- <Button @click="onCancel">取消</Button> -->
      <Button @click="onCancel" type="primary">关闭</Button>
    </div>

    <div slot="header">
      <b>关联账号</b>
      &nbsp;&nbsp;
      共
      <b class="total">{{totalAccounts||"--"}}</b>个账号，
      已关联
      <b class="related">{{relatedAccounts||"--"}}</b>个，
      还可关联
      <b class="left">{{leftAccounts||"--"}}</b>个
    </div>

    <div class="all-accounts-wrap" v-loading="modalLoading" element-loading-text="拼命加载中">
      <div class="related-table">
        <h3 class="title">已关联账号</h3>
        <Table
          :columns="relatedColumns"
          :data="relatedData"
          border
          v-loading="relatedLoading"
          element-loading-text="拼命加载中"
          height="220"
        />
      </div>

      <div class="unrelated-table">
        <h3 class="title">可关联账号</h3>

        <Form :model="searchData" :label-width="90">
          <Row>
            <i-col span="9">
              <form-item label="用户名">
                <i-input v-model="searchData.realName" placeholder="请输入用户名"/>
              </form-item>
            </i-col>
            <i-col span="9">
              <form-item label="账号(手机号)">
                <i-input v-model="searchData.accountNo" placeholder="请输入账号(手机号)"/>
              </form-item>
            </i-col>
            <i-col span="6" style="padding-left:15px;">
              <i-button type="primary" @click="search">搜索</i-button>
              <i-button @click="reset">重置</i-button>
            </i-col>
          </Row>
        </Form>
        <div class="table-wrapper">
          <Table
            :columns="unRelatedColumns"
            :data="unRelatedData"
            border
            v-loading="unRelatedLoading"
            element-loading-text="拼命加载中"
            height="240"
          />
        </div>

        <div class="page-load">
          <Page
            :total="total"
            placement="top"
            :current="currentPage"
            :page-size="pageSize"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizeChange"
            show-elevator
            show-sizer
            show-total
          />
        </div>
      </div>
    </div>
  </Modal>
</template>

<script>
export default {
  data() {
    return {
      canRelate: true,
      modalLoading: false,
      orgId: "",
      contractId: "",
      modal: false,
      totalAccounts: "",
      relatedAccounts: "",
      relatedData: [],
      relatedLoading: false,
      unRelatedData: [],
      unRelatedLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10,
      searchData: {},
      hasDataChanged: false
    };
  },

  computed: {
    relatedColumns() {
      let action = {
        title: "操作",
        render: (h, { row }) => {
          return h(
            "div",
            {
              attrs: {
                class:this.canRelate ? "deleteBtn" :"disabledBtn",
                title: this.canRelate ? "解除关联" : "合同状态不正常"
              },
              on: {
                click: () => {
                  if (!this.canRelate) {
                    return;
                  }
                  this.unrelated(row.id);
                }
              }
            },
            "解除关联"
          );
        }
      };

      let basic = this.getBasicColumns();
      basic.push(action);
      return basic;
    },

    unRelatedColumns() {
      let action = {
        title: "操作",
        render: (h, { row }) => {
          let ifDisable = this.totalAccounts == this.relatedAccounts;
          return h(
            "div",
            {
              attrs: {
                class: ifDisable || !this.canRelate? "disabledBtn" : "deleteBtn",
                title: ifDisable ? "已关联全部账号" : "",
                title: this.canRelate ? "关联" : "合同状态不正常"
              },
              on: {
                click: () => {
                  if (ifDisable || !this.canRelate) {
                    return;
                  }
                  this.related(row.id);
                }
              }
            },
            "关联"
          );
        }
      };

      let basic = this.getBasicColumns();
      basic.push(action);
      return basic;
    },

    leftAccounts() {
      return this.totalAccounts - this.relatedAccounts || "0";
    }
  },

  methods: {
    getBasicColumns() {
      return [
        {
          key: "realName",
          title: "用户名",
          render(h, { row }) {
            return h("span", row.realName || "--");
          }
        },
        {
          key: "accountNo",
          title: "账号(手机号)",
          render(h, { row }) {
            return row.accountNo || "--";
          }
        },
        {
          key: "endDate",
          title: "结束日期",
          render(h, { row }) {
            return row.endDate ? row.endDate.substr(0, 11) : "--";
          }
        },
        {
          key: "managerName",
          title: "责任人",
          render: (h, { row }) => {
            return h("span", row.managerName || "--");
          }
        },
        {
          key: "orgName",
          title: "机构名称",
          ellipsis: true,
          render(h, { row }) {
            return h(
              "span",
              {
                attrs: {
                  title: row.orgName
                }
              },
              row.orgName || "--"
            );
          }
        },
        {
          key: "visitingCardUrl",
          title: "名片",
          ellipsis: true,
          render(h, { row }) {
            let url;
            if (row.visitingCardUrl) {
              let picUrl = JSON.parse(JSON.stringify(row.visitingCardUrl));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? "http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";
                picUrl = `Uploads/crm/${row.visitingCardUrl}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        }
      ];
    },

    search() {
      this.pageSize = 10;
      this.currentPage = 1;
      this.getUnrelatedList();
    },

    reset() {
      this.searchData = {};
      this.search();
    },

    onPageChange(val) {
      this.currentPage = val;
      this.getUnrelatedList();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getUnrelatedList();
    },

    getRelatedList() {
      let params = {
        orgId: this.orgId,
        contractId: this.contractId,
        pageSize: -1
      };
      return new Promise(resolve => {
        this.relatedLoading = true;
        this.getAccounts(params, true).then(() => {
          this.relatedLoading = false;
          resolve();
        });
      });
    },

    getAccounts(params, ifGetTotal) {
      return new Promise(resolve => {
        this.$http
          .get("accounts/getContractsAccount", params)
          .then(res => {
            resolve();
            if (res.code === 20000) {
              if (ifGetTotal) {
                this.relatedAccounts = res.data.total || "0";
                this.relatedData = res.data.records || [];
              } else {
                this.total = res.data.total;
                this.unRelatedData = res.data.records || [];
              }
            } else {
              this.$Message.error(res.msg);
            }
          })
          .catch(err => {
            console.error(err);
            resolve();
            this.$Message.error("获取数据失败：网络错误！");
          });
      });
    },

    getUnrelatedList() {
      let params = {
        pageSize: this.pageSize,
        pageNo: this.currentPage,
        orgId: this.orgId,
        noContract: 1,
        ...this.searchData
      };
      return new Promise(resolve => {
        this.unRelatedLoading = true;
        this.getAccounts(params).then(() => {
          this.unRelatedLoading = false;
          resolve();
        });
      });
    },

    // onOk() {},

    onCancel() {
      this.orgId = "";
      this.contractId = "";
      this.totalAccounts = "";
      this.relatedAccounts = "";
      this.unRelatedData = [];
      this.relatedData = [];
      this.total = 0;
      this.currentPage = 1;
      this.pageSize = 10;
      this.searchData = {};
      this.modal = false;
      if (this.hasDataChanged) {
        this.hasDataChanged = false;
        this.$emit("refresh");
      }
      this.canRelate = true;
    },

    show({ orgId, contractId, totalAccount, canRelate }) {
      this.canRelate = canRelate;
      this.totalAccounts = totalAccount;
      this.orgId = orgId;
      this.contractId = contractId;
      this.modal = true;

      this.modalLoading = true;
      Promise.all([this.getRelatedList(), this.getUnrelatedList()]).then(
        res => {
          this.modalLoading = false;
        }
      );
    },

    unrelated(id) {
      let params = {
        accId: id,
        contractId: this.contractId
      };

      this.$Message.loading({
        duration: 0,
        content: "关联中..."
      });

      this.$http
        .post("accounts/removeContractsAccount", params)
        .then(res => {
          this.$Message.destroy();
          if (res.code === 20000) {
            this.$Message.success("解除关联成功！");
            this.modalLoading = true;
            this.hasDataChanged = true;
            Promise.all([this.getRelatedList(), this.getUnrelatedList()]).then(
              () => {
                this.modalLoading = false;
              }
            );
          } else {
            this.$Message.error(res.msg);
          }
        })
        .catch(err => {
          console.error(err);
          this.$Message.destroy();
          this.$Message.error("解除关联失败：网络错误");
        });
    },

    related(id) {
      let params = {
        accId: id,
        contractId: this.contractId
      };

      this.$Message.loading({
        duration: 0,
        content: "关联中..."
      });

      this.$http
        .post("accounts/addContractsAccount", params)
        .then(res => {
          this.$Message.destroy();
          if (res.code === 20000) {
            this.$Message.success("关联成功！");
            this.hasDataChanged = true;
            Promise.all([this.getRelatedList(), this.getUnrelatedList()]).then(
              () => {
                this.modalLoading = false;
              }
            );
          } else {
            this.$Message.error(res.msg);
          }
        })
        .catch(err => {
          console.error(err);
          this.$Message.destroy();
          this.$Message.error("关联失败：网络错误");
        });
    }
  }
};
</script>

<style lang="less" scoped>
.total,
.left,
.related {
  font-size: 14px;
  font-weight: 900;
}
.related {
  color: red;
}
.left {
  color: green;
}

.title {
  padding: 5px 15px;
  background: #eeeeee;
  margin: 10px 0px;
}

.page-load {
  text-align: right;
  margin: 10px;
}
</style>

