<template>
  <Modal
    :title="modalTitle"
    v-model="modal"
    :mask-closable="false"
    transfer
    class="add-contracts-modal"
    width="700"
  >
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer" v-if="canEdit">
      <Button type="default" @click="onCancel">取消</Button>
      <Button type="primary" @click="onOk" :loading="buttonLoading">确定</Button>
    </div>

    <div slot="footer" v-if="!canEdit">
      <Button type="primary" @click="onCancel">关闭</Button>
    </div>

    <div class="form-container" v-loading="modalLoading" element-loading-text="拼命加载中">
      <Form :model="form" ref="addContractForm" :rules="validateRules" :label-width="100">
        <Row>
          <i-col span="24">
            <FormItem label="客户" prop="orgName">
              <span>{{form.orgName || "--"}}</span>
            </FormItem>
          </i-col>

          <i-col span="12">
            <FormItem label="合同编号" prop="contractNumber">
              <i-input v-model="form.contractNumber" :disabled="!canEdit" placeholder="请输入合同编号"></i-input>
            </FormItem>
          </i-col>

          <i-col span="12">
            <FormItem label="合同负责人" prop="managerId">
              <Select v-model="form.managerId" placeholder="请输入合同负责人" :disabled="!canEdit" transfer>
                <Option
                  v-for="(item,index) in managerList"
                  :key="index"
                  :value="item.value"
                >{{item.label}}</Option>
              </Select>
            </FormItem>
          </i-col>

          <i-col span="12">
            <FormItem label="合同开始日期" prop="startTime">
              <DatePicker
                style="width:100%"
                transfer
                type="date"
                :disabled="!canEdit"
                v-model="form.startTime"
                placeholder="请选择合同开始日期"
              ></DatePicker>
            </FormItem>
          </i-col>

          <i-col span="12">
            <FormItem label="合同结束日期" prop="endTime">
              <DatePicker
                style="width:100%"
                transfer
                type="date"
                :disabled="hasRelatedAccount || !canEdit"
                v-model="form.endTime"
                placeholder="请选择合同结束日期"
              ></DatePicker>
            </FormItem>
          </i-col>

          <i-col span="12">
            <FormItem label="已开发票" prop="hasInvoice">
              <Row>
                <i-col span="4">
                  <Checkbox
                    v-model="form.hasInvoice"
                    :disabled="!canEdit"
                    :false-value="0"
                    :true-value="1"
                  ></Checkbox>
                </i-col>

                <i-col span="20">
                  <i-input
                    :disabled="form.hasInvoice==0 && !canEdit"
                    v-model="form.invoiceCode"
                    placeholder="请输入发票编号"
                  ></i-input>
                </i-col>
              </Row>
            </FormItem>
          </i-col>

          <i-col span="12">
            <FormItem label="预计到款日期" prop="expectPayDate">
              <DatePicker
                transfer
                style="width:100%"
                type="date"
                :disabled="!canEdit"
                v-model="form.expectPayDate"
                placeholder="请选择预计到款日期"
              ></DatePicker>
            </FormItem>
          </i-col>

          <i-col span="24">
            <div class="moudle">
              <form-item label="合同模块" prop="contractModel">
                <CheckboxGroup v-model="form.contractModel" @on-change="onContractModel">
                  <Checkbox label="1" :disabled="!canEdit">数据库</Checkbox>
                  <Checkbox :disabled="hasRelatedAccount || !canEdit" label="2">组合大师</Checkbox>
                </CheckboxGroup>
              </form-item>
            </div>
          </i-col>

          <i-col span="24" style="border-bottom:1px solid #ccc;margin-bottom:5px;">
            <Row>
              <i-col span="12">
                <Row>
                  <i-col
                    span="24"
                    style="border-bottom:1px solid #ccc;margin-bottom:15px;padding:5px;background:#ccc;"
                  >数据库</i-col>
                  <i-col span="23">
                    <form-item
                      label="数据库金额"
                      prop="dbAmount"
                      :class="{'ivu-form-item-required':form.contractModel.includes('1')}"
                    >
                      <i-input
                        v-model="form.dbAmount"
                        placeholder="请输入数据库金额"
                        :disabled="!form.contractModel.includes('1') || !canEdit"
                        @on-change="onAmountChange"
                      />
                    </form-item>
                  </i-col>
                </Row>
              </i-col>
              <i-col span="12" style="border-left:1px solid #ddd;">
                <Row>
                  <i-col
                    span="24"
                    style="border-bottom:1px solid #ccc;margin-bottom:15px;padding:5px;background:#ccc;"
                  >组合大师</i-col>
                  <i-col span="23">
                    <form-item
                      label="组合大师金额"
                      prop="assembleAmount"
                      :class="{'ivu-form-item-required':form.contractModel.includes('2')}"
                    >
                      <i-input
                        v-model="form.assembleAmount"
                        @on-change="onAmountChange"
                        placeholder="请输入组合大师金额"
                        :disabled="!form.contractModel.includes('2') || !canEdit"
                      />
                    </form-item>
                  </i-col>
                  <i-col span="23">
                    <form-item
                      label="账号数量"
                      prop="assembleAccountNum"
                      :class="{'ivu-form-item-required':form.contractModel.includes('2')}"
                    >
                      <i-input
                        v-model="form.assembleAccountNum"
                        placeholder="请输入账号数量"
                        :disabled="!form.contractModel.includes('2') || hasRelatedAccount || !canEdit"
                      />
                    </form-item>
                  </i-col>
                </Row>
              </i-col>
            </Row>
          </i-col>

          <i-col span="12">
            <FormItem label="合同金额" prop="amount">
              <span>{{form.amount||"--"}}</span>
            </FormItem>
          </i-col>

          <i-col span="12">
            <FormItem label="已到款金额">
              <span :key="amountKey" v-html="form.payedAmount||'--'"></span>
            </FormItem>
          </i-col>
        </Row>
      </Form>

      <div class="amount-details-container">
        <div style="float:right;" title="新增到款明细">
          <Button
            shape="circle"
            icon="plus"
            size="small"
            :disabled="!canEdit"
            @click="addAmountDetails"
          ></Button>
        </div>

        <p style="width:78px;text-align:right; margin-bottom:10px;">到款明细</p>

        <Table
          :data="form.payedinfo"
          :columns="columns"
          border
          v-loading="tableLoading"
          element-loading-text="拼命加载中"
        ></Table>
      </div>
    </div>
  </Modal>
</template>

<script>
import { mapGetters } from "vuex";
import moment from "moment";
let timer = null;
export default {
  props: {
    salerList: {
      type: [Array, Object],
      default: () => []
    }
  },

  data() {
    const validateContractNumber = (rules, value, cb) => {
      let errors = [];
      if (value) {
        let params = {
          contractId: this.contractId,
          contractNumber: value
        };

        if (timer) {
          clearTimeout(timer);
        }

        timer = setTimeout(() => {
          this.$http
            .get("contracts/validation", params)
            .then(res => {
              if (res.code === 20000) {
                if (!res.data.validation) {
                  errors.push(new Error("该合同编号已存在！"));
                }
              } else {
                errors.push(new Error("校验失败，请重新输入!"));
              }
            })
            .then(() => {
              cb(errors);
            });
        }, 500);
      }
    };

    const validateModules = (rules, value, cb) => {
      let errors = [];
      if (!value || value.length === 0) {
        errors.push(new Error("必须至少选择一个模块"));
      } else {
        errors = [];
      }

      cb(errors);
    };

    const validateAmountAndAccount = key => {
      return (rules, value, cb) => {
        let errors = [];
        switch (key) {
          case "db":
            if (
              this.form.contractModel.includes("1") &&
              (parseFloat(value) <= 0 || isNaN(parseFloat(value)))
            ) {
              errors.push(new Error("金额不能为空或小于0"));
            } else {
              errors = [];
            }
            break;
          case "fof":
            if (
              this.form.contractModel.includes("2") &&
              (parseFloat(value) <= 0 || isNaN(parseFloat(value)))
            ) {
              errors.push(new Error("金额不能为空或小于0"));
            } else {
              errors = [];
            }
            break;
          case "account":
            if (
              this.form.contractModel.includes("2") &&
              (parseFloat(value) <= 0 || isNaN(parseFloat(value)))
            ) {
              errors.push(new Error("账号数量不能为空或小于0"));
            } else {
              errors = [];
            }
            break;
          default:
            errors = [];
            break;
        }

        cb(errors);
      };
    };

    return {
      amountKey: null,
      modalLoading: false,
      modalTitle: "",
      buttonLoading: false,
      validateRules: {
        contractNumber: [
          {
            required: true,
            message: "合同编号不能为空"
          },
          {
            validator: validateContractNumber,
            trigger: "change"
          }
        ],
        managerId: {
          required: true,
          message: "合同负责人不能为空"
        },
        startTime: {
          required: true,
          message: "合同开始时间不能为空"
        },
        endTime: {
          required: true,
          message: "合同结束时间不能为空"
        },
        contractModel: {
          validator: validateModules,
          trigger: "change"
        },
        dbAmount: {
          validator: validateAmountAndAccount("db"),
          trigger: "change"
        },
        assembleAmount: {
          validator: validateAmountAndAccount("fof"),
          trigger: "change"
        },
        assembleAccountNum: {
          validator: validateAmountAndAccount("account"),
          trigger: "change"
        }
      },
      columns: [
        {
          key: "payedDate",
          title: "到款日期",
          minWidth: 100,
          render: (h, { row, column, index }) => {
            return h("datePicker", {
              props: {
                value: row.payedDate,
                placeholder: "请选择到款日期",
                transfer: true,
                placement: "top",
                disabled: !this.canEdit
              },
              on: {
                "on-change": val => {
                  row.payedDate = val;
                  this.form.payedinfo[index] = row;
                }
              }
            });
          }
        },
        {
          key: "amount",
          title: "到款金额",
          minWidth: 100,
          render: (h, { row, column, index }) => {
            return h("i-input", {
              props: {
                value: row.amount || "",
                placeholder: "请输入到款金额",
                disabled: !this.canEdit
              },
              on: {
                "on-change": event => {
                  row.amount = event.target.value;
                  this.form.payedinfo[index] = row;
                  // this.$set(
                  //   this.form,
                  //   "payedAmount",
                  //   this.form.payedinfo
                  //     .map(item => item.amount)
                  //     .reduce((pre, cur) => parseFloat(pre) + parseFloat(cur))
                  // );
                  let payedInfo = JSON.parse(
                    JSON.stringify(this.form.payedinfo)
                  );
                  let amount = 0;
                  // 获取总额
                  payedInfo
                    .map(item => item.amount)
                    .filter(item => item)
                    .forEach(item => (amount += parseFloat(item)));
                  this.amountKey = Date.now();
                  this.$set(this.form, "payedAmount", amount);
                  // this.form.payedAmount = amount;
                }
              }
            });
          }
        }
      ],
      tableLoading: false,
      modal: false,
      hasRelatedAccount: false,
      canEdit: true,
      form: {
        contractNumber: "",
        amount: "",
        orgName: "",
        managerId: "",
        hasInvoice: 0,
        invoiceCode: "",
        expectPayDate: "",
        payedAmount: "",
        payedinfo: [],
        contractModel: [],
        startTime: "",
        endTime: "",
        dbAmount: "",
        assembleAmount: "",
        assembleAccountNum: ""
      },
      showType: "",
      contractId: "",
      orgId: ""
    };
  },

  // created() {
  //   this.getManagerList();
  // },
  mounted() {},

  computed: {
    ...mapGetters({
      user: "getUser"
    }),

    managerList() {
      return this.salerList;
    }
  },

  methods: {
    onContractModel(val) {
      if (
        this.form.contractModel.includes("1") &&
        this.form.contractModel.includes("2")
      ) {
        this.form.amount =
          parseFloat(this.form.dbAmount) + parseFloat(this.form.assembleAmount);
      } else if (
        this.form.contractModel.includes("1") &&
        !this.form.contractModel.includes("2")
      ) {
        this.form.amount = parseFloat(this.form.dbAmount);
      } else if (
        !this.form.contractModel.includes("1") &&
        this.form.contractModel.includes("2")
      ) {
        this.form.amount = parseFloat(this.form.assembleAmount);
      } else {
        this.form.amount = 0;
      }
    },

    onAmountChange(e) {
      let value = e.target.value;
      if (
        this.form.contractModel.includes("1") &&
        this.form.contractModel.includes("2")
      ) {
        this.form.amount =
          parseFloat(this.form.dbAmount) + parseFloat(this.form.assembleAmount);
      } else if (
        this.form.contractModel.includes("1") &&
        !this.form.contractModel.includes("2")
      ) {
        this.form.amount = parseFloat(this.form.dbAmount);
      } else if (
        !this.form.contractModel.includes("1") &&
        this.form.contractModel.includes("2")
      ) {
        this.form.amount = parseFloat(this.form.assembleAmount);
      } else {
        this.form.amount = 0;
      }
    },

    getManagerList() {
      this.$http
        .get("dept/getUserByDept", {
          dept_id: 16, //机构销售部
          type: 1
        })
        .then(resp => {
          if (resp.code === 20000) {
            this.managerList = _.map(resp.data, person => person).filter(
              item => item.status
            );
          }
        });
    },

    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },

    /**
     * @param  showType @type [string]  value{add ,edit}
     * @param  orgId @type [string,number] 机构id
     * @param  contractId @type [string,number] 合同id
     * @param  orgName @type [string] 机构名称
     * @param hasRelatedAccount @type [boolean] 是否已有关联账号
     */
    show({
      showType,
      orgId,
      contractId,
      orgName,
      orgNameString,
      hasRelatedAccount,
      canEdit = true
    }) {
      this.showType = showType;
      this.orgId = orgId;
      this.contractId = contractId;
      this.hasRelatedAccount = hasRelatedAccount || false;
      this.canEdit = canEdit;

      // 默认加上当前用户
      if (
        !this.managerList.some(item => {
          return item.value == this.user.id;
        })
      ) {
        this.$set(this.managerList, this.managerList.length, {
          label: this.user.trueName,
          value: this.user.id
        });
      }
      if (this.showType === "add") {
        this.modalTitle = "新增合同";

        this.$set(this.form, "managerId", this.user.id);
        this.$set(this.form, "orgName", orgNameString);
      } else {
        this.modalTitle = "编辑合同";
        this.getContractDetails();
      }
      this.modal = true;
    },

    close() {
      this.$nextTick(() => {
        this.tableData = [];
        this.form = {
          ccontractNumber: "",
          amount: "",
          orgName: "",
          managerId: "",
          hasInvoice: 0,
          invoiceCode: "",
          expectPayDate: "",
          payedAmount: "",
          payedinfo: [],
          contractModel: [],
          startTime: "",
          endTime: "",
          dbAmount: "",
          assembleAmount: "",
          assembleAccountNum: ""
        };
        this.$refs.addContractForm.resetFields();
      });
      this.hasRelatedAccount = false;
      this.canEdit = true;
      this.contractId = "";
      this.orgId = "";
      this.showType = "";
      this.modal = false;
    },

    onOk() {
      this.$refs.addContractForm.validate(valid => {
        if (valid) {
          if (this.showType === "add") {
            this.addContract();
          } else {
            this.editContracts();
          }
        } else {
          this.$Message.warning("请按红色文字提示填写内容！");
        }
      });
    },

    // 新增合同
    addContract() {
      let form = JSON.parse(JSON.stringify(this.form));
      if (form.expectPayDate) {
        form.expectPayDate = this.setTimeZone(form.expectPayDate);
      }

      if (form.startTime) {
        form.startTime = this.setTimeZone(form.startTime);
      }

      if (form.endTime) {
        form.endTime = this.setTimeZone(form.endTime);
      }
      this.buttonLoading = true;
      let params = Object.assign(
        {
          orgId: this.orgId
        },
        form
      );
      this.$http
        .post("contracts", params)
        .then(res => {
          this.buttonLoading = false;
          if (res.code === 20000) {
            this.$Message.info("新增成功！");
            this.$emit("refreshTable");
            this.close();
          } else {
            this.$Message.warning("新增失败！");
          }
        })
        .catch(err => {
          console.error(err);
          this.buttonLoading = false;
          this.$Message.error("新增失败！");
        });
    },

    // 修改合同
    editContracts() {
      this.buttonLoading = true;
      let form = JSON.parse(JSON.stringify(this.form));
      if (form.expectPayDate) {
        form.expectPayDate = this.setTimeZone(form.expectPayDate);
      }

      if (form.startTime) {
        form.startTime = this.setTimeZone(form.startTime);
      }

      if (form.endTime) {
        form.endTime = this.setTimeZone(form.endTime);
      }

      this.$http
        .putWithoutId(`contracts/${this.contractId}`, form)
        .then(res => {
          this.buttonLoading = false;
          if (res.code === 20000) {
            this.$Message.info("修改成功！");
            this.$emit("refreshTable");
            this.close();
          } else {
            this.$Message.warning("修改失败！");
          }
        })
        .catch(err => {
          console.error(err);
          this.buttonLoading = false;
          this.$Message.error("修改失败！");
        });
    },

    // 获取合同详情
    getContractDetails() {
      this.modalLoading = true;
      this.$http
        .get(`contracts/${this.contractId}`)
        .then(res => {
          this.modalLoading = false;
          if (res.code === 20000) {
            this.form = res.data;
            if (this.form.hasInvoice) {
              this.form.hasInvoice += "";
            }
            if (this.form.contractModel) {
              this.form.contractModel =
                JSON.parse(this.form.contractModel) || [];
            } else {
              this.form.contractModel = [];
            }
            if (this.form.payedinfo.length) {
              // 计算合同总金额
              this.form.payedAmount = this.form.payedinfo
                .map(item => item.amount)
                .filter(item => item)
                .reduce((pre, cur) => parseFloat(pre) + parseFloat(cur));
            }
          } else {
            this.$Message.warning(`${res.msg}`);
          }
        })
        .catch(e => {
          this.modalLoading = false;
          console.error(e);
          this.$Message.warning("获取内容失败");
        });
    },

    onCancel() {
      this.close();
    },

    addAmountDetails() {
      this.$set(this.form.payedinfo, this.form.payedinfo.length, {});
    }
  }
};
</script>

<style lang="less" scoped>
</style>


