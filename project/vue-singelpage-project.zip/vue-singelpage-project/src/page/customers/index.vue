<template>
  <div class="grid-content">
    <div class="search-area keydown-box">
      <search-area @changeSearchParam="changeSearchParam" @onKeydownSearch="search">
        <div slot="default">
          <Row>
            <i-col span="8">
              <FormItem label="机构名">
                <Input v-model.trim="formSearch.orgName" placeholder="请输入关键字,如：总部 分部" />
              </FormItem>
            </i-col>

            <i-col span="8">
              <FormItem label="责任人">
                <Row>
                  <i-col span="12">
                    <Select v-model="formSearch.managerIds" multiple :key="managerIdKey">
                      <Option
                        v-for="option in managerList"
                        :value="option.value"
                        :key="option.value"
                      >{{option.label}}</Option>
                    </Select>
                  </i-col>

                  <i-col span="11" offset="1">
                    <Select v-model="tableShowType" @on-change="onTableShowTypeChange">
                      <Option
                        v-for="item in tableShowOptions"
                        :key="item.value"
                        :value="item.value"
                      >{{item.label}}</Option>
                    </Select>
                  </i-col>
                </Row>
              </FormItem>
            </i-col>

            <i-col span="4">
              <!-- 提交按钮 -->
              <Button type="primary" @click="search" style="margin-left:8px;">搜索</Button>
              <Button type="ghost" style="margin-left: -7px" @click="onReset">重置</Button>
            </i-col>
          </Row>
          <Row>
            <i-col span="8">
              <FormItem label="分配状态">
                <Select v-model="formSearch.assignStatus" :clearable="true">
                  <Option
                    v-for="option in statusOptions"
                    :value="option.value"
                    :key="option.value"
                  >{{option.label}}</Option>
                </Select>
              </FormItem>
            </i-col>

            <i-col span="8">
              <form-item label="机构状态">
                <i-select v-model="formSearch.status" clearable >
                  <i-option
                    v-for="item in orgStatusOptions"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>
          </Row>
        </div>

        <div slot="extend">
          <Row>
            <i-col span="8">
              <FormItem label="机构类型">
                <Row>
                  <i-col span="11">
                    <Select v-model="formSearch.ocId" clearable placeholder="请选择">
                      <Option
                        v-for="item in emnus.c_org"
                        :value="item.value"
                        :key="item.value"
                      >{{item.name}}</Option>
                    </Select>
                  </i-col>

                  <i-col span="12" offset="1">
                    <Select v-model="formSearch.departId" clearable placeholder="请选择">
                      <Option
                        v-for="item in emnus.c_depart"
                        :value="item.value"
                        :key="item.value"
                      >{{item.name}}</Option>
                    </Select>
                  </i-col>
                </Row>
              </FormItem>
            </i-col>

            <i-col span="8">
              <FormItem label="地域">
                <component
                  :is="'SelectLinkage'"
                  v-model="formSearch.area_ids"
                  :config="{
                    isFullfill:true,
                     useForSearch: true,
                     cacheKey: 'c_area_all',
                     row: 'dialog-form-item-row',}"
                  style="width:100%;"
                ></component>
              </FormItem>
            </i-col>
          </Row>

          <Row>
            <i-col span="8">
              <FormItem label="销售标签">
                <Select v-model="formSearch.salesPortrait" multiple>
                  <Option v-for="option in tagOptions" :value="option.value" :key="option.value">
                    <Tag :style="option.style">{{option.name}}</Tag>
                  </Option>
                </Select>
              </FormItem>
            </i-col>
          </Row>
        </div>
      </search-area>
    </div>

    <div class="assign-button">
      <Button type="primary" @click="assignResponsor" v-if="hasRight">批量分配</Button>
      <Button type="primary" @click="search">刷新表格</Button>
    </div>

    <div class="table-container">
      <Table
        class="table-grid"
        border
        :columns="columns"
        :data="tableData"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        @on-selection-change="onTableSelectionChange"
      ></Table>
    </div>

    <div class="page-load">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      ></Page>
    </div>
    <!-- <org-information-modal ref="orgInformationModal"></org-information-modal>  -->
    <edit-responsor-modal ref="editResponsorModal" @refreshTable="refreshData"></edit-responsor-modal>
  </div>
</template>

<script>
import $ from "jquery";
import searchArea from "../../components/search-area";
// import orgInformationModal from "./components/org-information-modal";
import SelectLinkage from "@/components/inputs/select-linkage";
import editResponsorModal from "../customers-assign/edit-responsors-modal";
import { mapGetters } from "vuex";
import { map } from "lodash";
import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  components: {
    searchArea,
    // orgInformationModal,
    SelectLinkage,
    editResponsorModal
  },

  mixins: [getMinusNumber],

  data() {
    return {
      resetFlag: false,
      tagOptions: [],
      assignOrgIds: [],
      tableShowType: 0,
      orgStatusOptions: [
        {
          value: 0,
          label: "试用"
        },
        {
          value: 1,
          label: "正式"
        }
      ],
      tableShowOptions: [
        {
          value: 1,
          label: "只看自己"
        },
        {
          value: 0,
          label: "查看所有"
        }
      ],
      deptsList: [],
      statusOptions: [
        {
          value: 0,
          label: "未分配"
        },
        {
          value: 1,
          label: "已分配"
        }
      ],
      managerList: [],
      managerIdKey: null,
      hasMoreParams: false,
      formSearch: {
        orgName: "",
        managerIds: [],
        status: "",
        assignStatus:"",
        area_ids: "",
        custTypeIds: [],
        salesPortrait: []
      },
      tableData: [],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  created() {
    this.tagOptions = this.emnus.c_port_all_sale;
    this.getManagerList();
    // this.formSearch.managerIds = [this.user.id];
    this.getCustomerList();
  },

  watch: {
    "formSearch.managerIds": {
      handler(val) {
        if (val.length === 1) {
          if (val[0] != this.user.id) {
            this.tableShowType = "";
          }
        } else if (!val.length) {
          this.tableShowType = 0;
        } else {
          this.tableShowType = "";
        }
      },
      deep: false
    },
    "formSearch.salesPortrait": {
      handler(val) {
        setTimeout(() => {
          let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(this.$el).find(
            ".ivu-select-selection .ivu-tag span"
          );
          let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
          let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTags.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText.trim() ==
                $(tag.get(i))[0].innerText.trim()
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    }
  },

  mounted() {
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".assign-button", ".page-load"],
      ".table-container"
    );
  },

  computed: {
    ...mapGetters({
      emnus: "getEnums",
      tabs: "getTabs",
      userInfo: "getUser"
    }),

    hasRight() {
      return this.userInfo.auth.functional.includes("assignCustomer");
    },
    columns() {
      let baseColumn = [
        {
          type: "selection",
          width: 60,
          align: "center"
        },
        {
          title: "客户编码",
          key: "orgId",
          width: 90,
          render: (h, { row, column, index }) => {
            let initStr = "0000000000";
            let jointStr = initStr + row.orgId;
            return jointStr.slice(-10);
          }
        },
        {
          title: "简称",
          key: "orgName",
          width: 400,
          render: (h, { row, column, index }) => {
            if (row.bread && row.bread.length) {
              let bread = row.bread.slice(1);
              return h(
                "div",
                bread.map((item, index) => {
                  return h(
                    "a",
                    {
                      on: {
                        click: e => {
                          let tab = {
                            activeName: `[客户]${item.title}`,
                            pid: item.id,
                            name: `[客户]${item.title}${item.id}`,
                            component: "customerDetails",
                            isShow: true,
                            orgType: row.ocId
                          };
                          this.$store.dispatch("setTabs", tab);
                          e.preventDefault();
                          e.stopPropagation();
                        }
                      }
                    },
                    index === bread.length - 1
                      ? `${item.title}`
                      : `${item.title}>`
                  );
                })
              );
            } else {
              return h(
                "a",
                {
                  on: {
                    click: e => {
                      let tab = {
                        activeName: `[客户]${row.orgName}`,
                        pid: row.orgId,
                        name: `[客户]${row.orgName}${row.orgId}`,
                        component: "customerDetails",
                        isShow: true,
                        orgType: row.ocId
                      };

                      this.$store.dispatch("setTabs", tab);
                      e.preventDefault();
                      e.stopPropagation();
                    }
                  }
                },
                `${row.orgName || "--"}`
              );
            }
          }
        },
        {
          title: "机构类型",
          key: "ocId",
          width: 100,
          render: (h, { row, column, index }) => {
            let orgTypeMapping = this.emnus.c_org;
            return orgTypeMapping
              .map(item => {
                if (row.ocId == item.value) {
                  return item.name;
                }
              })
              .join("");
          }
        },
        {
          title: "是否分配",
          key: "assignStatus",
          width: 100,
          render: (h, { row, column, index }) => {
            return row.manager && row.manager.length ? "是" : "否";
          }
        },
        {
          title: "机构状态",
          key: "status",
          width: 100,
          render: (h, { row, column, index }) => {
            return row.status ? "正式" : "试用";
          }
        },
        {
          title: "销售标签",
          key: "salesPortrait",
          width: 120,
          render: (h, { row, column, index }) => {
            if (row.salesPortrait && row.salesPortrait.length) {
              let tagArr = [];
              row.salesPortrait.forEach(item => {
                this.tagOptions.forEach(tagItem => {
                  if (item == tagItem.value) {
                    tagArr.push(tagItem);
                  }
                });
              });
              if (tagArr.length) {
                return h(
                  "div",
                  tagArr.map(item => {
                    return h(
                      "Tag",
                      {
                        style: Object.assign({}, item.style)
                      },
                      `${item.name}`
                    );
                  })
                );
              } else {
                return "--";
              }
            } else {
              return "--";
            }
          }
        },
        {
          title: "责任人",
          key: "manager",
          width: 100,
          render: (h, { row, column, index }) => {
            if (row.manager && row.manager.length) {
              let manager = JSON.parse(JSON.stringify(row.manager));
              return manager.shift();
            } else {
              return "--";
            }
          }
        },
        {
          title: "联系人个数",
          key: "countContact",
          width: 100,
          render(h, { row }) {
            return row.countContact;
          }
        },
        {
          title:"账号个数",
          key:"accountNum",
          width:80,
          render(h,{row}){
            return row.accountNum;
          }
        },
        {
          title: "活跃账户数",
          key: "activeAccount",
          width: 100,
          render(h, { row }) {
            return row.activeAccount;
          }
        },
        {
          title: "最近拜访时间",
          key: "recentVisitTime",
          width: 100,
          render(h, { row }) {
            return row.visit.visitTime
              ? row.visit.visitTime.substr(0, 11)
              : "--";
          }
        },
        {
          title: "最近拜访人",
          key: "recentVisitor",
          width: 100,
          render(h, { row }) {
            return row.visit.visitMemberName || "--";
          }
        }
      ];
      if (this.hasRight) {
        return [
          ...baseColumn,
          {
            title: "操作",
            key: "action",
            fixed: "right",
            width: 100,
            render: (h, { row, column, index }) => {
              return h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn",
                    title: "分配责任人"
                  },
                  on: {
                    click: () => {
                      if (!this.hasRight) {
                        return;
                      }
                      let managerIds = [];
                      if (row.managerIds) {
                        managerIds = row.managerIds
                          .split(",")
                          .filter(item => item);
                      }
                      let managerNames = row.manager;
                      this.$refs.editResponsorModal.show(
                        managerIds,
                        [row.orgId],
                        managerNames
                      );
                    }
                  }
                },
                "分配"
              );
            }
          }
        ];
      } else {
        return [...baseColumn];
      }
    }
  },

  methods: {
    // 获取批量分配时的机构id
    onTableSelectionChange(selection) {
      this.assignOrgIds = selection.map(item => item.orgId);
    },

    // 控制列表展示自己相关的记录还是全部记录
    onTableShowTypeChange(val) {
      if (this.resetFlag && val === 0) {
        this.resetFlag = !this.resetFlag;
        return;
      }
      if (val === 0) {
        this.formSearch.managerIds = [];
        this.getCustomerList();
      } else if (val === 1) {
        this.formSearch.managerIds = [this.user.id];
        this.getCustomerList();
      }
    },

    // 获取负责人列表
    getManagerList() {
      let params = {
        dept_id: 16,
        type: 1
      };

      this.$http.get("dept/getUserByDept", params).then(resp => {
        if (resp.code === 20000) {
          this.managerList = map(resp.data, person => person).filter(
            item => item.status
          );
          this.managerIdKey = Date.now();
        }
      });
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 120;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    // 获取客户列表
    getCustomerList() {
      this.tableLoading = true;
      this.$http
        .get("allocatedResources", this.getParams())
        .then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
          } else {
            this.tableData = [];
            this.$Message.warning(`${res.msg}`);
          }
        })
        .catch(e => {
          this.tableLoading = false;
          this.$Message.error("获取表格数据失败！");
        });
    },

    // 改变搜索条件的折叠状态
    changeSearchParam() {
      this.hasMoreParams = !this.hasMoreParams;
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".search-area", ".assign-button", ".page-load"],
          ".table-container"
        );
      });
    },

    refreshData() {
      this.assignOrgIds = [];
      this.getCustomerList();
    },

    // 搜索
    search() {
      this.assignOrgIds = [];
      this.pageSize = 10;
      this.currentPage = 1;
      this.getCustomerList();
    },

    // 搜索重置
    onReset() {
      this.resetFlag = true;
      this.formSearch = {
        orgName: "",
        managerIds: [],
        status: "",
        area_ids: "",
        custTypeIds: [],
        dept_id: "",
        salesPortrait: [],
        assignStatus:""
      };
      if (this.currentPage == 1 || this.pageSize == 10) {
        this.getCustomerList();
      } else {
        this.currentPage = 1;
        this.pageSize = 10;
      }

      // this.getCustomerList();
    },

    // 分配责任人
    assignResponsor() {
      if (!this.hasRight) {
        return;
      }
      if (!this.assignOrgIds.length) {
        this.$Message.warning("请先选择机构！");
      } else {
        this.$refs.editResponsorModal.show([], this.assignOrgIds);
      }
    },

    //  显示机构详情modal
    showOrgInformationModal(orgId) {
      this.$refs.orgInformationModal.show(orgId);
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getCustomerList();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      if (this.currentPage == 1) {
        this.getCustomerList();
      }
      this.currentPage = 1;
    },

    //  请求参数
    getParams() {
      let params = {};

      let initParams = JSON.parse(JSON.stringify(this.formSearch));

      if (!this.hasMoreParams) {
        for (let key in initParams) {
          if (key === "orgName" || key === "managerIds" || key === "status" || key==="assignStatus") {
            params[key] = initParams[key];
          }
        }
      } else {
        params = initParams;
      }
      if (params.orgName) {
        params.orgName = params.orgName.trim().split(/[ ]+/);
      }
      return Object.assign(
        {
          pageSize: this.pageSize,
          pageNo: this.currentPage
        },
        params
      );
    }
  }
};
</script>

<style lang="less" scoped>
.assign-button {
  margin: 10px;
}
.page-load {
  padding: 10px;
  float: right;
}
</style>
