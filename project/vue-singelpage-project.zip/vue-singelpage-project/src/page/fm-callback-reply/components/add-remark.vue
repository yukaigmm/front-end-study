<template>
  <Modal v-model="modal" title="填写备注" width="500" :mask-closable="false">
    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button @click="cancel">取消</Button>
      <Button @click="ok" type="primary" :loading="btnLoading">确定</Button>
    </div>
    <i-input
      v-model="remark"
      placeholder="请填写内容"
      type="textarea"
      :autosize="{minRows:2,maxRows:6}"
    />
  </Modal>
</template>

<script>


export default {
  props:['btnLoading'],
  data() {
    return {
      remark: "",
      id: "",
      modal: false
    };
  },


  methods: {
    show(remark, id) {
      this.modal = true;
      this.id = id;
      this.remark = remark;
    },

    ok() {
      this.$emit("ok", this.remark, this.id);
    },

    cancel() {
      this.remark = "";
      this.id = "";
      this.modal = false;
    }
  }
};
</script>

<style lang="less" scoped>
</style>

