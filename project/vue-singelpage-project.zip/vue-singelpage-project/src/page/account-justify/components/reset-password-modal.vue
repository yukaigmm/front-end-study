<template>
  <Modal
    v-model="modal"
    title="重置密码"
    width="450"
    class="reset-password-modal"
    :mask-closable="false"
  >
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button type="default" @click="onCancel">取消</Button>
      <Button type="primary" @click="onOk">确定重置密码</Button>
    </div>

    <p style="text-indent:2em;">
      此功能将重置用户的账号密码，重置后，用户需要使用新密码登陆
      <span class="special">官网、</span>
      <span class="special">组合大师、</span>
      <span class="special">基金大师，</span>
      重置成功，会将新密码通过短信发送给用户。
    </p>

    <Form ref="form" :model="formData" :rules="validateRules" :label-width="90">
      <FormItem label="手机号">
        <span style="line-height:32px;">{{formData.phoneNumber||"--"}}</span>
      </FormItem>

      <FormItem label="姓名">
        <span style="line-height:32px;">{{formData.name||"--"}}</span>
      </FormItem>

      <FormItem label="新密码" prop="newPassword">
        <Input
          v-model.trim="formData.newPassword"
          placeholder="请输入新密码"
          :type="newPasswordInputType"
          :icon="newPasswordIconType"
          @on-click="swithVisable('newPassword')"
        />
      </FormItem>

      <FormItem label="重复新密码" prop="duplicatePassword">
        <Input
          :disabled="!formData.newPassword"
          v-model.trim="formData.duplicatePassword"
          placeholder="请再次输入新密码"
          :type="rePasswordInputType"
          :icon="reIconType"
          @on-click="swithVisable('repeatNewPassword')"
        />
      </FormItem>
    </Form>

    <comfirmModal ref="comfirmModal" @onReset="onCancel"></comfirmModal>
  </Modal>
</template>

<script>
import comfirmModal from "./comfirm-reset-pass-modal.vue";
export default {
  components: {
    comfirmModal
  },

  data() {
    const validatePassword = prop => {
      return (rule, value, callback) => {
        let errors = [];
        if (prop === "newPassword") {
          if (this.formData.duplicatePassword) {
            if (value != this.formData.duplicatePassword) {
              errors.push("两次密码输入不一致");
            }
          }
        } else {
          if (this.formData.newPassword) {
            if (this.formData.newPassword != value) {
              errors.push("两次密码输入不一致");
            }
          }
        }

        callback(errors);
      };
    };

    return {
      modal: false,
      formData: {
        phoneNumber: "",
        name: "",
        officialUserId: "",
        newPassword: "",
        duplicatePassword: "",
        productId: ""
      },
      ifNewPWDVisiable: false,
      ifRePWDVisiable: false,
      validateRules: {
        newPassword: [
          {
            min: 6,
            message: "密码长度不能低于6位"
          },
          {
            required: true,
            message: "密码不能为空"
          },
          {
            validator: validatePassword("newPassword"),
            trigger: "blur"
          }
        ],
        duplicatePassword: [
          {
            min: 6,
            message: "密码长度不能低于6位"
          },
          {
            required: true,
            message: "密码不能为空"
          },
          {
            validator: validatePassword("repeatNewPassword"),
            trigger: "blur"
          }
        ]
      }
    };
  },

  computed: {
    newPasswordInputType() {
      return this.ifNewPWDVisiable ? "text" : "password";
    },
    newPasswordIconType() {
      return this.ifNewPWDVisiable ? "eye-disabled" : "eye";
    },
    rePasswordInputType() {
      return this.ifRePWDVisiable ? "text" : "password";
    },
    reIconType() {
      return this.ifRePWDVisiable ? "eye-disabled" : "eye";
    }
  },

  methods: {
    // 点击取消
    onCancel() {
      this.formData = {
        phoneNumber: "",
        name: "",
        officialUserId: "",
        newPassword: "",
        duplicatePassword: "",
        productId: ""
      };
      this.$refs.form.resetFields();
      this.ifNewPWDVisiable = false;
      this.ifRePWDVisiable = false;
      this.modal = false;
    },

    // 点击确定
    onOk() {
      let labelStyle = {
        display: "inline-block",
        width: "80px",
        marginRight: "10px",
        textAlign: "right",
        marginTop: "15px"
      };

      let items = [
        {
          key: "phoneNumber",
          label: "手机号:"
        },
        {
          key: "name",
          label: "姓名:"
        },
        {
          key: "newPassword",
          label: "新密码:"
        }
      ];

      this.$refs.form.validate(valid => {
        if (valid) {
          // this.$Modal.confirm({
          //   width:300,
          //   render: h => {
          //     return h("div", [
          //       h("h5", "您正在重置用户密码，请谨慎操作!"),

          //       ...items.map(item => {
          //         return h("p", [
          //           h(
          //             "span",
          //             {
          //               style: { ...labelStyle }
          //             },
          //             `${item.label}`
          //           ),
          //           h("span", `${this.formData[item.key] || "--"}`)
          //         ]);
          //       })
          //     ]);
          //   },
          //   onOk: () => {
          //     this.resetPWd();
          //   },
          // });
          this.$refs.comfirmModal.show(this.formData);
        } else {
          this.$Message.warning("请按照红色字段修改内容!");
        }
      });
    },

    // 重置密码
    resetPWd() {
      let keys = [
        "officialUserId",
        "productId",
        "duplicatePassword",
        "newPassword",
        "phoneNumber"
      ];
      let params = {};
      keys.forEach(key => {
        params[key] = this.formData[key];
      });

      if (params.phoneNumber) {
        params.mobile = params.phoneNumber;
        delete params.phoneNumber;
      }
      this.$Message.loading("重置中，请稍候...");

      this.$http.putWithoutId("accounts/resetPassword", params).then(res => {
        this.$Message.destroy();
        if (res.code === 20000) {
          this.$Message.success("修改成功！");
          this.onCancel();
        } else {
          this.$Message.error(`修改失败：${res.msg}!`);
        }
      });
    },

    // 显示模态框
    show(accountInfo = {}) {
      for (let key in this.formData) {
        this.$set(this.formData, key, accountInfo[key] || "");
      }
      this.modal = true;
    },

    // 切换密码的显、隐状态
    swithVisable(prop) {
      if (prop === "newPassword") {
        this.ifNewPWDVisiable = !this.ifNewPWDVisiable;
      } else {
        this.ifRePWDVisiable = !this.ifRePWDVisiable;
      }
    }
  }
};
</script>

<style lang="less" scoped>
.special {
  font-weight: 900;
  font-size: 14px;
}
</style>


