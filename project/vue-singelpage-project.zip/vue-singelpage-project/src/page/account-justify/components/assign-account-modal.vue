<template>
  <Modal
    v-model="modal"
    title="分配责任人"
    :mask-closable="false"
    width="500"
    class="reset-password-modal"
  >
    <div slot="footer">
      <Button type="primary" @click="onOk" :loading="btnLoading">确定</Button>
      <Button @click="onCancel">取消</Button>
    </div>

    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <Select
      v-model="managerId"
      :multiple="multiple"
      placeholder="请选择责任人"
      :key="selectKey"
      clearable
    >
      <Option v-for="(item,index) in managersList" :key="index" :value="item.value-0">{{item.label}}</Option>
    </Select>
  </Modal>
</template>

<script>
import { map } from "lodash";
export default {
  props: {
    multiple: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      btnLoading: false,
      productId: "",
      selectKey: null,
      managersList: [],
      modal: false,
      managerId: "",
      accountIds: []
    };
  },

  created() {
    this.getManagersList();
  },

  methods: {
    getManagersList() {
      this.$http
        .get("dept/getUserByDept", {
          dept_id: 16,
          type: 1
        })
        .then(res => {
          if (res.code === 20000) {
            this.managersList = map(res.data, person => person).filter(
              item => item.status
            );
          }
        })
        .catch(e => {
          console.error("获取人员列表失败");
        });
    },

    show(managerId, accountId, productId) {
      this.selectKey = Date.now();
      if (managerId) {
        this.managerId = managerId - 0;
      }
      this.accountIds = accountId;
      this.productId = productId;
      this.modal = true;
    },

    onOk() {
      if (this.managerId) {
        this.setResponsor();
      } else {
        this.$Message.warning("请先选择责任人！");
      }
    },

    setResponsor() {
      let params = {
        productId: this.productId,
        accIds: this.accountIds,
        managerId: this.managerId
      };
      this.btnLoading = true;
      this.$http
        .putWithoutId("accounts/setAccountManager", params)
        .then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.$Message.success("分配成功！");
            this.$emit("refreshTable");
            this.$emit("clearSelection");
            this.onCancel();
          } else {
            this.$Message.error(`分配失败：${res.msg}`);
          }
        });
    },

    onCancel() {
      this.managerId = "";
      this.accountIds = [];
      this.productId = "";
      this.modal = false;
    }
  }
};
</script>

<style lang="less" scoped>
</style>


