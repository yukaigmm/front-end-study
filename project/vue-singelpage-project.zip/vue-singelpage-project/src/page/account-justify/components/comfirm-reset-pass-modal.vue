<template>
  <Modal v-model="modal" :mask-closable="false" width="300" class="comfirm-pass-modal">
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button type="default" @click="onCancel">取消</Button>
      <Button type="primary" @click="onOk">确定</Button>
    </div>

    <h5>您正在重置用户密码，请谨慎操作!</h5>

    <p v-for="(item,index) in items" :key="index">
      <span :style="labelStyle">{{item.label}}</span>
      <span>{{formData[item.key]||"--"}}</span>
    </p>
  </Modal>
</template>

<script>
export default {
  data() {
    return {
      formData: {
        phoneNumber: "",
        name: "",
        newPassword: ""
      },
      modal: false,
      labelStyle: {
        display: "inline-block",
        width: "80px",
        marginRight: "10px",
        textAlign: "right",
        marginTop: "15px"
      },
      items: [
        {
          key: "phoneNumber",
          label: "手机号:"
        },
        {
          key: "name",
          label: "姓名:"
        },
        {
          key: "newPassword",
          label: "新密码:"
        }
      ]
    };
  },

  methods: {
    onOk() {
      this.resetPWd();
    },

    // 重置密码
    resetPWd() {
      let keys = [
        "officialUserId",
        "productId",
        "duplicatePassword",
        "newPassword",
        "phoneNumber"
      ];
      let params = {};
      keys.forEach(key => {
        params[key] = this.formData[key];
      });

      if (params.phoneNumber) {
        params.mobile = params.phoneNumber;
        delete params.phoneNumber;
      }
      this.$Message.loading("重置中，请稍候...");

      this.$http.putWithoutId("accounts/resetPassword", params).then(res => {
        this.$Message.destroy();
        if (res.code === 20000) {
          this.$Message.success("修改成功！");
          this.onCancel();
          this.$emit("onReset");
        } else {
          this.$Message.error(`修改失败：${res.msg}!`);
        }
      });
    },

    show(data) {
      this.formData = data;
      this.modal = true;
    },

    onCancel() {
      this.modal = false;
      this.formData = {};
    }
  }
};
</script>

<style lang="less" scoped>
</style>
