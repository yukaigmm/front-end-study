<template>
  <Modal class="cus-logo-modal" v-model="modal" title="自定义logo" width="600" :mask-closable="false">
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button type="default" @click="onCancel">取消</Button>
      <Button type="primary" :loading="btnLoading" @click="onOK">确定</Button>
    </div>

    <div class="action-wrap">
      <label for="uploads" class="upload-btn">{{cropperOptions.img?"更换图片":"上传图片"}}</label>
      <input
        v-if="modal"
        ref="picUpload"
        class="upload-pic-wrap"
        type="file"
        id="uploads"
        accept="image/*"
        @change="uploadImg($event)"
      >
      <Button type="primary" :disabled="!cropperOptions.img" @click="spinLeft">左转</Button>
      <Button type="primary" :disabled="!cropperOptions.img" @click="spinRight">右转</Button>
    </div>

    <div class="pic-wrap">
      <div class="pic-area">
        <vue-cropper
          :key="picKey"
          ref="vueCropper"
          :outputSize="cropperOptions.outputSize"
          autoCrop
          :autoCropWidth="165"
          :autoCropHeight="46"
          :fixedNumber="[165,46]"
          :fixed="fixed"
          original
          @realTime="realTime"
          :img="cropperOptions.img"
        />
      </div>

      <div class="real-time-wrap" :style="previews.div">
        <img :src="previews.url" :style="previews.img">
      </div>
    </div>
  </Modal>
</template>


<script>
import { VueCropper } from "vue-cropper";

export default {
  components: {
    VueCropper
  },

  data() {
    return {
      fixed: false,
      previews: {},
      picKey: "",
      cropperOptions: {
        outputSize: 1,
        img: ""
      },
      modal: false,
      btnLoading: false
    };
  },

  methods: {
    onCancel() {
      this.modal = false;
      this.$refs.picUpload.value = "";
      this.cropperOptions = {
        outputSize: 1,
        img: ""
      };
      this.$refs.vueCropper.clearCrop();
      this.previews = {};
    },

    onOK() {
      if (!this.cropperOptions.img) {
        this.onCancel();

        return;
      }
      this.$refs.vueCropper.getCropData(data => {
        this.$emit("getBase64Pic", data);
        this.$refs.vueCropper.getCropBlob(pic => {
          this.$emit("getBlobPic", pic);
          this.onCancel();
        });
      });
    },

    spinLeft() {
      this.$refs.vueCropper.rotateLeft();
    },

    spinRight() {
      this.$refs.vueCropper.rotateRight();
    },

    show() {
      this.modal = true;
      this.picKey = Date.now();
    },

    realTime(data) {
      this.previews = data;
      if (data.w > 165 || data.h > 46) {
        this.fixed = true;
      } else {
        this.fixed = false;
      }
    },

    uploadImg(e) {
      let file = e.target.files[0];
      let type = file.type;

      if (!type.includes("image")) {
        this.$Message.error("只能上传图片！");
        return;
      }

      let _this = this;
      let reader = new FileReader();

      reader.onload = event => {
        let data;

        let img = new Image();
        img.src = event.target.result;
        // if (typeof event.target.result === "object") {
        //   data = window.URL.createObjectURL(new Blob([event.target.result]));
        // } else {
        //   data = event.target.result;
        // }
        if (img.complete) {
          data = _this.getPicData(img, type);
          _this.$set(this.cropperOptions, "img", data);
        } else {
          img.onload = () => {
            data = _this.getPicData(img, type);
            _this.$set(this.cropperOptions, "img", data);
          };
          img.onerror = () => {
            _this.$Message.error("上传失败！");
          };
        }
      };

      reader.readAsDataURL(file);
    },
    getPicData(img, type) {
      let imgType = type.split("/")[1];
      let canvas = document.createElement("canvas");
      let ctx = canvas.getContext("2d");
      let width = img.width;
      let height = img.height;
      canvas.width = width;
      canvas.height = height;
      ctx.fillStyle = "#234";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, width, height);
      let data = canvas.toDataURL(`image/${imgType}`, 1);
      return data;
    }
  }
};
</script>

<style lang="less" scoped>
.pic-area {
  height: 300px;
}

.upload-pic-wrap {
  display: none;
}

.upload-btn {
  display: inline-block;
  padding: 5px 8px;
  color: #fff;
  border: 1px solid #2d8cf0;
  background: #2d8cf0;
  border-radius: 4px;
  margin-right: 8px;
  &:hover {
    border-color: #57a3f3;
    background: #57a3f3;
  }
}

.action-wrap {
  margin-bottom: 10px;
}

.real-time-wrap {
  margin: 10px;
  overflow: hidden;
}
</style>

