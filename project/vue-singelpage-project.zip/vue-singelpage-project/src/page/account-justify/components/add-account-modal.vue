<template>
  <Modal
    class="choose-mutiple-targets"
    v-model="modal"
    title="账号开通"
    :mask-closable="false"
    width="1000"
  >
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button type="default" @click="onCancel">取消</Button>
      <Button type="primary" @click="onOk" :loading="buttonLoading">确定</Button>
    </div>

    <!-- <div class="tips">注：密码不填则默认为手机号码后6位</div> -->
    <Form :model="accountData" ref="form" :rules="validateRules" :label-width="90">
      <Row>
        <Col span="12" class="visit-card">
          <FormItem prop="visitingCardUrl" label="名片">
            <Upload
              v-loading="imgLoading"
              element-loading-text="上传中，请稍候"
              :show-upload-list="false"
              :default-file-list="defaultFileList"
              ref="upload"
              accept="image/*"
              action="api/common/uploadFile"
              :on-error="onUploadError"
              :on-success="onUploadSuccess"
              :before-upload="beforeUpload"
              style="display: inline-block;width:362px;height:214px;border:1px dotted #ccc;"
              :data="{fileType:'visitingCard'}"
            >
              <!-- <Button type="ghost" icon="ios-cloud-upload-outline">上传名片</Button> -->
              <div class="upload-list-img" v-if="imgUrl">
                <img :src="imgUrl" :alt="accountData.realName+'名片'" @click="onPreviewCard">
                <div class="upload-list-cover">
                  <div class="change-button" title="更换名片">
                    <Icon type="ios-cloud-upload"></Icon>
                  </div>
                  <div class="preview-button" @click="onPreviewCard" title="预览">
                    <Icon type="ios-eye-outline"></Icon>
                  </div>
                  <div class="delete-button" @click="onUploadsRemove" title="删除名片">
                    <Icon type="ios-trash-outline"></Icon>
                  </div>
                </div>
              </div>

              <div v-else class="upload-button-container" title="上传名片">
                <Icon type="camera" size="20"></Icon>
              </div>
            </Upload>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="用户名" prop="realName">
            <Input v-model.trim="accountData.realName" placeholder="请输入用户名" disabled></Input>
          </FormItem>
        </Col>

        <Col span="12" class="telephone-col">
          <FormItem label="手机号码" prop="cellphone">
            <Input v-model.trim="accountData.cellphone" placeholder="请输入手机号码" disabled></Input>
          </FormItem>
        </Col>

        <!-- <Col span='12'>
                 <FormItem label='密码' prop='password'>
                    <Input
                      v-model.trim='accountData.password'
                      :type="passwordType"
                      :icon="passwordIcon"
                      placeholder="请输入密码"
                      :key='passwordKey'
                      @on-click='toggleVisibility'></Input>
                 </FormItem>
        </Col>-->
        <Col span="12" class="email-col">
          <FormItem label="邮箱" prop="email">
            <Input v-model.trim="accountData.email" placeholder="请输入邮箱" disabled></Input>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="产品类型" prop="productId">
            <Select v-model="accountData.productId" placeholder="请选择产品类型" clearable>
              <Option
                v-for="item in productList"
                :value="item.value"
                :key="item.value"
                :disabled="item.value==2"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="用户组" prop="groupId">
            <Select
              v-model="accountData.groupId"
              placeholder="请选择用户组"
              :disabled="accountData.groupId==1"
              clearable
            >
              <Option
                v-for="item in groupIdList"
                :value="item.value"
                :disabled="item.disabled"
                :key="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="账号状态" prop="accountStatus">
            <Select v-model="accountData.accountStatus" placeholder="请选择账号状态" clearable>
              <Option
                v-for="item in accountStatusList"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="是否付费" prop="payingFlag">
            <Select v-model="accountData.payingFlag" placeholder="请选择付费状态" clearable>
              <Option
                v-for="item in payingFlagList"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <!-- <Col span='12'>
                 <FormItem label='用户状态' prop='userLevel'>
                    <Select v-model="accountData.userLevel" placeholder='请选择用户状态'>
                       <Option
                         v-for="item in userLevelList"
                         :value="item.value"
                         :key='item.value'>
                           {{item.label}}
                       </Option>
                    </Select>
                 </FormItem>
        </Col>-->
        <!-- <Col span='12'>
                 <FormItem label='邀请码' prop='invitedCode'>
                     <Input v-model.trim='accountData.invitedCode' placeholder="请输入邀请码"></Input>
                 </FormItem>
        </Col>-->
        <Col span="12">
          <FormItem label="开始日期" prop="beginDate">
            <DatePicker
              style="width:100%"
              v-model="accountData.beginDate"
              type="date"
              disabled
              placeholder="请选择开始日期"
            ></DatePicker>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem label="结束日期" prop="endDate" class="account-end-date">
            <DatePicker
              style="width:100%"
              v-model="accountData.endDate"
              type="date"
              placeholder="请选择结束日期"
            ></DatePicker>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="isHide" label="隐藏数据">
            <Checkbox
              :disabled="!hasRightToHideFund"
              v-model="accountData.isHide"
              :true-value="1"
              :false-value="0"
            >是(选中即隐藏基金数据)</Checkbox>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="logo" label="自定义logo">
            <div
              class="cus-logo"
              @click="showCustomizedLogoModal"
              :title="cusLogoSrc?'更换logo':''"
              :style="logoStyle"
            >
              {{cusLogoSrc?"":"请选择logo"}}
              <div
                class="clear-logo-wrap"
                v-show="cusLogoSrc"
                @click.prevent.stop="clearLogo"
                title="清除"
              >×</div>
            </div>
          </FormItem>
        </Col>

        <Col span="24">
          <FormItem label="备注" prop="remark">
            <Input
              type="textarea"
              :autosize="{minRows: 2,maxRows: 5}"
              v-model.trim="accountData.remark"
              placeholder="请输入备注"
            ></Input>
          </FormItem>
        </Col>
      </Row>
    </Form>
    <customized-logo-modal
      ref="customizedLogoModal"
      @getBase64Pic="getBase64Pic"
      @getBlobPic="getBlobPic"
    />
  </Modal>
</template>



<script>
const validatePassword = (rules, value, callback) => {
  let error = [];
  if (value && (value.trim().length < 6 || value.trim().length > 18)) {
    error.push(new Error("密码应该在6~18位之间"));
  }
  callback(error);
};

import { mapGetters } from "vuex";
import customizedLogoModal from "./customized-logo.vue";
import $ from "jquery";
import moment from "moment";
import uglifyPic from "@/mixins/condensePic";
export default {
  mixins: [uglifyPic],

  components: {
    customizedLogoModal
  },

  data() {
    return {
      logoStyle: {},
      cusLogoSrc: "",
      cusLogoBlob: "",
      imgLoading: false,
      buttonLoading: false,
      // passwordIcon: "eye",
      // passwordType: "password",
      // passwordKey: "",
      productList: [
        {
          value: 1,
          label: "组合大师"
        },
        {
          value: 2,
          label: "基金大师"
        }
      ],
      accountStatusList: [
        {
          value: 0,
          label: "异常"
        },
        {
          value: 1,
          label: "申请"
        },
        {
          value: 2,
          label: "试用"
        },
        {
          value: 3,
          label: "正式"
        },
        {
          value: 4,
          label: "停用"
        }
      ],
      groupIdList: [
        {
          value: 1,
          label: "组合大师管理员",
          disabled: true
        },
        {
          value: 2,
          label: "VIP会员"
        },
        {
          value: 3,
          label: "普通会员"
        }
      ],
      userLevelList: [
        {
          value: 0,
          label: "异常"
        },
        {
          value: 1,
          label: "正常"
        }
      ],
      payingFlagList: [
        {
          value: 0,
          label: "未付费"
        },
        {
          value: 1,
          label: "已付费"
        }
      ],
      modal: false,
      accountData: {
        orgId: "",
        productId: 1,
        cellphone: "",
        // password: "",
        realName: "",
        email: "",
        visitingCardUrl: "",
        accountStatus: 2,
        groupId: 3,
        payingFlag: 0,
        logo: "",
        beginDate: "",
        endDate: "",
        remark: "",
        isHide: 1
      },
      defaultFileList: [],
      imgUrl: ""
    };
  },

  computed: {
    validateRules() {
      const validateEndDate = (rules, value, callback) => {
        let errors = [];
        if (
          this.accountData.accountStatus == "2" ||
          this.accountData.accountStatus == "3"
        ) {
          if (!value) {
            errors.push(new Error("结束日期不能为空"));
          }
        }
        callback(errors);
      };

      return {
        productId: [{ required: true, message: "产品类型不能为空" }],
        cellphone: [
          {
            required: true,
            message: "手机号不能为空"
          },
          {
            pattern: /^1(3|4|5|6|7|8|9)\d{9}$/,
            trigger: "change,blur",
            message: "请输入正确的手机号码"
          }
        ],
        accountStatus: [{ required: true, message: "账号状态不能为空" }],
        name: [{ required: true, message: "姓名不能为空" }],
        endDate: [{ validator: validateEndDate }],
        groupId: [{ required: true, message: "用户组不能为空" }],
        visitingCardUrl: [
          { required: true, message: "请上传名片", trigger: "change" }
        ]
      };
    },

    ...mapGetters({
      userInfo: "getUser"
    }),

    hasRightToHideFund() {
      return this.userInfo.auth.functional.includes("hideFund");
    }
  },

  watch: {
    "accountData.accountStatus": {
      handler(val) {
        if (val && (val == 2 || val == 3)) {
          $(this.$el)
            .find(".account-end-date.ivu-form-item")
            .addClass("ivu-form-item-required");
        } else {
          $(this.$el)
            .find(".account-end-date.ivu-form-item")
            .removeClass("ivu-form-item-required");
        }
      },
      deep: true
    }
  },

  methods: {
    clearLogo() {
      this.cusLogoSrc = "";
      this.logoStyle = {};
      this.cusLogoBlob = "";
      this.formData.logo = "";
    },

    showCustomizedLogoModal() {
      this.$refs.customizedLogoModal.show();
    },

    getBase64Pic(pic) {
      this.cusLogoSrc = pic;
      let style = {
        "background-image": `url(${this.cusLogoSrc})`,
        " background-repeat": "no-repeat",
        "background-size": "100% 100%",
        "-moz-background-size": "100% 100%"
      };
      this.logoStyle = {
        ...style
      };
    },

    getBlobPic(pic) {
      this.cusLogoBlob = pic;
    },

    upLoadCusLogo() {
      let type = this.cusLogoBlob.type.split("/")[1];
      let formData = new FormData();
      formData.append("fileType", "customizedLogo");
      formData.append("file", this.cusLogoBlob, `${Date.now()}.${type}`);

      return new Promise((resolve, reject) => {
        this.$http.post("/common/uploadFile", formData).then(res => {
          if (res.code === 20000) {
            resolve(res.data.filePath);
          } else {
            this.$Message.error(`上传logo失败:${res.data.errorMsg}`);
            reject(false);
          }
        });
      });
    },

    stopDefault(e) {
      return false;
    },
    // 切换密码的显示状态
    // toggleVisibility() {
    //   this.passwordKey = Date.now();
    //   if (this.passwordIcon === "eye") {
    //     this.passwordIcon = "eye-disabled";
    //     this.passwordType = "text";
    //   } else {
    //     this.passwordIcon = "eye";
    //     this.passwordType = "password";
    //   }
    // },

    // 上传之前清空已有列表，控制只能上传一个文件
    beforeUpload(file) {
      this.$refs.upload.clearFiles();
      this.imgLoading = true;
      this.uglifyPic(file, "form", "accountData", "visitingCardUrl");
      return false;
    },

    // 预览文件
    onPreviewCard(e) {
      e.stopPropagation();
      e.preventDefault();
      window.open(`${this.imgUrl}`);
      return false;
    },

    getImgUrl(path) {
      let url;
      let picUrl;
      if (path.includes("/Onstage/")) {
        url =
          process.env.NODE_ENV === "production"
            ? "https://fof.simuwang.com/"
            : "https://master-test.simuwang.com/";
      } else {
        url =
          process.env.NODE_ENV === "production"
            ? " http://static.simuwang.com/"
            : "https://static-test-ali.simuwang.com/";
        picUrl = `Uploads/crm/${path}`;
      }
      this.imgUrl = `${url}${picUrl}`;
    },

    // 上传成功
    onUploadSuccess(response, file, fileList) {
      let res = response;

      this.imgLoading = false;

      if (res.code === 20000) {
        this.$Message.success("上传成功！");
        this.accountData.visitingCardUrl = res.data.filePath;
        this.$refs.form.validateField("visitingCardUrl");
        let url;
        let picUrl;
        if (res.data.filePath.includes("/Onstage/")) {
          url =
            process.env.NODE_ENV === "production"
              ? "https://fof.simuwang.com/"
              : "https://master-test.simuwang.com/";
        } else {
          url =
            process.env.NODE_ENV === "production"
              ? " http://static.simuwang.com/"
              : "https://static-test-ali.simuwang.com/";
          picUrl = `Uploads/crm/${res.data.filePath}`;
        }
        this.imgUrl = `${url}${picUrl}`;
        // this.$refs.form.validateField("visitingCardUrl");
      } else {
        this.$Message.error(`上传失败：${res.msg}`);
      }
    },

    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },

    //  移除上传附件
    onUploadsRemove(e) {
      e.stopPropagation();
      e.preventDefault();
      this.$refs.upload.clearFiles();
      this.accountData.visitingCardUrl = "";
      this.imgUrl = "";
      this.$refs.form.validateField("visitingCardUrl");
      return false;
      // this.$refs.form.validateField("visitingCardUrl");
    },

    // 上传失败
    onUploadError(error, file, fileList) {
      this.imgLoading = false;
      this.$Message.error("上传失败！");
    },

    // 默认显示人员的部分信息
    show(data) {
      this.modal = true;
      this.accountData.cellphone = data.telephone || "";
      this.accountData.orgId = data.org_id;
      this.accountData.email = data.email || "";
      this.accountData.realName = data.name || "";
      this.accountData.visitingCardUrl = data.visiting_card_url || "";
      if (data.visiting_card_url) {
        this.getImgUrl(data.visiting_card_url);
      }
      this.accountData.beginDate = moment(new Date()).format("YYYY-MM-DD");
      this.accountData.endDate = moment(new Date())
        .add(1, "month")
        .format("YYYY-MM-DD");
    },

    onOk() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.addAccount();
        } else {
          let that = this;
          this.$Message.error("请按红色字段填写内容！");
          setTimeout(() => {
            $(that.$el)
              .find(".account-end-date.ivu-form-item")
              .addClass("ivu-form-item-required");
          }, 0);
        }
      });
    },

    // 添加账号
    async addAccount() {
      this.buttonLoading = true;
      let logo;
      let flag = false;
      if (this.cusLogoSrc) {
        try {
          logo = await this.upLoadCusLogo();
        } catch (err) {
          flag = !err;
        }
      }

      if (flag) {
        this.buttonLoading = false;
        return;
      }

      this.accountData.logo = logo || "";
      if (this.accountData.beginDate) {
        this.accountData.beginDate = this.setTimeZone(
          this.accountData.beginDate
        );
      }
      if (this.accountData.endDate) {
        this.accountData.endDate = this.setTimeZone(this.accountData.endDate);
      }

      let params = {
        ...this.accountData
      };

      this.$http.post("/accounts/registerAccount", params).then(res => {
        if (res.code === 20000) {
          this.$Message.success("添加成功！");
          this.$emit("refreshTable");
          this.onCancel();
        } else {
          this.$Message.error(`添加失败：${res.msg}`);
        }
        this.buttonLoading = false;
      });
    },

    onCancel() {
      this.$refs.form.resetFields();
      this.accountData = {
        orgId: "",
        productId: 1,
        cellphone: "",
        realName: "",
        email: "",
        logo: "",
        visitingCardUrl: "",
        accountStatus: 2,
        groupId: 3,
        payingFlag: 0,
        beginDate: "",
        endDate: "",
        remark: "",
        isHide: 1
      };
      this.imgUrl = "";
      this.$refs.upload.clearFiles();
      this.modal = false;
      this.logoStyle = {};
      this.cusLogoSrc = "";
      this.cusLogoBlob = "";
    }
  }
};
</script>

<style lang="less" scoped>
.upload-list-img {
  cursor: pointer;
  vertical-align: top;
  display: inline-block;
  width: 360px;
  height: 212px;
  text-align: center;
  line-height: 212px;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  margin-right: 4px;
  img {
    width: 100%;
    height: 100%;
  }
}
.upload-button-container {
  width: 360px;
  height: 212px;
  line-height: 212px;
  text-align: center;
  overflow: hidden;
}

.upload-list-cover {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  position: absolute;
  height: 60px;
  bottom: -60px;
  left: 0;
  right: 0;
  line-height: 60px;
  background: rgba(0, 0, 0, 0.6);
  transition: all 0.5s ease;
  div {
    flex: 1;
  }
}
.upload-list-img:hover .upload-list-cover {
  bottom: 0;
}
.upload-list-cover i {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 5px;
}

.cus-logo {
  position: relative;
  width: 167px;
  height: 48px;
  line-height: 35px;
  border: 1px solid #dddee1;
  border-radius: 4px;
  .clear-logo-wrap {
    position: absolute;
    width: 20px;
    height: 20px;
    line-height: 20px;
    text-align: center;
    color: #fff;
    border-radius: 50%;
    top: -10px;
    right: -1000000000000px;
    background: rgba(0, 0, 0, 0.6);
  }
  &:hover {
    border-color: #57a3f3;
    .clear-logo-wrap {
      right: -10px;
    }
  }
  cursor: pointer;
}
</style>


