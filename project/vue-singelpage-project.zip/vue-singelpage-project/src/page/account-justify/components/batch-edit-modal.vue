<template>
  <Modal v-model="modal" :mask-closable="false" title="批量编辑账号" width="780">
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button type="default" @click="onCancel">取消</Button>
      <Button type="primary" :loading="btnLoading" @click="onOK">确定</Button>
    </div>

    <h4>账号列表</h4>

    <div class="batch-edit-table-area">
      <Table :data="tableData" :columns="columns" border/>
    </div>

    <div class="form-area">
      <Form
        :model="formData"
        :label-width="90"
        ref="form"
        :rules="validateRules"
        style="overflow:hidden;padding:10px;"
      >
        <Row>
          <i-col span="12">
            <Checkbox v-model="ifEditTime">
              <FormItem prop="endDate">
                <div slot="label">
                  结束时间
                  <Tooltip content="列表中的账号的结束日期将统一修改为这个日期">
                    <Icon size="14" type="ios-help" color="#2d8cf0"/>
                  </Tooltip>
                </div>
                <DatePicker
                  v-model="formData.endDate"
                  placeholder="请选择结束时间"
                  type="date"
                  :disabled="!ifEditTime"
                  formate="YYYY-MM-DD"
                  transfer
                />
              </FormItem>
            </Checkbox>
          </i-col>

          <i-col span="12" class="cus-span">
            <Checkbox v-model="ifEditLogo">自定义logo</Checkbox>

            <div
              :class="{'disabled-cus-logo':!this.ifEditLogo}"
              class="cus-logo"
              @click.prevent="showCustomizedLogoModal"
              :title="cusLogoSrc?'更换logo':''"
              :style="logoStyle"
            >
              {{cusLogoSrc?"":"请选择logo"}}
              <div
                class="clear-logo-wrap"
                v-show="cusLogoSrc"
                @click.prevent.stop="clearLogo"
                title="清除"
              >×</div>
            </div>
          </i-col>
        </Row>
      </Form>
    </div>
    <logo-modal ref="logoModal" @getBase64Pic="getBase64Pic" @getBlobPic="getBlobPic"/>
  </Modal>
</template>


<script>
import $ from "jquery";
import moment from "moment";
import logoModal from "./customized-logo.vue";
export default {
  props: {
    tableData: {
      type: [Array, Object],
      default: () => []
    }
  },

  components: {
    logoModal
  },

  data() {
    return {
      modalKey: "",
      logoStyle: {},
      cusLogoSrc: "",
      cusLogoBlob: "",
      fofLogo: require("../../../assets/fof-logo.png"),
      fmLogo: require("../../../assets/fm-logo.png"),
      btnLoading: false,
      modal: false,
      ifEditTime: false,
      ifEditLogo: false,
      columns: [
        {
          key: "realName",
          title: "用户名",
          width: 80,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  display: "flex",
                  justifyContent: "flex-start",
                  alignItems: "center"
                }
              },
              [
                h("span", {
                  attrs: {
                    title: row.productId == 1 ? "组合大师账号" : "基金大师账号"
                  },
                  style: {
                    backgroundImage:
                      row.productId == 1
                        ? `url(${this.fofLogo})`
                        : `url(${this.fmLogo})`,
                    display: "inline-block",
                    backgroundSize: "100%",
                    backgroundRepeat: "no-repeat",
                    width: "20px",
                    height: "20px",
                    borderRadius: "4px",
                    marginRight: "5px"
                  }
                }),
                h("span", row.realName || "--")
              ]
            );
          }
        },
        {
          key: "accountNo",
          title: "账号",
          width: 100,
          render(h, { row }) {
            return row.accountNo || "--";
          }
        },
        // {
        //   key: "productId",
        //   title: "产品类型",
        //   width: 100,
        //   render(h, { row }) {
        //     let mapping = {
        //       "1": "组合大师",
        //       "2": "基金大师"
        //     };
        //     return mapping[row.productId] || "--";
        //   }
        // },
        {
          key: "accountStatus",
          title: "账号状态",
          width: 80,
          render(h, { row }) {
            let mapping = {
              "4": "停用",
              "3": "正式",
              "2": "试用",
              "1": "申请",
              "0": "异常"
            };
            return mapping[row.accountStatus] || "--";
          }
        },
        // {
        //   key: "beginDate",
        //   title: "开始日期",
        //   width: 100,
        //   render(h, { row }) {
        //     return row.beginDate ? row.beginDate.substr(0, 11) : "--";
        //   }
        // },
        {
          key: "endDate",
          title: "结束日期",
          width: 100,
          render(h, { row }) {
            return row.endDate ? row.endDate.substr(0, 11) : "--";
          }
        },
        {
          key: "managerName",
          title: "责任人",
          width: 80,
          render(h, { row }) {
            return h("span", row.managerName || "--");
          }
        },
        {
          key: "companyName",
          title: "机构名称",
          width: 300,
          render(h, { row }) {
            if (row.bread && row.bread.length) {
              return h(
                "div",
                row.bread.map((item, index) => {
                  if (index === row.bread.length - 1) {
                    return h(
                      "a",
                      {
                        attrs: {
                          href: "javascript:void(0)"
                        }
                      },
                      `${item.title}`
                    );
                  } else {
                    return h(
                      "a",
                      {
                        attrs: {
                          href: "javascript:void(0)"
                        }
                      },
                      `${item.title}>`
                    );
                  }
                })
              );
            } else {
              return h(
                "a",
                {
                  attrs: {
                    href: "javascript:void(0)"
                  }
                },
                "--"
              );
            }
          }
        }
      ],
      formData: { endDate: "", logo: "" },
      validateRules: {
        // endDate: [{ required: true, message: "结束时间不能为空" }]
      }
    };
  },

  methods: {
    clearLogo() {
      this.cusLogoSrc = "";
      this.logoStyle = {};
      this.cusLogoBlob = "";
      this.formData.logo = "";
    },

    showCustomizedLogoModal() {
      if (!this.ifEditLogo) {
        return;
      }

      this.$refs.logoModal.show();
    },

    getBase64Pic(pic) {
      this.cusLogoSrc = pic;
      let style = {
        "background-image": `url(${this.cusLogoSrc})`,
        " background-repeat": "no-repeat",
        "background-size": "100% 100%",
        "-moz-background-size": "100% 100%"
      };
      this.logoStyle = {
        ...style
      };
    },

    getBlobPic(pic) {
      this.cusLogoBlob = pic;
    },

    upLoadCusLogo() {
      let type = this.cusLogoBlob.type.split("/")[1];
      let formData = new FormData();
      formData.append("fileType", "customizedLogo");
      formData.append("file", this.cusLogoBlob, `${Date.now()}.${type}`);

      return new Promise((resolve, reject) => {
        this.$http.post("/common/uploadFile", formData).then(res => {
          if (res.code === 20000) {
            resolve(res.data.filePath);
          } else {
            this.$Message.error(`上传logo失败:${res.data.errorMsg}`);
            reject(false);
          }
        });
      });
    },

    show() {
      this.modal = true;
    },

    onCancel() {
      this.modal = false;
      this.formData = {
        endDate: ""
      };
      this.btnLoading = false;
      this.$refs.form.resetFields();
      this.ifEditTime = false;
      this.ifEditLogo = false;
      this.clearLogo();
    },

    onOK() {
      this.$refs.form.validate(async valid => {
        if (valid) {
          this.btnLoading = true;
          let logo;
          let flag = false;

          if (this.cusLogoSrc) {
            try {
              logo = await this.upLoadCusLogo();
            } catch (err) {
              flag = !err;
            }
          }

          if (flag) {
            this.btnLoading = false;
            return;
          }

          let params = {
            accIds: JSON.parse(JSON.stringify(this.tableData)).map(
              item => item.accId - 0
            ),
            endDate: moment(this.formData.endDate).format("YYYY-MM-DD"),
            logo,
            productId: JSON.parse(JSON.stringify(this.tableData)).map(
              item => item.productId - 0
            )[0]
          };

          if (!this.ifEditTime) {
            delete params.endDate;
          }

          if (!this.ifEditLogo) {
            delete params.logo;
          }
          if (!params.logo && !params.endDate) {
            this.$Message.warning("至少需要填写一项！");
            this.btnLoading = false;
            return;
          }
          this.$http
            .putWithoutId("accounts/setAccountEndDate", params)
            .then(res => {
              this.btnLoading = false;
              if (res.code === 20000) {
                this.$Message.success("设置成功");
                this.onCancel();
                this.$emit("clearSelection");
                this.$emit("refreshTable");
              } else {
                this.$Message.error(`设置失败：${res.msg}`);
              }
            });
        } else {
          this.$Message.warning("请按红色字段填写内容");
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.form-area {
  margin-top: 15px;
}

.ivu-form-item-label > div {
  display: inline-block;
}

.cus-logo {
  position: relative;
  width: 167px;
  height: 48px;
  line-height: 35px;
  border: 1px solid #dddee1;
  border-radius: 4px;
  .clear-logo-wrap {
    position: absolute;
    width: 20px;
    height: 20px;
    line-height: 20px;
    text-align: center;
    color: #fff;
    border-radius: 50%;
    top: -10px;
    right: -1000000000000px;
    background: rgba(0, 0, 0, 0.6);
  }
  &:hover {
    border-color: #57a3f3;
    .clear-logo-wrap {
      right: -10px;
    }
  }
  cursor: pointer;
}

.ivu-checkbox-wrapper {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  .ivu-form-item {
    margin-bottom: 0;
  }
  .ivu-form-item-required {
    margin-bottom: 0;
  }
}

.disabled-cus-logo {
  &:hover {
    border-color: #dddee1 !important;
  }
  cursor: not-allowed;
  color: #dddee1;
}

.cus-span {
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
</style>

