<template>
  <Modal
    title="编辑"
    v-model="modal"
    :mask-closable="false"
    width="1100"
    class="reset-password-modal"
  >
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button type="default" @click="onCancel">取消</Button>
      <Button type="primary" @click="onOk" :loading="btnLoading">确定</Button>
    </div>

    <Form
      v-loading="loading"
      element-loading-text="拼命加载中"
      :model="formData"
      ref="editAccountForm"
      :label-width="90"
      style="overflow:hidden"
      :rules="ruleValidate"
    >
      <Row>
        <Col span="12" class="visit-card">
          <FormItem
            prop="visitingCardUrl"
            label="名片"
            :class="[{ 'ivu-form-item-required': isOrgNameOrVisitCardRequired }]"
          >
            <Upload
              v-loading="imgLoading"
              element-loading-text="上传中，请稍候"
              :show-upload-list="false"
              :default-file-list="defaultFileList"
              ref="upload"
              accept="image/*"
              action="api/common/uploadFile"
              :on-error="onUploadError"
              :on-success="onUploadSuccess"
              :before-upload="beforeUpload"
              style="display: inline-block;width:362px;height:214px;border:1px dotted #ccc;"
              :data="{fileType:'visitingCard'}"
            >
              <!-- <Button type="ghost" icon="ios-cloud-upload-outline">上传名片</Button> -->
              <div class="upload-list-img" v-if="imgUrl">
                <img :src="imgUrl" :alt="formData.realName+'名片'" @click="onPreviewCard">
                <div class="upload-list-cover">
                  <div class="change-button" title="更换名片">
                    <Icon type="ios-cloud-upload"></Icon>
                  </div>
                  <div class="preview-button" @click="onPreviewCard" title="预览">
                    <Icon type="ios-eye-outline"></Icon>
                  </div>
                  <div class="delete-button" @click="onUploadsRemove" title="删除名片">
                    <Icon type="ios-trash-outline"></Icon>
                  </div>
                </div>
              </div>

              <div v-else class="upload-button-container" title="上传名片">
                <Icon type="camera" size="20"></Icon>
              </div>
            </Upload>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="realName" label="用户名">
            <Input v-model.trim="formData.realName" placeholder="请输入用户名"></Input>
          </FormItem>
        </Col>

        <Col span="12" class="company-col">
          <FormItem
            label="公司名称"
            prop="orgName"
            :class="[{ 'ivu-form-item-required': isOrgNameOrVisitCardRequired }]"
          >
            <Poptip
              placement="bottom-start"
              style="width:100%;"
              confirm
              @on-cancel="onCancelCompanyPick"
              @on-ok="getCompany"
            >
              <Input
                v-model="companyKeyword"
                placeholder="请输入关键字"
                style="width:438px"
                @input="getCompanyTree"
              ></Input>
              <div slot="title">
                <div v-if="companyTreeLoading">
                  <Spin fix>
                    <Icon type="load-c" size="18" class="demo-spin-icon-load"></Icon>
                    <div>加载中...</div>
                  </Spin>
                </div>

                <div v-else class="company-tree-container" style="padding-right:16px;">
                  <div v-if="!companyTreeList.length" style="text-align:center;">暂无数据</div>

                  <div v-else>
                    <el-tree
                      class="radio-tree"
                      :data="companyTreeList"
                      show-checkbox
                      node-key="id"
                      ref="targetTree"
                      :auto-expand-parent="true"
                      :check-strictly="true"
                      @check="targetCheckChange"
                      :expand-on-click-node="false"
                      check-on-click-node
                      :default-expanded-keys="targetExpandIdArr"
                      :props="defaultProps"
                    ></el-tree>
                  </div>
                </div>

                <!-- <div class="button-container">
                    <Button type="primary" size='small' @click="getCompany">确定</Button>
                </div>-->
              </div>
            </Poptip>
          </FormItem>
          <!-- <FormItem prop='companyName' label='公司名称'>
            <Input v-model.trim="formData.companyName" placeholder="请输入公司名称"></Input>
          </FormItem>-->
        </Col>

        <Col span="12" class="account-col">
          <FormItem prop="accountNo" label="账号">
            <Input v-model.trim="formData.accountNo" placeholder="请输入账号" disabled></Input>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="email" label="邮箱">
            <Input v-model.trim="formData.email" placeholder="请输入邮箱" disabled></Input>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="userSource" label="用户来源">
            <Select v-model="formData.userSource" placeholder="请选择用户来源" clearable transfer>
              <Option
                v-for="item in userSourceMapping"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="accountStatus" label="账号状态">
            <Select
              v-model="formData.accountStatus"
              :disabled="hasRelated"
              placeholder="请选择账号状态"
              clearable
              transfer
            >
              <Option
                v-for="item in accountStatusMapping"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="applySource" label="申请来源">
            <Select v-model="formData.applySource" placeholder="请选择申请来源" clearable transfer>
              <Option
                v-for="item in applySourceMapping"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>
        <Col span="12">
          <FormItem prop="isForeigner" label="是否海外用户">
            <Select v-model="formData.isForeigner" placeholder="请选择是否海外用户" clearable transfer>
              <Option
                v-for="item in isForeignerMapping"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="groupId" label="用户组">
            <Select
              v-model="formData.groupId"
              placeholder="请选择用户组"
              :disabled="formData.groupId == 1"
              clearable
              transfer
            >
              <Option
                v-for="item in groupIdMapping"
                :value="item.value"
                :key="item.value"
                :disabled="item.disabled"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="payingFlag" label="是否付费">
            <Select v-model="formData.payingFlag" placeholder="请选择是否付费" clearable transfer>
              <Option
                v-for="item in payingFlagMapping"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</Option>
            </Select>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="beginDate" label="开始日期">
            <DatePicker
              transfer
              disabled
              style="width:100%"
              v-model="formData.beginDate"
              placeholder="请选择开始日期"
            ></DatePicker>
          </FormItem>
        </Col>

        <Col span="12">
          <FormItem prop="endDate" label="结束日期" class="account-end-date">
            <DatePicker
              transfer
              style="width:100%"
              v-model="formData.endDate"
              :disabled="hasRelated"
              placeholder="请选择结束日期"
            ></DatePicker>
          </FormItem>
        </Col>

        <Col span="12">
          <Row>
            <Col span="12">
              <FormItem label="自定义logo">
                <div
                  class="cus-logo"
                  @click="showCustomizedLogoModal"
                  :title="cusLogoSrc?'更换logo':''"
                  :style="logoStyle"
                >
                  {{cusLogoSrc?"":"请选择logo"}}
                  <div
                    class="clear-logo-wrap"
                    @click.prevent.stop="clearLogo"
                    v-show="cusLogoSrc"
                    title="清除"
                  >×</div>
                </div>
              </FormItem>
            </Col>

            <Col span="12">
              <FormItem prop="isHide" label="隐藏数据">
                <Checkbox
                  :disabled="!hasRightToHideFund"
                  v-model="formData.isHide"
                  :true-value="1"
                  :false-value="0"
                >是(选中即隐藏基金数据)</Checkbox>
              </FormItem>
            </Col>
          </Row>
        </Col>
        <Col span="24">
          <FormItem
            prop="remark"
            label="备注"
            :class="[{ 'ivu-form-item-required': isRemarksRequired }]"
          >
            <Input
              v-model="formData.remark"
              :autosize="{minRows: 2,maxRows: 5}"
              :rows="3"
              type="textarea"
            ></Input>
          </FormItem>
        </Col>
      </Row>
    </Form>

    <customized-logo-modal
      ref="customizedLogoModal"
      @getBase64Pic="getBase64Pic"
      @getBlobPic="getBlobPic"
    />
  </Modal>
</template>

<script>
import $ from "jquery";
import moment from "moment";
import { mapGetters } from "vuex";
import uglifyPic from "@/mixins/condensePic";
import customizedLogoModal from "./customized-logo.vue";

export default {
  components: {
    customizedLogoModal
  },

  data() {
    return {
      hasRelated: false,
      logoStyle: {},
      cusLogoSrc: "",
      cusLogoBlob: "",
      imgLoading: false,
      btnLoading: false,
      initOrg: {},
      targetExpandIdArr: [],
      id: null,
      companyKeyword: "",
      companyTreeLoading: false,
      companyTreeList: [],
      lastTargetOrg: {},
      defaultProps: {
        children: "children",
        label: "title"
      },
      productId: "",
      accountStatusMapping: [
        {
          label: "异常",
          value: 0
        },
        {
          label: "申请",
          value: 1
        },
        {
          label: "试用",
          value: 2
        },
        {
          label: "正式",
          value: 3
        },
        {
          label: "停用",
          value: 4
        }
      ],

      userSourceMapping: [
        {
          label: "PC端",
          value: 1
        },
        {
          label: "移动端（扫码）",
          value: 2
        },
        {
          label: "banner申请",
          value: 3
        },
        {
          label: "批量导入",
          value: 4
        },
        {
          label: "CRM单条新增",
          value: 5
        }
      ],
      applySourceMapping: [
        {
          label: "主站",
          value: 1
        },
        {
          label: "扫码注册",
          value: 7
        },
        {
          label: "其他",
          value: 8
        }
      ],
      isForeignerMapping: [
        {
          label: "国内用户",
          value: 0
        },
        {
          label: "海外用户",
          value: 1
        }
      ],
      groupIdMapping: [
        {
          label: "组合大师管理员",
          value: 1,
          disabled: true
        },
        {
          label: "VIP会员",
          value: 2
        },
        {
          label: "普通用户",
          value: 3
        }
      ],
      payingFlagMapping: [
        {
          label: "已付费",
          value: 1
        },
        {
          label: "未付费",
          value: 0
        }
      ],
      timerId: null,
      defaultFileList: [],
      formData: {
        accountStatus: "",
        orgName: "",
        realName: "",
        email: "",
        accountNo: "",
        logo: "",
        visitingCardUrl: "",
        inviteCode: "",
        isHide: 0,
        userSource: "",
        applySource: "",
        isForeigner: "",
        groupId: "",
        payingFlag: "",
        beginDate: "",
        endDate: "",
        orgId: ""
      },
      initAccountStatus: "",
      loading: false,
      modal: false,
      accountId: "",
      account: "",
      imgUrl: "",
      isFirstChange: true,
      isOrgNameOrVisitCardRequired: false,
      isRemarksRequired: false
    };
  },

  mixins: [uglifyPic],

  computed: {
    ruleValidate() {
      const validateEndDate = (rules, value, callback) => {
        if (
          this.formData.accountStatus == "2" ||
          this.formData.accountStatus == "3"
        ) {
          if (!value) {
            callback(new Error("结束日期不能为空"));
          } else {
            callback();
          }
        } else {
          callback();
        }
      };

      const validateVisitCard = (rules, value, callback) => {
        if (this.isOrgNameOrVisitCardRequired) {
          if (!this.formData.visitingCardUrl) {
            callback(new Error("名片不能为空！"));
          } else {
            callback();
          }
        } else {
          callback();
        }
      };
      const validateCompany = (rules, value, callback) => {
        if (this.isOrgNameOrVisitCardRequired) {
          if (!this.companyKeyword) {
            callback(new Error("公司名称不能为空!"));
          } else {
            callback();
          }
        } else {
          callback();
        }
      };
      const validateRemarksCard = (rules, value, callback) => {
        let errors = [];
        if (this.isRemarksRequired) {
          if (!value) {
            errors.push(new Error("备注不能为空!"));
          }
        }
        callback(errors);
      };

      return {
        // realName: [{ required: true, message: "姓名不能为空" }],
        accountStatus: [{ required: true, message: "账号状态不能为空" }],
        endDate: [{ validator: validateEndDate }],
        inviteCode: [{ required: true, message: "邀请码不能为空" }],
        groupId: [{ required: true, message: "用户组不能为空" }],
        userSource: [{ required: true, message: "用户来源不能为空" }],
        applySource: [{ required: true, message: "申请来源不能为空" }],
        visitingCardUrl: [{ validator: validateVisitCard }],
        orgName: [{ validator: validateCompany }],
        remark: [{ validator: validateRemarksCard }]
      };
    },

    ...mapGetters({
      userName: "getUserName",
      userTrueName: "getTrueName",
      userInfo: "getUser"
    }),

    hasRightToHideFund() {
      return this.userInfo.auth.functional.includes("hideFund");
    }
  },

  watch: {
    "formData.accountStatus": {
      handler(val, oldval) {
        if (val && (val == 2 || val == 3)) {
          $(this.$el)
            .find(".account-end-date.ivu-form-item")
            .addClass("ivu-form-item-required");
        } else {
          $(this.$el)
            .find(".account-end-date.ivu-form-item")
            .removeClass("ivu-form-item-required");
        }
        if (this.isFirstChange && oldval) {
          this.isFirstChange = false;
        }
        if (this.formData.accountStatus != 4) {
          this.isOrgNameOrVisitCardRequired = true;
        } else {
          this.isOrgNameOrVisitCardRequired = false;
        }
        if (val != this.initAccountStatus) {
          this.isRemarksRequired = true;
        } else {
          this.isRemarksRequired = false;
        }
      },
      deep: true
    }
  },

  methods: {
    showCustomizedLogoModal() {
      this.$refs.customizedLogoModal.show();
    },

    clearLogo() {
      this.cusLogoSrc = "";
      this.logoStyle = {};
      this.cusLogoBlob = "";
      this.formData.logo = "";
    },

    getBase64Pic(pic) {
      this.cusLogoSrc = pic;
      let style = {
        "background-image": `url(${this.cusLogoSrc})`,
        " background-repeat": "no-repeat",
        "background-size": "100% 100%",
        "-moz-background-size": "100% 100%"
      };
      this.logoStyle = {
        ...style
      };
    },

    getBlobPic(pic) {
      this.cusLogoBlob = pic;
    },

    upLoadCusLogo() {
      let type = this.cusLogoBlob.type.split("/")[1];
      let formData = new FormData();
      formData.append("fileType", "customizedLogo");
      formData.append("file", this.cusLogoBlob, `${Date.now()}.${type}`);

      return new Promise((resolve, reject) => {
        this.$http.post("/common/uploadFile", formData).then(res => {
          if (res.code === 20000) {
            resolve(res.data.filePath);
          } else {
            this.$Message.error(`上传logo失败:${res.data.errorMsg}`);
            reject(false);
          }
        });
      });
    },

    // 获取机构树
    getCompanyTree() {
      this.companyTreeList = [];
      if (!this.companyKeyword) {
        return;
      }
      let companyKeyword = this.companyKeyword.trim().split(/[ ]+/);
      let params = {
        type: 4,
        keywords: companyKeyword
      };
      this.companyTreeLoading = true;
      clearTimeout(this.id);
      this.id = setTimeout(() => {
        this.$http.get("visit/gettreebytype", params).then(res => {
          this.companyTreeList = res.data;
          this.companyTreeLoading = false;
        });
      }, 800);
    },

    // 取消选择
    onCancelCompanyPick() {
      this.companyKeyword = this.initOrg.orgName;
      this.formData.orgName = this.initOrg.orgName;
      this.formData.orgId = this.initOrg.orgId;
      this.lastTargetOrg = {};
      this.companyTreeList = [];
    },

    //  获取机构
    getCompany() {
      this.companyKeyword = this.lastTargetOrg.title;
      this.formData.orgName = this.lastTargetOrg.title;
      this.formData.orgId = this.lastTargetOrg.id;
    },

    // 设定只能选一个
    targetCheckChange(data, nodeInfo) {
      if (nodeInfo.checkedKeys.length) {
        this.$refs.targetTree.setCheckedNodes([data]);
        this.lastTargetOrg = {
          id: data.id,
          title: data.title
        };
      } else {
        this.lastTargetOrg = {};
      }
      this.getCompany();
    },
    // 上传之前先清空,保证只能上传最后一条文件
    beforeUpload(file) {
      this.$refs.upload.clearFiles();
      this.imgLoading = true;
      this.uglifyPic(file, "editAccountForm", "formData", "visitingCardUrl");
      return false;
    },

    getImgUrl(path) {
      let url;
      let picUrl = path;
      if (path.includes("/Onstage/")) {
        url =
          process.env.NODE_ENV === "production" ||
          process.env.NODE_ENV === "test"
            ? "https://fof.simuwang.com/"
            : "https://master-test.simuwang.com/";
      } else {
        url =
          process.env.NODE_ENV === "production"
            ? " http://static.simuwang.com/"
            : "https://static-test-ali.simuwang.com/";
        picUrl = `Uploads/crm/${path}`;
      }
      this.imgUrl = `${url}${picUrl}`;
    },

    // 点击文件 预览
    onPreviewCard(e) {
      e.stopPropagation();
      e.preventDefault();
      window.open(`${this.imgUrl}`);
      return false;
    },

    // 上传成功的回调
    onUploadSuccess(response, file, fileList) {
      let res = response;
      this.imgLoading = false;
      if (res.code === 20000) {
        this.$Message.success("上传成功！");
        this.formData.visitingCardUrl = res.data.filePath;
        this.$refs.editAccountForm.validateField("visitingCardUrl");
        this.getImgUrl(res.data.filePath);
      } else {
        this.$Message.error(`上传失败：${res.msg}`);
      }
    },

    // 上传失败的回调
    onUploadError(error, file, fileList) {
      this.imgLoading = false;
      this.$Message.error("上传失败！");
    },

    //  移除上传附件
    onUploadsRemove(e) {
      e.stopPropagation();
      e.preventDefault();
      this.formData.visitingCardUrl = "";
      this.$refs.upload.clearFiles();
      this.imgUrl = "";
      this.$refs.editAccountForm.validateField("visitingCardUrl");
      return false;
    },

    //   取消操作
    onCancel() {
      this.modal = false;
      this.reset();
    },

    // 重置数据
    reset() {
      this.formData = {
        accountStatus: "",
        realName: "",
        email: "",
        isHide: 0,
        logo: "",
        accountNo: "",
        visitingCardUrl: "",
        inviteCode: "",
        userSource: "",
        isForeigner: "",
        groupId: "",
        payingFlag: "",
        beginDate: "",
        endDate: "",
        orgId: ""
      };
      this.companyKeyword = "";
      this.companyTreeList = [];
      this.productId = "";
      this.defaultFileList = [];
      this.$refs.upload && this.$refs.upload.clearFiles();
      this.accountId = "";
      this.account = "";
      this.lastTargetOrg = {};
      this.imgUrl = "";
      this.initOrg = {};
      this.initAccountStatus = "";
      this.hasRelated = false;

      this.$refs.editAccountForm && this.$refs.editAccountForm.resetFields();
      this.isFirstChange = true;
      this.isOrgNameOrVisitCardRequired = false;
      this.logoStyle = {};
      this.cusLogoSrc = "";
      this.cusLogoBlob = "";
    },

    // 获取详情
    getAccountDetails() {
      let params = {
        accountNo: this.account,
        productId: this.productId
      };
      this.loading = true;
      this.$http.get("/accounts/getAccount", params).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          if (!res.data.productId) {
            res.data.productId = null;
          }
          this.formData = res.data;
          this.formData.remark = "";
          this.companyKeyword = this.formData.orgName;
          if (!this.formData.groupId) {
            this.formData.groupId = "";
          }
          if (this.formData.visitingCardUrl) {
            this.getImgUrl(this.formData.visitingCardUrl);
          } else {
            this.imgUrl = "";
          }
          if (this.formData.logo) {
            let url =
              process.env.NODE_ENV === "production"
                ? " http://static.simuwang.com/"
                : "https://static-test-ali.simuwang.com/";
            let picUrl = `Uploads/crm/${this.formData.logo}`;
            this.cusLogoSrc = `${url}${picUrl}`;
            this.getBase64Pic(this.cusLogoSrc);
          }
          this.initOrg.orgName = this.formData.orgName;
          this.initOrg.orgId = this.formData.orgId;
          this.initAccountStatus = this.formData.accountStatus;

          //控制开始日期和结束日期为空的情况
          if (res.data.beginDate.indexOf("00-00-00") != -1) {
            this.formData.beginDate = moment(new Date()).format("YYYY-MM-DD");
          }
          if (res.data.endDate.indexOf("00-00-00") != -1) {
            this.formData.endDate = moment(new Date(this.formData.beginDate))
              .add(1, "months")
              .format("YYYY-MM-DD");
          }
        } else {
          this.$Message.error("获取数据失败！");
        }
      });
    },

    // 确定提交
    onOk() {
      this.submitFormData();
    },

    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },

    //    提交数据
    submitFormData() {
      this.$refs.editAccountForm.validate(async valid => {
        if (valid) {
          this.btnLoading = true;
          let data = JSON.parse(JSON.stringify(this.formData));
          let logo;
          let flag = false;
          if (this.cusLogoSrc && !this.cusLogoSrc.includes("http")) {
            try {
              logo = await this.upLoadCusLogo();
            } catch (err) {
              flag = !err;
            }
          }

          if (flag) {
            this.btnLoading = false;
            return;
          }

          data.logo = logo || "";

          if (data.remark) {
            data.remark = `处理者${this.userTrueName},手机号${
              data.accountNo
            },原因${data.remark}`;
          }
          if (data.beginDate) {
            data.beginDate = this.setTimeZone(data.beginDate);
          }
          if (data.endDate) {
            data.endDate = this.setTimeZone(data.endDate);
          }

          if (!this.companyKeyword) {
            data.orgName = "";
          }

          if (!data.orgName) {
            data.orgId = "";
          }

          let params = Object.assign(
            {
              id: this.accountId,
              productId: 1
            },
            data
          );
          this.$http
            .putWithoutId(`accounts/updateAccount`, params)
            .then(res => {
              this.btnLoading = false;
              if (res.code === 20000) {
                this.$Message.success("修改成功！");
                this.$emit("refreshTable", true);
                this.onCancel();
              } else {
                this.$Message.error("修改失败！");
              }
            });
        } else {
          let that = this;
          setTimeout(() => {
            $(that.$el)
              .find(".account-end-date.ivu-form-item")
              .addClass("ivu-form-item-required");
            $(this.$el)
              .find(".account-visiting-cardUrl.ivu-form-item")
              .addClass("ivu-form-item-required");
            $(this.$el)
              .find(".account-org-name.ivu-form-item")
              .addClass("ivu-form-item-required");
          }, 0);
          this.$Message.error("请按红色字段填写数据！");
        }
      });
    },

    // 显示
    show(id, account, productId, hasRelated) {
      this.hasRelated = !!hasRelated;
      this.productId = productId;
      this.account = account;
      this.accountId = id;
      this.modal = true;
      this.isFirstChange = true;
      this.isOrgNameOrVisitCardRequired = false;
      this.getAccountDetails();
    }
  }
};
</script>

<style lang="less" scoped>
.upload-list-img {
  cursor: pointer;
  vertical-align: top;
  display: inline-block;
  width: 360px;
  height: 212px;
  text-align: center;
  line-height: 212px;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  margin-right: 4px;
  img {
    width: 100%;
    height: 100%;
  }
}

.upload-button-container {
  width: 360px;
  height: 212px;
  line-height: 212px;
  text-align: center;
  overflow: hidden;
}

.upload-list-cover {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  position: absolute;
  height: 60px;
  bottom: -60px;
  left: 0;
  right: 0;
  line-height: 60px;
  background: rgba(0, 0, 0, 0.6);
  transition: all 0.5s ease;
  div {
    flex: 1;
  }
}

.upload-list-img:hover .upload-list-cover {
  // display: block;
  bottom: 0;
}

.upload-list-cover i {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 5px;
}

.company-col {
  // position: absolute !important;
  // top: 50px;
}

.account-col {
  // position: absolute !important;
  // top: 100px;
}

// .visit-card {
//   height: 230px !important;
//   width: 464px !important;
// }

.cus-logo {
  position: relative;
  width: 167px;
  height: 48px;
  line-height: 35px;
  border: 1px solid #dddee1;
  border-radius: 4px;
  .clear-logo-wrap {
    position: absolute;
    width: 20px;
    height: 20px;
    line-height: 20px;
    text-align: center;
    color: #fff;
    border-radius: 50%;
    top: -10px;
    right: -1000000000000px;
    background: rgba(0, 0, 0, 0.6);
  }
  &:hover {
    border-color: #57a3f3;
    .clear-logo-wrap {
      right: -10px;
    }
  }
  cursor: pointer;
}
</style>