<template>
  <Poptip
    placement="top-end"
    trigger="click"
    transfer
    width="520"
    @on-popper-show="onPopperShow"
    @on-popper-hide="onPopperHide"
  >
    <span class="managerName-wrap" title="查看分配日志">{{row.managerName||"--"}}</span>

    <span slot="title" class="title-wrap">分配日志</span>

    <div slot="content">
      <Table
        height="120"
        :columns="columns"
        :data="tableData"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        border
        :key="tableKey"
      ></Table>
    </div>
  </Poptip>
</template>


<script>
export default {
  props: {
    row: {
      type: [Array, Object],
      default: () => ({})
    }
  },
  name: "managerPoptip",

  data() {
    return {
      columns: [
        {
          title: "开始时间",
          key: "beginAt",
          width: 120,
          render(createElement, params) {
            return createElement(
              "span",
              params.row.beginAt ? params.row.beginAt.slice(0, 11) : "--"
            );
          }
        },
        {
          title: "结束时间",
          key: "endAt",
          width: 120,
          render(createElement, params) {
            return createElement(
              "span",
              params.row.endAt ? params.row.endAt.slice(0, 11) : "--"
            );
          }
        },
        {
          title: "原责任人",
          key: "oldManager",
          width: 80,
          render(createElement, params) {
            return createElement("span", params.row.oldManager || "--");
          }
        },
        {
          title: "新责任人",
          key: "newManager",
          width: 80,
          render(createElement, params) {
            return createElement("span", params.row.newManager || "--");
          }
        },
        {
          title: "操作人",
          key: "updaterName",
          width: 80
        }
      ],
      tableData: [],
      tableKey: null,
      tableLoading: false
    };
  },

  methods: {
    onPopperShow() {
      this.tableLoading = true;
      try {
        this.$http
          .get("accounts/getManagerChangeLog", {
            accIds: [this.row.id]
          })
          .then(res => {
            this.tableLoading = false;
            if (res.code === 20000) {
              this.tableData = res.data;
              this.tableKey = Date.now();
            } else {
              this.$Message.error(`获取日志失败：${res.msg}`);
            }
          });
      } catch (e) {
        this.tableLoading = false;
        this.$Message.error(`获取日志失败`);
      }
    },
    onPopperHide() {
      this.tableData = [];
    }
  }
};
</script>

<style lang="less" scoped>
.managerName-wrap {
  color: #0c7beb;
  cursor: pointer;
  display: inline-block;
  width: 60px;
  height: 20px;
}
.title-wrap {
  font-size: 14px;
  font-weight: 900;
}
</style>
