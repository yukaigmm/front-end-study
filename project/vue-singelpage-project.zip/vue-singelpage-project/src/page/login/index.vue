<template>
  <div class="webkit-login-page moz-login-page">
    <Card class="login-wrap" @keyup.enter.native="submit">
      <div class="logo-area">
        <img src="../../assets/logo.png" alt class="smppw-logo">
        <img src="../../assets/logo_index_crm.png" class="crm-logo" alt>
      </div>

      <div class="login-form">
        <Form :model="userData" :rules="validateRules" ref="form" :label-width="60">
          <form-item
            v-for="item in userConfig"
            :key="item.prop"
            :prop="item.prop"
            :label="item.label"
          >
            <input
              class="ivu-input"
              v-model="userData[item.prop]"
              :type="item.type"
              autocomplete="off"
              :placeholder="item.placeholder"
            >
          </form-item>

          <form-item>
            <Checkbox v-model="userData.rember">
              <span>记住账号</span>
            </Checkbox>
          </form-item>
          <form-item>
            <i-button
              type="success"
              :disabled="isLogin"
              class="submit-button"
              @click="submit"
              :loading="isLogin"
            >{{btnTxt}}</i-button>
          </form-item>
        </Form>
      </div>
    </Card>
  </div>
</template>

<script>
export default {
  data() {
    return {
      userData: {
        rember: true,
        code: "8888"
      },
      validateRules: {
        user_name: {
          required: true,
          message: "用户名不能为空"
        },
        password: {
          required: true,
          message: "密码不能为空"
        }
      },
      userConfig: [
        {
          prop: "user_name",
          label: "用户名",
          type: "text",
          placeholder: "请输入用户名"
        },
        {
          prop: "password",
          label: "密码",
          type: "password",
          placeholder: "请输入密码"
        }
      ],
      isLogin: false
    };
  },

  computed: {
    btnTxt() {
      return this.isLogin ? "登陆中..." : "登陆";
    }
  },

  methods: {
    submit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.loginIn();
        } else {
          this.$Message.error("请按红色文字提示填写内容！");
        }
      });
    },

    loginIn() {
      this.isLogin = true;
      this.$http
        .post("login/crmLogin", this.userData)
        .then(res => {
          if (res.code === 20000) {
            this.$router.push("/index");
            this.$store.dispatch("setUser", res.data);
            this.$Message.success("登陆成功！");
          } else {
            this.$Message.error(`登陆失败：${res.msg}`);
          }
          this.isLogin = false;
        })
        .catch(err => {
          console.error(err);
          this.$Message.error(`登陆失败：网络请求错误！`);
          this.isLogin = false;
        });
    },

    // getCurrentUserInfo() {
    //   this.$http
    //     .get("common/getLoginStatus")
    //     .then(res => {
    //       if (res.code === 20000) {
    //         this.$router.push("/index");
    //         this.$store.dispatch("setUser", res.data);
    //         this.$Message.success("登陆成功！");
    //       } else {
    //         this.$Message.error(`登陆失败：${res.msg}`);
    //       }
    //       this.isLogin = false;
    //     })
    //     .catch(err => {
    //       console.log(err);
    //       this.$Message.error(`登陆失败：网络请求错误！`);
    //       this.isLogin = false;
    //     });
    // }
  }
};
</script>

<style lang="less" scoped>
@import "./css/index.less";
</style>
