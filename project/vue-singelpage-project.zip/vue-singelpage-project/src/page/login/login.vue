<template>
    <div class="login-form login-form-webkit login-form-moz">

      <Card class="box-card" @keyup.enter.native="onSubmit">
        <!-- <div v-if="!ifBinded" class="binding-warning">
            <Icon type="information-circled" style="color:#ff9900"></Icon>
            <p style='text-align:left;color:#495060;'>您已经通过微信扫码成功登陆！<br/>
                 首次微信扫码登录，需要账号密码确认身份。 <br/>
                 身份确认仅需一次，谢谢配合！</p>
        </div> -->
        <template>
          <Form ref="form" :model="form" :label-width="60">

            <Form-item
              v-for="item in formItems"
              :prop="item.prop"
              :label="item.label"
              :key="item.prop"

              :rules="{
                required: true, message: item.label + '不能为空', trigger: 'blur, change'
              }"
            >
              <Input
                :type=" item.prop === 'password' ? 'password' : 'text' "
                v-model="form[item.prop]"
              />
            </Form-item>
            <Form-item >
              <Checkbox v-model="form.rember" >
                <span >记住账号</span>
              </Checkbox>
            </Form-item>
            <!-- <Form-item class="change-img">
              <img class="img" v-if="!!src" :src="src" @click="changeImg"  alt="验证码">
            </Form-item> -->

            <Form-item>
              <Button type="success" class="submit-button" @click="onSubmit">登录</Button>
              <!-- <Button type="success" class="submit-button" @click="loginByWX">微信登录</Button> -->
            </Form-item>

          </Form>
          <!-- <div v-if="ifBinded"> 
            <p style="text-align:center;">其他登录方式</p>
            <ul class="another-login-methods" style="text-align:center;">
              <li title="微信扫码登录" >
                <a :href='loginUrl+"/user/wechat?id=1"'>
                  <img src="../../assets/wechatlogo.png" alt="微信登录">
                </a>
              </li>
              <li title="钉钉登录" v-if="false">
                <a :href='loginUrl+"/user/ding?id=1"'>
                  <img src="../../assets/dingdinglogo.png" alt="钉钉登录">
                </a>
              </li>
            </ul>
          </div> -->
        </template>
      </Card>
    </div>
</template>

<script>
import { fetchCodeImage, fetchLogin, fetchUser } from "@/service/getData";
// import axios from "axios";
import { mapGetters } from "vuex";
import { isEmpty } from "lodash";
import $ from "jquery";
export default {
  name: "login",
  mounted() {
    // this.form.user_name = this.user.userName;
    // this.changeImg();
  },
  computed: {
    ...mapGetters({
      user: "getUser"
      // ifBinded: "getIfBinded"
    })

    // loginUrl() {
    //   // return "http://login.smppw.com";
    //   if (window.location.origin != "http://crm.smppw.com") {
    //     return "http://uc-test.smppw.com";
    //   } else {
    //     return "http://login.smppw.com";
    //   }
    // }
  },

  watch: {
    $route: {
      handler(val) {
        if (val && val.fullPath === "/login") {
          // 登出之后，清除除了首页之外的tab
          this.$store.dispatch("setTabsAll", [
            {
              isShow: true,
              name: "首页0",
              activeName: "首页",
              component: "index",
              closable: false
            }
          ]);
          this.$store.dispatch("setActiveTab", { activeTab: "首页0" });
        }
      },

      immediate: true
    }
  },
  data() {
    return {
      src: "",
      form: {
        user_name: "",
        password: "",
        code: "8888",
        rember: true
      },
      openid: "",
      formItems: [
        {
          prop: "user_name",
          label: "用户名"
        },
        {
          prop: "password",
          label: "密码"
        }
        // {
        //   prop: "code",
        //   label: "验证码"
        // }
      ]
    };
  },
  methods: {
    // 切换验证码
    // changeImg() {
    //   let me = this;
    //   this.src = false;
    //   fetchCodeImage().then(resp => {
    //     let src =
    //       process.env.NODE_ENV === "production"
    //         ? resp.data.src
    //         : "api" + resp.data.src;
    //     // let src = resp.data.src;
    //     src += "?_t=" + new Date().getTime();
    //     me.src = src;
    //   });
    // },

    // 获取url中的参数
    // getQueryParams() {
    //   let windowParams = JSON.parse(JSON.stringify(window.location));
    //   let queryString = windowParams.search.slice(1);
    //   let queryStringArr = queryString.split("&");
    //   let params = {};
    //   queryStringArr
    //     .filter(item => {
    //       return item.indexOf("=") !== -1;
    //     })
    //     .forEach(item => {
    //       let [key, value] = item.split("=");
    //       params[key] = value;
    //     });
    //   return params;
    // },

    // 提交表单
    onSubmit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.$Message.loading({
            content:"登陆中...",
            duration:0
          });
          fetchLogin(this.form)
            .then(resp => {
              if (resp.code === 20000) {
                return {
                  flag: true
                };
              } else {
                return {
                  flag: false,
                  msg: resp.msg
                };
              }
            })
            .then(data => {
              if (data.flag) {
                fetchUser().then(resp => {
                  // 登录成功之后绑定微信
                  // let urlParams = this.getQueryParams();
                  // if (!isEmpty(urlParams)) {
                  //   let bindParams = {
                  //     username: this.form.user_name,
                  //     password: this.form.password
                  //   };
                  //   let params = Object.assign(bindParams, urlParams);
                  //   $.post("api/login/binding", params, data => {
                  //     this.$Message.info("绑定成功！");
                  //   });
                  // }

                  this.$store.dispatch("setUser", resp.data);
                  this.$router.push({ path: "/index" });
                  this.$Message.destroy();
                  this.$Message.success("登陆成功！");
                });
              } else {
                this.$router.push({ path: "/login" });
                this.$Message.destroy();
                this.$Message.error(`登陆失败：${data.msg}`);
              }
            });
        }
      });
    }
    // getUrlParams() {
    //   return new Promise((resolve, reject) => {
    //     let urlParams = {};
    //     let pairs = window.location.search.substring(1).split("&");
    //     for (let i = 0; i < pairs.length; i++) {
    //       let pos = pairs[i].indexOf("=");
    //       if (pos === -1) {
    //         continue;
    //       }
    //       let [key, value] = pairs[i].split("=");
    //       urlParams[key] = value;
    //     }
    //     resolve(urlParams);
    //   });
    // }
  }
};
</script>

<style scoped lang="less">
.box-card {
  width: 400px;
  position: relative;
  left: 50%;
  top: 100px;
  transform: translateX(-50%);
  padding: 20px;
  padding-right: 40px;
  padding-top: 15px;
}
.binding-warning {
  margin-bottom: 10px;
  position: relative;
  height: 75px;
  i {
    position: absolute;
    top: 0;
    left: 0;
  }
  p {
    position: absolute;
    top: 0;
    left: 25px;
  }
}

.login-form {
  width: 100%;
  position: fixed;
  height: 100%;
}
.login-form-webkit {
  background: -webkit-linear-gradient(top, #ccc, #333);
}
.login-form-moz {
  background: -moz-linear-gradient(top, #ccc, #333);
}
.submit-button {
  position: relative;
  top: -10px;
  width: 100%;
}
.change-img {
  height: 70px;
  .img {
    width: 70%;
    position: relative;
    float: left;
  }
}
.another-login-methods {
  &:after {
    content: ".";
    display: block;
    height: 0;
    clear: both;
    visibility: hidden;
  }
  li {
    // float: left;
    margin-right: 10px;
    img {
      width: 30px;
      height: 30px;
      border-radius: 50%;
    }
  }
}
</style>