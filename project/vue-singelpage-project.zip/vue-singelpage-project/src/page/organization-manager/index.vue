<template>
  <common-index-page
    ref="commonIndexPage"
    :search-config="searchConfig"
    :table-data="tableData"
    :table-config="tableConfig"
    :current-page="currentPage"
    :total="total"
    :page-size="pageSize"
    :table-loading="tableLoading"
    @search="search"
    @changeSearchParam="showExpandParams"
    @onPageChange="onPageChange"
    @onPageSizeChange="onPageSizeChange"
  >
    <Row slot="search-default">
      <i-col span="8">
        <form-item label="关键字">
          <i-input v-model.trim="searchData.keywords" placeholder="请输入关键字,如：总部 分部"/>
        </form-item>
      </i-col>

      <i-col span="8" :offset="1">
        <form-item label="更新人">
          <Row>
            <i-col span="12">
              <i-select
                v-model="searchData.dept_id"
                placeholder="请选择部门"
                transfer
                clearable
                @on-change="onDeptChange"
              >
                <i-option
                  v-for="item in deptList"
                  :key="item.value"
                  :value="item.value"
                >{{item.label}}</i-option>
              </i-select>
            </i-col>
            <i-col span="11" :offset="1">
              <i-select
                v-model="searchData.update_member_id"
                :disabled="!searchData.dept_id"
                :loading="workmateLoading"
                transfer
                clearable
              >
                <i-option
                  v-for="item in workmateList"
                  :key="item.value"
                  :value="item.value"
                >{{item.label}}</i-option>
              </i-select>
            </i-col>
          </Row>
        </form-item>
      </i-col>

      <i-col span="7" style="padding-left:15px;">
        <i-button type="primary" @click="search">搜索</i-button>
        <i-button @click="reset">重置</i-button>
      </i-col>
    </Row>

    <Row slot="search-expand">
      <i-col span="8">
        <select-link ref="link" :selectData="areaList" @onChange="getAreaInfo"></select-link>
      </i-col>

      <i-col span="8" :offset="1">
        <form-item label="更新时间">
          <date-picker
            v-model="searchData.update_time"
            style="width:100%;"
            type="daterange"
            format="yyyy-MM-dd"
            placeholder="请选择更新时间"
            transfer
          />
        </form-item>
      </i-col>

      <i-col span="8">
        <form-item label="机构类型">
          <Row>
            <i-col span="12">
              <i-select v-model="searchData.oc_id" clearable transfer>
                <i-option
                  v-for="item in orgType"
                  :key="item.value"
                  :value="item.value"
                >{{item.name}}</i-option>
              </i-select>
            </i-col>

            <i-col span="11" :offset="1">
              <i-select v-model="searchData.depart_id" placeholder="请选择机构类别" clearable transfer>
                <i-option
                  v-for="item in departType"
                  :key="item.value"
                  :value="item.value"
                >{{item.name}}</i-option>
              </i-select>
            </i-col>
          </Row>
        </form-item>
      </i-col>

      <i-col span="8" :offset="1">
        <form-item label="画像">
          <i-select v-model="searchData.portrait" transfer clearable placeholder="请选择画像" multiple>
            <i-option
              class="portrait-selector"
              v-for="item in portraitList"
              :key="item.value"
              :value="item.value"
            >
              <Tag :style="item.style">{{item.name}}</Tag>
            </i-option>
          </i-select>
        </form-item>
      </i-col>
    </Row>

    <div slot="action-area">
      <i-button type="primary" @click="addNewOrg" title="添加新机构">添加</i-button>
      <i-button type="primary" @click="exportData" :disabled="ifExportDisabled" title="导出数据">导出</i-button>
    </div>

    <modal-add
      :port="portraitList"
      :modal="showAddModal"
      :formValidate="addModalFormValidate"
      @submit="submitAddData"
      @close="closeAddModal"
    />
    <modal-change-org-msg ref="modalChange" @closeModal="search"/>
  </common-index-page>
</template>

<script>
import CommonIndexPage from "../../components/common-index-page.vue";
import ModalAdd from "./modal-addOrg.vue";
import SelectLink from "./select-link.vue";
import ModalChangeOrgMsg from "./modal-changOrgMsg";
import { getTableConfig } from "./config.js";
import $ from "jquery";
import { mapGetters } from "vuex";
import moment from "moment";

export default {
  components: {
    CommonIndexPage,
    SelectLink,
    ModalAdd,
    ModalChangeOrgMsg
  },

  computed: {
    ...mapGetters({
      tabs: "getTabs",
      emnus: "getEnums",
      userInfo: "getUser"
    }),

    canDelete() {
      return this.userInfo.auth.functional.includes("deleteOrg");
    },

    areaList() {
      return this.emnus.c_area_all;
    },

    cityList() {
      return this.emnus.c_area_deep_2;
    },

    userId() {
      return this.userInfo.id;
    },

    orgType() {
      return this.emnus.c_org;
    },

    departType() {
      return this.emnus.c_depart;
    },

    portraitList() {
      return this.emnus.c_port_all_org;
    },

    customerTypeList() {
      return this.emnus.c_port_all_cust;
    },

    canDelete() {
      return this.userInfo.auth.functional.includes("deleteOrg");
    }
  },

  watch: {
    "searchData.portrait": {
      handler(val) {
        setTimeout(() => {
          let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");

          let selectTag = $(this.$el).find(
            ".ivu-select-selection .ivu-tag span"
          );
          let tag = $.find(".portrait-selector span");
          let tagContianer = $.find(".portrait-selector  .ivu-tag");
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText ==
                $($(tag).get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $($(tagContianer).get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    }
  },

  created() {
    this.getDeparment();
    this.getTableData();
  },

  mounted() {
    this.$refs.commonIndexPage.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".page-load"],
      ".table-area",
      150,
      false
    );
  },

  data() {
    return {
      searchConfig: {
        showExpand: true,
        showSearch: true
      },

      tableData: [],

      tableConfig: getTableConfig.apply(this),

      tableLoading: false,

      currentPage: 1,

      total: 0,

      pageSize: 10,

      searchData: {
        keywords: "",
        portrait: [],
        area_ids: "",
        oc_id: "",
        depart_id: "",
        update_time: [],
        update_member_id: "",
        dept_id: ""
      },

      deptList: [],

      workmateList: [],

      workmateLoading: false,

      ifShowExpand: false,

      showAddModal: false,

      addModalFormValidate: {
        name: "",
        type: "",
        phone: "",
        site: "",
        tag: [],
        address: "",
        note: "",
        cust_type_ids: [],
        area: "",
        register_num: ""
      },

      ifExportDisabled: false
    };
  },

  methods: {
    search() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getTableData();
    },

    reset() {
      this.searchData = {
        keywords: "",
        portrait: [],
        area_ids: "",
        oc_id: "",
        depart_id: "",
        update_time: [],
        update_member_id: "",
        dept_id: ""
      };
      this.search();
    },

    showExpandParams(ifShowExpand) {
      this.$nextTick(() => {
        this.$refs.commonIndexPage.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".search-area", ".page-load"],
          ".table-area",
          150,
          false
        );
      });

      this.ifShowExpand = ifShowExpand;
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getTableData();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getTableData();
    },

    exportData() {
      if (this.total <= 0) {
        this.$Message.warning("无可导出数据");
        return;
      }
      this.ifExportDisabled = true;
      this.$Message.loading({
        content: "正在导出中，请稍候...",
        duration: 0
      });

      let params = this.getParams();

      params.rows = this.total > 1000 ? 1000 : this.total;

      this.$http
        .get("index/orgexport", params)
        .then(res => {
          this.ifExportDisabled = false;
          this.$Message.destroy();
          if (res.code === 20000) {
            let url = res.data.url;
            let el = document.createElement("a");
            el.href = url;
            el.target = "_blank";
            document.body.appendChild(el);
            el.click();
            document.body.removeChild(el);
          } else {
            this.$Message.error(`导出失败：${res.msg}`);
          }
        })
        .catch(err => {
          this.$Message.error(`导出失败!`);
          this.ifExportDisabled = false;
          this.$Message.destroy();
        });
    },

    getParams() {
      let params = {};
      let data = JSON.parse(JSON.stringify(this.searchData));
      if (this.ifShowExpand) {
        params = {
          ...data
        };

        params.org_name = data.keywords
          ? data.keywords.trim().split(/[ ]+/)
          : "";
        delete params.keywords;
      } else {
        params = {
          org_name: data.keywords ? data.keywords.trim().split(/[ ]+/) : "",
          dept_id: data.dept_id,
          update_member_id: data.update_member_id
        };
      }

      //   去除空键
      for (let key in params) {
        if (!params[key]) {
          delete params[key];
        }

        if (Array.isArray(params[key])) {
          if (!params[key].length) {
            delete params[key];
          }
        }
      }

      //   处理日期
      if (params.update_time && !params.update_time[0]) {
        delete params.update_time;
      }

      if (params.update_time && params.update_time[0]) {
        params.update_time[0] = moment(params.update_time[0]).format(
          "YYYY-MM-DD"
        );
        params.update_time[1] = moment(params.update_time[1]).format(
          "YYYY-MM-DD"
        );
      }

      return Object.assign(
        {
          rows: this.pageSize,
          page: this.currentPage,
          sortKey: "update_time",
          sortOrder: "desc",
          ifCancelRequest: true
        },
        params
      );
    },

    getTableData() {
      let params = this.getParams();
      this.tableLoading = true;
      this.$http
        .get("index/organization", params)
        .then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.data;
            this.total = res.data.total;
          } else {
            this.total = 0;
            this.$Message.error(`获取表格数据失败:${res.msg}`);
          }
        })
        .catch(err => {
          if (err !== "canceled") {
            this.tableLoading = false;
            this.$Message.error("获取表格数据失败:网络请求错误！");
          }
        });
    },

    getDeparment() {
      this.$http.get("dept/getAllSelect").then(res => {
        if (res.code === 20000) {
          this.deptList = res.data;
        } else {
          this.$Message.error(`获取部门失败：${res.msg}`);
        }
      });
    },

    onDeptChange(deptId) {
      this.workmateList = [];

      if (!deptId) {
        return;
      }

      let params = {
        dept_id: deptId,
        type: 1
      };
      this.workmateLoading = true;

      this.$http.get("dept/getUserByDept", params).then(res => {
        this.workmateLoading = false;
        if (res.code === 20000) {
          this.workmateList = res.data;
        } else {
          this.$Message.error(`获取更新人列表失败:${res.msg}`);
        }
      });
    },

    addNewOrg() {
      this.showAddModal = true;
      this.addModalFormValidate = {
        name: "",
        type: "",
        phone: "",
        site: "",
        tag: [],
        address: "",
        note: "",
        area: "",
        cust_type_ids: [],
        register_num: ""
      };
    },

    submitAddData(data) {
      this.showAddModal = false;
      this.$http.post("index/organization", data).then(res => {
        if (res.code === 20000) {
          this.$Message.info("添加成功");
          this.search();
        } else {
          this.$Message.warning(res.msg);
        }
      });
    },

    closeAddModal() {
      this.showAddModal = false;
    },

    deleteOrg(id) {
      this.$Modal.confirm({
        title: "删除",
        content: "确定删除？",
        width: 300,
        loading: true,
        onOk: () => {
          this.$http.del("index/organization/", id).then(res => {
            if (res.code === 20000) {
              this.$Message.info("删除成功");
              // 如果删除的机构，已经在tab，中重新更新tab去掉删除的tab
              let tabsArr = this.tabs.filter(item => {
                return item.pid != id;
              });
              this.$store.dispatch("setTabsAll", tabsArr);
              this.search();
            } else {
              this.$Message.warning(`${res.msg}`);
            }
            this.$Modal.remove();
          });
        }
      });
    },

    getAreaInfo(val) {
      this.searchData.area_ids = val;
    }
  }
};
</script>

<style lang="less" scoped>
</style>


