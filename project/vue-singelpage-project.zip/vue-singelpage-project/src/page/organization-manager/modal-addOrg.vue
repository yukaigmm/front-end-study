<template>
    <div>
        <Modal v-model="selfModal" :loading="loading" :mask-closable="false" title="添加" @on-ok="ok" @on-cancel="cancel" width=700 ok-text="提交">

            <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80" class="org-adding-form">
                <Row :gutter="10">
                    <Col span="12" style="padding-right:11px;">
                        <FormItem label="机构名称" prop="name">
                            <Input v-model.trim="formValidate.name" placeholder="请输入"></Input>
                        </FormItem>
                    </Col>

                <Col span="12"  style="padding-right:11px;">
                    <FormItem label="机构类型" prop="type">
                        <Select v-model="formValidate.type" placeholder="请选择">
                            <Option v-for="(item,index) in orgType" :key="index" :value="item.value">{{item.name}}</Option>
                        </Select>
                    </FormItem>
                </Col>
                </Row>
             <Row :gutter="10">
                 <Col span="12"  style="padding-right:11px;">
                <FormItem label="机构电话" prop="phone">
                    <Input v-model.trim="formValidate.phone"  placeholder="请输入"></Input>
                </FormItem>
                </Col>

                <Col span="12"  style="padding-right:11px;">
                <FormItem label="机构网址" prop="site">
                    <Input v-model.trim="formValidate.site" placeholder="请输入"></Input>
                </FormItem>
                </Col>
                </Row>

                <FormItem label="画像" prop="tag"  style="padding-right:8px;">
                    <Select v-model="formValidate.tag" multiple placeholder="请选择">
                        <Option v-for="item in port" :value="item.value" :key="item.value"><Tag :style="item.style">{{item.name}}</Tag></Option>
                    </Select>
                </FormItem>

                <FormItem label="客户类型" prop="cust_type_ids"  style="padding-right:8px;">
                    <Select v-model="cust_type_ids" multiple placeholder="请选择">
                        <Option v-for="item in customerType" :value="item.value" :key="item.value"><Tag :style="item.style">{{item.name}}</Tag></Option>
                    </Select>
                </FormItem>

                <select-link :selectData="selectData"  @onChange="getSelInfo" ref="link"></select-link>

                <FormItem label="详细街道" prop="address"  style="padding-right:8px;">
                    <Input v-model.trim="formValidate.address" placeholder="请输入"></Input>
                </FormItem>
                 <FormItem label="备案编码" prop="register_num"  style="padding-right:8px;">
                    <Input v-model.trim="formValidate.register_num" placeholder="请输入"></Input>
                </FormItem>
            </Form>
        </Modal>
    </div>
</template>


<script>
import selectLink from "./select-link.vue";
import $ from "jquery";
// import { fetchAllPullList } from "@/service/getData";
import { mapGetters } from "vuex";
export default {
  data() {
    return {
      customerType: [],
      cust_type_ids: [],
      selectData: [],
      selfModal: false,
      loading: true,
      ruleValidate: {
        name: [
          { required: true, message: "请输入机构名称", trigger: "change" }
        ],
        type: [
          { required: true, message: "请选择机构类型", trigger: "change" }
        ],
        // area: [{ required: true, message: "请选择城市", trigger: "blur,change" }],
        phone: [
          {
            pattern: /(^1(3|4|5|6|7|8|9)\d{9}$)|(^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$)/,
            message: "请输入正确电话 如:400-6802928",
            trigger: "blur,change"
          }
        ],
        site: [
          {
            pattern: /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/,
            message: "参照 http://www.smppw.com",
            trigger: "blur,change"
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      emnus: "getEnums",
      userId: "getUserId"
    }),
    ifAdmin() {
      return this.emnus.c_admin_acc
        .filter(item => item.name === "机构销售")
        .map(item => item.value)
        .includes(this.userId + "");
    },

    orgType() {
      return this.ifAdmin
        ? this.emnus.c_org
        : this.emnus.c_org.filter(item => item.value != 2);
    }
  },

  components: {
    selectLink
  },
  props: ["modal", "formValidate", "port"],
  watch: {
    "formValidate.tag": {
      handler(val) {
        setTimeout(() => {
          let el = $(".org-adding-form");
          let selectTags = $(el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(el).find(".ivu-select-selection .ivu-tag span");
          let tag = $(el).find(
            ".ivu-select-dropdown-list .ivu-select-item .ivu-tag span"
          );
          let tagContianer = $(el).find(
            ".ivu-select-dropdown-list .ivu-select-item .ivu-tag"
          );
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    },
    cust_type_ids: {
      handler(val) {
        setTimeout(() => {
          let el = $(".org-adding-form");
          let selectTags = $(el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(el).find(".ivu-select-selection .ivu-tag span");
          let tag = $(el).find(
            ".ivu-select-dropdown-list .ivu-select-item .ivu-tag span"
          );
          let tagContianer = $(el).find(
            ".ivu-select-dropdown-list .ivu-select-item .ivu-tag"
          );
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    },

    modal(val) {
      this.selfModal = val;
      this.$refs.link.currentCountry = "86";
      this.$refs.link.onCountryChange("86");
    }
  },
  mounted() {
    this.selectData = this.emnus.c_area_all;
    this.customerType = this.emnus.c_port_all_cust;
  },
  methods: {
    // 获取下拉
    // getPullList() {
    //  fetchAllPullList().then(res => {
    //     this.selectData = res.data.data.c_area_all;
    //   });
    // },

    changeLoading() {
      this.loading = false;
      this.$nextTick(() => {
        this.loading = true;
      });
    },
    ok() {
      this.$refs["formValidate"].validate(valid => {
        if (!valid) {
          return this.changeLoading();
        }
        setTimeout(() => {
          this.changeLoading();
          var formData = {
            org_name: this.formValidate.name,
            oc_id: this.formValidate.type,
            area_ids: this.formValidate.area,
            area_info: this.formValidate.address,
            phone_num: this.formValidate.phone,
            website: this.formValidate.site,
            oc_content: this.formValidate.note,
            portrait: this.formValidate.tag,
            register_num: this.formValidate.register_num,
            cust_type_ids: this.cust_type_ids
          };
          this.$nextTick(() => {
            this.$refs["formValidate"].resetFields();
            if (this.$refs.link.currentProvince) {
              this.$refs.link.currentProvince = "";
            }
            if (this.$refs.link.currentCity) {
              this.$refs.link.currentCity = "";
            }
            if (this.$refs.link.currentTown) {
              this.$refs.link.currentTown = "";
            }
          });

          this.$emit("submit", formData);
          this.$refs.link.currentCountry = "";
        }, 1000);
      });
    },
    cancel() {
      this.$refs.formValidate.resetFields();
      this.$refs.link.clear();
      this.$emit("close");
    },
    getSelInfo(val) {
      this.formValidate.area = val;
    }
  }
};
</script>
