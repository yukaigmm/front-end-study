const getTableConfig = function () {
  return {
    columns: [{
        title: "机构名称",
        key: "org_name",
        render: (h, {row }) => {
          if (row.bread && row.bread.length) {
            return h(
              "div",
              row.bread
              .map((bread, index, breads) => {
                return h(
                  "a", {
                    attrs: {
                      title: "点击查看详情"
                    },
                    on: {
                      click: e => {
                        let tab = {
                          activeName: bread.title,
                          pid: bread.id,
                          name: `${bread.title}${bread.id}`,
                          component: "departmentDetails",
                          isShow: true
                        };
                        this.$store.dispatch("setTabs", tab);
                        e.stopPropagation();
                      }
                    }
                  },
                  index === breads.length - 1 ?
                  `${bread.title}` :
                  `${bread.title}>`
                );
              })
              .splice(1)
            );
          } else {
            let tab = {
              activeName: row.org_name,
              pid: row.id,
              name: `${row.org_name}${row.id}`,
              component: "departmentDetails",
              isShow: true
            };
            return h(
              "a", {
                attrs: {
                  title: "点击查看详情"
                },
                on: {
                  click: e => {
                    this.$store.dispatch("setTabs", tab);
                    e.stopPropagation();
                  }
                }
              },
              row.org_name || "--"
            );
          }
        }
      },
      {
        title: "机构类型",
        key: "oc_id",
        width: 110,
        render: (h, {
          row
        }) => {
          let text = "";

          let matchItem = this.orgType.filter(
            item => item.value == row.oc_id
          );

          text = matchItem.length ? matchItem[0]["name"] : "--";
          return h("span", text || "--");
        }
      },
      {
        title: "客户类型",
        key: "cust_type_ids",
        width: 110,
        render: (h, {
          row
        }) => {
          let cust_type_ids = row.cust_type_ids.length ?
            row.cust_type_ids : [];
          if (cust_type_ids && cust_type_ids.length) {
            let cusType = [];
            cust_type_ids.forEach(item => {
              this.customerTypeList.forEach(itemCus => {
                if (item == itemCus.value) {
                  cusType.push({
                    name: itemCus.name,
                    style: itemCus.style
                  });
                }
              });
            });
            return h(
              "div",
              cusType.map(item => {
                return h(
                  "Tag", {
                    style: {
                      ...item.style
                    }
                  },
                  `${item.name}`
                );
              })
            );
          } else {
            return "--";
          }
        }
      },
      {
        title: "城市",
        key: "city_id",
        width: 80,
        render: (h, {
          row
        }) => {
          let text = "";
          let matchItem = this.cityList.filter(
            item => item.value == row.city_id
          );
          text = matchItem.length ? matchItem[0]["name"] : "--";
          return h("span", text || "--");
        }
      },
      {
        title: "更新时间",
        key: "update_time",
        width: 90,
        render: (h, params) => {
          return h(
            "p", {
              attrs: {
                title: `${params.row.update_time}`
              }
            },
            `${params.row.update_time.substring(0, 10)}`
          );
        }
      },
      {
        title: "更新人",
        key: "update_member_name",
        width: 80,
        render(h, {
          row
        }) {
          return h("span", row.update_member_name || "--");
        }
      },
      {
        title: "操作",
        key: "action",
        width: 100,
        render: (h, {
          row
        }) => {
          let canDelete =
            row.create_member_id === this.userId || this.canDelete;
          return h("div", [
            h(
              "span", {
                attrs: {
                  class: "deleteBtn"
                },
                on: {
                  click: () => {
                    this.$refs.modalChange.showModal(row);
                  }
                }
              },
              "编辑"
            ),
            h(
              "span", {
                attrs: {
                  class: canDelete ? "deleteBtn" : "disabledBtn"
                },
                on: {
                  click: () => {
                    this.deleteOrg(row.id);
                  }
                }
              },
              "删除"
            )
          ]);
        }
      }
    ]

  }
}

export {
  getTableConfig
};
