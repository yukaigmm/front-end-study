<template>
  <div class="org-content">
    <div class="org-searchOptions keydown-box">
      <search-area @changeSearchParam="changeSearchParam" @onKeydownSearch="search">
        <div slot="default">
          <!-- 第一行：机构类型和类别 -->
          <Row>
            <Col span="8">
              <FormItem label="关键字">
                <Input v-model.trim="input" placeholder="请输入关键字,如：总部 分部"></Input>
              </FormItem>
            </Col>
            <Col span="8" offset="1">
              <FormItem label="更新人">
                <Row>
                  <Col span="11">
                    <Select
                      v-model="select_self_dpt"
                      placeholder="请选择部门"
                      clearable
                      @on-change="changeDept"
                    >
                      <Option
                        v-for="item in sel_depart"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>
                  <Col span="12" offset="1">
                    <Select
                      v-model="person"
                      not-found-text="无匹配数据"
                      :disabled="choose"
                      clearable
                      placeholder="请选择更新人"
                      style="width:100%;"
                      @on-change="onPersonChange"
                    >
                      <Option
                        v-for="item in select_update"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></Option>
                    </Select>
                  </Col>
                </Row>
              </FormItem>
            </Col>
            <Col span="4">
              <!-- 提交按钮 -->
              <Button type="primary" @click="search" style="margin-left:8px;">搜索</Button>
              <Button type="ghost" style="margin-left: -7px" @click="reset">重置</Button>
            </Col>
          </Row>
        </div>
        <div slot="extend">
          <!-- 第二行：地域和关键字 -->
          <Row>
            <Col span="8">
              <select-link ref="link" :selectData="selectData" @onChange="getSelInfo"></select-link>
            </Col>
            <Col span="8" offset="1">
              <FormItem label="更新时间">
                <DatePicker
                  style="width:100%;"
                  type="daterange"
                  format="yyyy-MM-dd"
                  placeholder="选择日期"
                  v-model="dateRange"
                ></DatePicker>
              </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span="8">
              <FormItem label="机构类型">
                <Row>
                  <Col span="11">
                    <Select v-model="select_org" clearable placeholder="请选择">
                      <Option
                        v-for="item in selectAll.c_org"
                        :value="item.value"
                        :key="item.value"
                      >{{item.name}}</Option>
                    </Select>
                  </Col>
                  <Col span="12" offset="1">
                    <Select v-model="select_depart" clearable placeholder="请选择机构类别">
                      <Option
                        v-for="item in selectAll.c_depart"
                        :value="item.value"
                        :key="item.value"
                      >{{item.name}}</Option>
                    </Select>
                  </Col>
                </Row>
              </FormItem>
            </Col>
            <Col span="8" offset="1">
              <FormItem label="画像">
                <Select v-model="portrait" clearable placeholder="请选择画像" multiple>
                  <Option
                    v-for="item in selectAll.c_port_all_org"
                    :value="item.value"
                    :key="item.id"
                  >
                    <Tag :style="item.style">{{item.name}}</Tag>
                  </Option>
                </Select>
              </FormItem>
            </Col>
          </Row>
        </div>
      </search-area>
    </div>
    <!-- 机构列表的操作按钮 -->
    <div class="org-cl org-orgItems">
      <div class="org-orgEdit">
        <Button type="primary" @click="showAdd">添加</Button>
        <Button type="primary" style="margin-left: 8px" @click="outPut">导出</Button>
      </div>
    </div>
    <!-- 机构列表 -->
    <div v-loading="loading" element-loading-text="拼命加载中" class="tableContainer">
      <Table border :columns="columns" :data="data.data"></Table>
    </div>
    <!-- 分页器 -->
    <div class="org-cl">
      <div class="org-page-div">
        <Page
          :total="data.total"
          placement="top"
          :current="page"
          :page-size="pageSize"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizeChange"
          show-elevator
          show-sizer
          show-total
        />
      </div>
    </div>
    <!-- 新增模态框 -->
    <div>
      <modal-add
        :selectData="selectData"
        :port="selectAll.c_port_all_org"
        :orgType="selectAll.c_org"
        :modal="add"
        :formValidate="formValidate"
        @submit="submit"
        @close="close"
      ></modal-add>
    </div>
    <!-- 编辑信息模态框 -->
    <modalChangeOrgMsg ref="modalChange" @closeModal="closeModal"></modalChangeOrgMsg>
  </div>
</template>
<script>
import searchArea from "../../components/search-area";
// import modalDel from "./modal-del.vue";
import modalAdd from "./modal-addOrg.vue";
import modalChangeOrgMsg from "./modal-changOrgMsg";
import selectLink from "./select-link.vue";

import {
  getReciver,
  fetchAllPullList,
  getUpdatePerson,
  getInnerDepart,
  fetchGrid,
  postFormData,
  delRow,
  getList
} from "@/service/getData";
import { mapGetters } from "vuex";
import $ from "jquery";
import _ from "lodash";
import moment from "moment";
import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  mixins: [getMinusNumber],
  data() {
    return {
      customerType: [],
      isShowMoreParams: false,
      portrait: [],
      person: [],
      dept_id: [],
      choose: true,
      loading: false,
      portraits: [],
      // 搜索时提供的数据
      input: "",
      select_org: "", //机构类型
      select_depart: "", //类别
      select_update: "", //更新人
      select_self_dpt: "", //内部部门
      dateRange: [],
      date: [],
      data: {},
      config: {},
      sel_update: [],
      sel_depart: [],
      //设置selectAll变量，接收getSelectAll函数通过axios请求回来的数据
      // selectAll: {},
      // 和子组件通信
      port: [],
      // selectData: [],
      area_id: "",
      // orgType: [],
      formValidate: {
        name: "",
        type: "",
        phone: "",
        site: "",
        tag: [],
        address: "",
        note: "",
        cust_type_ids: [],
        area: "",
        register_num: ""
      },
      // 分页器
      pageSize: 10,
      page: 1,
      // 模态框
      del: false,
      currentId: "",
      add: false,
      columns: [
        {
          title: "机构名称",
          key: "org_name",
          render: (h, params) => {
            if (params.row.bread && params.row.bread.length) {
              return h(
                "div",
                params.row.bread
                  .map((bread, index, breads) => {
                    return h(
                      "a",
                      {
                        on: {
                          click: e => {
                            let tab = {
                              activeName: bread.title,
                              pid: bread.id,
                              name: `${bread.title}${bread.id}`,
                              component: "departmentDetails",
                              isShow: true
                            };
                            this.$store.dispatch("setTabs", tab);
                            e.stopPropagation();
                          }
                        }
                      },
                      index === breads.length - 1
                        ? `${bread.title}`
                        : `${bread.title}>`
                    );
                  })
                  .splice(1)
              );
            } else {
              return h("div", [
                h(
                  "a",
                  {
                    on: {
                      click: e => {
                        this.$store.dispatch("setTabs", tab);

                        e.stopPropagation();
                      }
                    }
                  },
                  params.row.org_name
                )
              ]);
            }
          }
        },
        {
          title: "机构类型",
          key: "orgType",
          width: 110,
          render:(h,{row})=>{
            return h("span",row.orgType || "--")
          }
        },
        {
          title: "客户类型",
          key: "cust_type_ids",
          width: 110,
          render: (h, params) => {
            let cust_type_ids = params.row.cust_type_ids.length
              ? params.row.cust_type_ids
              : [];
            if (cust_type_ids && cust_type_ids.length) {
              let cusType = [];
              cust_type_ids.forEach(item => {
                this.customerType.forEach(itemCus => {
                  if (item == itemCus.value) {
                    cusType.push({
                      name: itemCus.name,
                      style: itemCus.style
                    });
                  }
                });
              });
              return h(
                "div",
                cusType.map(item => {
                  return h(
                    "Tag",
                    {
                      style: { ...item.style }
                    },
                    `${item.name}`
                  );
                })
              );
            } else {
              return "--";
            }
          }
        },
        {
          title: "城市",
          key: "city",
          width: 80,
          render: (h, params) => {
            return h("p", params.row.city ? params.row.city : "--");
          }
        },
        {
          title: "更新时间",
          key: "update_time",
          width: 90,
          render: (h, params) => {
            return h(
              "p",
              {
                attrs: {
                  title: `${params.row.update_time}`
                }
              },
              `${params.row.update_time.substring(0, 10)}`
            );
          }
        },
        {
          title: "更新人",
          key: "update_member_name",
          width: 80,
          render(h, { row }) {
            return h("span", row.update_member_name || "--");
          }
        },
        {
          title: "操作",
          key: "action",
          width: 100,
          render: (h, params) => {
            if (params.row.create_member_id === this.userId || this.canDelete) {
              return h("div", [
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    on: {
                      click: () => {
                        this.$refs.modalChange.showModal(params.row);
                      }
                    }
                  },
                  "编辑"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    on: {
                      click: () => {
                        this.confirm(params.row.id);
                      }
                    }
                  },
                  "删除"
                )
              ]);
            } else {
              return h("div", [
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    on: {
                      click: () => {
                        this.$refs.modalChange.showModal(params.row);
                      }
                    }
                  },
                  "编辑"
                )
              ]);
            }
          }
        }
      ]
    };
  },
  computed: {
    ...mapGetters({
      tabs: "getTabs",
      emnus: "getEnums",
      userInfo: "getUser"
    }),

    userId() {
      return this.userInfo.id;
    },

    canDelete() {
      return this.userInfo.auth.functional.includes("deleteOrg");
    },

    selectAll() {
      return this.emnus;
    },

    selectData() {
      return this.selectAll.c_area_all;
    },

    cityList() {
      return this.selectAll.c_area_deep_2;
    },

    orgType() {
      return this.selectAll.c_org;
    }
  },

  mounted() {
    this.customerType = this.emnus.c_port_all_cust;
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".org-searchOptions", ".org-orgItems", ".org-page-div"],
      ".tableContainer"
    );
    this.loading = true;
    let data = JSON.parse(JSON.stringify(this.selectAll));
    let _this = this;
    // 由于机构的类型和城市需要在getSelectAll的请求返回的数据中匹配，因此使用promise保证另一个异步请求发送回来之后能获取到selectAll的数据

    let cityList = data.c_area_deep_2;
    let orgType = data.c_org;
    _this.date = _this.dateRange;
    fetchGrid("index/organization", {
      rows: 10,
      page: 1,
      update_time: _this.dateRange,
      sortKey: "update_time",
      sortOrder: "desc"
    }).then(res => {
      _this.data = res.data;
      for (let item1 of _this.data.data) {
        for (let item2 of cityList) {
          if (item2.value == item1.city_id) {
            item1["city"] = item2.name;
          }
        }
      }
      for (let item1 of _this.data.data) {
        for (let item2 of orgType) {
          if (item2.value == item1.oc_id) {
            item1["orgType"] = item2.name;
          }
        }
      }
      _this.loading = false;
    });

    this.getInnerDepart();
  },
  watch: {
    portrait: {
      handler(val) {
        setTimeout(() => {
          let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(this.$el).find(
            ".ivu-select-selection .ivu-tag span"
          );
          let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
          let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    },
    select_self_dpt: {
      handler(val) {
        if (val) {
          this.choose = true;
        }
      },
      deep: true
    },
    dateRange: {
      handler(val) {
        if (val.length && val[0]) {
          this.dateRange[0] = this.setTimeZone(val[0]);
          this.dateRange[1] = this.setTimeZone(val[1]);
        }
      },
      deep: true
    }
  },
  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 120;
      let minusNumber = this.getMinusNumberOfFixedTable();

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },
    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },
    // 关闭模态框之后刷新列表
    closeModal(val) {
      this.getOrgList();
    },
    // 控制更多打开时传递的参数
    changeSearchParam(val) {
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".org-searchOptions", ".org-orgItems", ".org-page-div"],
          ".tableContainer"
        );
      });

      this.isShowMoreParams = val;
    },
    onPersonChange(val) {
      this.update_member_id = val;
    },
    changeDept(val) {
      this.choose = true;
      this.select_update = [];
      this.dept_id = val;
      let data = {
        dept_id: this.dept_id,
        type: 1
      };
      if (!val) {
        return;
      }
      this.getWorkmate(data);
    },
    getWorkmate(data) {
      if (this.dept_id.length == 0) {
        this.choose = true;
      }
      getReciver(data).then(res => {
        if (res.code == 20000) {
          this.select_update = res.data;
          this.choose = false;
        }
      });
    },
    // 定义获得数据的方法
    // getSelectAll() {
    //   let _this = this;
    //   return new Promise((resolve, reject) => {
    //     fetchAllPullList().then(function(res) {
    //       _this.selectAll = res.data.data;
    //       _this.selectData = _this.selectAll.c_area_all;
    //       _this.cityList = _this.selectAll.c_area_deep_2;
    //       _this.orgType = _this.selectAll.c_org;
    //       // _this.loading = false;
    //       resolve(_this.selectAll);
    //     });
    //   });
    // },
    // 获得更新人的下拉列表
    getUpdatePerson() {
      getUpdatePerson().then(res => {
        this.sel_update = res.data;
      });
    },
    // 获得内部部门的级联菜单
    getInnerDepart() {
      getInnerDepart().then(res => {
        this.sel_depart = res.data;
      });
    },
    // 获得机构列表
    getOrgList() {
      let ori = {};
      let now = new Date();
      if (!this.isShowMoreParams) {
        if (this.dateRange[0]) {
          ori = {
            rows: this.pageSize,
            page: this.page,
            org_name: JSON.parse(JSON.stringify(this.input))
              .trim()
              .split(/[ ]+/),
            update_member_id: this.update_member_id,
            dept_id: this.dept_id,
            // area_ids: this.area_id,
            sortKey: "update_time",
            sortOrder: "desc"
          };
        } else {
          ori = {
            rows: this.pageSize,
            page: this.page,
            org_name: JSON.parse(JSON.stringify(this.input))
              .trim()
              .split(/[ ]+/),
            update_member_id: this.update_member_id,
            dept_id: this.dept_id,
            // area_ids: this.area_id,
            sortKey: "update_time",
            sortOrder: "desc"
          };
        }
      } else {
        // 判断选择时间的数组是否为空数组，如果是则踢掉，否则请求不到后台数据
        if (this.dateRange[0]) {
          ori = {
            portrait: this.portrait,
            rows: this.pageSize,
            page: this.page,
            oc_id: this.select_org,
            depart_id: this.select_depart,
            area_ids: this.area_id,
            org_name: JSON.parse(JSON.stringify(this.input))
              .trim()
              .split(/[ ]+/),
            update_time: this.dateRange,
            update_member_id: this.update_member_id,
            dept_id: this.dept_id,
            sortKey: "update_time",
            sortOrder: "desc"
          };
        } else {
          ori = {
            portrait: this.portrait,
            rows: this.pageSize,
            page: this.page,
            oc_id: this.select_org,
            depart_id: this.select_depart,
            area_ids: this.area_id,
            org_name: JSON.parse(JSON.stringify(this.input))
              .trim()
              .split(/[ ]+/),
            update_member_id: this.update_member_id,
            dept_id: this.dept_id,
            sortKey: "update_time",
            sortOrder: "desc"
          };
        }
      }

      let params = {};
      // 遍历对象，踢掉没有值的键
      for (let key in ori) {
        if (ori[key]) {
          params[key] = ori[key];
        }
      }
      this.config = {
        params: params
      };
      this.loading = true;
      let _this = this;
      fetchGrid("index/organization", params).then(res => {
        _this.data = res.data;
        for (let item1 of _this.data.data) {
          for (let item2 of _this.cityList) {
            if (item2.value == item1.city_id) {
              item1["city"] = item2.name;
            }
          }
        }
        for (let item1 of _this.data.data) {
          for (let item2 of _this.orgType) {
            if (item2.value == item1.oc_id) {
              item1["orgType"] = item2.name;
            }
          }
        }
        this.loading = false;
      });
    },
    // 搜索按钮，增加配置，发送请求
    getSelInfo(val) {
      this.area_id = val;
    },
    search() {
      this.page = 1;
      this.pageSize = 10;
      this.getOrgList();
    },
    // 点击重置按钮，将所有的输入框和选择框的值都设置为空，然后发送请求获得列表
    reset() {
      // this.dateRange = [];
      this.portrait = [];
      this.input = "";
      this.select_org = "";
      this.select_depart = "";
      this.update_member_id = "";
      this.dept_id = [];
      this.$refs["link"].currentCountry = "";
      this.area_id = "";
      this.select_update = "";
      this.select_self_dpt = "";
      this.dateRange = [];
      this.date = this.dateRange;
      this.getOrgList();
    },
    // 分页器功能部分
    onPageSizeChange(val) {
      this.page = 1;
      this.pageSize = val;
      this.getOrgList();
    },
    onPageChange(val) {
      this.page = val;
      this.getOrgList();
    },
    // 点击删除按钮显示的模态框
    showModel(id) {
      this.currentId = id;
      this.del = true;
    },
    // 点击新增按钮显示的模态框
    showAdd() {
      this.add = true;
      this.formValidate = {
        name: "",
        type: "",
        phone: "",
        site: "",
        tag: [],
        address: "",
        note: "",
        area: "",
        cust_type_ids: [],
        register_num: ""
      };
    },
    // 提交添加机构的模态框
    submit(data) {
      this.add = false;
      this.loading = true;
      postFormData("index/organization", data).then(res => {
        if (res.code === 20000) {
          this.$Message.info("添加成功");
          this.getOrgList();
        } else {
          this.$Message.warning(res.msg);
        }
        this.loading = false;
      });
    },
    close() {
      this.add = false;
    },
    // 删除机构的模态框
    confirm(id) {
      this.$Modal.confirm({
        title: "删除",
        content: "确定删除？",
        width: 300,
        loading: true,
        onOk: () => {
          delRow("index/organization/", id).then(res => {
            if (res.code === 20000) {
              this.$Message.info("删除成功");
              // 如果删除的机构，已经在tab，中重新更新tab去掉删除的tab
              let tabsArr = this.tabs.filter(item => {
                return item.pid != id;
              });
              this.$store.dispatch("setTabsAll", tabsArr);
              this.getOrgList();
            } else {
              this.$Message.warning(`${res.msg}`);
            }
            this.$Modal.remove();
          });
        }
      });
    },
    // cancel() {
    //   this.del = false;
    // },
    // 点击导出按钮配置之后发送请求
    outPut() {
      if (this.data.total === 0) {
        this.$Message.warning({
          content: "无可导出数据"
        });
        return;
      }
      this.$Message.loading({
        content: "正在导出中，请稍候...",
        duration: 0
      });
      let config = this.config;
      if (config.params) {
        config.params.rows = this.data.total > 1000 ? 1000 : this.data.total;
      } else {
        config = {
          params: {
            page: 1,
            rows: this.data.total > 1000 ? 1000 : this.data.total
          }
        };
      }
      fetchGrid("index/orgexport", config.params).then(resp => {
        if (resp.code == 20000) {
          resp = resp.data;
          const link = document.createElement("a");
          link.href = resp.url;
          link.target = "_blank";
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
        this.$Message.destroy();
        this.$Message.info("导出成功！");
      });
    }
  },
  components: {
    modalAdd,
    selectLink,
    searchArea,
    modalChangeOrgMsg
  }
};
</script>
<style scoped>
.org-content {
  position: relative;
}

.org-orgEdit {
  float: right;
  padding: 10px;
}

.org-cl:after {
  content: "";
  display: block;
  clear: both;
  height: 0;
  line-height: 0;
  visibility: hidden;
}

.org-page-div {
  padding: 10px;
  float: right;
}
</style>
