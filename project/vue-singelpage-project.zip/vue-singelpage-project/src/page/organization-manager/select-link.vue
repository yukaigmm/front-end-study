<template>
    <!-- <div> -->
            <FormItem label="地域" prop="area">
                <Row>
                    <Col span="6" class="link">
                        <Select v-model="currentCountry" @on-change="onCountryChange(currentCountry)" transfer clearable placeholder="请选择">
                            <Option v-for="(item,index) in country" :value="item.value" :key="index">{{item.name}}</Option>
                        </Select>
                    </Col>
                    <Col span="6" class="link">
                        <Select v-model="currentProvince" @on-change="onProvinceChange(currentProvince)" transfer :disabled="!currentCountry" clearable placeholder="请选择">
                            <Option v-for="(item,index) in province" :value="item.value" :key="index">{{item.name}}</Option>
                        </Select>
                    </Col>
                    <Col span="6" class="link">
                        <Select v-model="currentCity" @on-change="onCityChange(currentCity)" transfer :disabled="!currentProvince" clearable placeholder="请选择">
                            <Option v-for="(item,index) in city" :value="item.value" :key="index">{{item.name}}</Option>
                        </Select>
                    </Col>
                    <Col span="6" class="link">
                        <Select v-model="currentTown" @on-change="onTownChange(currentTown)" transfer :disabled="!currentCity" v-show="showTown" clearable placeholder="请选择">
                            <Option v-for="(item,index) in town" :value="item.value" :key="index">{{item.name}}</Option>
                        </Select>
                    </Col>
                </Row>
            </FormItem>
    <!-- </div> -->
</template>

<script>
import { isEmpty } from "lodash";
export default {
  data() {
    return {
      currentCountry: "",
      currentProvince: "",
      currentCity: "",
      currentTown: "",
      selectAll: {},
      // 在获得selectAll的数据之后将每一级的数据缓存起来
      country: [],
      // province: [],
      // city: [],
      // town: [],
      showTown: false
    };
  },
  props: ["selectData", "currentValue"],
  mounted() {
    setTimeout(() => {
      this.country = this.selectData;
      this.onCountryChange("86");
    }, 1500);
  },
  watch: {
    selectData: function(val) {
      if (isEmpty(val)) {
        this.currentCountry = "";
        this.currentProvince = "";
        this.currentCity = "";
        this.currentTown = "";
      }
    },
    currentValue: function(val) {
      if (val) {
        let strs = val.split(",");
        if (strs[0]) {
          this.currentCountry = strs[0] + "";
        } else {
          this.currentCountry = "";
        }
        if (strs[1]) {
          this.currentProvince = strs[1] + "";
        } else {
          this.currentProvince = "";
        }
        if (strs[2]) {
          this.currentCity = strs[2] + "";
        } else {
          this.currentCity = "";
        }
        if (strs[3]) {
          this.currentTown = strs[3] + "";
        } else {
          this.currentTown = "";
        }
      } else {
        this.currentCountry = "";
        this.currentProvince = "";
        this.currentTown = "";
        this.currentCity = "";
      }
    },
    province(val) {
      if (!(val && val.length)) {
        this.currentCity = "";
        this.currentTown = "";
      }
    },
    city(val) {
      if (!(val && val.length)) {
        this.currentTown = "";
      }
    }
  },
  computed: {
    province() {
      if (this.currentCountry) {
        let province = [];
        for (let country of this.country) {
          if (this.currentCountry == country.value) {
            province = country.children;
            break;
          }
        }
        return province;
      } else {
        return [];
      }
    },
    city() {
      if (this.currentProvince && this.province && this.province.length) {
        let city = [];
        for (let province of this.province) {
          if (this.currentProvince == province.value) {
            city = province.children;
            break;
          }
        }
        return city;
      } else {
        return [];
      }
    },

    town() {
      if (this.currentCity) {
        let town = [];
        for (let city of this.city) {
          if (this.currentCity == city.value) {
            town = city.children;
            break;
          }
        }
        if (town.length) {
          this.showTown = true;
        } else {
          this.showTown = false;
        }
        return town;
      } else {
        this.showTown = false;
        return [];
      }
    }
  },
  methods: {
    //  在国家选项菜单发生变化时，使得省级菜单渲染对应的值
    onCountryChange(val) {
      // 如果前面的选项框为空，那么后面的选项框需要清除
      if (!this.currentCountry) {
        this.currentProvince = "";
        this.currentCity = "";
        this.currentTown = "";
      }
      let area =
        this.currentCountry +
        "," +
        this.currentProvince +
        "," +
        this.currentCity +
        "," +
        this.currentTown;
      area = area
        .split(",")
        .filter(item => item-0)
        .join(",");
      this.$emit("onChange", area);
    },
    // 在省级菜单发生变化时，使得市级菜单渲染相对应的值
    onProvinceChange(val) {
      // 如果前面的选项框为空，那么后面的选项框需要清除
      if (!this.currentProvince) {
        this.currentCity = "";
        this.currentTown = "";
      }
      let area =
        this.currentCountry +
        "," +
        this.currentProvince +
        "," +
        this.currentCity +
        "," +
        this.currentTown;
      area = area
        .split(",")
        .filter(item => item-0)
        .join(",");
      this.$emit("onChange", area);
    },
    onCityChange(val) {
      // 如果前面的选项框为空，那么后面的选项框需要清除
      if (!this.currentCity) {
        this.currentTown = "";
        // 当市级的选项卡为空时，后面的县级选项卡应该隐藏
        this.showTown = false;
      }
      let area =
        this.currentCountry +
        "," +
        this.currentProvince +
        "," +
        this.currentCity +
        "," +
        this.currentTown;
      area = area
        .split(",")
        .filter(item => item-0)
        .join(",");
      this.$emit("onChange", area);
    },
    onTownChange(val) {
      let area =
        this.currentCountry +
        "," +
        this.currentProvince +
        "," +
        this.currentCity +
        "," +
        this.currentTown;
      area = area
        .split(",")
        .filter(item => item-0)
        .join(",");
      this.$emit("onChange", area);
    },

    clear(){
      this.currentCountry = "";
      this.currentProvince = "";
      this.currentCity = "";
      this.currentTown = "";
    }
  }
};
</script>
<style>
.link {
  padding-right: 6px;
}
.link:last-child {
  padding-right: 0;
}
.ivu-select-dropdown-list {
  max-height: 150px;
}
</style>
