<template>
  <Modal
  title="编辑"
  v-model="modal"
  width="700"
  :mask-closable="false"
  >
     <!-- 关闭的×  -->
    <div slot="close" @click="cancel">
        <Icon type="ios-close-empty"></Icon>
    </div>
    <!-- 表单区域 -->
    <Form :label-width="80" ref="editForm" :model="formData" :rules="ruleValidate">
        <Row>
            <Col span="11">
                <FormItem label="机构名称" prop="org_name">
                    <Input  placeholder="机构名称" v-model.trim="formData.org_name">
                    </Input>
                </FormItem>
            </Col>
            <Col span="11" offset="1">
            <FormItem label="机构类型" prop="depart_id">
                <Row>
                   <Col span="12">
                       <Select placeholder="类型" v-model="formData.oc_id"  clearable :disabled="formData.oc_id==2&&!ifAdmin">
                           <Option   v-for="(item,index) in orgTypeList" :key="index" :value="item.value">{{item.name}}</Option >
                       </Select>
                   </Col>
                   <Col span="11" offset="1" >
                       <Select placeholder="类别"  v-model="formData.depart_id" clearable>
                           <Option   v-for="(item,index) in dpartTypeList" :key="index" :value="item.value">{{item.name}}</Option >
                       </Select>
                   </Col>
                </Row>
            </FormItem>
            </Col>
        </Row>
        <Row>
            <Col span="11">
               <FormItem label="电话" prop="phone_num">
                   <Input placeholder="电话" v-model.trim="formData.phone_num"></Input>
               </FormItem>
            </Col>
            <Col span="11" offset="1">
               <FormItem label="网址" prop="website">
                   <Input placeholder="网址" v-model.trim="formData.website"></Input>
               </FormItem>
            </Col>
        </Row>
        <Row>
            <Col span="23">
              <FormItem label="画像">
                  <Select  not-found-text="无匹配数据" v-model="formData.portrait" multiple>
                      <Option  v-for="(item,index) in orgTagList" :key="index" :value="item.value" ><slot><Tag :data-tag="item.value" :style="item.style">{{item.name}}</Tag></slot></Option >
                  </Select>
              </FormItem>
            </Col>
        </Row>
        <Row>
            <Col span="23">
                <FormItem label="客户类型" prop="cust_type_ids"  style="padding-right:8px;">
                    <Select v-model="formData.cust_type_ids" multiple placeholder="请选择">
                        <Option v-for="item in customerType" :value="item.value" :key="item.value"><Tag :style="item.style">{{item.name}}</Tag></Option>
                    </Select>
                </FormItem>
            </Col>
        </Row>
        <Row>
            <Col span="23">
               <selectLink ref="link" :selectData="selectData"  :currentValue="formData.area_ids" @onChange="getSelInfo"></selectLink>
            </Col>
        </Row>
        <Row>
          <Col span="23">
               <FormItem label="详细地址">
                   <Input placeholder="详细地址" v-model.trim="formData.area_info"></Input>
               </FormItem>
          </Col>
        </Row>
        <Row>
          <Col span="23">
         <FormItem label="备案编码" prop="register_num"  style="padding-right:8px;">
                    <Input v-model.trim="formData.register_num" placeholder="请输入"></Input>
                </FormItem>
           </Col>
        </Row>
    </Form>
    <!-- 底部按钮 -->
    <div slot="footer">
        <Button  size="large" style="width:70px;" @click="cancel" >取消</Button>
        <Button type="primary" size="large" :loading="buttonLoading" style="width:70px; padding:6px;" @click="submitEdit">
        提交</Button>
    </div>
  </Modal>
</template>
<script>
import $ from "jquery";
import selectLink from "./select-link";
import {  putFormData } from "@/service/getData";
import { mapGetters } from "vuex";
export default {
  components: {
    selectLink
  },
  watch: {
    "formData.portrait": {
      handler(val) {
        setTimeout(() => {
          let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(this.$el).find(
            ".ivu-select-selection .ivu-tag span"
          );
          let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
          let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    },
    "formData.cust_type_ids": {
      handler(val) {
        setTimeout(() => {
          let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(this.$el).find(
            ".ivu-select-selection .ivu-tag span"
          );
          let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
          let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    }
  },
  data() {
    return {
      customerType: [],
      buttonLoading: false,
      selectData: [],
      orgId: "",
      modal: false,
      formData: {},
      orgTypeList: [],
      orgTagList: [],
      dpartTypeList: [],
      ruleValidate: {
        depart_id: [
          { required: true, message: "请选择机构类型", trigger: "change" }
        ],
        org_name: [
          {
            required: true,
            message: "请输入机构名称",
            trigger: "change, blur"
          },
          { min: 2, message: "机构部门不得少于2个字", trigger: "change, blur" }
        ],
        area_info: [{ required: false, trigger: "change,blur" }],
        phone_num: [
          {
            pattern: /(^1(3|4|5|6|7|8|9)\d{9}$)|(^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$)/,
            message: "请输入正确电话 参照 400-6802928",
            trigger: "change, blur"
          }

          // { type: 'array', max: 2, message: '最多选择两个爱好', trigger: 'change' }
        ],
        // area: [{ required: true, message: "请选择城市", trigger: "blur" }],
        website: [
          {
            pattern: /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/,
            message: "参照 http://www.smppw.com",
            trigger: "change, blur"
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters({
      emnus: "getEnums",
       userId: "getUserId"
    }),
    ifAdmin() {
      return this.emnus.c_admin_acc
        .filter(item => item.name === "机构销售")
        .map(item => item.value)
        .includes(this.userId + "");
    }
  },
  mounted() {
    this.orgTypeList = this.emnus.c_org;
    this.dpartTypeList = this.emnus.c_depart;
    this.orgTagList = this.emnus.c_port_all_org;
    this.selectData = this.emnus.c_area_all;
    this.customerType = this.emnus.c_port_all_cust;
  },
  methods: {
    // 显示模态框
    showModal(rowData) {
      this.modal = true;
      this.orgId = rowData.id;
      this.$refs["editForm"].resetFields();
      this.$nextTick(() => {
        this.formData = {
          org_name: rowData.org_name,
          oc_id: rowData.oc_id ? rowData.oc_id + "" : "",
          depart_id: rowData.depart_id ? rowData.depart_id + "" : "",
          area_info: rowData.area_info,
          phone_num: rowData.phone_num,
          website: rowData.website,
          area_ids: rowData.area_ids,
          portrait: rowData.portrait
            ? JSON.parse(rowData.portrait).map(item => item + "")
            : [],
          cust_type_ids: rowData.cust_type_ids.length
            ? rowData.cust_type_ids.map(item => item + "")
            : [],
          register_num: rowData.register_num
        };
      });
    },
    // 取消时的事件
    cancel() {
      this.modal = false;
      this.formData.area_ids = "";
      this.$refs["editForm"].resetFields();
    },
    // 获取选定的地区id
    getSelInfo(val) {
      this.formData.area_ids = val;
    },
    // 提交修改
    submitEdit() {
      this.$refs["editForm"].validate(valid => {
        if (valid) {
          this.buttonLoading = true;
          putFormData("index/organization", this.orgId, this.formData).then(
            res => {
              if (res.code === 20000) {
                this.buttonLoading = false;
                this.$Message.info("修改成功");
                this.$emit("closeModal");
                this.cancel();
              }
              this.buttonLoading = false;
            }
          );
        } else {
          this.buttonLoading = false;
          this.$Message.info("输入有误");
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
</style>


