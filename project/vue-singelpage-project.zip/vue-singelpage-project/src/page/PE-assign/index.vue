<template>
  <div>
     <div class="help-icon">
      <Poptip placement="left-start" trigger="hover">
        <span style="font-size:12px;">帮助<Icon type="help-circled" style="font-size: 16px;vertical-align:text-bottom;"></Icon></span>
        <div slot="content">
          <p>
            <strong style="color:#495060;font-size:14px;">1. 分配给自己</strong>：只有没人负责的公司才可分配给自己
          </p>
          <p>
            <strong style="color:#495060;font-size:14px;">2. 清除责任人</strong>：只能清除自己负责公司的责任人
          </p>
        </div>
      </Poptip>
    </div>
    <div class="PE-assign-searchOptions keydown-box">
      <search-area @changeSearchParam="changeSearchParam" @onKeydownSearch="search">
        <div slot="default">
          <Row>
            <Col span="8">
            <FormItem label="机构名">
              <Input v-model.trim="basicSearchForm.orgName" placeholder="请输入关键字,如：总部 分部"></Input>
            </FormItem>
            </Col>
            <Col span="8">
            <FormItem label="责任人">
              <Select v-model="basicSearchForm.managerIds" multiple>
                <!-- <Option v-for="option in managerList" :value="option.value" :key="option.value">{{option.label}}</Option> -->
                <OptionGroup v-for = "item in managerList"  :label="item.label" :key="item.value">
                  <Option v-for="child in item.children" :value="child.value" :key="child.value">{{ child.label }}</Option>
                </OptionGroup>
              </Select>
            </FormItem>
            </Col>
            <Col span="4">
            <!-- 提交按钮 -->
            <Button type="primary" @click="search" style="margin-left:8px;">搜索</Button>
            <Button type="ghost" style="margin-left: -7px" @click="reset">重置</Button>
            </Col>
          </Row>
        </div>
        <div slot="extend">
          <Row>
             <!-- <Col span="8"> -->
            <!-- <FormItem label="客户类型">
              <Select v-model="extendSearchForm.custTypeIds" multiple>
                <Option v-for="option in enums.c_port_all_cust" :value="option.value" :key="option.value">
                  <Tag :style="option.style">{{option.name}}</Tag>
                </Option>
              </Select>
            </FormItem> -->
             <!-- <FormItem label="机构类型">
              <Row>
                <Col span="11">
                <Select v-model="extendSearchForm.ocId" clearable placeholder="请选择">
                  <Option v-for="item in enums.c_org" :value="item.value" :key="item.value">{{item.name}}</Option>
                </Select>
                </Col>
                <Col span="12" offset="1">
                <Select v-model="extendSearchForm.departId" clearable placeholder="请选择">
                  <Option v-for="item in enums.c_depart" :value="item.value" :key="item.value">{{item.name}}</Option>
                </Select>
                </Col>
              </Row>
            </FormItem>
            </Col> -->

            <!-- <Col span="8"> -->
            <!-- <FormItem label="地域">
              <component is="SelectLinkage" v-model="extendSearchForm.area_ids" :config="{
                useForSearch: true,
                cacheKey: 'c_area_all',
                row: 'dialog-form-item-row',}" style="width:100%;">
              </component>
            </FormItem> -->
            <!-- </Col> -->
            <Col span="8">
            <FormItem label="状态">
              <Select v-model="extendSearchForm.status" :clearable="true">
                <Option v-for="option in statusOptions" :value="option.value" :key="option.value">{{option.label}}</Option>
              </Select>
            </FormItem>
            </Col>

             <Col span="8">
            <FormItem label="是否有报告">
              <Select v-model="extendSearchForm.hasReport" :clearable="true">
                <Option v-for="option in hasReportOptions" :value="option.value" :key="option.value">{{option.label}}</Option>
              </Select>
            </FormItem>
            </Col>

          </Row>

           <Row>
             <Col span="8">
            <FormItem label="是否打分">
              <Select v-model="extendSearchForm.hasScore" :clearable="true">
                <Option v-for="option in hasScoreOptions" :value="option.value" :key="option.value">{{option.label}}</Option>
              </Select>
            </FormItem>
            </Col>
             <Col span="8">
            <FormItem label="打分人">
              <Input v-model.trim="extendSearchForm.scoreUser" placeholder="请输入打分人">
              </Input>
            </FormItem>
            </Col>
           </Row>

           <Row>
             <Col span="8">
            <FormItem label="是否简评">
              <Select v-model="extendSearchForm.hasSummary" :clearable="true">
                <Option v-for="option in hasSummaryOptions" :value="option.value" :key="option.value">{{option.label}}</Option>
              </Select>
            </FormItem>
            </Col>

             <Col span="8">
            <FormItem label="打分日期">
              <DatePicker type='daterange' v-model="extendSearchForm.scoreDate" placeholder='请选择打分日期' style="width:100%;">
              </DatePicker>
            </FormItem>
            </Col>




           </Row>
            <!-- <Row>

           </Row> -->
           <Row>
             <Col span="24">
             <Row>
               <Col span="8" >
                <FormItem label='城市'>
                  <Select
                   placeholder='请输入城市关键字'
                   @on-change='onCitySelectChange'
                   v-model="chosenArea"
                   filterable
                   remote
                   :key='citySelectKey'
                   :remote-method='getAreaList'
                   :loading='areaListLoading'>
                     <Option v-for="item in areaList" :label="item.label" :value="item.areaCode" :key="item.areaCode">
                     </Option>
                  </Select>
                 </FormItem>
               </Col>
               <Col span="8" class="tagList">
                 <Tag
                  v-for='(item,index) in cityTagList'
                  closable
                  :key="index"
                  :name="item.areaCode"
                  @on-close="onTagClose">
                    {{item.areaName}}</Tag>
               </Col>
             </Row>

             </Col>
           </Row>
        </div>
      </search-area>
    </div>
    <div class="clear PE-assign-btn">
      <Button type="primary" class="left" @click="batchAdd" v-if="hasRight">批量分配</Button>
    </div>
    <div class="tableContainer">
      <Table
        ref="table"
        :data="tableData"
        :columns="columns" v-loading="tableLoading"
        border
        element-loading-text='拼命加载中'
        @on-selection-change="onTableSelectionChange">
        </Table>
    </div>
    <div class="clear PE-assign-page">
      <Page class="right" :total="total" placement="top" :current="pageNo" :page-size="pageSize" @on-change="onPageNoChange" @on-page-size-change="onPageSizeChange" show-elevator show-sizer show-total />
    </div>
    <manager-modal ref="managerModal" @selectManager="selectManager"></manager-modal>
  </div>
</template>
<script>
import searchArea from "../../components/search-area";
import managerModal from "../customers-assign/select-dept-manager-modal";
import SelectLinkage from "../../components/inputs/select-linkage";
import { forEach, debounce } from "lodash";
import { mapGetters } from "vuex";
import $ from "jquery";
import moment from "moment";
import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  components: {
    searchArea,
    managerModal,
    SelectLinkage
  },

  mixins:[getMinusNumber],

  data() {
    return {
      citySelectKey: null,
      cityTagList: [],
      areaList: [],
      chosenArea: "",
      areaListLoading: false,
      hasSummaryOptions: [
        {
          value: 1,
          label: "是"
        },
        {
          value: 0,
          label: "否"
        }
      ],
      hasReportOptions: [
        {
          value: 1,
          label: "是"
        },
        {
          value: 0,
          label: "否"
        }
      ],
      hasScoreOptions: [
        {
          value: 1,
          label: "是"
        },
        {
          value: 0,
          label: "否"
        }
      ],
      statusOptions: [
        {
          value: 0,
          label: "未分配"
        },
        {
          value: 1,
          label: "已分配"
        }
      ],
      useExtendParams: false,
      initBasicSearchForm: {
        orgName: "",
        managerIds: []
      },
      basicSearchForm: {
        managerIds: [],
        orgName: ""
      },
      initExtendSearchForm: {
        status: "",
        area_ids: [],
        custTypeIds: [],
        hasReport: "",
        hasScore: "",
        hasSummary: "",
        scoreUser: "",
        scoreDate: []
      },
      extendSearchForm: {
        status: "",
        area_ids: [],
        custTypeIds: [],
        hasReport: "",
        hasScore: "",
        hasSummary: "",
        scoreUser: "",
        scoreDate: []
      },
      pageSize: 10,
      pageNo: 1,
      total: 0,
      managerList: [],
      tableLoading: false,
      tableSelectedRow: [],
      tableData: [],
      columns: [
        {
          type: "selection",
          width: 50,
          key: "selection",
          align: "center"
        },
        {
          title: "机构名",
          key: "orgName",
          width: 300,
          render: (h, params) => {
            let bread = params.row.bread.filter((item, index) => index !== 0);
            return h(
              "span",
              bread.map((item, index) => {
                if (index === bread.length - 1) {
                  return h("span", `${item.title}`);
                } else {
                  return h("span", `${item.title}>`);
                }
              })
            );
          }
        },
        {
          title: "机构类型",
          key: "ocId",
          width: 90,
          render: (h, { row }) => {
            return this.orgTypeMap[row.ocId];
          }
        },
        {
          title: "客户类型",
          key: "custTypeIds",
          width: 80,
          render: (h, params) => {
            if (params.row.custTypeIds && params.row.custTypeIds.length) {
              let cusType = [];
              params.row.custTypeIds.forEach(item => {
                this.enums.c_port_all_cust.forEach(itemCus => {
                  if (item == itemCus.value) {
                    cusType.push({
                      name: itemCus.name,
                      style: itemCus.style
                    });
                  }
                });
              });
              return h(
                "div",
                cusType.map(item => {
                  return h(
                    "Tag",
                    {
                      style: { ...item.style }
                    },
                    `${item.name}`
                  );
                })
              );
            } else {
              return "--";
            }
          }
        },
        {
          title: "城市",
          key: "cityId",
          width: 90,
          render: (h, { row }) => {
            return this.cityMap[row.cityId] || "--";
          }
        },
        {
          title: "责任人",
          key: "manager",
          width: 80,
          render: (h, { row }) => {
            return row.manager && row.manager.length
              ? row.manager.join("/")
              : "--";
          }
        },
        {
          title: "是否分配",
          key: "status",
          width: 80,
          render: (h, { row }) => {
            return row.manager.length ? "是" : "否";
          }
        },

        {
          title: "是否有报告",
          key: "hasReport",
          width: 80,
          render: (h, { row }) => {
            if (row.hasReport) {
              return parseInt(row.hasReport) ? "是" : "否";
            } else {
              return "否";
            }
          }
        },
        {
          title: "是否简评",
          key: "hasSummary",
          width: 80,
          render: (h, { row }) => {
            return row.hasSummary ? "是" : "否";
          }
        },
        {
          title: "是否打分",
          key: "hasScore",
          width: 80,
          render: (h, { row }) => {
            return row.hasScore ? "是" : "否";
          }
        },
        {
          title: "打分人",
          key: "scoreUser",
          width: 80,
          render: (h, { row }) => {
            return row.scoreUser ? `${row.scoreUser}` : "--";
          }
        },
        {
          title: "打分日期",
          key: "scoreDate",
          width: 100,
          render: (h, { row }) => {
            return row.scoreDate && row.scoreDate != "0000-00-00"
              ? `${row.scoreDate}`
              : "--";
          }
        },

        {
          title: "操作",
          key: "action",
          width: 170,
          fixed: "right",
          render: (h, { row, column, index }) => {
            let assignFlag = true&&this.hasRight;
            let clearFlag = true&&this.hasRight;
            let managerIds = row.managerIds.split(",").filter(item => item);
            if (managerIds.length) {
              assignFlag = false;
            } else {
              clearFlag = false;
            }
            if (!managerIds.includes(this.user.id + "")) {
              clearFlag = false;
            }

            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: assignFlag ? "deleteBtn" : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      // 只有数据部和研究部可以操作
                      // let dept_id = [];
                      // if (this.user.depts_info) {
                      //   dept_id = this.user.depts_info.map(
                      //     item => item.dept_id
                      //   );
                      //   dept_id.push(this.user.dept_id);
                      //   dept_id = [...new Set(dept_id)];
                      // } else {
                      //   dept_id.push(this.user.dept_id);
                      // }
                      // if (!dept_id.includes(1) && !dept_id.includes(15)) {
                      //   this.$Message.warning("没有权限！");
                      //   return;
                      // }
                      if (!assignFlag) {
                        return;
                      }

                      this.assignToMySelf([row.orgId]);
                    }
                  }
                },
                "分配给自己"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: clearFlag ? "deleteBtn" : "disabledBtn"
                  },
                  on: {
                    click: () => {
                      if (!clearFlag) {
                        return;
                      }
                      this.clearResponsor([row.orgId]);
                      // if (row.managerIds && row.managerIds.length) {
                      //   let managerIds = row.managerIds
                      //     .split(",")
                      //     .filter(item => item);
                      //   if (managerIds.some(item => item == this.user.id)) {
                      //     this.clearResponsor([row.orgId]);
                      //   } else {
                      //     this.$Message.warning("只能清除负责人是自己的机构！");
                      //   }
                      // } else {
                      //   this.$Message.warning("该机构没有负责人！");
                      // }
                    }
                  }
                },
                "清除责任人"
              )
            ]);
          }
        }
      ]
    };
  },
  watch: {
    "extendSearchForm.custTypeIds": {
      handler(val) {
        setTimeout(() => {
          let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(this.$el).find(
            ".ivu-select-selection .ivu-tag span"
          );
          let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
          let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    }
  },
  computed: {
    ...mapGetters({
      enums: "getEnums",
      user: "getUser"
    }),
    orgTypeMap() {
      let obj = {};
      this.enums.c_org.forEach(item => {
        obj[item.value] = item.name;
      });
      return obj;
    },
    cityMap() {
      let obj = {};
      this.enums.c_area_deep_2.forEach(item => {
        obj[item.value] = item.name;
      });
      return obj;
    },
    hasRight(){
      return this.user.auth.functional.includes("assignPe");
    }
  },

  methods: {
    // 城市搜索远程匹配城市列表
    getAreaList(query) {
      if (query.trim() !== "") {
        this.areaList = [];
        this.areaListLoading = true;
        const that = this;
        let params = {
          areaName: `${query}`
        };
        that.$http.get(`/common/getAreaByName`, params).then(res => {
          res.data.forEach(item => {
            let label = "";
            let value = "";
            item.bread.forEach(breadItem => {
              label += `/${breadItem.areaName}`;
              value += `,${breadItem.areaCode}`;
            });
            let option = Object.assign(
              {},
              {
                label: label.trim().slice(1),
                areaCode: value.trim().slice(1),
                areaName: item.current.areaName
              }
            );
            that.areaList.push(option);
          });
          that.areaListLoading = false;
        });
      } else {
        this.areaList = [];
      }
    },

    //  选择的城市不同时生成城市标签
    onCitySelectChange(val) {
      let currentCity = this.areaList.filter(item => item.areaCode == val)[0];
      if (
        !this.cityTagList.some(item => item.areaCode == currentCity.areaCode)
      ) {
        this.cityTagList.push(currentCity);
      }
      this.chosenArea = "";
      this.areaList = [];
      this.citySelectKey = Date.now();
    },

    // 关闭城市标签
    onTagClose(e, name) {
      let closeIndex = null;
      this.cityTagList.forEach((item, index) => {
        if (item.areaCode === name) {
          closeIndex = index;
        }
      });
      this.cityTagList.splice(closeIndex, 1);
    },

    // 分配给自己
    assignToMySelf(orgIds) {
      let params = {
        opType: 1,
        orgIds
      };
      this.$http.post("Diligence/custAllocate", params).then(res => {
        if (res.code === 20000) {
          this.$Message.success("分配成功！");
          this.search();
        } else {
          this.$Message.error("分配失败！");
        }
      });
    },
    // 清除责任人
    clearResponsor(orgIds) {
      let params = {
        opType: 2,
        orgIds
      };
      this.$http.post("Diligence/custAllocate", params).then(res => {
        if (res.code === 20000) {
          this.$Message.success("清除成功！");
          this.search();
        } else {
          this.$Message.error("清除失败！");
        }
      });
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 130;
      let minusNumber = this.getMinusNumberOfFixedTable(); 

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    changeSearchParam(val) {
      this.useExtendParams = val;
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [".PE-assign-searchOptions", ".PE-assign-btn", ".PE-assign-page"],
          ".tableContainer"
        );
      });
    },
    getManagerList() {
      // this.$http
      //   .get("dept/getUserByDept", {
      //     dept_id: 1, //数据部
      //     type: 1
      //   })
      //   .then(resp => {
      //     if (resp.code === 20000) {
      //       this.managerList = _.map(resp.data, person => person);
      //     }
      //   });
      this.$http
        .get("dept/getAllWithUser", {
          dept_id: "1,15"
        })
        .then(res => {
          if (res.code === 20000) {
            this.managerList = res.data;
          }
        });
    },
    search() {
      this.pageNo = 1;
      this.pageSize = 10;
      this.getData();
    },
    reset() {
      this.basicSearchForm = JSON.parse(
        JSON.stringify(this.initBasicSearchForm)
      );
      this.extendSearchForm = JSON.parse(
        JSON.stringify(this.initExtendSearchForm)
      );
      this.cityTagList = [];
      this.chosenArea = "";
      this.search();
    },

    setTimeZone(date) {
      let localTime = moment(date).format("YYYY-MM-DD");
      return localTime;
    },

    getData() {
      let basicSearchForm = JSON.parse(JSON.stringify(this.basicSearchForm));
      if (basicSearchForm.orgName) {
        basicSearchForm.orgName = basicSearchForm.orgName.trim().split(/[ ]+/);
      }
      let extendSearchForm = JSON.parse(JSON.stringify(this.extendSearchForm));
      if (extendSearchForm.scoreDate && extendSearchForm.scoreDate.length) {
        if (extendSearchForm.scoreDate[0]) {
          extendSearchForm.scoreDate[0] = this.setTimeZone(
            extendSearchForm.scoreDate[0]
          );
          extendSearchForm.scoreDate[1] = this.setTimeZone(
            extendSearchForm.scoreDate[1]
          );
        } else {
          extendSearchForm.scoreDate = [];
        }
      }

      if (this.cityTagList.length) {
        extendSearchForm.area_ids = this.cityTagList.map(item => item.areaCode);
      }
      let searchForm = {
        ...basicSearchForm,
        ...(this.useExtendParams ? extendSearchForm : {}),
        ...{ ocId: 7 }
      };
      for (let key in searchForm) {
        if (!searchForm[key] && searchForm[key] !== 0) {
          delete searchForm[key];
        }
      }
      let params = {
        ...searchForm,
        pageSize: this.pageSize,
        pageNo: this.pageNo
      };
      this.tableLoading = true;
      this.$http.get("FundAllocated", params).then(resp => {
        this.tableLoading = false;
        if (resp.code === 20000) {
          this.tableData = resp.data.records;
          this.total = resp.data.total;
        } else {
          this.tableData = [];
          this.total = 0;
        }
      });
    },
    onPageNoChange(val) {
      this.pageNo = val;
      this.getData();
    },
    onPageSizeChange(val) {
      this.pageNo = 1;
      this.pageSize = val;
      this.getData();
    },
    batchAdd() {
      if (this.tableSelectedRow.length) {
        let hasDistRow = this.tableSelectedRow.some(row => {
          return row.status === 1;
        });
        if (hasDistRow) {
          this.$Message.error("选择数据中存在已负责的机构");
        } else {
          //1为数据部的部门id， true表示多选
          this.$refs.managerModal.show(1, true, "pe");
        }
      } else {
        this.$Message.warning("请先选择机构");
      }
    },
    onTableSelectionChange(selection) {
      this.tableSelectedRow = selection;
    },
    selectManager(managerIds) {
      if (this.tableSelectedRow.length && managerIds) {
        //批量分配api
        this.tableLoading = true;
        this.$http
          .post("custManagerRela", {
            memberIds: managerIds,
            orgIds: this.tableSelectedRow.map(row => row.orgId),
            resourceType: 2,
            opType: 1
          })
          .then(resp => {
            this.tableSelectedRow = [];
            this.tableLoading = false;
            if (resp.code === 20000) {
              this.$Message.success("设置成功");
              this.getData();
            }
          });
      }
    }
  },
  mounted() {
    this.getManagerList();
    this.getData();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".PE-assign-searchOptions", ".PE-assign-btn", ".PE-assign-page"],
      ".tableContainer"
    );
  }
};
</script>
<style lang="less" rel="styleSheet/less">
.clear {
  padding: 8px 0;
  .left {
    float: left;
  }
  .right {
    float: right;
  }
  &:after {
    clear: both;
    display: block;
    content: "";
  }
}
.tagList {
  padding-left: 5px;
}
.help-icon {
  position: absolute;
  right: 20px;
  top: 48px;
  color: #2d8cf0;
  font-size: 16px;
  z-index: 1;
}
</style>
