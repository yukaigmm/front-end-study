<template>
  <div>
    <Form :model="formData" ref="form" :rules="validateRules" :label-width="90">
      <Row>
        <!-- <i-col span="12">
          <form-item label="直连版本" prop="fundLinkLevel">
            <i-select v-model="formData.fundLinkLevel" transfer>
              <i-option
                v-for="item in fundLinkLevelOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>-->

        <i-col span="12">
          <form-item label="公司套餐类型" >
            <i-select
              v-model="configData.versionType"
              disabled
              placeholder="请选择套餐类型"
              clearable
              transfer
            >
              <i-option
                v-for="item in versionOptions"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="12">
          <form-item label="禁用聊天">
            <i-switch v-model="ifChatDisabled" true-value="1" false-value="0" disabled>
              <span slot="open">是</span>
              <span slot="close">否</span>
            </i-switch>
          </form-item>
        </i-col>
      </Row>
      <Row>
        <i-col span="12">
          <form-item label="开始日期"  >
            <date-picker
              style="width:100%;"
              placeholder="请选择开始日期"
              v-model="configData.startDate"
              disabled
              clearable
              transfer
            ></date-picker>
          </form-item>
        </i-col>
        <i-col span="12">
          <form-item label="结束日期"  >
            <date-picker
              style="width:100%;"
              placeholder="请选择结束日期"
              v-model="configData.endDate"
              disabled
              clearable
              transfer
            ></date-picker>
          </form-item>
        </i-col>

        <i-col span="12">
          <form-item label="直连状态" prop="fmStatus">
            <i-select v-model="formData.fmStatus" transfer>
              <i-option
                v-for="item in fmStatusOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>
      </Row>
    </Form>
  </div>
</template>

<script>
export default {
  props: {
    accountData: {
      default: () => ({}),
      type: Object
    },

    configData: {
      type: Object,
      default: () => ({})
    },

    ifChatDisabled:{
      type:String,
      default:"0"
    }
  },

  computed: {
    formData() {
      let keys = ["fundLinkLevel", "fmStatus"];
      let data = JSON.parse(JSON.stringify(this.accountData));
      let form = {};
      keys.forEach(key => {
        form[key] = data[key];
      });

      return form;
    }
  },

  data() {
    return {
      validateRules: {
        fundLinkLevel: {
          required: true,
          message: "直连版本不能为空"
        },
        fmStatus: {
          required: true,
          message: "直连状态不能为空"
        }
      },
      fundLinkLevelOptions: [
        {
          label: "试用版",
          value: 1
        },
        {
          label: "基础版",
          value: 2
        }
      ],
      fmStatusOptions: [
        {
          label: "直连私募用户",
          value: 1
        },
        {
          label: "普通用户",
          value: 2
        }
      ],
      versionOptions: [
        {
          value: "1",
          label: "私募-试用版"
        },
        {
          value: "2",
          label: "私募-基础版"
        },
        {
          value: "6",
          label: "机构-试用版"
        },
        {
          value: "3",
          label: "机构-基础版"
        },
        {
          value: "4",
          label: "机构-加强版"
        },
        {
          value: "5",
          label: "机构-豪华版"
        },
        {
          value: "0",
          label: "关闭"
        }
      ],
    };
  },

  methods: {
    close() {
      this.$refs.form.resetFields();
    },

    validate() {
      let status = null;
      this.$refs.form.validate(valid => {
        if (valid) {
          status = Promise.resolve({
            status: true,
            comp: "peInfo"
          });
        } else {
          status = Promise.reject({
            status: false,
            comp: "peInfo"
          });
        }
      });

      return status;
    },

    getData() {
      return Promise.resolve(JSON.parse(JSON.stringify(this.formData)));
    }
  }
};
</script>

<style lang="less" scoped>
</style>

