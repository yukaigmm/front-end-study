<template>
  <div>
    <Row>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">名片</div>
          <div
            class="visit-card-wrap value-wrap"
            :style="{'background-image':formData.visiting_card_url}"
          >
            <span v-if="!formData.visiting_card_url">暂无名片</span>
          </div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">姓名</div>
          <div class="value-wrap">{{formData.name||"--"}}</div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">职务</div>
          <div class="value-wrap">{{formData.post||"--"}}</div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">手机</div>
          <div class="value-wrap">{{formData.telephone||"--"}}</div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">微信</div>
          <div class="value-wrap">{{formData.weichat||"--"}}</div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">用户</div>
          <div class="value-wrap">{{formData.contacts_type||"--"}}</div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">邮箱</div>
          <div class="value-wrap">{{formData.email||"--"}}</div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">性别</div>
          <div class="value-wrap">{{formData.sex||"--"}}</div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">年龄(岁)</div>
          <div class="value-wrap">{{formData.age||"--"}}</div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">公司</div>
          <div class="value-wrap">{{formData.org_name||"--"}}</div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">部门</div>
          <div class="value-wrap">{{formData.department||"--"}}</div>
        </div>
      </i-col>
      <i-col span="12">
        <div class="item-wrap">
          <div class="label-wrap">画像</div>
          <div class="value-wrap">
            <span
              v-for="(item,index) in formData.portrait"
              :key="index"
              :style="item.style"
            >{{item.text}}</span>
          </div>
        </div>
      </i-col>
    </Row>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  props: {
    contactData: {
      default: () => ({}),
      type: Object
    }
  },

  computed: {
    ...mapGetters({
      emnus: "getEnums"
    }),

    portraitList() {
      return this.emnus.c_port_all;
    },

    sexOptions() {
      return this.emnus.c_sex;
    },
    ageOptions() {
      return this.emnus.c_age;
    },

    userTypeOptions() {
      return this.emnus.c_usertype;
    },

    formData() {
      let data = JSON.parse(JSON.stringify(this.contactData));

      // 处理名片
      if (data.visiting_card_url) {
        let picUrl = JSON.parse(JSON.stringify(data.visiting_card_url));
        let url;
        if (picUrl.includes("/Onstage/")) {
          url =
            process.env.NODE_ENV === "production"
              ? "https://fof.simuwang.com/"
              : "https://master-test.simuwang.com/";
        } else {
          url =
            process.env.NODE_ENV === "production"
              ? "http://static.simuwang.com/"
              : "https://static-test-ali.simuwang.com/";
          picUrl = `Uploads/crm/${data.visiting_card_url}`;
        }

        data.visiting_card_url = `url(${url}${picUrl})`;
      } else {
        data.visiting_card_url = "";
      }

      // 处理公司部门信息
      if (data.bread && data.bread.length) {
        data.org_name = data.bread[1].title || data.org_name;

        data.department =
          data.bread
            .map(bread => {
              return bread.title;
            }).splice(2)
            .join(" ") || "--";
      } else {
        data.org_name = data.org_name;
        data.department = "总部";
      }

      // 处理画像
      let portrait = [];
      if (data.portrait) {
        portrait = JSON.parse(data.portrait);
      }

      if (portrait && portrait.length) {
        data.portrait = portrait.map(item => {
          let text = "";
          let style = null;
          let matchOne = this.portraitList.filter(p => {
            return p.value == item;
          })[0];

          text = matchOne.name;
          style = matchOne.style;

          return {
            text,
            style: {
              "border-radius": "10%",
              "max-width": "80px",
              "min-width": "40px",
              display: "inline-block",
              "text-align": "center",
              padding: "3px 5px",
              cursor: "pointer",
              ...style
            }
          };
        });
      } else {
        data.portrait = [
          {
            text: "--",
            style: {}
          }
        ];
      }

      // 处理年龄
      let matchItem = this.ageOptions.filter(item => item.value == data.age)[0];
      data.age = matchItem ? matchItem.name : "--";

      // 处理性别
      let sexMatchItem = this.sexOptions.filter(
        item => item.value == data.sex
      )[0];
      data.sex = sexMatchItem ? sexMatchItem.name : "--";

      // 处理用户类型
      let userType = this.userTypeOptions.filter(
        item => item.value == data.contacts_type
      )[0];
      data.contacts_type = userType ? userType.name : "--";
      return data;
    }
  },

  data() {
    return {};
  }
};
</script>

<style lang="less" scoped>
.item-wrap {
  display: flex;
  justify-content: flex-start;
  margin: 8px;
  align-items: flex-start;
  .label-wrap {
    width: 90px;
    text-align: right;
    margin-right: 10px;
    color: #666;
  }
  .value-wrap {
    flex: 1;
  }

  .visit-card-wrap {
    width: 250px;
    height: 160px;
    border: 1px solid #cccccc;
    border-radius: 10px;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    -moz-background-size: 100% 100%;
    text-align: center;
    line-height: 160px;
  }
}
</style>

