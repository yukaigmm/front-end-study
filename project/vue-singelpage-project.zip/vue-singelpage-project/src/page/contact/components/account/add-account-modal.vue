<template>
  <Modal
    v-model="modal"
    :title="modalTitle"
    :mask-closable="false"
    width="800"
    class="people-modal"
  >
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button @click="onCancel">取消</Button>
      <Button @click="onOk" type="primary" :loading="btnLoading">确定</Button>
    </div>

    <Collapse v-loading="modalLoading" v-model="activeComp" element-loading-text="拼命加载中">
      <Panel v-for="item in infosConfig" :key="item.name" :name="item.name">
        {{item.title}}
        <component
          :key="item.name"
          :contact-data="contactData"
          :account-data="accountData"
          :is-add="isAdd"
          :account-type="accountType"
          :recommendName="recommendName"
          :config-data="peConfigData"
          :ifChatDisabled="ifChatDisable"
          :is="item.component"
          slot="content"
          :ref="item.name"
        />
      </Panel>
    </Collapse>
  </Modal>
</template>


<script>
import { uniq } from "lodash";
import contactBasicInfo from "./components/contact-basic-info.vue";
import accountBasicInfo from "./components/account-basic-info.vue";
import fofAccountInfo from "./components/fof-account-info.vue";
import fmAccountInfo from "./components/fm-account-info.vue";
import fundlinkAccountInfo from "./components/fundlink-account-info.vue";
import bluevAccountInfo from "./components/bluev-account-info.vue";
import axios from "axios";

export default {
  data() {
    return {
      btnLoading: false,
      modal: false,
      accountType: "",
      isAdd: true,
      contactData: {},
      accountData: {},
      accountId: "",
      modalLoading: false,
      recommendName: "",
      activeComp: [],
      crmUserId: "",
      peConfigData: {},
      ifChatDisable: "0"
    };
  },

  components: {
    contactBasicInfo,
    accountBasicInfo,
    fofAccountInfo,
    fmAccountInfo,
    fundlinkAccountInfo,
    bluevAccountInfo
  },

  computed: {
    modalTitle() {
      let title = this.isAdd ? "账号开通" : "账号编辑";
      switch (this.accountType) {
        case "fof":
          title = `${title}：组合大师`;
          break;
        case "fm":
          title = `${title}：基金大师`;
          break;
        case "pe":
          title = `${title}：私募直营店`;
          break;
        case "blueV":
          title = `${title}：蓝V`;
          break;
        default:
          break;
      }
      return title;
    },

    infosConfig() {
      let baseConfig = [
        {
          name: "contactBaseInfo",
          title: "联系人基本信息",
          component: "contactBasicInfo"
        },
        {
          name: "accountBaseInfo",
          title: "账号基本信息",
          component: "accountBasicInfo"
        }
      ];

      switch (this.accountType) {
        case "fof":
          baseConfig.push({
            name: "fofInfo",
            title: "组合大师账号信息",
            component: "fofAccountInfo"
          });
          break;
        case "fm":
          baseConfig.push({
            name: "fmInfo",
            title: "基金大师账号信息",
            component: "fmAccountInfo"
          });
          break;
        case "pe":
          baseConfig.push({
            name: "peInfo",
            title: "私募直营店信息",
            component: "fundlinkAccountInfo"
          });
          break;
        case "blueV":
          baseConfig.push({
            name: "blueVInfo",
            title: "蓝V信息",
            component: "bluevAccountInfo"
          });
          break;
        default:
          break;
      }

      return baseConfig;
    }
  },

  methods: {
    onOk() {
      let mapping = {
        pe: "peInfo",
        fof: "fofInfo",
        blueV: "blueVInfo",
        fm: "fmInfo"
      };

      this.btnLoading = true;
      Promise.all([
        this.$refs.accountBaseInfo[0].validate(),
        this.$refs[mapping[this.accountType]][0].validate()
      ])
        .then(res => {
          this.getData(mapping);
        })
        .catch(err => {
          this.btnLoading = false;
          let comp = JSON.parse(JSON.stringify(this.activeComp));
          comp.push(err.comp);
          this.activeComp = uniq(comp);
          this.$Message.warning("请按红色文字提示填写内容！");
        });
    },

    // 新增账号
    addAccount(data = {}) {
      let apiMapping = {
        fof: "accounts/registerAccount",
        pe: `FlAccount/${this.crmUserId}`,
        fm: `FmAccount/${this.contactData.id}`,
        blueV: "openBlueVip"
      };

      let paramsMapping = {
        fof: this.getFofParams(data),
        pe: this.getPeParams(data),
        fm: this.getFmParams(data),
        blueV: this.getBlueVParams(data)
      };
      this.$http
        .post(apiMapping[this.accountType], paramsMapping[this.accountType])
        .then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.$Message.success("新增成功！");
            this.onCancel();
            this.$emit("refresh");
          } else {
            this.$Message.error(`新增失败：${res.msg}`);
          }
        })
        .catch(err => {
          this.btnLoading = false;
          this.$Message.error("网络请求错误！");
        });
    },

    // 编辑账号
    editAccount(data = {}) {
      let apiMapping = {
        fof: "accounts/updateAccount",
        pe: `FlAccount/${this.accountId}`,
        fm: `FmAccount/${this.accountId}`,
        blueV: "updateBlueVip"
      };

      let paramsMapping = {
        fof: this.getFofParams(data),
        pe: this.getPeParams(data),
        fm: this.getFmParams(data),
        blueV: this.getBlueVParams(data)
      };

      let method = this.accountType === "blueV" ? "post" : "putWithoutId";
      this.$http[method](
        apiMapping[this.accountType],
        paramsMapping[this.accountType]
      )
        .then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.onCancel();
            this.$Message.success(`修改成功！`);
            this.$emit("refresh");
          } else {
            this.$Message.error(`修改失败：${res.msg}`);
          }
        })
        .catch(err => {
          this.btnLoading = false;
          this.$Message.error("网络请求错误！");
        });
    },

    getFofParams(data = {}) {
      let params = {};

      let tempData = JSON.parse(JSON.stringify(data));

      if (tempData.initPsw) {
        delete tempData.initPsw;
      }
      params = {
        productId: 1,
        orgId: this.contactData.org_id,
        password: data.initPsw,
        realName: this.contactData.name,
        email: this.contactData.email,
        visitingCardUrl: this.contactData.visiting_card_url,

        ...tempData
      };

      //  编辑时，加上账号id
      if (!this.isAdd) {
        params = {
          id: this.accountId,
          ...params
        };
        delete params.productId;
      }

      return params;
    },

    getFmParams(data = {}) {
      let params = {};
      let tempData = JSON.parse(JSON.stringify(data));

      return tempData;
    },

    getPeParams(data = {}) {
      let params = {};
      let tempData = JSON.parse(JSON.stringify(data));
      params = {
        ...tempData
      };

      return params;
    },

    getBlueVParams(data = {}) {
      let params = {};
      let tempData = JSON.parse(JSON.stringify(data));

      let dept = "";

      // 处理公司部门信息
      if (this.contactData.bread && this.contactData.bread.length) {
        dept =
          this.contactData.bread
            .map(bread => {
              return bread.title;
            })
            .splice(2)
            .join(" ") || "--";
      } else {
        dept = "总部";
      }

      params = {
        realname: this.contactData.name,
        init_psw: tempData.initPsw,
        telephone: tempData.accountNo,
        blue_vip_status: tempData.blueVipStatus,
        blue_vip_remark: tempData.remark,
        official_user_id: this.accountData.officialUserId,
        bv_company_name: this.contactData.org_name,
        bv_dept_name: dept,
        bv_position_name: this.contactData.post,
        bv_level: tempData.bvLevel,
        bv_referee: tempData.recommenderId,
        bv_payment: tempData.payingFlag,
        blue_vip_time: tempData.beginDate,
        bv_expire_time: tempData.endDate,
        send_message: tempData.ifNotice
      };

      if (!this.isAdd) {
        delete params.realName;
        delete params.init_psw;
        delete params.send_message;
      }

      return params;
    },

    getData(mapping) {
      Promise.all([
        this.$refs.accountBaseInfo[0].getData(),
        this.$refs[mapping[this.accountType]][0].getData()
      ])
        .then(res => {
          let data = {
            ...res[0],
            ...res[1]
          };

          if (this.isAdd) {
            this.addAccount(data);
          } else {
            this.editAccount(data);
          }
        })
        .catch(err => {
          console.log(err);
          this.btnLoading = false;
          this.$Message.error("提交失败！");
        });
    },

    onCancel() {
      let mapping = {
        pe: "peInfo",
        fof: "fofInfo",
        blueV: "blueVInfo",
        fm: "fmInfo"
      };
      this.$refs.accountBaseInfo[0].close();
      this.$refs[mapping[this.accountType]][0].close();
      this.accountType = "";
      this.isAdd = true;
      this.contactData = {};
      this.accountData = {};
      this.accountId = "";
      this.recommendName = "";
      this.activeComp = [];
      this.peConfigData = {};
      this.modal = false;
    },

    show(
      contactData = {},
      type = "",
      isAdd,
      accountId,
      recommendName,
      // officialUser,
      crmUserId,
      peConfigData
    ) {
      this.accountId = accountId;
      this.contactData = JSON.parse(JSON.stringify(contactData));
      this.recommendName = recommendName;
      this.isAdd = isAdd;
      this.accountType = type;
      this.crmUserId = crmUserId;
      this.peConfigData = peConfigData;
      this.modal = true;
      switch (type) {
        case "pe":
          this.$nextTick(() => {
            this.activeComp = ["accountBaseInfo", "peInfo"];
          });
          break;
        case "fof":
          this.$nextTick(() => {
            this.activeComp = ["accountBaseInfo", "fofInfo"];
          });
          break;
        case "fm":
          this.$nextTick(() => {
            this.activeComp = ["accountBaseInfo", "fmInfo"];
          });
          break;
        case "blueV":
          this.$nextTick(() => {
            this.activeComp = ["accountBaseInfo", "blueVInfo"];
          });
          break;
      }
      if (!isAdd) {
        this.getAccountData(this.getParams());
      } else {
        this.accountData = {
          telephone: this.contactData.telephone
        };
      }
    },

    getParams() {
      let params = {};
      switch (this.accountType) {
        case "pe":
          break;
        case "fof":
          params = {
            accountNo: this.contactData.telephone,
            productId: 1
          };
          break;
        case "fm":
          break;
        case "blueV":
          params = {
            cellphone: this.contactData.telephone
          };
          break;
        default:
          break;
      }

      return params;
    },

    // 获取账号详情
    getAccountData(params) {
      let apiMapping = {
        pe: `FlAccount/${this.accountId}`,
        fof: "accounts/getAccount",
        blueV: "getBlueVipInfo",
        fm: `FmAccount/${this.accountId}`
      };

      this.modalLoading = true;

      if (this.accountType != "pe") {
        this.$http
          .get(apiMapping[this.accountType], params)
          .then(res => {
            this.modalLoading = false;
            if (res.code === 20000) {
              this.accountData = res.data;
              this.recommendName = this.recommendName || res.data.bvRefereeName;
            } else {
              this.$Message.error(`请求账号信息失败：${res.msg}`);
            }
          })
          .catch(e => {
            console.error(e);
            this.modalLoading = false;
            this.$Message.error("网络请求错误！");
          });
      } else {
        axios
          .all([
            this.$http.get(apiMapping[this.accountType], params),
            this.$http.get("FundLink/getCompanyChat", {
              companyId: this.contactData.company_id
            })
          ])
          .then(
            axios.spread((accountData, chatData) => {
              this.modalLoading = false;
              if (accountData.code === 20000) {
                this.accountData = accountData.data;
                this.recommendName =
                  this.recommendName || accountData.data.bvRefereeName;
              } else {
                this.$Message.error(`请求账号信息失败：${res.msg}`);
              }

              if (chatData.code === 20000) {
                this.ifChatDisable = chatData.data.disable || "0";
              } else {
                this.$Message.error(`请求账号信息失败：${chatData.msg}`);
              }
            })
          )
          .catch(e => {
            console.error(e);
            this.modalLoading = false;
            this.$Message.error("网络请求错误！");
          });
      }
    }
  }
};
</script>

<style lang="less" scoped>
</style>

