<template>
  <div>
    <Form ref="form" :model="formData" :rules="ruleValidate" :label-width="80">
      <Row>
        <i-col span="12">
          <form-item label="账号" prop>
            <span>{{formData.accountNo||"--"}}</span>
          </form-item>
        </i-col>

        <i-col span="12">
          <form-item label="初始密码" prop="initPsw" v-if="isAdd">
            <i-input v-model="formData.initPsw" :placeholder="passwordPlaceholder" disabled></i-input>
          </form-item>
        </i-col>

        <i-col span="12" v-if="accountType != 'blueV'">
          <form-item label="账号状态" prop="userStatus">
            <i-select v-model="formData.userStatus" placeholder="请选择账号状态" transfer>
              <i-option
                v-for="item in accountStatusOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="12">
          <form-item label="是否付费" prop="payingFlag">
            <i-select v-model="formData.payingFlag" placeholder="请选择是否付费" transfer>
              <i-option
                v-for="item in payFlagOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="12">
          <form-item
            label="开始日期"
            prop="beginDate"
            v-if="accountType != 'pe'"
            class="ivu-form-item ivu-form-item-required"
          >
            <date-picker
              v-model="formData.beginDate"
              style="width:100%"
              placeholder="请选择开始日期"
              transfer
            ></date-picker>
          </form-item>
        </i-col>

        <i-col span="12">
          <form-item
            label="结束日期"
            prop="endDate"
            v-if="accountType != 'pe'"
            class="ivu-form-item ivu-form-item-required"
          >
            <date-picker
              v-model="formData.endDate"
              style="width:100%"
              placeholder="请选择结束日期"
              transfer
            ></date-picker>
          </form-item>
        </i-col>

        <i-col span="12">
          <form-item label="推荐人" prop="recommenderId">
            <i-select
              :key="recoKey"
              v-model="formData.recommenderId"
              placeholder="请输入关键词"
              filterable
              remote
              transfer
              :loading="loading"
              :label="recoName"
              :remote-method="remoteMethod"
              clearable
            >
              <i-option
                v-for="item in recommenderList"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="12" v-show="isAdd">
          <form-item label="短信通知" prop="ifNotice">
            <Checkbox v-model="formData.ifNotice" :true-value="1" :false-value="0"></Checkbox>
          </form-item>
        </i-col>

        <i-col span="24">
          <form-item label="备注" prop="remark">
            <i-input
              v-model="formData.remark"
              type="textarea"
              placeholder="请输入备注"
              :autosize="{minRows:4,maxRows:6}"
            ></i-input>
          </form-item>
        </i-col>
      </Row>
    </Form>
  </div>
</template>

<script>
import moment from "moment";

export default {
  props: {
    contactData: {
      default: () => ({}),
      type: Object
    },

    accountData: {
      default: () => ({}),
      type: Object
    },

    isAdd: {
      default: true,
      type: Boolean
    },

    accountType: {
      default: "",
      type: String
    },
    recommendName: {}
  },

  computed: {
    // formData() {
    //   let keys = [
    //     "accountNo",
    //     "userStatus",
    //     "payingFlag",
    //     "beginDate",
    //     "endDate",
    //     "recommenderId",
    //     "remark"
    //   ];
    //   let blueVMapping = {
    //     accountNo: "telephone",
    //     payingFlag: "bvPayment",
    //     beginDate: "blueVipTime",
    //     endDate: "bvExpireTime",
    //     recommenderId: "bvReferee",
    //     remark: "blueVipRemark"
    //   };
    //   let info = JSON.parse(JSON.stringify(this.accountData)) || {};
    //   let data = {};
    //   // 蓝V需要mapping映射
    //   if (this.accountType == "blueV") {
    //     keys.forEach(key => {
    //       if (blueVMapping[key]) {
    //         data[key] = info[blueVMapping[key]];
    //       }
    //     });
    //     data.payingFlag = data.payingFlag - 0;
    //   } else {
    //     keys.forEach(key => {
    //       data[key] = info[key];
    //     });
    //   }
    //   // data.recommendName = this.recommendName;
    //   if (this.isAdd) {
    //     data.ifNotice = 1;
    //     switch (this.accountType) {
    //       case "pe":
    //         data.beginDate = moment().format("YYYY-MM-DD");
    //         data.endDate = moment().add(1, "M");
    //         break;
    //       case "fof":
    //         data.beginDate = moment().format("YYYY-MM-DD");
    //         data.endDate = moment().add(3, "M");
    //         break;
    //       case "fm":
    //         data.beginDate = moment().format("YYYY-MM-DD");
    //         data.endDate = moment().add(1, "Y");
    //         break;
    //       case "blueV":
    //         data.blueVipTime = moment().format("YYYY-MM-DD");
    //         data.bvExpireTime = moment().add(3, "M");
    //         break;
    //       default:
    //         break;
    //     }
    //   } else {
    //     data.ifNotice = 0;
    //   }
    //   data.accountNo = data.accountNo || this.contactData.telephone;
    //   return data;
    // }

    ruleValidate() {
      const validateDate = type => {
        return (rules, value, cb) => {
          let mapping = {
            endDate: "结束日期不能为空！",
            beginDate: "开始日期不能为空！"
          };
          let errors = [];
          if (!this.formData[type]) {
            errors.push(new Error(mapping[type]));
          } else {
            errors = [];
          }

          cb(errors);
        };
      };
      if (this.accountType != "pe") {
        return {
          userStatus: {
            required: true,
            message: "账号状态不能为空"
          },
          beginDate: {
            validator: validateDate("beginDate")
          },
          endDate: {
            validator: validateDate("endDate")
          }
        };
      } else {
        return {
          userStatus: {
            required: true,
            message: "账号状态不能为空"
          }
        };
      }
    }
  },

  watch: {
    "formData.accountNo": {
      handler(val) {
        if (this.isAdd) {
          this.ifHasAccount(val);
        }
      }
    },

    accountData: {
      handler(val) {
        this.show();
      },

      deep: true,
      immediate: true
    },

    "formData.beginDate": {
      handler(val) {
        if (this.$refs.form && this.accountType && this.accountType != "pe") {
          this.$refs.form.validateField("beginDate");
        }
      },

      deep: true,
      immediate: true
    },

    "formData.endDate": {
      handler(val) {
        if (this.$refs.form && this.accountType && this.accountType != "pe") {
          this.$refs.form.validateField("endDate");
        }
      },

      deep: true,
      immediate: true
    }
  },

  data() {
    return {
      recoName: "",
      recoKey: null,
      loading: false,
      recommenderList: [],
      passwordPlaceholder: "初始密码",
      // ruleValidate:
      accountStatusOptions: [
        {
          value: 1,
          label: "正常"
        },
        {
          value: 2,
          label: "禁用"
        },
        {
          value: 3,
          label: "离职"
        },
        {
          value: 4,
          label: "删除"
        }
      ],

      payFlagOptions: [
        {
          value: 1,
          label: "已付费"
        },
        {
          value: 0,
          label: "未付费"
        }
      ],
      formData: {}
    };
  },

  methods: {
    close() {
      this.passwordPlaceholder = "初始密码";

      this.$refs.form.resetFields();
    },

    validate() {
      let status = null;
      this.$refs.form.validate(valid => {
        if (valid) {
          status = Promise.resolve({
            status: true,
            comp: "accountBaseInfo"
          });
        } else {
          status = Promise.reject({
            status: false,
            comp: "accountBaseInfo"
          });
        }
      });

      return status;
    },

    show() {
      let keys = [
        "accountNo",
        "userStatus",
        "payingFlag",
        "beginDate",
        "endDate",
        "recommenderId",
        "remark"
      ];

      let blueVMapping = {
        accountNo: "telephone",
        payingFlag: "bvPayment",
        beginDate: "blueVipTime",
        endDate: "bvExpireTime",
        recommenderId: "bvReferee",
        remark: "blueVipRemark"
      };
      let info = JSON.parse(JSON.stringify(this.accountData)) || {};
      let data = {};

      // 蓝V需要mapping映射
      if (this.accountType == "blueV") {
        keys.forEach(key => {
          if (blueVMapping[key]) {
            data[key] = info[blueVMapping[key]];
          }
        });
        data.payingFlag = data.payingFlag - 0;
        if (data.recommenderId === "0") {
          data.recommenderId = null;
        }
      } else {
        keys.forEach(key => {
          data[key] = info[key];
        });
        if (data.recommenderId == "0") {
          data.recommenderId = null;
        }
      }

      // data.recommendName = this.recommendName;

      if (this.isAdd) {
        data.ifNotice = 1;
        switch (this.accountType) {
          case "pe":
            data.beginDate = moment().format("YYYY-MM-DD");
            data.endDate = moment().add(1, "M");
            break;
          case "fof":
            data.beginDate = moment().format("YYYY-MM-DD");
            data.endDate = moment().add(3, "M");
            break;
          case "fm":
            data.beginDate = moment().format("YYYY-MM-DD");
            data.endDate = moment().add(1, "Y");
            break;
          case "blueV":
            data.beginDate = moment().format("YYYY-MM-DD");
            data.endDate = moment().add(10, "d");
            break;
          default:
            break;
        }
      } else {
        data.ifNotice = 0;
      }

      data.accountNo = data.accountNo || this.contactData.telephone;

      this.formData = JSON.parse(JSON.stringify(data));
      this.recoName = this.recommendName;
    },

    // 推荐人搜索
    remoteMethod(query) {
      if (!query) {
        this.recommenderList = [];
        return;
      } else {
        this.loading = true;
        let params = {
          name: query,
          ifCancelRequest: true
        };

        this.$http
          .get("accounts/getAccountByName", params)
          .then(res => {
            this.loading = false;
            if (res.code === 20000) {
              if (res.data.length) {
                this.recommenderList = res.data.map(item => {
                  return {
                    label: item.linkman,
                    value: item.id
                  };
                });
              } else {
                this.recommenderList = [];
              }
            } else {
              this.recommenderList = [];
              this.$Message.error(`获取推荐人数据失败:${res.msg}`);
            }
          })
          .catch(err => {
            if (err !== "canceled") {
              console.error(err);
              this.loading = false;
              this.recommenderList = [];
              this.$Message.error("获取推荐人数据失败：网络请求错误！");
            }
          });
      }
    },

    // 判断官网是否有注册,并设置初始密码
    ifHasAccount(val) {
      if (!val) {
        return;
      }

      let params = {
        mobile: val
      };
      this.$http.get("FmAccount/status", params).then(res => {
        if (res.code === 20000) {
          if (res.data.accStatus == 1 || res.data.accStatus == 2) {
            this.passwordPlaceholder = "该手机号已绑定官网账号，无需设置密码";
            this.$set(this.formData, "initPsw", "");
          } else {
            this.$set(this.formData, "initPsw", this.randomPassword());
            this.passwordPlaceholder = "初始密码";
          }
        } else {
          this.passwordPlaceholder = "初始密码";
          this.$set(this.formData, "initPsw", this.randomPassword());
        }
      });
    },

    // 随机生成初始密码
    randomPassword() {
      let password = "smppw";
      for (let i = 0; i < 4; i++) {
        password += Math.floor(Math.random() * 10);
      }
      return password;
    },

    getData() {
      let data = JSON.parse(JSON.stringify(this.formData));
      if (data.beginDate) {
        data.beginDate = moment(data.beginDate).format("YYYY-MM-DD");
      }

      if (data.endDate) {
        data.endDate = moment(data.endDate).format("YYYY-MM-DD");
      }
      return Promise.resolve(data);
    }
  }
};
</script>

<style lang="less" scoped>
</style>

