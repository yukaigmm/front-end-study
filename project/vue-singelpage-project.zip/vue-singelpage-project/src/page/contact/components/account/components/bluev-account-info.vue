<template>
  <div>
    <Form :model="formData" ref="form" :rules="validateRules" :label-width="80">
      <Row>
        <i-col span="12">
          <form-item label="账号状态" prop>
            <i-select v-model="formData.blueVipStatus" transfer>
              <i-option
                v-for="item in blueVipStatusOptions"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>
        <i-col span="12">
          <form-item label="蓝V等级" prop="bvLevel">
            <i-select v-model="formData.bvLevel" transfer>
              <i-option
                v-for="item in bvLevelOptions"
                :value="item.value"
                :key="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>
      </Row>
    </Form>
  </div>
</template>

<script>
export default {
  props: {
    accountData: {
      default: () => ({}),
      type: Object
    }
  },

  computed: {
    formData() {
      let keys = ["bvLevel", "blueVipStatus"];
      let data = JSON.parse(JSON.stringify(this.accountData));
      let form = {};
      keys.forEach(key => {
        form[key] = data[key];
      });
      return form;
    }
  },

  data() {
    return {
      validateRules: {
        bvLevel: {
          required: true,
          message: "蓝V等级不能为空"
        },
        blueVipStatus: {
          required: true,
          message: "账号状态不能为空"
        }
      },
      bvLevelOptions: [
        {
          value: "1",
          label: "V1"
        },
        {
          value: "2",
          label: "V2"
        },
        {
          value: "3",
          label: "V3"
        },
        {
          value: "0",
          label: "无"
        }
      ],
      blueVipStatusOptions: [
        {
          value: "0",
          label: "异常"
        },
        {
          value: "1",
          label: "申请 "
        },
        {
          value: "2",
          label: "试用 "
        },
        {
          value: "3",
          label: "正式 "
        },
        {
          value: "4",
          label: "停用"
        }
      ]
    };
  },

  methods: {
    close() {
      this.$refs.form.resetFields();
    },

    validate() {
      let status = null;
      this.$refs.form.validate(valid => {
        if (valid) {
          status = Promise.resolve({
            status: true,
            comp: "blueVInfo"
          });
        } else {
          status = Promise.reject({
            status: false,
            comp: "blueVInfo"
          });
        }
      });

      return status;
    },
    getData() {
      return Promise.resolve(JSON.parse(JSON.stringify(this.formData)));
    }
  }
};
</script>

<style lang="less" scoped>
</style>

