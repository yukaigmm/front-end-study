<template>
  <div>
    <Form :model="formData" ref="form" :rules="validateRules" :label-width="80">
      <Row>
        <!-- <i-col span="12">
          <form-item label="业务类型" prop="businessType">
            <i-select v-model="formData.businessType" transfer clearable>
              <i-option
                v-for="(item ,index ) in businessTypeOptions"
                :key="index"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col> -->
        <i-col span="12">
          <form-item label="用户权限" prop="userPermission">
            <i-select v-model="formData.userPermission" transfer clearable>
              <i-option
                v-for="(item ,index ) in userPermissionOptions"
                :key="index"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>
        <i-col span="12">
          <form-item label="管理员" prop>
            <Checkbox :true-value="1" :false-value="0" v-model="formData.isAdmin">是</Checkbox>
          </form-item>
        </i-col>
      </Row>
    </Form>
  </div>
</template>

<script>
export default {
  props: {
    accountData: {
      default: () => ({}),
      type: Object
    }
  },

  computed: {
    formData() {
      let data = JSON.parse(JSON.stringify(this.accountData));

      let form = {};
      // let keys = ["isAdmin",'businessType','userPermission'];
      let keys = ["isAdmin",'userPermission'];
      keys.forEach(key => {
        form[key] = data[key];
      });
      return form;
    }
  },

  data() {
    return {
      validateRules: {
        // businessType: {
        //   required: true,
        //   message: "业务类型不能为空"
        // },
        userPermission: {
          required: true,
          message: "用户权限不能为空"
        }
      },
      userPermissionOptions: [
        {
          value: 1,
          label: "可读写"
        },
        {
          value: 2,
          label: "只读"
        }
      ],
      businessTypeOptions: [
        {
          label: "私募",
          value: 1
        },
        {
          label: "信托",
          value: 2
        },
        {
          label: "券商",
          value: 3
        },
        {
          label: "期货",
          value: 4
        },
        {
          label: "银行",
          value: 5
        }
      ]
    };
  },

  methods: {
   close(){
     this.$refs.form.resetFields();
   },

    validate() {
      let status = null;
      this.$refs.form.validate(valid => {
        if (valid) {
          status = Promise.resolve({
            status: true,
            comp: "fmInfo"
          });
        } else {
          status = Promise.reject({
            status: false,
            comp: "fmInfo"
          });
        }
      });

      return status;
    },
    getData() {
      return Promise.resolve(JSON.parse(JSON.stringify(this.formData)));
    }
  }
};
</script>

<style lang="less" scoped>
</style>

