<template>
  <div class="detail-wrap">
    <div class="info-wrap">
      <h2 class="title-wrap">{{title}}</h2>
      <div class="info-content">
        <slot name="content"></slot>
      </div>
    </div>

    <div class="action-btn add-all-account">
      <Tooltip v-if="disabled" style="width:100%">
        <div slot="content">
          <div>{{disabledReason}}</div>
          <div v-if="disabledReason=='未配置直营店套餐'" class="set-btn" @click="setFundLink">设置直营店套餐</div>
        </div>
        <Button
          style="width:100%"
          :type="btnType"
          @click="operate"
          :disabled="disabled"
        >{{buttonText}}</Button>
      </Tooltip>
      <Button
        v-else
        style="width:100%"
        :type="btnType"
        @click="operate"
        :disabled="disabled"
      >{{buttonText}}</Button>
    </div>

    <fund-link-config-modal ref="fundLinkConfigModal"  @refreshData="refreshData"/>
  </div>
</template>

<script>
import FundLinkConfigModal from "../../../expired-account/components/fund-link-config.vue";

export default {
  props: {
    title: {
      type: String,
      default: ""
    },
    buttonText: {
      type: String,
      default: "编辑"
    },
    disabled: {
      type: Boolean,
      default: false
    },
    disabledReason: {
      type: String,
      default: ""
    },

    companyId: {
      type: String,
      default: ""
    }
  },

  components: {
    FundLinkConfigModal
  },

  computed: {
    btnType() {
      return this.buttonText === "编辑" ? "primary" : "success";
    }
  },

  methods: {
    operate() {
      this.$emit("operate");
    },

    setFundLink() {
      this.$refs.fundLinkConfigModal.show(this.companyId);
    },

    refreshData(){
      this.$emit("refreshData")
    }
  }
};
</script>

<style lang="less" scoped>
.detail-wrap {
  border: 1px solid #cccccc;
  width: 200px;
  .info-wrap {
    padding: 10px;
    border-bottom: 1px solid #cccccc;
  }
  .title-wrap {
    text-align: center;
    color: #0b5b91;
  }

  .info-content {
    height: 250px;
  }

  .action-btn {
    padding: 10px;
  }
}

.set-btn {
  text-align: center;
  color: #0c7beb;
  cursor: pointer;
}
</style>

