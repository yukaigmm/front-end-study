<template>
  <div>
    <Form ref="form" :model="formData" :rules="validateRules" :label-width="90">
      <Row>
        <i-col span="12">
          <form-item label="申请状态" prop="accountStatus">
            <i-select v-model="formData.accountStatus" transfer>
              <i-option
                v-for="item in accountStatusList"
                :key="item.value"
                :value="item.value"
                :disabled="item.disabled"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>
        <i-col span="12">
          <form-item prop="logo" label="自定义logo">
            <div
              class="cus-logo"
              @click="showCustomizedLogoModal"
              :title="cusLogoSrc?'更换logo':''"
              :style="logoStyle"
            >
              {{cusLogoSrc?"":"请选择logo"}}
              <div
                class="clear-logo-wrap"
                v-show="cusLogoSrc"
                @click.prevent.stop="clearLogo"
                title="清除"
              >×</div>
            </div>
          </form-item>
        </i-col>
        <i-col span="12">
          <form-item label="用户组" prop="groupId">
            <i-select
              v-model="formData.groupId"
              placeholder="请选择用户组"
              :disabled="formData.groupId==1"
              transfer
              clearable
            >
              <i-option
                v-for="item in groupIdList"
                :value="item.value"
                :disabled="item.disabled"
                :key="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>
        <i-col span="12">
          <form-item prop="isHide" label="隐藏数据">
            <Checkbox
              :disabled="!hasRightToHideFund"
              v-model="formData.isHide"
              :true-value="1"
              :false-value="0"
            >是(选中即隐藏基金数据)</Checkbox>
          </form-item>
        </i-col> 
      </Row>
    </Form>

    <customizedLogoModal
      @getBase64Pic="getBase64Pic"
      @getBlobPic="getBlobPic"
      ref="customizedLogoModal"
    />
  </div>
</template>

<script>
import customizedLogoModal from "../../../../account-justify/components/customized-logo.vue";
import { mapGetters } from "vuex";
export default {
  components: {
    customizedLogoModal
  },

  props: {
    accountData: {
      default: () => ({}),
      type: Object
    },

    isAdd: {
      default: true,
      type: Boolean
    }
  },

  computed: {
    formData() {
      let data = JSON.parse(JSON.stringify(this.accountData));
      let form = {};

      let keys = ["accountStatus", "logo", "isHide", "groupId"];
      keys.forEach(key => {
        form[key] = data[key];
      });

      if (this.isAdd) {
        form.isHide = 1;
      }

      return form;
    },

    ...mapGetters({
      userInfo: "getUser"
    }),

    hasRightToHideFund() {
      return this.userInfo.auth.functional.includes("hideFund");
    }
  },

  data() {
    return {
      firstLoad: true,
      cusLogoSrc: "",
      logoStyle: {},
      validateRules: {
        accountStatus: {
          required: true,
          message: "申请状态不能为空"
        },
        groupId: {
          required: true,
          message: "用户组不能为空"
        }
      },
      groupIdList: [
        {
          value: 1,
          label: "组合大师管理员",
          disabled: true
        },
        {
          value: 2,
          label: "VIP会员"
        },
        {
          value: 3,
          label: "普通会员"
        }
      ],
      accountStatusList: [
        {
          value: 0,
          label: "异常",
          disabled: this.isAdd
        },
        {
          value: 1,
          label: "申请"
        },
        {
          value: 2,
          label: "试用"
        },
        {
          value: 3,
          label: "正式"
        },
        {
          value: 4,
          label: "停用",
          disabled: this.isAdd
        }
      ]
    };
  },

  watch: {
    "formData.logo": {
      handler(val) {
        if (val) {
          let url =
            process.env.NODE_ENV === "production"
              ? " http://static.simuwang.com/"
              : "https://static-test-ali.simuwang.com/";
          let picUrl = `Uploads/crm/${val}`;
          this.cusLogoSrc = `${url}${picUrl}`;
          this.getBase64Pic(this.cusLogoSrc);
        } else {
          this.cusLogoSrc = "";
        }
      },

      deep: true
    }
  },

  methods: {
    close() {
      this.logoStyle = {};
      this.$refs.form.resetFields();
      this.cusLogoSrc = "";
    },

    validate() {
      let status = null;
      this.$refs.form.validate(valid => {
        if (valid) {
          status = Promise.resolve({
            status: true,
            comp: "fofInfo"
          });
        } else {
          status = Promise.reject({
            status: false,
            comp: "fofInfo"
          });
        }
      });

      return status;
    },

    showCustomizedLogoModal() {
      this.$refs.customizedLogoModal.show();
    },

    async getData() {
      let logo = "";
      let errFlag = false;
      let data = JSON.parse(JSON.stringify(this.formData));
      if (this.cusLogoBlob) {
        try {
          logo = await this.upLoadCusLogo();
        } catch (err) {
          errFlag = !err;
        }
        if (errFlag) {
          return Promise.reject();
        } else {
          data.logo = logo;
          return Promise.resolve(JSON.parse(JSON.stringify(data)));
        }
      } else {
        return Promise.resolve(JSON.parse(JSON.stringify(data)));
      }
    },

    clearLogo() {
      this.cusLogoSrc = "";
      this.logoStyle = {};
      this.cusLogoBlob = "";
      this.formData.logo = "";
    },

    getBase64Pic(pic) {
      this.cusLogoSrc = pic;
      let style = {
        "background-image": `url(${this.cusLogoSrc})`,
        " background-repeat": "no-repeat",
        "background-size": "100% 100%",
        "-moz-background-size": "100% 100%"
      };
      this.logoStyle = {
        ...style
      };
    },

    getBlobPic(pic) {
      this.cusLogoBlob = pic;
    },

    upLoadCusLogo() {
      let type = this.cusLogoBlob.type.split("/")[1];
      let formData = new FormData();
      formData.append("fileType", "customizedLogo");
      formData.append("file", this.cusLogoBlob, `${Date.now()}.${type}`);

      return new Promise((resolve, reject) => {
        this.$http.post("/common/uploadFile", formData).then(res => {
          if (res.code === 20000) {
            resolve(res.data.filePath);
          } else {
            this.$Message.error(`上传logo失败:${res.data.errorMsg}`);
            reject(false);
          }
        });
      });
    }
  }
};
</script>

<style lang="less" scoped>
.cus-logo {
  position: relative;
  width: 167px;
  height: 48px;
  line-height: 35px;
  border: 1px solid #dddee1;
  border-radius: 4px;
  .clear-logo-wrap {
    position: absolute;
    width: 20px;
    height: 20px;
    line-height: 20px;
    text-align: center;
    color: #fff;
    border-radius: 50%;
    top: -10px;
    right: -1000000000000px;
    display: none;
    background: rgba(0, 0, 0, 0.6);
  }
  &:hover {
    border-color: #57a3f3;
    .clear-logo-wrap {
      right: -10px;
      display: block;
    }
  }
  cursor: pointer;
}
</style>
