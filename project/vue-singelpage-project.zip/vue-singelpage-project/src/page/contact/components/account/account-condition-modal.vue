<template>
  <Modal v-model="modal" title="账号开通情况" :mask-closable="false" :width="modalWidth">
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button @click="onCancel">取消</Button>
      <Button @click="onOk" type="primary">确定</Button>
    </div>

    <div class="account-condition-wrap" v-loading="modalLoading" element-loading-text="拼命加载中">
      <account-detail
        title="组合大师"
        :button-text="fofBtnText"
        :disabledReason="fofAndFmDisabledReason"
        class="account-content"
        :disabled="!fofAndFmDisabled"
        @operate="addAccount('fof')"
      >
        <div slot="content">
          <p class="detail-item">
            <span class="label-wrap">开始日期:</span>
            <span class="value-wrap">{{fofAccountCondition.beginDate || '--'}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">结束日期:</span>
            <span class="value-wrap">{{fofAccountCondition.endDate || "--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">是否付费:</span>
            <span class="value-wrap">{{fofAccountCondition.payingFlag||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">推荐人:</span>
            <span class="value-wrap">{{fofAccountCondition.recommendName||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">账号状态:</span>
            <span class="value-wrap">{{fofAccountCondition.accountStatus || "--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">隐藏数据:</span>
            <span class="value-wrap">{{fofAccountCondition.isHide||"--"}}</span>
          </p>
          <div class="detail-item">
            <span class="label-wrap">自定义logo:</span>
            <div class="cus-logo" :style="logoStyle"></div>
          </div>
        </div>
      </account-detail>

      <account-detail
        v-if="ifShowFmCondition"
        title="基金大师"
        :disabledReason="fofAndFmDisabledReason"
        :button-text="fmBtnText"
        :disabled="!fofAndFmDisabled"
        class="account-content"
        @operate="addAccount('fm')"
      >
        <div slot="content">
          <p class="detail-item">
            <span class="label-wrap">开始日期:</span>
            <span class="value-wrap">{{fmAccountCondition.beginDate|| "--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">结束日期:</span>
            <span class="value-wrap">{{fmAccountCondition.endDate||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">是否付费:</span>
            <span class="value-wrap">{{fmAccountCondition.payingFlag||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">推荐人:</span>
            <span class="value-wrap">{{fmAccountCondition.recommendName||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">管理员:</span>
            <span class="value-wrap">{{fmAccountCondition.isAdmin||'--'}}</span>
          </p>
        </div>
      </account-detail>

      <account-detail
        title="私募直营店"
        :button-text="peBtnText"
        class="account-content"
        :disabledReason="peDisabledReason"
        :disabled="!peDisabled"
        :company-id="contactData.company_id"
        @operate="addAccount('pe')"
        @refreshData="getAccountCondition"
      >
        <div slot="content">
          <p class="detail-item">
            <span class="label-wrap">开始日期:</span>
            <span class="value-wrap">{{peAccountCondition.beginDate||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">结束日期:</span>
            <span class="value-wrap">{{peAccountCondition.endDate||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">是否付费:</span>
            <span class="value-wrap">{{peAccountCondition.payingFlag||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">推荐人:</span>
            <span class="value-wrap">{{peAccountCondition.recommendName||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">用户等级:</span>
            <span class="value-wrap">{{peAccountCondition.fundLinkLevel || "--"}}</span>
          </p>
        </div>
      </account-detail>

      <account-detail
        title="蓝V"
        :button-text="blueVBtnText"
        :disabled="!blueVDisabled"
        :disabledReason="blueVDisabledReason"
        class="account-content"
        @operate="addAccount('blueV')"
      >
        <div slot="content">
          <p class="detail-item">
            <span class="label-wrap">开始日期:</span>
            <span class="value-wrap">{{blueVAccountCondition.blueVipTime||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">结束日期:</span>
            <span class="value-wrap">{{blueVAccountCondition.bvExpireTime||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">是否付费:</span>
            <span class="value-wrap">{{blueVAccountCondition.bvPayment||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">推荐人:</span>
            <span class="value-wrap">{{blueVAccountCondition.recommendName||"--"}}</span>
          </p>
          <p class="detail-item">
            <span class="label-wrap">蓝V等级:</span>
            <span class="value-wrap">{{blueVAccountCondition.bvLevel||"--"}}</span>
          </p>
        </div>
      </account-detail>
    </div>

    <add-account-modal ref="AddAccountModal" @refresh="getAccountCondition"/>
  </Modal>
</template>

<script>
import AccountDetail from "./account-detail.vue";
import AddAccountModal from "./add-account-modal.vue";
import { mapGetters } from "vuex";
export default {
  components: {
    AccountDetail,
    AddAccountModal
  },

  data() {
    return {
      contactData: {},
      modal: false,
      modalLoading: false,
      accountCondition: {},
      logoStyle: {},
      crmUserId: ""
    };
  },

  computed: {
    ...mapGetters({
      userInfo: "getUser"
    }),

    canAddFmAccount() {
      return this.userInfo.auth.functional.includes("addFmAccount");
    },

    canEditFmAccount() {
      return this.userInfo.auth.functional.includes("editFmAccount");
    },

    ifShowFmCondition() {
      // 如果是已经开通了的根据是否有编辑权限进行显示
      if (this.fmStatus) {
        return this.canEditFmAccount;
      } else {
        // 如果是没有开通的根据是否有新增权限进行显示
        return this.canAddFmAccount;
      }
    },

    // 是否已开通组合大师
    fofStatus() {
      return this.accountCondition.fofUser
        ? -this.accountCondition.fofUser.status
          ? true
          : false
        : false;
    },

    fofAccountCondition() {
      let condition = this.accountCondition.fofUser || {};

      let payingFlagMapping = {
        "1": "已付费",
        "0": "未付费"
      };

      let accountStatusMapping = {
        "0": "异常",
        "1": "申请",
        "2": "试用",
        "3": "正式",
        "4": "停用"
      };

      let isHideMapping = {
        "1": "是",
        "0": "否"
      };

      if (-condition.status) {
        condition.beginDate = condition.beginDate
          ? condition.beginDate.slice(0, 11)
          : "--";
        condition.endDate = condition.endDate
          ? condition.endDate.slice(0, 11)
          : "--";
        condition.payingFlag = payingFlagMapping[condition.payingFlag] || "--";
        condition.accountStatus =
          accountStatusMapping[condition.accountStatus] || "--";
        condition.isHide = isHideMapping[condition.isHide] || "--";

        this.getLogoStyle(condition.logo);
      }

      return condition;
    },

    fofAndFmDisabled() {
      return this.contactData.visiting_card_url && this.contactData.telephone;
    },

    fofAndFmDisabledReason() {
      if (!this.contactData.telephone) {
        return "联系人电话号码缺失";
      } else if (!this.contactData.visiting_card_url) {
        return "联系人名片缺失";
      } else {
        return "";
      }
    },

    fofBtnText() {
      return this.fofStatus ? "编辑" : "开通";
    },

    // 是否已开通基金大师
    fmStatus() {
      return this.accountCondition.masterUser
        ? -this.accountCondition.masterUser.status
          ? true
          : false
        : false;
    },

    fmAccountCondition() {
      let condition = this.accountCondition.masterUser || {};

      let payingFlagMapping = {
        "1": "已付费",
        "0": "未付费"
      };

      let isAdminMapping = {
        "1": "是",
        "0": "否"
      };

      if (-condition.status) {
        condition.beginDate = condition.beginDate
          ? condition.beginDate.slice(0, 11)
          : "--";
        condition.endDate = condition.endDate
          ? condition.endDate.slice(0, 11)
          : "--";

        condition.isAdmin = isAdminMapping[condition.isAdmin];
        condition.payingFlag = payingFlagMapping[condition.payingFlag] || "--";
      }

      return condition;
    },

    fmBtnText() {
      return this.fmStatus ? "编辑" : "开通";
    },

    // 是否已开通私募直连
    peStatus() {
      return this.accountCondition.fundLinkUser
        ? -this.accountCondition.fundLinkUser.status
          ? true
          : false
        : false;
    },

    peDisabled() {
      let fundLinkVersion = this.accountCondition.fundLinkVersion
        ? this.accountCondition.fundLinkVersion.versionType
        : false;
      return (
        this.fmStatus &&
        this.contactData.post &&
        this.contactData.company_id &&
        fundLinkVersion
      );
    },

    peDisabledReason() {
      let fundLinkVersion = this.accountCondition.fundLinkVersion
        ? this.accountCondition.fundLinkVersion.versionType
        : false;

      if (!fundLinkVersion) {
        return "未配置直营店套餐";
      }

      if (!this.fmStatus) {
        return "未开通基金大师账号";
      } else if (!this.contactData.post) {
        return "联系人职位缺失";
      } else if (!this.contactData.telephone) {
        return "联系人电话号码缺失";
      } else if (!this.contactData.company_id) {
        return "公司ID缺失";
      } else {
        return "";
      }
    },

    peAccountCondition() {
      let condition = this.accountCondition.fundLinkUser || {};

      let payingFlagMapping = {
        "1": "已付费",
        "0": "未付费"
      };

      let fundLinkLevelMapping = {
        "1": "试用版",
        "2": "基础版"
      };

      if (-condition.status) {
        condition.beginDate = condition.beginDate
          ? condition.beginDate.slice(0, 11)
          : "--";
        condition.endDate = condition.endDate
          ? condition.endDate.slice(0, 11)
          : "--";

        condition.payingFlag = payingFlagMapping[condition.payingFlag] || "--";
        condition.fundLinkLevel =
          fundLinkLevelMapping[condition.fundLinkLevel] || "--";
      }

      return condition;
    },

    peBtnText() {
      return this.peStatus ? "编辑" : "开通";
    },

    // 是否已开通蓝v
    blueVStatus() {
      return this.accountCondition.blueVipUser
        ? -this.accountCondition.blueVipUser.status
          ? true
          : false
        : false;
    },

    blueVDisabled() {
      // 必须有部门，职务才可开通蓝V,部门需要自己推导
      if (this.contactData.bread && this.contactData.bread.length) {
        if (this.contactData.bread[2]) {
          return this.contactData.post && this.contactData.telephone;
        } else {
          return (
            this.contactData.org_name &&
            this.contactData.post &&
            this.contactData.telephone
          );
        }
      } else {
        return (
          this.contactData.org_name &&
          this.contactData.post &&
          this.contactData.telephone
        );
      }
    },

    blueVDisabledReason() {
      if (!this.contactData.telephone) {
        return "联系人电话号码缺失";
      } else if (!this.contactData.post) {
        return "联系人职位缺失";
      } else if (!this.contactData.org_name) {
        //  部门现在如果没有是默认为总部的，所以不存在缺失，如果后期补上部门字段，则要判断部门缺失的情况
        return "联系人部门缺失";
      } else {
        return "";
      }
    },

    blueVAccountCondition() {
      let condition = this.accountCondition.blueVipUser || {};
      let bvLevelMapping = {
        "1": "V1",
        "2": "V2",
        "3": "V3"
      };

      let bvPaymentMapping = {
        "0": "未付费",
        "1": "已付费"
      };

      if (-condition.status) {
        condition.blueVipTime = condition.beginDate
          ? condition.beginDate.slice(0, 11)
          : "--";
        condition.bvExpireTime = condition.endDate
          ? condition.endDate.slice(0, 11)
          : "--";

        condition.bvPayment = bvPaymentMapping[condition.payingFlag] || "--";

        condition.bvLevel = bvLevelMapping[condition.bvLevel];
      } else {
        condition = {};
      }
      return condition;
    },

    blueVBtnText() {
      return this.blueVStatus ? "编辑" : "开通";
    },

    modalWidth() {
      return this.ifShowFmCondition ? 850 : 680;
    }
  },

  methods: {
    onCancel() {
      this.modal = false;
      this.accountCondition = {};
      this.contactData = {};
      this.logoStyle = {};
      this.crmUserId = {};
    },

    getLogoStyle(path) {
      let url =
        process.env.NODE_ENV === "production"
          ? " http://static.simuwang.com/"
          : "https://static-test-ali.simuwang.com/";
      let picUrl = `Uploads/crm/${path}`;
      this.logoStyle = {
        "background-image": `url(${url}${picUrl})`,
        ...{
          " background-repeat": "no-repeat",
          "background-size": "100% 100%",
          "-moz-background-size": "100% 100%"
        }
      };
    },

    addAccount(type) {
      let mapping = {
        pe: this.peStatus,
        fof: this.fofStatus,
        fm: this.fmStatus,
        blueV: this.blueVStatus
      };
      let idMapping = {
        pe: this.peAccountCondition.id || "",
        fof: this.fofAccountCondition.id || "",
        fm: this.fmAccountCondition.id || "",
        blueV: this.blueVAccountCondition.id || ""
      };

      let recommendNameMapping = {
        pe: this.peAccountCondition.recommendName || "",
        fof: this.fofAccountCondition.recommendName || "",
        fm: this.fmAccountCondition.recommendName || "",
        blueV: this.blueVAccountCondition.recommendName || ""
      };
      this.$refs.AddAccountModal.show(
        this.contactData,
        type,
        !mapping[type],
        idMapping[type],
        recommendNameMapping[type],
        this.crmUserId,
        this.accountCondition.fundLinkVersion
      );
    },

    onOk() {
      this.onCancel();
    },

    getAccountCondition() {
      this.modalLoading = true;
      this.$http
        .get(`contact/user/${this.contactData.id}`)
        .then(res => {
          this.modalLoading = false;
          if (res.code === 20000) {
            this.accountCondition = res.data;
            this.crmUserId = res.data.crmUserId;
          } else {
            this.$Message.error("获取账号信息失败：" + res.msg + "！");
          }
        })
        .catch(err => {
          console.error(err);
          this.modalLoading = false;
          this.$Message.error("获取账号信息失败：网络请求错误！");
        });
    },

    show(contactData = {}) {
      this.contactData = JSON.parse(JSON.stringify(contactData));
      this.modal = true;
      this.getAccountCondition();
    }
  }
};
</script>

<style lang="less" scoped>
.cus-logo {
  margin-left: 10px;
  width: 167px;
  height: 48px;
  line-height: 35px;
  border: 1px solid #dddee1;
  border-radius: 4px;
  cursor: pointer;
  &:hover {
    border-color: #57a3f3;
  }
}

.account-condition-wrap {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  .account-content {
    margin-left: 10px;
  }
}

.detail-item {
  margin: 10px 0;
}

.label-wrap {
  cursor: default;
  font-size: 12px;
  display: inline-block;
  width: 80px;
  text-align: right;
  margin-right: 10px;
}
</style>

