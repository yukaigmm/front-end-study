<template>
    <div>
        <chance-follow-up></chance-follow-up>
    </div>
</template>

<script>
import chanceFollowUp from "../welcome-page/components/chance-follow-up";
import getMinusNumber from "@/mixins/getMinusNumber.js";
import $ from "jquery";
export default {
  components: {
    chanceFollowUp
  },
  mixins: [getMinusNumber],
  data() {
    return {};
  },

  mounted() {
    this.setMaxHeightOfTable();
  },

  methods: {
    setMaxHeightOfTable() {
      let wholeHeight = $(".content-body.ivu-col").height();
      let targetTable = $(this.$el).find(".table-area");
      let maxHeight = wholeHeight - 250;
      let minusNumber = this.getMinusNumberOfFixedTable();
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    }
  }
};
</script>

<style lang="less" scoped>
</style>

