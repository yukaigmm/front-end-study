<template>
	<Modal
		v-model="modal"
		width="700"
    title="添加标签"
    :mask-closable="false"
    @on-cancel="cancel">
	  <div slot="footer">
	  	<Button @click="cancel">取消</Button>
	  	<Button type="primary" @click="ok" :loading="buttonLoading">确定</Button>
	  </div>

	  <Form ref="form" :label-width="80" :model="form" :rules="rules">
      <FormItem prop="name" label="标签名称" class="inline-item">
          <Input type="text" v-model="form.name" style="width: 160px;"></Input>
      </FormItem>
      <FormItem prop="score" label="权重分数" class="inline-item">
          <Input type="text" v-model="form.score" style="width: 160px;"></Input>
      </FormItem>
      <FormItem prop="port_type" label="画像类型" class="inline-item">
        <Select style="width: 160px;" v-model="form.port_type">
					<Option v-for="option in portTypeOptions" :value="option.value" :key="option.value">{{option.label}}</Option>
				</Select>
      </FormItem>
      <FormItem prop="isvalid" label="是否可见" class="inline-item">
        <i-switch v-model="form.isvalid">
	        <span slot="open">是</span>
	        <span slot="close">否</span>
		    </i-switch>
      </FormItem>
      <FormItem prop="style" label="标签样式">
        <div class="style-container">
        	<div class="left">
        		<p class="style-title">颜色：</p>
        		<div class="clear">
        			<div class="color-item">
	        			<span>字体颜色</span>
	        			<color-picker v-model="styleObj.color" :parentCustomStyle="{width: '100%'}" :customStyle="{border: '1px solid #999', width: '100%'}"></color-picker>
	        		</div>
	        		<div class="color-item">
	        			<span>边框颜色</span>
	        			<color-picker v-model="styleObj.borderColor" :parentCustomStyle="{width: '100%'}" :customStyle="{border: '1px solid #999', width: '100%'}"></color-picker>
	        		</div>
	        		<div class="color-item">
	        			<span>背景颜色</span>
	        			<color-picker v-model="styleObj.backgroundColor" :parentCustomStyle="{width: '100%'}" :customStyle="{border: '1px solid #999', width: '100%'}"></color-picker>
	        		</div>
        		</div>
        		<p class="style-title">字号：</p>
        		<Slider class="slider" :max="20" :min="12" :show-input="true" show-tip="never" v-model="styleObj.fontSize"></Slider>
        	</div>
        	<div class="right">
        		<p class="style-title">样例：</p>
        		<Tag class="show" :style="showStyle">{{form.name || '样例文字'}}</Tag>
        	</div>
        </div>
      </FormItem>
      <FormItem prop="description" label="描述" >
        <Input v-model="form.description" type="textarea" :rows="4" placeholder="描述" style="margin-top:20px;"></Input>
      </FormItem>
     </Form>
	</Modal>
</template>

<script>
	import _ from 'lodash';
	import colorPicker from '@/support/color-picker/colorPicker'
	import { Photoshop } from 'vue-color'
	const initForm = {
		name: '',
		score: '',
		port_type: '1',
		isvalid: true,
		description: '',
		style: ''
	}
	export default {
		props: ['tagModal', 'rowData','buttonLoading'],
		components: {
			colorPicker,
			Photoshop
		},
		data () {
			return {
				// buttonLoading:false,
				modal: false,
				form: JSON.parse(JSON.stringify(initForm)),
				styleObj: {
					fontSize: 12,
					backgroundColor: '#fff',
					color: '#000',
					borderColor: '#fff',
					borderStyle: 'solid',
					borderWidth: '1px'
				},
				portTypeOptions: [
					{
						value: '1',
						label: '用户画像'
					},
					{
						value: '2',
						label: '机构画像'
					},
					{
						value: '3',
						label: '客户类型'
					},
					{
						value:'4',
						label:'销售机构画像'
					}
				],
				rules: {
					name: [
						{ required: true, message: '标签名称不能为空', trigger: 'blur, change'}
					],
					score: [
						{ required: true, message: '权重不能为空', trigger: 'blur, change'},
						// { type: 'number', message: '权重须为数字', trigger: 'blur, change'},
					],
					port_type: [
						{ required: true, message: '画像类型不能为空', trigger: 'blur, change'}
					],
				}
			}
		},
		computed: {
			showStyle () {
				return {
					...this.styleObj,
					fontSize: `${this.styleObj.fontSize}px`
				}
			}
		},
		methods: {
			ok () {
				this.$refs.form.validate( (valid) => {
					if(valid) {
						// this.buttonLoading = true;
						this.form.style = JSON.stringify(this.styleObj);
						this.form.isvalid = this.form.isvalid ? 1 : 0;
						this.$emit('closeTagModal', JSON.parse(JSON.stringify(this.form)));
						this.resetForm();
					}else {
						this.$Message.error('请按提示填写相应字段');
					}
				})

			},
			cancel () {
				this.$emit('closeTagModal');
				this.resetForm();
			},
			resetForm () {
				this.$refs.form.resetFields();
				// this.form = JSON.parse(JSON.stringify(initForm));
			}
		},
		watch: {
			tagModal (val) {
				this.modal = val;
			},
			rowData (val) {
				if(typeof val === 'boolean' && !val) {
					//新增操作时的数据传递
					this.form = JSON.parse(JSON.stringify(initForm));
					return ;
				}
				this.form = JSON.parse(JSON.stringify(val));
				this.form.score = val.score + '';
				this.form.port_type = val.port_type + '';
				this.form.isvalid = val.isvalid === 1 ? true : false;
				this.styleObj = JSON.parse(val.style);
			}
		}
	}
</script>

<style lang="less" rel="styleSheet/less" scoped>
	.inline-item {
		display: inline-block;
		width: 300px;
	}
	.style-container {
		height: 150px;
		.style-title {
			font-weight: bold;
		}
		.left {
			float:left;
			// width: 280px;
			height: 100%;
			padding-right: 10px;
			border-right: 1px dashed rgba(0, 0, 0, 0.15);
			.color-item {
				display: inline-block;
				float: left;
				margin: 0 5px;
				width: auto;
				& > span {
					font-size: 13px;
				}
			}
			&:after {
				content: '';
				display: block;
				clear: both;
			}
		}
		.right {
			float: left;
			width: 350px;
			height: 100%;
			padding-left: 10px;
			position: relative;
			.show {
				display: inline-block;
				position: absolute;
				top: 50%;
				left: 50%;
				transform: translate(-50%, -50%);
				padding: 5px;
				height: auto;
				line-height: 1;
				// border-radius: 5px;
			}
		}
	}
	.clear {
		&:after {
			display: block;
			content:'';
			clear: both;
		}
	}

</style>