<template>
  <div class="tag_container">
    <div class="button_container">
      <Button type="primary" @click="add" class="add_button">添加</Button>
    </div>
    <div v-loading="loading">
      <div class="table-container">
         <Table border :data="tableData" :columns="columns"></Table>
      </div>

      <div class="page_container">
        <Page class="page" :total="total" show-elevator show-sizer show-total placement="top" @on-change="onCurrentPageChange" @on-page-size-change="onPageSizeChange">
        </Page>
      </div>
    </div>
    <tag-modal :tagModal="tagModal" :rowData="rowData" :buttonLoading="buttonLoading" @closeTagModal="closeTagModal">
    </tag-modal>
  </div>
</template>
<script>
import _ from "lodash";
import tagModal from "./tag-modal.vue";
import getMinusNumber from "@/mixins/getMinusNumber.js";

import {
  getList,
  delListItem,
  addListItem,
  updateListItem
} from "@/service/getData";
import $ from "jquery";
export default {
  components: {
    tagModal
  },
  mixins: [getMinusNumber],

  data() {
    return {
      buttonLoading: false,
      tagModal: false,
      rowData: {},
      loading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10,
      tableData: [],
      columns: [
        {
          title: "标签名称",
          key: "name"
        },
        {
          title: "权重分数",
          key: "score",
          width: 100
        },
        {
          title: "画像类型",
          key: "port_type",
          width: 100,
          render: (h, { row, column, index }) => {
            let map = {
              1: "用户画像",
              2: "机构画像",
              3: "客户类型",
              4: "销售机构画像"
            };
            return h("span", {}, map[row.port_type]);
          }
        },
        {
          title: "是否可见",
          key: "isvalid",
          width: 100,
          render: (h, { row, column, index }) => {
            return h(
              "Icon",
              {
                props: {
                  type: row.isvalid == 1 ? "checkmark" : "close"
                }
              },
              ""
            );
          }
        },
        {
          title: "标签样式",
          key: "style",
          render: (h, { row, column, index }) => {
            let style = JSON.parse(row.style || JSON.stringify({}));
            // let {fontColor, borderColor, bgColor, fontSize, fontSizeVal} = style;
            // fontColor = fontColor.split(":")[1].replace(';','');
            // borderColor = borderColor.split(":")[1].replace(';','');
            // bgColor = bgColor.split(":")[1].replace(';','');
            // fontSize = fontSize.split(":")[1].replace(';','');
            return h(
              "Tag",
              {
                style: {
                  ...style,
                  fontSize: `${style.fontSize}px`,
                  height: "auto",
                  padding: "5px",
                  lineHeight: 1
                }
              },
              row.name
            );
          }
        },
        {
          title: "描述",
          key: "description"
        },
        {
          title: "操作",
          key: "action",
          width: 120,
          render: (h, { row, column, index }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: this.edit(index)
                  }
                },
                "修改"
              ),
              // h("span", {}, " "),
              row.load_status !== 1
                ? h(
                    "div",
                    {
                      attrs: {
                        class: "deleteBtn"
                      },
                      on: {
                        click: this.del(row.id)
                      }
                    },
                    "删除"
                  )
                : ""
            ]);
          }
        }
      ]
    };
  },
  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 150;
      let minusNumber = this.getMinusNumberOfFixedTable(); 

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },
    onCurrentPageChange(val) {
      this.currentPage = val;
      this.updateTable();
    },
    onPageSizeChange(val) {
      this.currentPage = 1;
      this.pageSize = val;
      this.updateTable();
      this.setMaxHeightOfFixedTable(
        ".content-body.ivu-col",
        [".button_container", ".page_container"],
        ".table-container"
      );
    },
    updateTable() {
      this.loading = true;
      let searchParams = {
        rows: this.pageSize,
        page: this.currentPage
      };
      getList("/sys-portrait/", searchParams).then(resp => {
        if (resp.code == 20000) {
          this.loading = false;
          this.tableData = resp.data.data;
          this.total = resp.data.total;
        }
      });
    },
    add() {
      this.tagModal = true;
    },
    edit(index) {
      return () => {
        this.tagModal = true;
        this.rowData = this.tableData[index];
      };
    },
    del(rowId) {
      return () => {
        this.$Modal.confirm({
          title: "确认",
          content: "确认删除该标签吗？",
          loading: true,
          onOk: () => {
            this.loading = true;
            delListItem("/sys-portrait", rowId).then(resp => {
              if (resp.code == 20000) {
                this.$Message.success("删除成功");
                this.$http.get("common/rebuildPortraitCache").then(res => {
                  if (res.code === 20000) {
                    this.$http.get("/common/getSelectAll").then(resp => {
                      this.$store.dispatch("addEmums", resp.data.data);
                      localStorage.removeItem("emnums");
                      localStorage.setItem("emnums",JSON.stringify(resp.data.data))
                    });
                  }
                });
                this.updateTable();
                this.$Modal.remove();
              }
            });
          },
          onCancel: () => false
        });
      };
    },
    closeTagModal(data) {
      this.tagModal = false;
      this.rowData = false;
      if (data) {
        this.buttonLoading = true;
        this.loading = true;
        if (data.id) {
          //编辑
          updateListItem("/sys-portrait/", data).then(resp => {
            if (resp.code == 20000) {
              this.buttonLoading = false;
              this.$Message.success("修改成功");
              this.updateTable();
            } else {
              this.buttonLoading = false;
              this.loading = false;
            }
          });
        } else {
          //新增
          addListItem("/sys-portrait/", data).then(resp => {
            if (resp.code == 20000) {
              this.$Message.success("新增成功");
              this.buttonLoading = false;
              this.updateTable();
            } else {
              this.buttonLoading = false;
              this.loading = false;
            }
          });
        }
      }
    }
  },
  mounted() {
    this.updateTable();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".button_container", ".page_container"],
      ".table-container"
    );
  }
};
</script>
<style lang="less" rel="styleSheet/less" scoped>
.tag_container {
  margin: 10px 0;
  .button_container {
    margin-bottom: 10px;
    .add_button {
      margin-right: 0;
    }
    &:after {
      content: "";
      display: block;
      clear: both;
    }
  }
  .page_container {
    &:after {
      content: "";
      display: block;
      clear: both;
    }
    .page {
      margin: 10px;
      float: right;
    }
  }
}
</style>
