<template>
  <Modal v-model="innerModal" title="请选择拜访人" :mask-closable="false" width="300" class="people-modal">
    <Spin fix v-if="loading">
      <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
      <div>加载中...</div>
    </Spin>
    <div v-else>
      <Row type='flex' justify='start'>
        <Col>
        <!--  <Tree :data="treeData" multiple show-checkbox empty-text="暂无数据" ref="tree"></Tree> -->
        <el-tree :data="treeData" show-checkbox node-key="id" ref="tree" :default-checked-keys="selectedPeopleId" :auto-expand-parent="true" :default-expanded-keys="defaultExpandedKeys" :props="defaultProps">
        </el-tree>
        </Col>
      </Row>
    </div>
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>
    <div slot="footer">
      <Button @click="onOK">确认</Button>
      <Button @click="onCancel">取消</Button>
    </div>
  </Modal>
</template>
<script>
import _ from "lodash";
import { fetchGrid } from "@/service/getData"
export default {
  data() {
    return {
      defaultExpandedKeys: [0],
      selectedPeopleId: [],
      loading: false,
      innerModal: false,
      treeData: [],
      defaultProps: {
        children: 'children',
        label: 'title'
      }
    };
  },
  mounted() {
    this.getTreeData();
  },
  methods: {
    // 获取树数据
    getTreeData() {
      return new Promise((resolve, reject) => {
        fetchGrid("dept/getAllTree").then(res => {
          let initTreeData = JSON.parse(JSON.stringify(res.data));
          resolve(initTreeData);
        });
      });
    },
    // 默认展示的数据
    // setChosenPeople(data, ids) {
    //   if (data.children && data.children.length) {
    //     _.forEach(data.children, per => {
    //       if (per.children && per.children.length) {
    //         _.forEach(per.children, c => {
    //           this.setChosenPeople(c, ids);
    //         });
    //       } else {
    //         if (ids.indexOf(per.id) !== -1 && per.type == 2) {
    //           per.checked = true;
    //         }
    //       }
    //     });
    //   } else {
    //     if (ids.indexOf(data.id) !== -1) {
    //       data.checked = true;
    //     }
    //   }
    // },
    // 显示模态框
    setExpandDepartments(data, ids, fatherData) {
      if (data.children && data.children.length) {
        _.forEach(data.children, per => {
          if (per.children && per.children.length) {
            _.forEach(per.children, c => {
              this.setExpandDepartments(c, ids, per);
            });
          } else {
            if (ids.indexOf(per.id) !== -1) {
              if (per.type !== 2) {
                this.defaultExpandedKeys.push(per.id);
              }
              this.defaultExpandedKeys.push(data.id);
            }
          }
        });
      } else {
        if (ids.indexOf(data.id) !== -1) {
          if (data.type !== 2) {
            this.defaultExpandedKeys.push(data.id);
          }
          this.defaultExpandedKeys.push(fatherData.id);
        }
      }
    },
    modalShow(ids) {
      this.loading = true;
      this.getTreeData().then(treeData => {
        this.$nextTick(() => {
          this.setExpandDepartments(treeData[0], ids);
          this.selectedPeopleId =
            ids instanceof Array ? ids : [];
        })
        // this.setChosenPeople(treeData[0], ids);
        this.treeData = treeData;
        this.loading = false;
      });
      this.innerModal = true;
    },
    // 获取选定的部门与人
    getSelectedItems() {
      // 获取选定节点
      let tree = this.$refs.tree.getCheckedNodes();
      // 排除部门节点
      let people = tree.filter(item => {
        return item.type == 2;
      });
      // 获取id和人名
      let chosenPeople = people.map(item => {
        return {
          id: item.id,
          name: item.title
        };
      });
      this.$emit("getInnerPeople", chosenPeople);
    },
    // 确认时的回调
    onOK() {
      this.getSelectedItems();
      this.onCancel();
    },
    // 取消和关闭时的回调
    onCancel() {
      this.defaultExpandedKeys = [0];
      this.innerModal = false;
    }
  }
};

</script>
<style lang="less" scoped>
.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}

@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}

</style>
