<template>
  <div>
    <div class="config-wrap">
      <h2>直营店套餐配置</h2>

      <div class="form-wrap" v-loading="loading" element-loading-text="拼命加载中">
        <Form :model="formData" ref="form" :rules="validateRules" :label-width="300">
          <Row>
            <i-col span="24">
              <form-item label="请先选择套餐">
                <i-select v-model="formData.versionType" @on-change="onPackageChange">
                  <i-option
                    v-for="item in versionOptions"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>

            <i-col span="24">
              <form-item label="每周推荐金V个数" prop="commonVipNum">
                <i-input v-model="formData.commonVipNum" placeholder="请输入"/>
              </form-item>
            </i-col>

            <i-col span="24">
              <form-item label="每天推荐蓝V(V2、V3)个数" prop="blueVipNum">
                <i-input v-model="formData.blueVipNum" placeholder="请输入"/>
              </form-item>
            </i-col>

            <i-col span="24">
              <form-item label="每天推荐普通用户(普通用户和蓝V1)个数" prop="otherNum">
                <i-input v-model="formData.otherNum" placeholder="请输入"/>
              </form-item>
            </i-col>
          </Row>
        </Form>

        <div class="btn-wrap">
          <Button type="primary" @click="submit" :loading="btnLoading">提交</Button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      versionOptions: [
        {
          value: 1,
          label: "私募-试用版"
        },
        {
          value: 2,
          label: "私募-基础版"
        },
        {
          value: 6,
          label: "机构-试用版"
        },
        {
          value: 3,
          label: "机构-基础版"
        },
        {
          value: 4,
          label: "机构-加强版"
        },
        {
          value: 5,
          label: "机构-豪华版"
        }
      ],
      validateRules: {
        blueVipNum: {
          required: true,
          message: "不能为空"
        },
        commonVipNum: {
          required: true,
          message: "不能为空"
        },
        otherNum: {
          required: true,
          message: "不能为空"
        }
      },
      formData: {
        versionType: 1
      },
      initFormData: {},
      loading: false,
      btnLoading: false
    };
  },

  mounted() {
    this.getConfigData({ versionType: this.formData.versionType });
  },

  methods: {
    submit() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.btnLoading = true;
          this.$http
            .post("FundLink/updateFundLinkVersionConfig", this.formData)
            .then(res => {
              this.btnLoading = false;
              if (res.code === 20000) {
                this.getConfigData({ versionType: this.formData.versionType });
                this.$Message.success("配置成功！");
              } else {
                this.$Message.error(`配置失败:${res.msg}`);
              }
            })
            .catch(err => {
              this.btnLoading = false;
              console.log(err);
              this.$Message.error("配置失败：网络请求错误！");
            });
        } else {
          this.$Message.warning("请按红色文字提示填写内容！");
        }
      });
    },

    onPackageChange(val) {
      let params = {
        versionType: val
      };

      let initData = JSON.parse(JSON.stringify(this.initFormData));
      let currentData = JSON.parse(JSON.stringify(this.formData));
      delete initData.versionType;
      delete currentData.versionType;

      // 如果数据未更改，则不需要提示
      if (JSON.stringify(initData) != JSON.stringify(currentData)) {
        this.$Modal.confirm({
          title: "数据未保存",
          content: "当前配置信息未提交，是否继续更换套餐类型？",
          okText: "继续",
          cancelText: "取消",
          onOk: () => {
            this.getConfigData(params);
          },
          onCancel: () => {
            this.formData.versionType = this.initFormData.versionType;
            this.$set(
              this.formData,
              "versionType",
              this.initFormData.versionType
            );
          }
        });
      } else {
        this.getConfigData(params);
      }
    },

    getConfigData(params) {
      this.loading = true;
      this.$http
        .get("FundLink/getVersionConfig", params)
        .then(res => {
          this.loading = false;
          if (res.code === 20000) {
            let keys = ["commonVipNum", "blueVipNum", "otherNum"];

            keys.forEach(key => {
              this.$set(this.formData, key, res.data[key]);
            });
            this.initFormData = JSON.parse(JSON.stringify(this.formData));
          } else {
            this.$Message.error(`获取套餐信息失败:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.$Message.error("获取套餐信息失败：网络请求错误！");
        });
    }
  }
};
</script>

<style lang="less" scoped>
@import "./css/index.less";
</style>
