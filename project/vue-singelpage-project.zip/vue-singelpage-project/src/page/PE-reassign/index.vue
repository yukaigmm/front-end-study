<template>
  <div>
    <div class="PE-reassign-searchOptions keydown-box">
      <search-area @changeSearchParam="changeSearchParam" @onKeydownSearch="search">
        <div slot="default">
          <Row>
            <Col span="8">
            <FormItem label="机构名">
              <Input v-model.trim="basicSearchForm.orgName" placeholder="请输入关键字,如：总部 分部"></Input>
            </FormItem>
            </Col>
            <Col span="8">
            <FormItem label="责任人">
              <Select v-model="basicSearchForm.managerIds" multiple>
                <!-- <Option v-for="option in managerList" :value="option.value" :key="option.value">{{option.label}}</Option> -->
                <OptionGroup v-for="item in managerList" :label="item.label" :key="item.value">
                  <Option v-for="child in item.children" :value="child.value" :key="child.value">{{ child.label }}</Option>
                </OptionGroup>
              </Select>
            </FormItem>
            </Col>
            <Col span="4">
            <Button type="primary" @click="search" style="margin-left:8px;">搜索</Button>
            <Button type="ghost" style="margin-left: -7px" @click="reset">重置</Button>
            </Col>
          </Row>
        </div>
        <div slot="extend">
          <Row>
            <Col span="8">
            <!--  <FormItem label="客户类型">
              <Select v-model="extendSearchForm.custTypeIds" multiple>
                <Option v-for="option in enums.c_port_all_cust" :value="option.value" :key="option.value">
                  <Tag :style="option.style">{{option.name}}</Tag>
                </Option>
              </Select>
            </FormItem> -->
            <FormItem label="机构类型">
              <Row>
                <Col span="11">
                <Select v-model="extendSearchForm.ocId" clearable placeholder="请选择">
                  <Option v-for="item in enums.c_org" :value="item.value" :key="item.value">{{item.name}}</Option>
                </Select>
                </Col>
                <Col span="12" offset="1">
                <Select v-model="extendSearchForm.departId" clearable placeholder="请选择">
                  <Option v-for="item in enums.c_depart" :value="item.value" :key="item.value">{{item.name}}</Option>
                </Select>
                </Col>
              </Row>
            </FormItem>
            </Col>
            <Col span="8">
            <FormItem label="地域">
              <component is="SelectLinkage" v-model="extendSearchForm.area_ids" :config="{
              useForSearch: true,
              cacheKey: 'c_area_all',
              row: 'dialog-form-item-row',}" style="width:100%;">
              </component>
            </FormItem>
            </Col>
          </Row>
          <Row>
            <Col span="8">
            <FormItem label="状态">
              <Select v-model="extendSearchForm.status" :clearable="true">
                <Option v-for="option in statusOptions" :value="option.value" :key="option.value">{{option.label}}</Option>
              </Select>
            </FormItem>
            </Col>
          </Row>
        </div>
      </search-area>
    </div>
    <div class="clear PE-reassign-btn">
      <Button type="primary" class="left" @click="batchAdd">批量分配</Button>
      <Button type="primary" class="left" @click="batchEmpty">批量清空</Button>
    </div>
    <div class="tableContainer">
      <Table ref="table" :data="tableData" :columns="columns" :loading="tableLoading" border @on-selection-change="onTableSelectionChange"></Table>
    </div>
    <div class="clear PE-reassign-page">
      <Page class="right" :total="total" placement="top" :current="pageNo" :page-size="pageSize" @on-change="onPageNoChange" @on-page-size-change="onPageSizeChange" show-elevator show-sizer show-total />
    </div>
    <manager-modal ref="managerModal" @selectManager="selectManager"></manager-modal>
  </div>
</template>
<script>
import searchArea from "../../components/search-area";
import managerModal from "../customers-assign/select-dept-manager-modal";
import $ from "jquery";
import SelectLinkage from "../../components/inputs/select-linkage";
import _ from "lodash";
import { mapGetters } from "vuex";
import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  components: {
    searchArea,
    managerModal,
    SelectLinkage
  },

  mixins:[getMinusNumber],
  data() {
    return {
      statusOptions: [
        {
          value: 0,
          label: "未分配"
        },
        {
          value: 1,
          label: "已分配"
        }
      ],
      useExtendParams: false,
      initBasicSearchForm: {
        orgName: "",
        managerIds: []
      },
      basicSearchForm: {
        orgName: "",
        managerIds: []
      },
      initExtendSearchForm: {
        status: "",
        area_ids: "",
        custTypeIds: []
      },
      extendSearchForm: {
        status: "",
        area_ids: "",
        custTypeIds: []
      },
      pageSize: 10,
      pageNo: 1,
      total: 0,
      managerList: [],
      tableLoading: false,
      tableSelectedRow: [],
      tableData: [],
      columns: [
        {
          type: "selection",
          width: 60,
          key: "selection",
          align: "center"
        },
        {
          title: "机构名",
          key: "orgName",
          width: 340,
          render: (h, params) => {
            let bread = params.row.bread.filter((item, index) => index !== 0);
            return h(
              "span",
              bread.map((item, index) => {
                if (index === bread.length - 1) {
                  return h("span", `${item.title}`);
                } else {
                  return h("span", `${item.title}>`);
                }
              })
            );
          }
        },
        {
          title: "机构类型",
          key: "ocId",
          width: 140,
          render: (h, { row }) => {
            return this.orgTypeMap[row.ocId];
          }
        },
        {
          title: "客户类型",
          key: "custTypeIds",
          width: 140,
          render: (h, params) => {
            if (params.row.custTypeIds && params.row.custTypeIds.length) {
              let cusType = [];
              params.row.custTypeIds.forEach(item => {
                this.enums.c_port_all_cust.forEach(itemCus => {
                  if (item == itemCus.value) {
                    cusType.push({
                      name: itemCus.name,
                      style: itemCus.style
                    });
                  }
                });
              });
              return h(
                "div",
                cusType.map(item => {
                  return h(
                    "Tag",
                    {
                      style: { ...item.style }
                    },
                    `${item.name}`
                  );
                })
              );
            } else {
              return "--";
            }
          }
        },
        {
          title: "城市",
          key: "cityId",
          width: 160,
          render: (h, { row }) => {
            return this.cityMap[row.cityId];
          }
        },
        {
          title: "是否分配",
          key: "status",
          width: 80,
          render: (h, { row }) => {
            return row.status == 1 ? "是" : "否";
          }
        },
        {
          title: "责任人",
          key: "managerIds",
          render: (h, params) => {
            let managerIds =
              params.row.managerIds instanceof Array
                ? params.row.managerIds
                : JSON.parse(params.row.managerIds);
            let allManagers = [];
            let responsorNames = [];
            this.managerList.forEach(item => {
              allManagers = allManagers.concat(item.children);
            });
            managerIds.forEach(idItem => {
              allManagers.forEach(memberItem => {
                if (Number(idItem) == memberItem.value) {
                  responsorNames.push(memberItem.label);
                }
              });
            });
            return responsorNames.length ? responsorNames.join(",") : "无";
          }
          // render: (h, { row }) => {
          //   let managerIds =
          //     row.managerIds instanceof Array
          //       ? row.managerIds
          //       : JSON.parse(row.managerIds);
          //   return h(
          //     "div",
          //     managerIds
          //       .map(id => {
          //         let person =
          //           _.find(this.managerList, person => {
          //             return `${person.value}` == `${id}`;
          //           }) || {};
          //         return person.label || "无";
          //       })
          //       .join(",")
          //   );
          // }
        }
      ]
    };
  },
  watch: {
    "extendSearchForm.custTypeIds": {
      handler(val) {
        setTimeout(() => {
          let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag");
          let selectTag = $(this.$el).find(
            ".ivu-select-selection .ivu-tag span"
          );
          let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
          let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
          let tagStyle = [];
          for (let i = 0; i < tagContianer.length; i++) {
            for (let j = 0; j < selectTag.length; j++) {
              if (
                $(selectTag.get(j))[0].innerText == $(tag.get(i))[0].innerText
              ) {
                $(selectTags.get(j))[0].setAttribute(
                  "style",
                  $(tagContianer.get(i))[0].getAttribute("style")
                );
              }
            }
          }
        }, 10);
      },
      deep: true
    }
  },
  computed: {
    ...mapGetters({
      enums: "getEnums"
    }),
    orgTypeMap() {
      let obj = {};
      this.enums.c_org.forEach(item => {
        obj[item.value] = item.name;
      });
      return obj;
    },
    cityMap() {
      let obj = {};
      this.enums.c_area_deep_2.forEach(item => {
        obj[item.value] = item.name;
      });
      return obj;
    }
  },

  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 140;
      let minusNumber = this.getMinusNumberOfFixedTable(); 

      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    changeSearchParam(val) {
      this.useExtendParams = val;
      this.$nextTick(() => {
        this.setMaxHeightOfFixedTable(
          ".content-body.ivu-col",
          [
            ".PE-reassign-searchOptions",
            ".PE-reassign-btn",
            ".PE-reassign-page"
          ],
          ".tableContainer"
        );
      });
    },
    getManagerList() {
      // this.$http
      //   .get("dept/getUserByDept", {
      //     dept_id: 1, //数据部
      //     type: 1
      //   })
      //   .then(resp => {
      //     if (resp.code === 20000) {
      //       this.managerList = _.map(resp.data, person => person);
      //     }
      //   });
      this.$http
        .get("dept/getAllWithUser", {
          dept_id: "1,15"
        })
        .then(res => {
          if (res.code === 20000) {
            this.managerList = res.data;
          }
        });
    },
    search() {
      this.pageNo = 1;
      this.pageSize = 10;
      this.getData();
    },
    reset() {
      this.basicSearchForm = JSON.parse(
        JSON.stringify(this.initBasicSearchForm)
      );
      this.extendSearchForm = JSON.parse(
        JSON.stringify(this.initExtendSearchForm)
      );
      this.search();
    },
    getData() {
      let basicSearchForm = JSON.parse(JSON.stringify(this.basicSearchForm));
      if (basicSearchForm.orgName) {
        basicSearchForm.orgName = basicSearchForm.orgName.trim().split(/[ ]+/);
      }
      let searchForm = {
        ...basicSearchForm,
        ...(this.useExtendParams ? this.extendSearchForm : {})
      };
      let params = {
        ...searchForm,
        pageSize: this.pageSize,
        pageNo: this.pageNo,
        resourceType: 2
      };
      this.tableLoading = true;
      this.$http.get("custResources", params).then(resp => {
        this.tableLoading = false;
        if (resp.code === 20000) {
          this.tableData = resp.data.records;
          this.total = resp.data.total;
        } else {
          this.tableData = [];
          this.total = 0;
        }
      });
    },
    onPageNoChange(val) {
      this.pageNo = val;
      this.getData();
    },
    onPageSizeChange(val) {
      this.pageNo = 1;
      this.pageSize = val;
      this.getData();
    },
    batchAdd() {
      if (this.tableSelectedRow.length) {
        //1为数据部的部门id， true表示多选
        this.$refs.managerModal.show(1, true, "pe");
      } else {
        this.$Message.warning("请先选择机构");
      }
    },
    batchEmpty() {
      if (this.tableSelectedRow.length) {
        this.$Modal.confirm({
          title: "确认",
          content: "确认清空所选机构的责任人？",
          onOk: () => {
            this.tableLoading = true;
            this.$http
              .post("custManagerRela", {
                orgIds: this.tableSelectedRow.map(row => row.orgId),
                opType: 2
              })
              .then(resp => {
                if (resp.code === 20000) {
                  this.tableSelectedRow = [];
                  this.$Message.success("清空成功");
                  this.getData();
                }
              });
          }
        });
      } else {
        this.$Message.warning("请先选择机构");
      }
    },
    onTableSelectionChange(selection) {
      this.tableSelectedRow = selection;
    },
    selectManager(managerIds) {
      if (this.tableSelectedRow.length && managerIds) {
        //批量分配api
        this.tableLoading = true;
        this.$http
          .post("custManagerRela", {
            memberIds: managerIds,
            orgIds: this.tableSelectedRow.map(row => row.orgId),
            resourceType: 2,
            opType: 1
          })
          .then(resp => {
            this.tableSelectedRow = [];
            this.tableLoading = false;
            if (resp.code === 20000) {
              this.$Message.success("设置成功");
              this.getData();
            }
          });
      }
    }
  },
  mounted() {
    this.getManagerList();
    this.getData();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".PE-reassign-searchOptions", ".PE-reassign-btn", ".PE-reassign-page"],
      ".tableContainer"
    );
  }
};
</script>
<style lang="less" rel="styleSheet/less">
.clear {
  padding: 8px 0;
  .left {
    float: left;
  }
  .right {
    float: right;
  }
  &:after {
    clear: both;
    display: block;
    content: "";
  }
}
</style>
