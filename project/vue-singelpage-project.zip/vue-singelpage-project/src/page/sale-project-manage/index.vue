<template>
  <div id="project-setting">
    <i-form
      ref="formData"
      :model="formData"
      :label-width="80"
      :inline="true"
      @keydown.enter.native.prevent="search"
    >
      <Row>
        <Col span="8">
          <form-item label="项目名称" prop="projectName">
            <i-input v-model="formData.projectName" placeholder="请输入项目名称" style="width:100%"></i-input>
          </form-item>
        </Col>
        <Col span="8">
          <form-item label="销售人员" prop="saleId">
            <Select v-model="formData.saleId" style="width:100%" clearable>
              <Option
                v-for="option in managerList"
                :value="option.value"
                :key="option.value"
              >{{option.label}}</Option>
            </Select>
          </form-item>
        </Col>
        <Col span="8" style="padding-left:20px;">
          <form-item>
            <i-button @click="search" type="primary">搜索</i-button>
            <i-button style="margin-left: 8px" @click="clear">重置</i-button>
          </form-item>
        </Col>

        <Col span="8">
          <FormItem label="拜访情况">
            <!-- <i-switch v-model="formData.visitCondition" size="large">
                    <span slot="open">所有</span>
                    <span slot="close">30天未拜访</span>
            </i-switch>-->
            <Checkbox v-model="formData.visitStatus" :true-value="1" :false-value="0">30天未拜访</Checkbox>
          </FormItem>
        </Col>
      </Row>
    </i-form>
    <div style="overflow: hidden;margin-bottom: 10px">
      <i-button type="primary" @click="unFollowMutiProject">取消关注</i-button>
      <i-button type="primary" @click="followMutiProject">批量关注</i-button>
      <i-button type="primary" :disabled="ifExportDisabeld" @click="exportExcel">导出</i-button>
      <i-button type="primary" @click="add">新增</i-button>
    </div>
    <div>
      <el-table
        :data="listData"
        :key="tableKey"
        :max-height="maxTableHeight"
        v-loading="loading"
        cellClassName="table-cell-class"
        @selection-change="onSelectionChange"
        element-loading-text="拼命加载中..."
        style="width: 100%"
        @sort-change="onSortChange"
        border
      >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column
          prop="projectName"
          label="项目名称"
          align="center"
          fixed
          :show-overflow-tooltip="true"
        ></el-table-column>
        <el-table-column
          prop="saleName"
          label="销售人员"
          align="center"
          fixed
          :show-overflow-tooltip="true"
        ></el-table-column>
        <el-table-column
          prop="completePayedAmountRate"
          width="110"
          label="回款进度"
          align="center"
          fixed
          sortable="custom"
        ></el-table-column>
        <el-table-column
          prop="completeAccountsRate"
          label="账号开通进度"
          width="130"
          align="center"
          fixed
          sortable="custom"
        ></el-table-column>
        <el-table-column
          prop="completeActivationRate"
          label="账号激活进度"
          width="130"
          align="center"
          fixed
          sortable="custom"
        ></el-table-column>
        <el-table-column
          prop="completeActiveRate"
          label="账号活跃进度"
          width="130"
          align="center"
          fixed
          sortable="custom"
        ></el-table-column>
        <el-table-column
          prop="lastVisitTime"
          label="最近拜访时间"
          width="130"
          align="center"
          fixed
          sortable="custom"
        >
          <template slot-scope="scope">
            <a
              @click="showVisitRecordsModal(scope.row.saleId,scope.row.projectId)"
            >{{scope.row.lastVisitTime}}</a>
          </template>
        </el-table-column>
        <el-table-column label="目标计划" align="center">
          <el-table-column
            prop="targetPayedAmount"
            label="回款总额"
            align="center"
            width="110"
            sortable="custom"
          ></el-table-column>
          <el-table-column
            prop="targetAccount"
            label="账号总数"
            align="center"
            width="110"
            sortable="custom"
          ></el-table-column>
          <el-table-column
            prop="targetActivation"
            label="账号激活数"
            width="130"
            align="center"
            sortable="custom"
          ></el-table-column>
          <el-table-column
            prop="targetActive"
            label="账号活跃数"
            width="130"
            align="center"
            sortable="custom"
          ></el-table-column>
          <el-table-column
            prop="endDate"
            label="完成时间"
            width="130"
            align="center"
            :show-overflow-tooltip="true"
            sortable="custom"
          ></el-table-column>
        </el-table-column>
        <el-table-column label="实际完成" align="center">
          <el-table-column
            prop="payedAmount"
            label="回款总额"
            align="center"
            width="110"
            sortable="custom"
          ></el-table-column>
          <el-table-column
            prop="completeAccounts"
            label="账号总数"
            width="110"
            align="center"
            sortable="custom"
          ></el-table-column>
          <el-table-column
            prop="completeActivation"
            label="账号激活数"
            width="130"
            align="center"
            sortable="custom"
          ></el-table-column>
          <el-table-column
            prop="completeActive"
            label="账号活跃数"
            width="130"
            align="center"
            sortable="custom"
          ></el-table-column>
          <el-table-column
            prop="completeActivationRatio"
            label="账号激活率"
            width="130"
            align="center"
            sortable="custom"
          ></el-table-column>
          <el-table-column
            prop="completeActiveRatio"
            label="账号活跃率"
            width="130"
            align="center"
            sortable="custom"
          ></el-table-column>
        </el-table-column>
        <el-table-column label="操作" fixed="right" align="center" width="200">
          <template slot-scope="scope">
            <span class="deleteBtn" @click="editProject(scope.row.projectId)">编辑</span>
            <span class="deleteBtn" @click="projectDetail(scope.row)">详情</span>
            <span
              class="deleteBtn"
              @click="follwSingleProject(scope.row.projectId,scope.row.isFollow)"
            >{{scope.row.isFollow?"取消关注":"关注"}}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="page-load">
        <Page
          style="float: right"
          :total="total"
          placement="top"
          :current="currentPage"
          :page-size="pageSize"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizeChange"
          show-elevator
          show-sizer
          show-total
        ></Page>
      </div>
    </div>
    <Modal
      class="project-edit-detail-modal"
      v-model="showDialog"
      width="1200"
      :title="dialogTitle"
      :mask-closable="false"
      @on-cancel="onAssignCancel"
    >
      <!-- <project-add ref="group-add"
                       @success="addSuccess"
                       @cancel="showDialog=false"
                       v-if="showDialog"
                       :operate="operate"
      :edit-id="editId"></project-add>-->
      <div slot="close">
        <Icon type="ios-close-empty"></Icon>
      </div>

      <div slot="footer">
        <Button type="default" @click="onAssignCancel">取消</Button>
        <Button
          type="primary"
          @click="onAssignOk"
          :disabled="this.operate==='detail'"
          :loading="btnLoading"
        >确定</Button>
      </div>
      <project-manager
        ref="projectManager"
        ifFirstMount
        :managerList="managerList"
        :projectId="editId"
        :operate="operate"
      ></project-manager>
    </Modal>

    <visit-records-modal ref="visitRecordsModal"></visit-records-modal>
  </div>
</template>

<script>
import _ from "lodash";
import ProjectManager from "./components/project-manager";
import { saleProjectList } from "@/service/getData.js";
import saleProjectManageService from "@/service/sale-project-manage/sale-project-manage-service";
import visitRecordsModal from "./components/visit-record-modal";
import $ from "jquery";
import { mapGetters } from "vuex";
export default {
  name: "project-setting",
  components: {
    ProjectManager,
    visitRecordsModal
  },

  computed: {
    ...mapGetters({
      projectStatus: "getProjectVisitedStatus"
    })
  },

  data() {
    return {
      tableKey: null,
      maxTableHeight: 0,
      sortParams: {},
      btnLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10,
      loading: false,
      formData: {
        projectName: "",
        saleId: "",
        visitStatus: 0
      },
      showDialog: false,
      dialogTitle: "新增项目",
      operate: "",
      editId: "",
      managerList: [],
      listData: [],
      selectedRows: [],
      showByAlysis: false,
      ifExportDisabeld:false 
    };
  },

  watch: {
    projectStatus: {
      handler(val) {
        if (val.saleId) {
          this.$set(this.formData, "saleId", val.saleId);
          this.$set(this.formData, "visitStatus", ~~!val.ifVisited);
          this.showByAlysis = true;
          this.search();
        }
      },
      deep: true,
      immediate: true
    }
  },

  destroyed() {
    this.$store.dispatch("setProjectVisitedStatus", {
      saleId: "",
      ifVisited: ""
    });
    this.showByAlysis = false;
  },

  mounted() {
    this.getManagerList();
    if (!this.showByAlysis) {
      this.projectList();
    }
    this.getMaxTableHeight();
  },
  methods: {
    showVisitRecordsModal(saleId, projectId) {
      this.$refs.visitRecordsModal.show(saleId, projectId);
    },

    getMaxTableHeight() {
      let wholeHeight = $(".content-body.ivu-col").height();
      this.maxTableHeight = wholeHeight - 250;
      this.tableKey = Date.now();
    },

    onSortChange({ column, prop, order }) {
      if (prop) {
        let key = prop.replace(/([A-Z])/g, "_$1").toLowerCase();
        this.sortParams = {
          sortKey: key,
          sortOrder: order === "descending" ? "desc" : "asc"
        };
      } else {
        this.sortParams = {};
      }

      this.projectList();
    },

    onAssignCancel() {
      this.showDialog = false;
      this.operate = "";
      this.btnLoading = false;
      this.editId = "";
      this.$refs.projectManager.clear();
    },

    onAssignOk() {
      this.btnLoading = true;
      this.$refs.projectManager
        .submit()
        .then(() => {
          this.btnLoading = false;
          this.onAssignCancel();
          this.projectList();
        })
        .catch(e => {
          this.btnLoading = false;
        });
    },

    onSelectionChange(selection) {
      this.selectedRows = selection;
    },

    // 关注请求
    followProject(params = {}) {
      this.$http.putWithoutId("salesProject/follow", params).then(res => {
        if (res.code === 20000) {
          this.$Message.success("设置成功！");
          this.projectList();
        } else {
          this.$Message.error(`设置失败:${res.msg}!`);
        }
      });
    },

    //  批量关注
    followMutiProject() {
      let ids = this.selectedRows
        .filter(item => !item.isFollow)
        .map(item => item.projectId);
      if (!ids.length) {
        this.$Message.warning("未选中项目或选中的项目已关注！");
        return;
      }
      let params = {
        projectIds: ids,
        followType: 1
      };
      this.followProject(params);
    },

    // 批量取消关注
    unFollowMutiProject(id) {
      let ids = this.selectedRows
        .filter(item => item.isFollow)
        .map(item => item.projectId);
      if (!ids.length) {
        this.$Message.warning("未选中项目或选中的项目未关注！");
        return;
      }
      let params = {
        projectIds: ids,
        followType: 0
      };
      this.followProject(params);
    },

    // 关注单条数据
    follwSingleProject(id, followStatus) {
      let params = {
        followType: ~~!followStatus,
        projectIds: [id]
      };
      this.followProject(params);
    },

    search() {
      this.pageSize = 10;

      this.currentPage = 1;
      this.projectList();
    },

    clear() {
      this.formData = {
        projectName: "",
        saleId: "",
        visitStatus: 0
      };
      this.projectList();
    },

    projectList(sortParams) {
      this.loading = true;
      const params = {
        ...this.formData,
        ...this.sortParams,
        pageSize: this.pageSize,
        pageNo: this.currentPage
      };
      saleProjectManageService.saleProjectList(params).then(data => {
        this.tableKey = Date.now();
        data.data.records = data.data.records.map(item => {
          if (item.endDate == "0000-00-00") {
            item.endDate = "--";
          }
          if (item.lastVisitTime&&item.lastVisitTime.indexOf("0000-00-00") !== -1) {
            item.lastVisitTime = "--";
          } else {
            item.lastVisitTime = item.lastVisitTime ? item.lastVisitTime.slice(0, 11) : "--";
          }
          let targetPayedAmount =
            Math.round(parseFloat(item.targetPayedAmount || 0) * 100) / 100;
          let payedAmount =
            Math.round(parseFloat(item.payedAmount || 0) * 100) / 100;
          if (targetPayedAmount < 10000) {
            item.targetPayedAmount = targetPayedAmount + "(元)";
          } else {
            item.targetPayedAmount =
              Math.round((targetPayedAmount||0) / 100) / 100 + "(万元)";
          }
          if (payedAmount < 10000) {
            item.payedAmount = (payedAmount||0) + "(元)";
          } else {
            item.payedAmount = Math.round((payedAmount || 0) / 100) / 100 + "(万元)";
          }
          item.completeActivationRatio =
            Math.round(parseFloat(item.completeActivationRatio || 0) * 10000) / 100 +
            "%";
          item.completeActiveRatio =
            Math.round(parseFloat(item.completeActiveRatio || 0) * 10000) / 100 +
            "%";
          item.completePayedAmountRate =
            Math.round(parseFloat(item.completePayedAmountRate || 0) * 10000) / 100 +
            "%";
          item.completeAccountsRate =
            Math.round(parseFloat(item.completeAccountsRate || 0) * 10000) / 100 +
            "%";
          item.completeActivationRate =
            Math.round(parseFloat(item.completeActivationRate||0) * 10000) / 100 +
            "%";
          item.completeActiveRate =
            Math.round(parseFloat(item.completeActiveRate || 0) * 10000) / 100 + "%";
          return item;
        });
        this.loading = false;
        this.listData = (data && data.data && data.data.records) || [];

        for (let value of this.listData) {
          for (let key in value) {
            if (!value[key]) {
              value[key] = value[key] == 0 ? 0 : "--";
            }
          }
        }
        this.total = data.data.total;
      });
    },

    editProject(id) {
      this.editId = id;
      this.operate = "edit";
      this.showDialog = true;
      this.dialogTitle = "编辑项目";
    },

    exportExcel() {
      this.ifExportDisabeld = true;
      const msg = this.$Message.loading({
        content: "导出中，请稍候...",
        duration: 0
      });

      let params = {
        ...this.formData,
        ...this.sortParams
      };

      this.$http.get("salesProject/export", params).then(res => {
        this.ifExportDisabeld = false;
        this.$Message.destroy();
        if (res.code === 20000) {
          this.$Message.success("导出成功！");
          window.open(`${res.data.url}`);
        } else {
          this.$Message.error("导出失败！");
        }
      });
    },

    projectDetail(row) {
      this.editId = row.projectId;
      this.operate = "detail";
      this.showDialog = true;
      this.dialogTitle = `${row.projectName}项目详情`;
    },

    add() {
      this.operate = "add";
      this.showDialog = true;
      this.dialogTitle = "新增项目";
    },

    onPageChange(page) {
      this.currentPage = page;
      this.projectList();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.projectList();
    },

    // 获取销售人员列表
    getManagerList() {
      let params = {
        dept_id: 16,
        type: 1
      };

      this.$http.get("dept/getUserByDept", params).then(resp => {
        if (resp.code === 20000) {
          this.managerList = _.map(resp.data, person => person).filter(
            item => item.status
          );
        }
      });
    }
  }
};
</script>
<style lang="less">
#project-setting {
  .el-table td,
  .el-table th {
    padding: 0px 0;
  }
  .el-table--border,
  .el-table--group {
    border: 1px solid #dddee1;
  }
  .el-table td,
  .el-table th.is-leaf {
    border-bottom: 1px solid #dddee1;
  }
  .el-table--border td,
  .el-table--border th,
  .el-table__body-wrapper
    .el-table--border.is-scrolling-left
    ~ .el-table__fixed {
    border-right: 1px solid #dddee1;
  }
  .el-table--border th,
  .el-table__fixed-right-patch {
    border-bottom: 1px solid #dddee1;
  }

  // modal 样式
}
.project-edit-detail-modal {
  .ivu-modal {
    .ivu-modal-body {
      min-height: 420px;
      max-height: 1000% !important;
    }
  }
}
// @media screen and (max-height: 700px) {
//   .ivu-modal-body{
//     min-height: 420px;
//   }
// }
</style>
<style lang="less" scoped>
// .ivu-form-item {
//   width: initial;
// }
// .ivu-modal-body {
//   max-height: initial;
// }
.table-cell-class {
  border: 1px solid #dddee1;
}
table {
  border-collapse: collapse;
}
.page-load {
  margin-top: 10px;
}
/*table{*/
/*border-collapse:collapse;*/
/*th{*/
/*height: 30px;*/
/*}*/
/*}*/
/*table,tr,th,td {*/
/*border: 1px solid #dddee1;*/
/*}*/
</style>