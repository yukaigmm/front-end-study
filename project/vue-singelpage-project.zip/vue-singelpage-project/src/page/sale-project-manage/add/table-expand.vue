<template>
    <div>
        <el-tree :data="treeData"
                 node-key="orgId"
                 v-loading="loading"
                 element-loading-text="品名加载中..."
                 :props="{children: 'children',label: 'orgName'}">
                    <span class="custom-tree-node" slot-scope="{ node, data }">
                        <span>{{ node.label }}</span>
                        <span>

                        </span>
                    </span>
        </el-tree>
    </div>
</template>

<script>
  export default {
    name: "table-expand",
    props: {
      treeData: Array
    },
    computed:{
      loading(){
        return this.treeData.length>0;
      }
    },
    data(){
      return {

      }
    }
  }
</script>

<style lang="less" scoped>

</style>