<template>
     <Modal
       v-model="modal"
       title="机构分配"
       :mask-closable="false"
       width="400"
       class="outer-people-modal"
     >
         <div slot="footer">
             <Button type="default" @click="onCancel">取消</Button>
             <Button type="primary" @click="onOk" :loading="btnLoading">确定</Button>
         </div>

         <div slot="close" @click="onCancel">
            <Icon type="ios-close-empty"></Icon>
         </div>
         <div class="search-area">
               <span class="label">关键字：</span>
               <Input class="search-input" v-model.trim="keyword" placeholder="请输入关键字" @input="onKeywordChange"/>
         </div>
         <div v-loading="loading" element-loading-text="拼命加载中" class="tree-container">
             <el-tree
               :data="treeData"
               show-checkbox
               node-key="orgId"
               ref="tree"
               check-strictly
               @check-change="currentNodeCheckChange"
               :default-checked-keys="defaultCheckedOrgs"
               :default-expanded-keys="defaultCheckedOrgs"
               :props="{children: 'children',label: 'orgName'}"
             >
               <span class='self-define-tree' slot-scope="{node,data}">
                   <span :class="{'disabled-tree':data.status}">{{node.label}}</span>
                   <span class="disabled-tree" v-if='data.status'>{{data.saleName?"("+data.saleName+")":data.saleName}}</span>               </span>

             </el-tree>
         </div>
     </Modal>
</template>

<script>
import saleProjectManageService from "@/service/sale-project-manage/sale-project-manage-service.js";
let timer = null;
export default {
  data() {
    return {
      defaultCheckedOrgs: [],
      modal: false,
      saleId: "",
      keyword: "",
      loading: false,
      treeData: [],
      btnLoading: false,
      childOrgIds: []
    };
  },

  methods: {
    show(saleId, defaultCheckedOrgs = []) {
      this.defaultCheckedOrgs = defaultCheckedOrgs;
      this.saleId = saleId;
      this.modal = true;
      this.getTreeData();
    },

    hide() {
      this.modal = false;
    },

    onCancel() {
      this.defaultCheckedOrgs = [];
      this.treeData = [];
      this.keyword = "";
      this.saleId = "";
      this.childOrgIds = [];
      this.hide();
    },

    currentNodeCheckChange(data, status) {
      this.childOrgIds = [];
      if (data.children.length) {
        this.getChildNodesId(data);
        this.childOrgIds.forEach(item => {
            this.$refs.tree.setChecked(item,status);
        });
      }
    },

    getChildNodesId(data) {
      if (data.children && data.children.length) {
        for (let i = 0, len = data.children.length; i < len; i++) {
          if(!data.children[i].status){
            this.childOrgIds.push(data.children[i].orgId);
          }
          this.getChildNodesId(data.children[i]);
        }
      } else {
        return;
      }
    },

    onOk() {
      let checkedOrgIds = this.$refs.tree.getCheckedKeys();
      // 获取选中的机构的组织架构
      this.dealWithCheckedTreeData(checkedOrgIds)
        .then(data => {
          this.onCancel();
          this.$emit("assignSuccess", data,checkedOrgIds);
        })
        .catch(e => {
          this.$Message.error(e);
        });
    },

    onKeywordChange() {
      if (timer) {
        clearTimeout(timer);
      }

      timer = setTimeout(() => {
        this.getTreeData();
      }, 600);
    },

    setDisabledTree(data) {
      if (data.length) {
        for (let i = 0, len = data.length; i < len; i++) {
          if (data[i].status) {
            data[i].disabled = true;
          } else {
            data[i].disabled = false;
          }
          if (data[i].children && data[i].children.length) {
            this.setDisabledTree(data[i].children);
          } else {
            continue;
          }
        }
      } else {
        return;
      }
    },

    getTreeData() {
      if(!this.saleId){
        return ;
      }
      let params = {
        saleId: this.saleId,
        orgName: this.keyword.trim().split(/\s+/)
      };
      this.loading = true;
      saleProjectManageService.getOrgDistribute(params).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          this.setDisabledTree(res.data);
          this.treeData = res.data;
        } else {
          this.$Message.error(`获取数据失败：${res.msg}`);
        }
      });
    },

    addFlagToChosenNode(node, idArr = []) {
      if (node.length) {
        for (let i = 0, len = node.length; i < len; i++) {
          if (idArr.includes(node[i].orgId)) {
            node[i].checkedFlag = true;
          } else {
            node[i].checkedFlag = false;
          }

          if (node[i].children && node[i].children.length) {
            this.addFlagToChosenNode(node[i].children, idArr);
          } else {
            continue;
          }
        }
      } else {
        return;
      }
    },

    dealWithCheckedTreeData(checkedOrgIds) {
      let params = {
        projectIds: checkedOrgIds
      };
      this.btnLoading = true;
      return new Promise((resolve, reject) => {
        saleProjectManageService.getAssignedOrgTree(params).then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.addFlagToChosenNode(res.data, checkedOrgIds);
            resolve(res.data);
          } else {
            reject(res.msg);
          }
        });
      });
    }
  }
};
</script>

<style lang="less" scoped>
.search-area {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  .label {
    width: 80px;
    text-align: right;
    padding-right: 10px;
  }
  .search-input {
    flex: 1;
  }
}
.tree-container {
  margin-top: 15px;
  margin-left: 30px;
}

.disabled-tree {
  color: #999;
}
</style>


