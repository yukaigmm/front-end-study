<template>
    <div>
      <div v-loading="loading" element-loading-text="拼命加载中">

        <div class="form-area" >
            <Form 
              ref="form" 
              :rules="formValidateRules" 
              :model="formData"
              :label-width="120">
                 <Row>
                     <Col span="12">
                        <FormItem label="项目名称" prop="projectName" class="ivu-form-item ivu-form-item-required">
                             <Input 
                               :disabled="readOnly"
                               v-model.trim="formData.projectName"
                               placeholder="请输入项目名称"
                               ></Input>
                        </FormItem>
                     </Col>

                     <Col span="12">
                        <FormItem label="销售人员" prop="saleId">
                            <Select 
                              v-model="formData.saleId" 
                              placeholder="请选择销售人员" 
                              @on-change="onSalesManChange" 
                              :disabled="readOnly">
                                <Option
                                  v-for="option in managerList"
                                  :value="option.value"
                                  :key="option.value">
                                        {{option.label}}
                                </Option>
                            </Select>
                        </FormItem>
                     </Col>

                     <Col span="12">
                        <FormItem class="" label="目标回款金额(万元)" prop="targetReturn">
                             <Input 
                               @on-change="onTargetReturnChange"
                              :disabled="readOnly"
                               v-model.number="formData.targetPayedAmount" 
                               placeholder="请输入目标回款总额"/>

                        </FormItem>
                     </Col>

                     <Col span="12">
                        <FormItem label="目标账户总数" prop="targetAccount">
                            <Input 
                               :disabled="readOnly"
                               v-model.number="formData.targetAccount" 
                               placeholder="请输入目标账户总数"/>
                        </FormItem>
                     </Col>

                     <Col span="12">
                        <FormItem label="目标账号激活数" prop="targetActivation">
                            <Input 
                               :disabled="readOnly"
                               v-model.number="formData.targetActivation" 
                               placeholder="请输入目标账号激活数"/>
                        </FormItem>
                     </Col>

                     <Col span="12">
                        <FormItem label="目标账号活跃数" prop="targetActive">
                            <Input 
                               :disabled="readOnly"
                               v-model.number="formData.targetActive" 
                               placeholder="请输入目标账号活跃数"/>
                        </FormItem>
                     </Col>

                     <Col span="12">
                        <FormItem  class="" label="实际回款金额(万元)" prop="payedAmount">
                            <Input 
                               @on-change="onPayedAmountChange"
                               :disabled="readOnly"
                               v-model.number="formData.payedAmount" 
                               placeholder="请输入实际回款金额"/>
                        </FormItem>
                     </Col>

                     <Col span="12">
                        <FormItem label="计划完成时间" prop="endDate">
                            <DatePicker
                               :disabled="readOnly"
                               v-model="formData.endDate"
                               style="width: 100%"
                               placeholder="请选择计划完成时间"
                            >
                            </DatePicker>
                        </FormItem>
                     </Col>
                 </Row>
             </Form>
           </div>

          <div class="assign-btn">
            <Button type="primary" :disabled="readOnly" @click="orgAssign">机构分配</Button>
          </div>
          <div class="authority-tabel">
             <project-organization-edit-table 
                :orgCheckedTreeData="orgCheckedTreeData" 
                :orgTableTotal="orgTableTotal"
                :operate="operate"
                :loading="tableLoading"
                @setOrgIdsAfterDelete="setOrgIdsAfterDelete"
                @getOrgChildren="getOrgChildren"
                @getOrgTableTree="getOrgTableTree"
                @deleteSingleOrg="deleteSingleOrg"
                >
             </project-organization-edit-table>
          </div>
        </div>

       

        <org-assign-modal ref="OrgAssignModal" @assignSuccess="assignSuccess"></org-assign-modal>
    </div>
</template>

<script>
import OrgAssignModal from "./org-assign-modal";
import saleProjectManageService from "@/service/sale-project-manage/sale-project-manage-service.js";
import projectOrganizationEditTable from "./project-organization-edit-table.vue";
import moment from "moment";
let validteProjectNameTimer = null;

export default {
  components: {
    OrgAssignModal,
    projectOrganizationEditTable
  },

  props: ["projectId", "operate", "managerList"],

  data() {
    const validateProjectName = (rules, value, callback) => {
      let errors = [];
      clearTimeout(validteProjectNameTimer);
      if (value) {
        let params = {
          projectName: value,
          projectId: this.projectId
        };
        validteProjectNameTimer = setTimeout(() => {
          this.$http
            .get("salesProject/checkProjectName", params)
            .then(res => {
              if (res.data.isRepeat) {
                errors.push(new Error("项目名重复"));
              }
            })
            .then(() => {
              callback(errors);
            });
        }, 500);
      } else {
        errors.push("项目名称不能为空");
        callback(errors);
      }
    };

    const validateActiveAndActivation = keyword => {
      return (rules, value, callback) => {
        let errors = [];
        if (value) {
          if (value > this.formData.targetAccount) {
            errors.push(`${keyword}不能大于目标账号总数`);
          }
        }
        callback(errors);
      };
    };

    const validatePlanDate = (rules, value, callback) => {
      let errors = [];
      let now = moment().format("YYYY-MM-DD");
      if (value) {
        let chosenDate = moment(value).format("YYYY-MM-DD");
        if (new Date(chosenDate) < new Date(now)) {
          errors.push("计划时间不能小于当前日期");
        }
      }

      callback(errors);
    };

    return {
      formatTargetPayedAmount: "",
      formatPayedAmount: "",
      initSaleId: "",
      initProjectOrgIds: [],
      initOrgCheckedTreeData: [],
      isClear: false,
      ifFirstMount: true,
      formData: {
        projectName: "",
        saleId: "",
        targetPayedAmount: "",
        targetAccount: "",
        targetActivation: "",
        targetActive: "",
        payedAmount: "",
        endDate: "",
        projectOrgIds: []
      },
      orgCheckedTreeData: [],
      formValidateRules: {
        projectName: [
          // { required: true, message: "项目名称不能为空",trigger:'change,blur' },
          { validator: validateProjectName, trigger: "change" }
        ],
        saleId: [{ required: true, message: "销售人员不能为空" }],
        targetActivation: [
          { validator: validateActiveAndActivation("目标账号激活数") }
        ],
        targetActive: [
          { validator: validateActiveAndActivation("目标账号活跃数") }
        ],
        endDate: [{ validator: validatePlanDate }]
      },
      orgTableTotal: 0,
      loading: false,
      tableLoading: false
    };
  },

  mounted() {},

  watch: {
    operate: {
      handler(val) {
        if (val === "edit") {
          this.getProjectDetails();
        } else if (val === "detail") {
          this.getProjectDetails().then(() => {
            this.getOrgTableTree();
          });
        }
      }
    }
  },

  computed: {
    readOnly() {
      return this.operate === "detail" ? true : false;
    }

    // targetReturnLabel() {
    //   return this.formData.targetPayedAmount
    //     ? "目标回款总额(万元)"
    //     : "目标回款总额(元)";
    // },

    // payedAmountLabel() {
    //   return this.formData.payedAmount
    //     ? "实际回款金额(万元)"
    //     : "实际回款金额(元)";
    // }
  },

  methods: {
    onPayedAmountChange(e) {
      let value = e.target.value;
      if (value >= 10000) {
        this.formatPayedAmount = Math.round(value / 100) / 100;
      }
    },

    onTargetReturnChange(e) {
      let value = e.target.value;
      if (value >= 10000) {
        this.formatTargetPayedAmount = Math.round(value / 100) / 100;
      }
    },

    // 变更时间为格林威治时区标准
    setTimeZone(time) {
      let localTime = moment(time).format("YYYY-MM-DD");
      return localTime;
    },

    //  提交数据
    submit() {
      let params = JSON.parse(JSON.stringify(this.formData));
      if (params.targetPayedAmount) {
        params.targetPayedAmount = params.targetPayedAmount * 10000;
      }
      if (params.payedAmount) {
        params.payedAmount = params.payedAmount * 10000;
      }
      if (params.endDate) {
        params.endDate = this.setTimeZone(params.endDate);
      }
      return new Promise((resolve, reject) => {
        this.$refs.form.validate(valid => {
          if (valid) {
            // 目标回款金额低于10000元进行提示
            if (params.targetPayedAmount && params.targetPayedAmount < 10000) {
              this.$Modal.confirm({
                title: "提交",
                content: "当前目标回款金额低于一万元，确定提交吗？",
                onOk: () => {
                  if (this.operate === "add") {
                    this.addProject(resolve, reject, params);
                  } else if (this.operate === "edit") {
                    this.editProject(resolve, reject, params);
                  }
                },
                onCancel:()=>{
                  reject();
                }
              });

            } else {
              if (this.operate === "add") {
                this.addProject(resolve, reject, params);
              } else if (this.operate === "edit") {
                this.editProject(resolve, reject, params);
              }
            }
          } else {
            this.$Message.warning("请按红色字段填写内容！");
            reject();
          }
        });
      });
    },

    //  新增项目
    addProject(resolve, reject, params) {
      this.$http.post("salesProject", params).then(res => {
        if (res.code === 20000) {
          this.$Message.success("添加成功！");
          resolve();
        } else {
          this.$Message.error(`添加失败:${res.msg}!`);
          reject();
        }
      });
    },

    // 编辑项目
    editProject(resolve, reject, params) {
      this.$http
        .putWithoutId(`salesProject/${this.projectId}`, params)
        .then(res => {
          if (res.code === 20000) {
            this.$Message.success("编辑成功！");
            resolve();
          } else {
            this.$Message.error(`编辑失败:${res.msg}!`);
            reject();
          }
        });
    },

    // 清空数据
    clear() {
      this.formData = {
        projectName: "",
        saleId: "",
        targetPayedAmount: "",
        targetAccount: "",
        targetActivation: "",
        targetActive: "",
        payedAmount: "",
        endDate: "",
        projectOrgIds: []
      };

      this.formatTargetPayedAmount = "";
      this.formatPayedAmount = "";
      this.initSaleId = "";
      this.initProjectOrgIds = [];
      this.initOrgCheckedTreeData = [];
      this.orgCheckedTreeData = [];
      this.isClear = true;
      this.$refs.form.resetFields();
    },

    // 分配机构的回调
    assignSuccess(data = [], ids = []) {
      this.orgCheckedTreeData = JSON.parse(JSON.stringify(data));
      this.$set(this.formData, "projectOrgIds", ids);
    },

    // 机构分配
    orgAssign() {
      if (!this.formData.saleId) {
        this.$Message.warning("请先选择销售人员");
        return;
      }
      this.$refs.OrgAssignModal.show(
        this.formData.saleId,
        this.formData.projectOrgIds
      );
    },

    //    销售人员变化时，对应的数据发生改变
    onSalesManChange(val) {
      if (!this.ifFirstMount) {
        if (val !== this.initSaleId) {
          this.orgCheckedTreeData = [];
          this.$set(this.formData, "projectOrgIds", []);
        } else {
          this.orgCheckedTreeData = this.initOrgCheckedTreeData;
          this.$set(this.formData, "projectOrgIds", this.initProjectOrgIds);
        }
      }
      this.ifFirstMount = false;
      if (this.isClear) {
        this.ifFirstMount = true;
        this.isClear = false;
      }
    },

    // 获取销售人员列表
    // getManagerList() {
    //   let params = {
    //     dept_id: 16,
    //     type: 1
    //   };

    //   this.$http.get("dept/getUserByDept", params).then(resp => {
    //     if (resp.code === 20000) {
    //       this.managerList = _.map(resp.data, person => person).filter(item => {
    //         if (item.status !== undefined) return item.status;
    //       });
    //     }
    //   });
    // },

    // 获取详情
    getProjectDetails() {
      return new Promise((resolve, reject) => {
        this.loading = true;
        saleProjectManageService.getDetail(this.projectId).then(res => {
          this.loading = false;
          if (res.code === 20000) {
            if (res.data.startDate === "0000-00-00") {
              res.data.startDate = "";
            }
            if (res.data.endDate === "0000-00-00") {
              res.data.endDate = "";
            }
            for (let key in this.formData) {
              if (Array.isArray(this.formData[key])) {
                res.data[key] && res.data[key].length
                  ? this.$set(this.formData, key, res.data[key])
                  : this.$set(this.formData, key, []);
              } else {
                this.$set(this.formData, key, res.data[key]);
              }
            }
            // 获取项目中分配的机构id
            if (res.data.projectOrgIds && res.data.projectOrgIds.length) {
              this.initProjectOrgIds = res.data.projectOrgIds.map((orgId) => {
                return +orgId;
              })
            }
            if (this.formData.saleId) {
              this.initSaleId = this.formData.saleId;
            }

            if (this.formData.targetPayedAmount) {
              this.formData.targetPayedAmount =
                this.formData.targetPayedAmount / 10000;
            }
            if (this.formData.payedAmount) {
              this.formData.payedAmount = this.formData.payedAmount / 10000;
            }
            if (this.operate !== "detail") {
              this.orgCheckedTreeData = this.setCheckedOrgFlag(
                JSON.parse(JSON.stringify(res.data.projectOrgTree))
              );
              this.initOrgCheckedTreeData = this.setCheckedOrgFlag(
                JSON.parse(JSON.stringify(res.data.projectOrgTree))
              );
            }
            resolve();
          } else {
            this.$Message.error(`获取数据失败:${res.msg}`);
            reject();
          }
        });
      });
    },

    // 获取详情modal里机构分配tableData
    getOrgTableTree(params = {}) {
      const defaultParams = {
        // projectId: this.projectId, //项目ID
        pageSize: 10,
        pageNo: 1
      };
      this.tableLoading = true;
      params = Object.assign({}, defaultParams, params);

      saleProjectManageService
        .getProjectOrg(params, this.projectId)
        .then(res => {
          this.orgCheckedTreeData = this.setCheckedOrgFlag(
            JSON.parse(JSON.stringify(res.data.records))
          );
          this.orgTableTotal = res.data.total;
          this.tableLoading = false;
        });
    },
    // 懒加载时，加载子机构
    getOrgChildren(node, resolve) {
      if (node.data.orgId && this.projectId) {
        // this.tableLoading = true;
        let params = {
          projectId: this.projectId,
          orgId: node.data.orgId
        };
        saleProjectManageService.orgChildren(params).then(res => {
          // this.tableLoading = false;
          let children = this.setCheckedOrgFlag(
            JSON.parse(JSON.stringify(res.data))
          );
          resolve(children);
        });
      }
    },

    // 更新分配的机构
    setOrgIdsAfterDelete(deleteIds) {
      let orgIdArr = this.formData.projectOrgIds || [];
      orgIdArr = orgIdArr.filter(orgId => {
        return !deleteIds.includes(orgId);
      });
      this.formData.projectOrgIds = orgIdArr;
      this.$Message.success("删除成功，点击确定之后保存修改");
    },

    // 详情modal删除单条机构
    deleteSingleOrg(orgId) {
      let params = {
        projectId: this.projectId,
        orgId
      };
      saleProjectManageService.deleteOrgById(params).then(res => {
        if (res.code === 20000) {
          this.$Message.success("删除成功");
        } else {
          this.$Message.error(res.msg);
        }
      });
    },

    // 递归设置已分配的机构标识
    setCheckedOrgFlag(orgTableData) {
      orgTableData.forEach(data => {
        if (this.initProjectOrgIds.includes(data.orgId)) {
          data.checkedFlag = true;
        } else {
          data.checkedFlag = false;
        }

        if (data.children) {
          this.setCheckedOrgFlag(data.children);
        }
      });
      return orgTableData;
    }
  }
};
</script>

<style lang="less" scoped>
.form-area {
  width: 90%;
  margin: 0 auto;
}
.assign-btn {
  margin: 10px;
  text-align: right;
}
</style>

