<template>
   <Modal
      title="拜访记录列表"
      width="1200"
      v-model="modal"
      :mask-closable="false"
   >
      <div slot="close" @click="onCancel">
          <Icon type="ios-close-empty"></Icon>
      </div>

      <div slot="footer">
          <Page 
            :total="total"
            placement="top"
            :current="currentPage"
            :page-size="pageSize"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizeChange"
            show-elevator
            show-sizer
            show-total
          />
      </div>

      <div class="table-area">
          <Table
            ref="table"
            border
            :columns="columns"
            :data="tableData"
            v-loading="tableLoading"
            element-loading-text="拼命加载中"
          />
      </div>

      <share ref="share" class="project-operation-modal"></share>

      <visit-contact-dialog ref="visitContactDialog" showType='visit' @refreshTable="refreshTable" class="project-operation-modal"></visit-contact-dialog>
      


   </Modal>
</template>

<script>
import { mapGetters } from "vuex";
import { getCache } from "@/plugin/cache";
import { delRow } from "@/service/getData";
import share from "../../visit-record-manager/share";
import visitContactDialog from "../../contact-manager/visit-contact-dialog";
import $ from "jquery"
import getMinusNumber from "../../../mixins/getMinusNumber"

export default {
  components: {
    share,
    visitContactDialog
  },

  mixins:[getMinusNumber],

  data() {
    return {
      modal: false,
      total: 0,
      currentPage: 1,
      pageSize: 10,
      tableData: [],
      tableLoading: false,
      saleId: "",
      projectId:''
    };
  },

  computed: {
    ...mapGetters({
      enums: "getEnums",
      userId: "getUserId"
    }),

    columns() {
      return [
        {
          title: "拜访时间",
          key: "visit_time",
          width: 90,
          fixed: "left",
          render(h, params) {
            return h(
              "p",
              params.row.visit_time ? params.row.visit_time : "未设"
            );
          }
        },
        {
          title: "拜访人",
          width: 80,
          key: "update_member_id",
          fixed: "left",
          render(h, params) {
            return h("p", params.row.visit_member_name);
          }
        },
        {
          title: "拜访对象",
          key: "contacts_name",
          width: 80,
          fixed: "left"
        },
        {
          title: "其他接待人",
          key: "other_contacts_name",
          width: 80,
          fixed: "left",
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  maxWidth: "80px",
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  cursor: "pointer"
                },
                attrs: {
                  title:
                    row.other_contacts_name.map(item => item.name).join(",") ||
                    ""
                }
              },
              row.other_contacts_name.map(item => item.name).join(",") || "--"
            );
          }
        },
         {
          title: "需求点",
          width: 150,
          key: "demand_ids",
          render: (h, params) => {
            let demand_ids = params.row.demand_ids
              ? JSON.parse(params.row.demand_ids)
              : [];
            let demandsAll = getCache("c_demand");
            let demands = [];
            for (let i = 0; i < demand_ids.length; i++) {
              for (let j = 0; j < demandsAll.length; j++) {
                if (demandsAll[j].value == demand_ids[i]) {
                  demands.push(demandsAll[j].name);
                }
              }
            }
            if (demands.length == 0) {
              demands.push("未知");
            }
            return h("p", demands ? demands.join(",") : "未知");
          }
        },
        {
          title: "意向",
          width: 100,
          key: "intention_type",
          render: (h, params) => {
            let cDepart = getCache("c_intention", params.row.intention_type);
            return h("p", cDepart);
          }
        },
        {
          title: "机构名称",
          key: "org_name",
          width: 350,
          render: (h, { row }) => {
            if (row.bread && row.bread.length) {
              let breads = JSON.parse(JSON.stringify(row.bread)).splice(1);
              return h(
                "div",
                breads.map((item, index) => {
                  if (index == breads.length - 1) {
                    return h("span", `${item.title}`);
                  } else {
                    return h("span", `${item.title}>`);
                  }
                })
              );
            } else {
              return h("div", row.org_name || "--");
            }
          }
        },
        {
          title: "部门类型",
          key: "depart_id",
          width: 100,
          render: (h, params) => {
            let cDepart = getCache("c_depart", params.row.depart_id);
            return h("p", cDepart);
          }
        },
        {
          title: "拜访类型",
          key: "visit_type",
          width: 80,
          render: (h, { row }) => {
            let visitType = getCache("c_visit_type");
            let map = {};
            visitType.forEach(v => {
              map[v.value] = v.name;
            });
            return h("span", map[row.visit_type]);
          }
        },
       
        {
          title: "预设回访时间",
          key: "order_time",
          width: 100,
          render(h, params) {
            return h(
              "p",
              params.row.order_time ? params.row.order_time : "未设"
            );
          }
        },
        {
          title: "更新时间",
          key: "update_time",
          width: 100,
          render: (h, row) => {
            let date = row.row.update_time;
            return h("span", date.split(" ")[0]);
          }
        },
        {
          title: "操作",
          key: "action",
          align: "left",
          width: 140,
          fixed: "right",
          render: (h, params) => {
            return h(
              "div",
              {
                on: {
                  click: e => {
                    e.stopPropagation();
                    return false;
                  }
                }
              },
              [
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    style: {
                      backgroundColor: "none"
                    },
                    on: {
                      click: () => {
                        this.showEidtModal(params.row);
                      }
                    }
                  },
                  "拜访"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    style: {
                      backgroundColor: "none"
                    },
                    on: {
                      click: () => {
                        this.$refs.share.show(
                          JSON.parse(JSON.stringify(params.row))
                        );
                      }
                    }
                  },
                  "分享"
                ),
                h(
                  "div",
                  {
                    attrs: {
                      class: "deleteBtn"
                    },
                    style: {
                      backgroundColor: "none"
                    },
                    on: {
                      click: () => {
                        this.deleteVisitRow(
                          params.row.update_member_id,
                          params.row.id
                        );
                      }
                    }
                  },
                  "删除"
                )
              ]
            );
          }
        }
      ];
    }
  },

  mounted() {
    this.setMaxHeightOfFixedTable();
  },

  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable() {
      let maxHeight = $("body").height()*0.7 - 100;
      let minusNumber = this.getMinusNumberOfFixedTable();
      let targetTable = $(this.$el).find(".table-area");
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    show(saleId,projectId) {
      this.saleId = saleId;
      this.projectId = projectId;
      this.modal = true;
      this.getTableData();
    },

    onCancel() {
      this.modal = false;
      this.total = 0;
      this.currentPage = 1;
      this.pageSize = 10;
      this.tableData = [];
      this.projectId = "";
      this.saleId = "";
    },

    refreshTable() {
      this.total = 0;
      this.currentPage = 1;
      this.pageSize = 10;
      this.getTableData();
    },

    getTableData() { 
      let params = {
        rows: this.pageSize,
        page: this.currentPage,
        update_member_id: this.saleId,
        project_id:this.projectId,
        order: "visit_time desc,update_time desc"
      };
      this.tableLoading = true;
      try {
        this.$http.get("index/visit", params).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.total = res.data.total;
            this.tableData = res.data.data;
          } else {
            this.$Message.error(`获取列表失败:${res.msg}`);
          }
        });
      } catch (err) {
        this.tableLoading = false;
        this.$Message.error(`获取列表失败:${err}`);
      }
    },

    onPageChange(val) {
      this.currentPage = val;
      this.getTableData();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getTableData();
    },

    //删除当前行拜访记录
    deleteVisitRow(id, contactId) {
      let that = this;
      if (id == this.userId) {
        this.$Modal.confirm({
          title: "删除",
          content: "删除当前拜访记录？",
          okText: "确定",
          cancelText: "取消",
          loading: true,
          onOk: id => {
            delRow("index/visit/", contactId).then(function(response) {
              if (response.code === 20000) {
                that.$Message.info("删除成功");
                that.refreshTable();
              } else {
                that.$Message.error(response.msg);
              }
              that.$Modal.remove();
            });
          }
        });
      } else {
        this.$Modal.remove();
        this.$Message.warning("只能删除自己的拜访信息");
      }
    },

    //   编辑显示模态框
    showEidtModal(row) {
      let params = {
        tabShow: "visit",
        personId: row.contacts_id,
        personName: row.contacts_name,
        orgId: row.org_id
      }
      this.$refs.visitContactDialog.show(params);
    }
  }
};
</script>


<style lang="less" scoped>
</style>

