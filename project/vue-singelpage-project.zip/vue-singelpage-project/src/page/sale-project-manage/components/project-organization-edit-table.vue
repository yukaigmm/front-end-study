<template>
    <div class="org-distribute-table-container" v-loading="loading" element-loading-text="拼命加载中">
        <div class="org-distribute-edit-table" v-if="operate !== 'detail'">
            <div class="org-distribute-edit-table-header">
                <ul class="anthority-table-row">
                    <li class="org-name-header">机构名称</li>
                    <li class="org-type-header">机构类型</li>
                    <li class="org-delete-header">操作</li>
                </ul>
            </div>
            <el-tree 
                :data="orgCheckedTreeData"
                :expand-on-click-node="false"
                accordion
                node-key="id"
                class="org-tree"
				:key="`editTree`"
            >
                <div class="anthority-table-row" slot-scope="{node, data}">
                    <span :class="{'org-name-column':true,'no-checked':data.checkedFlag === false}">{{data.orgName}}</span>
                    <span class="org-type-column">{{orgTypeMap[data.ocId]}}</span>
                    <span class="org-delete-column">
                        <span class="deleteBtn" @click="()=>{confirmDeleteOrg(node,data)}">删除</span>
                    </span>
                </div>
            </el-tree>
        </div>
        <div class="org-distribute-detail-tabel" v-else>
            <el-table 
				border 
				@sort-change="orgTableSort"
				>
                <el-table-column 
                    v-for="(column, index) in detailTableColumns" 
                    :key="index"  
                    :sortable ="column.sortable"
                    :prop="column.prop" 
                    :label="column.label" 
                    :width="column.width"
					:class="column.className"
                ></el-table-column>
                <el-table-column prop="action" label="操作" align="center" width="120"></el-table-column>
            </el-table>
             <el-tree
                accordion
                :lazy="true"
                :data="orgCheckedTreeData"
                :expand-on-click-node="false"
                :props="orgTreeProps"
                :load="detailTableLoad"
                node-key="orgId"
                class="org-tree"
				:key="`detailTree`"
            >
                <div class="anthority-table-row" slot-scope="{node, data}">
                    <span :class="{'org-name-column':true,'no-checked':data.checkedFlag === false}">{{data.orgName}}</span>
                    <span class="complete-contribution-column">{{data.completeContribution ?  `${data.completeContribution*100}%` : "--"}}</span>
                    <span class="complete-accounts-column">{{data.completeAccounts == null ? "--" : data.completeAccounts }}</span>
                    <span class="complete-activation-column">{{data.completeActivation == null ? "--" : data.completeActivation}}</span>
                    <span class="complete-active-column">{{data.completeActive == null ? "--" : data.completeActive}}</span>
                    <span class="last-visit-column">{{formatLastVisitTime(data.lastVisitTime)}}</span>
                    <span class="org-delete-column">
                        <span class="deleteBtn" @click="()=>{confirmDeleteOrg(node,data)}">删除</span>
                    </span>
                </div>
            </el-tree>
        </div>
    </div>


</template>


<script>
import { mapGetters } from 'vuex';
import saleProjectManageService from "@/service/sale-project-manage/sale-project-manage-service.js";
export default {
	props: {
		orgCheckedTreeData: {
			type: Array,
		},
		operate: {
			type: String
		},
		loading: {
			type: Boolean
		}
	},
	data() {
		return {
            detailTableColumns:[
                {
                    label: "机构名称",
                    prop: "org_name",
					sortable: false,
					className:"org-name-header"
                },
                {
                    label: "账号总数贡献度",
                    prop: "complete_contribution",
                    width: 135,
                    sortable: "custom"
                },
                {
                    label: "实际账号总数",
                    prop: "complete_accounts",
                    width: 120,
                    sortable: "custom"
                },
                {
                    label: "实际账号激活数",
                    prop: "complete_activation",
                    width: 135,
                    sortable: "custom"
                },
                {
                    label: "实际账号活跃数",
                    prop: "complete_active",
                    width: 135,
                    sortable: "custom"
                },
                {
                    label: "最近拜访时间",
                    prop: "last_visit_time",
                    width: 120,
                    sortable: "custom"
                },
            ],
			orgTreeProps:{isLeaf:this.setLeaf},
			deleteIds: [],
        };
	},
	
	computed: {
		...mapGetters({
			enums: 'getEnums',
		}),
		
		// 获取机构类型map
		orgTypeMap() {
			let orgTypeMap = {};
			this.enums.c_org.forEach(org => {
				orgTypeMap[org.value] = org.name;
			});
			return orgTypeMap;
		},
	},

	methods: {
		// 提示删除机构
		confirmDeleteOrg(node, data) {
			this.$Modal.confirm({
				title: '确认删除',
				content: this.getDeleteOrgNocite(data),
				onOk: () => {
					this.deleteOrg(node, data);
				},
			});
		},
		
		// 获取删除提示
		getDeleteOrgNocite(data) {
			if (data.children instanceof Array && data.children.length) {
				return `确认删除<strong style="font-size:14px;margin:0 10px">${data.orgName}</strong>及其下属机构吗？`;
			} else {
				return `确认删除<strong style="font-size:14px;margin:0 10px">${data.orgName}</strong>吗？`;
			}
		},
		
		// 删除机构
		deleteOrg(node, data) {
			this.removeTreeNode(node, data);
			if(this.operate == "detail"){
				this.$emit("deleteSingleOrg",data.orgId);
			}else{
				// const children = parent.data.children || parent.data || [];
				// const index = children.findIndex(child => child.orgId === data.orgId);
				// children.splice(index, 1);
				let deleteIds = this.getDeleteIds(data);
				this.$emit('setOrgIdsAfterDelete', JSON.parse(JSON.stringify(deleteIds)));
				this.deleteIds = [];
			}
		},
		// 删除树的节点
		removeTreeNode(node, data){
			const parent = node.parent;
			const children = parent.childNodes;
			const index = children.findIndex(child => child.id === node.id);
			children.splice(index, 1);
			if(children.length === 0){
				parent.isLeaf = true;
				if(parent.data.checkedFlag === false){
					this.removeTreeNode(parent, parent.data);
				}
			}
		},

		
		// 递归获取删除机构的id
		getDeleteIds(data){
			this.deleteIds.push(data.orgId);
			if(data.children){
				data.children.forEach((child) => {
					this.getDeleteIds(child);
				})
			};
			return this.deleteIds;
		},


		// 表格排序
		orgTableSort({column, prop, order}){
			let sortOrderMap = {
				"ascending": "asc",
				"descending": "desc",
				"null": null
			};
			let params = {
				sortOrder: sortOrderMap[order],
				sortKey: prop
			}
			this.$emit("getOrgTableTree", params);
		},


        // 设置表格行是否能展开
        setLeaf(data, node){
			if(data && data.children){
				return !data.children.length;
			}
			return !data.hasChildren;
		},
		
        // 设置表格展开数据结构
        detailTableLoad(node, resolve) {
			this.$emit("getOrgChildren", node, resolve);
		},
		
		// 格式化拜访时间
		formatLastVisitTime(visitTime = ""){
			return ["0000-00-00 00:00:00", null].includes(visitTime)  ? 
			"--" 
			: visitTime.slice(0,10);
		}
	},
	mounted() {},
};
</script>


<style lang="less">
.org-distribute-table-container {
	position: relative;
	// 编辑和新增表格
	.org-distribute-edit-table {
		height: 200px;
		overflow-y: auto;
		overflow-x: hidden;
		// margin-left: calc(~"100vw - 100%");
		// padding-right: 18px;
		// 表头样式
		.org-distribute-edit-table-header {
			// margin-right: 18px;
			width: 1150px;
			position: absolute;
			background-color: #fff;
			z-index: 999;
			// width: calc(~"100% - 18px");
			.anthority-table-row {
				display: flex;
				justify-content: flex-end;
				height: 40px;
				line-height: 40px;
				border: 1px solid #dddee1;
				font-size: 14px;
				font-weight: bold;
				color: #666;
				
				li {
					height: 100%;
				}
				.org-name-header {
					flex: 1;
					padding-left: 46px;
				}
				.org-type-header {
					width: 200px;
					padding-left: 20px;
					border-right: 1px solid #dddee1;
					border-left: 1px solid #dddee1;
				}
				.org-delete-header {
					width: 200px;
					text-align: center;
				}
			}
		}
		// 每一个树结构单元格
		// .el-table__expanded-cell{
		.el-tree {
			padding-top: 40px;
			// margin-right: 18px;
			width: 1150px;
			// width: calc(~"100% - 18px");
			.el-tree-node {
				// padding-left: 16px !important;
				.el-tree-node__content {
					border: 1px solid #dddee1;
					border-top: none;
					height: 40px;
					line-height: 40px;
					// 每一行的icon设置
					.el-tree-node__expand-icon.el-icon-caret-right {
						padding: 8px 16px;
						font-size: 12px;
						color: #666;
						&.is-leaf {
							color: transparent;
						}
						&::before {
							content: '\E604';
						}
					}

					// 每一行样式
					.anthority-table-row {
						width: 100%;
						display: flex;
						justify-content: flex-end;
						.no-checked{
							color: #999;
						}
						span {
							display: inline-block;
							&.org-delete-column {
								width: 200px;
								text-align: center;
								.deleteBtn {
									line-height: 23px;
									cursor: pointer;
								}
							}
							&.org-type-column {
								width: 200px;
								padding-left: 20px;
								border-left: 1px solid #dddee1;
								border-right: 1px solid #dddee1;
							}
							&.org-name-column {
								flex: 1;
								text-align: left;
							}
						}
					}
				}
			}
		}
		// }
	}

	// 详情表格
	.org-distribute-detail-tabel {
		height: 270px;
		overflow-y: auto;
		.el-table {
			border-top: 1px solid #dddee1;
			border-bottom: 1px solid #dddee1;
			border-right: 1px solid #dddee1;
			position: absolute;
			z-index: 999;
			width: 1156px;
			.el-table__body-wrapper {
				display: none;
			}
			.el-table__header-wrapper{
				.el-table__header{
					th{
						border-left: 1px solid #dddee1;
						border-bottom: none;
						padding: 0;
						height: 50px;
						line-height: 50px;
						&:first-child{
							padding-left: 44px;
						}
						.cell{
							padding-right: 0;
						}
					}
				}
			}
		}
		.el-tree.org-tree {
			padding-top: 52px;
			.el-tree-node {
				.el-tree-node__content {
					width: 1156px;
                    .anthority-table-row{
						.no-checked{
							color: #999;
						}
                        span{
                            width: 135px;
                            border-right: 1px solid #dddee1;
                            padding-left: 10px;
                        }
						.complete-accounts-column,.last-visit-column{
							width: 120px
						}
                        .org-name-column{
                            width: auto;
                            flex: 1
                        }
                        .org-delete-column{
                            width: 119px;
                            border: none;
                            text-align: center;
                            .deleteBtn {
                                line-height: 23px;
                                width: auto;
								border: none;
								cursor: pointer;
                            }
                            
                        }
                    }
				}
			}
		}
	}

	// 树结构公共样式
	.el-tree {
		// margin-right: 18px;
		// width: 100%;
		// width: calc(~"100% - 18px");
		.el-tree-node {
			// padding-left: 16px !important;
			.el-tree-node__content {
				border: 1px solid #dddee1;
				border-top: none;
				height: 40px;
				line-height: 40px;
				// 每一行的icon设置
				.el-tree-node__expand-icon.el-icon-caret-right {
					padding: 8px 16px;
					font-size: 12px;
					color: #666;
					&.is-leaf {
						color: transparent;
					}
					&::before {
						content: '\E604';
					}
				}

				// 每一行样式
				.anthority-table-row {
					width: 100%;
					display: flex;
					justify-content: flex-end;
					span {
						display: inline-block;
						cursor: text;
					}
				}
			}
		}
	}
}
</style>
