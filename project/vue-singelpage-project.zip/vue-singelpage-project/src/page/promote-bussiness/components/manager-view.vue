<template>
  <div class="manager-view-container">
    <div class="sells-form-container">
      <i-form
        ref="formData"
        :model="formData"
        :label-width="80"
        :inline="true"
        @keydown.enter.native.prevent="search"
      >
        <Row>
          <Col span="8">
            <form-item label="销售人员" prop="saleId">
              <Select v-model="formData.saleId" @on-change="onSaleChange" clearable>
                <Option
                  v-for="option in managerList"
                  :value="option.value"
                  :key="option.value"
                >{{option.label}}</Option>
              </Select>
            </form-item>
          </Col>

          <Col span="8" :offset="1">
            <form-item :label-width="0">
              <Button
                :type="dateRange ==='thisWeek'?'info':'default'"
                @click="()=>{this.onClickTimeSelectBtn('thisWeek')}"
              >本周</Button>
              <Button
                :type="dateRange ==='lastWeek'?'info':'default'"
                @click="()=>{this.onClickTimeSelectBtn('lastWeek')}"
              >上周</Button>
              <Button
                :type="dateRange ==='thisMonth'?'info':'default'"
                @click="()=>{this.onClickTimeSelectBtn('thisMonth')}"
              >本月</Button>
              <Button
                :type="dateRange ==='lastMonth'?'info':'default'"
                @click="()=>{this.onClickTimeSelectBtn('lastMonth')}"
              >上月</Button>
            </form-item>
          </Col>

          <Col span="7" style="padding-left:15px;">
            <Button type="primary" @click="search">搜索</Button>
            <Button @click="onReset">重置</Button>
          </Col>

          <Col span="8">
            <form-item label="起始时间">
              <DatePicker
                @on-change="onDateChange"
                style="width:100%"
                placeholder="请选择起始时间"
                type="date"
                v-model="formData.startDate"
                :clearable="false"
              />
            </form-item>
          </Col>

          <Col span="8" :offset="1">
            <form-item label="结束时间">
              <DatePicker
                @on-change="onDateChange"
                style="width:100%"
                placeholder="请选择结束时间"
                type="date"
                v-model="formData.endDate"
                :clearable="false"
              />
            </form-item>
          </Col>
        </Row>
      </i-form>
    </div>
    <div class="manager-view-table-container">
      <el-table
        :max-height="maxTableHeight"
        :key="tableKey"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        :data="sellsTableData"
        border
        style="width: 100%"
      >
        <el-table-column
          v-for="column in sellsTableColumns"
          :key="column.prop"
          :prop="column.prop"
          :width="column.width"
          :label="column.label"
          :align="column.align"
        >
          <el-table-column
            v-for="subColumn in column.children"
            :key="subColumn.prop"
            :prop="subColumn.prop"
            :width="subColumn.width"
            :label="subColumn.label"
            :render-header="subColumn.renderHeader"
            :align="subColumn.align"
          >
            <template slot-scope="scope">
              <a
                style="display:inline-block;width:100%;height:100%;"
                @click="()=>{
                                  if(!scope.row[subColumn.prop]){
                                      return ;
                                  }
                                  showDetailModal(scope,subColumn.prop)}"
                v-if="subColumn.slot"
              >{{scope.row[subColumn.prop]}}</a>
              <span v-else>{{scope.row[subColumn.prop]}}</span>
            </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </div>
    <div class="pagination-contaienr">
      <Page
        style="float: right"
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      ></Page>
    </div>
    <div class="modal-container">
      <miss-info-account-modal ref="missInfoAccountModal" @refreshTable="getSellsTableData"></miss-info-account-modal>
      <unvisited-org-modal ref="unvisitedOrgModal"></unvisited-org-modal>
    </div>
  </div>
</template>

<script>
import missInfoAccountModal from "./miss-info-account-modal.vue";
import unvisitedOrgModal from "./unvisited-org-modal.vue";
import moment from "moment";
import $ from "jquery";
import { mapGetters } from "vuex";
export default {
  props: {
    managerList: {
      type: Array
    }
  },
  components: {
    missInfoAccountModal,
    unvisitedOrgModal
  },

  computed: {
    ...mapGetters({
      tabs: "getTabs",
      activeTab: "getActiveTab"
    })
  },

  data() {
    return {
      maxTableHeight: 0,
      tableKey: "",
      ifDateChangeByBtn: false,
      dateRange: "",
      formData: {
        saleId: "",
        startDate: "",
        endDate: ""
      },
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10,
      sellsTableData: [],
      sellsTableColumns: [
        {
          prop: "linkman",
          label: "销售人员",
          width: "120",
          align: "center"
        },
        {
          prop: "show",
          label: "展业情况",
          align: "center",
          children: [
            {
              prop: "saleProject",
              label: "项目数",
              slot: {}
            },
            {
              prop: "notVisitProject",
              label: "未拜访项目数",
              slot: {},
              renderHeader: (h, { column }) => {
                return h(
                  "div",
                  {
                    class: {
                      "cell-with-tooltip": true
                    }
                  },
                  [
                    h("span", "未拜访项目数"),
                    h(
                      "Tooltip",
                      {
                        props: {
                          placement: "top"
                        }
                      },
                      [
                        h("Icon", {
                          props: {
                            type: "help-circled"
                          },
                          style: {
                            cursor: "pointer"
                          }
                        }),
                        h(
                          "div",
                          {
                            slot: "content"
                          },
                          [
                            h(
                              "p",
                              "项目对应的机构中，存在近30天未拜访的机构，则该项目未拜访"
                            )
                          ]
                        )
                      ]
                    )
                  ]
                );
              }
            },
            {
              prop: "visitCount",
              label: "拜访次数",
              slot: {}
            },
            // {
            //   prop: "lastWeekVisit",
            //   label: "上周拜访客户数"
            // },
            // {
            //   prop: "notVisit",
            //   label: "未拜访客户数",
            //   width: 150,
            //   slot: {},
            //   renderHeader: (h, { column }) => {
            //     return h(
            //       "div",
            //       {
            //         class: {
            //           "cell-with-tooltip": true
            //         }
            //       },
            //       [
            //         h("span", "未拜访客户数"),
            //         h(
            //           "Tooltip",
            //           {
            //             props: {
            //               placement: "top"
            //             }
            //           },
            //           [
            //             h("Icon", {
            //               props: {
            //                 type: "help-circled"
            //               },
            //               style: {
            //                 cursor: "pointer"
            //               }
            //             }),
            //             h(
            //               "div",
            //               {
            //                 slot: "content"
            //               },
            //               [h("p", "近30天未拜访的机构")]
            //             )
            //           ]
            //         )
            //       ]
            //     );
            //   }
            // },
            {
              prop: "customers",
              label: "总客户数(总部/分支机构)",
              width: "180"
            },
            {
              prop: "nextWeekVisitCount",
              label: "下周计划拜访次数",
              width: "150",
              slot: {}
            }
          ]
        },
        {
          prop: "accountData",
          label: "账号数据",
          align: "center",
          children: [
            {
              prop: "accountCount",
              label: "总账号数",
              slot: {}
            },
            {
              prop: "activeAccounts",
              label: "活跃账号数",
              renderHeader: (h, { column }) => {
                return h(
                  "div",
                  {
                    class: {
                      "cell-with-tooltip": true
                    }
                  },
                  [
                    h("span", "活跃账号数"),
                    h(
                      "Tooltip",
                      {
                        props: {
                          placement: "top"
                        }
                      },
                      [
                        h("Icon", {
                          props: {
                            type: "help-circled"
                          },
                          style: {
                            cursor: "pointer"
                          }
                        }),
                        h(
                          "div",
                          {
                            slot: "content"
                          },
                          [
                            h("p", "近30天，有大于或"),
                            h("p", "等于3天登录过的账号")
                          ]
                        )
                      ]
                    )
                  ]
                );
              }
            },
            {
              prop: "activeAccountsRate",
              label: "活跃率",
              renderHeader: (h, { column }) => {
                return h(
                  "div",
                  {
                    class: {
                      "cell-with-tooltip": true
                    }
                  },
                  [
                    h("span", "活跃率"),
                    h(
                      "Tooltip",
                      {
                        props: {
                          placement: "top"
                        }
                      },
                      [
                        h("Icon", {
                          props: {
                            type: "help-circled"
                          },
                          style: {
                            cursor: "pointer"
                          }
                        }),
                        h(
                          "div",
                          {
                            slot: "content"
                          },
                          [h("p", "活跃账号和总账号的百分比率")]
                        )
                      ]
                    )
                  ]
                );
              }
            },
            {
              prop: "incompleteAccounts",
              label: "信息不全账号数",
              slot: {},
              renderHeader: (h, { column }) => {
                return h(
                  "div",
                  {
                    class: {
                      "cell-with-tooltip": true
                    }
                  },
                  [
                    h("span", "信息不全账号数"),
                    h(
                      "Tooltip",
                      {
                        props: {
                          placement: "top-end",
                          transfer: true
                        }
                      },
                      [
                        h("Icon", {
                          props: {
                            type: "help-circled"
                          },
                          style: {
                            cursor: "pointer"
                          }
                        }),
                        h(
                          "div",
                          {
                            slot: "content"
                          },
                          [
                            h("p", "名片或电话信息不全，"),
                            h("p", "且未过期的账号")
                          ]
                        )
                      ]
                    )
                  ]
                );
              }
            }
          ]
        }
        // {
        //   prop: "saleProject",
        //   label: "项目数",
        //   width: "120",
        //   align: "center"
        // }
      ]
    };
  },

  created() {
    this.getDefaultDate();
    this.getSellsTableData();
  },

  mounted() {
    this.getMaxTableHeight();
  },

  methods: {
    getMaxTableHeight() {
      let wholeHeight = $(".content-body.ivu-col").height();
      this.maxTableHeight = wholeHeight - 250;
      this.tableKey = Date.now();
    },

    onClickTimeSelectBtn(dateRange) {
      this.dateRange = dateRange;

      let startDate;
      let endDate;
      this.ifDateChangeByBtn = true;
      switch (dateRange) {
        case "thisWeek":
          startDate = moment()
            .day(1)
            .format("YYYY-MM-DD");
          endDate = moment().format("YYYY-MM-DD");
          break;

        case "lastWeek":
          startDate = moment()
            .day(-6)
            .format("YYYY-MM-DD");
          endDate = moment()
            .day(0)
            .format("YYYY-MM-DD");
          break;
        case "thisMonth":
          startDate = moment()
            .date(1)
            .format("YYYY-MM-DD");
          endDate = moment().format("YYYY-MM-DD");
          break;
        case "lastMonth":
          startDate = moment()
            .subtract(1, "months")
            .startOf("month")
            .format("YYYY-MM-DD");
          endDate = moment()
            .subtract(1, "months")
            .endOf("month")
            .format("YYYY-MM-DD");
          break;

        default:
          break;
      }

      this.$set(this.formData, "startDate", startDate);
      this.$set(this.formData, "endDate", endDate);
      this.search();
    },

    onDateChange() {
      if (this.ifDateChangeByBtn) {
        this.ifDateChangeByBtn = !this.ifDateChangeByBtn;
        this.dateRange = "";
      }
    },

    search() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getSellsTableData();
    },

    onReset() {
      this.formData = {
        saleId: "",
        endDate: "",
        startDate: ""
      };
      this.getDefaultDate();
      this.dateRange = "";
      this.search();
    },

    getDefaultDate() {
      let nowDate = moment().format("YYYY-MM-DD");
      let sevenDaysAgo = moment()
        .subtract(7, "days")
        .format("YYYY-MM-DD");
      this.$set(this.formData, "startDate", sevenDaysAgo);
      this.$set(this.formData, "endDate", nowDate);
    },

    getSellsTableData() {
      this.tableLoading = true;
      let params = {
        pageSize: this.pageSize,
        pageNo: this.currentPage,
        deptId: 16,
        userId: this.formData.saleId,
        startDate: moment(this.formData.startDate).format("YYYY-MM-DD"),
        endDate: moment(this.formData.endDate).format("YYYY-MM-DD")
      };

      this.$http.get("statistics/findSaleList", params).then(res => {
        this.tableLoading = false;
        this.tableKey = Date.now();
        if (res.code === 20000) {
          this.total = res.data.total;
          this.sellsTableData = this.dealWithTableData(res.data.records);
        } else {
          this.$Message.error(`获取数据失败:${res.msg}`);
        }
      });
    },

    dealWithTableData(data) {
      return data.map(item => {
        item.customers = `${item.customerRootCount}/${item.customerCount}`;
        item.activeAccountsRate = `${Math.round(
          item.activeAccountsRate * 1000
        ) / 10}%`;
        return item;
      });
    },

    onSaleChange() {
      this.getSellsTableData();
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getSellsTableData();
    },
    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getSellsTableData();
    },

    showDetailModal(scope, key) {
      if (key === "notVisit") {
        this.$refs.unvisitedOrgModal.show(scope.row.userId);
      } else if (key === "incompleteAccounts") {
        this.$refs.missInfoAccountModal.show(scope.row.userId);
      } else if (key === "saleProject") {
        this.$store.dispatch("setProjectVisitedStatus", {
          saleId: scope.row.userId,
          ifVisited: true
        });
        this.jumpToProjectManager();
      } else if (key === "notVisitProject") {
        this.$store.dispatch("setProjectVisitedStatus", {
          saleId: scope.row.userId,
          ifVisited: false
        });
        this.jumpToProjectManager();
      } else if (key === "accountCount") {
        this.$store.dispatch("setAccountStatus", {
          saleId: scope.row.userId,
          managerName: scope.row.linkman
        });
        this.jumpToAccountJusitify();
      } else if (key === "visitCount") {
        this.$store.dispatch("setVisitStatus", {
          saleId: scope.row.userId,
          startDate: this.formData.startDate,
          endDate: this.formData.endDate
        });
        this.jumpToVisitRecords();
      } else if (key === "nextWeekVisitCount") {
        let startDate = moment()
          .week(moment(this.formData.endDate).week() + 1)
          .startOf("week")
          .format("YYYY-MM-DD");
        let endDate = moment()
          .week(moment(this.formData.endDate).week() + 1)
          .endOf("week")
          .format("YYYY-MM-DD");

        this.$store.dispatch("setVisitProjectStatus", {
          saleId: scope.row.userId,
          startDate: startDate,
          endDate: endDate
        });
        this.jumpToVisitProject();
      }
    },

    jumpToProjectManager() {
      let tab = {
        activeName: "项目管理",
        name: "项目管理0",
        component: "projectSetting",
        isShow: true
      };
      this.jump(tab);
    },

    jumpToVisitProject() {
      let tab = {
        activeName: "计划列表",
        name: "计划列表0",
        component: "visitPlanManager",
        isShow: true
      };
      this.jump(tab);
    },

    jump(tab) {
      this.$store.dispatch("setTabs", tab);
      // if (
      //   this.tabs.some(item => {
      //     return item.name === tab.name && item.pid === tab.pid;
      //   })
      // ) {
      //   let newtabs = this.tabs.map(item => {
      //     if (item.name == tab.name) {
      //       item.isShow = true;
      //     }
      //     return item;
      //   });
      //   this.$store.dispatch("setTabsAll", newtabs);
      //   this.$store.dispatch("setActiveTab", { activeTab: tab.name });
      // } else {
      //   this.$store.dispatch("setTabs", tab);
      //   this.$store.dispatch("setActiveTab", { activeTab: tab.name });
      // }
    },

    jumpToAccountJusitify() {
      let tab = {
        activeName: "账号调整",
        name: "账号调整0",
        component: "accountJustify",
        isShow: true
      };
      this.jump(tab);
    },

    jumpToVisitRecords() {
      let tab = {
        activeName: "拜访记录",
        name: "拜访记录0",
        component: "visitRecordManager",
        isShow: true
      };

      this.jump(tab);
    }
  }
};
</script>

<style lang="less">
.manager-view-container {
  .manager-view-table-container {
    .el-table__header-wrapper {
      th {
        overflow: visible;
        padding: 8px 0;
      }
      .cell {
        overflow: visible;
        .cell-with-tooltip {
          overflow: visible;
          padding: 0;
          line-height: normal;
          .ivu-tooltip {
            margin-left: 5px;
            padding: 0;
            width: 14px;
            height: 14px;
            line-height: 14px;
            position: relative;
            overflow: visible;
            .ivu-tooltip-rel {
              width: 100%;
              height: 100%;
              line-height: 14px;
              padding: 0;
            }
            .ivu-tooltip-popper {
              top: 0 !important;
              left: 50% !important;
              transform: translate(-50%, -100%);
              line-height: normal;
              padding: 0;

              div {
                padding: 0;
                line-height: normal;
              }
              .ivu-tooltip-inner {
                padding: 5px 5px;
                min-height: 0;
              }
            }
          }
        }
      }
    }
    .el-table__body {
      .el-table__row {
        td {
          padding: 8px;
          // line-height: 23px;
        }
      }
    }
  }
  .pagination-contaienr {
    padding-top: 10px;
  }
}
</style>


