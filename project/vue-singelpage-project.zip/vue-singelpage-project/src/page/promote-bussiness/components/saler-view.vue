<template>
    <div class="saler-view">
        <Card>
           <h4>尊敬的{{userName}},您好,以下是您的工作情况统计:</h4>


           <div v-loading="loading" element-loading-text="拼命加载中">

               <div class="org-amount ">
                    <div class="amount-area">
                       <h5>项目概览</h5>
                       <p>
                         <span 
                            class="unvisited-wrapper" 
                            title="点击查看详情" 
                            @click="showUnvisitedDetailModal">{{saleData.notVisitProject||0}}</span>
                         /
                         <span>{{saleData.saleProject||0}}</span>
                       </p>
                    </div>
     
                    <div class="tip-area">
                        未拜访项目数(近30天未拜访)&nbsp;&nbsp;<b style="font-size:16px;color:#2d8cf0;">/</b>&nbsp;&nbsp;项目总数
                    </div>
                </div>
                
                <div class="account-amount">
                    <div class="amount-area">
                        <h5>账号概览</h5> 
                        <p>
                           
                            <span>{{saleData.activeAccounts||0}}</span>
                            /
                            <span 
                               class="miss-info-wrapper" 
                               title="点击查看详情" 
                               @click="showMissInfoModal">
                               {{saleData.incompleteAccounts||0}}
                            </span>
                            /
                             <span>{{saleData.accountCount||0}}</span>
                            
                        </p>
                    </div>
                    
                    <div class="tip-area">
                        活跃账号数(近30天登录大于等于3天)&nbsp;&nbsp; 

                        <b style="font-size:16px;color:#2d8cf0;">/</b>&nbsp;&nbsp;

                        信息不全账号数(账号未过期,但名片或电话信息不全)&nbsp;&nbsp;

                        <b style="font-size:16px;color:#2d8cf0;">/</b>&nbsp;&nbsp;

                        账号总数<br/>

                        <span>请尽量补全信息不全的账号的信息</span>
                    </div>
                </div>
           </div>

          
        </Card> 

        <miss-info-accountModal ref="missInfoAccountModal"></miss-info-accountModal>
        
        <unvisited-org-modal ref="unvisitedOrgModal"></unvisited-org-modal>
    </div>
</template>


<script>
import missInfoAccountModal from "./miss-info-account-modal";
import unvisitedOrgModal from "./unvisited-org-modal";

import { mapGetters } from "vuex";
export default {
  components: {
    missInfoAccountModal,
    unvisitedOrgModal
  },

  props: {
    userInfo: {
      type: [Object],
      default: () => ({})
    }
  },

  computed: {
    userName() {
      return this.userInfo.trueName || this.userInfo.userName;
    },

    userId() {
      return this.userInfo.id;
    },
    ...mapGetters({
      tabs: "getTabs",
      activeTab: "getActiveTab"
    })
  },

  data() {
    return {
      loading: false,
      saleData: {}
      // customerData:{
      //   customerCount:"",
      //   notVisit:""
      // },
      // accountData:{
      //   accountCount:"",
      //   activeAccounts:"",
      //   incompleteAccounts:""
      // }
    };
  },

  created() {
    this.getData();
  },

  methods: {
    showUnvisitedDetailModal() {
      // this.$refs.unvisitedOrgModal.show();
      let ids = this.userInfo.depts_info.map(item=>item.dept_id-0) || [];
      if(!ids.includes(16)){
        this.$Message.warning("没有权限")
        return 
      }
      let tab = {
        activeName: "项目管理",
        name: "项目管理0",
        component: "projectSetting",
        isShow: true
      };
      this.$store.dispatch("setProjectVisitedStatus", {
        saleId: this.userId,
        ifVisited: false
      });
       this.$store.dispatch("setTabs", tab);

      // if (
      //   this.tabs.some(item => {
      //     return item.name === tab.name && item.pid === tab.pid;
      //   })
      // ) {
      //   let newtabs = this.tabs.map(item => {
      //     if (item.name == tab.name) {
      //       item.isShow = true;
      //     }
      //     return item;
      //   });

      //   this.$store.dispatch("setTabsAll", newtabs);
      //   this.$store.dispatch("setActiveTab", { activeTab: tab.name });
      // } else {
      //   this.$store.dispatch("setTabs", tab);
      //   this.$store.dispatch("setActiveTab", { activeTab: tab.name });
      // }
    },

    showMissInfoModal() {
      this.$refs.missInfoAccountModal.show();
    },

    getData() {
      this.loading = true;

      // Promise.all([this.getCustomerCount(), this.getAccountCount()]).then(
      //   () => {
      //     this.loading = false;
      //   }
      // );

      let params = {
        deptId: 16,
        userId: this.userId
      };

      this.$http.get("statistics/findSaleList", params).then(res => {
        this.loading = false;
        if (res.code === 20000) {
          this.saleData = res.data.records[0] || {};
        } else {
          this.$Message.error(`获取数据失败:${res.msg}`);
        }
      });
    }

    //   getCustomerCount() {
    //     return new Promise((resolve, reject) => {
    //       this.$http.get("statistics/getMyOrg").then(res => {
    //         if (res.code === 20000) {
    //           this.customerData = res.data;
    //           resolve();
    //         } else {
    //           this.$Message.error(`获取信息失败：${res.msg}`);
    //           resolve();
    //         }
    //       });
    //     });
    //   },

    //   getAccountCount() {
    //     return new Promise((resolve, reject) => {
    //       this.$http.get("statistics/getMyOrgAccounts").then(res => {
    //         if (res.code === 20000) {
    //           this.accountData = res.data;
    //           resolve();
    //         } else {
    //           this.$Message.error(`获取信息失败：${res.msg}`);
    //           resolve();
    //         }
    //       });
    //     });
    //   }
  }
};
</script>

<style lang="less" scoped>
.saler-view {
  margin-top: 20px;
}

.org-amount,
.account-amount {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin: 15px 0 0 15px;
  .amount-area {
    width: 200px;
  }
  p {
    font-size: 24px;
    font-weight: 900;
  }

  .miss-info-wrapper {
    color: #2d8cf0;
    cursor: pointer;
    text-decoration: underline;
  }

  .unvisited-wrapper {
    color: #f11515;
    cursor: pointer;
    text-decoration: underline;
  }
  .tip-area {
    margin-left: 20px;
    background: #bdd7f3;
    padding: 10px 15px;
    border-radius: 8px;
  }
}
</style>

