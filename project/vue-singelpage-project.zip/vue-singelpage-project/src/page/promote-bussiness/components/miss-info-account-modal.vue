<template>
    <Modal
       v-model="modal"
       :mask-closable="false"
       title="信息缺失账号列表"
       width='1200'
    >
        <div slot="close" @click="onCancel">
            <Icon type="ios-close-empty"></Icon>
        </div>

        <div slot="footer">
            <Button type="default" @click="onCancel">取消</Button>
            <Button type="primary" @click="onOk">确定</Button>
        </div>

        <div class="table-area">
            <Table
              class="fixed-height-table"
              :data="tableData"
              :columns="columns"
              v-loading="tableLoading"
              element-loading-text="拼命加载中"
              border
            />
        </div>

        <div class="page-load">
            <Page
              :total="total"
              placement="top"
              :current="currentPage"
              :page-size="pageSize"
              @on-change="onPageChange"
              @on-page-size-change="onPageSizeChange"
              show-elevator
              show-sizer
              show-total
            />
        </div>

        <account-edit-modal ref="accountEditModal" @refreshTable="refreshTable" class="people-modal"></account-edit-modal>
    </Modal>
</template>

<script>
import accountEditModal from "../../account-justify/components/account-edit-modal";
export default {
  props: {
    saleId: {
      type: [String, Number],
      default: ""
    }
  },

  components: {
    accountEditModal
  },

  data() {
    return {
      ifReFreshParentTable:false,
      fofLogo:require("../../../assets/fof-logo.png"),
      fmLogo:require("../../../assets/fm-logo.png"),
      modal: false,
      userId: "",
      total: 0,
      currentPage: 1,
      pageSize: 10,
      tableData: [],
      tableLoading: false,
      columns: [
        {
          key: "realName",
          title: "用户名",
          width: 80,
          fixed: "left",
          render:(h, { row }) =>{
            return h(
              "div",
              {
                style: {
                  display: "flex",
                  justifyContent: "flex-start",
                  alignItems: "center"
                }
              },
              [
                h("span", {
                  attrs: {
                    title: row.productId == 1 ? "组合大师账号" : "基金大师账号"
                  },
                  style: {
                    backgroundImage:
                      row.productId == 1
                        ? `url(${this.fofLogo})`
                        : `url(${this.fmLogo})`,
                    display: "inline-block",
                    backgroundSize: "100%",
                    backgroundRepeat: "no-repeat",
                    width: "20px",
                    height: "20px",
                    borderRadius: "4px",
                    marginRight: "5px"
                  }
                }),
                h("span", row.realName || "--")
              ]
            );
          }
        },
        {
          key: "accountNo",
          title: "账号",
          width: 100,
          fixed: "left",
          render(h, { row }) {
            return row.accountNo || "--";
          }
        },
        {
          key: "accountStatus",
          title: "账号状态",
          width: 80,
          render(h, { row }) {
            let mapping = {
              "4": "停用",
              "3": "正式",
              "2": "试用",
              "1": "申请",
              "0": "异常"
            };
            return mapping[row.accountStatus] || "--";
          }
        },
        {
          key: "endDate",
          title: "结束日期",
          width: 100,
          render(h, { row }) {
            return row.endDate ? row.endDate.substr(0, 11) : "--";
          }
        },
        {
          key: "managerName",
          title: "责任人",
          width: 80,
          render(h, { row }) {
            return row.managerName || "--";
          }
        },

        // {
        //   key: "productId",
        //   title: "产品类型",
        //   width: 80,
        //   render(h, { row }) {
        //     let mapping = {
        //       "1": "组合大师",
        //       "2": "基金大师"
        //     };
        //     return mapping[row.productId] || "--";
        //   }
        // },
        {
          key: "orgName",
          title: "机构名称",
          width: 200,
          render(h, { row }) {
            return row.orgName || "--";
          }
        },
        {
          key: "visitingCardUrl",
          title: "名片",
          width: 80,
          render(h, { row }) {
            let url;
            if (row.visitingCardUrl) {
              let picUrl = JSON.parse(JSON.stringify(row.visitingCardUrl));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? " http://static.simuwang.com/"
                    : "https://static-test-ali.simuwang.com/";
                picUrl = `Uploads/crm/${row.visitingCardUrl}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        },
        {
          key: "isHide", // 字段待定，新需求
          title: "隐藏数据",
          width: 80,
          render(h, { row }) {
            let mapping = {
              "1": "是",
              "0": "否"
            };
            return mapping[row.isHide] || "--";
          }
        },
        {
          key: "groupId",
          title: "用户组",
          width: 100,
          render(h, { row }) {
            let mapping = {
              "1": "组合大师管理员",
              "2": "VIP会员",
              "3": "普通用户"
            };
            return mapping[row.groupId] || "--";
          }
        },
        {
          key: "payingFlag",
          title: "是否付费",
          width: 80,
          render(h, { row }) {
            let mapping = {
              "0": "未付费",
              "1": "已付费"
            };
            return mapping[row.payingFlag] || "--";
          }
        },

        {
          key: "orgManagerName",
          title: "公司责任人",
          width: 120,
          render(h, { row }) {
            return row.orgManagerName || "--";
          }
        },
        {
          key: "userSource",
          title: "用户来源",
          width: 100,
          render(h, { row }) {
            let mapping = {
              "1": "PC端",
              "2": "移动端（扫码）",
              "3": "banner申请",
              "4": "批量导入",
              "5": "CRM单条新增"
            };
            return mapping[row.userSource] || "--";
          }
        },
        {
          key: "remarks",
          title: "备注",
          width: 80,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  maxWidth: "130px",
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  cursor: "pointer"
                },
                attrs: {
                  title: row.remark || ""
                }
              },
              row.remark || "--"
            );
          }
        },

        {
          key: "isForeigner",
          title: "是否海外用户",
          width: 100,
          render(h, { row }) {
            let mapping = {
              "1": "海外用户",
              "0": "国内用户"
            };
            return mapping[row.isForeigner] || "--";
          }
        },

        {
          key: "beginDate",
          title: "开始日期",
          width: 100,
          render(h, { row }) {
            return row.beginDate ? row.beginDate.substr(0, 11) : "--";
          }
        },

        {
          key: "creater",
          title: "创建人",
          width: 80,
          render(h, { row }) {
            return row.creater || "--";
          }
        },
        {
          key: "updater",
          title: "更新人",
          width: 80,
          render(h, { row }) {
            return row.updater || "--";
          }
        },
        {
          key: "updateTime",
          title: "更新时间",
          width: 100,
          render(h, { row }) {
            return row.updateTime ? row.updateTime.substr(0, 11) : "--";
          }
        },

        {
          key: "apply_source",
          title: "申请来源",
          width: 80,
          render(h, { row }) {
            const applySourceMapping = {
              1: "主站",
              7: "扫码注册",
              8: "其他"
            };
            return applySourceMapping[row.applySource] || "--";
          }
        },

        {
          title: "操作",
          width: 80,
          fixed: "right",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: row.productId == 2 ? "disabledBtn" : "deleteBtn"
                  },
                  on: {
                    click: () => {
                      if (row.productId == 2) {
                        return;
                      }
                      this.$refs.accountEditModal.show(
                        row.id,
                        row.accountNo,
                        row.productId
                      );
                    }
                  }
                },
                "编辑"
              )
            ]);
          }
        }
      ]
    };
  },

  methods: {
     refreshTable(){
         this.currentPage =1;
         this.pageSize = 10;
         this.getTableData();
         this.ifReFreshParentTable = true;
     },

    show(userId = "") {
      this.userId = userId;
      this.modal = true;
      this.getTableData();
    },

    getTableData() {
      this.tableLoading = true;
      let params = {
        pageSize: this.pageSize,
        pageNo: this.currentPage
      };
      if (this.userId) {
        params = {
          userId: this.userId,
          ...params
        };
      }
      this.$http
        .get("statistics/findMyOrgIncompleteAccounts", params)
        .then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.total = res.data.total;
            this.tableData = res.data.records;
          } else {
            this.$Message.error(`获取数据失败：${res.msg}!`);
          }
        });
    },

    onCancel() {
      this.modal = false;
      this.userId = "";
      this.tableData = [];
      this.total = 0;
      this.currentPage =1;
      this.pageSize = 10;
      if( this.ifReFreshParentTable){
        this.$emit("refreshTable");
        this.ifReFreshParentTable = !this.ifReFreshParentTable;
      }
    },

    onOk() {
      this.onCancel();
    },

    onPageChange(val) {
      this.currentPage = val;
      this.getTableData();
    },

    onPageSizeChange(val) {
      this.pageSize = val;
      this.getTableData();
    }
  }
};
</script>


<style lang="less" scoped>
.page-load {
  text-align: right;
  margin: 10px;
}
</style>

