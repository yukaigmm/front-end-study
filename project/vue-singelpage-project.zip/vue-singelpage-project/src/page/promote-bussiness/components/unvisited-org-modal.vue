<template>
    <Modal
      :mask-closable="false"
      v-model="modal"
      title="未拜访客户列表"
      width="1200"
    >
         <div slot="close" @click="onCancel">
            <Icon type="ios-close-empty"></Icon>
        </div>

        <div slot="footer">
            <Button type="default" @click="onCancel">取消</Button>
            <Button type="primary" @click="onOk">确定</Button>
        </div>

        <div class="table-area">
            <Table
               class="fixed-height-table"
               :data="tableData"
               v-loading="tableLoading"
               element-loading-text="拼命加载中"
               :columns="columns"
               border
            />
        </div>

        <div class="page-load">
            <Page
              :total="total"
              placement="top"
              :current="currentPage"
              :page-size="pageSize"
              @on-change="onPageChange"
              @on-page-size-change="onPageSizeChange"
              show-elevator
              show-sizer
              show-total
            />
        </div>
    </Modal>
</template>


<script>
import { mapGetters } from "vuex";

export default {
  props: {
    saleId: {
      type: [String, Number],
      default: ""
    }
  },

  computed: {
    ...mapGetters({
      emnus: "getEnums"
    })
  },

  data() {
    return {
      modal: false,
      total: 0,
      currentPage: 1,
      pageSize: 10,
      tableData: [],
      tableLoading: false,
      userId: "",
      columns: [
        {
          title: "客户编码",
          key: "orgId",
          width: 90,
          render: (h, { row, column, index }) => {
            let initStr = "0000000000";
            let jointStr = initStr + row.orgId;
            return jointStr.slice(-10);
          }
        },
        {
          title: "简称",
          key: "orgName",
          width: 400,
          render: (h, { row }) => {
            if (row.bread && row.bread.length) {
              let bread = row.bread.slice(1);
              return h(
                "div",
                bread.map((item, index) => {
                  return h(
                    "a",
                    {
                      attrs: {
                        href: "javascript:void(0)"
                      }
                    },
                    index === bread.length - 1
                      ? `${item.title}`
                      : `${item.title}>`
                  );
                })
              );
            } else {
              return h(
                "a",
                {
                  attrs: {
                    href: "javascript:void(0)"
                  }
                },
                `${row.orgName || "--"}`
              );
            }
          }
        },
        {
          title: "机构类型",
          key: "ocId",
          width: 100,
          render: (h, { row, column, index }) => {
            let orgTypeMapping = this.emnus.c_org;
            return orgTypeMapping
              .map(item => {
                if (row.ocId == item.value) {
                  return item.name;
                }
              })
              .join("");
          }
        },
        {
          title: "是否分配",
          key: "assignStatus",
          width: 100,
          render: (h, { row, column, index }) => {
            return row.manager && row.manager.length ? "是" : "否";
          }
        },
        {
          title: "机构状态",
          key: "status",
          width: 100,
          render: (h, { row, column, index }) => {
            return row.status ? "正式" : "试用";
          }
        },
        {
          title: "销售标签",
          key: "salesPortrait",
          width: 220,
          render: (h, { row, column, index }) => {
            let salesPortrait = row.salesPortrait
              ? Array.isArray(row.salesPortrait)
                ? row.salesPortrait
                : JSON.parse(row.salesPortrait)
              : [];
            if (salesPortrait && salesPortrait.length) {
              let tagArr = [];
              salesPortrait.forEach(item => {
                this.emnus.c_port_all_sale.forEach(tagItem => {
                  if (item == tagItem.value) {
                    tagArr.push(tagItem);
                  }
                });
              });
              if (tagArr.length) {
                return h(
                  "div",
                  tagArr.map(item => {
                    return h(
                      "Tag",
                      {
                        style: Object.assign({}, item.style)
                      },
                      `${item.name}`
                    );
                  })
                );
              } else {
                return "--";
              }
            } else {
              return "--";
            }
          }
        },
        {
          title: "责任人",
          key: "manager",
          width: 200,
          render: (h, { row, column, index }) => {
            if (row.manager && row.manager.length) {
              let manager = JSON.parse(JSON.stringify(row.manager));
              return manager.shift();
            } else {
              return "--";
            }
          }
        },
        {
          title: "联系人个数",
          key: "countContact",
          width: 100,
          render(h, { row }) {
            return row.countContact;
          }
        },
        {
          title: "活跃账户数",
          key: "activeAccount",
          width: 100,
          render(h, { row }) {
            return row.activeAccount;
          }
        },
        {
          title: "最近拜访时间",
          key: "recentVisitTime",
          width: 100,
          render(h, { row }) {
            return row.visit.visitTime
              ? row.visit.visitTime.substr(0, 11)
              : "--";
          }
        },
        {
          title: "最近拜访人",
          key: "recentVisitor",
          width: 100,
          render(h, { row }) {
            return row.visit.visitMemberName || "--";
          }
        }
      ]
    };
  },

  methods: {
    show(userId = "") {
      this.userId = userId;
      this.modal = true;
      this.getTableData();
    },

    getTableData() {
      this.tableLoading = true;
      let params = {
        pageSize: this.pageSize,
        pageNo: this.currentPage
      };
      if (this.userId) {
        params = {
          userId: this.userId,
          ...params
        };
      }
      this.$http.get("statistics/findUserNotVisitOrg", params).then(res => {
        this.tableLoading = false;
        if (res.code === 20000) {
          this.total = res.data.total;
          this.tableData = res.data.records;
        } else {
          this.$Message.error(`获取数据失败：${res.msg}!`);
        }
      });
    },

    onCancel() {
      this.modal = false;
      this.userId = "";
      this.tableData = [];
      this.total = 0;
      this.currentPage = 1;
      this.pageSize = 10;
    },

    onOk() {
      this.onCancel();
    },

    onPageChange(val) {
      this.currentPage = val;
      this.getTableData();
    },

    onPageSizeChange(val) {
      this.pageSize = val;
      this.getTableData();
    }
  }
};
</script>


<style lang="less" scoped>
.page-load {
  text-align: right;
  margin: 10px;
}
</style>

