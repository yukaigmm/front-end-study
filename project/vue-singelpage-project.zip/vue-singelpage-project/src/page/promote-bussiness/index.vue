<template>
    <div class="promote-bussiness">
        <saler-view v-if="!ifShowManagerPage" :userInfo="userInfo"></saler-view>
        <manager-view v-else :managerList="managerList"></manager-view>
    </div>
</template>


<script>
import managerView from "./components/manager-view";
import salerView from "./components/saler-view";
import { map } from "lodash";
import { mapGetters } from "vuex";

export default {
  components: {
    managerView,
    salerView
  },

  computed: {
    ...mapGetters({
      userInfo: "getUser",
      userId: "getUserId"
    }),

    ifShowManagerPage() {
      return this.userInfo.auth.functional.includes("showAnalysisManagerPage")
    }
  },

  data() {
    return {
      managerList: [],
    };
  },

  created() {
    this.getManagerList();
  },


  methods: {
    //  获取机构销售部人员列表
    getManagerList() {
      this.$http
        .get("dept/getUserByDept", {
          dept_id: 16,
          type: 1
        })
        .then(res => {
          if (res.code === 20000) {
            this.managerList = map(res.data, person => person).filter(
              item => item.status
            );
          }
        })
        .catch(e => {
          console.error("获取人员列表失败");
        });
    }
  }
};
</script>

<style lang="less" scoped>
</style>

