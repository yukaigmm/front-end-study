<template>
  <div>
    <h3 class="step-title">第二步：请填写蓝V开通信息</h3>

    <i-form :model="formData" ref="formData" :label-width="80" :rules="validateRules">
      <Row>
        <i-col span="11" offset="1">
          <form-item label="账号">
            <span>{{telephone}}</span>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="账号状态" prop="blue_vip_status">
            <i-select v-model="formData.blue_vip_status" placeholder="请选择蓝V等级" transfer clearable>
              <i-option
                v-for="item in statusOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="初始密码" prop="init_psw">
            <i-input v-model="formData.init_psw" :placeholder="passwordPlaceholder" disabled></i-input>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="蓝V等级" prop="bv_level">
            <i-select v-model="formData.bv_level" placeholder="请选择蓝V等级" transfer clearable>
              <i-option
                v-for="item in levelOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="开始日期" prop="blue_vip_time">
            <date-picker
              style="width:100%;"
              v-model="formData.blue_vip_time"
              @on-change="onStartTimeChange"
              clearable
              transfer
              placeholder="请选择开始日期"
            />
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="结束日期" prop="bv_expire_time">
            <date-picker
              style="width:100%;"
              v-model="formData.bv_expire_time"
              clearable
              transfer
              placeholder="请选择结束日期"
            />
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="是否付费" prop="bv_payment">
            <i-select v-model="formData.bv_payment" placeholder="请选择是否付费" transfer clearable>
              <i-option
                v-for="item in paymentOptions"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="推荐人" prop="bv_referee">
            <i-select
              v-model="formData.bv_referee"
              placeholder="请输入关键词"
              filterable
              remote
              transfer
              :loading="loading"
              :remote-method="remoteMethod"
              clearable
            >
              <i-option
                v-for="item in recommenderList"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="短信通知" prop="send_message">
            <Checkbox v-model="formData.send_message" :true-value="1" :false-value="0"></Checkbox>
          </form-item>
        </i-col>

        <i-col span="22" offset="1">
          <form-item label="备注" prop="blue_vip_remark ">
            <i-input
              v-model.trim="formData.blue_vip_remark "
              placeholder="请输入备注"
              type="textarea"
              :autosize="{minRows:2,maxRows:5}"
            />
          </form-item>
        </i-col>
      </Row>
    </i-form>
  </div>
</template>


<script>
import moment from "moment";

export default {
  props: ["telephone"],

  data() {
    return {
      ifFirstChange: true,
      loading: false,
      timer: null,
      formData: {},
      passwordPlaceholder: "请填写初始密码",
      hasPassword: false,
      recommenderList: [],
      statusOptions: [
        {
          label: "异常",
          value: 0
        },
        {
          label: "申请",
          value: 1
        },
        {
          label: "试用",
          value: 2
        },
        {
          label: "正式",
          value: 3
        },
        {
          label: "停用",
          value: 4
        }
      ],
      levelOptions: [
        {
          label: "蓝V1",
          value: 1
        },
        {
          label: "蓝V2",
          value: 2
        },
        {
          label: "蓝V3",
          value: 3
        }
      ],

      paymentOptions: [
        {
          label: "未付费",
          value: 0
        },
        {
          label: "已付费",
          value: 1
        }
      ],
      validateRules: {
        blue_vip_status: {
          required: true,
          message: "账号状态不能为空"
        },
        bv_level: {
          required: true,
          message: "蓝V等级不能为空"
        },
        blue_vip_time: {
          required: true,
          message: "开始时间不能为空"
        },
        bv_expire_time: {
          required: true,
          message: "结束时间不能为空"
        },
        bv_payment: {
          required: true,
          message: "是否付费不能为空"
        }
      }
    };
  },

  watch: {
    telephone: {
      handler(val) {
        this.ifHasAccount(val);
      },

      immediate: true
    }
  },

  methods: {
    // 检测该账号是否有官网账号
    ifHasAccount(val) {
      let params = {
        mobile: val
      };
      this.$http.get("FmAccount/status", params).then(res => {
        if (res.code === 20000) {
          if (res.data.accStatus == 1 || res.data.accStatus == 2) {
            this.passwordPlaceholder = "该手机号已绑定官网账号，无需设置密码";
            this.$set(this.formData, "init_psw", "");
          } else {
            this.$set(this.formData, "init_psw", this.randomPassword());
            this.passwordPlaceholder = "初始密码";
            this.hasPassword = false;
          }
        } else {
          this.passwordPlaceholder = "初始密码";
          this.$set(this.formData, "init_psw", this.randomPassword());
          this.hasPassword = false;
        }
      });
    },

    // 随机生成初始密码
    randomPassword() {
      let password = "smppw";
      for (let i = 0; i < 4; i++) {
        password += Math.floor(Math.random() * 10);
      }
      return password;
    },

    remoteMethod(query) {
      if (!query) {
        this.recommenderList = [];
        return;
      } else {
        this.loading = true;
        let params = {
          name: query,
          ifCancelRequest: true
        };

        this.$http
          .get("accounts/getAccountByName", params)
          .then(res => {
            this.loading = false;
            if (res.code === 20000) {
              if (res.data.length) {
                this.recommenderList = res.data.map(item => {
                  return {
                    label: item.linkman,
                    value: item.id
                  };
                });
              } else {
                this.recommenderList = [];
              }
            } else {
              this.recommenderList = [];
              this.$Message.error(`获取推荐人数据失败:${res.msg}`);
            }
          })
          .catch(err => {
            if (err !== "canceled") {
              this.loading = false;
              this.recommenderList = [];
              this.$Message.error("获取推荐人数据失败：网络请求错误！");
            }
          });
      }
    },

    onStartTimeChange(date) {
      if (this.ifFirstChange && !this.formData.bv_expire_time) {
        let endDate = moment(date).add(3, "M");
        this.$set(this.formData, "bv_expire_time", endDate);
        this.$refs.formData.validateField("bv_expire_time");
        this.ifFirstChange = !this.ifFirstChange;
      }
    },

    confirmFormData() {
      let flag = false;
      this.$refs.formData.validate(valid => {
        if (valid) {
          flag = true;
        } else {
          flag = false;
          this.$Message.warning("请按红色文字提示填写内容！");
        }
      });

      if (flag) {
        let formData = JSON.parse(JSON.stringify(this.formData));
        if (formData.bv_expire_time) {
          formData.bv_expire_time = moment(formData.bv_expire_time).format(
            "YYYY-MM-DD"
          );
        }
        if (formData.blue_vip_time) {
          formData.blue_vip_time = moment(formData.blue_vip_time).format(
            "YYYY-MM-DD"
          );
        }
        return formData;
      } else {
        return false;
      }
    }
  }
};
</script>

<style lang="less" scoped>
.step-title {
  margin-bottom: 15px;
  padding: 5px 0;
  border-bottom: 1px solid #aaaaaa;
}
</style>
