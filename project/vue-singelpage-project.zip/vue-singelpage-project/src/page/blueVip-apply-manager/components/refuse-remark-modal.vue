<template>
  <Modal v-model="modal" :title="modalTitle" :mask-closable="false" width="400">
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button @click="onCancel">取消</Button>
      <Button @click="onOk" type="primary" :loading="btnLoading">确定</Button>
    </div>

    <i-form :model="form" ref="form" :label-width="0" :rules="validateRules" label-position="top">
      <form-item :label="label" prop="content">
        <i-input
          style="width:100%"
          v-model.trim="form.content"
          placeholder="请输入..."
          type="textarea"
          :autosize="{minRows: 3,maxRows: 5}"
        />
      </form-item>
    </i-form>
  </Modal>
</template>


<script>
export default {
  data() {
    return {
      modal: false,
      type: "",
      form: {},
      id: "",
      btnLoading: false,
      validateRules: {
        content: { required: true, message: "不能为空！" }
      }
    };
  },

  computed: {
    modalTitle() {
      return this.type === "remark" ? "备注" : "拒绝蓝V申请";
    },

    label() {
      return this.type === "remark" ? "请输入备注" : "请输入拒绝原因";
    }
  },

  methods: {
    onCancel() {
      this.modal = false;
      this.type = "";
      this.id = "";
      this.form = {};
      this.$refs.form.resetFields();
    },

    onOk() {
      this.$refs.form.validate(valid => {
        if (valid) {
          if (this.type === "remark") {
            this.addRemark();
          } else {
            this.refuse();
          }
        } else {
          this.$Message.warning("请按红色文字提示填写内容！");
        }
      });
    },

    addRemark() {
      let params = {
        remark: this.form.content,
        id: this.id
      };

      this.deal(params, "remark");
    },

    refuse() {
      let params = {
        remark: this.form.content,
        id: this.id,
        status: 2
      };
      this.deal(params, "refuse");
    },

    deal(params = {}, msgType = "") {
      this.btnLoading = true;
      let msg = {
        remark: {
          success: "添加备注成功！",
          fail: "添加备注失败"
        },
        refuse: {
          success: "拒绝申请成功！",
          fail: "拒绝申请失败"
        }
      };

      this.$http
        .post("blueVip/updateAssembleBlueVip", params)
        .then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.$Message.success(`${msg[msgType]["success"]}`);
            this.onCancel();
            this.$emit("refreshTable");
          } else {
            this.$Message.error(`${msg[msgType]["fail"]}:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.$Message.error(`${msg[msgType]["fail"]}:网络请求错误！`);
          this.btnLoading = false;
        });
    },

    show(type, id) {
      this.type = type;
      this.id = id;
      this.modal = true;
    }
  }
};
</script>

<style lang="less" scoped>
</style>

