<template>
  <div>
    <h3 class="step-title">
      第一步：请核对或完善联系人信息
      <span class="tip-info">{{tipInfo}}</span>
    </h3>
    <i-form :model="formData" ref="formData" :label-width="80" :rules="validateRules">
      <Row>
        <i-col span="11" offset="1" class="visit-card">
          <form-item prop="visiting_card_url" label="名片">
            <Upload
              v-loading="imgLoading"
              element-loading-text="上传中，请稍候"
              :show-upload-list="false"
              ref="upload"
              accept="image/*"
              action="api/common/uploadFile"
              :before-upload="beforeUpload"
              style="display: inline-block;width:362px;height:214px;border:1px dotted #ccc;"
              :data="{fileType:'visitingCard'}"
            >
              <div class="upload-list-img" v-if="imgUrl">
                <img :src="imgUrl" :alt="formData.name+'名片'" @click="onPreviewCard">
                <div class="upload-list-cover">
                  <div class="change-button" title="更换名片">
                    <Icon type="ios-cloud-upload"></Icon>
                  </div>
                  <div class="preview-button" @click="onPreviewCard" title="预览">
                    <Icon type="ios-eye-outline"></Icon>
                  </div>
                  <div class="delete-button" @click="onUploadsRemove" title="删除名片">
                    <Icon type="ios-trash-outline"></Icon>
                  </div>
                </div>
              </div>

              <div v-else class="upload-button-container" title="上传名片">
                <Icon type="camera" size="20"></Icon>
              </div>
            </Upload>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="姓名" prop="name">
            <i-input v-model.trim="formData.name" placeholder="请输入姓名"/>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="职务" prop="post">
            <i-input v-model.trim="formData.post" placeholder="请输入职务"/>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="手机" prop="telephone">
            <i-input disabled v-model.trim="formData.telephone" placeholder="请输入手机"/>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="微信" prop="weichat">
            <i-input v-model.trim="formData.weichat" placeholder="请输入微信"/>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="用户" prop="contacts_type">
            <i-select v-model="formData.contacts_type" placeholder="请选择用户类型" transfer clearable>
              <i-option
                v-for="item in userTypeOptions"
                :key="item.value"
                :value="item.value-0"
              >{{item.name}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="邮箱" prop="email" :class="{'ivu-form-item-required':this.imgUrl}">
            <i-input v-model.trim="formData.email" placeholder="请输入邮箱"/>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="性别" prop="sex">
            <i-select v-model="formData.sex" placeholder="请选择性别" transfer clearable>
              <i-option
                v-for="item in sexOptions"
                :key="item.value"
                :value="item.value-0"
              >{{item.name}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="年龄" prop="age">
            <i-select v-model="formData.age" placeholder="请选择年龄" transfer clearable>
              <i-option
                v-for="item in ageOptions"
                :key="item.value"
                :value="item.value-0"
              >{{item.name}}</i-option>
            </i-select>
          </form-item>
        </i-col>

        <i-col span="11" offset="1">
          <form-item label="公司/部门" prop="orgNameStr" class="ivu-form-item-required">
            <i-input
              placeholder="请选择公司/部门"
              v-model="orgNameStr"
              :title="orgNameStr"
              @on-focus="showDeptSelectModal"
            ></i-input>
          </form-item>

          <span
            class="apply-dept"
            :title="applyCompanyName"
          >申请公司/部门信息：{{applyCompanyName||"无申请公司信息"}}</span>
        </i-col>

        <i-col span="23" offset="1">
          <!-- 用户标签 -->
          <Form-item label="画像" prop="portrait" class="dialog-form-item-row">
            <!-- 用户标签 -->
            <Tag
              v-for="item in portraitData"
              :key="item.value"
              :style="getStyle(item.style)"
              :name="item.value"
              closable
              @on-close="delPort"
            >{{item.name}}</Tag>

            <!-- tag 添加按钮 -->
            <Select
              v-if="addTags"
              transfer
              v-model="modelPort"
              filterable
              remote
              style="width:100px"
              @on-change="selectPort"
              :remote-method="remoteMethodPort"
              :loading="loadingPort"
              placeholder="添加标签"
            >
              <Option v-for="(option,index) in optionsPort" :value="option.value" :key="index">
                <Tag :style="option.style">{{option.name}}</Tag>
              </Option>
            </Select>

            <div style="display:inline-block;">
              <Tag @click.native="addMore">
                <span v-if="!addTags">
                  <Icon type="plus"></Icon>
                </span>

                <span v-else>
                  <Icon type="minus"></Icon>
                </span>
              </Tag>
            </div>
          </Form-item>
        </i-col>
      </Row>
    </i-form>

    <div class="company-change-log-container">
      <div class="change-log-title" @click="toggleLogTableVisibility">公司/职务变更日志</div>
      <div class="change-log-table-container" v-show="showLogTable">
        <change-log-table :showLogTable="showLogTable" :person-id="contactId" ref="changeLogTable"></change-log-table>
      </div>
    </div>

    <customer-dept ref="customerDept" @submit="getCheckedDept"/>
  </div>
</template>

<script>
import uglifyPic from "@/mixins/condensePic";
import { mapGetters } from "vuex";
import customerDept from "@/components/common-components/customer/subcomponents/customer-dept-select-modal.vue";
import changeLogTable from "@/components/common-components/customer/subcomponents/changeLogTable.vue";
import _ from "lodash";
export default {
  mixins: [uglifyPic],

  components: {
    customerDept,
    changeLogTable
  },

  data() {
    const validateEmail = (rules, value, callback) => {
      let errors = [];
      if (this.imgUrl) {
        if (!value) {
          errors.push(new Error("邮箱不能为空！"));
        } else {
          callback(errors);
        }
      }
      callback(errors);
    };

    const validateCompany = (rules, value, cb) => {
      let errors = [];
      if (!this.orgNameStr) {
        errors.push(new Error("公司/部门不能为空！"));
      }

      cb(errors);
    };
    return {
      formData: {},

      tipInfo: "",

      validateRules: {
        post: [
          {
            required: true,
            message: "请输入职务信息",
            trigger: "change, blur"
          }
        ],
        name: [
          {
            required: true,
            message: "请输入姓名",
            trigger: "change, blur"
          }
        ],
        telephone: [
          {
            pattern: /^1(3|4|5|6|7|8|9)\d{9}$/,
            message: "请输入正确的电话",
            trigger: "change, blur"
          }
        ],
        email: [
          {
            pattern: /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/,
            message: "请输入正确的邮箱",
            trigger: "change, blur"
          },
          {
            validator: validateEmail
          }
        ],
        sex: [
          {
            required: true,
            message: "请选择性别"
          }
        ],
        contacts_type: [
          {
            required: true,
            message: "请选择用户类型"
          }
        ],

        orgNameStr: {
          validator: validateCompany,
          trigger: "change"
        }
      },
      //  名片相关 --start
      imgUrl: "",
      imgLoading: false,

      // 名片相关 --end

      orgNameStr: "",
      orgId: "",

      portraitData: [],
      modelPort: "",
      addTags: false,
      loadingPort: false,
      optionsPort: [],

      showLogTable: false,
      contactId: "",
      applyCompanyName: "",
      orgNameString: ""
    };
  },

  computed: {
    ...mapGetters({
      enums: "getEnums"
    }),

    userTypeOptions() {
      return this.enums.c_usertype;
    },

    sexOptions() {
      return this.enums.c_sex;
    },

    ageOptions() {
      return this.enums.c_age;
    },

    cacheData() {
      return this.enums.c_port_all;
    }
  },

  methods: {
    close() {
      this.formData = {};
      this.tipInfo = "";
      this.imgUrl = "";
      this.orgNameStr = "";
      this.orgId = "";
      this.portraitData = [];
      this.modelPort = "";
      this.showLogTable = false;
      this.contactId = "";
      this.applyCompanyName = "";
      this.orgNameString = "";
      this.$refs.formData.resetFields();
    },

    // 上传之前先清空,保证只能上传最后一条文件
    beforeUpload(file) {
      this.$refs.upload.clearFiles();
      this.imgLoading = true;
      this.uglifyPic(file, "formData", "formData", "visiting_card_url");
      return false;
    },

    getImgUrl(path) {
      let url;
      let picUrl = path;
      if (path.includes("/Onstage/")) {
        url =
          process.env.NODE_ENV === "production" ||
          process.env.NODE_ENV === "test"
            ? "https://fof.simuwang.com/"
            : "https://master-test.simuwang.com/";
      } else {
        url =
          process.env.NODE_ENV === "production"
            ? " http://static.simuwang.com/"
            : "https://static-test-ali.simuwang.com/";
        picUrl = `Uploads/crm/${path}`;
      }
      this.imgUrl = `${url}${picUrl}`;
    },

    // 点击文件 预览
    onPreviewCard(e) {
      e.stopPropagation();
      e.preventDefault();
      window.open(`${this.imgUrl}`);
      return false;
    },

    onUploadsRemove(e) {
      e.stopPropagation();
      e.preventDefault();
      this.formData.visiting_card_url = "";
      this.$refs.upload.clearFiles();
      this.imgUrl = "";
      this.$refs.formData.validateField("email");
      return false;
    },

    // 打开设置联系人部门的modal
    showDeptSelectModal() {
      this.$refs.customerDept.show(this.orgId);
    },

    // 获取部门层级的字符串
    getCheckedDept(data) {
      let { checkedId, checkedLabelArr } = data;
      this.orgId = checkedId;
      this.orgNameStr = checkedLabelArr.join(">");
    },

    // 设置
    setOrgNameStr(bread = []) {
      let orgNameArr = [];
      bread.forEach(breadItem => {
        orgNameArr.push(breadItem.title);
      });
      this.orgNameStr = orgNameArr.join(">") || this.orgNameString;
    },

    getStyle(styleObj) {
      return {
        ...styleObj,
        fontSize: `${styleObj.fontSize}px`
      };
    },

    delPort(e, val) {
      let portData = JSON.parse(JSON.stringify(this.portraitData));
      _.remove(portData, item => {
        return item.value === val;
      });
      this.portraitData = portData;
    },

    // 画像设置
    selectPort(val) {
      let port = _.filter(this.cacheData, item => {
        return item.value === val;
      })[0];
      let isRepeat = _.some(this.portraitData, item => {
        return item.value === port.value;
      });
      if (!isRepeat) {
        this.portraitData.push(port);
      }
      this.addTags = false;
      this.modelPort = "";
      this.optionsPort = JSON.parse(JSON.stringify(this.cacheData));
    },

    getInitPort() {
      let ports = this.formData.portrait || [];
      this.portraitData = this.cacheData.filter(item => {
        return ports.includes(item.value);
      });
    },

    remoteMethodPort(query) {
      if (query !== "") {
        this.loadingPort = true;
        setTimeout(() => {
          this.loadingPort = false;

          let optionsPort = _.filter(this.cacheData, item => {
            return item.name.indexOf(query) !== -1;
          });
          if (_.isEmpty(optionsPort)) {
            optionsPort = JSON.parse(JSON.stringify(this.cacheData));
          }
          this.optionsPort = optionsPort;
        }, 100);
      } else {
        this.optionsPort = JSON.parse(JSON.stringify(this.cacheData));
      }
    },

    addMore() {
      this.addTags = !this.addTags;
    },

    // 切换职位变更日志
    toggleLogTableVisibility() {
      this.showLogTable = !this.showLogTable;
    },

    show(
      contactInfo = {},
      tipInfo = "该联系人在crm中不存在，点击下一步将新增联系人",
      applyCompanyName,
      orgNameString
    ) {
      this.applyCompanyName = applyCompanyName;
      this.tipInfo = tipInfo;
      this.orgNameString = orgNameString;
      this.formData = JSON.parse(JSON.stringify(contactInfo));
      this.orgId = this.formData.org_id || "";
      this.contactId = this.formData.id;
      if (!this.formData.age) {
        this.formData.age = "";
      }
      this.setOrgNameStr(this.formData.bread || []);
      this.getImgUrl(this.formData.visiting_card_url);
      this.optionsPort = this.cacheData;
      this.getInitPort();
    },

    confirmContactInfo() {
      let flag = false;
      if (this.portraitData.length) {
        this.formData.portrait = this.portraitData.map(item => item.value);
      }
      this.$refs.formData.validate(valid => {
        if (valid) {
          flag = true;
        } else {
          flag = false;
          this.$Message.warning("请按红色文字提示填写内容！");
        }
      });

      let formData = {
        org_id: this.orgId,
        ...this.formData
      };

      if (flag) {
        return {
          data: formData,
          orgName: this.orgNameStr
        };
      } else {
        return false;
      }
    }
  }
};
</script>

<style lang="less" scoped>
.upload-list-img {
  cursor: pointer;
  vertical-align: top;
  display: inline-block;
  width: 360px;
  height: 212px;
  text-align: center;
  line-height: 212px;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  margin-right: 4px;
  img {
    width: 100%;
    height: 100%;
  }
}

.upload-button-container {
  width: 360px;
  height: 212px;
  line-height: 212px;
  text-align: center;
  overflow: hidden;
}

.upload-list-cover {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  position: absolute;
  height: 60px;
  bottom: -60px;
  left: 0;
  right: 0;
  line-height: 60px;
  background: rgba(0, 0, 0, 0.6);
  transition: all 0.5s ease;
  div {
    flex: 1;
  }
}

.upload-list-img:hover .upload-list-cover {
  bottom: 0;
}

.upload-list-cover i {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 5px;
}

.step-title {
  margin-bottom: 15px;
  padding: 5px 0;
  border-bottom: 1px solid #aaaaaa;
  .tip-info {
    font-size: 12px;
    font-weight: normal;
    color: #e42619;
    padding-left: 15px;
  }
}

.company-change-log-container {
  padding-left: 82px;
  .change-log-title {
    color: #0c7beb;
    text-decoration: underline;
    cursor: pointer;
    margin-bottom: 5px;
    display: inline-block;
  }
}

.apply-dept {
  color: #e42619;
  padding-left: 80px;
  overflow: hidden;
  display: inline-block;
  width: 100%;
  word-break: break-all;
  height: 20px;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>

