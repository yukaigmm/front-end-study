<template>
  <Modal v-model="modal" title="同意蓝V申请" :mask-closable="false" width="900">
    <div slot="close" @click="onCancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer" v-if="isFirstStep">
      <Button @click="onCancel">取消</Button>
      <Button @click="nextStep" type="primary" :loading="contactLoading" :disabled="!canGonext">下一步</Button>
    </div>

    <div slot="footer" v-else>
      <Button @click="preStep">上一步</Button>
      <Button @click="onOk" type="primary" :loading="addBVLoading">完成</Button>
    </div>

    <div v-loading="modalLoading" element-loading-text="拼命加载中">
      <transition>
        <component :is="currentStepComponent" :telephone="telephone" :ref="currentStepComponent"></component>
      </transition>
    </div>
  </Modal>
</template>

<script>
import ContactInfo from "./contact-info.vue";
import AddBlueVip from "./add-blue-vip.vue";

export default {
  components: {
    ContactInfo,
    AddBlueVip
  },

  data() {
    return {
      modal: false,
      isFirstStep: true,
      applyInfo: {}, // 申请信息
      contactInfo: {}, // 填入表单的用户数据
      modalLoading: false,
      ifAddContact: false,
      companyName: "",
      applyCompanyName: "",
      canGonext: true,
      addBVLoading: false,
      contactLoading: false,
      initApplyContactData: {}, // 初始的用户申请数据
      crmContactInfo: {}, // crm中查到的用户数据
      hasContactChanged: false
    };
  },

  computed: {
    currentStepComponent() {
      return this.isFirstStep ? "ContactInfo" : "AddBlueVip";
    },

    telephone() {
      return this.isFirstStep ? "" : this.applyInfo.mobile;
    }
  },

  methods: {
    show(data = {}) {
      this.applyInfo = JSON.parse(JSON.stringify(data));
      let applyCompanyNameArr = [
        data.orgName,
        data.branchCompany,
        data.deptName
      ].filter(item => !!item);
      this.applyCompanyName = applyCompanyNameArr.join(">");
      this.modalLoading = true;
      this.getContactInfo()
        .then(() => {
          let msg = this.ifAddContact
            ? "该联系人在crm中不存在，点击下一步将新增联系人"
            : "";
          this.$refs.ContactInfo.show(
            this.contactInfo,
            msg,
            this.applyCompanyName
          );
          this.modalLoading = false;
        })
        .catch(err => {
          this.modalLoading = false;
        });
      this.modal = true;
    },

    getContactInfo() {
      let params = {
        id: this.applyInfo.id
      };

      return new Promise((resolve, reject) => {
        this.$http
          .get("blueVip/getContactsInfo", params)
          .then(res => {
            if (res.code === 20000) {
              let status = res.data.num;

              switch (status) {
                //   匹配不到联系人
                case 0:
                  this.ifAddContact = true;

                  if (!this.hasContactChanged) {
                    this.transfer();
                  }
                  resolve();
                  break;

                //   只能匹配到一个联系人
                case 1:
                  this.ifAddContact = false;
                  // 比对申请信息里的联系人信息和系统已有的联系人信息，以申请信息为准
                  let contactInfo = res.data.contacts;
                  // 保存一份系统原始信息，用于比对信息相对系统原始信息是否有更改
                  this.crmContactInfo = JSON.parse(JSON.stringify(contactInfo));
                  if (!this.hasContactChanged) {
                    this.transfer();
                    let keys = [
                      "visiting_card_url",
                      "name",
                      "post",
                      "telephone"
                    ];
                    keys.forEach(key => {
                      if (this.initApplyContactData[key])
                        contactInfo[key] = this.initApplyContactData[key];
                    });
                    this.contactInfo = contactInfo;
                  } else {
                    this.contactInfo = contactInfo;
                  }

                  resolve();
                  break;
                //   匹配到多个联系人：
                case 2:
                  this.$Message.warning(
                    "该联系人从属于多家公司，请先整理联系人数据！"
                  );
                  reject();
                  this.canGonext = false;
                  break;
              }
            } else {
              this.$Message.error(`获取联系人信息失败:${res.msg}`);
              reject();
            }
          })
          .catch(err => {
            console.error(err);
            reject();
            this.$Message.error(`获取联系人信息失败：网络请求错误！`);
          });
      });
    },

    onCancel() {
      this.isFirstStep = true;
      this.modal = false;
      this.applyInfo = {};
      this.contactInfo = {};
      this.ifAddContact = false;
      this.companyName = "";
      this.applyCompanyName = "";
      this.canGonext = true;
      this.initApplyContactData = {};
      this.crmContactInfo = {};
      this.hasContactChanged = false;
      if (this.$refs.ContactInfo) {
        this.$refs.ContactInfo.close();
      }
    },

    // 下一步
    nextStep() {
      //   this.isFirstStep = false;
      let formData = this.$refs.ContactInfo.confirmContactInfo();
      let data = formData["data"];
      this.companyName = formData["orgName"];

      let ifDataChange = !(
        JSON.stringify(this.crmContactInfo) == JSON.stringify(data)
      );
      this.contactInfo = data;
      if (data) {
        if (this.ifAddContact) {
          this.addContact(data)
            .then(() => {
              this.isFirstStep = false;
            })
            .catch(err => {
              this.$Message.warning("请核对联系人信息！");
            });
        } else {
          // 数据是否有更改，没有直接下一步
          if (ifDataChange) {
            this.editContact(data)
              .then(() => {
                this.isFirstStep = false;
              })
              .catch(err => {
                this.$Message.warning("请核对联系人信息！");
              });
          } else {
            this.isFirstStep = false;
          }
        }
      }
    },

    // 新增联系人
    addContact(contactInfo) {
      let params = {
        ...contactInfo
      };

      return new Promise((resolve, reject) => {
        this.contactLoading = true;
        this.$http
          .post("index/contact", params)
          .then(res => {
            this.contactLoading = false;
            if (res.code === 20000) {
              this.$Message.success("新增联系人成功！");
              this.hasContactChanged = true;
              resolve();
            } else {
              reject();
              this.$Message.error(`新增联系人失败：${res.msg}`);
            }
          })
          .catch(err => {
            this.contactLoading = false;
            reject();
            console.error("新增联系人失败：网络请求错误！");
          });
      });
    },

    // 编辑联系人
    editContact(contactInfo) {
      let params = {
        ...contactInfo
      };
      return new Promise((resolve, reject) => {
        this.contactLoading = true;
        this.$http
          .putWithoutId(`index/contact/${params.id}`, params)
          .then(res => {
            this.contactLoading = false;
            if (res.code === 20000) {
              this.$Message.success("编辑联系人成功！");
              this.hasContactChanged = true;
              resolve();
            } else {
              reject();
              this.$Message.error(`编辑联系人失败：${res.msg}`);
            }
          })
          .catch(err => {
            this.contactLoading = false;
            reject();
            console.error("编辑联系人失败：网络请求错误！");
          });
      });
    },

    // 上一步
    preStep() {
      this.isFirstStep = true;

      //   数据回填到联系人
      this.$nextTick(() => {
        this.modalLoading = true;
        this.getContactInfo()
          .then(() => {
            let msg = this.ifAddContact
              ? "该联系人在crm中不存在，点击下一步将新增联系人"
              : "";
            this.$refs.ContactInfo.show(
              this.contactInfo,
              msg,
              this.applyCompanyName
            );
            this.modalLoading = false;
          })
          .catch(err => {
            this.modalLoading = false;
          });
      });
    },

    onOk() {
      let data = this.$refs.AddBlueVip.confirmFormData();
      if (!data) {
        return;
      }
      let nameArr = this.companyName.split(">");
      let companyName = nameArr.shift();
      let departName = nameArr.join(" ");

      let applyDepart =
        this.applyInfo.branchCompany + " " + this.applyInfo.deptName;

      // 如果crm有子公司名以crm为准，如果没有以用户申请为准，如果申请也没有，则为总部
      departName = departName ? departName : applyDepart ? applyDepart : "总部";

      let applyParams = {
        apply_id: this.applyInfo.id,
        telephone: this.telephone,
        bv_company_name: companyName,
        bv_dept_name: departName,
        bv_position_name: this.contactInfo.post,
        realname: this.contactInfo.name,
        ...data
      };

      this.addBVLoading = true;

      this.$http
        .post("openBlueVip", applyParams)
        .then(res => {
          this.addBVLoading = false;
          if (res.code === 20000) {
            this.$Message.success("申请已同意！");
            this.onCancel();
            this.$emit("refreshTable");
          } else {
            this.$Message.error(`处理申请失败:${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.addBVLoading = false;
          this.$Message.error("处理申请失败:网络请求错误！");
        });
    },

    // 转换数据
    transfer() {
      let keysMapping = {
        visitingCard: "visiting_card_url",
        realName: "name",
        position: "post",
        mobile: "telephone"
      };

      let contactInfo = {};
      for (let key in keysMapping) {
        contactInfo[keysMapping[key]] = this.applyInfo[key];
      }

      this.contactInfo = contactInfo;
      this.initApplyContactData = JSON.parse(JSON.stringify(contactInfo));
    }
  }
};
</script>

<style lang="less" scoped>
</style>


