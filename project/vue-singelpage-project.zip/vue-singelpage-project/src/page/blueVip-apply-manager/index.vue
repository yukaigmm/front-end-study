<template>
  <div class="blue-vip-manager">
    <div class="search-area">
      <search-area :show-expand="false" @onKeydownSearch="search" ref="searchArea">
        <div slot="default">
          <Row>
            <i-col span="8">
              <form-item label="审批状态">
                <i-select v-model="searchData.status" clearable placeholder="请选择审批状态">
                  <i-option
                    v-for="item in statusOptions"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>

            <i-col span="8" offset="1">
              <form-item label="申请时间">
                <date-picker
                  style="width:100%"
                  v-model="searchData.createtime"
                  placeholder="请选择申请时间"
                  clearable
                />
              </form-item>
            </i-col>

            <i-col span="7">
              <div class="action-btn">
                <i-button type="primary" @click="search">搜索</i-button>
                <i-button @click="reset">重置</i-button>
              </div>
            </i-col>

            <i-col span="8">
              <form-item label="申请来源">
                <i-select v-model="searchData.source" placeholder="请选择申请来源" clearable transfer>
                  <i-option
                    v-for="item in sourceOptions"
                    :key="item.value"
                    :value="item.value"
                  >{{item.label}}</i-option>
                </i-select>
              </form-item>
            </i-col>
          </Row>
        </div>
      </search-area>
    </div>

    <div class="table-area">
      <Table
        :columns="columns"
        :data="tableData"
        v-loading="tableLoading"
        element-loading-text="拼命加载中"
        border
      />
    </div>

    <div class="page-load">
      <Page
        :total="total"
        placement="top"
        :current="currentPage"
        :page-size="pageSize"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      />
    </div>

    <refuse-remark-modal ref="refuseRemarkModal" @refreshTable="search"/>
    <approve-modal ref="approveModal" @refreshTable="search"/>
  </div>
</template>

<script>
import SearchArea from "@/components/search-area.vue";
import RefuseRemarkModal from "./components/refuse-remark-modal.vue";
import ApproveModal from "./components/approve-modal.vue";
import moment from "moment";
import setMaxHeightToTable from "@/mixins/setMaxHeightToTable.js";

export default {
  components: {
    SearchArea,
    RefuseRemarkModal,
    ApproveModal
  },

  mixins: [setMaxHeightToTable],

  data() {
    let commonCellStyle = {
      "text-overflow": "ellipsis",
      overflow: "hidden",
      "white-space": "nowrap"
    };
    return {
      searchData: {},
      sourceOptions: [
        {
          value: 1,
          label: "基金大师未知来源"
        },
        {
          value: 101,
          label: "基金大师banner"
        },
        {
          value: 2,
          label: "组合大师未知来源"
        },
        {
          value: 201,
          label: "组合大师浮窗"
        },
        {
          value: 202,
          label: "组合大师banner"
        },
        {
          value: 301,
          label: "官网广告位"
        }
      ],
      statusOptions: [
        {
          label: "未处理",
          value: 0
        },
        {
          label: "已同意",
          value: 1
        },
        {
          label: "已拒绝",
          value: 2
        },
        {
          label: "处理中",
          value: 3
        }
      ],
      tableData: [],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10,
      columns: [
        {
          title: "姓名",
          key: "realName",
          width: 120,
          fixed: "left",
          render: (h, { row }) => {
            return h("span", row.realName || "--");
          }
        },
        {
          title: "电话",
          key: "mobile",
          width: 120,
          fixed: "left",
          render: (h, { row }) => {
            return h("span", row.mobile || "--");
          }
        },
        {
          title: "公司名称",
          key: "orgName",
          width: 240,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "230px"
                },
                attrs: {
                  title: row.orgName
                }
              },
              row.orgName || "--"
            );
          }
        },
        {
          title: "分公司/营业部",
          key: "branchCompany",
          width: 240,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "230px"
                },
                attrs: {
                  title: row.branchCompany
                }
              },
              row.branchCompany || "--"
            );
          }
        },
        {
          title: "部门",
          key: "deptName",
          width: 200,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "190px"
                },
                attrs: {
                  title: row.deptName
                }
              },
              row.deptName || "--"
            );
          }
        },
        {
          key: "source",
          title: "申请来源",
          width: 150,
          ellipsis: true,
          render: (h, { row }) => {
            let matchItem = this.sourceOptions.filter(
              item => item.value == row.source
            );
            let text =
              matchItem && matchItem.length ? matchItem[0]["label"] : "";
            return h(
              "span",
              {
                attrs: {
                  title: text
                }
              },
              text || "--"
            );
          }
        },
        {
          title: "职务",
          key: "position",
          width: 120,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "230px"
                },
                attrs: {
                  title: row.position
                }
              },
              row.position || "--"
            );
          }
        },
        {
          title: "名片",
          key: "visitingCard",
          width: 100,
          render: (h, { row }) => {
            let url = "";

            if (row.visitingCard) {
              let picUrl = JSON.parse(JSON.stringify(row.visitingCard));
              if (picUrl.includes("/Onstage/")) {
                url =
                  process.env.NODE_ENV === "production"
                    ? "https://fof.simuwang.com/"
                    : "https://master-test.simuwang.com/";
              } else {
                url =
                  process.env.NODE_ENV === "production"
                    ? "http://static.simuwang.com/Uploads/crm/"
                    : "https://static-test-ali.simuwang.com/Uploads/crm/";
                picUrl = `${row.visitingCard}`;
              }
              return h(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    href: `${url}${picUrl}`
                  }
                },
                "查看名片"
              );
            } else {
              return "--";
            }
          }
        },
        {
          title: "申请时间",
          key: "createtime",
          width: 120,
          render: (h, { row }) => {
            return h("span", row.createtime.substring(0, 11) || "--");
          }
        },
        {
          title: "审批状态",
          key: "status",
          width: 120,
          render: (h, { row }) => {
            let text = "";

            let matchOne = this.statusOptions.filter(
              item => item.value == row.status
            )[0];

            text = matchOne ? matchOne.label : "--";

            return h("span", text);
          }
        },
        {
          title: "备注",
          key: "remark",
          width: 200,
          render: (h, { row }) => {
            return h(
              "div",
              {
                style: {
                  ...commonCellStyle,
                  "max-width": "190px"
                },
                attrs: {
                  title: row.remark
                }
              },
              row.remark || "--"
            );
          }
        },
        {
          title: "操作",
          key: "action",
          width: 150,
          fixed: "right",
          render: (h, { row }) => {
            let flag = row.status == 1 || row.status == 2;
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: flag ? "disabledBtn" : "deleteBtn"
                  },
                  on: {
                    click: () => {
                      if (flag) {
                        return;
                      }
                      this.$refs.approveModal.show(row);
                    }
                  }
                },
                "同意"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: flag ? "disabledBtn" : "deleteBtn"
                  },
                  on: {
                    click: () => {
                      if (flag) {
                        return;
                      }
                      this.$refs.refuseRemarkModal.show("refuse", row.id);
                    }
                  }
                },
                "拒绝"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.$refs.refuseRemarkModal.show("remark", row.id);
                    }
                  }
                },
                "备注"
              )
            ]);
          }
        }
      ]
    };
  },

  mounted() {
    this.getTableData();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".page-load"],
      ".table-area",
      150,
      true
    );
  },

  methods: {
    search() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getTableData();
    },

    reset() {
      this.searchData = {};
      this.search();
    },

    onPageChange(val) {
      this.currentPage = val;
      this.getTableData();
    },

    onPageSizeChange(val) {
      this.pageSize = val;
      this.getTableData();
    },

    getTableData() {
      let searchData = JSON.parse(JSON.stringify(this.searchData));

      let params = {
        pageNo: this.currentPage,
        pageSize: this.pageSize,
        ...searchData
      };

      if (!params.status && params.status !== 0) {
        delete params.status;
      }

      if (params.createtime) {
        params.createtime = moment(params.createtime).format("YYYY-MM-DD");
      }
      this.tableLoading = true;
      this.$http
        .get("assembleBlueVip", params)
        .then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
          } else {
            this.$Message.error(`获取表格数据失败：${res.msg}`);
          }
        })
        .catch(err => {
          console.error(err);
          this.tableLoading = false;
          this.$Message.error("获取表格数据失败：网络请求失败！");
        });
    }
  }
};
</script>

<style lang="less" scoped>
@import "./css/index.less";
</style>


