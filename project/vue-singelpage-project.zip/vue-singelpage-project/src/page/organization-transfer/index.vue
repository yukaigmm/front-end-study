
<template>
  <!-- <Modal
    v-model="modal"
    width="500"
    title="机构变更"
    :mask-closable="false"
    @on-ok="ok"
    @on-cancel="cancel"
  > -->
    <!-- <div slot="footer">
      <Button type="primary" :loading="loading" @click="ok">确定</Button>
      <Button @click="cancel">取消</Button>
    </div> -->
    <div>
    <Form ref="form" inline :label-width="80" :model="form" :rules="rules">
      <FormItem label="方式" prop="transferType">
        <RadioGroup v-model="form.transferType">
          <Radio v-for=" (option, index) in transferTypeOptions" :key="index" :label="option.value">
            <span>{{option.label}}</span>
          </Radio>
        </RadioGroup>
      </FormItem>

      <FormItem label="原始机构" prop="currentOrgId">
        <Poptip
          placement="bottom"
          width="300"
          @on-ok="currentPoptipOk"
          @on-cancel="currentPoptipCancel"
          confirm>
          <Input
            v-model.trim="currentKeyword"
            placeholder="请输入关键字,如：总部 分部"
            style="width:300px;"
            @input="getCurrentOrgList">
          </Input>
          <div slot="title">
            <Spin fix v-if="currentListLoading">
              <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
              <div>加载中...</div>
            </Spin>
            <div v-else  class="trasfer-tree">
                <el-tree
                  class="radio-tree"
                  :data="currentOuterList"
                  show-checkbox
                  node-key="id"
                  ref="currentTree"
                  :auto-expand-parent="true"
                  :check-strictly="true"
                  :expand-on-click-node="false"
                  :props="defaultProps"
                  @check="currentCheckChange"
                  check-on-click-node
                  :default-expanded-keys="currentExpandIdArr">
                </el-tree>
            </div>
          </div>
        </Poptip>
      </FormItem>
      <FormItem label="目标机构" prop="targetOrgId">
        <Poptip
          placement="bottom"
          width="300"
          @on-ok="targetPoptipOk"
          @on-cancel="targetPoptipCancel"
          confirm>
          <Input
            v-model.trim="targetKeyword"
            placeholder="请输入关键字,如：总部 分部"
            style="width:300px;"
            @input="getTargetOrgList">
          </Input>
          <div slot="title">
            <Spin fix v-if="targetListLoading">
              <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
              <div>加载中...</div>
            </Spin>
            <div v-else  class="trasfer-tree">
                <el-tree
                  class="radio-tree"
                  :data="targetOuterList"
                  show-checkbox
                  node-key="id"
                  ref="targetTree"
                  :auto-expand-parent="true"
                  :check-strictly="true"
                  :props="defaultProps"
                  @check="targetCheckChange"
                  :expand-on-click-node="false"
                  check-on-click-node
                  :default-expanded-keys="targetExpandIdArr">
                </el-tree>
            </div>
          </div>
        </Poptip>
      </FormItem>

      <div style="min-height: 25px;">
        <span v-if="form.transferType===1&&this.lastCurrentOrg.title&&this.lastTargetOrg.title" class="tips">
          注：该方式下，<b>{{this.lastCurrentOrg.title}}</b>将直接迁移至<b>{{this.lastTargetOrg.title}}</b>组织架构下，成为<b>{{this.lastTargetOrg.title}}</b>的分支机构。
        </span>
        <span v-if="form.transferType===2&&this.lastCurrentOrg.title&&this.lastTargetOrg.title"  class="tips">
          注：该方式下，<b>{{this.lastCurrentOrg.title}}</b>将与<b>{{this.lastTargetOrg.title}}</b>合并数据，<b>{{this.lastCurrentOrg.title}}</b>将被删除。
        </span>
      </div>
      <FormItem>
        <Button type="primary" :loading="loading" @click="showTransferModal">确定</Button>
        <Button @click="cancel">重置</Button>
      </FormItem>
    </Form>
    <div v-if="showErrorTip" style="border: 1px solid #CD1E06;padding: 10px;display: inline-block;border-radius: 5px;">
      <div>无法合并。<b>{{errorTip.current}}</b>与<b>{{errorTip.target}}</b>存在以下重复机构：</div>
      <div style="margin-top: 10px;">
        <span style="display: block;" v-for="(org, index) in errorTip.repeatOrgs" :key="index">{{org}}</span>
      </div>
    </div>
    <transferModal ref="transferModal" @ok="ok"></transferModal>
    </div>
  <!-- </Modal> -->
</template>
<script>
import _ from "lodash";
import { fetchUser, fetchGrid } from "@/service/getData";
import transferModal from "./components/tips";
export default {
  components: {
    transferModal
  },

  data() {
    return {
      // preData: [],
      defaultProps: {
        children: "children",
        label: "title"
      },
      modal: false,
      loading: false,
      initForm: {
        transferType: "",
        currentOrgId: "",
        targetOrgId: ""
      },
      form: {},
      rules: {
        transferType: [
          {
            required: true,
            type: "number",
            message: "必选",
            trigger: "change, blur"
          }
        ],
        currentOrgId: [
          {
            required: true,
            type: "number",
            message: "必选",
            trigger: "change, blur"
          }
        ],
        targetOrgId: [
          {
            required: true,
            type: "number",
            message: "必选",
            trigger: "change, blur"
          }
        ]
      },
      transferTypeOptions: [
        {
          value: 1,
          label: "将原始机构移动至目标机构下"
        },
        {
          value: 2,
          label: "将原始机构合并到目标机构"
        }
      ],
      targetKeyword: "",
      currentKeyword: "",
      currentListLoading: false,
      targetListLoading: false,
      currentOuterList: [],
      targetOuterList: [],
      searchType: "2",
      lastCurrentOrg: {},
      lastTargetOrg: {},
      targetExpandIdArr: [],
      currentExpandIdArr: [],
      currentId: null,
      targetId: null,
      showErrorTip: false,
      errorTip: {},
    };
  },
  methods: {
    showTransferModal() {
      if (!this.currentId || !this.targetId || !this.form.transferType) {
        this.$Message.warning("请先选择机构或转移方式！");
        return;
      }
      this.$refs.transferModal.show(
        this.currentKeyword,
        this.targetKeyword,
        this.form.transferType
      );
    },

    ok() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.loading = true;

          let type = this.form.transferType;
          if (type === 1) {
            //移动
            this.$http
              .post("organization/moveto", {
                orgId: this.form.currentOrgId,
                targetOrgId: this.form.targetOrgId
              })
              .then(res => {
                this.loading = false;
                if (res.code === 20000) {
                  this.$Message.success("移动成功");
                  // this.$emit("refresh");
                  this.reset();
                } else {
                  this.$Message.error(`${res.msg}: ${res.data}`);
                }
              });
          } else {
            //合并
            this.$http
              .post("organization/mergeto", {
                orgId: this.form.currentOrgId,
                targetOrgId: this.form.targetOrgId
              })
              .then(res => {
                this.loading = false;
                if (res.code === 20000) {
                  this.$Message.success("合并成功");
                  // this.$emit("refresh");
                  this.reset();
                } else {
                  this.$Message.error(res.msg);
                  if (res.code === 40010) {
                    this.errorTip = {
                      current: this.currentKeyword,
                      target: this.targetKeyword,
                      repeatOrgs: res.data,
                    };
                    this.showErrorTip = true;
                  }
                }
              });
          }
        } else {
          this.$Message.error("请按提示补充信息");
        }
      });
    },
    cancel() {
      this.reset();
    },
    reset() {
      this.currentKeyword = "";
      this.currentOuterList = [];
      this.targetKeyword = "";
      this.targetOuterList = [];
      this.form = JSON.parse(JSON.stringify(this.initForm));
      this.$refs.form.resetFields();
    },
    targetCheckChange(data, nodeInfo) {
      // this.preData = data;
      // this.setChildTreeDisabled(data)
      if (nodeInfo.checkedKeys.length) {
        this.$refs.targetTree.setCheckedNodes([data]);
        this.lastTargetOrg = {
          id: data.id,
          title: data.title
        };
      } else {
        this.lastTargetOrg = {};
      }
      this.targetPoptipOk();
    },

    // setChildTreeDisabled(data) {
    //   if (data.children && data.children.length) {
    //     for (let i = 0, len = data.children.length; i < len; i++) {
    //       data.children[i].disabled = true;
    //       if (!data.children[i].children || !data.children[i].children.length) {
    //         continue;
    //       } else {
    //         this.setChildTreeDisabled(data.children[i]);
    //       }
    //     }
    //   } else {
    //     return;
    //   }
    // },

    currentCheckChange(data, nodeInfo) {
      if (nodeInfo.checkedKeys.length) {
        this.$refs.currentTree.setCheckedNodes([data]);
        this.lastCurrentOrg = {
          id: data.id,
          title: data.title
        };
      } else {
        this.lastCurrentOrg = {};
      }
      this.currentPoptipOk();
    },
    // 获取选定的节点
    targetPoptipOk() {
      this.targetKeyword = this.lastTargetOrg.title;
      this.form.targetOrgId = this.lastTargetOrg.id;
    },
    currentPoptipOk() {
      this.currentKeyword = this.lastCurrentOrg.title;
      this.form.currentOrgId = this.lastCurrentOrg.id;
    },
    targetPoptipCancel() {
      this.targetOuterList = [];
      this.targetKeyword = "";
      this.form.targetOrgId = "";
    },
    currentPoptipCancel() {
      this.currentOuterList = [];
      this.currentKeyword = "";
      this.form.currentOrgId = "";
    },

    // 获取外部部门列表
    getTargetOrgList() {
      this.targetOuterList = [];
      if (!this.targetKeyword) {
        return;
      }
      let targetKeyword = this.targetKeyword.trim().split(/[ ]+/);
      let params = {
        type: this.searchType,
        keywords: targetKeyword,
        showPerson: false,
        disabled: false
        // disabledKey: 'disableCheckbox'
        // disabledKey: 'disabled'
      };
      this.targetListLoading = true;
      clearTimeout(this.targetId);
      this.targetId = setTimeout(() => {
        fetchGrid("visit/gettreebytype", params).then(res => {
          // this.targetOuterList = res.data;
          _.forEach(res.data, data => {
            //  this.setAllParentNodeAsFalse(data, 'null', this.targetExpandIdArr)
            this.setExpandId(data, targetKeyword, this.targetExpandIdArr);
          });
          this.targetOuterList = [
            {
              id: -1,
              checked: false,
              disabled: true,
              expand: true,
              title: "所有",
              children: [].concat(res.data)
            }
          ];
          this.targetExpandIdArr.unshift(-1);
          this.targetListLoading = false;
        });
      }, 800);
    },
    getCurrentOrgList() {
      this.currentOuterList = [];
      if (!this.currentKeyword) {
        return;
      }
      let currentKeyword = this.currentKeyword.trim().split(/[ ]+/);
      let params = {
        type: this.searchType,
        keywords: currentKeyword,
        showPerson: false,
        disabled: false
        // disabledKey: 'disableCheckbox'
        // disabledKey: 'disabled'
      };
      this.currentListLoading = true;
      clearTimeout(this.currentId);
      this.currentId = setTimeout(() => {
        fetchGrid("visit/gettreebytype", params).then(res => {
          // this.currentOuterList = res.data;
          _.forEach(res.data, data => {
            //  this.setAllParentNodeAsFalse(data, 'null', this.targetExpandIdArr)
            this.setExpandId(data, currentKeyword, this.currentExpandIdArr);
          });
          this.currentOuterList = [
            {
              id: -1,
              checked: false,
              disabled: true,
              expand: true,
              title: "所有",
              children: [].concat(res.data)
            }
          ];
          this.targetExpandIdArr.unshift(-1);
          this.currentListLoading = false;
        });
      }, 800);
    },

    setExpandId(data, keyword, expandIdArr) {
      this.getNeedExpand(data, keyword, expandIdArr);
    },
    getNeedExpand(data, keyword, expandIdArr) {
      let needExpand = data.children.some(c => {
        if (c.title.indexOf(keyword) !== -1) {
          return true;
        } else if (c.children && c.children.length) {
          return this.getNeedExpand(c, keyword, expandIdArr);
        } else {
          return false;
        }
      });

      if (needExpand) {
        expandIdArr.push(data.id);
      }
      return needExpand;
    },
    stopPropagation(e) {
      e.stopPropagation();
    }
  },
  mounted() {
    this.form = JSON.parse(JSON.stringify(this.initForm));
  },
  watch: {
    form: {
      handler () {
        
        this.showErrorTip = false;
        this.errorTip = {};
      },
      deep: true,
    }
  }
};
</script>
<style scoped lang="less">
.tips {
  display: block;
  margin-top: -5px;
  margin-left: 80px;
  margin-bottom: 7px;
  font-size:14px;
  color: #2d8cf0;
}
</style>

