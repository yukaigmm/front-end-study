<template>
   <Modal
     v-model="modal"
     title="机构变更"
     :mask-closable="false"
   >
     <div slot="close" @click="onCancel">
         <Icon type='ios-close-empty'></Icon>
     </div>

     <div slot='footer'>
       <Button type="primary" @click="transferOrg">确定</Button>
       <Button  @click="onCancel">取消</Button>
     </div>


    <span v-if="transferType===1">
     确定将<b>{{originOrg}}</b>直接迁移至<b>{{targetOrg}}</b>组织架构下？
    </span>

    <span v-if="transferType===2">
      确定删除<b>{{originOrg}}</b>,并将此机构与<b>{{targetOrg}}</b>进行合并？
    </span>

   </Modal>
</template>

<script>
export default {
   data(){
     return {
       modal:false,
       originOrg:"",
       targetOrg:"",
       transferType:"",
     }
   },

   methods:{
     show(originOrg,targetOrg,transferType){
       this.originOrg = originOrg;
       this.targetOrg = targetOrg;
       this.transferType = transferType;
       this.modal = true;
     },

     transferOrg(){
      this.$emit('ok');
      this.onCancel();
     },

     onCancel(){
       this.modal = false;
       this.originOrg = "";
       this.targetOrg = "";
       this.transferType = "";
     },
   }
}
</script>

<style lang="less" scoped>

</style>

