<template>
   <Modal
     v-model="modal"
     title="管理账号列表"
     :mask-closable="false"
     width="1300"
     class="choose-mutiple-targets"
   >
       <div slot="close" @click="onCancel">
           <Icon type="ios-close-empty"></Icon>
       </div>

       <div slot="footer">
           <Button type="default" @click="onCancel">关闭</Button>
           <Button type="primary" @click="onOk">确定</Button>
       </div>
       
       <div class="account-list">
           <div class="form-area">
               <Form :label-width="80">
                   <Row>
                     <i-col span="12">
                        <Row>
                            <i-col span="20">
                                <FormItem label="机构名称">
                                     <Input 
                                       v-model.trim="searchParams.orgName"
                                       placeholder="请输入机构名称"  
                                     />
                                </FormItem>
                                </i-col>
                                <i-col span="20">
                                      <FormItem label="账号信息">
                                          <Input 
                                            v-model.trim="searchParams.user_keyword"
                                            placeholder="请输入用户名或账号"  
                                          />
                                     </FormItem>
                                </i-col>
         
                                <i-col span="20" style="text-align:right;">
                                     <Button type="primary" @click="search">搜索</Button>
                                </i-col>
                        </Row>
                      
                     </i-col>
                       
                   </Row>
               </Form>
           </div>
            
           <transfer-table 
              ref="transferTable"
              ifShowOriginPage
              ifShowTargetPage
              :columns="columns"
              :originTableLoading="originTableLoading"
              :originTableData="originTableData"
              transferKey="officialUserId"
              tableHeight="250"
              :targetTableData="targetTableData"
              :originTotal="originTotal"
              @getOriginTableData="getOriginTableData"
           >
              <h5 slot="orginTitle">账号列表</h5>
              <h5 slot="targetTitle">已添加账号列表</h5>
           </transfer-table>
        

       </div>


   </Modal>    
</template>

<script>
import transferTable from "./transfer-table-with-page.vue";
export default {
  components: {
    transferTable
  },

  data() {
    return {
      targetTableData: [],
      modal: false,
      originTotal: 0,
      originTableLoading: false,
      searchParams: {
        orgName: "",
        user_keyword: ""
      },
      originTableData: [],
      columns: [
        {
          type: "selection",
          align: "center",
          width: 50
        },
        {
          key: "realName",
          title: "用户名",
          width: 135,
          render(h, { row }) {
            return h("span", row.realName || "--");
          }
        },
        {
          key: "accountNo",
          title: "账号",
          width: 150,
          render(h, { row }) {
            return h("span", row.accountNo || "--");
          }
        },
        {
          key: "accountStatus",
          title: "账号状态",
          width: 110,
          render(h, { row }) {
            let mapping = {
              "4": "停用",
              "3": "正式",
              "2": "试用",
              "1": "申请",
              "0": "异常"
            };
            return mapping[row.accountStatus] || "--";
          }
        },
        {
          key: "endDate",
          title: "结束日期",
          width: 130,
          render(h, { row }) {
            return row.endDate ? row.endDate.substr(0, 11) : "--";
          }
        }
      ]
    };
  },

  methods: {
    show(targetTableData) {
      this.modal = true;
      this.targetTableData = targetTableData;
      this.getOriginTableData();
    },

    onOk() {
      this.$emit("getData", this.getSelectedData());
      this.onCancel();
    },

    onCancel() {
      this.modal = false;
      this.searchParams = {
        orgName: "",
        user_keyword: ""
      };
      this.targetTableData = [];
      this.originTotal = 0;
      this.$refs.transferTable.clearData();
    },

    getSelectedData() {
      return this.$refs.transferTable.getData().targetData;
    },

    search() {
      this.getOriginTableData();
    },

    getOriginTableData(param = {}) {
      let params = {
        pageSize: param.pageSize || 10,
        pageNo: param.pageNo || 1,
        productId: 1,
        ...this.searchParams
      };
      this.originTableLoading = true;
      this.$http.get("/accounts/findAccount", params).then(res => {
        this.originTableLoading = false;
        if (res.code === 20000) {
          this.originTableData = res.data.records;
          this.originTotal = res.data.total;
        } else {
          this.$Message.error("获取账号列表失败！");
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.form-area {
  margin-bottom: 15px;
}
</style>


