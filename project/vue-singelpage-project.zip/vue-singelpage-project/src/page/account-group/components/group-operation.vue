<template>
   <Modal
     v-model="modal"
     :title="modalTitle"
     width="885"
     :mask-closable='false'
   >
       <div slot="close" @click="onCancel">
           <Icon type="ios-close-empty"></Icon>
       </div>

       <div slot="footer">
           <Button type="default" @click="onCancel">关闭</Button>
           <Button type="primary" @click="onOk" :loading="btnLoading">确定</Button>
       </div>

       <div v-loading="modalLoading" element-loading-text="拼命加载中">
           <Form :model="formData" :label-width="80" :rules="validateRules" ref="form">
              <form-item prop="groupName" label="组名">
                <Row>
                    <i-col span="8">
                       <Input 
                        v-model="formData.groupName" 
                        placeholder="请输入组名" />
                    </i-col>
                </Row>
              </form-item>
      </Form>

      <div class="action-btn-wrap">
          <span style="margin-right:15px;">账号列表</span>
          <!-- <Button type="primary" @click="managerAccount">管理账号列表</Button> -->
          <Button type="primary" :disabled="!this.sletectedTableData.length" @click="setAsAdmin">设为管理员</Button>
          <Button type="primary" :disabled="!this.sletectedTableData.length" @click="setAsNotAdmin">取消管理员</Button>
      </div>

      <div class="table-area">
          <Table
              ref="table"
             :key="tableKey"
             :height="300"
             :data="tableData"
             :columns="columns"
             v-loading="tableLoading"
             element-loading-text="拼命加载中"
             border
             @on-selection-change="onSelectionChange"
          />
      </div>
      <div class="page-load" v-if="total>30">
         <Page 
               :total="total"
               placement="top"
               :current="currentPage"
               :page-size="pageSize"
               @on-change="onPageChange"
               @on-page-size-change="onPageSizeChange"
               show-elevator
               show-total
               show-sizer
         />
      </div>
       </div>
       
      
       <group-account-list ref="groupAccountList" @getData="getSelectedUser"></group-account-list>
   </Modal>    
</template>


<script>
import groupAccountList from "./group-account-list.vue";
import { unionBy } from "lodash";

export default {
  components: {
    groupAccountList
  },

  props: {
    showType: {
      type: [String]
    }
  },

  computed: {
    modalTitle() {
      let title = "";

      switch (this.showType) {
        case "edit":
          title = "编辑分组";
          break;
        case "add":
          title = "新建分组";
          break;
        default:
          break;
      }
      return title;
    },

    total() {
      return this.initTableData.length || 0;
    }
  },

  data() {
    return {
      modalLoading: false,
      currentPage: 1,
      pageSize: 10,
      modal: false,
      btnLoading: false,
      formData: {
        name: ""
      },
      validateRules: {
        groupName: {
          required: true,
          message: "组名不能为空"
        }
      },
      tableData: [],
      columns: [
        {
          type: "selection",
          width: 50,
          align: "center"
        },
        {
          title: "用户名",
          key: "realName",
          width: 100,
          ellipsis: true,
          render(h, { row }) {
            let elArr = [
              h("Icon", {
                props: {
                  type: "person"
                },
                attrs: {
                  title: "管理员"
                }
              }),
              h("span", row.realName || "--")
            ];

            if (row.isAdmin) {
              return h("span", elArr);
            } else {
              return h("span", row.realName || "--");
            }
          }
        },
        {
          title: "账号",
          key: "accountNo",
          width: 100,
          render(h, { row }) {
            return h("span", row.accountNo || "--");
          }
        },
        {
          title: "账号状态",
          key: "status",
          width: 80,
          render(h, { row }) {
            let mapping = {
              "4": "停用",
              "3": "正式",
              "2": "试用",
              "1": "申请",
              "0": "异常"
            };
            return mapping[row.accountStatus] || "--";
          }
        },
        {
          title: "结束日期",
          key: "endDate",
          width: 110,
          render(h, { row }) {
            return row.endDate ? row.endDate.substr(0, 11) : "--";
          }
        },
        {
          title: "责任人",
          key: "managerName",
          width: 100,
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.managerName || "--");
          }
        },
        {
          title: "机构名称",
          key: "orgName",
          width: 300,
          ellipsis: true,
          render(h, { row }) {
            return h("span", row.orgName || row.companyName || "--");
          }
        }
      ],
      initTableData: [],
      tableLoading: false,
      tableKey: "",
      groupId: "",
      sletectedTableData: []
    };
  },

  watch: {
    total: {
      handler(val) {
        if (val > 30) {
          this.setTableData();
        } else {
          this.tableData = this.initTableData;
        }
      },

      immediate: true
    }
  },

  methods: {
    onSelectionChange(selection) {
      this.sletectedTableData = selection || [];
    },

    setAsAdmin() {
      let ids = this.sletectedTableData.map(item => item.officialUserId - 0);
      this.initTableData.forEach(item => {
        if (ids.includes(item.officialUserId - 0)) {
          item.isAdmin = 1;
        }
      });
      this.tableKey = Date.now();
      this.sletectedTableData = [];
      this.$refs.table.selectAll(false);
      this.$Message.success("设置成功，点击确定后生效");
    },

    setAsNotAdmin() {
      let ids = this.sletectedTableData.map(item => item.officialUserId - 0);
      this.initTableData.forEach(item => {
        if (ids.includes(item.officialUserId - 0)) {
          item.isAdmin = 0;
        }
      });
      this.tableKey = Date.now();
      this.sletectedTableData = [];
      this.$refs.table.selectAll(false);
      this.$Message.success("设置成功，点击确定后生效");
    },

    show(groupId) {
      this.modal = true;
      this.groupId = groupId;
      if (this.groupId) {
        this.getGroupDetails();
      }
    },

    getSelectedUser(users) {
      this.initTableData = users;
      this.tableKey = Date.now();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.setTableData();
    },

    onPageChange(page) {
      this.currentPage = page;
      this.setTableData();
      this.sletectedTableData = [];
    },

    onOk() {
      this.$refs.form.validate(valid => {
        if (valid) {
          if (this.groupId) {
            this.editGroup();
          } else {
            this.addGroup();
          }
        } else {
          this.$Message.warning("请按红色字段填写内容！");
        }
      });
    },

    onCancel() {
      this.modal = false;
      this.clearData();
    },

    clearData() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.formData = {
        groupName: ""
      };
      this.tableData = [];
      this.initTableData = [];
      this.groupId = "";
      this.sletectedTableData = [];
       this.$refs.table.selectAll(false);
      this.$refs.form.resetFields();
    },

    getSubmitParams() {
      let params = {};
      params.groupName = this.formData.groupName;
      let userList = this.initTableData.map(item => ({
        officialUserId: item.officialUserId || item.userId,
        isAdmin: item.isAdmin || 0
      }));
      return {
        ...params,
        userList
      };
    },

    editGroup() {
      this.btnLoading = true;
      this.$http
        .putWithoutId(`CmGroup/${this.groupId}`, this.getSubmitParams())
        .then(res => {
          this.btnLoading = false;
          if (res.code === 20000) {
            this.$Message.success("编辑成功！");
            this.$emit("refreshTable");
            this.onCancel();
          } else {
            this.$Message.error("编辑失败！");
          }
        });
    },

    addGroup() {
      this.btnLoading = true;
      this.$http.post("CmGroup", this.getSubmitParams()).then(res => {
        this.btnLoading = false;
        if (res.code === 20000) {
          this.$Message.success("新增成功！");
          this.$emit("refreshTable");
          this.onCancel();
        } else {
          this.$Message.error("新增失败！");
        }
      });
    },

    managerAccount() {
      this.$refs.groupAccountList.show(this.initTableData);
    },

    // 设置表格的初始数据
    setTableData() {
      let endIndex = this.currentPage * this.pageSize;
      let startIndex = endIndex - this.pageSize;
      if (endIndex > this.total - 1) {
        this.tableData = this.initTableData.slice(startIndex);
      } else {
        this.tableData = this.initTableData.slice(startIndex, endIndex);
      }
    },

    getGroupDetails() {
      this.modalLoading = true;
      this.$http.get(`CmGroup/${this.groupId}`).then(res => {
        this.modalLoading = false;
        if (res.code === 20000) {
          this.$set(this.formData, "groupName", res.data.groupName);
          this.initTableData = res.data.groupAccounts;
        }
      });
    }
  }
};
</script>


<style lang="less" scoped>
.action-btn-wrap {
  margin: 15px;
}

.page-load {
  text-align: right;
  margin: 10px;
}
</style>
