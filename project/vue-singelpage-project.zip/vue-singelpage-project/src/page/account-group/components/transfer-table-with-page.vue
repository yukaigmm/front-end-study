<template>
    <div class="transfer-table">
         <div class="origin-table">
             <slot name="orginTitle"></slot>

             <div class="table-are">
                <Table
                   :data="oriTableData"
                   :columns="columns"
                   v-loading="originTableLoading"
                   @on-selection-change="onOriginSelectionChange"
                   element-loading-text="拼命加载中"
                   :key="originTableKey"
                   :height="tableHeight"
                   :row-class-name="setRowClassName"
                   border
                />    
             </div>

             <div class="page-load" v-if="ifShowOriginPage">
                   <Page 
                     size="small"
                     :total="originTotal"
                     placement="top"
                     :current="originCurrentPage"
                     :page-size="originPageSize"
                     @on-change="onOriginPageChange"
                     @on-page-size-change="onOriginPageSizeChange"
                     show-total
                     show-sizer
                     />
             </div>
         </div>    

         <div class="action-btn">
             <Button 
               type="primary" 
               :disabled="!canAdd"
               @click="addRow"
               >
                 添加＞＞
             </Button>
             <br>
             <Button 
               type="primary" 
               :disabled="!canDelete" 
               @click="deleteRow"
               style="margin-top:15px;">
                 ＜＜移除
             </Button>
         </div>

         <div class="target-table">
              <slot name="targetTitle"></slot>
              <div class="table-are">
                <Table
                   :key="targetTableKey"
                   :data="tarTableData"
                   :columns="columns"
                   :height="tableHeight"
                   v-loading="targetTableLoading"
                   @on-selection-change="onTargetSelectionChange"
                   element-loading-text="拼命加载中"
                   border
                />    
             </div>
             <div class="page-load" v-if="ifShowTargetPage">
                <Page 
                     size="small"
                     :total="targetTotal"
                     placement="top"
                     :current="targetCurrentPage"
                     :page-size="targetPageSize"
                     @on-change="onTargetPageChange"
                     @on-page-size-change="onTargetPageSizeChange"
                     show-total
                     show-sizer
                     />
             </div>
         </div>
    </div>    
</template>

<script>
import { unionBy } from "lodash";

export default {
  props: {
    ifShowOriginPage: {
      type: Boolean,
      default: false
    },
    ifShowTargetPage: {
      type: Boolean,
      default: false
    },
    columns: {
      type: [Object, Array],
      default: () => []
    },
    originTableData: {
      type: [Array],
      default: () => []
    },
    originTableLoading: {
      type: Boolean,
      default: false
    },
    originTotal: {
      type: [Number, String],
      default: 0
    },
    targetTableData: {
      type: [Array],
      default: () => []
    },
    targetTableLoading: {
      type: Boolean,
      default: false
    },

    transferKey: {
      type: String
    },
    tableHeight: {
      type: [String, Number]
    }
  },

  data() {
    return {
      originCurrentPage: 1,
      originPageSize: 10,
      targetCurrentPage: 1,
      targetPageSize: 10,
      canAdd: false,
      canDelete: false,
      addSelections: [],
      deleteSelections: [],
      originTableKey: "",
      targetTableKey: "",
      addRows: [],
      deleteRows: [],
      tarTableData: [],
      initTargetTableData: []
    };
  },

  watch: {
    targetTableData: {
      handler(val) {
        this.initTargetTableData = val;
        if (val.length) {
          this.$nextTick(() => {
            this.setTargetTableData();
          });
        } else {
          this.tarTableData = [];
        }
      }
    }
  },

  computed: {
    oriTableData() {
      let ids = this.initTargetTableData.map(item => item[this.transferKey]);
      let data = this.originTableData.map(item => {
        if (ids.includes(item[this.transferKey])) {
          item._disabled = true;
        } else {
          item._disabled = false;
        }
        return item;
      });
      return data;
    },

    targetTotal() {
      return this.initTargetTableData.length || 0;
    }
  },

  methods: {
    clearData() {
      this.addRows = [];
      this.deleteRows = [];
      this.tarTableData = [];
      this.initTargetTableData = [];
      this.originCurrentPage = 1;
      this.originPageSize = 10;
    },

    setInitDisabledRow() {
      let ids = this.initTargetTableData.map(item => item[this.transferKey]);
      this.originTableData.forEach(item => {
        if (ids.includes(item[this.transferKey])) {
          item._disabled = true;
        }
      });
      this.targetTableKey = Date.now();
    },

    onOriginPageChange(page) {
      this.originCurrentPage = page;
      this.getOriginTableData();
    },

    onOriginPageSizeChange(pageSize) {
      this.originPageSize = pageSize;
      this.getOriginTableData();
    },

    onTargetPageChange(page) {
      this.targetCurrentPage = page;
      this.setTargetTableData();
    },

    onTargetPageSizeChange(pageSize) {
      this.targetPageSize = pageSize;
      this.setTargetTableData();
    },

    // 获取源表格数据
    getOriginTableData() {
      let params = {
        pageNo: this.originCurrentPage,
        pageSize: this.originPageSize
      };
      this.$emit("getOriginTableData", params);
    },

    // 获取目标表格数据
    // 设置表格的初始数据
    setTargetTableData() {
      let endIndex = this.targetCurrentPage * this.targetPageSize;
      let startIndex = endIndex - this.targetPageSize;
      if (endIndex > this.total - 1) {
        this.tarTableData = this.initTargetTableData.slice(startIndex);
      } else {
        this.tarTableData = this.initTargetTableData.slice(
          startIndex,
          endIndex
        );
      }
      this.originTableKey = Date.now();
    },

    getData() {
      return {
        targetData: this.initTargetTableData || [],
        addRows: this.addRows || [],
        deleteRows: this.deleteRows || []
      };
    },

    // 选中源表格的行
    onOriginSelectionChange(selection) {
      if (selection && selection.length) {
        this.canAdd = true;
      } else {
        this.canAdd = false;
      }
      this.addSelections = JSON.parse(JSON.stringify(selection));
    },

    // 选中目标表格的行
    onTargetSelectionChange(selection) {
      if (selection && selection.length) {
        this.canDelete = true;
      } else {
        this.canDelete = false;
      }
      this.deleteSelections = JSON.parse(JSON.stringify(selection));
    },

    // 添加
    addRow() {
      let ids = this.addSelections.map(item => item[this.transferKey]);
      this.originTableData.forEach(item => {
        if (ids.includes(item[this.transferKey])) {
          item._disabled = true;
        }
      });

      this.initTargetTableData = [
        ...this.addSelections,
        ...this.initTargetTableData
      ];
      this.canAdd = false;
      this.addRows = unionBy(
        this.addRows,
        this.addSelections,
        this.transferKey
      );

      this.setTargetTableData();
      this.originTableKey = Date.now();
      this.addSelections = [];
    },

    // 移除
    deleteRow() {
      let ids = this.deleteSelections.map(item => item[this.transferKey]);
      this.initTargetTableData = this.initTargetTableData.filter(item => {
        return !ids.includes(item[this.transferKey]);
      });

      this.setTargetTableData();

      this.originTableData.forEach(item => {
        if (ids.includes(item[this.transferKey])) {
          item._disabled = false;
        }
      });
      this.originTableKey = Date.now();
      this.canDelete = false;
      this.deleteRows = unionBy(
        this.deleteRows,
        this.deleteSelections,
        this.transferKey
      );

      this.deleteSelections = [];
    },

    // 设置已选中的行的样式
    setRowClassName(row, index) {
      let ids = this.initTargetTableData.map(item => item[this.transferKey]);
      if (ids.includes(row[this.transferKey])) {
        return "disabeld-row";
      } else {
        row._disabled = false;
        return "";
      }
    },

    //  获取选中的行
    getSelectedRow() {
      return JSON.stringify(JSON.stringify(this.initTargetTableData));
    }
  }
};
</script>

<style lang="less" scoped>
.transfer-table {
  display: flex;
  justify-content: space-around;
  .action-btn {
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin-right: 15px;
    margin-left: 15px;
  }
}

.page-load {
  text-align: right;
  margin: 10px;
}
</style>
