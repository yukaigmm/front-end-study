<template>
   <div>
     <div class="search-area">
        <Form :model="formData" :label-width="90" @keydown.enter.native.prevent="search">
           <Row>
               <i-col span="8">
                  <form-item prop="name" label="组名">
                        <Input 
                          v-model.trim="formData.groupName"
                          placeholder="请输入组名"
                        />
                  </form-item>
               </i-col>

               <i-col span="8" style="margin-left:20px;">
                  <Button type="primary" @click="search">搜索</Button>
               </i-col>
           </Row>
       </Form>
     </div>
    

       <!-- <div class="action-btn-wrap">
           <Button type="primary" @click="addGroup">新建分组</Button>
       </div> -->

       <div class="table-area">
              <Table 
                :data="tableData"
                :columns="columns"
                border
                v-loading="tableLoading"
                element-loading-text="拼命加载中"

              />
       </div>

       <div class="page-load">
             <Page 
               :total="total"
               placement="top"
               :current="currentPage"
               :page-size="pageSize"
               @on-change="onPageChange"
               @on-page-size-change="onPageSizeChange"
               show-elevator
               show-total
               show-sizer
             />
       </div>

       <group-operation-modal 
          @refreshTable="search"
          ref="groupOperationModal"
          :showType="showType"
       />
   </div>    
</template>

<script>
import groupOperationModal from "./components/group-operation.vue";
import $ from "jquery";
import getMinusNumber from "@/mixins/getMinusNumber.js";

export default {
  components: {
    groupOperationModal
  },
  mixins: [getMinusNumber],

  data() {
    return {
      showType: "",
      formData: {
        groupName: ""
      },
      tableLoading: false,
      tableData: [],
      columns: [
        {
          title: "组名",
          key: "groupName",
          render(h, { row }) {
            return h("span", row.groupName||"--");
          }
        },
        {
          title: "账号数",
          key: "accountCount",
          render(h, { row }) {
            return h("span", row.accountCount || 0);
          }
        },
        {
          title: "创建时间",
          key: "createtime",
          render(h, { row }) {
            return h("span", row.createtime.substr(0, 11)||"--");
          }
        },
        {
          title: "创建人",
          key: "creator",
          render(h, { row }) {
            return h("span", row.creator||"--");
          }
        },
        {
          title: "操作",
          key: "action",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.editGroup(row.id);
                    }
                  }
                },
                "编辑"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.deleteGroup(row.id);
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ],
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  mounted() {
    this.getGroupList();
    this.setMaxHeightOfFixedTable(
      ".content-body.ivu-col",
      [".search-area", ".action-btn-wrap", ".page-load"],
      ".table-area"
    );
  },

  methods: {
    search() {
      this.pageSize = 10;
      this.currentPage = 1;
      this.getGroupList();
    },

    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass,
      cutElementClassArray,
      targetTableClass
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - 142;
      let minusNumber = this.getMinusNumberOfFixedTable();
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    addGroup() {
      this.showType = "add";
      this.$refs.groupOperationModal.show();
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getGroupList();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getGroupList();
    },

    editGroup(id) {
      this.showType = "edit";
      this.$refs.groupOperationModal.show(id);
    },

    deleteGroup(id) {
      this.$Modal.confirm({
        title: "删除分组",
        content: "确认删除该分组吗？",
        loading: true,
        onOk: () => {
          this.$http.del("CmGroup", id).then(res => {
            this.$Modal.remove();
            if (res.code === 20000) {
              this.$Message.success("删除成功!");
              this.search();
            } else {
              this.$Message.error("删除失败!");
            }
          });
        }
      });
    },

    getGroupList() {
      let params = {
        pageNo: this.currentPage,
        pageSize: this.pageSize,
        ...this.formData
      };

      this.tableLoading = true;
      this.$http.get("CmGroup", params).then(res => {
        this.tableLoading = false;
        if (res.code === 20000) {
          this.tableData = res.data.records;
          this.total = res.data.total;
        } else {
          this.$Message.error("获取分组列表失败！");
        }
      });
    }
  }
};
</script>

<style lang="less" scoped>
.action-btn-wrap {
  margin: 15px 0;
}

.page-load {
  margin: 15px;
  text-align: right;
}
</style>

