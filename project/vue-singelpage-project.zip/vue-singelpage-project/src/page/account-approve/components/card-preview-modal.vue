<template>
   <Modal
     v-model="modal"
     width="650"
     :mask-closable='false'
     @on-cancel="cancel"
     footer-hide
   >
    <div class="card-preview-container" ref="cardPreviewContainer">
      <Spin fix v-show="modalLoading">
        <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
        <div>拼命加载中...</div>
      </Spin>
      <img v-if="src != undefined" class="card-preview-img" ref="imgPreview" :src="src" alt="--">
    </div>
   </Modal>    
</template>


<script>

export default {
  components: {
  },

  props: {
  },

  computed: {
  },

  data() {
    return {
      modal: false,
      modalLoading: false,
      src: ""
    };
  },

  watch: {
  },

  methods: {
    open(src){
      let baseUrl;
      let picSrc = src;
      this.modal = true;
      this.modalLoading = true;
      if (src && src.includes("/Onstage/")) {
        baseUrl =
          process.env.NODE_ENV === "production" ||
          process.env.NODE_ENV === "test"
            ? "https://fof.simuwang.com/"
            : "https://master-test.simuwang.com/";
      } else {
        baseUrl =
          process.env.NODE_ENV === "production"
            ? " http://static.simuwang.com/"
            : "https://static-test-ali.simuwang.com/";
        picSrc = `Uploads/crm/${src}`;
      }
      this.src = `${baseUrl}${picSrc}`;
      if(src){
        this.$nextTick(() => {
          this.$refs.imgPreview.onload = this.imgOnload;
          this.$refs.imgPreview.onerror = this.imgLoadError;
        })
      }else{
        this.modalLoading = false;
      }
    },
    cancel(){
      this.modal = false;
      this.src = ""
    },
    imgOnload(){
      this.modalLoading = false;
    },
    imgLoadError(){
      this.modalLoading = false;
    }
  }
};
</script>


<style lang="less" scoped>
  .card-preview-container{
    height: 360px;
    display: flex;
    justify-content: center;
    align-items: center;
    .card-preview-img{
      max-height: 100%;
      max-width: 100%;
    }
  }
</style>
