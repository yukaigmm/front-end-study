<template>
   <Modal
     v-model="modal"
     width="1000"
     :mask-closable='false'
     @on-cancel="cancel"
     title="账号审批"
   >
    <div slot="footer">
        <Button type="primary" @click="ok">确定</Button>
        <Button @click="cancel">取消</Button>
    </div>
    <div class="process-status-container">
      <Spin fix v-show="modalLoading">
        <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
        <div>拼命加载中...</div>
      </Spin>
      <div class="account-approve-set-status-form">
        <Form ref="form" :model="form" :label-width="80" :rules="rules" inline>
          <FormItem label="名片" class="linkman-card" style="width: 440px">
            <img :src="imgSrc" :alt="linkname+'名片'" style="width: 100%">
          </FormItem>
          <FormItem label="联系人" style="width: 500px">
            <span>{{`${orgName}  ${linkname}`}}</span>
          </FormItem>
          <FormItem label="手机号" style="width: 300px">
            <span>{{phone}}</span>
          </FormItem>
          <FormItem prop="orgId" label="公司名称" style="width: 500px" v-if="form.status == 2">
              <Input style="display:none" v-model="form.orgId"></Input>
              <company-input ref="companyInput" @getChosenOrg="getChosenOrg"></company-input>
              <Button @click="clearParentOrg" type="ghost" size="small">清空</Button>
          </FormItem>
          <FormItem prop="initPsw" label="初始密码" style="width: 380px" v-if="form.status == 2">
              <Input v-model="form.initPsw" disabled :placeholder="initPswPlaceholder"></Input>
          </FormItem>
          <FormItem prop="ifNotice" label="是否发送短信" style="width: 300px" :label-width="100" v-if="form.status == 2">
            <Checkbox v-model="form.ifNotice" :true-value="1" :false-value="0"/>
          </FormItem>
          <FormItem prop="remark" label="审批备注">
            <Input type="textarea" :rows="4" v-model.trim="form.remark" :placeholder="`请输入${approveText}的原因`"></Input>
          </FormItem>
        </Form>
      </div>
    </div>
   </Modal>    
</template>


<script>
import companyInput from "./choose-org-input.vue";
export default {
  components: {
    companyInput
  },

  props: {
  },

  computed: {
    approveText(){
      return this.form.status == 2 ? "审批通过" : "审批不通过"
    },
    imgSrc(){
      let picSrc = this.src;
      let baseUrl;
      if (this.src && this.src.includes("/Onstage/")) {
        baseUrl =
          process.env.NODE_ENV === "production" ||
          process.env.NODE_ENV === "test"
            ? "https://fof.simuwang.com/"
            : "https://master-test.simuwang.com/";
      } else {
        baseUrl =
          process.env.NODE_ENV === "production"
            ? " http://static.simuwang.com/"
            : "https://static-test-ali.simuwang.com/";
        picSrc = `Uploads/crm/${this.src}`;
      }
      return `${baseUrl}${picSrc}`;
    }
  },

  data() {
    return {
      modal: false,
      modalLoading: false,
      orgName: "",
      linkname: "",
      src: "",
      phone: "",
      form: {
        remark: "",
        initPsw: ""
      },
      initPswPlaceholder: "",
      rules: {
        orgId: [{required: true, message:"请选择公司名称",trigger: "change"}],
        remark: [{required: true, message:`请输入审批备注`}]
      }
    };
  },

  watch: {
  },

  methods: {
    open(params){
      this.linkname = params.linkname;
      this.phone = params.phone;
      this.src = params.visitingCardUrl;
      this.modal = true;
      this.$set(this.form, "status", params.status);
      this.form.id = params.id;
      this.form.ifNotice = params.ifNotice;
      if(params.status === 2){
        // 如果是官网注册过的，就提示初始密码是官网密码；否则就给用户生成一个随机的初始密码
        if(params.isOfficialUser == 1){
          this.form.initPsw = "";
          this.initPswPlaceholder = "账号已经在官网注册，初始密码为官网密码"
        }else{
          this.form.initPsw = `fof${(Math.random()*10000).toFixed(0)}`;
          // this.form.ifNotice = 1;
        }
      }
    },
    resetModal(){
      this.form = {
        remark: "",
        id: "",
        orgId: "",
        status: "",
        initPsw: "",
      };
      this.$refs.form.resetFields();
      this.orgName = "",
      this.modal = false;
    },
    cancel(){
      this.resetModal();
      this.$emit("cancelApprove");
    },
    ok(){
      // 同意和拒绝用的是同一个接口，返回数据以后直接回写备注和状态到 table 中，不刷新
      this.modalLoading = true;
      this.$refs.form.validate((valid) => {
        if(valid){
          let params = JSON.parse(JSON.stringify(this.form));
          delete params.id;
          this.$http.post(`accounts/apply/change/${this.form.id}`,params).then((res) => {
            this.modalLoading = false;
            if(res.code === 20000){
              this.$Message.success("审批账号成功");
              if(this.form.status == 2){
                this.$emit("updateAgreeTableData",{accountId: res.data.accountId, remark: res.data.remark});
              }else{
                this.$emit("updateRejectTableData",{remark: res.data.remark})
              }
              this.resetModal();
            }
          })
        }else{
          this.modalLoading = false;
        }
      })
    },
    clearParentOrg(){
      this.orgName = "";
      this.form.orgId = "";
      this.$refs.companyInput.clearCompanyName();
    },
    getChosenOrg({title, id}){
      // iview表单验证的bug，input里面如果是数字，表单验证会出问题，因此需要拼接成字符串
      this.form.orgId = ""+id;
      this.getOrgName(id);
    },
    // 根据拿到的orgId获取公司详细的名称
    getOrgName(orgId){
      let params = {
            showBread: 1,
            showContacts: 0
        }
      this.modalLoading = true;
      let orgNameArr = [];
      this.$http.get(`orgDocument/orgOtherInfo/${orgId}`,params).then((res) => {
          this.modalLoading = false;
          if(res.code === 20000){
              let bread = res.data.bread || [];
              orgNameArr = bread.map((item) => {
                  return item.title
              });
              this.orgName = orgNameArr.join(" ");
          }
      })
    }
  }
};
</script>


<style lang="less">
  .account-approve-set-status-form{
    .linkman-card{
      height: 260px;
      float: left;
      .ivu-form-item-content{
        border: 1px solid #ccc;
        height: 100%;
        text-align: center;
      }
    }
  }
</style>
