<template>
      <Poptip placement="bottom-start" width="400" @on-ok="getChosenNode" confirm cancel-text="">
        <Input v-model.trim="outerKeywords" placeholder="请输入关键字,如：总部 分部" style="width:300px" @input="getOuterList">
        </Input>
        <div slot="title">
          <Spin fix v-if="outerListLoading">
            <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
            <div>加载中...</div>
          </Spin>
          <div v-else>
            <el-tree :data="outerList" check-strictly class="org-tree" show-checkbox node-key="id" ref="tree" :auto-expand-parent="true" :props="defaultProps" @check-change="currentChange" :default-expanded-keys="expandIdArr">
            </el-tree>
          </div>
        </div>
      </Poptip>
</template>
<script>
import { fetchGrid } from "@/service/getData";
export default {
  data() {
    return {
      outerKeywords: "",
      outerListLoading: false,
      outerList: [],
      // 默认树节点信息
      defaultProps: {
        children: "children",
        label: "title"
      },
      // 最后选中的上级机构
      lastOrg: {},
      // 展开的树结构
      expandIdArr: [],
      clearId: ""
    };
  },

  methods: {
    getChosenNode() {
      this.outerKeywords = this.lastOrg.title;
      this.$emit("getChosenOrg", this.lastOrg);
      // this.cancel();
    },

    // 获取上级机构列表
    getOuterList() {
      this.outerList = [];
      if (!this.outerKeywords) {
        return;
      }
      let outerKeywords = this.outerKeywords.trim().split(/[ ]+/);
      let params = {
        // 是否显示部门下的人
        showPerson: false,
        // 搜索类型是机构
        type: 2,
        keywords: outerKeywords,
        disabled: false,
        disabledKey: "disabled"
      };
      this.outerListLoading = true;
      clearTimeout(this.clearId);
      this.clearId = setTimeout(() => {
        fetchGrid("visit/gettreebytype", params).then(res => {
          this.outerList = [
            {
              id: -1,
              checked: false,
              disabled: true,
              expand: true,
              title: "所有",
              children: [].concat(res.data)
            }
          ];
          this.expandIdArr.unshift(-1);
          this.lastTreeData = [];
          this.outerListLoading = false;
        });
      }, 500);
    },

    // 手动设置选中状态，确保只能选中一个
    currentChange(data, isChecked) {
      if (isChecked) {
        this.$refs.tree.setCheckedNodes([data]);
        this.lastOrg = {
          id: data.id,
          title: data.title
        };
        // this.outerKeywords = data.title;
      } 
    },
    clearCompanyName(){
      this.outerKeywords = "";
      this.outerList = [];
    }
  }
};
</script>
<style lang='less' scoped>
.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}
@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
