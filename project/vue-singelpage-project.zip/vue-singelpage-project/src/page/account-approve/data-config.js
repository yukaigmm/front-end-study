let dataConfig = function(self) {
    return {
        // userSourceOptions: [
        //    {
        //     name: "PC端",
        //     value: 1
        //   },
        //   {
        //     name: "移动端（扫码）",
        //     value: 2
        //   },
        //   {
        //     name: "banner申请",
        //     value: 3
        //   },
        //   {
        //     name: "批量导入",
        //     value: 4
        //   },
        //   {
        //     name: "CRM单条新增",
        //     value: 5
        //   }
        // ],
        statusOptions: [{
            name: "审批通过",
            value: "2"
          },
          {
            name: "审批拒绝",
            value: "3"
          },
          {
            name: "未审批",
            value: "1"
          }
        ],
        isFofUserOptions: [{
            name: "是",
            value: "1"
          },
          {
            name: "否",
            value: "2"
          },
        ],
        columns: [{
            title: "联系人",
            key: "linkname",
            // fixed: "left",
            width: 90,
            render: (h, {row}) => {
                return h("span", row.linkname || "--");
            }
          },
          {
            title: "个人名片",
            key: "visitingCardUrl",
            align: "center",
            width: 100,
            render: (h, {row}) => {
                if(row.visitingCardUrl){
                    return h("i", {
                        "class": {
                            "id-card": true
                        },
                        on: {
                            click: () => {
                                self.$refs.imgPreviewModal.open(row.visitingCardUrl);
                            }
                        }
                    })
                }else{
                    return h("span", "--");
                }
            },
          },
          {
            title: "公司",
            key: "companyName",
            width: 150,
            render: (h, {row}) => {
                return h("span", row.companyName || "--");
            }
          },
          {
            title: "联系电话",
            key: "phone",
            width: 100,
            render: (h, {row}) => {
                return h("span", row.phone || "--");
            }
          },
          {
            title: "组合大师",
            key: "isFofUser",
            width: 100,
            render: (h, {row}) => {
              let map = {
                1: "已注册",
                2: "未注册"
              }
              if (row.isFofUser == 1) {
                return h("a", {
                  href: "javascript:void(0)",
                  on: {
                    click: () => {
                      self.$refs.accountEditModal.show(row.accountId, row.phone, 1, !!row.contractId); 
                    }
                  }
                }, map[row.isFofUser])
              }
              return h("span", map[row.isFofUser] || "--");
            },
          },
          {
            // 文档里面搜索条件和列表数据表示的map不一致，卅林说以搜索条件为准。
            title: "主站",
            key: "isOfficialUser",
            width: 100,
            render: (h, {
              row
            }) => {
              let map = {
                1: "已注册",
                2: "未注册"
              }
              return h("span", map[row.isOfficialUser] || "--");
            },
          },
          {
            title: "申请来源",
            key: "sourceName",
            width: 130,
            render: (h, {
              row
            }) => {
              return h("span", row.sourceName || '--');
            },
          },
          {
            title: "来源渠道",
            key: "channelName",
            width: 130,
            render: (h, {
              row
            }) => {
              return h("span", row.channelName || '--');
            },
          },
          // {
          //   title: "用户来源",
          //   key: "userSource",
          //   width: 100,
          //   render: (h, {
          //     row
          //   }) => {
          //     let map = {
          //       "1": "PC端",
          //       "2": "移动端（扫码）",
          //       "3": "banner申请",
          //       "4": "批量导入",
          //       "5": "CRM单条新增"
          //     };
          //     return map[row.userSource] || '--';
          //   },
          // },
          {
            title: "审批状态",
            key: "status",
            width: 130,
            // 如果用户已注册组合大师，且没有审批状态，则不需要再审批，直接将审批状态设置为--
            // 如果主站已注册，则在审批时提示密码为主站密码
            // 如果主站未注册，则前端生成密码
            render: (h, {
              row
            }) => {
              let selectOptions = [{
                  name: "通过",
                  value: 2
                },
                {
                  name: "拒绝",
                  value: 3
                },
                {
                  name: "未审批",
                  value: 1
                }
              ];
              let map = {
                "2": "通过",
                "3": "拒绝",
                "1": "未审批"
              };
              if (row.isFofUser == 1 && row.status == null) {
                return h("span", "--");
              }
              if (+row.status === 1) {
                // return h("Select", {
                //     props: {
                //       value: +row.status
                //     },
                //     on: {
                //       "on-change": (val) => {
                //         let params = {
                //           id: row.id,
                //           status: val,
                //           isOfficialUser: row.isOfficialUser
                //         }
                //         self.$refs.statusModal.open(params);
                //         self.$set(row, "status", val);
                //         self.currentRow = row;
                //       }
                //     }
                //   },
                //   selectOptions.map(option => {
                //     return h("Option", {
                //       props: {
                //         value: option.value,
                //         key: option.value
                //       }
                //     }, option.name);
                //   })
                // );
                return h("div",[
                    h("Button", {
                        props: {
                            type: "primary",
                            size: "small",
                            // 可能给用户在crm或其他渠道开了组合大师，但是没有处理用户的申请，
                            // 因此用户的状态还是未审批，这种情况下置灰按钮，不允许再设置账号状态
                            disabled: +row.isFofUser === 1
                        },
                        on: {
                            click: () => {
                                let params = {
                                    id: row.id,
                                    status: 2,
                                    isOfficialUser: row.isOfficialUser,
                                    visitingCardUrl: row.visitingCardUrl,
                                    linkname: row.linkname,
                                    phone: row.phone,
                                    ifNotice: 1,
                                }
                                self.$refs.statusModal.open(params);
                                // self.$set(row, "status", 1);
                                self.currentRow = row;
                            }
                        }
                    },"通过"),
                    h("Button", {
                        props: {
                            type: "error",
                            size: "small",
                            disabled: +row.isFofUser === 1
                        },
                        on: {
                            click: () => {
                                let params = {
                                    id: row.id,
                                    status: 3,
                                    isOfficialUser: row.isOfficialUser,
                                    visitingCardUrl: row.visitingCardUrl,
                                    linkname: row.linkname,
                                    phone: row.phone,
                                    ifNotice: 0
                                }
                                self.$refs.statusModal.open(params);
                                // self.$set(row, "status", 2);
                                self.currentRow = row;
                            }
                        }
                    },"拒绝"),
                ])
              } else {
                return h("span", map[row.status] || "--");
              }
            },
          },
          {
            title: "申请时间",
            key: "applyDate",
            width: 160,
            render: (h, {row}) => {
                return h("span", row.applyDate || "--");
            }
          },
          {
            title: "备注",
            key: "remark",
            width: 200,
            render: (h, {
              row
            }) => {
              if (+row.status === 0 || !row.remark) {
                return h("span", "--")
              } else {
                return h("span", `处理者：${row.handleUserName}${row.handleMobile ? "（"+row.handleMobile+"）" : ""}，原因：${row.remark || ""}`);
              }
            },
          }
        ],
      }
}

module.exports = dataConfig;