<template>
  <div class="account-approve-container">
    <div class="account-approve-search-form">
      <Form ref="form" :model="form" inline :label-width="80" @keydown.enter.native.prevent="search">
        <FormItem prop="keyword" label="关键字">
          <Input type="text" v-model.trim="form.keyword" placeholder="请输入公司名称/手机号/姓名/审批人" clearable></Input>
        </FormItem>
        <FormItem prop="applyDate" label="申请时间">
          <DatePicker
            type="daterange"
            v-model="form.applyDate"
            placement="bottom-end"
            placeholder="请选择申请时间"
            @on-change="applyDateChange"
          ></DatePicker>
        </FormItem>
        <FormItem prop="sourceId" label="申请来源">
          <Select
          ref="sourceSelect"
          placeholder= "请输入关键字"
          v-model="form.sourceId"
          clearable
          filterable
          remote
          :remote-method="getSourceOptions" 
          :loading="searchLoading"
          @on-change="sourceChange"
          @on-clear="clearSourceSearch"
          @on-query-change="queryChange"
          >
            <Option
              v-for="item in sourceOptions"
              :key="item.id"
              :value="item.id"
            >{{item.sourceName}}</Option>
          </Select>
        </FormItem>
        <FormItem prop="channelId" label="来源渠道">
          <Select
          ref="sourceSelect"
          placeholder= "请输入关键字"
          v-model="form.channelId"
          clearable
          filterable
          remote
          :remote-method="getChannelOptions" 
          :loading="searchLoading"
          @on-change="sourceChange"
          @on-clear="clearChannelSearch"
          @on-query-change="queryChange"
          >
            <Option
              v-for="item in channelOptions"
              :key="item.id"
              :value="item.id"
            >{{item.sourceName}}</Option>
          </Select>
        </FormItem>
        <!-- <FormItem prop="userSource" label="用户来源">
          <Select v-model="form.userSource" clearable>
            <Option
              v-for="item in userSourceOptions"
              :key="item.value"
              :value="item.value"
            >{{item.name}}</Option>
          </Select>
        </FormItem> -->
        <FormItem prop="status" label="审批状态">
          <Select v-model="form.status" clearable>
            <Option
              v-for="item in statusOptions"
              :key="item.value"
              :value="item.value"
            >{{item.name}}</Option>
          </Select>
        </FormItem>
        <FormItem prop="isFofUser" label="已注册组合大师" :label-width="114">
          <Select v-model="form.isFofUser" clearable>
            <Option
              v-for="item in isFofUserOptions"
              :key="item.value"
              :value="item.value"
            >{{item.name}}</Option>
          </Select>
        </FormItem>
        <FormItem>
          <Button type="primary" @click="search">搜索</Button>
          <Button @click="reset">重置</Button>
        </FormItem>
      </Form>
    </div>
    <div class="account-approve-table">
      <Table :height="tableHeight" width="100%" v-loading="loading" element-loading-text="拼命加载中" border :columns="columns" :data="tableData"></Table>
    </div>
    <div class="account-approve-table-pagination">
      <Page
        style="float: right"
        :current="currentPage"
        :page-size="pageSize"
        :total="total"
        placement="top"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizeChange"
        show-elevator
        show-sizer
        show-total
      ></Page>
    </div>
    <img-preview-modal ref="imgPreviewModal"></img-preview-modal>
    <status-modal ref="statusModal" @updateAgreeTableData="updateAgreeTableData" @updateRejectTableData="updateRejectTableData" @cancelApprove="cancelApprove"></status-modal>
    <account-edit-modal ref="accountEditModal"></account-edit-modal>
  </div>
</template>

<script>
import imgPreviewModal from "./components/card-preview-modal.vue";
import statusModal from "./components/set-process-status-modal.vue";
import accountEditModal from "@/page/account-justify/components/account-edit-modal.vue";
import dataConfig from "./data-config.js";
import $ from "jquery";
import {mapGetters} from "vuex";
export default {
  components: {
    imgPreviewModal,
    statusModal,
    accountEditModal
  },
  data() {
    let config = dataConfig(this);
    return {
      loading: false,
      searchLoading: false,
      tableHeight: 300,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      form: {
        keyword: "",
        applyDate: [],
        userSource: "",
        status: "1",
        isFofUser: "2"
      },
      sourceOptions: [],
      channelOptions: [],
      tableData: [],
      currentRow: {},
      ...config,
    };
  },

  mounted() {
    this.getTableData();
    this.setTableHeight();
    this.getSourceOptions("");
    this.getChannelOptions("");
    window.addEventListener("resize", this.setTableHeight);
  },
  computed: {
    ...mapGetters({
      userInfo: "getUser",
    })
  },
  methods: {
    // 获取tableData
    getTableData(){
      this.loading = true;
      let params = Object.assign({}, this.form, {pageSize: this.pageSize, pageNo: this.currentPage});
      delete params.start;
      delete params.end;
      params.applyDate = params.applyDate.length > 1 ? params.applyDate : [];
      this.$http.get("accounts/apply",params).then((res) => {
        this.loading = false;
        if(res.code === 20000){
          this.tableData = res.data.records;
          this.total = res.data.total;
        }
      })
    },
    search() {
      this.pageSize = 10;
      this.currentPage = 1;
      this.getTableData();
    },
    reset() {
      this.form = {
        keyword: "",
        applyDate: [],
        userSource: "",
        status: "",
        isFofUser: "",
      };
      this.currentPage = 1;
      this.pageSize = 10;
      this.getTableData();
    },
    onPageChange(page){
      this.currentPage = page;
      this.getTableData();
    },
    onPageSizeChange(pageSize){
      this.pageSize = pageSize;
      this.getTableData();
    },
    // 表单数据处理
    getSourceOptions(query){
      this.searchLoading = true;
      this.$http.get("accounts/source",{keyword: query, dataType: 1}).then((res) => {
        if(res.code === 20000){
          this.searchLoading = false;
          this.sourceOptions = res.data;
        }
      })
    },
    getChannelOptions(query){
      this.searchLoading = true;
      this.$http.get("accounts/source",{keyword: query, dataType: 2}).then((res) => {
        if(res.code === 20000){
          this.searchLoading = false;
          this.channelOptions = res.data;
        }
      })
    },
    clearSourceSearch(){
      this.getSourceOptions("");
    },
    clearChannelSearch(){
      this.getChannelOptions("");
    },
    sourceChange(val){
    },
    queryChange(val){
    },
    applyDateChange(val) {
      if(val[0] == undefined || val[1] == undefined){
        this.form.applyDate = [];
      }else{
        this.form.applyDate = val;
      }
    },
    // 更新成功之后，直接回写table，不刷新
    updateAgreeTableData({accountId, remark}){
      this.$set(this.currentRow, "accountId", accountId || null);
      this.$set(this.currentRow, "isFofUser", 1);
      this.$set(this.currentRow, "status", 2);
      this.$set(this.currentRow, "remark", remark);
      this.$set(this.currentRow, "handleUserName", this.userInfo.trueName);
    },
    // 拒绝操作之后也直接回写table，不刷新
    updateRejectTableData({remark}){
      this.$set(this.currentRow, "status", 3);
      this.$set(this.currentRow, "remark", remark);
      this.$set(this.currentRow, "handleUserName", this.userInfo.trueName);
    },
    cancelApprove(){
      this.$set(this.currentRow, "status", 1);
    },
    // 动态设置table高度
    setTableHeight(){
      let _this = this;
      if(this.timer){
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        _this.tableHeight = $(_this.$el).height() - $(_this.$el).find(".account-approve-search-form").height() - 50;
      }, 500);
    },
  },
  watch: {
    "form.sourceId": {
      handler(val){
      },
      deep: true
    }
  }
};
</script>

<style lang="less">
.account-approve-container{
  height: 100%;
}
// form
.account-approve-search-form {
  .ivu-form-item {
    width: 280px;
    .ivu-date-picker {
      width: 200px;
    }
  }
}
// table
.account-approve-table{
  i.id-card{
    display: inline-block;
    width: 16px;
    height: 16px;
    background-position: -0px -72px;
    background-image: url("../../assets/admin_01.png");
    background-repeat: no-repeat;
    overflow: hidden;
    cursor: pointer;
    &:hover{
      background-position: 0 -88px;
    }
  }
}
// pagination
.account-approve-table-pagination{
  margin-top: 10px;
}
</style>

