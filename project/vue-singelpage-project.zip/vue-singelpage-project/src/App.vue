<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style lang="less">

html {
  height: 100%;
}

body {
  margin: 0;
  padding: 0;
  border: none;
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  overflow: hidden;
}

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /*text-align: center;*/
  color: #2c3e50;
  height: 100%;
}
.ivu-btn{
  margin-right: 6px;
}

  .ivu-tabs-tab-active {
    border-bottom: 3px solid #2d8cf0;
  }
  .ivu-tabs-ink-bar{
    display: none !important;
  }

</style>
