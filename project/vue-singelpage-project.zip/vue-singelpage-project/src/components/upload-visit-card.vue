<template>
  <div>
    <Upload
      v-loading="imgLoading"
      element-loading-text="上传中，请稍候..."
      :show-upload-list="ifShowUploadList"
      accept="image/*"
      :action="actionUrl"
      :on-error="onUploadError"
      :on-success="onUploadSuccess"
      :before-upload="beforeUpload"
      :style="uploadStyle"
      :data="data"
      ref="upload"
    >
      <slot></slot>
    </Upload>
  </div>
</template>

<script>
export default {
  props: {
    ifShowUploadList: {
      type: Boolean,
      default: false
    },
    actionUrl: {
      type: String,
      default: ""
    },
    uploadStyle: {
      type: [Object, String],
      default: () => ({})
    },
    data: {
      type: [Object, String],
      default: () => ({})
    }
  },

  data() {
    return {
      imgLoading: false
    };
  },
  methods: {
    // 上传之前先清空,保证只能上传最后一条文件
    beforeUpload(file) {
      this.$refs.upload.clearFiles();
      this.imgLoading = true;
      this.uglifyPic(file, "formData");
      return false;
    },

    clearFiles() {
      this.$refs.upload.clearFiles();
    },

    // 上传失败的回调
    onUploadError(error, file, fileList) {
      this.imgLoading = false;
      this.$Message.error("上传失败！");
    },

    // 上传成功的回调
    onUploadSuccess(response, file, fileList) {
      let res = response;
      this.imgLoading = false;
      if (res.code === 20000) {
        this.$Message.success("上传成功！");
        this.$emit("getResponse", res);
      } else {
        this.$Message.error(`上传失败：${res.msg}`);
      }
    },

    // 压缩名片
    uglifyPic(file) {
      let format = file.type;
      if (format.indexOf("image/") == -1) {
        this.$Message.warning({
          content: "请上传正确的文件！",
          duration: 3
        });
        this.imgLoading = false;
        return;
      }
      if (!window.FileReader) {
        this.imgLoading = false;
        return;
      }

      try {
        let reader = new FileReader();
        reader.readAsDataURL(file);
        let _this = this;
        reader.onload = function() {
          let result = this.result;
          let img = new Image();
          img.src = result;

          if (img.complete) {
            _this.getImgData(img, format);
          } else {
            img.onload = _this.getImgData.bind(_this, img, format);
            img.onerror = () => {
              _this.imgLoading = false;
              _this.$Message.warning({
                content: "文件内容错误！",
                duration: 3
              });
            };
          }
        };
      } catch (e) {
        console.error(e);
      }
    },

    // canvas重绘、压缩图片
    condense(img) {
      let canvas = document.createElement("canvas");
      let tCanvas = document.createElement("canvas");
      let ctx = canvas.getContext("2d");
      let tctx = tCanvas.getContext("2d");
      let width = img.width;
      let height = img.height;
      let ratio;
      //如果图片大于四百万像素，计算压缩比并将大小压至400万以下
      if ((ratio = (width * height) / 4000000) > 1) {
        ratio = Math.sqrt(ratio);
        width /= ratio;
        height /= ratio;
      } else {
        ratio = 1;
      }

      canvas.width = width;
      canvas.height = height;

      // 底色
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // 如果图片像素大于100万则使用瓦片绘制
      let count;
      if ((count = (width * height) / 1000000) > 1) {
        count = ~~(Math.sqrt(count) + 1);
        let nw = ~~(width / count);
        let nh = ~~(height / count);
        tCanvas.width = nw;
        tCanvas.height = nh;
        for (let i = 0; i < count; i++) {
          for (let j = 0; j < count; j++) {
            tctx.drawImage(
              img,
              i * nw * ratio,
              j * nh * ratio,
              nw * ratio,
              nh * ratio,
              0,
              0,
              nw,
              nh
            );
            ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
          }
        }
      } else {
        ctx.drawImage(img, 0, 0, width, height);
      }

      let data = canvas.toDataURL("image/jpeg", 0.3);
      tCanvas.width = tCanvas.height = canvas.height = canvas.width = 0;
      return data;
    },

    // 获取压缩后的图片
    getImgData(img, format) {
      let pic = this.condense(img);
      let text = window.atob(pic.split(",")[1]);
      let buffer = new Uint8Array(text.length);

      for (let i = 0, len = text.length; i < len; i++) {
        buffer[i] = text.charCodeAt(i);
      }
      let blob = this.getBlob([buffer], format);
      this.getImgFormData(blob, format);
    },

    /**
     *
     * @param {*binary} blob 二进制图片
     * @param {*string} format 图片格式
     */
    getImgFormData(blob, format) {
      let type = format.split("/")[1];
      let formData = new FormData();
      formData.append("fileType", "visitingCard");
      formData.append("file", blob, `${Date.now()}.${type}`);
      try {
        this.$http.post(`${this.actionUrl}`, formData).then(res => {
          this.imgLoading = false;
          if (res.code === 20000 || res.code === 21000) {
            this.$Message.success("上传成功！");
            this.$emit("getResponse", res);
          } else {
            this.$Message.error(`上传失败：${res.msg}`);
          }
        });
      } catch (e) {
        console.error(e);
        this.$Message.error("上传失败！");
      }
    },

    getBlob(buffer, format) {
      try {
        return new Blob(buffer, {
          type: format
        });
      } catch (e) {
        let bb = new (window.BlobBuilder ||
          window.WebkitBlobBuilder ||
          window.MSBlobBuilder)();
        bb.append(buffer);

        return bb.getBlob(format);
      }
    }
  }
};
</script>

<style lang="less" scoped>
</style>

