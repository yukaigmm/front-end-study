<template>
    <div class="tree-radio-container">
        <div style="margin-left: 10px;">
            <span>关键字：</span>
            <Input style="width:200px;margin-right:8px;" placeholder="请输入关键字" @input="filterTree" v-model="filterText" v-if="filter"/>
        </div>
		<div class="tree-radio-tree-container" v-loading="loading" element-loading-text="拼命加载中">
			<el-tree
				ref="tree"
				:class="{'common-tree-in-modal':true, 'radio': true}"
				:data="treeData"
				accordion
				show-checkbox
				:default-expand-all="false"
				:default-expanded-keys="defaultExpandKeys"
				:props="treeProps"
				:node-key="nodeKey"
				:filter-node-method="filterNode"
				@check="handleCheck"
			>
			</el-tree>
		</div>
    </div>
</template>


<script>
export default {
	props: {
		treeData: {
			type: Array,
		},
		defaultExpandKeys: {
			type: Array,
		},
		treeProps: {
			type: Object,
			default: () => {
                return {}
            },
		},
		nodeKey: {
			type: String,
		},
		labelKey: {
			type: String,
		},
		checkedKey: {
			type: [String,Number]
        },
        filter: {
            type: Boolean,
            default: true
		},
		loading: {
			type: Boolean,
		},
		justFilter: {
			type: Boolean,
			default: false
		},
		fuzzySearch: {
			type: Boolean,
			default: false
		},
		treeName: {
			type: String
		},

		showSearch:{
			type:Boolean,
			default:true
		}
	},
	data() {
		return {
			filterText: '',
			checkedId: 0,
			checkedLabelArr: [],
		};
	},
	watch: {
		treeData: {
			handler(val) {
				// console.log(val)
			},
			deep: true,
		},
		defaultExpandKeys: {
			handler(val) {
				// console.log(val)
			},
			deep: true,
		},
		
	},
	methods: {
		// 设置搜索节点
		filterNode(value, data) {
			if (!value) return true;
			return data.title.indexOf(value) !== -1;
		},
		// 根据选中的key设置选中显示
		setChecked(checkedKey){
			this.$refs.tree.setCheckedKeys([]);
			this.checkedLabelArr = [];
			if(this.$refs.tree.getNode(checkedKey)){
				let currentNode = this.$refs.tree.getNode(checkedKey);
				this.$refs.tree.setChecked(checkedKey, true, false);
				this.getNodeLabel(currentNode);
				this.setChildNotChecked(currentNode);
				this.setParentNotChecked(currentNode);
			}
		},
		// 选中某个节点，子节点也会跟着选中，需要去掉勾选
		setChildNotChecked(node){
			let childNodes = node.childNodes || [];
			childNodes.forEach((child, index) => {
				child.checked = false;
				if (child.childNodes) {
					this.setChildNotChecked(child.childNodes);
				}
			});
		},
		// 如果只有自己一个子节点，在自己勾选时父节点也会被选中，单选需要去掉父节点的勾选
		setParentNotChecked(node) {
			let parent = node.parent;
			if(parent){
				parent.checked = false;
				this.getNodeLabel(parent);
				if (parent.parent) {
					this.setParentNotChecked(parent);
				}
			}
		},
		// 获取节点的label
		getNodeLabel(node){
			let nodeLabel = node.data[this.labelKey || "label"];
			if(nodeLabel){
				this.checkedLabelArr.unshift(nodeLabel);
			}
		},
		// 点击选中的回调
		handleCheck(data, statusObj) {
			if (statusObj.checkedKeys.includes(data.id)) {
				this.setChecked(data.id);
				this.checkedId = data.id;
				this.submitData();
			}
		},
		submitData(){
			let emitData = {
				checkedId: this.checkedId,
				checkedLabelArr: this.checkedLabelArr,
				name: this.treeName
			};
			this.$emit('submit',emitData);
		},

		// 过滤和模糊搜索
        filterTree(val){
			if(this.justFilter){
				this.$refs.tree.filter(this.filterText);
			}else if (this.fuzzySearch){
				this.$emit("getTreeData",val);
			}
		},
		// 清除过滤条件和搜索条件
		clearFilterText(){
			this.filterText = ""
		}
	},
};
</script>

<style lang="less">
.tree-radio-container{
    .radio {
		.el-checkbox__input.is-indeterminate {
			& > span.el-checkbox__inner {
				background-color: #fff;
			}
		}
	}
	.tree-radio-tree-container{
		min-height: 150px;
	}
}
</style>


