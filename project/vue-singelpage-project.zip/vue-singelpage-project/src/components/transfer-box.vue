<template>
  <div class="transfer-box">
    <div class="origin-box">
      <slot name="originHeader"></slot>
      <slot name="originTitle"></slot>

      <div class="orign-list" :style="{height:`${height}px`}">
        <CheckboxGroup
          v-model="selectedOrignData"
          @on-change="onOriginSelectedDataChange"
          v-if="orignData.length"
        >
          <Row>
            <Col span="24" v-for="(item,index) in orignData" :key="index">
              <Checkbox :disabled="disabledIds.includes(item[valueKey])" :label="item[valueKey]">
                <span>
                  <span class="icon" v-if="showIcon" :title="iconTitleMapping[item.type]">
                    <img :src="iconMapping[item.type]" :alt="iconTitleMapping[item.type]">
                  </span>
                  {{item[labelKey]}}
                </span>
              </Checkbox>
            </Col>
          </Row>
        </CheckboxGroup>
        <span class="empty-box" v-else>暂无数据</span>
      </div>
    </div>

    <div class="action-box">
      <Button type="primary" :disabled="!canAdd" @click="addRow">添加＞＞</Button>
      <Button type="primary" style="margin-top:15px;" :disabled="!canDelete" @click="deleteRow">＜＜移除</Button>
    </div>

    <div class="target-box">
      <slot name="targetHeader"></slot>
      <slot name="targetTitle"></slot>
      <div class="target-list" :style="{height:`${height}px`}">
        <CheckboxGroup
          v-model="selectedTargetData"
          @on-change="onTargetSelectedDataChange"
          v-if="targetData.length"
        >
          <Row>
            <Col span="24" v-for="(item,index) in targetData" :key="index">
              <Checkbox :label="item[valueKey]">
                <span>
                  <span class="icon" v-if="showIcon" :title="iconTitleMapping[item.type]">
                    <img :src="iconMapping[item.type]" :alt="iconTitleMapping[item.type]">
                  </span>
                  {{item[labelKey]}}
                </span>
              </Checkbox>
            </Col>
          </Row>
        </CheckboxGroup>

        <span class="empty-box" v-else>暂无数据</span>
      </div>
    </div>
  </div>
</template>


<script>
export default {
  props: {
    height: {
      type: [Number, String],
      default: 300
    },
    orignData: {
      type: [Array, Object],
      default: () => []
    },
    allOriginData: {
      type: [Array, Object],
      default: () => []
    },
    selectedKeys: {
      type: [Array, Object],
      default: () => []
    },
    labelKey: {
      type: String
    },
    valueKey: {
      type: String
    },
    showIcon: {
      type: Boolean,
      default: false
    }
  },

  computed: {
    targetData() {
      let data = this.allOriginData.length
        ? this.allOriginData
        : this.orignData;
      return (
        data.filter(item => this.seletedItem.includes(item[this.valueKey])) ||
        []
      );
    },
    disabledIds() {
      return this.targetData.map(item => item[this.valueKey]) || [];
    }
  },

  watch: {
    selectedKeys: {
      handler(val) {
        if (val) {
          this.seletedItem = val;
        }
      }
    },
  },

  data() {
    return {
      seletedItem: this.selectedKeys,
      canAdd: false,
      canDelete: false,
      selectedOrignData: [],
      selectedTargetData: [],
      iconTitleMapping: {
        "1": "菜单",
        "2": "功能",
        "3":"数据",
        group: "权限组"
      },
      iconMapping: {
        "1": require("@/assets/菜单.png"),
        "2": require("@/assets/功能.png"),
        "3": require("@/assets/数据.png"),
        group: require("@/assets/权限组.png")
      }
    };
  },

  methods: {
    clearData() {
      this.selectedOrignData = [];
      this.selectedTargetData = [];
    },

    onOriginSelectedDataChange(selection) {
      if (selection && selection.length) {
        this.canAdd = true;
      } else {
        this.canAdd = false;
      }
    },

    onTargetSelectedDataChange(selection) {
      if (selection && selection.length) {
        this.canDelete = true;
      } else {
        this.canDelete = false;
      }
    },

    addRow() {
      this.seletedItem = [
        ...new Set(this.seletedItem.concat(this.selectedOrignData))
      ];
      this.selectedOrignData = [];
      this.canAdd = false;
    },

    deleteRow() {
      this.seletedItem = this.seletedItem.filter(
        item => !this.selectedTargetData.includes(item)
      );
      this.selectedTargetData = [];
      this.canDelete = false;
    },

    getSelectedRows() {
      return this.targetData;
    }
  }
};
</script>

<style lang="less" scoped>
.transfer-box {
  display: flex;
  justify-content: space-around;
  padding: 15px;
  .action-box {
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin-right: 15px;
    margin-left: 15px;
  }
  .origin-box {
    flex: 1;
  }
  .orign-list {
    border: 1px solid #ccc;
    padding: 15px;
    overflow: auto;
  }
  .target-box {
    flex: 1;
  }
  .target-list {
    border: 1px solid #ccc;
    padding: 15px;
    overflow: auto;
  }
}
.icon {
  display: inline-block !important;
  width: 15px;
  height: 15px;
  img {
    width: 100%;
    height: auto;
  }
}

.empty-box {
  text-align: center;
  display: inline-block;
  width: 100%;
}
</style>

