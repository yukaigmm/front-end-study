<template>
  <Modal
    :value="modal"
    :title="title"
    :mask-closable="false"
    :width="width"
    :closable="false"
    @on-visible-change="onVisibleChange"
  >
    <div slot="header" class="y-modal-header">
      <h4>{{title}}</h4>
      <div slot="close" @click="cancel" class="y-modal-close">
        <Icon type="ios-close-empty"></Icon>
      </div>
    </div>

    <div slot="footer">
      <slot name="footer">
        <Button @click="cancel">{{cancelTxt}}</Button>
        <Button type="primary" @click="ok" :loading="btnLoading">{{okText}}</Button>
      </slot>
    </div>

    <slot name="close">
      <div slot="close" @click="cancel">
        <Icon type="ios-close-empty"></Icon>
      </div>
    </slot>

    <Spin fix size="large" v-if="loading"></Spin>

    <slot></slot>
  </Modal>
</template>


<script>
export default {
  props: {
    modal: {
      type: Boolean,
      default: false
    },

    title: {
      default: ""
    },

    width: {
      default: 500
    },
    btnLoading: {
      type: Boolean,
      default: false
    },

    loading: {
      type: Boolean,
      default: false
    },

    cancelTxt: {
      type: String,
      default: "取消"
    },

    okText: {
      type: String,
      default: "确定"
    }
  },

  data() {
    return {};
  },

  methods: {
    // 使用esc快捷键关闭modal时，改变父组件中的modal的值
    onVisibleChange(val) {
      if (!val) {
        this.$emit("cancel");
      }
    },

    ok() {
      this.$emit("ok");
    },

    cancel() {
      this.$emit("cancel");
    }
  }
};
</script>

<style lang="less" scoped>
.y-modal-header{
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 20px;
  .y-modal-close{
    font-size:31px;
    cursor: pointer;
  }
}
</style>

