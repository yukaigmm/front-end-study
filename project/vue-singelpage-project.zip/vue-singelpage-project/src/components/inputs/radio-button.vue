<template>
  
 <!--  <Radio-group v-model="currentValue" @on-change="onChange" :disabled="disabled" >
      <Radio v-for="item in list" :label="item.value + ''" :key="item.value + ''">{{ item.name }}</Radio>
  </Radio-group> -->
      <Checkbox v-model="currentValue" @on-change="onChange" :disabled="disabled">
        
    </Checkbox>    
  <!-- <Radio-group v-model="currentValue" @on-change="onChange"  type="button" >
        <Radio label="1"><Icon type="checkmark"></Icon></Radio>
        <Radio label="0"><Icon type="close"></Icon></Radio>
  </Radio-group> -->
</template>

<script>
  import { forEach,isEmpty } from 'lodash'
  import { fetchSelect } from '@/service/getData'
  import {getCache} from '@/plugin/cache'
  let cacheDatas = new Map()

  export default {
    props: ['value', 'config'],
    mounted () {
//      this.initDatas()
      this.$emit('input', this.currentValue)

      if (this.config.editDisabled === true) {
        this.disabledWhenEdit()
      }
    },
    data () {
      return {
        disabled: false,
        currentValue: this.value == 1 ? true : false ,
        list: []
      }
    },
    computed: {
      url () {
        return this.config.url
      }
    },
    watch: {
      value: function (val) {
        if (val === this.currentValue) {
          return
        }
        this.currentValue = val
      }
    },
    methods: {
      initDatas () {
        if( cacheDatas.get(this.url) ) {
          this.list = JSON.parse( JSON.stringify( cacheDatas.get(this.url) ) )

        } else {
          fetchSelect(this.url).then(resp => {
            cacheDatas.set( this.url, JSON.parse( JSON.stringify( resp.data ) ) )
            this.list = resp.data
          })

        }
      },
      onChange (val) {
        this.$emit('input', val)
        this.$emit('on-change', val)
      },
      disabledWhenEdit () {
        let parent = this.$parent || this.$root;
        let name = parent.$options.name;

        while (parent && (!name || name !== 'GridDialog')) {
          parent = parent.$parent;

          if (parent) {
            name = parent.$options.name;
          }
        }

        if (parent && parent.getEditType() === 'edit') {
            this.disabled = true
        }
      },
      getSelectedData () {
        let list = this.list, currentValue = this.currentValue

        for (let i=0, length = list.length; i<length; i++) {
          if (list[i].value.toString() === currentValue) {
            return JSON.parse(JSON.stringify(list[i]))
          }
        }

        return {}
      }
    }
  }
</script>
