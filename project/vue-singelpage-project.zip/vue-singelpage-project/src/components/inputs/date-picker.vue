<template>
  <Date-picker type="daterange" confirm placement="bottom-end" placeholder="选择日期" @on-change="onInput" ></Date-picker>
</template>

<script>
import { isEmpty } from 'lodash'
  export default {
    props: ['value'],
    data () {
        return {
          currentValue: this.value || ''
        }
    },
    watch: {
      value (val) {
        if (val === this.currentValue) {
          return
        }
        this.currentValue = val
      }
    },
    methods: {
      onInput (val) {
        let value = val
        if(isEmpty(value[0])){
          value = '';
        }
        this.$emit('input', value)
        // this.$emit('change', value)
      },
      

    }
  }
</script>
