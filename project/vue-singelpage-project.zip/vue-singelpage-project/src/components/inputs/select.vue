<template>
  <Select v-model="currentValue" @on-change="onChange" clearable :disabled="disabled">
    <Option v-for="item in list" :value="item.value + ''" :key="item.value + ''">{{ item.name }}</Option>
  </Select>
</template>

<script>
  export default {
    props: ['value', 'config'],
    mounted () {
      this.$emit('input', this.currentValue)

      if (this.config.editDisabled === true) {
        this.disabledWhenEdit()
      }
    },
    data () {
      return {
        disabled: false,
        currentValue: typeof this.value === 'number' || typeof this.value === 'string' ? this.value + '' : '',
        list: this.config.list || []
      }
    },
    computed: {

    },
    watch: {
      value: function (val) {
        if (val === this.currentValue) {
          return
        }
        this.currentValue = val
      }
    },
    methods: {
      onChange (val) {
        this.$emit('input', val)
        this.$emit('on-change', val)
      },
      disabledWhenEdit () {
        let parent = this.$parent || this.$root;
        let name = parent.$options.name;

        while (parent && (!name || name !== 'GridDialog')) {
          parent = parent.$parent;

          if (parent) {
            name = parent.$options.name;
          }
        }

        if (parent && parent.getEditType() === 'edit') {
          this.disabled = true
        }
      },
      getSelectedData () {
        let list = this.list, currentValue = this.currentValue

        for (let i=0, length = list.length; i<length; i++) {
          if (list[i].value.toString() === currentValue) {
            return JSON.parse(JSON.stringify(list[i]))
          }
        }

        return {}
      }
    }
  }
</script>
