<template>
    <div>
        <Row>
            <Col span="24" style="padding-bottom:10px;">
                <span :style="style">{{name}}我是样例</span>
            </Col>
            <Col span="24"> 
                <div>
                    <Button @click="changeColor('fontColor')">字体颜色</Button>
                    <input ref="color" type="color" value="" @change="fn" style="position:absolute;top:-1444px;">
                    <Button @click="changeColor('borderColor')">边框颜色</Button>
                    <Button  @click="changeColor('bgColor')">背景颜色</Button>
                </div>
                <div>
                    <b>字体大小:</b>
                    <Slider style="width:300px;" v-model="valNum" show-input :min="min" :max="max" @on-input="geiFontSize"></Slider>
                </div>
                 <Input readonly v-model="currentValue" v-if="false" />
            </Col>
        </Row>
    </div> 
</template>
<script>
    export default {
        props: ['value','name'],
        data(){
            return{
                currentTarget: '',
                styleJson: {
                    fontColor:'color:#000000;',
                    borderColor:'border:0px solid #fff;',
                    bgColor:'background-color:#fff;',
                    fontSize:'font-size:12px;',
                    fontSizeVal:12,
                },
                styleDefault:'border:solid #fff 1px;padding:2px;',
                style:'',
                valNum: 16,
                seen:false,
                currentValue: this.value || '',
                defaultVal: '',
                max:25,
                min:10

            }
        },
        mounted () {
                if(this.value){
                    this.defaultVal = JSON.parse(this.value);
                }else{
                    this.defaultVal = this.styleJson;
                }

                this.styleJson['fontColor'] = this.defaultVal.fontColor
                this.styleJson['borderColor'] = this.defaultVal.borderColor
                this.styleJson['bgColor'] = this.defaultVal.bgColor
                this.styleJson['fontSize'] = this.defaultVal.fontSize
                this.styleJson['fontSizeVal'] = this.defaultVal.fontSizeVal
            let temStyle =  this.styleJson['fontColor']+this.styleJson['borderColor']+this.styleJson['bgColor']+this.styleJson['fontSize'];
                this.style = this.styleDefault+temStyle;
                this.currentValue = JSON.stringify(this.styleJson);
                this.$emit('input', this.currentValue)
                this.valNum = this.defaultVal.fontSizeVal || 14;
        },
    
        methods: {
           changeColor(target){
            this.currentTarget = target;
            this.$refs.color.click()
           },

           fn (e) {
            
                if(this.currentTarget == 'fontColor'){
                    this.styleJson['fontColor'] = 'color:'+e.target.value+';'
                }
                if(this.currentTarget == 'borderColor'){
                    this.styleJson['borderColor'] = 'border:1px solid '+e.target.value+';'
                }
                if(this.currentTarget == 'bgColor'){
                    this.styleJson['bgColor'] = 'background-color:'+e.target.value+';'
                }
                 let temStyle =  this.styleJson['fontColor']+this.styleJson['borderColor']+this.styleJson['bgColor']+this.styleJson['fontSize'];
                this.style = this.styleDefault+temStyle;
                this.currentValue = JSON.stringify(this.styleJson);
                this.$emit('input', this.currentValue)
           },
           geiFontSize (val) {
                this.styleJson['fontSize'] = 'font-size:'+val+'px;';
                let temStyle =  this.styleJson['fontColor']+this.styleJson['borderColor']+this.styleJson['bgColor']+this.styleJson['fontSize'];
                this.style = this.styleDefault+temStyle;
                this.styleJson['fontSizeVal'] = val;
                this.currentValue = JSON.stringify(this.styleJson);
                this.$emit('input', this.currentValue)
                return '大小' + val + 'px';
            }
        }
    }
</script>