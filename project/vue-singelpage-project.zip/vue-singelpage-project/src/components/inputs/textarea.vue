<template>
  <Input type="textarea" v-model="currentValue" @input="onInput"/>
</template>

<script>

  export default {
    props: ['value'],
    data () {
        return {
          currentValue: this.value || ''
        }
    },
    watch: {
      value (val) {
        if (val === this.currentValue) {
          return
        }
        this.currentValue = val
      }
    },
    methods: {
      onInput (val) {
        this.$emit('input', val)
        this.$emit('change', val)
      }
    }
  }
</script>
