<template>
<span>
    <Button type="primary" @click="addItem" icon="plus"></Button>
    <Row class="inputjson">
        <span style="display:inline-block;width:100px;margin-right:8px;">键名</span>
        <span style="display:inline-block;width:100px;margin-right:8px;">标识</span>
        <span style="display:inline-block;width:100px;margin-right:8px;">排序规则</span>
        <span style="display:inline-block;width:100px;margin-right:8px;">操作</span>
    </Row>
  <div v-for="(item, index) in lists" :key="index" >
    
    <Row class="inputjson" >
        <Input style="width:100px;margin-right:8px;" v-model="item.name"  :key="item"  @on-change="onInput" />
        <Input style="width:100px;margin-right:8px;" v-model="item.value" :key="item" @on-change="onInput" />
        <Input style="width:100px;margin-right:8px;" v-model="item.sort_id"  :key="item" @on-change="onInput" />
        <Button  @click="removeItem(index)" icon="close"></Button>
    </Row>
  </div>
</span>  
</template>
 
<script>

  export default {
    props: ['value'],
    data () {
        return {
          currentValue: this.value || '',
          lists : JSON.parse(JSON.stringify(this.value))
        }
    },
    watch: {
      lists : {
        handler:(val,oldVal)=>{

                    //要执行的任务
                    //这里不知道怎么才能修改到this.data的数据，有知道的麻烦告知
                    //现在知道的就是通过直接修改Store.state的方式来更新数据，当然效果和修改this.data是一样的



                    // 这个问题我知道，但是不想告诉你
                },
                deep:true
      },
    },
    computed: {
      list () {
         return JSON.parse(JSON.stringify(this.value)) 
      }
    },
    methods: {
      onInput (val) {
        let info = this.lists
        this.$emit('input', info)
        this.$emit('change', info)
      },
      addItem (index) {
        // JSON.stringify
        let info = this.lists;
        let result = [];
        for (let key in this.lists) {
            // console.log(info)
            result.push(this.lists[key])
        }
        let row = {name: "", value: 0, sort_id: 0}
         // info = this.list 

        // let row = ['name']
        result.push(row)
        // info.push(row);
        this.lists = result
        this.$emit('input', result)
        this.$emit('change', result)
        // console.log(result)
      },
      removeItem (index) {
       // arr.splice(1,1)
        let info = this.lists;
        let result = [];
        for (let key in this.lists) {
            // console.log(info)
            result.push(this.lists[key])
        }
        result.splice(index,1) 
        // this.lists = result;
        this.lists = result
        console.log('remove')
        this.$emit('input', result)
        this.$emit('change', result)
      },
    }
  }
</script>
<style>
  .inputjson{
    margin-top: 10px;
  }
</style>