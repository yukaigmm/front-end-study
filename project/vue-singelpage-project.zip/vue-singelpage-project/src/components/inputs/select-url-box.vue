<template>
  <Select v-model="currentValue" @on-change="onChange" :disabled="disabled" :placeholder="this.config.placeholder"  multiple >
    <Option v-for="item in list" :value="item.value + ''" :key="item.value + ''"><Tag :style="item.style">{{ item.name }}</Tag></Option>
  </Select>
</template>

<script>
  import { forEach,isEmpty } from 'lodash'
  import { fetchSelect } from '@/service/getData'
  import {getCache} from '@/plugin/cache'
  import  $ from "jquery";
  let cacheDatas = new Map()
 
  export default {
    props: ['value', 'config'],
    mounted () {
      // console.log(this.cacheData) 获取用户缓存数据
       let key = this.config.cacheKey;
      if(key){
        let cData = getCache(key)
        this.list = cData
      }else{
      fetchSelect(this.url).then(resp => {
        this.list = resp.data

        //字段名不对应时，根据配置进行匹配
        if(this.config.name && this.config.value){
          forEach(this.list, (item) => {
            item.name = item[this.config.name]
            item.value = item[this.config.value]
          })
        }
      })
    }

//      this.initDatas()
      this.$emit('input', this.currentValue)

      if (this.config.editDisabled === true) {
        this.disabledWhenEdit()
      }
    },
    data () {
      return {
        disabled: false,
        currentValue: isEmpty(this.value) ? [] :  JSON.parse(this.value),
        list: []
      }
    },
    computed: {
      url () {
        return this.config.url
      },
     
    },
    watch: {
      "currentValue":{
       handler(val){
          setTimeout( () => {
            let selectTags = $(this.$el).find(".ivu-select-selection .ivu-tag")
            let selectTag = $(this.$el).find(".ivu-select-selection .ivu-tag span");
            let tag = $(this.$el).find(".ivu-select-dropdown .ivu-tag span");
            let tagContianer = $(this.$el).find(".ivu-select-dropdown .ivu-tag");
            let tagStyle = [];
            for(let i = 0 ;i< tagContianer.length ;i++){
              for(let j= 0;j<selectTag.length;j++){
                if($(selectTag.get(j))[0].innerText==$(tag.get(i))[0].innerText){
                $(selectTags.get(j))[0].setAttribute('style', $(tagContianer.get(i))[0].getAttribute('style'))
              }
              }
            }
          }, 10)
       },
       deep:true
     },
      value: function (val) {
        if(isEmpty(val)){
          return [];
        }
        if (val === this.currentValue) {
          return
        }

        this.currentValue = val
      }
    },
    methods: {
      initDatas () {
         let key = this.config.cacheKey;
          if(key){
            let cData = getCache(key)
            this.list = cData
          }else{
          fetchSelect(this.url).then(resp => {
            cacheDatas.set( this.url, JSON.parse( JSON.stringify( resp.data ) ) )
            this.list = resp.data
          })

        }
      },
      onChange (val) {
        this.$emit('input', val)
        this.$emit('on-change', val)
      },
      disabledWhenEdit () {
        let parent = this.$parent || this.$root;
        let name = parent.$options.name;

        while (parent && (!name || name !== 'GridDialog')) {
          parent = parent.$parent;

          if (parent) {
            name = parent.$options.name;
          }
        }

        if (parent && parent.getEditType() === 'edit') {
            this.disabled = true
        }
      },
      getSelectedData () {
        let list = this.list, currentValue = this.currentValue

        for (let i=0, length = list.length; i<length; i++) {
          if (list[i].value.toString() === currentValue) {
            return JSON.parse(JSON.stringify(list[i]))
          }
        }

        return {}
      }
    }
  }
</script>
