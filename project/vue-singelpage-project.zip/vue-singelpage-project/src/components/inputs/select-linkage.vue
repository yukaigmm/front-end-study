<template>
  <Row>
    <Col span="6" class="linkage">
    <Select v-model="currentValue" @on-change="onChange" clearable  transfer :disabled="disabled" placeholder='请选择国家'>
      <Option v-for="item in list" :value="item.value" :key="item.value + ''">{{ item.name }}</Option>
    </Select>
    </Col>
    <Col span="6" class="linkage">
    <Select v-model="currentValue1" @on-change="onChange1" clearable transfer  :disabled="disabled1" placeholder='省份'>
      <Option v-for="item in list1" :value="item.value " :key="item.value + ''">{{ item.name }}</Option>
    </Select>
    </Col>
    <Col span="6" class="linkage">
    <Select v-model="currentValue2" @on-change="onChange2" clearable transfer  :disabled="disabled2" placeholder='城市'>
      <Option v-for="item in list2" :value="item.value" :key="item.value + ''">{{ item.name }}</Option>
    </Select>
    </Col>
    <Col span="6">
    <Select v-model="currentValue3" @on-change="onChange3" clearable transfer  :disabled="disabled3" placeholder='区县' v-show="!disabled3">
      <Option v-for="item in list3" :value="item.value" :key="item.value + ''">{{ item.name }}</Option>
    </Select>
    </Col>
  </Row>
</template>
<script>
import { getCache } from '@/plugin/cache'
import { forEach, isEmpty, filter, get, first } from 'lodash'
export default {
  props: ['value', 'config'],
  mounted() {
    let key = this.config.cacheKey;
    if (key) {
      let cData = getCache(key)
      this.list = cData
    }
    if (this.value) {
      let strs = new Array(); //定义一数组
      strs = this.value.split(","); //字符分割
      if (strs[0]) {
        this.currentValue = strs[0]
      }
      if (strs[1]) {
        this.currentValue1 = strs[1]
      }
      if (strs[2]) {
        this.currentValue2 = strs[2]
      }
      if (strs[3]) {
        this.currentValue3 = strs[3]
      }
    } else {
      if (!this.config.isFullfill) {
        this.currentValue = '86';
        this.onChange('86');
      }else{
        this.currentValue = '';
        this.onChange('');
      }

    }

    this.$emit('input', this.currentValue)
    if (this.config.editDisabled === true) {
      this.disabledWhenEdit()
    }
  },
  data() {
    return {
      disabled: false,
      disabled1: false,
      disabled2: false,
      disabled3: false,
      currentValue: '',
      currentValue1: typeof this.value === 'number' || typeof this.value === 'string' ? this.value + '' : '',
      currentValue2: typeof this.value === 'number' || typeof this.value === 'string' ? this.value + '' : '',
      currentValue3: typeof this.value === 'number' || typeof this.value === 'string' ? this.value + '' : '',
      list: this.config.list || [],
      list1: [],
      list2: [],
      list3: [],
    }
  },
  computed: {

  },
  watch: {
    value: function(val) {
      if (isEmpty(val)) {
        this.currentValue = '';
        this.currentValue1 = '';
        this.currentValue2 = '';
        this.currentValue3 = '';
        this.disabled1 = true
        this.disabled2 = true
        this.disabled3 = true
      } else {
        let strs = new Array(); //定义一数组
        strs = this.value.split(","); //字符分割
        if (strs[0]) {
          this.currentValue = strs[0]
        }
        if (strs[1]) {
          this.currentValue1 = strs[1]
        }
        if (strs[2]) {
          this.currentValue2 = strs[2]
        }
        if (strs[3]) {
          this.currentValue3 = strs[3]
        }
      }
    }
  },
  methods: {
    onChange(val) {
      let name = get(first(filter(this.list, (item) => {
        return item.value == val
      })), 'children');
      this.list1 = name;
      if (!this.currentValue1) {
        this.list2 = [];
        this.list3 = [];
        this.currentValue1 = '';
        this.currentValue2 = '';
        this.currentValue3 = '';
      }
      if (!val) {
        this.disabled1 = true;
      } else {
        this.disabled1 = false;

      }
      this.disabled2 = true
      this.disabled3 = true
      this.currentValue = val;

      let value = val;
      this.$emit('input', value)

      if (this.config.useForSearch) {
        this.config.useForSearch = false;
        return;
      }
      this.$emit('on-change', value)
    },
    onChange1(val) {
      let name = get(first(filter(this.list1, (item) => {
        return item.value == val
      })), 'children');
      this.list2 = name;
      this.list3 = [];
      if (!this.currentValue2) { 
        this.list3 = [];
        this.currentValue2 = '';
        this.currentValue3 = '';
      }
      if (!val) {
        this.disabled2 = true;
      } else {
        this.disabled2 = false;

      }
      this.disabled3 = true
      // this.currentValue ;
      this.currentValue1 = val;


      let value = this.currentValue + ',' + val;
      this.$emit('input', value)
      this.$emit('on-change', value)
    },
    onChange2(val) {
      let name = get(first(filter(this.list2, (item) => {
        return item.value == val
      })), 'children');
      this.list3 = name;
      if (!this.currentValue3) {
        this.currentValue3 = '';
      }

      this.currentValue2 = val;
      let value = this.currentValue + ',' + this.currentValue1 + ',' + val;
      if (!val) {
        this.disabled3 = true;
      } else {
        if (isEmpty(this.list3)) {
          this.disabled3 = true;
        } else {
          this.disabled3 = false;
        }
      }
      this.$emit('input', value)
      this.$emit('on-change', value)
    },
    onChange3(val) {
      this.currentValue3 = val;
      let value = this.currentValue + ',' + this.currentValue1 + ',' + this.currentValue2 + ',' + val;
      this.$emit('input', value)
      this.$emit('on-change', value)
    },
    disabledWhenEdit() {
      let parent = this.$parent || this.$root;
      let name = parent.$options.name;

      while (parent && (!name || name !== 'GridDialog')) {
        parent = parent.$parent;

        if (parent) {
          name = parent.$options.name;
        }
      }

      if (parent && parent.getEditType() === 'edit') {
        this.disabled = true
      }
    },
    getSelectedData() {
      let list = this.list,
        currentValue = this.currentValue
      for (let i = 0, length = list.length; i < length; i++) {
        if (list[i].value.toString() === currentValue) {
          return JSON.parse(JSON.stringify(list[i]))
        }
      }

      return {}
    }
  }
}

</script>
<style scoped lang="less">
.dialog-form-item-less {
  display: inline-block;
  width: 120px;
}

.dialog-form-item {
  display: inline-block;
  width: 330px;
}

.dialog-form-item-row {
  display: inline-block;
  width: 660px;
}

.pull-right {
  float: right;
  margin-right: 10px;
}

.pull-center {
  margin: 0 150px 0 150px,
}

.linkage {
  padding-right: 6px;
}

</style>
