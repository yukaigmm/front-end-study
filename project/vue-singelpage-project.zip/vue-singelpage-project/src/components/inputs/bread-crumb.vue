<template>
  <div class="bread-container">
    <div class="bread-content">
      <Row>
        <Col span="24">
          <Breadcrumb separator="<b class='demo-breadcrumb-separator'>></b>">
            <Breadcrumb-item v-for="item in list" :href="item.url" :key="item.id">
              <span @click="getclicks(item)">{{ item.title }}</span>
            </Breadcrumb-item>
          </Breadcrumb>
        </Col>
        <!-- <Col span=1>
           <Icon type="android-arrow-back" size="20" @click.native="goback" ></Icon>
        </Col>-->
      </Row>
    </div>
    <!-- old version -->
  </div>
</template>



<script>
import { forEach } from "lodash";
import router from "@/router";
import SelectLinkage from "@/components/inputs/select-linkage";
import SelectUrl from "@/components/inputs/select-url";
import SelectUrlBox from "@/components/inputs/select-url-box";
import { mapGetters } from "vuex";
import { getRow, putFormData } from "@/service/getData";
let cacheDatas = new Map();

export default {
  props: ["value", "config", "pid"],
  mounted() {
    this.initDatas();
  },
  components: {
    SelectLinkage,
    SelectUrl,
    SelectUrlBox
  },
  data() {
    return {
      list: [],
      info: {},
      flip: "flip",
      upurl: "/index/organization",
      ruleValidate: {
        org_name: [
          {
            required: true,
            message: "请输入机构名称",
            trigger: "change, blur"
          },
          { min: 2, message: "机构部门不得少于2个字", trigger: "change, blur" }
        ],
        area_info: [{ required: false, trigger: "change,blur" }],
        phone_num: [
          {
            pattern: /(^1(3|4|5|6|7|8|9)\d{9}$)|(^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$)/,
            message: "请输入正确电话 参照 400-6802928",
            trigger: "change, blur"
          }

          // { type: 'array', max: 2, message: '最多选择两个爱好', trigger: 'change' }
        ],
        website: [
          {
            pattern: /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/,
            message: "参照 http://www.smppw.com",
            trigger: "change, blur"
          }
        ]
      }
    };
  },
  computed: {
    url() {
      return this.config.url;
    },
    ...mapGetters({
      tabs: "getTabs",
      activeTab: "getActiveTab"
    })
  },
  watch: {
    value: function(val) {
      if (val === this.currentValue) {
        return;
      }
      this.currentValue = val;
    },
    pid: function(val, oldVal) {
      // 更新表单数据

      this.flip = "";
      this.initDatas();
      this.flip = "flip";
    }
  },
  methods: {
    initDatas() {
      getRow(this.url, this.pid).then(resp => {
        // this.$refs['formInline'].resetFields();
        this.list = resp.data.breadcrumb;
        this.info = resp.data;
        this.$emit("closeLoading");
      });
    },
    resetForm() {
      for (let key in this.info) {
        let keyType = typeof this.info[key];
        this.info[key] = "";
      }
    },
    getclicks(item) {
      // // this.$emit('click-detail', id)
      let tab = {
        activeName: item.title,
        pid: item.id,
        name: `${item.title}${item.id}`,
        component: "departmentDetails",
        isShow: true
      };
      // 点击首页时跳转到机构页面
      if (item.id === 0) {
        tab = {
          activeName: "机构",
          name: "机构0",
          component: "organizationManager",
          isShow: true
        };
      }

      this.$store.dispatch("setTabs", tab);

      // 如果有跳到该tab，并激活
      // if(  (_.findIndex(this.tabs, tabItem => {
      //           return tabItem.name == tab.name;
      //                           }) != -1)&& (_.findIndex(this.tabs, tabItem => {
      //                             return tabItem.pid == tab.pid;
      //                           }) != -1)){
      //    let newtabs = this.tabs.map(item => {
      //       if (item.name == tab.name) {
      //           item.isShow = true;
      //         }
      //       return item;
      //     });
      //      this.$store.dispatch("setTabsAll", newtabs);
      //      this.$store.dispatch("setActiveTab", {
      //        activeTab: tab.name
      //       });
      //  }else{
      //    // 如果没有新建并激活
      //  this.$store.dispatch("setTabs", tab);
      //  this.$store.dispatch("setActiveTab", {
      //      activeTab: tab.name
      //   });
      //  }
    },
    goback() {
      if (this.list.length >= 2) {
        let data = this.list[this.list.length - 2];
        this.getclicks(data.id);
      } else {
        this.getclicks(0);
      }
      // getclicks();
    },
    getArea() {
      let url = "/common/getAreaByCity";
      let address = this.info.area_info;
      getRow(url, address).then(resp => {
        if (resp.code == 20000) {
          this.info.area_ids = resp.data.area_ids;
        }
      });
    },
    async() {
      this.$refs["formInline"].validate(valid => {
        if (valid) {
          this.$Modal.confirm({
            title: `您正在修改${this.info.org_name}的信息`,
            content: "<p>是否确认修改</p>",
            loading: true,
            onOk: () => {
              this.$refs["formInline"].validate(valid => {
                if (valid) {
                  let putdata = {};
                  putdata.org_name = this.info["org_name"];
                  putdata.oc_id = this.info["oc_id"];
                  putdata.depart_id = this.info["depart_id"];
                  putdata.portrait = this.info["portrait"];
                  putdata.area_ids = this.info["area_ids"];
                  putdata.area_info = this.info["area_info"];
                  putdata.phone_num = this.info["phone_num"];
                  putdata.website = this.info["website"];
                  putdata.org_content = this.info["org_content"];
                  putFormData(this.upurl, this.info["id"], putdata).then(
                    resp => {
                      this.$Modal.remove();
                      this.$Message.info("修改成功");
                    },
                    error => {
                      this.loading = false;
                      this.$Message.info("修改失败");
                    }
                  );
                } else {
                  this.$Message.info("请核查数据格式");
                }
              });
            }
          });
        } else {
          this.$Message.info("请核查数据格式");
        }
      });
    }
  }
};
</script>
<style  lang="less">
.demo-breadcrumb-separator {
  color: #ff5500;
  padding: 0 5px;
}

.bread-container {
  z-index: 10;
  .bread-content {
    line-height: 50px;
    padding: 0 5px 0 5px;
  }
} // .button{
//       display: none !important;
// }
.alert:hover + .card {
  border: 1px soild red;
}

.card {
  padding: 0 205px 15px 5px;
}

.card:hover + .button {
  display: inline-block !important;
}

.button:hover {
  display: inline-block !important;
}

@keyframes myfirst {
  from {
    width: 0;
  }
  to {
    width: 100%;
  }
}

@-moz-keyframes myfirst
/* Firefox */ {
  from {
    background: red;
  }
  to {
    background: yellow;
  }
}

@-webkit-keyframes myfirst
/* Safari 和 Chrome */ {
  from {
    background: red;
  }
  to {
    background: yellow;
  }
}

@-o-keyframes myfirst
/* Opera */ {
  from {
    background: red;
  }
  to {
    background: yellow;
  }
}

.flipped {
  transform: translateX(-100%) rotateY(-180deg);
}

.flip {
  animation: myfirst 2s;
  -moz-animation: myfirst 2s;
  /* Firefox */
  -webkit-animation: myfirst 2s;
  /* Safari 和 Chrome */
  -o-animation: myfirst 2s;
  /* Opera */
}
</style>
