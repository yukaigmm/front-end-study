<template>
  <div>
    <i-switch v-model="currentValue" @on-change="onChange">
    </i-switch>

    <span v-if="currentValue">
      {{ openLabel }}
    </span>

    <span v-else="">
      {{ closeLabel }}
    </span>
  </div>

</template>

<script>
  export default {
    props: ['value', 'config'],
    mounted () {
      if (this.currentValue) {
        this.$emit('input', this.openVal)

      } else {
        this.$emit('input', this.closeVal)

      }
    },
    data () {
      return {
        currentValue: this.value === this.config.openVal
      }
    },
    computed: {
      openVal () {
        return this.config.openVal
      },
      closeVal () {
        return this.config.closeVal
      },
      openLabel () {
        return this.config.openLabel
      },
      closeLabel () {
        return this.config.closeLabel
      }
    },
    watch: {
      value (val) {
        let open = (val === this.openVal)

        if (open === this.currentValue) {
          return
        }

        this.currentValue = open
      }
    },
    methods: {
      onChange (val) {
        if (val) {
          this.$emit('input', this.openVal)

        } else {
          this.$emit('input', this.closeVal)

        }
      }
    }
  }
</script>
