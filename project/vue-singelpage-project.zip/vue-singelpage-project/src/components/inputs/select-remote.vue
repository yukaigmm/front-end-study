<template>
  <el-select
    ref="remoteSelect"
    size="small"
    :remote="isRemote"
    :filterable="isRemote"
    :loading="loading"
    :remote-method="remoteMethod"
    @change="onChange"
    v-model="currentValue"
    :placeholder="placeholder"
    class="remote-select"
  >
    <el-option
        v-for="item in options"
        :key="item.value"
        :label="item.name"
        :value="item.value + ''"
    >
    </el-option>

  </el-select>
</template>

<script>
  import { fetchSelect } from '@/service/getData'
  import { find } from 'lodash'

  export default {
    props: ['value', 'config', 'placeholder'],
    data () {
      return {
        currentValue: this.value,
        options: this.config.options || [],
        isLoading: false
      }
    },
    computed: {
      url () {
        return this.config.url
      },
      isRemote () {
        return !!this.config.url
      },
      loading () {
        if (!this.config.url) {
          return false
        }

        return this.isLoading
      },
      validName () {
        return this.config.validate.validName
      }

    },
    watch: {
      value (val) {
        if (val === this.currentValue) {
          return
        }
        this.currentValue = val
      }
    },
    methods: {
      remoteMethod (val) {
        if (!val.trim()) {
          return
        }

        this.isLoading = true
        fetchSelect(this.url, {name: val,ifCancelRequest: true}).then(resp => {
          this.isLoading = false;
          this.options = resp.data
        })

      },

      onChange (val) {
        this.$emit('input', val)
        this.$emit('change', val)

        if (!this.validName) {
          return
        }

        let parent = this.$parent || this.$root;
        let name = parent.$options.name;

        while (parent && (!name || name !== 'GridDialog')) {
          parent = parent.$parent;

          if (parent) {
            name = parent.$options.name;
          }
        }

        parent && parent.$refs.form.validateField(this.validName)
      },

      setOptions (options) {
        this.options = options
      },

      getSelectedOptions () {
        if (!this.currentValue) {
          return null
        }

        return find(this.options, item => item.value === this.currentValue)
      }
    }
  }
</script>

<style scoped>
  .remote-select {
    width: 100%;
  }
</style>

