<template>
  <div class="common-index">
    <div class="search-area" v-if="searchConfig.showSearch">
      <slot name="search-area">
        <search-area
          :show-expand="searchConfig.showExpand"
          ref="searchArea"
          @onKeydownSearch="search"
          @changeSearchParam="changeSearchParam"
        >
          <div slot="default">
            <slot name="search-default"></slot>
          </div>

          <div slot="extend">
            <slot name="search-expand"></slot>
          </div>
        </search-area>
      </slot>
    </div>

    <div class="action-area" v-if="showAction">
      <slot name="action-area"></slot>
    </div>

    <div class="table-area">
      <slot name="table-area">
        <Table
          :columns="tableConfig.columns"
          :data="tableData"
          :height="tableConfig.height"
          :highlight-row="tableConfig.highlightRow"
          :stripe="tableConfig.stripe"
          @on-row-click="onClickTableRow"
          @on-row-dblclick="onDbClickTableRow"
          @on-select="onSelect"
          @on-select-cancel="onSelectCancel"
          @on-select-all="onSelectAll"
          @on-selection-change="onSelectChange"
          v-loading="tableLoading"
          element-loading-text="拼命加载中"
          border
        />
      </slot>
    </div>

    <div class="page-load" v-if="pageConfig.showPage">
      <slot name="page-area">
        <Page
          :total="total"
          :current="currentPage"
          :page-size="pageSize"
          :show-elevator="pageConfig.showElevator"
          :show-sizer="pageConfig.showSizer"
          :show-total="pageConfig.showTotal"
          placement="top"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizeChange"
        />
      </slot>
    </div>

    <slot></slot>
  </div>
</template>


<script>
// 参数设置有所不同，所以表格高度自适应这里不做处理，
// 可以使用$refs调用该组件的setMaxHeightOfFixedTable方法设置，
// 具体使用方法可以查看@/mixins/setMaxHeightToTable.js文件
import SearchArea from "./search-area.vue";
import setMaxHeightOfFixedTable from "@/mixins/setMaxHeightToTable.js";
export default {
  components: {
    SearchArea
  },

  mixins: [setMaxHeightOfFixedTable],

  props: {
    //   搜索区域配置
    searchConfig: {
      type: Object,
      default: () => {
        return {
          showExpand: false,
          showSearch: true
        };
      }
    },

    //   是否显示操作按钮
    showAction: {
      type: Boolean,
      default: true
    },

    //  默认表格参数配置(也可自定义表格)
    tableConfig: {
      type: Object,
      default: () => {
        return {
          columns: [],
          height: "",
          highlightRow: false,
          stripe: false
        };
      }
    },

    // 表格数据
    tableData: {
      type: Array,
      default: () => []
    },

    // 分页器配置
    pageConfig: {
      type: Object,
      default: () => {
        return {
          showPage: true,
          showElevator: true,
          showSizer: true,
          showTotal: true
        };
      }
    },

    //  当前页码
    currentPage: {
      type: [Number, String],
      default: 1
    },

    // 总条数
    total: {
      type: [Number, String],
      default: 0
    },

    pageSize: {
      type: [Number, String],
      default: 10
    },

    // 表格loading
    tableLoading: {
      type: Boolean,
      default: false
    }
  },

  data() {
    return {};
  },

  methods: {
    //   搜索
    search() {
      this.$emit("search");
    },

    //  是否展开搜索折叠区域（是否使用折叠区域的搜索参数）
    /**
     * @val Boolean 折叠区域是否展开
     */
    changeSearchParam(val) {
      this.$emit("changeSearchParam", val);
    },

    // 单击某行表格
    /**
     * @row Object 当前选中的行
     * @index Number 当前选中的行号
     */
    onClickTableRow(row, index) {
      this.$emit("onClickTableRow", row, index);
    },

    // 双击某行表格
    /**
     * @row Object 当前选中的行
     * @index Number 当前选中的行号
     */
    onDbClickTableRow(row, index) {
      this.$emit("onDbClickTableRow", row, index);
    },

    // 在多选模式下有效，选中某一项时触发
    /**
     * @selection Array 已选中的数据
     * @row  Object 当前选中项
     */
    onSelect(selection, row) {
      this.$emit("onSelect", selection, row);
    },

    // 多选模式下有效，取消选中某一项时触发
    /**
     * @selection Array 已选中的数据
     * @row Object 当前取消项
     */
    onSelectCancel(selection, row) {
      this.$emit("onSelectCancel", selection, row);
    },

    // 在多选模式下有效，点击全选时触发
    /**
     * @selection Array 已选中的数据
     */
    onSelectAll(selection) {
      this.$emit("onSelectAll", selection);
    },

    // 在多选模式下有效，只要选中项发生变化时就会触发
    /**
     * @selection Array 已选中的数据
     */
    onSelectChange(selection) {
      this.$emit("onSelectChange", selection);
    },

    // 页码发生变化
    /**
     * @page  Number 当前页码
     */
    onPageChange(page) {
      this.$emit("onPageChange", page);
    },

    // 一页显示数量发生变化
    /**
     * @pageSize  Number 当前一页显示多少条数据
     */
    onPageSizeChange(pageSize) {
      this.$emit("onPageSizeChange", pageSize);
    }
  }
};
</script>

<style lang="less" scoped>
.search-area {
  margin-bottom: 15px;
}

.action-area {
  margin-bottom: 15px;
}

.table-area {
  margin-bottom: 15px;
}

.page-load {
  margin: 15px;
  text-align: right;
}
</style>

