<template>
  <Modal
    width="700"
    v-model="modal"
    :title="title"
    :loading="loading"
    :mask-closable="false"
    ok-text="提交"
    @on-ok="ok"
    @on-cancel="cancel"
    class="sys-set-modal">
    <transition name="fade">
      <Form ref="form" :model="form" :label-width="100" v-if="modal">

        <Form-item
          v-for="(item, index) in editOptions "
          :key="index"
          :prop="item.key"
          :label="item.title"
          :rules="item.typeConfig.validate.rules"
          :class="item.typeConfig.row ? 'dialog-form-item-row' : 'dialog-form-item'"
        >
          <component
            :ref="'item' + index"
            :is="item.type || 'i-input'"
            v-model="form[item.key]"
            :config="item.typeConfig"
            :placeholder="item.placeholder"
            :form="form"
            @on-change="onChange(index,form[item.key])"
          >
          </component>
        </Form-item>

      </Form>
    </transition>

    <transition name="fade">
      <component
        ref="component"
        v-if="modal && componentShow"
        :is="componentModel"
      >
      </component>
    </transition>
    <div slot="footer">
            <Button  size="large" style="width:70px;"   @click="cancel">取消</Button>
            <Button type="primary" size="large" style="width:70px;" :loading="buttonLoading" @click="ok">提交</Button>
            
    </div>
  </Modal>
</template>

<script>
  import { postFormData,putFormData } from '@/service/getData'

  const getFormInit = (data) => {
    let result = {}
    for (let i=0; i<data.length; i++) {
      result[data[i].key] = ''
    }

    return result
  }

  export default{
    name: 'GridDialog',
    props: ['value', 'editOptions', 'url','editkey'],
    data(){
      return {
        buttonLoading:false,
        dialogType: 'add',
        modal: false,
        modal_loading: false,
        loading: true,
        form: getFormInit(this.editOptions),
        componentShow: false,
        componentModel: ''
      }
    },
    computed: {
      title () {
        if (this.dialogType === 'edit') {
            return '编辑'
        }

        if (this.dialogType === 'add') {
            return '添加'
        }

        return '编辑'
      }
    },
    watch: {
      value (val) {
        if (val === this.modal) {
          return
        }
        this.modal = val
      },
      modal (val) {
        this.$emit('input', val)
      }
    },
    methods: {
      ok () {
        this.$refs.form.validate(valid => {
          if (valid) {
            this.buttonLoading = true;
            let postData = JSON.parse(JSON.stringify(this.form))
            this.$emit('before-submit', postData, this.getEditType())
            // 多层级选择时候的
            let from_id = this.$store.getters.getLogId
             if(from_id*1 > 0){
               postData.front_id = from_id
             }
             if (this.dialogType === 'edit') {
                putFormData(this.url, postData[this.editkey] , postData).then(resp => {
                  this.modal = false;
                  this.buttonLoading = false;
                  this.$emit('ok')
                }, error => {
                  this.buttonLoading = false;
                  this.loading = false
                  this.$nextTick(() => {
                    this.loading = true
                  })
                })

             }else if( this.dialogType === 'add' ){
                postFormData(this.url, postData).then(resp => {
                  this.buttonLoading = false;
                  this.modal = false
                  this.$emit('ok')
                }, error => {
                  this.loading = false
                  this.buttonLoading = false;
                  this.$nextTick(() => {
                    this.loading = true
                  })
                })
             }
            

          } else {
            this.loading = false
            this.$nextTick(() => {
              this.loading = true
            })
          }
        })

      },

      cancel () {
        this.modal = false
      },
      showByAdd (form) {
        for (let key in form) {
          this.form[key] = form[key]
        }
        this.modal = true
        this.dialogType = 'add'
      },
      showByEdit (form) {
        for (let key in form) {
          this.form[key] = form[key]
        }
        this.modal = true
        this.dialogType = 'edit'
      },
      showComponent (component) {
        this.componentShow = true
        this.componentModel = component
      },
      hideComponent () {
        this.componentShow = false
      },
      onChange(index, value) {
        let component = this.$refs.component

        if (component && component.updateByChange) {
          component.updateByChange(index, value)
        }
      },
      getEditType () {
        return this.dialogType
      }
    }
  }
</script>

<style scoped lang="less">
  .dialog-form-item {
    display: inline-block;
    width: 330px;
  }

  .dialog-form-item-row {
    display: inline-block;
    width: 660px;
  }
  .fade-enter-active, .fade-leave-active {
    transition: opacity 1s
  }
  .fade-enter, .fade-leave-active {
    opacity: 0
  }

</style>
