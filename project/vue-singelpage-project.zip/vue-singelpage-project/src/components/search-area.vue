<template>
  <div class="search-area-contianer">
    <Form :label-width="85" ref="form" @keydown.enter.native.prevent="onKeydown">
      <div class="default-area">
        <slot name="default"></slot>
      </div>
      <div class="extend-area" :class="{open: this.extendAreaStatus}" v-if="showExpand">
        <slot name="extend"></slot>
      </div>
      <div class="extendContainer" @click="toggleExtendArea" v-if="showExpand">
        <div class="line" v-if="!extendAreaStatus" title="使用更多搜索条件">
          <span class="text">更多</span>
          <div class="icon-container">
            <Icon :size="18" color="#666" class="icon" type="ios-arrow-down"></Icon>
            <Icon :size="18" color="#666" class="icon second" type="ios-arrow-down"></Icon>
            <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-down"></Icon>
          </div>
        </div>
        <div class="line" v-else title="关闭更多搜索条件">
          <span class="text">收起</span>
          <div class="icon-container">
            <Icon :size="18" color="#666" class="icon" type="ios-arrow-up"></Icon>
            <Icon :size="18" color="#666" class="icon second" type="ios-arrow-up"></Icon>
            <Icon :size="18" color="#666" class="icon thrid" type="ios-arrow-up"></Icon>
          </div>
        </div>
      </div>
    </Form>
  </div>
</template>
<script>
export default {
  props: {
    showExpand: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      extendAreaStatus: false,
      useExtendParams: false
    };
  },
  methods: {
    toggleExtendArea() {
      this.toggleParams().then(() => {
        this.$emit("changeSearchParam", this.useExtendParams);
      });
    },
    toggleParams() {
      return new Promise((resolve, reject) => {
        this.extendAreaStatus = !this.extendAreaStatus;
        this.useExtendParams = !this.useExtendParams;
        resolve();
      });
    },

    onKeydown() {
      this.$emit("onKeydownSearch");
    },

    expandMore() {
      this.extendAreaStatus = true;
      this.useExtendParams = true;
      this.$emit("changeSearchParam", this.useExtendParams);
    }
  }
};
</script>
<style lang="less" rel="styleSheet/less">
.search-area-contianer {
  height: auto;
  .ivu-form-item {
    margin-bottom: 8px;
  }
  .extend-area {
    height: 0;
    overflow: hidden;
    transition: all 1s;
    &.open {
      height: auto;
      overflow: visible;
    }
  }
  .extendContainer {
    position: relative;
    width: 100%;
    margin-top: 5px;
    border-top: 1px solid #ccc;
    .line {
      cursor: pointer;
      width: 60px;
      height: 20px;
      margin: 0px 5px;
      padding: 0 10px;
      position: absolute;
      top: -10px;
      left: 50%;
      transform: translate(-50%, 0);
      background-color: #fff;
      .icon-container {
        float: left;
        display: inline-block;
        position: relative;
        margin-left: 2px;
        .icon {
          display: block;
          position: absolute;
          top: -3px;
          &.second {
            top: 0px;
          }
          &.thrid {
            top: 3px;
          }
        }
      }
      .text {
        float: left;
        font-size: 12px;
        color: #666;
      }
    }
  }
}
</style>
