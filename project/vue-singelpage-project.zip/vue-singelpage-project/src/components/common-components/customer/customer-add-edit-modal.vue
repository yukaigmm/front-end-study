<template>
  <Modal
    width="1000"
    v-model="modal"
    :title="status == 'add' ? '新增联系人' : '编辑联系人'"
    :loading="loading"
    :mask-closable="false"
  >
    <div slot="close" @click="cancel">
      <Icon type="ios-close-empty"></Icon>
    </div>

    <div slot="footer">
      <Button @click="identifyVisitCard" v-if="status =='edit'">识别名片</Button>
      <Button size="large" style="width:70px;" @click="cancel">取消</Button>
      <Button
        type="primary"
        size="large"
        style="width:70px;"
        :loading="buttonLoading"
        @click="ok"
      >提交</Button>
    </div>
    <customer-info
      ref="customerInfo"
      :orgNameString="orgNameString"
      @cancelButtonLoading="cancelButtonLoading"
    ></customer-info>
  </Modal>
</template>
<script>
import { postFormData, putFormData } from "@/service/getData";
import customerInfo from "@/components/common-components/customer/customer-info.vue";
export default {
  props: {
    orgNameString: {
      type: String
    }
  },
  components: {
    customerInfo
  },
  data() {
    return {
      status: "",
      modal: false,
      loading: false,
      buttonLoading: false
    };
  },

  computed: {},

  mounted() {},

  methods: {
    identifyVisitCard() {
      this.$refs.customerInfo.identifyVisitCard();
    },
    // 提交
    ok() {
      this.buttonLoading = true;
      this.$refs.customerInfo.getSubmitFormData().then(submitData => {
        if (submitData) {
          if (this.status === "edit") {
            this.submitEditData(submitData);
          } else {
            this.submitAddData(submitData);
          }
        } else {
          this.cancelButtonLoading();
        }
      });
    },

    // 添加联系人
    submitAddData(submitData) {
      postFormData("index/contact", {
        ...submitData,
        isValid: 1,
        contacts_type: "99"
      }).then(resp => {
        this.buttonLoading = false;
        if (resp.code === 20000) {
          this.$Message.success("添加成功");
          this.cancel();
          this.$emit("refreshContactTable");
        } else {
          this.$Message.error("添加失败 " + resp.msg);
        }
      });
    },

    // 编辑联系人
    submitEditData(submitData) {
      putFormData("/index/contact", this.personId, submitData).then(resp => {
        this.buttonLoading = false;
        if (resp.code === 20000) {
          this.$Message.success("修改成功");
          this.cancel();
          this.$emit("refreshContactTable");
        } else {
          this.$Message.error("修改失败 " + resp.msg);
        }
      });
    },

    // 取消
    cancel() {
      this.modal = false;
      this.buttonLoading = false;
      this.$refs.customerInfo.resetForm();
    },

    // 显示树状结构
    show(status, orgId, personId) {
      this.status = status;
      this.personId = personId;
      if (status === "add") {
        this.$refs.customerInfo.show(orgId);
      } else {
        this.$refs.customerInfo.show(orgId, personId);
      }
      this.modal = true;
    },

    // 取消modal的确定按钮loading
    cancelButtonLoading() {
      this.buttonLoading = false;
    }
  }
};
</script>
<style lang="less" scoped>
</style>
