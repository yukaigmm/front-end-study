<template>
  <div v-loading="modalLoading" class="common-customer-info" element-loading-text="loading...">
    <Form ref="formData" :model="formData" :rules="ruleValidate" :label-width="80">
      <Row>
        <Col span="11" offset="1" class="visit-card">
          <FormItem
            prop="visiting_card_url"
            label="名片"
            :class="[{ 'ivu-form-item-required': isOrgNameOrVisitCardRequired }]"
          >
            <!-- <Upload
              v-loading="imgLoading"
              element-loading-text="上传中，请稍候"
              :show-upload-list="false"
              :default-file-list="defaultFileList"
              ref="upload"
              accept="image/*"
              action="api/common/uploadFile"
              :on-error="onUploadError"
              :on-success="onUploadSuccess"
              :before-upload="beforeUpload"
              style="display: inline-block;width:362px;height:214px;border:1px dotted #ccc;"
              :data="{fileType:'visitingCard'}"
            >
              <div class="upload-list-img" v-if="imgUrl">
                <img :src="imgUrl" :alt="formData.name+'名片'">
                <div class="upload-list-cover">
                  <div class="change-button" title="更换名片">
                    <Icon type="ios-cloud-upload"></Icon>
                  </div>
                  <div class="preview-button" @click="onPreviewCard" title="预览">
                    <Icon type="ios-eye-outline"></Icon>
                  </div>
                  <div class="delete-button" @click="onUploadsRemove" title="删除名片">
                    <Icon type="ios-trash-outline"></Icon>
                  </div>
                </div>
              </div>

              <div v-else class="upload-button-container" title="上传名片">
                <Icon type="camera" size="20"></Icon>
              </div>
            </Upload>-->

            <upload-visit-card
              actionUrl="teIdentifyBusinesscard"
              uploadStyle="display: inline-block;width:362px;height:214px;border:1px dotted #ccc;"
              :data="{fileType:'visitingCard'}"
              ref="uploadVisitCard"
              @getResponse="getVisitCardUrl"
            >
              <div class="upload-list-img" v-if="imgUrl">
                <img :src="imgUrl" :alt="formData.name+'名片'" @click="onPreviewCard">
                <div class="upload-list-cover">
                  <div class="change-button" title="更换名片">
                    <Icon type="ios-cloud-upload"></Icon>
                  </div>
                  <div class="preview-button" @click="onPreviewCard" title="预览">
                    <Icon type="ios-eye-outline"></Icon>
                  </div>
                  <div class="delete-button" @click="onUploadsRemove" title="删除名片">
                    <Icon type="ios-trash-outline"></Icon>
                  </div>
                </div>
              </div>

              <div v-else class="upload-button-container" title="上传名片">
                <Icon type="camera" size="20"></Icon>
              </div>
            </upload-visit-card>
          </FormItem>
        </Col>
        <Col span="11" offset="1">
          <Form-item label="姓名" prop="name">
            <Input v-model.trim="formData.name" placeholder="请输入姓名"></Input>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="职务" prop="post">
            <Input v-model.trim="formData.post" placeholder="请输入职务"></Input>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="手机" prop="telephone">
            <Input
              v-model.trim="formData.telephone"
              :disabled="ifTelephoneDisabled"
              placeholder="请输入手机"
            ></Input>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="微信" prop="weichat">
            <Input v-model.trim="formData.weichat" placeholder="请输入微信"></Input>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="用户" prop="contacts_type">
            <select-url :config="{cacheKey:'c_usertype'}" v-model="formData.contacts_type"></select-url>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="邮箱" prop="email" :class="{'ivu-form-item-required':this.imgUrl}">
            <Input v-model.trim="formData.email" placeholder="请输入邮箱"></Input>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="性别" prop="sex">
            <select-url :config="{cacheKey:'c_sex'}" v-model="formData.sex"></select-url>
          </Form-item>
        </Col>

        <Col span="11" offset="1">
          <Form-item label="年龄" prop="age">
            <select-url :config="{cacheKey:'c_age'}" v-model="formData.age"></select-url>
          </Form-item>
        </Col>
        <Col span="11" offset="1">
          <Form-item label="公司/部门" prop="age">
            <Input
              placeholder="请选择公司/部门"
              v-model="orgNameStr"
              :title="orgNameStr"
              @on-focus="showDeptSelectModal"
            ></Input>
          </Form-item>
        </Col>
        <Col span="23" offset="1">
          <!-- 用户标签 -->
          <Form-item label="画像" prop="portrait" class="dialog-form-item-row">
            <!-- 用户标签 -->
            <Tag
              v-if="portraitData"
              v-for="(item, index) in portraitData"
              :key="index"
              :style="getStyle(item.style)"
              :name="item.value"
              closable
              @on-close="delPort"
            >{{item.name}}</Tag>

            <!-- tag 添加按钮 -->
            <Select
              v-if="addTags"
              transfer
              v-model="modelPort"
              filterable
              remote
              style="width:100px"
              @on-change="selectPort"
              :remote-method="remoteMethodPort"
              :loading="loadingPort"
              placeholder="添加标签"
            >
              <Option v-for="(option,index) in optionsPort" :value="option.value" :key="index">
                <Tag :style="option.style">{{option.name}}</Tag>
              </Option>
            </Select>

            <div style="display:inline-block;">
              <Tag @click.native="addMore">
                <span v-if="!addTags">
                  <Icon type="plus"></Icon>
                </span>

                <span v-else>
                  <Icon type="minus"></Icon>
                </span>
              </Tag>
            </div>
          </Form-item>
        </Col>
      </Row>
    </Form>
    <div class="company-change-log-container">
      <div class="change-log-title" @click="toggleLogTableVisibility">公司/职务变更日志</div>
      <div class="change-log-table-container" v-show="showLogTable">
        <change-log-table :showLogTable="showLogTable" :personId="personId" ref="changeLogTable"></change-log-table>
      </div>
    </div>
    <!--  -->
    <customer-dept ref="customerDept" @submit="getCheckedDept"></customer-dept>
  </div>
</template>
<script>
import SelectUrl from "@/components/inputs/select-url";
import SelectUrlBox from "@/components/inputs/select-url-box";
import customerDept from "./subcomponents/customer-dept-select-modal.vue";
import changeLogTable from "./subcomponents/changeLogTable.vue";
import { putFormData, getRow } from "@/service/getData";
import { getCache } from "@/plugin/cache";
import uglifyPic from "@/mixins/condensePic";
import eventBus from "./eventBus";
import UploadVisitCard from "../../upload-visit-card.vue";
import _ from "lodash";
export default {
  mixins: [uglifyPic],
  props: {
    orgNameString: {
      type: String
    }
  },
  components: {
    SelectUrl,
    SelectUrlBox,
    customerDept,
    changeLogTable,
    UploadVisitCard
  },
  watch: {
    orgId: {
      handler(val) {
        if (val) {
          eventBus.$emit("getOrgIdAndOrgNameStr", {
            orgId: val,
            orgNameStr: this.orgNameStr
          });
        }
      },
      deep: true,
      immediate: true
    }
  },
  data() {
    const validateEmail = (rules, value, callback) => {
      let errors = [];
      if (this.imgUrl) {
        if (!value) {
          errors.push(new Error("邮箱不能为空！"));
        } else {
          callback(errors);
        }
      }
      callback(errors);
    };
    return {
      imgLoading: false,
      loading: false,
      orgId: 0,
      personId: 0,
      formData: {},
      orgNameStr: "",
      treeProps: {
        label: (data, node) => data.title
      },
      deptTreeData: [],
      ruleValidate: {
        post: [
          {
            required: true,
            message: "请输入职务信息",
            trigger: "change, blur"
          }
        ],
        name: [
          {
            required: true,
            message: "请输入姓名",
            trigger: "change, blur"
          }
        ],
        telephone: [
          {
            pattern: /^((\+?86)|(\(\+86\)))?1(3|4|5|6|7|8|9)\d{9}$/,
            message: "请输入正确的电话",
            trigger: "change, blur"
          }
        ],
        email: [
          {
            pattern: /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/,
            message: "请输入正确的邮箱",
            trigger: "change, blur"
          },
          {
            validator: validateEmail
          }
        ],
        sex: [
          {
            required: true,
            message: "请选择性别",
            trigger: "change"
          }
        ],
        contacts_type: [
          {
            required: true,
            message: "请选择用户类型",
            trigger: "change"
          }
        ]
      },
      modalLoading: false,
      loadingPort: false,
      optionsPort: [],
      portraitData: [],
      modelPort: "",
      addTags: false,
      isOrgNameOrVisitCardRequired: false,
      defaultFileList: [],
      imgUrl: "",
      showLogTable: false,
      ifOtherCompany: false,
      ifTelephoneDisabled: false
    };
  },
  computed: {
    cacheData() {
      let cacheDatas = getCache("c_port_all");
      return cacheDatas;
    }
  },

  mounted() {
    this.optionsPort = JSON.parse(JSON.stringify(this.cacheData));
  },

  methods: {
    identifyVisitCard() {
      let params = {
        imgPath: this.imgUrl
      };
      if (!this.imgUrl) {
        this.$Message.warning("请先上传名片!");
        return;
      }
      this.$Message.loading("识别中，请稍候...");
      this.$http.post("teIdentifyBusinesscard", params).then(res => {
        this.$Message.destroy();
        if (res.code === 20000) {
          // 获取识别信息
          this.getVisitCardUrl(res, true);
          this.$Message.success("识别成功！");
        } else {
          this.$Message.error(`识别失败:${res.msg}`);
        }
      });
    },

    getStyle(styleObj) {
      return {
        ...styleObj,
        fontSize: `${styleObj.fontSize}px`
      };
    },
    show(orgId, personId) {
      this.personId = personId;
      this.orgId = orgId;
      this.orgNameStr = this.orgNameString;
      if (personId != -1 && personId !== undefined) {
        //获取用户信息，填充到表单,其中包括标签
        this.modalLoading = true;
        getRow("index/contact", personId).then(resp => {
          if (resp.code === 20000) {
            let data = JSON.parse(JSON.stringify(resp.data));
            this.setOrgNameStr(data);
            this.getFormData(JSON.parse(JSON.stringify(data)));
            if (data.visiting_card_url) {
              this.getImgUrl(data.visiting_card_url);
            }
            if (data.portrait && data.portrait.length) {
              this.portraitData = this.cacheData.filter(item => {
                return data.portrait.indexOf(item.value) != -1;
              });
            } else {
              this.portraitData = [];
            }

            this.orgId = resp.data.org_id;
          } else {
            this.$Message.error(resp.msg);
          }
          this.modalLoading = false;
        });
      }
    },
    getFormData(data) {
      // 没有时默认为0，不应该显示
      data.age = data.age || "";
      data.sex = data.sex || "";
      data.contacts_type = data.contacts_type || "";
      if (!!data.telephone) {
        this.ifTelephoneDisabled = true;
      } else {
        this.ifTelephoneDisabled = false;
      }
      this.formData = data;
    },
    addMore() {
      this.addTags = !this.addTags;
    },
    // 画像设置
    selectPort(val) {
      let port = _.filter(this.cacheData, item => {
        return item.value === val;
      })[0];
      let isRepeat = _.some(this.portraitData, item => {
        return item.value === port.value;
      });
      if (!isRepeat) {
        this.portraitData.push(port);
      }
      this.addTags = false;
      this.modelPort = "";
      this.optionsPort = JSON.parse(JSON.stringify(this.cacheData));
    },
    remoteMethodPort(query) {
      if (query !== "") {
        this.loadingPort = true;
        setTimeout(() => {
          this.loadingPort = false;

          let optionsPort = _.filter(this.cacheData, item => {
            return item.name.indexOf(query) !== -1;
          });
          if (_.isEmpty(optionsPort)) {
            optionsPort = JSON.parse(JSON.stringify(this.cacheData));
          }
          this.optionsPort = optionsPort;
        }, 100);
      } else {
        this.optionsPort = JSON.parse(JSON.stringify(this.cacheData));
      }
    },
    delPort(e, val) {
      let portData = JSON.parse(JSON.stringify(this.portraitData));
      _.remove(portData, item => {
        return item.value === val;
      });
      this.portraitData = portData;
    },
    // 表单验证
    validateForm() {
      return new Promise((resolve, reject) => {
        this.$refs.formData.validate(valid => {
          if (valid) {
            this.validateTelephone().then(res => {
              resolve();
            });
          } else {
            reject();
            this.$Message.error("请按要求填充");
          }
        });
      });
    },
    // 验证手机号
    validateTelephone() {
      return new Promise((resolve, reject) => {
        if (this.formData.telephone) {
          this.$http
            .get(`contact/getUserByPhone/${this.formData.telephone}`)
            .then(res => {
              if (res.code === 20000) {
                if (res.data.id && res.data.id != this.formData.id) {
                  let _this = this;
                  this.$Message.info({
                    // title:
                    content: `手机号重复,<br>该手机号联系人为<span style="margin:0 3px;color: #2d8cf0;font-weight: bold">${
                      res.data.name
                    }</span><br>
                  所在机构为：<span style="margin:0 3px;color: #2d8cf0;font-weight: bold">${res.data.bread
                    .map(bread => bread.title)
                    .join(" - ")}</span><br>
                  
                `,
                    duration: 3
                    // onOk: () => {
                    //   resolve();
                    // },
                    // onCancel: () => {
                    //   _this.$emit("cancelButtonLoading");
                    // }
                  });

                  resolve();
                } else {
                  resolve();
                }
              } else {
                resolve();
              }
            });
        } else {
          resolve();
        }
      });
    },
    getSubmitFormData() {
      return new Promise((resolve, reject) => {
        this.validateForm()
          .then(res => {
            //获取用户信息,包括标签
            let portIds = this.portraitData.length
              ? this.portraitData.map(item => {
                  return item.value;
                })
              : [];
            let data = {
              ...this.formData,
              portrait: portIds,
              confirm: 1,
              org_id: this.orgId
            };
            resolve(data);
          })
          .catch(res => {
            resolve();
          });
      });
    },
    resetForm() {
      this.formData = {};
      this.imgUrl = "";
      this.orgNameStr = "";
      this.portraitData = [];
      this.$refs.formData.resetFields();
      this.showLogTable = false;
      this.orgId = "";
      this.ifTelephoneDisabled = false;
      this.$refs.changeLogTable.clearChangeLogData();
    },

    getVisitCardUrl(res, hasCard) {
      if (!hasCard) {
        this.formData.visiting_card_url =
          res.data.path || this.formData.visiting_card_url;
        this.$refs.formData.validateField("visiting_card_url");
        this.getImgUrl(res.data.path);
      }
      // 名片上传成功，但未识别成功！
      if (res.code === 21000) {
        return;
      }
      let phone = res.data.phone || res.data.telephone;
      let telephone = phone
        ? phone
            .split("-")
            .join("")
            .trim()
        : "";
      let params = {
        name: res.data.name ? res.data.name.trim() : "",
        post: res.data.position ? res.data.position.trim() : "",
        telephone: telephone,
        weichat: res.data.wechat ? res.data.wechat.trim() : "",
        email: res.data.email ? res.data.email.trim() : ""
      };
      // 设置获取的信息
      this.getVisitCardInfo(params);
    },

    getVisitCardInfo(data = {}) {
      // 新增时
      if (!this.personId) {
        this.$set(this.formData, "name", data.name);
        this.$set(this.formData, "post", data.post);
        this.$set(this.formData, "telephone", data.telephone);
        this.$set(this.formData, "weichat", data.weichat);
        this.$set(this.formData, "email", data.email);
      } else {
        //  编辑时空值就填充
        let keys = ["name", "post", "telephone", "weichat", "email"];
        keys.forEach(key => {
          if (!this.formData[key]) {
            this.$set(this.formData, key, data[key]);
          }
        });
      }
    },

    getImgUrl(path) {
      let url;
      let picUrl = path;
      if (path.includes("/Onstage/")) {
        url =
          process.env.NODE_ENV === "production" ||
          process.env.NODE_ENV === "test"
            ? "https://fof.simuwang.com/"
            : "https://master-test.simuwang.com/";
      } else {
        url =
          process.env.NODE_ENV === "production"
            ? " http://static.simuwang.com/"
            : "https://static-test-ali.simuwang.com/";
        picUrl = `Uploads/crm/${path}`;
      }
      this.imgUrl = `${url}${picUrl}`;
    },
    // 点击文件 预览
    onPreviewCard(e) {
      e.stopPropagation();
      e.preventDefault();
      window.open(`${this.imgUrl}`);
      return false;
    },
    onUploadsRemove(e) {
      e.stopPropagation();
      e.preventDefault();
      this.formData.visiting_card_url = "";
      this.$refs.uploadVisitCard.clearFiles();
      this.imgUrl = "";
      this.$refs.formData.validateField("email");
      return false;
      // this.$refs.editAccountForm.validateField("visiting_card_url");
    },
    // 打开设置联系人部门的modal
    showDeptSelectModal() {
      this.$refs.customerDept.show(this.orgId);
    },
    // 指定部门树的每一个单元名称所对应的字段
    setDeptTreeLabel(node, data) {
      return data.title;
    },
    // 获取部门层级的字符串
    getCheckedDept(data, ifOtherCompany) {
      this.ifOtherCompany = ifOtherCompany;
      if (this.ifOtherCompany) {
        this.$Modal.confirm({
          title: "变更用户户所属公司",
          content: "点击继续将会停用该用户的所有关联账号，是否继续？",
          onOk: () => {
            let { checkedId, checkedLabelArr } = data;
            this.orgId = checkedId;
            this.orgNameStr = checkedLabelArr.join(">");
          },
          onCancel: () => {},
          okText: "继续",
          cancelText: "取消"
        });
      } else {
        let { checkedId, checkedLabelArr } = data;
        this.orgId = checkedId;
        this.orgNameStr = checkedLabelArr.join(">");
      }
    },
    // 设置
    setOrgNameStr(data) {
      let orgNameArr = [];
      data.bread.forEach(breadItem => {
        orgNameArr.push(breadItem.title);
      });
      this.orgNameStr = orgNameArr.join(">") || this.orgNameString;
    },
    // 切换职位变更日志
    toggleLogTableVisibility() {
      this.showLogTable = !this.showLogTable;
    }
  }
};
</script>
<style scoped lang="less">
.dialog-form-item {
  display: inline-block;
  width: 330px;
}

.dialog-form-item-row {
  display: inline-block;
  width: 660px;
}

.pull-right {
  float: right;
  margin-right: 10px;
}

.upload-list-img {
  cursor: pointer;
  vertical-align: top;
  display: inline-block;
  width: 360px;
  height: 212px;
  text-align: center;
  line-height: 212px;
  // border: 1px solid transparent;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  margin-right: 4px;

  img {
    width: 100%;
    height: 100%;
  }
}

.upload-button-container {
  width: 360px;
  height: 212px;
  line-height: 212px;
  text-align: center;
  overflow: hidden;
}

.upload-list-cover {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  position: absolute;
  z-index: 99999;
  height: 60px;
  bottom: -60px;
  left: 0;
  right: 0;
  line-height: 60px;
  background: rgba(0, 0, 0, 0.6);
  transition: all 0.5s ease;
  div {
    flex: 1;
  }
}

.upload-list-img:hover .upload-list-cover {
  // display: block;
  bottom: 0;
}

.upload-list-cover i {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 5px;
}

.common-customer-info {
  .el-checkbox__inner {
    &::before {
    }
  }
}

.company-change-log-container {
  padding-left: 82px;
  .change-log-title {
    color: #0c7beb;
    text-decoration: underline;
    cursor: pointer;
    margin-bottom: 5px;
    display: inline-block;
  }
}
</style>
