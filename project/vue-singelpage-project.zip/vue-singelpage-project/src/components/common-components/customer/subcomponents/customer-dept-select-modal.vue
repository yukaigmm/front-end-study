<template>
  <Modal
    v-model="modal"
    class="common-customer-dept-modal"
    title="设置联系人部门"
    @on-ok="ok"
    @on-cancel="cancel"
  >
    <Tabs :animated="false" @on-click="handleTabClick" v-model="currentTab">
      <TabPane
        v-for="tabInfo in companyTabConfig"
        :key="tabInfo.key"
        :label="tabInfo.label"
      >
        <tree-radio
          :show-search="showSearch"
          :ref="tabInfo.ref"
          :treeName="tabInfo.treeKey"
          :key="tabInfo.treeKey"
          :loading="loading"
          :treeData="tabInfo.treeData"
          :labelKey="'title'"
          :nodeKey="'id'"
          :treeProps="treeProps"
          :filter="true"
          :fuzzySearch="tabInfo.fuzzySearch"
          :justFilter="tabInfo.justFilter"
          :checkedKey="currentCompanyId"
          :defaultExpandKeys="tabInfo.defaultExpandKeys"
          @submit="getCurrentOrgIdAndOrgNameStr"
          @getTreeData="getOtherCompanyTreeData"
        ></tree-radio>
      </TabPane>
    </Tabs>
  </Modal>
</template>

<script>
import treeRadio from "@/components/tree-radio.vue";

export default {
  components: {
    treeRadio
  },
  props: {},
  data() {
    return {
      modal: false,
      treeProps: {
        label: (data, node) => data.title
      },
      currentCompanyId: 0,
      currentCompanyParentId: -1,
      currentCompanyTreeData: [],
      otherCompanyTreeData: [],
      loading: false,
      timerId: null,
      orgData: {},
      currentTab: 0,
    };
  },
  computed: {
    companyTabConfig() {
      return [
        {
          justFilter: true,
          ref: "currentCompanyTree",
          label: "当前公司",
          key: "currentCompanyTab",
          treeKey: "currentCompanyTree",
          treeData: this.currentCompanyTreeData,
          defaultExpandKeys: this.currentCompanyTreeData.length
            ? [this.currentCompanyTreeData[0].id, this.currentCompanyId]
            : [""]
        },
        {
          fuzzySearch: true,
          ref: "otherCompanyTree",
          label: "其他公司",
          key: "otherCompanyTab",
          treeKey: "otherCompanyTree",
          treeData: this.otherCompanyTreeData,
          defaultExpandKeys: [this.currentCompanyId]
        }
      ];
    },

    showSearch() {
      this.currentTab === 0 ? false : true;
    }
  },
  methods: {
    ok() {
      if (this.orgData.checkedId && this.orgData.checkedLabelArr) {
        let ifOtherCompany =
          this.currentTab == 0 ? false : true;
        this.$emit("submit", this.orgData,ifOtherCompany);
      }
      this.cancel();
    },
    cancel() {
      this.currentCompanyTreeData = [];
      this.otherCompanyTreeData = [];
      this.$refs.currentCompanyTree[0].clearFilterText();
      this.$refs.otherCompanyTree[0].clearFilterText();
      this.modal = false;
      this.currentTab = 0;
    },
    // 打开modal显示本公司树结构
    show(orgId) {
      this.modal = true;
      if (!orgId) {
        return;
      }

      this.currentCompanyId = orgId;
      this.loading = true;

      this.$http
        .get(`visit/getTreeByOrgId/${orgId}`, { orgParent: 1, showUser: 0 })
        .then(res => {
          if (res.code === 20000) {
            this.currentCompanyTreeData = res.data;
            this.currentCompanyParentId = res.data[0].id;
            setTimeout(() => {
              this.$refs.currentCompanyTree[0].setChecked(orgId);
            }, 100);
          } else {
            this.$Message.error(res.msg);
          }
          this.loading = false;
        });
    },
    handleTabClick(name) {
      // console.log(name);
    },
    // 获取当前选中公司的名字和部门字符串
    getCurrentOrgIdAndOrgNameStr(data) {
      this.currentCompanyId = data.checkedId;
      this.$refs.currentCompanyTree[0].setChecked(data.checkedId);
      this.$refs.otherCompanyTree[0].setChecked(data.checkedId);
      this.orgData = data;
    },
    // 模糊搜索公司树的回调
    getOtherCompanyTreeData(val) {
      this.loading = true;
      this.otherCompanyTreeData = [];
      let keywords = val.split(/\s+/);
      clearTimeout(this.timerId);
      this.timerId = setTimeout(() => {
        this.$http
          .get("visit/gettreebytype", {
            keywords,
            type: 2,
            showPerson: false
          })
          .then(res => {
            if (res.code === 20000) {
              let data = res.data || [];
              data.forEach(dataItem => {
                if (dataItem.id !== this.currentCompanyParentId) {
                  this.otherCompanyTreeData.push(dataItem);
                }
              });
            } else {
              this.$Message.error(res.msg);
            }
            this.loading = false;
          });
      }, 800);
    }
  }
};
</script>

<style lang="less">
.common-customer-dept-modal {
  .ivu-modal-mask {
    z-index: 1001;
  }
  .ivu-modal-wrap {
    z-index: 1002;
    .ivu-modal-body {
      overflow-y: auto;
      min-height: 300px;
      max-height: 500px !important;
      .tree-container {
        // height: 100%;
        min-height: 300px;
      }
      .ivu-tabs-content {
        // position: absolute;
        max-height: 400px;
        overflow-y: auto;
      }
    }
  }
}
</style>
