<template>
    <div v-loading="loading" element-loading-text="拼命加载中">
        <Table :columns="changeLogColumns" :data="changeLogData" height="200"></Table>
    </div>
</template>


<script>
export default {
	props: {
		showLogTable: {
			type: Boolean,
			default: false,
		},
		personId: {
			type: [String, Number],
		},
	},
	data() {
		return {
            loading: false,
			changeLogData: [],
			changeLogColumns: [
				{
					title: '起始时间',
					key: 'startTime',
					render: (h, { row }) => {
						return h('div', row.startTime || '--');
					},
				},
				{
					title: '结束时间',
					key: 'endTime',
					render: (h, { row }) => {
						return h('div', row.endTime || '--');
					},
				},
				{
					title: '原公司/部门',
					key: 'oldOrgNameStr',
					render: (h, { row }) => {
						return h('div', row.oldOrgNameStr || '--');
					},
				},
				{
					title: '原职位',
					key: 'oldPost',
					render: (h, { row }) => {
						return h('div', row.oldPost || '--');
					},
				},
				{
					title: '现公司/部门',
					key: 'newOrgNameStr',
					render: (h, { row }) => {
						return h('div', row.newOrgNameStr || '--');
					},
				},
				{
					title: '现职位',
					width: 120,
					key: 'newPost',
					render: (h, { row }) => {
						return h('div', row.newPost || '--');
					},
				},
			],
		};
	},
	watch: {
		showLogTable: {
			handler(val) {
				if (!this.changeLogData.length && val === true && this.personId) {
					this.getChangeLogData();
				}
			},
		},
	},
	methods: {
		// 获得变更日志数据
		getChangeLogData() {
            this.loading = true;
			this.$http.get('contactsChangeLog/getList', { contact_id: this.personId, rows: 10, page: 1 }).then(res => {
				if (res.code === 20000) {
					// this.changeLogData = res.data.records;
					let records = res.data.records || [];
					records.forEach(record => {
						let newOrgNameArr = [];
						let oldOrgNameArr = [];
						let { startTime, endTime, newPost, oldPost } = record;
						record.newBread.forEach(org => {
							newOrgNameArr.push(org.title);
						});
						record.oldBread.forEach(org => {
							oldOrgNameArr.push(org.title);
						});
						let newOrgNameStr = newOrgNameArr.join('>');
						let oldOrgNameStr = oldOrgNameArr.join('>');
						this.changeLogData.push({ startTime, endTime, newPost, oldPost, newOrgNameStr, oldOrgNameStr });
					});
				}else{
                    this.$Message.error(res.msg);
                }
                this.loading = false;
			});
		},
		// 清除变更日志
		clearChangeLogData() {
			this.changeLogData = [];
		},
	},
};
</script>
