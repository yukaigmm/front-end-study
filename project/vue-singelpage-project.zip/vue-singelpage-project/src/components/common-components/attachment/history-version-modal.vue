<template>
   <Modal
    v-model="modal"
    title="文件历史版本"
    :mask-closable="false"
    width="1200"
   >
      <div slot="close" @click="onCancel">
            <Icon type="ios-close-empty"></Icon>
      </div>

      <div slot="footer">
             <div class="page-load">
               <Page
                 :total="total"
                 :current="currentPage"
                 :page-size="pageSize"
                 @on-change="onPageChange"
                 @on-page-size-change="onPageSizeChange"
                 placement="top"
                 show-elevator
                 show-sizer
                 show-total
               />
            </div>
      </div>

      <div class="table-area">
         <Table
           :data="tableData"
           :columns="columns"
           v-loading="tableLoading"
           element-loading-text="拼命加载中"
           border
          />
     </div>

  

   </Modal>
</template>

<script>
import $ from "jquery";
import getMinusNumber from "@/mixins/getMinusNumber";

export default {
  mixins: [getMinusNumber],

  data() {
    return {
      modal: false,
      tableData: [],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10,
      docId: "",
      orgId: "",
      hasDataChanged: false
    };
  },

  computed: {
    columns() {
      return [
        {
          title: "文件名称",
          key: "docName",
          width: 200,
          render: (h, { row }) => {
            return h(
              "a",
              {
                style: {
                  display: "inline-block",
                  width: "100%",
                  height: "100%",
                  maxWidth: "200px",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  textOverflow: "ellipsis"
                },
                attrs: {
                  title: row.docName
                },
                on: {
                  click: () => {
                    this.viewFile(row.docId, row.id);
                  }
                }
              },
              row.docName
            );
          }
        },
        {
          title: "文件类型",
          key: "docType",
          width: 100,
          render: (h, { row }) => {
            let fileTypeMapping = [
              {
                label: "尽调资料",
                value: 7
              },
              {
                label: "路演资料",
                value: 4
              },
              {
                label: "数据资料",
                value: 8
              },
              {
                label: "合同资料",
                value: 1
              },
              {
                label: "研究报告",
                value: 5
              },
              {
                label: "公司介绍",
                value: 3
              },
              {
                label: "基金经理介绍",
                value: 2
              },
              {
                label: "其他",
                value: 6
              }
            ];
            let text = fileTypeMapping.filter(
              item => item.value == row.docType
            )[0]
              ? fileTypeMapping.filter(item => item.value == row.docType)[0][
                  "label"
                ]
              : "--";
            return h("span", text);
          }
        },
        {
          title: "上传时间",
          key: "docTime",
          width: 100,
          render: (h, { row }) => {
            if (row.docTime) {
              return h("span", row.docTime.slice(0, 11));
            } else {
              return h("span", "--");
            }
          }
        },
        {
          title: "上传人",
          key: "creater",
          width: 100
        },
        {
          title: "文件来源",
          key: "docSource",
          width: 100,
          render: (h, { row }) => {
            let mapping = [
              {
                label: "联系人提供",
                value: 1
              },
              {
                label: "公开资料",
                value: 2
              },
              {
                label: "其他",
                value: 3
              }
            ];

            let text = mapping.filter(item => item.value == row.docSource)[0]
              ? mapping.filter(item => item.value == row.docSource)[0]["label"]
              : "--";
            return h("span", text);
          }
        },
        {
          title: "文档提供人",
          key: "docUserName",
          width: 100
        },
        {
          title: "机构名称",
          key: "orgName",
          width: 210,
          render: (h, { row }) => {
            return h(
              "span",
              {
                style: {
                  display: "inline-block",
                  width: "100%",
                  height: "100%",
                  maxWidth: "200px",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  textOverflow: "ellipsis"
                },
                attrs: {
                  title: row.orgName
                }
              },
              row.orgName || "--"
            );
          }
        },
        {
          title: "文件可见范围",
          key: "docOpenScope",
          width: 150,
          render: (h, { row }) => {
            let mapping = [
              {
                label: "公司内部",
                value: 1
              },
              {
                label: "完全公开",
                value: 2
              }
            ];

            let text = mapping.filter(item => item.value == row.docOpenScope)[0]
              ? mapping.filter(item => item.value == row.docOpenScope)[0][
                  "label"
                ]
              : "--";

            return h("span", text);
          }
        },
        {
          title: "操作",
          width: 100,
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.deleteFile(
                        row.docId,
                        row.docTime,
                        row.docName,
                        row.orgId,
                        row.id
                      );
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ];
    }
  },

  mounted() {
    this.setMaxHeightOfFixedTable();
  },

  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable() {
      let maxHeight = $("body").height() * 0.7 - 100;
      let minusNumber = this.getMinusNumberOfFixedTable();
      let targetTable = $(this.$el).find(".table-area");
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight - minusNumber + "px");
    },

    getHistoryVersionData() {
      this.tableLoading = true;
      let params = {
        pageSize: this.pageSize,
        pageNo: this.currentPage
      };
      try {
        this.$http
          .get(`orgDocument/history/${this.orgId}/${this.docId}`, params)
          .then(res => {
            this.tableLoading = false;
            if (res.code === 20000) {
              this.tableData = res.data.records;
              this.total = res.data.total;
            } else {
              this.$Message.warning("获取附件列表失败");
            }
          });
      } catch (e) {
        this.tableLoading = false;
        this.$Message.error("获取历史附件失败！");
      }
    },

    show(docId, orgId) {
      this.modal = true;
      this.docId = docId;
      this.orgId = orgId;
      this.getHistoryVersionData();
    },

    onCancel() {
      this.modal = false;
      this.tableData = [];
      this.currentPage = 1;
      this.pageSize = 10;
      this.total = 0;
      if (this.hasDataChanged) {
        this.hasDataChanged = !this.hasDataChanged;
        this.$emit("refreshTable");
      }
    },
    /**
     * @param docId {type:number} 文档id
     * @param docTime {type:string} 文档上传时间
     * @param docName {type:string} 文档名称
     * @param orgId {type：number} 文档所属机构id
     * @param id {type：number}  当前历史文档id
     */
    // 删除附件
    deleteFile(docId, docTime, docName, orgId, id) {
      this.$Modal.confirm({
        title: "删除文件",
        content: `确定删除${
          docTime ? docTime.slice(0, 11) + "上传的" : ""
        }${docName}吗？`,
        loading: true,
        onOk: () => {
          try {
            this.$http
              .delByParams(
                `orgDocument/${orgId || this.orgId}/${docId}?id=${id}`
              )
              .then(res => {
                this.$Modal.remove();
                if (res.code === 20000) {
                  this.$Message.success("删除成功！");
                  this.hasDataChanged = true;
                  this.getHistoryVersionData();
                } else {
                  this.$Message.error(`删除失败:${res.msg}`);
                }
              });
          } catch (e) {
            this.$Modal.remove();
            console.error(e);
            this.$Message.error("删除失败！");
          }
        }
      });
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getHistoryVersionData();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getHistoryVersionData();
    },

    // 查看当前文件
    viewFile(docId, versionId) {
      // this.$http.get(`orgDocument/viewFile/${docId}`).then(res=>{
      //   console.log(res);
      // })

      window.open(`api/orgDocument/viewFile/${docId}?id=${versionId - 0}`);
    }
  }
};
</script>

<style lang="less" scoped>
.page-load {
  text-align: right;
  margin: 10px;
}
</style>


