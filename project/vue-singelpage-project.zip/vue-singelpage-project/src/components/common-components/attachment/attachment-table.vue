<template>
    <div>
     <Button class="operator-button" type="primary" @click="addAttachment">添加</Button>
     
     <div class="table-area">
         <Table
           :data="tableData"
           :columns="columns"
           v-loading="tableLoading"
           element-loading-text="拼命加载中"
           border
          />
     </div>

     <div class="page-load">
         <Page
           :total="total"
           :current="currentPage"
           :page-size="pageSize"
           @on-change="onPageChange"
           @on-page-size-change="onPageSizeChange"
           placement="top"
           show-elevator
           show-sizer
           show-total
         />
     </div>
     
     <add-attach-modal ref="addAttachMomal" :orgId="orgId" @refreshTable="refreshTable"></add-attach-modal>
     
     <history-version-modal ref="historyVersionModal"  @refreshTable="refreshTable"></history-version-modal>

    </div>
</template>

<script>
import AddAttachModal from "./add-attach-modal";
import HistoryVersionModal from "./history-version-modal";

export default {
  props: {
    orgId: {
      type: [Number, String],
      default: ""
    }
  },

  components: {
    AddAttachModal,
    HistoryVersionModal
  },

  data() {
    return {
      tableData: [],
      tableLoading: false,
      total: 0,
      currentPage: 1,
      pageSize: 10
    };
  },

  computed: {
    columns() {
      return [
        {
          title: "文件名称",
          key: "docName",
          render: (h, { row }) => {
            return h(
              "a",
              {
                style: {
                  display: "inline-block",
                  width: "100%",
                  height: "100%",
                  maxWidth: "200px",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  textOverflow: "ellipsis"
                },
                attrs: {
                  title: row.docName
                },
                on: {
                  click: () => {
                    this.viewFile(row.docId);
                  }
                }
              },
              row.docName || "--"
            );
          }
        },
        {
          title: "文件类型",
          key: "docType",
          render: (h, { row }) => {
            let fileTypeMapping = [
              {
                label: "尽调资料",
                value: 7
              },
              {
                label: "路演资料",
                value: 4
              },
              {
                label: "数据资料",
                value: 8
              },
              {
                label: "合同资料",
                value: 1
              },
              {
                label: "研究报告",
                value: 5
              },
              {
                label: "公司介绍",
                value: 3
              },
              {
                label: "基金经理介绍",
                value: 2
              },
              {
                label: "其他",
                value: 6
              }
            ];
            let text = fileTypeMapping.filter(
              item => item.value == row.docType
            )[0]
              ? fileTypeMapping.filter(item => item.value == row.docType)[0][
                  "label"
                ]
              : "--";
            return h("span", text);
          }
        },
        {
          title: "上传时间",
          key: "docTime",
          render: (h, { row }) => {
            if (row.docTime) {
              return h("span", row.docTime.slice(0, 11));
            } else {
              return h("span", "--");
            }
          }
        },
        {
          title: "上传人",
          key: "creater"
        },
        {
          title: "文件来源",
          key: "docSource",
          render: (h, { row }) => {
            let mapping = [
              {
                label: "联系人提供",
                value: 1
              },
              {
                label: "公开资料",
                value: 2
              },
              {
                label: "其他",
                value: 3
              }
            ];

            let text = mapping.filter(item => item.value == row.docSource)[0]
              ? mapping.filter(item => item.value == row.docSource)[0]["label"]
              : "--";
            return h("span", text);
          }
        },
        {
          title: "文档提供人",
          key: "docUserName"
        },
        {
          title: "机构名称",
          key: "orgName",
          render: (h, { row }) => {
            return h(
              "span",
              {
                style: {
                  display: "inline-block",
                  width: "100%",
                  height: "100%",
                  maxWidth: "200px",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  textOverflow: "ellipsis"
                },
                attrs: {
                  title: row.orgName
                }
              },
              row.orgName || "--"
            );
          }
        },
        {
          title: "文件可见范围",
          key: "docOpenScope",
          render: (h, { row }) => {
            let mapping = [
              {
                label: "公司内部",
                value: 1
              },
              {
                label: "完全公开",
                value: 2
              }
            ];

            let text = mapping.filter(item => item.value == row.docOpenScope)[0]
              ? mapping.filter(item => item.value == row.docOpenScope)[0][
                  "label"
                ]
              : "--";

            return h("span", text);
          }
        },
        {
          title: "操作",
          render: (h, { row }) => {
            return h("div", [
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.deleteFile(
                        row.docId,
                        row.docTime,
                        row.docName,
                        row.orgId
                      );
                    }
                  }
                },
                "删除"
              ),
              h(
                "div",
                {
                  attrs: {
                    class: "deleteBtn"
                  },
                  on: {
                    click: () => {
                      this.viewHistoryVersion(row.docId, row.orgId);
                    }
                  }
                },
                "历史"
              )
            ]);
          }
        }
      ];
    }
  },

  created() {
    if (this.orgId) {
      this.getAttachMent();
    }
  },

  mounted() {},

  methods: {
    refreshTable() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.getAttachMent();
    },

    //   获取列表
    getAttachMent() {
      let params = {
        pageSize: this.pageSize,
        pageNo: this.currentPage
      };
      this.tableLoading = true;
      try {
        this.$http.get(`orgDocument/${this.orgId}`, params).then(res => {
          this.tableLoading = false;
          if (res.code === 20000) {
            this.tableData = res.data.records;
            this.total = res.data.total;
          } else {
            this.$Message.warning("获取附件列表失败");
          }
        });
      } catch (e) {
        this.tableLoading = false;
        this.$Message.error("获取附件失败！");
      }
    },

    onPageChange(page) {
      this.currentPage = page;
      this.getAttachMent();
    },

    onPageSizeChange(pageSize) {
      this.pageSize = pageSize;
      this.getAttachMent();
    },

    // 新增附件
    addAttachment() {
      this.$refs.addAttachMomal.show();
    },

    // 删除附件
    deleteFile(docId, docTime, docName, orgId) {
      this.$Modal.confirm({
        title: "删除文件",
        content: `确定删除${
          docTime ? docTime.slice(0, 11) + "上传的" : ""
        }${docName}吗？`,
        loading: true,
        onOk: () => {
          try {
            this.$http
              .del(`orgDocument/${orgId || this.orgId}`, docId)
              .then(res => {
                this.$Modal.remove();
                if (res.code === 20000) {
                  this.$Message.success("删除成功！");
                  this.getAttachMent();
                } else {
                  this.$Message.error(`删除失败:${res.msg}`);
                }
              });
          } catch (e) {
            this.$Modal.remove();
            console.error(e);
            this.$Message.error("删除失败！");
          }
        }
      });
    },

    //    查看历史版本
    viewHistoryVersion(docId, orgId) {
      this.$refs.historyVersionModal.show(docId, orgId);
    },

    // 查看当前文件
    viewFile(docId) {
      // this.$http.get(`orgDocument/viewFile/${docId}`).then(res=>{
      //   console.log(res);
      // })

      window.open(`api/orgDocument/viewFile/${docId}`);
    }
  }
};
</script>

<style lang="less" scoped>
.table-area {
  margin-top: 10px;
}

.page-load {
  text-align: right;
  margin: 10px;
}
</style>


