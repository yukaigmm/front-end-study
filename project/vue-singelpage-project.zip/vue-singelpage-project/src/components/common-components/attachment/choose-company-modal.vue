<template>
   <Modal
     title="选择机构"
     width="350"
     v-model="modal"
     class="choose-mutiple-targets"
   >   
      <div slot="footer">
          <Button type="default" @click="onCancel">取消</Button>
          <Button type="primary" @click="onOk">确定</Button>
      </div>

      <tree-radio
         ref="tree"
         :treeData="treeData"
         :justFilter="true"
         :labelKey="'title'"
         :nodeKey="'id'"
         :loading="treeLoading"
         :treeProps="treeProps"
         :defaultExpandKeys="defaultExpandKeys"
         @submit="getCurrentOrgIdAndOrgNameStr"
       />
   </Modal>    
</template>


<script>
import treeRadio from "@/components/tree-radio";
export default {
  components: {
    treeRadio
  },

  data() {
    return {
      orgData: {},
      modal: false,
      currentCompanyId: "",
      treeLoading: false,
      treeData: [],
      currentCompanyParentId: "",
      treeProps: {
        label: (data, node) => data.title
      }
    };
  },

  computed: {
    defaultExpandKeys() {
      return this.treeData.length
        ? [this.treeData[0].id, this.currentCompanyId]
        : [""];
    }
  },

  methods: {
    show(orgId) {
      this.currentCompanyId = orgId;
      this.loading = true;
      this.modal = true;
      this.$http
        .get(`visit/getTreeByOrgId/${orgId}`, { orgParent: 1, showUser: 0 })
        .then(res => {
          if (res.code === 20000) {
            this.treeData = res.data;
            this.currentCompanyParentId = res.data[0].id;
            setTimeout(() => {
              this.$refs.tree.setChecked(orgId);
            }, 100);
          } else {
            this.$Message.error(res.msg);
          }
          this.loading = false;
        });
    },

    onCancel() {
      this.modal = false;
      this.currentCompanyId = "";
      this.treeData = [];
      this.currentCompanyParentId = "";
    },

    onOk() {
      if (this.orgData.checkedId && this.orgData.checkedLabelArr) {
        this.$emit("getOrgData", this.orgData);
      }
      this.onCancel();
    },

    getCurrentOrgIdAndOrgNameStr(data) {
      this.orgData = data;
      this.$refs.tree.setChecked(data.checkedId);
      this.currentCompanyId = data.checkedId;
    }
  }
};
</script>

<style lang="less" scoped>
</style>

