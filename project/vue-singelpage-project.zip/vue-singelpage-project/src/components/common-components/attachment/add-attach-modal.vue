<template>
    <Modal
       v-model="modal"
       title="添加附件"
       :mask-closable="false"
       width="400"
    >
        <div slot="close" @click="onCancel">
            <Icon type="ios-close-empty"></Icon>
        </div>

        <div slot="footer">
            <Button type="default" @click="onCancel">取消</Button>
            <Button type="primary" @click="onOk">确定</Button>
        </div>


        <Form ref="form" :rules="validateRules" :model="formData" :label-width="90">
            <Row>
                <Col span="24">
                   <FormItem label="机构名称" prop="orgName">
                       <div>
                           <Input
                             v-model="orgNameStr"
                             placeholder="点击选择机构"
                             @on-focus="showSelectOrgModal"
                            />
                       </div>
                   </FormItem>
                </Col>

                <Col span="24">
                   <FormItem label="文件类型" prop="docType">
                       <Select 
                         v-model="formData.docType"
                         transfer
                         placeholder="请选择文件类型"
                         >
                           <Option 
                              v-for="item in docTypeMapping" 
                              :key="item.value"
                              :value="item.value">
                                {{item.label}}
                              </Option>
                       </Select>
                   </FormItem>
                </Col>
                
                <Col span="24">
                   <FormItem label="文件来源" prop="docSource" >
                       <Select 
                         v-model="formData.docSource"
                         transfer
                         placeholder="请选择文件来源"
                         >
                           <Option 
                              v-for="item in docSourceMapping" 
                              :key="item.value"
                              :value="item.value">
                                {{item.label}}
                              </Option>
                       </Select>
                   </FormItem>
                </Col>

                <Col span="24">
                  <FormItem label="文件提供人" prop="docUser" :class="{'ivu-form-item-required':this.formData.docSource ==1}">
                       <Select 
                         v-model="formData.docUser"
                         transfer
                         placeholder="请选择文件提供人"
                         >
                           <Option 
                              v-for="item in docUserMapping" 
                              :key="item.id"
                              :value="item.id">
                                {{item.name}}
                              </Option>
                       </Select>
                  </FormItem>
                </Col>

                <Col span="24">
                  <FormItem label="文件可见范围" prop="docOpenScope">
                    <RadioGroup v-model="formData.docOpenScope">
                      <Radio label="1">
                        公司内部
                      </Radio>
                      <Radio label="2">
                        完全公开
                      </Radio>
                    </RadioGroup>
                  </FormItem>
                
                </Col>

                <Col span="24">
                   <FormItem label="上传文件" prop="docPath">
                     <div class="file-wrapper">
                        <span class="file-container" v-if="fileName" :title="fileName">
                            <span class="file-name-container">
                             {{fileName}}
                            </span>
                             <span class="clear-file-container" title="清除文件" @click="clearCurrentFile">×</span>
                         </span>
                         <Upload
                           ref="upload"
                           :show-upload-list="false"
                           :action="actionUrl"
                           :on-error='onUploadError'
                           :on-success='onUploadSuccess'
                           :before-upload='beforeUpload'
                           name="document"
                           :max-size="50*1024"
                           :on-exceeded-size="onExceededSize"
                         > 
                           
                           <Button size="small" :disabled='ifUploadDisabled' type="primary" icon="upload" :title="this.formData.docPath?'更换文件':'上传文件'"></Button>
                         </Upload>
                     </div>
                         
                   </FormItem>
                </Col>
            </Row>
        </Form>
        <choose-company-modal ref="chooseCompanyModal" @getOrgData="getOrgData"></choose-company-modal>
    </Modal> 
</template>

<script>
import chooseCompanyModal from "./choose-company-modal";

export default {
  components: {
    chooseCompanyModal
  },

  props: {
    orgId: {
      type: [Number, String],
      default: ""
    }
  },

  data() {
    return {
      currentOrgId: "",
      orgNameStr: "",
      docUserMapping: [],
      fileName: "",
      modal: false,

      formData: {
        docName: "",
        docType: "",
        docSource: "",
        docUser: "",
        docOpenScope: "",
        docPath: ""
      }
    };
  },

  computed: {
    docTypeMapping() {
      return [
        {
          label: "尽调资料",
          value: 7
        },
        {
          label: "路演资料",
          value: 4
        },
        {
          label: "数据资料",
          value: 8
        },
        {
          label: "合同资料",
          value: 1
        },
        {
          label: "研究报告",
          value: 5
        },
        {
          label: "公司介绍",
          value: 3
        },
        {
          label: "基金经理介绍",
          value: 2
        },
        {
          label: "其他",
          value: 6
        }
      ];
    },

    docSourceMapping() {
      return [
        {
          label: "联系人提供",
          value: 1
        },
        {
          label: "公开资料",
          value: 2
        },
        {
          label: "其他",
          value: 3
        }
      ];
    },

    actionUrl() {
      return `api/orgDocument/uploadFile/${this.formData.docType}`;
    },

    ifUploadDisabled() {
      return this.formData.docType ? false : true;
    },

    validateRules() {
      const validateDocUser = (rules, value, cb) => {
        let errors = [];
        if (this.formData.docSource == 1) {
          if (!value) {
            errors.push("文档提供人不能为空");
          }
        }

        cb(errors);
      };

      return {
        docType: [
          {
            required: true,
            message: "文档类型不能为空"
          }
        ],
        docSource: [{ required: true, message: "文档来源不能为空" }],
        docUser: [
          {
            validator: validateDocUser
          }
        ],
        docPath: [{ required: true, message: "请上传文件" }]
      };
    }
  },

  created() {
    // this.getUserMapping();
  },

  methods: {
    onExceededSize(file, fileList) {
      this.$Message.error("文件大小不能超过50M！");
      return;
    },

    showSelectOrgModal() {
      this.$refs.chooseCompanyModal.show(this.currentOrgId || this.orgId);
    },

    getOrgData(data) {
      this.orgNameStr = data.checkedLabelArr.join(">");
      this.currentOrgId = data.checkedId;
    },

    getUserMapping() {
      try {
        this.$http
          .get(`orgDocument/orgOtherInfo/${this.orgId}`, {
            showContacts: 1,
            showBread: 1
          })
          .then(res => {
            if (res.code === 20000) {
              this.docUserMapping = res.data.contacts.map(item => {
                return {
                  name: item.name,
                  id: item.id
                };
              });
              this.orgNameStr = res.data.bread
                .map(item => item.title)
                .join(">");
            } else {
              this.$Message.error("获取文档提供人失败！");
            }
          });
      } catch (error) {
        this.$Message.error("获取文档提供人失败！");
      }
    },

    show() {
      this.modal = true;
      this.getUserMapping();
    },

    onOk() {
      this.addNewAttachment();
    },

    addNewAttachment() {
      let params = {
        ...this.formData
      };

      this.$refs.form.validate(valid => {
        if (valid) {
          this.$http
            .post(`orgDocument/${this.currentOrgId || this.orgId}`, params)
            .then(res => {
              if (res.code === 20000) {
                this.$Message.success("添加成功！");
                this.$emit("refreshTable");
                this.onCancel();
              } else {
                this.$Message.error(`添加失败：${res.msg}`);
              }
            });
        } else {
          this.$Message.warning("请按红色字段提示填写内容！");
        }
      });
    },

    onCancel() {
      this.modal = false;
      this.currentOrgId = "";
      this.orgNameStr = "";
      this.docUserMapping = [];
      this.$refs.form.resetFields();
      this.fileName = "";
    },

    beforeUpload(file) {
      if (this.ifUploadDisabled) {
        this.$Message.info("请先选择文件类型");
        return false;
      }

      if (file.size < 50 * 1024 * 1024) {
        this.$Message.loading({
          content: "上传中，请稍候...",
          duration: 0
        });

        this.$refs.upload.clearFiles();
      }
    },

    onUploadError(error, file, fileList) {
      this.$Message.destroy();
      this.$Message.error("上传失败！");
    },

    onUploadSuccess(res, file, fileList) {
      this.$Message.destroy();
      if (res.code === 20000) {
        this.$Message.success("上传成功！");
        this.fileName = res.data.fileName;
        this.$set(this.formData, "docPath", `${res.data.filePath}`);
        this.$set(this.formData, "docName", `${res.data.fileName}`);
        this.$refs.form.validateField("docPath");
      } else {
        this.$Message.error("上传失败！");
      }
    },

    clearCurrentFile() {
      this.fileName = "";
      this.$set(this.formData, "docPath", "");
      this.$refs.upload.clearFiles();
    }
  }
};
</script>

<style lang="less" scoped>
.file-wrapper {
  display: flex;
  justify-content: flex-start;
  align-items: center;
}
.file-container {
  cursor: pointer;
  position: relative;
  margin-right: 20px;

  .file-name-container {
    display: inline-block;
    max-width: 230px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }

  .clear-file-container {
    position: absolute;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    line-height: 16px;
    background: #ccc;
    text-align: center;
    top: 0;
    right: -16px;
    display: none;
  }
  &:hover {
    .clear-file-container {
      display: block;
    }
  }
}
</style>


