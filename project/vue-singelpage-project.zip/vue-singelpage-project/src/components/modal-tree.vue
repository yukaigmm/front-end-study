<template>
    <Modal
        v-model="modal"
        class="common-modal-tree"
        :title="title"
        @on-ok="ok"
        @on-cancel="cancel">
        <div class="tree-container" v-loading="loading" element-loading-text="拼命加载中">
			<div style="margin-left: 10px;">
				<span>关键字：</span>
				<Input style="width:200px;margin-right:8px;" placeholder="请输入关键字" @input="filterTree" v-model="filterText" v-if="filter"/>
			</div>
            <el-tree
                :class="{'common-tree-in-modal':true, 'radio': radio}"
                :data="treeData"
                accordion
                show-checkbox
                :default-expand-all="false"
                :props="treeProps"
                :node-key="nodeKey"
				:default-expanded-keys="defaultExpandKeys"
                :filter-node-method="filterNode"
                @check="handleCheck"
                @check-change="handleCheckChange"
                ref="tree">
            </el-tree>
        </div>
    </Modal>
</template>

<script>
export default {
	props: {
		title: {
			type: String,
		},
		treeData: {
			type: Array,
		},
		filter: {
			type: Boolean,
			default: false,
		},
		treeProps: {
			type: Object,
			default: {},
        },
        checkedKeys:{
            type: Array,
            default: []
        },
		radio: {
			type: Boolean,
		},
		nodeKey: {
			type: String,
        },
        labelKey:{
            type: String,
        },
		loading: {
			type: Boolean,
			default: false,
		},
		defaultExpandKeys:{
			type: Array
		}
	},
	data() {
		return {
			filterText: '',
			modal: false,
			checkedId: 0,
			checkedLabelArr: [],
		};
	},
	computed:{
	},
	watch: {
		treeData: {
			handler(val) {
                setTimeout(() => {
                    this.checkedKeys.forEach((checkedKey) => {
						// 先清空所有的之前选中的节点，再根据选中的数组设置选中
						this.$refs.tree.setCheckedKeys([]);
						// this.$refs.tree.setCheckedNodes([]);
                        this.$refs.tree.setChecked(checkedKey,true,false);
                    })
                    if(this.radio){
                        this.checkedId = this.checkedKeys[0];
                        let checkedNode = this.$refs.tree.getNode(this.checkedId);
                        let parent = checkedNode.parent;
                        this.checkedLabelArr = [checkedNode.data[this.labelKey || "label"]];
                        this.getParentLabel(parent);
                    }
                }, 100);
            },
            deep: true
		}
	},
	methods: {
		filterNode(value, data) {
			if (!value) return true;
			return data.title.indexOf(value) !== -1;
		},
		ok() {
            let emitData;
			if (this.radio) {
				emitData = {
					checkedId: this.checkedId,
					checkedLabelArr: this.checkedLabelArr,
				};
				this.$emit('submit',emitData);
            }
            this.cancel();
		},
		cancel() {
			this.$refs.tree.setCheckedKeys([]);
			setTimeout(() => {
				this.$emit("cleanData");
				this.filterText = '';
				this.modal = false;
			}, 100);
		},
		cleanCheckedKey(){
		},
		show() {
			this.modal = true;
		},
		handleCheck(data, statusObj) {
			if (this.radio) {
				this.handleRadioCheck(data, statusObj);
			} else {
				this.handleMultiCheck(data, statusObj);
			}
		},
		filterTree(val){
			this.$refs.tree.filter(this.filterText);
		},
		handleCheckChange(data, status, childrenStatus) {},
		// ----------------------------------多选树的处理---------------------------------------------------
		handleMultiCheck() {},
		// ----------------------------------单选树的处理---------------------------------------------------
		handleRadioCheck(data, statusObj) {
			if (statusObj.checkedKeys.includes(data.id)) {
                // this.$refs.tree.setChecked(data.id);
                this.$refs.tree.setCheckedKeys([data.id]);
                this.setRadioCheckedIdAndLabel(data);
				let currentNode = this.$refs.tree.getNode(data.id);
				if (currentNode) {
					this.setChildNotChecked(currentNode.childNodes);
					if (currentNode.parent) {
						this.setParentNotChecked(currentNode.parent);
					}
				}
			}
        },
        // 设置需要输出的 选中Id 和 选中的标签数组
        setRadioCheckedIdAndLabel(data){
            this.checkedId = data.id;
            let label = this.labelKey || "label";
            this.checkedLabelArr = [data[label]];
        },
		// 勾选时去除子节点的勾选
		setChildNotChecked(childNodes) {
			childNodes.forEach((child, index) => {
				child.checked = false;
				if (child.childNodes) {
					this.setChildNotChecked(child.childNodes);
				}
			});
		},
		// 如果只有自己一个子节点，在自己勾选时父节点也会被选中，单选需要去掉父节点的勾选
		setParentNotChecked(parent) {
            parent.checked = false;
            this.getParentLabel(parent);
			if (parent.parent) {
				this.setParentNotChecked(parent.parent);
			};
        },
        getParentLabel(parent){
            let label = this.labelKey || "label";
            if(parent.data[label]){
                this.checkedLabelArr.unshift(parent.data[label]);
            };
        }
	},
};
</script>

<style lang="less">
.common-modal-tree {
	.ivu-modal-mask {
		z-index: 1001;
	}
	.ivu-modal-wrap {
		z-index: 1002;
		.ivu-modal-body {
			overflow-y: auto;
			min-height: 300px;
			.tree-container {
				// height: 100%;
				min-height: 300px;
			}
		}
	}
}
</style>
