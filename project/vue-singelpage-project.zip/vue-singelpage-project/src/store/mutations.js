import _ from 'lodash';
import state from './state';

export const setLogId = (state, id) => {
  state.logId = id
}

export const setUser = (state, user) => {
  state.user = user
}
export const setTrueName = (state, trueName) => {
  state.user.trueName = trueName
}

export const setLoadingComponent = (state, loading) => {
  state.loadingComponent = loading
}

export const addEmums = (state, payload) => {
  state.enums = payload;
}
export const setMessageCount = (state, messageCount) => {
  state.messageCount = messageCount;
}





export const setTabs = (state, tab) => {
  let tabs = JSON.parse(JSON.stringify(state.tabs || []));

  let index = _.findIndex(tabs, function (item) {
    return (item.name === tab.name)
  })

  if (index != -1) {
    tab.isShow = true;
  } else {
    tabs.push(tab)
  }

  // 设置当前激活的tab名称
  state.activeTab = tab.name;

  state.tabs = JSON.parse(JSON.stringify(tabs));
}

export const setTabsAll = (state, tabs) => {
  state.tabs = tabs;
}

export const closeTab = (state, tab) => {
  let tabs = JSON.parse(JSON.stringify(state.tabs));



  let index = _.findIndex(tabs, function (item) {
    if (item.pid) {
      return (item.pid == tab.pid && item.name == tab.name);
    } else {
      return item.name == tab.name;
    }
  })

  let activeTab = "";

  tabs.splice(index, 1);

  if (tabs[index]) {
    activeTab = tabs[index]["name"]
  } else if (tabs[index - 1]) {
    activeTab = tabs[index - 1]["name"]
  } else {
    activeTab = tabs[0]["name"]
  }

  if (state.activeTab == tab.name) {
    state.activeTab = activeTab;
  }

  state.tabs = JSON.parse(JSON.stringify(tabs));
}


export const setActiveTab = (state, activeTab) => {
  state.activeTab = activeTab;
}

export const setCustomerType = (state, customerType) => {
  state.customerType = customerType;
}

export const setIfBinded = (state, ifBinded) => {
  state.ifBinded = ifBinded;
}

export const setProjectVisitedStatus = (state, status) => {
  state.projectVisitedStatus = status;
}

export const setAccountStatus = (state, status) => {
  state.accountStatus = status;
}

export const setVisitStatus = (state, status) => {
  state.visitStatus = status;
}

export const setVisitProjectStatus = (state, status) => {
  state.visitProjectStatus = status;
}


export const setIfAssistantOpen = (state, ifAssistantOpen) => {
  state.ifAssistantOpen = ifAssistantOpen;
}
