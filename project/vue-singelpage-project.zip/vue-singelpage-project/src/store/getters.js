export const getLogId = state => {
  return state.logId
}

export const getUser = state => {
  return state.user
}

export const getUserName = state => {
  return state.user.userName
}
export const getTrueName = state => {
  return state.user.trueName
}
export const getUserId = state => {
  return state.user.id
}

export const getUrl = state => {
  return state.route.path
}

export const getLoadingComponent = state => {
  return state.loadingComponent
}

export const getEnums = state => {
  return state.enums
}
export const getMessageCount = state => {
  return state.messageCount
}
export const getTabs = state => {
  return state.tabs
}
export const getActiveTab = state => {
  return state.activeTab;
}

export const getCustomerType = state => {
  return state.customerType;
}

export const getIfBinded = state => {
  return state.ifBinded;
}

export const getProjectVisitedStatus = state => {
  return state.projectVisitedStatus;
}


export const getAccountStatus = state => {
  return state.accountStatus;
}

export const getVisitStatus = state => {
  return state.visitStatus;
}


export const getVisitProjectStatus = state => {
  return state.visitProjectStatus;
}

export const getIfAssistantOpen = state => {
  return state.ifAssistantOpen
}
