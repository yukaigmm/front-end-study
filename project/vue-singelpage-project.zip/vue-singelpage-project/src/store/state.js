export default {
  logId: '',
  user: {},
  loadingComponent: false,
  enums: {

  },
  messageCount: 0,
  tabs: [{
    // 控制tab的开、关状态
    isShow: true,
    name: "首页0",
    activeName: "首页",
    component: "index",
    closable: false
  }, ],
  activeTab: "首页0",
  customerType: [],
  ifBinded: true,
  projectVisitedStatus: {
    saleId: "",
    ifVisited: false,
  },
  accountStatus: {
    saleId: "",
  },
  visitStatus: {
    saleId: "",
    startDate: "",
    endDate: "",
  },
  visitProjectStatus: {
    saleId: "",
    startDate: "",
    endDate: "",
  },
  ifAssistantOpen:true,
}
