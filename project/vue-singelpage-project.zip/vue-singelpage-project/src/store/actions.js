export const setUser = ( {commit}, user ) => {
  // state.user = user
  commit('setUser', user)
}
export const setTrueName = ( {commit}, trueName ) => {
  // state.user = user
  commit('setTrueName', trueName)
}
export const setLoadingComponent = ( {commit}, loading ) => {
  commit('setLoadingComponent', loading)
}

export const addEmums = ( {commit}, payload ) => {
  commit('addEmums', payload)
}
export const setMessageCount = ( {commit},{messageCount}) => {
  commit('setMessageCount', messageCount)
}
//
// increment ({ commit }) {
//   commit('increment')
// }
export const setTabs = ( {commit} ,tabs) => {
  commit('setTabs' , tabs);
}
export const setTabsAll = ({commit},tabs) =>{
  commit('setTabsAll', tabs);
}
export const closeTab = ({commit},tab) =>{
  commit('closeTab', tab);
}
export const setActiveTab = ({commit},{activeTab})=>{
  commit('setActiveTab',activeTab)
}

export const setCustomerType = ({commit},customerType) =>{
  commit('setCustomerType',customerType)
}

export const setIfBinded = ({commit},{ifBinded}) => {
  commit("setIfBinded",ifBinded)
}

export const setProjectVisitedStatus = ({commit},status) =>{
  commit("setProjectVisitedStatus",status)
}

export const setAccountStatus = ({commit},status) =>{
  commit("setAccountStatus",status)
}

export const setVisitStatus = ({commit},status) =>{
  commit("setVisitStatus",status)
}

export const setVisitProjectStatus = ({commit},status) =>{
  commit("setVisitProjectStatus",status)
}


export const setIfAssistantOpen = ( {commit},{ifAssistantOpen}) => {
  commit('setIfAssistantOpen', ifAssistantOpen)
}