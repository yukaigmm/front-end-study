import {
  mapGetters
} from "vuex"


export default {
  computed: {
    ...mapGetters({
    
      userId: "getUserId",
      userInfo:"getUser"
    }),
    ifAdmin() {

      return this.userInfo.auth.functional.includes("resetFofPsw");

    },

    canAssign(){
      return this.userInfo.auth.functional.includes("assignFofAccount");

    }
  },

  methods: {
    //  重置密码
    resetPassword(accountInfo = {}) {
      this.$refs.resetPasswordModal.show(accountInfo);
    },
  }
}
