export default {
  methods: {
    // 根据浏览器的不同确定计算表格高度时需要减去的常量
    getMinusNumberOfFixedTable() {
      let userAgent = navigator.userAgent;
      if (userAgent.indexOf("Chrome") > -1) {
        return 10;
      } else if (userAgent.indexOf("Trident") > -1 || userAgent.indexOf("compatible") > -1) {
        return 20;
      } else if(this.isIE()){
        return 16;
      }else{
          return 17;
      }
    },

    isIE() { //ie?
      if (!!window.ActiveXObject || "ActiveXObject" in window)
        return true;
      else
        return false;
    }
  }
}
