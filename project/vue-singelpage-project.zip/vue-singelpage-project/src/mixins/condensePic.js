export default {
  data() {
    return {

    }
  },

  methods: {
    /**
     * 
     * @param {*formData} file  上传的文件 
     * @param {*string} ref 关联的表单的ref
     * @param {*string} data 关联的表单数据
     * @param {*string} key 关联图片字段
     */
    uglifyPic(file, ref, data, key) {
      const maxSize = 300 * 1024;
      let format = file.type;
      if (format.indexOf("image/") == -1) {
        this.$Message.warning({
          content: "请上传正确的文件！",
          duration: 3
        });
        this.imgLoading = false;
        return;
      }
      //   大小在300K以下直接上传
      //   if (file.size > maxSize) {
      //   不支持直接上传
      if (!window.FileReader) {
        return;
      }


      try {
        let reader = new FileReader();
        reader.readAsDataURL(file);
        let _this = this;
        reader.onload = function () {
          let result = this.result;
          let img = new Image();
          img.src = result;


          if (img.complete) {
            _this.getImgData(img, format, ref, data, key);
          } else {
            img.onload = _this.getImgData.bind(_this, img, format, ref, data, key);
            img.onerror = () => {
              _this.imgLoading = false;
              _this.$Message.warning({
                content: "文件内容错误！",
                duration: 3
              })
            }
          }
        }
      } catch (e) {
        console.error(e);
      }


    },

    // canvas重绘、压缩图片
    condense(img) {
      let canvas = document.createElement("canvas");
      let tCanvas = document.createElement("canvas");
      let ctx = canvas.getContext("2d");
      let tctx = tCanvas.getContext("2d");
      let width = img.width;
      let height = img.height;
      let ratio;
      //如果图片大于四百万像素，计算压缩比并将大小压至400万以下
      if ((ratio = width * height / 4000000) > 1) {
        ratio = Math.sqrt(ratio);
        width /= ratio;
        height /= ratio;
      } else {
        ratio = 1;
      }

      canvas.width = width;
      canvas.height = height;

      // 底色   
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // 如果图片像素大于100万则使用瓦片绘制
      let count;
      if ((count = width * height / 1000000) > 1) {
        count = ~~(Math.sqrt(count) + 1);
        let nw = ~~(width / count);
        let nh = ~~(height / count);
        tCanvas.width = nw;
        tCanvas.height = nh;
        for (let i = 0; i < count; i++) {
          for (let j = 0; j < count; j++) {
            tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);
            ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
          }
        }
      } else {
        ctx.drawImage(img, 0, 0, width, height);
      }

      let data = canvas.toDataURL('image/jpeg', 0.3);
      tCanvas.width = tCanvas.height = canvas.height = canvas.width = 0;
      return data;
    },

    // 获取压缩后的图片
    getImgData(img, format, ref, data, key) {
      let pic = this.condense(img);
      let text = window.atob(pic.split(",")[1]);
      let buffer = new Uint8Array(text.length);

      for (let i = 0, len = text.length; i < len; i++) {
        buffer[i] = text.charCodeAt(i);
      }
      let blob = this.getBlob([buffer], format);
      this.getImgFormData(blob, format, ref, data, key);
    },

    getBlob(buffer, format) {
      try {
        return new Blob(buffer, {
          type: format
        });
      } catch (e) {
        let bb = new(window.BlobBuilder || window.WebkitBlobBuilder || window.MSBlobBuilder);
        bb.append(buffer)

        return bb.getBlob(format);
      }
    },

    /**
     * 
     * @param {*binary} blob 二进制图片 
     * @param {*string} format 图片格式
     * @param {*string} ref 关联的表单
     * @param {*string} data 关联的表单数据
     * @param {*string} key 名片字段
     */
    getImgFormData(blob, format, ref, data, key) {
      let type = format.split("/")[1];
      let formData = new FormData();
      formData.append("fileType", "visitingCard")
      formData.append("file", blob, `${Date.now()}.${type}`);
      try {
        this.$http.post('/common/uploadFile', formData).then(res => {
          this.imgLoading = false;
          if (res.code === 20000) {
            this.$Message.success("上传成功！");
            this[data][key] = res.data.filePath;
            this.$refs[ref].validateField(key);
            this.getImgUrl(res.data.filePath);
          } else {
            this.$Message.error(`上传失败：${res.msg}`);
          }
        })
      } catch (e) {
        console.error(e);
        this.$Message.error("上传失败！")
      }

    }
  }
}
