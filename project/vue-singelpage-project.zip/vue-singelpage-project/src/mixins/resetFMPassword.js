import {
    mapGetters
  } from "vuex"
  
  
  export default {
    computed: {
      ...mapGetters({
        
        userId: "getUserId",
        userInfo:"getUser"
      }),
      ifAdmin() {
        return this.userInfo.auth.functional.includes("resetFmPsw");
      },
    },
  
    methods: {
      //  重置密码
      resetPassword(accountInfo = {}) {
        this.$refs.resetPasswordModal.show(accountInfo);
      },
    }
  }