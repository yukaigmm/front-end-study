export default {
  methods: {
    checkType(data) {
      let class2Type = {};
      let toString = class2Type.toString;
      let types = "Boolean Number String Function Array Date RegExp Object Error".split(" ");
      types.forEach(item => {
        class2Type[`[object ${item}]`] = item.toLowerCase();
      });
      return data == null ? String(data) : class2Type[toString.call(data)] || 'object'
    },

    clear(data) {
      let keys = Object.keys(this[data]);

      keys.forEach(key => {
        if (this.checkType(this[data][key]) === "object") {
          this.$set(this[data], key, {});
        } else if (this.checkType(this[data][key]) === "array") {
          this.$set(this[data], key, []);
        } else {
          this.$set(this[data], key, "");
        }
      });
    }
  }
}
