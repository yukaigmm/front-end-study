import getMinusNumber from "@/mixins/getMinusNumber.js";
import $ from "jquery";

export default {

  mixins: [getMinusNumber],
  methods: {
    //设置表格的最大高度
    setMaxHeightOfFixedTable(
      wholeContainerClass = ".content-body.ivu-col",
      cutElementClassArray = [],
      targetTableClass = ".table-area",
      canstant = 100,
      minus = false
    ) {
      let wholeContainer = $(wholeContainerClass);
      let targetTable = $(this.$el).find(targetTableClass);
      let cutElementHeightTotle = 0;
      _.forEach(cutElementClassArray, classRule => {
        let height = $(this.$el)
          .find(classRule)
          .outerHeight(true);
        cutElementHeightTotle += height;
      });
      let maxHeight = wholeContainer.height() - cutElementHeightTotle - canstant;
      let minusNumber =minus? this.getMinusNumberOfFixedTable() : 0;
      targetTable.find(".ivu-table-body").css("maxHeight", maxHeight + "px");
      targetTable
        .find(".ivu-table-fixed-body")
        .css("maxHeight", maxHeight - minusNumber + "px");
      targetTable
        .find(".ivu-table-fixed-body .ivu-table-tbody")
        .css("maxHeight", maxHeight -minusNumber+ "px");
    },
  },
}
