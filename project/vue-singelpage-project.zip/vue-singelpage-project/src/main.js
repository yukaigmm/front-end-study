// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import {
  sync
} from 'vuex-router-sync'
import 'iview/src/styles/index.less'
import '../static/lib/fullcalendar.min.css';
import 'element-ui/lib/theme-chalk/index.css'
import './index.less';
// import "../static/lib/chat/ppw-chat/dist/index.css";

import {
  fetchSelect,
} from '@/service/getData'
import './plugin'
// import {wxLogin} from  './plugin/login.js'
import './service/api.js';
import axios from 'axios';

// console.log(process.env.NODE_ENV)




sync(store, router)
Vue.config.productionTip = false

function importStoreAssitant() {
  let env = process.env.NODE_ENV;
  let cdnMapping = {
    "development": "https://www-test.simuwang.com/",
    "test": "https://www-test.simuwang.com/",
    "pre": "https://www-pre.simuwang.com/",
    "production": "https://www.simuwang.com/"
  }

  let md5Script = document.createElement("script");
  let webImScript = document.createElement("script");
  let json2Script = document.createElement("script");
  let chatScript = document.createElement("script");
  let cssLink = document.createElement("link");

  webImScript.src = `${cdnMapping[env]}/Public/ppw-chat/sdk/webim.js`;
  document.body.appendChild(webImScript);


  json2Script.src = `${cdnMapping[env]}/Public/ppw-chat/sdk/json2.js`;
  document.body.appendChild(json2Script);

  md5Script.src = `${cdnMapping[env]}/Public/ppw-chat/sdk/lib/md5/spark-md5.js`
  document.body.appendChild(md5Script);


  window["PPW_CHAT_COMP_PATH"] = `${cdnMapping[env]}/Public/ppw-chat/`;


  cssLink.href = `${cdnMapping[env]}/Public/ppw-chat/index.css?v=${Date.now()}`
  cssLink.setAttribute("rel", "stylesheet");
  document.head.appendChild(cssLink);

  chatScript.src = `${cdnMapping[env]}/Public/ppw-chat/index.js?v=${Date.now()}`;
  document.body.appendChild(chatScript);


}

function getBrowserVersion() {
  return new Promise((resolve, reject) => {
    //判断是否为ie10以下浏览器,若是则提示并关闭当前页面
    if (navigator.appName == "Microsoft Internet Explorer") {
      var appVersion = navigator.appVersion.split(";")[1].replace(/[ ]/g, "");
      if (appVersion == "MSIE6.0" || appVersion == "MSIE7.0" || appVersion == "MSIE8.0" || appVersion == "MSIE9.0") {
        alert('您的浏览器版本过低，可能无法正常使用该功能。请使用主流浏览器或IE10+进行访问，360浏览器请选择极速模式,谢谢');
        window.close();
        reject();
      }
    }
    resolve();
  })
}


let GetUserInfo = axios.get('api/common/getLoginStatus').then((resp) => {
  store.dispatch("setUser", resp.data.data);
  return Promise.resolve(resp.data.data);
})

const getAllSelect = () => {
  return new Promise(resolve => {
    fetchSelect('/common/getSelectAll').then((res) => {
      let emnumsData = JSON.stringify(res.data.data)
      localStorage.setItem("emnums", emnumsData);
      localStorage.setItem('max_update_time', res.data.max_update_time);
      store.dispatch('addEmums', res.data.data);
      resolve(emnumsData);
    });
  });
}





let data = localStorage.getItem("emnums");
let max_update_time = localStorage.getItem("max_update_time");


const initApp = (userInfo) => {
  new Vue({
    el: '#app',
    router,
    store,
    template: '<App/>',
    components: {
      App
    }
  });
  if (userInfo.id) {
    router.push('/index');

  } else {
    router.push('/login');
  }

  importStoreAssitant();

}

if (!data) {
  getBrowserVersion().then(() => {
    Promise.all([GetUserInfo, getAllSelect()]).then(([userInfo]) => {
      initApp(userInfo);
    });
  });
} else {

  getBrowserVersion().then(() => {
    GetUserInfo.then(userInfo => {
      let currentUpdateTime = userInfo.max_update_time;
      if (currentUpdateTime) {
        localStorage.setItem('hasChanged', false);
      }
      let hasChanged = localStorage.getItem("hasChanged");


      if (new Date(JSON.parse(max_update_time)).getTime() <= new Date(currentUpdateTime).getTime() && !hasChanged) {
        getAllSelect().then(emnumsData => {
          localStorage.setItem('hasChanged', true);
          initApp(userInfo)
        })
      } else {
        store.dispatch('addEmums', JSON.parse(data));
        initApp(userInfo)
      }
    })
  })
}
