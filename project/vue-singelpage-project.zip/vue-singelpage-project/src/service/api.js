import Vue from 'vue';
import axios from 'axios';
import router from '@/router';
import {
  error
} from './notify'

let cancelToken = axios.CancelToken;
let pendingRequest = [];
const removePendingRequest = req => {
  for (let index in pendingRequest) {
    if (pendingRequest[index].url === req.url && pendingRequest[index].method === req.method) {
      pendingRequest[index].cancel();
      pendingRequest.splice(index, 1);
      break;
    }
  }
}

const http = axios.create({
  baseURL: 'api/'
})

http.interceptors.request.use(config => {

    let ifCancel = false;
    let data = null;
    let params = null;

    //  post和put请求
    if (config.data) {
      data = JSON.parse(JSON.stringify(config.data));
      if (config.data.ifCancelRequest) {
        delete config.data.ifCancelRequest
      }

      if (data.ifCancelRequest) {
        ifCancel = true;
      }
    }

    // get请求
    if (config.params) {
      params = JSON.parse(JSON.stringify(config.params));
      if (config.params.ifCancelRequest) {
        delete config.params.ifCancelRequest
      }

      if (params.ifCancelRequest) {
        ifCancel = true;
      }

    }

    // delete请求
    if (config.ifCancelRequest) {
      ifCancel = config.ifCancelRequest
    }

    if (ifCancel) {
      removePendingRequest(config);
    }

    config.cancelToken = new cancelToken(c => {
      pendingRequest.push({
        url: config.url,
        method: config.method,
        cancel: c
      })
    })

    return config;
  },
  err => {
    return Promise.reject(err)
  })

http.interceptors.response.use(
  response => {
    let data = response.data;
    let status = response.status;
    if (status === 200) {
      if (data.code === 20000 || data.code === 21000) {
        return Promise.resolve(response.data);
      } else {
        if (data.code === 10099) {
          //cookie失效 未登录
          router.push('/login');
          return Promise.resolve(response.data); // 当fetch.js一概不用之后可以注释
        } else {
          let msg = data.msg;
          msg ? error(msg) : error('请求出错')
          return Promise.resolve(response.data)
        }
      }
    } else {
      return Promise.reject(response);
    }
  },
  err => {
    if (!axios.isCancel(err)) {
      error(err);
      return Promise.reject(err);
    } else {
      console.warn("请求已取消！");
      return Promise.reject("canceled")
    }

  }
);



const get = (url, params) => http.get(url, {
  params
});
const getSingle = (url, id) => http.get(url + '/' + id);
const post = (url, data) => http.post(url, data);
const put = (url, data) => http.put(url + '/' + data.id, data);
const putWithoutId = (url, data) => http.put(url, data);
const del = (url, id) => http.delete(url + '/' + id);
const delByParams = (url, params) => http.delete(url, params);

Vue.prototype.$http = {
  get,
  getSingle,
  post,
  put,
  putWithoutId,
  del,
  delByParams,
}

export default http
