import Vue from 'vue'

const error = (title, msg) => {
  Vue.prototype.$Notice.error({title, msg})
}

const warning = (config) => {
  Vue.prototype.$Message.warning(config)
}
const config = (config) => {
  Vue.prototype.$Message.config(config)
}
export {
  error,
  warning,
  config
}
