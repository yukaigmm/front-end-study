import http from "../api.js";
const baseURL = 'salesProject'
export default class saleProjectManageService{
  static async  saleProjectList(params){
    return http.get(baseURL, {params});
  }
  static async  createProject(data){
    return http.post(baseURL, data);
  }
  static async  updateProject(data){
    return http.put(baseURL + '/' + data.projectId, data);
  }
  static async  getDetail(id){
    return http.get(`${baseURL}/${id}`);
  }
  static async  getProjectOrg(params,projectId){
    return http.get(`${baseURL}/allocation/${projectId}`,{params});
  }
  static async  orgChildren(params){
    return http.get(`${baseURL}/orgChildren/${params.projectId}`,{params});
  }
  static async  deleteOrgById(data){
    return http.delete(`${baseURL}/allocation/${data.projectId}`,{data});
  }
  static async  getSalesProject(orgId){
    return http.get(`${baseURL}/getOrgProject/${orgId}`);
  }
  static async mySalesProject(){
    return http.get('mySalesProject');
  }
  static async addOrgToProject(data){
    return http.put(`${baseURL}/allocation/${data.projectId}`,data);
  }
  static async  getOrgDistribute(params){
    return http.get(`${baseURL}/getUserAllotOrg`,{params});
  }

  static async getAssignedOrgTree(params){
    return http.get(`${baseURL}/getOrgTree`,{params});
  }
}
