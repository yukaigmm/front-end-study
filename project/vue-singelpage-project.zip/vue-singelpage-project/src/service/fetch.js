import axios from 'axios'
import { error } from './notify'
import router from '@/router'
import http from './api'

export default async (type = 'GET', url = '', data = {}) => {
  type = type.toLowerCase()
  url = url.replace('api/', '');
  let resp

  // if (process.env.NODE_ENV !== 'production') {
    // url = /^\//.test(url) ? '/api' + url : '/api/' + url
  // }
  if (type === 'get') {
    resp = await http.get(url, {params: data})
  } else {
    resp = await http[type](url, data)
  }
  // if (resp.code !== 20000) {

  //   // 未登录 跳至登录页面
  //   if (resp.code === 10099) {
  //     router.push('/login')
  //   }else{
  //      let msg = resp.msg
  //      msg ? error(msg) : error('请求出错')
  //   }



  //   // throw new Error(resp.data.msg)
  // }

  return resp
}
