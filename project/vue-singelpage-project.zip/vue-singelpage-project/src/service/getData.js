import fetch from './fetch'

// const fetchCodeImage = () => fetch('GET', '/common/getCaptchaSrc')
// const fetchLogin = (data) => fetch('POST', '/login/crmLogin', data)
const fetchGrid = (url, data) => fetch('GET', 'api/' + url, data)
const fetchSelect = (url, data) => fetch('GET', 'api/' + url, data)
const postFormData = (url, data) => fetch('POST', 'api/' + url, data)
const putFormData = (url, id, data) => fetch('PUT', 'api/' + url + '/' + id, data)
const delRow = (url, id) => fetch('DELETE', 'api/' + url + '/' + id)
const getRow = (url, id) => fetch('GET', 'api/' + url + '/' + id) //获取一条信息
const delTableData = (url, data) => fetch("DELETE", url, data)
const putDatas = (url , data) => fetch("PUT" , "api/" + url ,data)

const fetchAllPullList = () => fetch('GET', 'api/common/getSelectAll')
const fetchCodeImage = () => fetch('GET', 'api/common/getCaptchaSrc')
const fetchLogin = (data) => fetch('POST', 'api/login/crmLogin', data)
const fetchUid = () => fetch('GET', 'api/common/getUid')
const fetchUser = () => fetch('GET', 'api/common/getLoginStatus')
const logout = () => fetch('GET', 'api/login/crmLogout')
const fetchWorkmate = () => fetch('GET', 'api/dept/getAllSelect')
const postComments = (data) => fetch('POST', 'api/msg/send', data)

const getSelectOptions = (url, data) => fetch('GET', 'api/' + url, data);

const getList = (url, data) => fetch('GET', 'api' + url, data);
const getReciver = (data) => fetch('GET', 'api/dept/getUserByDept', data)
const getWorkmate = (data) => fetch('GET', '/common/getUpdaterSelect', data)
const addListItem = (url, data) => fetch('POST', 'api' + url, data);
const updateListItem = (url, data) => fetch('PUT', 'api' + url + data.id, data);
const delListItem = (url, id) => fetch('DELETE', 'api' + url + '/' + id);

const getUpdatePerson = () => fetch('GET', 'api/common/getUpdaterSelect?type=1')
const getInnerDepart = () => fetch('GET', "api/dept/getAllSelect")
const getMessageCount = () => fetch('GET', "api/msg/count?type=1")


//plan
const getMonthViewOfPlans = (data) => fetch('GET', "api/plan/getMonthList", data);
const getDayViewOfPlans = (data) => fetch('GET', "api/plan/getDayList", data);
const getPlanDetail = (data) => fetch('GET', "api/plan/getPlan", data);
const addPlan = (data) => fetch('POST', "api/plan/addPlan", data);
const editPlan = (data) => fetch('PUT', "api/plan/savePlan", data);
const delPlan = (id) => fetch('DELETE', "api/plan/delPlan/" + id);
const setPlanStatus = (data) => fetch('PUT', "api/plan/setPlanStatus", data);
const cancelOrRecoveryPlan = (data) => fetch('PUT',"api/plan/setPlanValidStatus",data)
const ifVisitRecordExist = (visitId) => fetch("GET","api/visit/get/visit_id/"+visitId)

//task
const getTaskOrProjectList = (parentTaskId) => fetch("GET","api/tasks",parentTaskId)
const getTaskOrProjectDetails = (taskId) => fetch("GET","api/tasks/"+taskId);
const deleteTaskOrProject = (taskId) => fetch("DELETE"," api/tasks/" + taskId);

//team
const getTeamList = (data) => fetch("GET","api/teams",data)
const deleteTeam = (id) => fetch("DELETE","api/teams/" + id)
const getTeamDetails = (id) => fetch("GET","api/teams/" + id)
const addTeam = (data) => fetch("POST","api/teams",data)
const editTeam = (id,data) => fetch("PUT","api/teams/"+id,data)

// indicator

const getLinkedIndicators = (id) => fetch("GET","api/targets?",id)
const addNewIndicator = (data) => fetch("POST","api/targets",data)

//sales manage
const getCustomersList  = (data) => fetch("GET","api/contactMissings",data)
const fullfillMessage = (data) => fetch("POST","api/fillContactMissing",data)
const fastAddVisitRecord = (data) => fetch("POST","api/fastVisits",data)

//group
const getGroupList  = (data) => fetch('GET', 'api/CmGroup', data)
export {
  fetchCodeImage,
  fetchLogin,
  fetchGrid,
  fetchSelect,
  postFormData,
  putFormData,
  fetchUid,
  fetchUser,
  fetchWorkmate,
  logout,
  getRow,
  delRow,
  delTableData,
  getReciver,
  getWorkmate,
  getList,
  addListItem,
  updateListItem,
  delListItem,

  fetchAllPullList,
  getUpdatePerson,
  getInnerDepart,
  getMessageCount,
  putDatas,

  getMonthViewOfPlans,
  getDayViewOfPlans,
  getPlanDetail,
  addPlan,
  editPlan,
  delPlan,
  setPlanStatus,
  cancelOrRecoveryPlan,
  ifVisitRecordExist,
  //task
  getTaskOrProjectList,
  getTaskOrProjectDetails,
  deleteTaskOrProject,

  //team
  getTeamList,
  deleteTeam,
  getTeamDetails,
  addTeam,
  editTeam,

  // indicators
  getLinkedIndicators,
  addNewIndicator,

  //sales manage
  getCustomersList,
  fullfillMessage,
  fastAddVisitRecord,

  //group
  getGroupList
}
